// ──────────────────────────────────────────────────────────
// INSTRUMENTATION — server bootstrap hook (Next.js 16)
// Starts the market scheduler: every 60 s it recomputes each
// app market's live status (scheduled → open → closed) from
// its timings + bet-closing-minutes, and prunes expired
// customer-app sessions. This is the "cron job" that opens
// and closes markets automatically in the application.
// ──────────────────────────────────────────────────────────

export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return

  const g = globalThis as Record<string, unknown>
  if (g.__mbCronStarted) return
  g.__mbCronStarted = true

  const run = async () => {
    try {
      const { marketCronTick } = await import('./lib/market-cron')
      const r = await marketCronTick()
      if (r.changed > 0) {
        console.log('[cron] market states updated:', r.changed, '· sessions pruned:', r.pruned)
      }
    } catch (err) {
      // DB may not be ready during first boot — retry silently on next tick
      console.error('[cron] tick failed:', (err as Error).message)
    }
  }

  // First tick after 10 s, then every 60 s
  setTimeout(run, 10_000)
  const timer = setInterval(run, 60_000)
  if (typeof timer.unref === 'function') timer.unref()
  console.log('[cron] market scheduler started (60s interval)')
}
