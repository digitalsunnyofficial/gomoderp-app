import type { Metadata, Viewport } from 'next'
import CustomerApp from '@/components/customerapp/CustomerApp'

export const metadata: Metadata = {
  title: 'Satta Matka God — Customer App',
  description: 'Play, results and wallet — the Satta Matka God customer app',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#6d28d9',
}

// Customer app (Android WebView / mobile browser) — standalone from the ERP shell
export default function CustomerAppPage() {
  return <CustomerApp />
}
