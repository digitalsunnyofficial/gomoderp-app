/**
 * /g/<token> — Super-Admin encrypted entry.
 *
 * Valid token → redirect to /merp (ERP login). Invalid/unknown → plain 404.
 * See src/lib/admin-gate.ts for token derivation.
 */
import { notFound, redirect } from 'next/navigation'
import { isValidAdminGateToken } from '@/lib/admin-gate'

export default async function AdminGatePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  if (!isValidAdminGateToken(token)) notFound()
  redirect('/merp')
}
