'use client'

import React, { useState, useEffect, useCallback, useRef, useMemo, useTransition, useDeferredValue } from 'react'
import { useAppStore, type PageName, type MobileTab } from '@/lib/store'
import { syncHashForPage, pageFromHash } from '@/lib/cache-cookies'
import {
  LayoutDashboard, Plus, List, ClipboardList,
  HandCoins, Receipt, Users, UserCircle, Settings, LogOut,
  Bell, Menu, X, Eye, EyeOff, Pencil, Trash2, Search, ChevronLeft,
  ChevronRight, RefreshCw, Printer, Check, RotateCcw, Shield,
  Download, Share2, BarChart3, AlertTriangle, Copy, CheckCircle2, MessageCircle,
  MapPin, Activity, Lock, Unlock, History, Filter, Clock, UserX, UserPlus,
  CreditCard, Wallet, Globe, Crown, CalendarDays, ExternalLink, DollarSign, Zap,
  Palette, ShieldAlert
} from 'lucide-react'
import { GroupBatchInput } from '@/components/matka/GroupBatchInput'
import { GroupBatchPreview } from '@/components/matka/GroupBatchPreview'
import { buildGroupBatch, getMergedEntries, getGrandTotal } from '@/lib/matka/group-batch-engine'
import type { GroupOption, GroupBatchResult } from '@/lib/matka/group-types'

// ── Triple section direct items (2026-09 operator request) ──
// The old "Group" umbrella dropdown is gone: every chart type is offered
// directly under the Triple section, plus the three Sangam entry types.
const TRIPLE_GROUP_ITEMS: readonly string[] = [
  'SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP',
  'Motor Pana', 'SP Motor', 'DP Motor',
  '20 Chart', '30 Chart', '40 Chart', '50 Chart', '60 Chart', '70 Chart',
  '90 DP Chart', '90 ABR Chart', 'Family Chart',
]
const TRIPLE_SANGAM_ITEMS: readonly string[] = ['Half Sangam A', 'Half Sangam B', 'Full Sangam']
const TRIPLE_DIRECT_ITEMS: readonly string[] = ['Mix', 'Common', ...TRIPLE_GROUP_ITEMS, ...TRIPLE_SANGAM_ITEMS]
import {
  CHART_50_CUT, CHART_70_JODI7, CHART_60_PANNAS, CHART_90_DP, CHART_ABR9_PANNAS,
  CHART_20_PANNAS, CHART_30_PANNAS, CHART_40_PANNAS,
  pannaToAnk as chartPannaToAnk, canonicalPanna,
} from '@/lib/matka/chart-definitions'
import { FAMILY_SET_4, FAMILY_SET_6, FAMILY_SET_8, resolveFamilyKey } from '@/lib/matka/panna-family'

// ── Imports from extracted modules ──
import { formatCurrency, formatDate, formatDateTime, formatTime, formatPanna, normalizePanna, getCurrentTime, MarketChip, StatusBadge, MARKET_COLORS, loadCustomMarkets, saveCustomMarkets, getAllMarketKeys, getMarketLabel, CUSTOM_MARKETS_STORAGE_KEY, DEFAULT_CUSTOM_COLOR, type CustomMarket } from '@/lib/format'
import { apiFetch, recordParserExceptions, logChartRevision } from '@/lib/api-helpers'
import { PAGE_TITLES } from '@/lib/navigation'
import { canAccessPage } from '@/lib/access-control'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, BlueButton, Pagination, Modal } from '@/components/shared-ui'
import { Sidebar } from '@/components/layout/Sidebar'
import { Topbar } from '@/components/layout/Topbar'
import { LoginPage } from '@/components/pages/LoginPage'
import { DashboardPage } from '@/components/pages/DashboardPage'
import { NewInventoryPage } from '@/components/pages/NewInventoryPage'
import { InventoryListPage } from '@/components/pages/InventoryListPage'
import { UnifiedEntryPage } from '@/components/pages/UnifiedEntryPage'
import { ConfigurePage, UsersPage, MarketPermissionsPage, UserActivityPage, LockedUsersPage, ParserExceptionsPage, ParserConfigPage, PendingSignupsPage, ChartRevisionsPage } from '@/components/pages/SystemMgmtPages'
import { MarketResultsPage } from '@/components/pages/MarketsPages'
import { StarlinesPage, ChartDataPage } from '@/components/pages/MarketMgmtPages'
import { GameManagementPage, GameAllocationPage } from '@/components/pages/GamesPages'
import { UnifiedCustomerListPage } from '@/components/pages/CustomerListPages'
import { PaywallPage, SubscriptionPlansPage, UserSubscriptionsPage, PaymentsPage, MobilePaywallPage } from '@/components/pages/SubscriptionPages'
import { HierarchyManagersPage, HierarchyAgentsPage, HierarchyCustomersPage } from '@/components/pages/HierarchyPages'
import { AppCustomersPage, AppBidsPage, FundRequestsPage } from '@/components/pages/AppAdminPages'
import { AppNotificationsPage } from '@/components/pages/AppNotificationsPage'
import { AppContentPage, AppBuildPage } from '@/components/pages/AppAdminPages3'
import { ChitthiPage } from '@/components/pages/ChitthiPages'
import { WhatsAppDashboardPage } from '@/components/pages/WhatsAppDashboardPage'
import { WhatsAppMessagesPage } from '@/components/pages/WhatsAppMessagesPage'
import { WhatsAppTemplatesPage } from '@/components/pages/WhatsAppTemplatesPage'
import { WhatsAppApprovalsPage, WhatsAppLearningPage, WhatsAppMappingsPage } from '@/components/pages/WhatsAppOperationsPages'
import { AgentCommissionPage } from '@/components/pages/AgentCommissionPage'
import { getMobileTabForPage, getPageForMobileTab, MobileLoginPage, MobileBottomNav, MobileTopBar, MobileFAB, MobileDashboardPage, MobileNewCardPage, MobileCardListPage, MobileKhatriPage, MobileProfilePage } from '@/components/pages/MobilePages'
import { DictationFormatButton } from '@/components/DictationFormatButton'
import { autoFormatDictation } from '@/lib/speech-dictation'

// ────────────────────────────────────────
// WHATSAPP PARSING LOGIC
// ────────────────────────────────────────

interface ParsedEntry {
  number: string
  price: number
  skipped?: boolean   // Valid panna number, but missing rate/amount
  dropped?: boolean   // Invalid token or syntax — not a recognizable panna
}

// Parser result includes entries + metadata for SKIPPED/DROPPED reporting
interface ParseResult {
  entries: ParsedEntry[]
  skippedNumbers: string[]   // Valid pannas with no rate
  droppedTokens: string[]    // Invalid tokens / unrecognized syntax
}

// Parse Milan-style Double input: "23.42.72.82.92.02." per line with "=500rs" at the end
function parseDoubleDotFormat(content: string): { entries: Array<{ number: string; price: number }>; rate: number; vendorName: string } {
  const lines = content.split('\n').map(l => l.trim()).filter(l => l.length > 0)
  const entries: Array<{ number: string; price: number }> = []
  let rate = 0
  let vendorName = ''

  for (const line of lines) {
    // Check if line ends with a rate like ".....=500rs" or "=500" or "500rs"
    const rateMatch = line.match(/[.=]+\s*(\d+)\s*(?:rs)?\s*$/i)
    if (rateMatch) {
      rate = parseInt(rateMatch[1])
      // Strip the rate part from the line for number extraction
      const lineWithoutRate = line.replace(/[.=]+\s*\d+\s*(?:rs)?\s*$/i, '')
      // Extract 2-digit numbers from dots
      const parts = lineWithoutRate.split('.').map(p => p.trim()).filter(p => /^\d{2}$/.test(p))
      for (const p of parts) entries.push({ number: p, price: rate })
      continue
    }

    // Check if this is a vendor name line (no digits or mostly text)
    const digitCount = (line.match(/\d/g) || []).length
    if (digitCount < 2 && !vendorName) {
      // Could be a vendor/series name like "Milan"
      const textParts = line.split(/[\s.]+/).filter(p => p.length > 0 && !/^\d+$/.test(p))
      if (textParts.length > 0) {
        vendorName = textParts.join(' ')
      }
      continue
    }

    // Extract 2-digit numbers from dot-separated format
    const dotParts = line.split('.').map(p => p.trim()).filter(p => /^\d{2}$/.test(p))
    if (dotParts.length > 0) {
      for (const p of dotParts) entries.push({ number: p, price: rate })
      continue
    }

    // Try comma/space separated 2-digit numbers
    const spaceParts = line.split(/[\s,]+/).map(p => p.trim()).filter(p => /^\d{2}$/.test(p))
    if (spaceParts.length > 0) {
      for (const p of spaceParts) entries.push({ number: p, price: rate })
    }
  }

  // Aggregate duplicate numbers (sum prices)
  const agg = new Map<string, number>()
  for (const e of entries) {
    agg.set(e.number, (agg.get(e.number) || 0) + e.price)
  }
  const finalEntries = Array.from(agg.entries()).map(([number, price]) => ({ number, price }))

  return { entries: finalEntries, rate, vendorName }
}

// ────────────────────────────────────────────────────────────────────────────
// DEBUG MODE (v4 fix, retained in v5)
// ────────────────────────────────────────────────────────────────────────────
// Toggle from the browser console at any time:
//   window.__parserDebug = true    // enable
//   window.__parserDebug = false   // disable
// When enabled, every parse / submit / render step logs timing to the console.
// ────────────────────────────────────────────────────────────────────────────
declare global { interface Window { __parserDebug?: boolean } }
function parserDebug(label: string, details?: Record<string, unknown>): void {
  if (typeof window !== 'undefined' && window.__parserDebug === true) {
    const t = new Date().toISOString().split('T')[1]
    if (details) {
      console.log(`%c[parser ${t}]`, 'color:#C9A84C;font-weight:bold', label, details)
    } else {
      console.log(`%c[parser ${t}]`, 'color:#C9A84C;font-weight:bold', label)
    }
  }
}

// ────────────────────────────────────────────────────────────────────────────
// Parser safety caps (v4 fix, retained in v5)
// ────────────────────────────────────────────────────────────────────────────
const PARSER_TIME_BUDGET_MS = 3000
const PARSER_BUDGET_CHECK_INTERVAL = 50
const MAX_LINE_LENGTH = 500
const MAX_PARSER_ENTRIES = 2000
const MAX_PARSER_LINES = 3000
const MAX_DROPPED_TOKENS = 200
const MAX_SKIPPED_NUMBERS = 200
const MAX_RENDER_TRIPLES = 200
const MAX_RENDER_DS = 200

// ============================================================================
// PARSER v5 — 5-STAGE DESIGN (handles all 19 grammar patterns + aggregation)
// ============================================================================
//
//   Stage 1: Remove WhatsApp metadata (timestamps, names, phone headers)
//   Stage 2: Remove noise words (Type 16: Mob, MB, DMO, DMB, Mo.ko, Total, etc.)
//   Stage 3: Normalize separators (. , .. , ... , .... , = , == , === , + , - ,
//            * , : , / , _) — all collapse to a single split point
//   Stage 4: Extract pannas[] and amount (last numeric token before ₹/rs suffix)
//   Stage 5: Aggregate (Type 18: Map<number, totalAmount> — ALWAYS sum dups)
//
// All 19 patterns supported:
//   Type 1:  489.50₹                  — single panna + sep + amount
//   Type 2:  366/690/456...50₹        — N pannas + sep + amount
//   Type 3:  347,356,590,267.....200₹ — comma group + dots amount
//   Type 4:  123.135.158...150rs      — dot group + amount
//   Type 5:  145-127-230-129..25₹     — hyphen group + amount
//   Type 6:  128:560:129:679...700₹  — colon group + amount
//   Type 7:  119 110 112 113...350₹   — space group + amount
//   Type 8:  matrix lines + +150₹     — multi-line matrix (carry-forward)
//   Type 9:  680=200₹                 — assignment
//   Type 10: 178*200₹                 — star separator
//   Type 11: 470+200₹                 — plus separator (NOT addition)
//   Type 12: 488,448,247,389,377..50₹ — pending pannas then amount (also multi-line)
//   Type 13: 577,469,356..25₹         — mixed pending
//   Type 14: 159,357___370₹           — underscore separator (multi-line carry-forward)
//   Type 15: 280.357=200₹             — multiple groups one line
//   Type 16: noise words              — ignore (Mob, MB, DMO, DMB, etc.)
//   Type 17: 566 166 660 150₹         — last numeric token is amount
//   Type 18: 389=260₹ + 389=30₹ → 389=290₹ — aggregate duplicates (ALWAYS sum)
//   Type 19: 000=25₹                  — keep as "000", never convert to "0"
// ============================================================================

// WhatsApp message header: [6/6/2026, 3:03 PM] Salman Ansari: content
// Also matches [06-06-26, 15:03] +91 98765 43210: content
// Also matches [06/06, 9:22 pm] Name: content  (no year — common in WhatsApp exports)
// Also matches [8:47 pm, 29/7/2026] Name: content  (time-first format — common in WhatsApp mobile)
const WA_HEADER_RE = /^\[\s*(?:(?:\d{1,2}[\/\-.]\d{1,2}(?:[\/\-.]\d{2,4})?\s*,?\s*)?\d{1,2}:\d{2}\s*(?:AM|PM)?\s*(?:,\s*\d{1,2}[\/\-.]\d{1,2}(?:[\/\-.]\d{2,4})?)?|\d{1,2}[\/\-.]\d{1,2}(?:[\/\-.]\d{2,4})?\s*,?\s*\d{1,2}:\d{2}\s*(?:AM|PM)?)\s*\]\s+([^:]+?)\s*:\s*(.*)$/i

// Type 16 — noise words to drop COMPLETELY (entire line is garbage)
const NOISE_LINE_RE = /^(Mob|MB|M\.B|M\s*b|Mo|NMB|DMO|DMB|Mo\.ko|Mb\.kb|Mop\.?|SR|Ko|Rs|Total|========|Mohabat(?:\s+Bazaar)?)\s*[:.]?\s*$/i

// Type 16 — leading noise-word prefixes to strip from a line: "Mo 345=200₹" → "345=200₹"
const NOISE_PREFIX_RE = /^(?:Mob|MB|M\.B|M\s*b|Mo|NMB|DMO|DMB|Mo\.ko|Mb\.kb|Mop\.?|SR|Ko|Rs)\s+/i

// Type 16b — group type prefixes to strip from a line: "Spdpmo 12489=50" → "12489=50"
// Handles: Spdpmo, Spmo, Spdp, Sptp, Dptp, Spdptp, Motor Pana, Motor, Sp, Dp, Tp
const TYPE_PREFIX_RE = /^(?:Spdpmo|Spmo|Spdp|Sptp|Dptp|Spdptp|Motor\s*(?:Pana)?|Sp|Dp|Tp)\s+/i

// Type 16b — standalone type label lines to drop entirely: "Spdpmo", "Motor Pana"
const TYPE_LABEL_RE = /^(?:Spdpmo|Spmo|Spdp|Sptp|Dptp|Spdptp|Motor(?:\s+Pana)?|Sp|Dp|Tp)\s*[:.]?\s*$/i

// All separator characters for Stage 3 (used in a RegExp character class)
// Underscore `_` is included (Type 14)
const SEPARATOR_CHARS = '.,=+\\-*:/_'
// Regex that splits a line on any run of separators (also collapses whitespace)
const SPLIT_RE = new RegExp('[' + SEPARATOR_CHARS + '\\s]+')

// Stage 4 — extract the trailing amount (1-5 digits, MUST be followed by ₹/rs).
// Captures everything BEFORE the rate (group 1) and the rate itself (group 2).
// The rate must be preceded by either start-of-line or a separator run,
// so that "489.50₹" yields before="489" and rate="50" (not before="" rate="48950").
//
// CRITICAL: ₹/rs is MANDATORY. Without it, lines like "155,669,588,227"
// (matrix pannas without a rate) would be misparsed — the last number "227"
// would be wrongly treated as the rate, losing that panna and assigning
// the wrong rate to the others.
const RATE_SUFFIX_RE = new RegExp(
  '^(.*?)[' + SEPARATOR_CHARS + '\\s]*(\\d{1,5})\\s*[.,]*\\s*(?:₹|rs)\\s*$',
  'i'
)

// ────────────────────────────────────────────────────────────────────────────
// NEW FAST-PATH REGEX PATTERNS for common WhatsApp formats (no ₹/rs suffix)
// These are tried BEFORE the existing Stage 3+4 logic in parseLineV5().
// When a pattern matches, we return immediately. Otherwise we fall through.
// ────────────────────────────────────────────────────────────────────────────

// (NNN)RATE or (NN)RATE — panna in parentheses with rate (Format 1)
const PAREN_RATE_RE = /^\((\d{2,3})\)\s*(\d+)\s*$/

// [NN]-RATE or [NNN]-RATE — double/triple in brackets with rate (Format 13)
const BRACKET_DASH_RE = /^\[(\d{2,3})\]\s*[-–]\s*(\d+)\s*$/

// NN-rsRATE — double with rs before rate (Format 8)
const RS_RATE_RE = /^(\d{2,3})\s*[-–]\s*rs\s*(\d+)\s*$/i

// NN*NN=RATE — double pair with equals rate (Format 15: 33*38=50)
const PAIR_EQ_RE = /^(\d{2})\s*[*×xX]\s*(\d{2})\s*=\s*(\d+)\s*$/

// *N=RATE or ×N=RATE — star/× prefix with equals (Format 2: *1=20, *6=20)
const STAR_EQ_RE = /^[*×xX]\s*(\d{1,3})\s*=\s*(\d+)\s*$/

// ×NNN-RATE or *NNN-RATE — star/× prefix with dash (Format 19: ×990-25)
const X_DASH_RE = /^[*×xX]\s*(\d{2,3})\s*[-–]\s*(\d+)\s*$/

// Space-separated group with trailing =RATE (Format 7: "44 49 94 99=25" or "61 =50")
const GROUP_RATE_RE = /^((?:\d{2,3}\s+)+\d{2,3})\s*=\s*(\d+)\s*$/

// Single number with space then =RATE (Format 7: "61 =50")
const SINGLE_EQ_RATE_RE = /^(\d{2,3})\s+=\s*(\d+)\s*$/

// Dot-separated doubles with trailing rate (Format 14: "05 . 00 . 55 . 50 ..... 10 rs")
const DOT_GROUP_RS_RE = /^((?:\d{2}\s*\.\s*)+\d{2})\s*\.{3,}\s*(\d+)\s*rs\s*$/i

// Comma-separated inline with dash rate (Format 6: "91-20, 96-20, 90-20, 95-20")
// Detected by presence of comma — handled specially in parseLineV5

// NN=RATE or NNN=RATE — double/triple with equals (Format 2: 64=40, 08=25)
const EQUALS_RATE_RE = /^(\d{2,3})\s*=\s*(\d+)\s*$/

// NNN*RATE — triple with star (Format 11: 149*200, 240*20)
const TRIPLE_STAR_RE = /^(\d{3})\s*[*]\s*(\d+)\s*$/

// NN*RATE — double with star (Format 2 variant: 64*20)
const DOUBLE_STAR_RE = /^(\d{2})\s*[*]\s*(\d+)\s*$/

// N*RATE or N×RATE — single with star/× (Format 11: 4*350)
const SINGLE_STAR_RE = /^(\d{1})\s*[×xX*]\s*(\d+)\s*$/

// NN/-RATE — double with slash-dash (Format 4: 03/-20)
const SLASH_DASH_RE = /^(\d{2,3})\s*\/[-–]\s*(\d+)\s*$/

// N/RATE or NN/RATE — single/double with slash (Format 5: 9/25, 99/5)
const SLASH_RATE_RE = /^(\d{1,3})\s*\/\s*(\d+)\s*$/

// NN..RATE or NNN..RATE — double-dot format (Format 21: 08..10)
const DOT_DOT_RE = /^(\d{2,3})\s*\.{2,}\s*(\d+)\s*$/

// NN.RATE — double with single dot, Milan style (Format 17: 02.20, 07.20)
// IMPORTANT: Only match exactly 2 digits before the dot to avoid conflicting
// with "NNN.RATE" (3-digit panna + decimal rate) which the existing parser handles
const DOT_RATE_RE = /^(\d{2})\.\s*(\d+)\s*$/

// NNN-RATE — triple with dash (Format 12: 199-30, 679-20)
const TRIPLE_DASH_RE = /^(\d{3})\s*[-–]\s*(\d+)\s*$/

// NN-RATE — double with dash (Format 6/18: 91-20, 18-100)
const DOUBLE_DASH_RE = /^(\d{2})\s*[-–]\s*(\d+)\s*$/

// N-RATE — single with dash (Format 20: 1-250, 4-200)
const SINGLE_DASH_RE = /^(\d{1})\s*[-–]\s*(\d+)\s*$/

// NNN×RATE — triple with ×/x/X separator (Format 16: 579×10, 244x10)
const TRIPLE_X_RE = /^(\d{3})\s*[×xX]\s*(\d+)\s*$/

// NN×RATE — double with ×/x/X separator
const DOUBLE_X_RE = /^(\d{2})\s*[×xX]\s*(\d+)\s*$/

// N×RATE — single with ×/x/X separator (Format 19: 1×75, 6×50)
const SINGLE_X_RE = /^(\d{1})\s*[×xX]\s*(\d+)\s*$/

// Parse a single line into { pannas, rate } using Stage 3 + Stage 4.
// Returns rate=null when no amount suffix is found (pannas go to pending buffer).
// In group mode, also accepts bare "DIGITS=RATE" format without ₹/rs suffix.
function parseLineV5(line: string, isGroupMode = false): { pannas: string[]; rate: number | null } {
  const trimmed = line.trim()
  if (trimmed.length === 0) return { pannas: [], rate: null }

  // ── NEW FAST PATH: Common WhatsApp formats without ₹/rs suffix ──
  // These patterns are tried FIRST. If any matches, we return immediately.
  // If none matches, we fall through to the existing Stage 3+4 logic.

  // Format 1: (NNN)RATE — panna in parentheses with rate
  let m = trimmed.match(PAREN_RATE_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 13: [NN]-RATE — double in brackets with rate
  m = trimmed.match(BRACKET_DASH_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 8: NN-rsRATE — double with rs before rate
  m = trimmed.match(RS_RATE_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 15: NN*NN=RATE — double pair with equals rate (33*38=50)
  m = trimmed.match(PAIR_EQ_RE)
  if (m) return { pannas: [m[1], m[2]], rate: parseInt(m[3], 10) }

  // Format 2 variant: *N=RATE — star prefix with equals (*1=20, *6=20)
  m = trimmed.match(STAR_EQ_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 19: ×NNN-RATE — × prefix with dash (×990-25)
  m = trimmed.match(X_DASH_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 14: dot-separated doubles with trailing rs rate
  // "05 . 00 . 55 . 50 ..... 10 rs"
  m = trimmed.match(DOT_GROUP_RS_RE)
  if (m) {
    const nums = m[1].split(/\s*\.\s*/).filter((n: string) => /^\d{2}$/.test(n))
    return { pannas: nums, rate: parseInt(m[2], 10) }
  }

  // Format 7: space-separated group with trailing =RATE
  // "44 49 94 99=25" or "47 74 26 62 30 32=10"
  // Must have at least 2 space-separated numbers before =rate
  m = trimmed.match(GROUP_RATE_RE)
  if (m) {
    const nums = m[1].trim().split(/\s+/).filter((n: string) => /^\d{2,3}$/.test(n))
    if (nums.length >= 2) return { pannas: nums, rate: parseInt(m[2], 10) }
  }

  // Format 7 variant: single number with space then =RATE ("61 =50")
  m = trimmed.match(SINGLE_EQ_RATE_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Comma-separated inline entries (Format 6: "91-20, 96-20, 90-20, 95-20")
  // Split on commas, parse each sub-entry, collect all pannas
  if (trimmed.includes(',')) {
    const parts = trimmed.split(',').map((p: string) => p.trim()).filter((p: string) => p.length > 0)
    if (parts.length >= 2) {
      const subPannas: string[] = []
      let subRate: number | null = null
      let allOk = true
      for (const part of parts) {
        // Try each sub-pattern for the comma-separated part
        const sm = part.match(/^(\d{1,3})\s*[-–]\s*(\d+)\s*$/) ||
                   part.match(/^(\d{1,3})\s*=\s*(\d+)\s*$/) ||
                   part.match(/^(\d{1,3})\s*[×xX*]\s*(\d+)\s*$/) ||
                   part.match(/^(\d{1,3})\s*\/\s*(\d+)\s*$/)
        if (sm) {
          const r = parseInt(sm[2], 10)
          if (subRate === null) subRate = r
          else if (subRate !== r) { allOk = false; break } // different rates — bail
          subPannas.push(sm[1])
        } else {
          allOk = false; break
        }
      }
      if (allOk && subPannas.length > 0 && subRate !== null) {
        return { pannas: subPannas, rate: subRate }
      }
    }
  }

  // Format 2/3: NN=RATE or NNN=RATE — double/triple with equals (64=40, 08=25)
  m = trimmed.match(EQUALS_RATE_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 16/11: NNN×RATE — triple with ×/x/X separator (579×10, 244x10)
  m = trimmed.match(TRIPLE_X_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 11: NNN*RATE — triple with star (149*200, 240*20)
  m = trimmed.match(TRIPLE_STAR_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Double with ×/x/X separator
  m = trimmed.match(DOUBLE_X_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Double with star
  m = trimmed.match(DOUBLE_STAR_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 19: N×RATE — single with ×/x/X separator (1×75, 6×50)
  m = trimmed.match(SINGLE_X_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Single with star (4*350)
  m = trimmed.match(SINGLE_STAR_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 4: NN/-RATE — double with slash-dash (03/-20)
  m = trimmed.match(SLASH_DASH_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 5: N/RATE or NN/RATE — single/double with slash (9/25, 99/5)
  m = trimmed.match(SLASH_RATE_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 21: NN..RATE or NNN..RATE — double-dot format (08..10)
  m = trimmed.match(DOT_DOT_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 17: NN.RATE — double with single dot, Milan style (02.20, 07.20)
  // Only match 2-digit before dot to avoid conflicting with existing "NNN.RATE₹" handling
  m = trimmed.match(DOT_RATE_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 12: NNN-RATE — triple with dash (199-30, 679-20)
  m = trimmed.match(TRIPLE_DASH_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 6/18: NN-RATE — double with dash (91-20, 18-100)
  m = trimmed.match(DOUBLE_DASH_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // Format 20: N-RATE — single with dash (1-250, 4-200)
  m = trimmed.match(SINGLE_DASH_RE)
  if (m) return { pannas: [m[1]], rate: parseInt(m[2], 10) }

  // ── END NEW FAST PATH ──
  // No new pattern matched — fall through to existing Stage 3+4 logic

  // Stage 4: try to peel the trailing rate suffix
  let workLine = line
  let rate: number | null = null

  m = line.match(RATE_SUFFIX_RE)
  if (m) {
    const before = m[1]
    const rateStr = m[2]
    const rateNum = parseInt(rateStr, 10)
    // The "before" portion must contain at least one digit (a panna)
    // OR be empty (meaning the whole line is just "AMOUNT₹" — standalone rate).
    // If "before" has no digits but rateNum is valid, treat as standalone rate.
    if (rateNum > 0 && before.length === 0) {
      // Pure standalone rate line, e.g. "20₹"
      rate = rateNum
      workLine = ''
    } else if (rateNum > 0 && /\d/.test(before)) {
      // Has pannas before the rate
      rate = rateNum
      workLine = before
    }
    // else: rateNum is 0 or "before" has no digits — leave rate=null, treat
    // whole line as a potential panna list (it will be parsed below)
  }

  // Group mode: also try bare "DIGITS=RATE" format without ₹/rs suffix
  // e.g. "12489=50" → seed "12489" with rate 50
  if (rate === null && isGroupMode) {
    const bareM = line.match(/^(\d{1,10})[.=]+\s*(\d+)\s*$/)
    if (bareM) {
      const seed = bareM[1]
      const rateNum = parseInt(bareM[2], 10)
      if (rateNum > 0 && seed.length > 0) {
        return { pannas: [seed], rate: rateNum }
      }
    }
  }

  // Stage 3: split workLine on any separator run
  const maxDigits = isGroupMode ? '1,10' : '1,4'
  const digitRe = new RegExp('^\\d{' + maxDigits + '}$')
  const tokens = workLine.split(SPLIT_RE).filter(t => t.length > 0)
  const pannas: string[] = []
  for (const t of tokens) {
    // Accept numeric tokens as candidate pannas/seeds.
    // Non-numeric tokens are dropped at the caller layer (we don't have access
    // to the droppedTokens array here, but the caller can re-validate by mode).
    if (digitRe.test(t)) {
      pannas.push(t)
    }
  }

  return { pannas, rate }
}

// Fast-path helper: try all new regex patterns on a single line.
// Returns ParsedEntry[] if any pattern matches, or null if not.
// This avoids the full pipeline for common WhatsApp formats.
function fastParseNewFormats(line: string, shouldNormalize: boolean): ParsedEntry[] | null {
  // Format 1: (NNN)RATE
  let m = line.match(PAREN_RATE_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize && n.length === 3) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Format 13: [NN]-RATE
  m = line.match(BRACKET_DASH_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize && n.length === 3) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Format 8: NN-rsRATE
  m = line.match(RS_RATE_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 15: NN*NN=RATE
  m = line.match(PAIR_EQ_RE)
  if (m) {
    const r = parseInt(m[3], 10)
    return [{ number: m[1], price: r }, { number: m[2], price: r }]
  }

  // Format 2 variant: *N=RATE
  m = line.match(STAR_EQ_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 19: ×NNN-RATE
  m = line.match(X_DASH_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize && n.length === 3) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Format 14: dot-separated doubles with trailing rs rate
  m = line.match(DOT_GROUP_RS_RE)
  if (m) {
    const nums = m[1].split(/\s*\.\s*/).filter((n: string) => /^\d{2}$/.test(n))
    const r = parseInt(m[2], 10)
    return nums.map((n: string) => ({ number: n, price: r }))
  }

  // Format 7: space-separated group with trailing =RATE
  m = line.match(GROUP_RATE_RE)
  if (m) {
    const nums = m[1].trim().split(/\s+/).filter((n: string) => /^\d{2,3}$/.test(n))
    if (nums.length >= 2) {
      const r = parseInt(m[2], 10)
      return nums.map((n: string) => {
        let nn = n
        if (shouldNormalize && nn.length === 3) nn = normalizePanna(nn)
        return { number: nn, price: r }
      })
    }
  }

  // Format 7 variant: single number with space then =RATE
  m = line.match(SINGLE_EQ_RATE_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize && n.length === 3) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Comma-separated inline entries
  if (line.includes(',')) {
    const parts = line.split(',').map((p: string) => p.trim()).filter((p: string) => p.length > 0)
    if (parts.length >= 2) {
      const subEntries: ParsedEntry[] = []
      let subRate: number | null = null
      let allOk = true
      for (const part of parts) {
        const sm = part.match(/^(\d{1,3})\s*[-–]\s*(\d+)\s*$/) ||
                   part.match(/^(\d{1,3})\s*=\s*(\d+)\s*$/) ||
                   part.match(/^(\d{1,3})\s*[×xX*]\s*(\d+)\s*$/) ||
                   part.match(/^(\d{1,3})\s*\/\s*(\d+)\s*$/)
        if (sm) {
          const r = parseInt(sm[2], 10)
          if (subRate === null) subRate = r
          else if (subRate !== r) { allOk = false; break }
          let n = sm[1]
          if (shouldNormalize && n.length === 3) n = normalizePanna(n)
          subEntries.push({ number: n, price: r })
        } else {
          allOk = false; break
        }
      }
      if (allOk && subEntries.length > 0) return subEntries
    }
  }

  // Format 2/3: NN=RATE or NNN=RATE
  m = line.match(EQUALS_RATE_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize && n.length === 3) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Format 16/11: NNN×RATE
  m = line.match(TRIPLE_X_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Format 11: NNN*RATE
  m = line.match(TRIPLE_STAR_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Double with ×/x/X
  m = line.match(DOUBLE_X_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Double with star
  m = line.match(DOUBLE_STAR_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Single with ×/x/X
  m = line.match(SINGLE_X_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Single with star
  m = line.match(SINGLE_STAR_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 4: NN/-RATE
  m = line.match(SLASH_DASH_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 5: N/RATE or NN/RATE
  m = line.match(SLASH_RATE_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 21: NN..RATE
  m = line.match(DOT_DOT_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 17: NN.RATE (Milan style)
  m = line.match(DOT_RATE_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 12: NNN-RATE
  m = line.match(TRIPLE_DASH_RE)
  if (m) {
    let n = m[1]
    if (shouldNormalize) n = normalizePanna(n)
    return [{ number: n, price: parseInt(m[2], 10) }]
  }

  // Format 6/18: NN-RATE
  m = line.match(DOUBLE_DASH_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  // Format 20: N-RATE
  m = line.match(SINGLE_DASH_RE)
  if (m) return [{ number: m[1], price: parseInt(m[2], 10) }]

  return null
}

// Fast-path: if EVERY non-empty line matches the simple "NNN=RATE₹" pattern
// OR one of the new format patterns, parse them all without entering the full
// pipeline. This keeps the common case (operators typing one bet per line)
// instant on slow mobile CPUs.
function fastParsePannaRateLines(content: string, mode: string): ParsedEntry[] | null {
  const lines = content.split('\n').map(l => l.trim()).filter(l => l.length > 0)
  if (lines.length === 0) return null

  const shouldNormalize = mode === 'mix' || mode === 'triple'  // Group mode never normalizes — seeds are raw digit strings
  // Mode validity filter — MUST match the full pipeline's isValidPanna rules.
  // Without this, the fast path leaks wrong-length numbers into the mode's
  // results (e.g. a 3-digit panna "128" appearing in the DOUBLE grid with a
  // bogus column position, inflating totals). The full pipeline filters via
  // isValidPanna; the fast path previously did NOT — that asymmetry is why
  // "only certain patterns" behaved differently between the triple and
  // double tabs.
  const isValidForMode = (n: string): boolean => {
    if (!/^\d+$/.test(n)) return false
    if (mode === 'group') return n.length >= 1 && n.length <= 10
    if (n.length < 1 || n.length > 4) return false
    if (mode === 'single') return n.length === 1
    if (mode === 'double') return n.length === 2
    return true // mix / triple / amount: accept 1-4 digits
  }
  const entries: ParsedEntry[] = []
  const simpleRe = mode === 'group'
    ? /^(\d{1,10})[.=]+\s*(\d+)\s*[.,]*\s*(?:₹|rs)\s*$/i
    : /^(\d{1,4})[.=]+\s*(\d+)\s*[.,]*\s*(?:₹|rs)\s*$/i
  let matchCount = 0
  let sawWrongLength = false // if a line's numbers are valid format but wrong length for this mode, bail to full parser (it records them as dropped)

  for (const line of lines) {
    if (/^[=\-+_*#]{3,}$/.test(line)) continue
    if (/^\d{5,}\s*$/.test(line)) continue
    if (/^total/i.test(line)) continue
    if (NOISE_LINE_RE.test(line)) continue
    if (TYPE_LABEL_RE.test(line)) continue

    // Try the original simple ₹/rs pattern first
    const m = line.match(simpleRe)
    if (m) {
      const num = m[1]
      const price = parseInt(m[2], 10)
      if (price > 0) {
        let n = num
        if (shouldNormalize && n.length === 3) n = normalizePanna(n)
        if (!isValidForMode(n)) { sawWrongLength = true; break }
        entries.push({ number: n, price })
        matchCount++
        continue
      }
    }
    // In group mode, also try bare "DIGITS=RATE" format (no ₹/rs suffix)
    if (mode === 'group') {
      const bareM = line.match(/^(\d{1,10})[.=]+\s*(\d+)\s*$/)
      if (bareM) {
        const num = bareM[1]
        const price = parseInt(bareM[2], 10)
        if (price > 0) {
          entries.push({ number: num, price })
          matchCount++
          continue
        }
      }
    }

    // Try new format patterns (fast path for common WhatsApp formats)
    const newFmtEntries = fastParseNewFormats(line, shouldNormalize)
    if (newFmtEntries) {
      // Mode-filter each entry — wrong-length numbers send the line to the
      // full parser so they are properly recorded as DROPPED there.
      const filtered = newFmtEntries.filter(e => isValidForMode(e.number))
      if (filtered.length !== newFmtEntries.length) { sawWrongLength = true; break }
      entries.push(...filtered)
      matchCount += filtered.length
      continue
    }

    // Any non-matching line bails out to the full parser
    return null
  }

  if (sawWrongLength) return null
  if (matchCount < 1) return null  // Group mode can have just 1 seed
  return entries
}

function parseWhatsAppContent(content: string, mode: string, defaultRate: number = 0): ParsedEntry[] {
  // The legacy entry-point returns just entries[]. Internally we delegate to
  // the full parser and discard the skipped/dropped metadata.
  return parseWhatsAppContentFull(content, mode, defaultRate).entries
}

// Extended parser — full ParseResult with SKIPPED/DROPPED metadata + aggregation
function parseWhatsAppContentFull(content: string, mode: string, defaultRate: number = 0): ParseResult {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now()
  parserDebug('parseWhatsAppContentFull start', { mode, contentLen: content.length, defaultRate })

  // Fast path: simple "NNN=RATE₹" lines (90%+ of real input)
  const fastResult = fastParsePannaRateLines(content, mode)
  if (fastResult) {
    parserDebug('parseWhatsAppContentFull: fast path', { entries: fastResult.length })
    // Still apply Stage 5 aggregation on the fast path — duplicates must be summed
    const aggregated = aggregateEntries(fastResult)
    return { entries: aggregated, skippedNumbers: [], droppedTokens: [] }
  }

  const rawEntries: ParsedEntry[] = []
  const skippedNumbers: string[] = []
  const droppedTokens: string[] = []
  const lines = content.split('\n').map(l => l.trim())
  const shouldNormalize = mode === 'mix' || mode === 'triple'

  // Pending pannas buffer — for Type 12, 13, 14, 8 (multi-line carry-forward)
  let pendingNumbers: string[] = []

  function normalizeN(n: string): string {
    if (shouldNormalize && n.length === 3) return normalizePanna(n)
    return n
  }

  function flushPending(rate: number) {
    for (const n of pendingNumbers) {
      const nn = normalizeN(n)
      rawEntries.push({ number: nn, price: rate })
    }
    pendingNumbers = []
  }

  function dropPending() {
    for (const n of pendingNumbers) {
      const nn = normalizeN(n)
      rawEntries.push({ number: nn, price: 0, skipped: true })
      skippedNumbers.push(nn)
    }
    pendingNumbers = []
  }

  function isValidPanna(n: string): boolean {
    if (!/^\d+$/.test(n)) return false
    if (mode === 'group') return n.length >= 1 && n.length <= 10  // Seeds can be 1-10 digit strings
    if (n.length < 1 || n.length > 4) return false
    if (mode === 'single') return n.length === 1
    if (mode === 'double') return n.length === 2
    // mix / triple / amount: accept 1-4 digits (matrix pannas etc.)
    return true
  }

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const rawLine = lines[lineIdx]
    if (rawLine.length === 0) continue

    // ── Time-budget guard (v4 fix, retained) ──
    if (lineIdx % PARSER_BUDGET_CHECK_INTERVAL === 0 && lineIdx > 0) {
      const elapsed = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0
      if (elapsed > PARSER_TIME_BUDGET_MS) {
        const err = new Error(
          `Parser exceeded ${PARSER_TIME_BUDGET_MS}ms time budget on line ${lineIdx} of ${lines.length}. ` +
          `Input is too complex or contains a pathological pattern. Please simplify and try again.`
        )
        ;(err as Error & { code?: string }).code = 'PARSER_TIMEOUT'
        parserDebug('parser: TIME BUDGET EXCEEDED', { lineIdx, elapsed: Math.round(elapsed) })
        throw err
      }
    }
    if (rawEntries.length >= MAX_PARSER_ENTRIES) break
    if (rawLine.length > MAX_LINE_LENGTH) continue
    if (lineIdx >= MAX_PARSER_LINES) break

    // ── STAGE 1: Strip WhatsApp metadata ──
    let line = rawLine
    const headerMatch = line.match(WA_HEADER_RE)
    if (headerMatch) {
      const namePart = headerMatch[1].trim()
      const contentPart = (headerMatch[2] || '').trim()
      if (/^\+?\d{10,}/.test(namePart)) {
        // Phone-number author with no real content → skip
        if (!contentPart || !/\d{2,}/.test(contentPart)) {
          if (pendingNumbers.length > 0) {
            if (defaultRate > 0) flushPending(defaultRate)
            else dropPending()
          }
          continue
        }
      }
      line = contentPart
    }

    // Skip phone-only lines
    if (/^\+?\d{10,}/.test(line)) continue
    // Skip timestamp-only lines like "[6/6/26, 3:03 PM]" (with or without year)
    if (/^\[\s*\d{1,2}[\/\-.]\d{1,2}(?:[\/\-.]\d{2,4})?\s*,?\s*\d{1,2}:\d{2}\s*(?:AM|PM)?\s*\]$/i.test(line)) continue
    // Skip "Total" / "TOTAL" / "Total: 34850" / "34850 Total" lines
    if (/^total/i.test(line)) {
      if (pendingNumbers.length > 0) {
        if (defaultRate > 0) flushPending(defaultRate)
        else dropPending()
      }
      continue
    }
    if (/^\d+\s*Total/i.test(line)) continue
    // Skip "T---1750" / "T====1750" style total lines (WhatsApp-style totals)
    if (/^T[\-=]{2,}\d*\s*$/i.test(line)) {
      if (pendingNumbers.length > 0) {
        if (defaultRate > 0) flushPending(defaultRate)
        else dropPending()
      }
      continue
    }
    // Skip standalone large numbers (5+ digits, likely a summary/total)
    if (/^\d{5,}\s*[.,]*\s*(?:₹|rs)?\s*$/i.test(line)) continue
    // Pure separator lines: ========, ------, ++++++, ******, _ _ _ _
    if (/^[=\-+_*#]{3,}$/.test(line)) {
      // Flush pending — explicit divider means the previous block is closed
      if (pendingNumbers.length > 0) {
        if (defaultRate > 0) flushPending(defaultRate)
        else dropPending()
      }
      continue
    }
    // Pure alphabetic lines (no digits) — likely a vendor name or comment
    if (/^[a-zA-Z.\s]+$/.test(line) && !/\d/.test(line)) continue
    if (line.length === 0) continue

    // ── STAGE 2: Remove noise words ──
    // (a) Drop entire line if it's JUST a noise word (Type 16)
    if (NOISE_LINE_RE.test(line)) continue
    // (b) Drop entire line if it's JUST a type label (Spdpmo, Motor, etc.)
    if (TYPE_LABEL_RE.test(line)) continue
    // (c) Strip leading noise-word prefix
    line = line.replace(NOISE_PREFIX_RE, '')
    // (d) Strip leading type prefix (Spdpmo 12489=50 → 12489=50)
    line = line.replace(TYPE_PREFIX_RE, '')

    // ── STAGE 3 + 4: parse the line ──
    const { pannas, rate } = parseLineV5(line, mode === 'group')

    // Filter pannas by mode validity (e.g. single-mode wants 1-digit only)
    const validPannas: string[] = []
    for (const p of pannas) {
      if (isValidPanna(p)) {
        validPannas.push(p)
      } else {
        // Not valid for this mode → dropped
        droppedTokens.push(p)
      }
    }

    if (rate !== null) {
      // We have a rate for this line — flush any pending pannas with it,
      // then add this line's pannas with the same rate.
      flushPending(rate)
      for (const p of validPannas) {
        const np = normalizeN(p)
        rawEntries.push({ number: np, price: rate })
      }
    } else {
      // No rate on this line — push pannas into the pending buffer.
      // They will be picked up when a rate line appears (Type 12/13/14/8)
      // or marked as skipped at end-of-input.
      for (const p of validPannas) {
        pendingNumbers.push(p)
      }
    }
  }

  // End of input — flush any remaining pending pannas
  if (pendingNumbers.length > 0) {
    if (defaultRate > 0) flushPending(defaultRate)
    else dropPending()
  }

  // ── STAGE 5: Aggregate (Type 18) ──
  // Always sum duplicates: 389=260₹ + 389=30₹ → 389=290₹ (NOT 30, NOT 260)
  const aggregated = aggregateEntries(rawEntries)

  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now()
  parserDebug('parseWhatsAppContentFull: done', {
    rawEntries: rawEntries.length,
    aggregated: aggregated.length,
    skipped: skippedNumbers.length,
    dropped: droppedTokens.length,
    ms: Math.round(t1 - t0),
  })

  return {
    entries: aggregated,
    skippedNumbers: skippedNumbers.slice(0, MAX_SKIPPED_NUMBERS),
    droppedTokens: droppedTokens.slice(0, MAX_DROPPED_TOKENS),
  }
}

// Stage 5 helper: aggregate duplicate pannas by summing their rates.
// Skipped entries (price=0, skipped=true) are kept as-is, NOT aggregated,
// because they represent "panna seen but no rate" — they should stay visible
// in the SKIPPED section for manual review, not be silently merged into a
// priced entry.
function aggregateEntries(rawEntries: ParsedEntry[]): ParsedEntry[] {
  const priceMap = new Map<string, number>()
  const skippedSet = new Set<string>()
  const result: ParsedEntry[] = []

  for (const e of rawEntries) {
    if (e.skipped) {
      // Dedupe skipped pannas — same panna appearing 3× as skipped should
      // only show ONCE in the SKIPPED list
      if (!skippedSet.has(e.number)) {
        skippedSet.add(e.number)
        result.push(e)
      }
      continue
    }
    // Aggregate priced entries: sum rates for the same panna number
    const prev = priceMap.get(e.number) || 0
    priceMap.set(e.number, prev + e.price)
  }

  // Materialize aggregated entries in insertion order
  for (const [number, price] of priceMap) {
    result.push({ number, price })
  }

  return result
}


function calculateTriplePosition(numStr: string): number {
  let sum = 0
  for (const ch of numStr) {
    sum += parseInt(ch)
  }
  // Ank = digitSum % 10; 0 maps to column 10
  const ank = sum % 10
  return ank === 0 ? 10 : ank
}

interface GridData {
  [position: number]: Array<{ number: string; price: number }>
}

function buildGridFromParsed(entries: ParsedEntry[]): GridData {
  const grid: GridData = {}
  for (let i = 1; i <= 10; i++) {
    grid[i] = []
  }
  for (const entry of entries) {
    if (entry.skipped) continue  // Don't add skipped numbers to the grid
    const pos = calculateTriplePosition(entry.number)
    if (pos >= 1 && pos <= 10) {
      grid[pos].push({ number: entry.number, price: entry.price })
    }
  }
  return grid
}

function calculateSinglePosition(numStr: string): number {
  const num = parseInt(numStr)
  if (num >= 1 && num <= 9) return num
  if (num === 0) return 10 // 0 maps to column 10
  return 0
}

function calculateDoublePosition(numStr: string): number {
  // Same as triple: sum all digits and reduce to 1-9
  return calculateTriplePosition(numStr)
}

function buildGridFromParsedByMode(entries: ParsedEntry[], mode: 'single' | 'double'): GridData {
  const grid: GridData = {}
  for (let i = 1; i <= 10; i++) {
    grid[i] = []
  }
  for (const entry of entries) {
    if (entry.skipped) continue  // Don't add skipped numbers to the grid
    let pos = 0
    if (mode === 'single') {
      pos = calculateSinglePosition(entry.number)
    } else {
      // double and amount both use sum-of-digits position
      pos = calculateDoublePosition(entry.number)
    }
    if (pos >= 1 && pos <= 10) {
      grid[pos].push({ number: entry.number, price: entry.price })
    }
  }
  return grid
}

function buildDsPositionGridFromList(dsList: Array<Record<string, unknown>>, type: string): GridData {
  const grid: GridData = {}
  for (let i = 1; i <= 10; i++) {
    grid[i] = []
  }
  for (const entry of dsList) {
    const e = entry as { type: string; parsedData: string; details: string; totalAmount: number }
    if (e.type !== type) continue
    try {
      const pd = JSON.parse(e.parsedData)
      if (pd.numbers && Array.isArray(pd.numbers) && pd.numbers.length > 0) {
        for (const num of pd.numbers) {
          const n = num as { number: string; price: number }
          let pos = 0
          if (type === 'single') {
            pos = calculateSinglePosition(n.number)
          } else {
            pos = calculateDoublePosition(n.number)
          }
          if (pos >= 1 && pos <= 10) {
            grid[pos].push({ number: n.number, price: n.price })
          }
        }
      } else if (e.details && e.details.trim()) {
        // Fallback: parse the details field when parsedData is empty
        const entries = parseWhatsAppContent(e.details, type)
        if (entries.length > 0) {
          for (const entry of entries) {
            let pos = 0
            if (type === 'single') {
              pos = calculateSinglePosition(entry.number)
            } else {
              pos = calculateDoublePosition(entry.number)
            }
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: entry.number, price: entry.price })
            }
          }
        } else if (type === 'single') {
          // For single type, try parsing raw digits from details like "5=200" or "Card: 5 Single:"
          const digitMatch = e.details.match(/(\d)/g)
          if (digitMatch) {
            const perDigitAmount = e.totalAmount > 0 ? e.totalAmount / digitMatch.length : 0
            for (const d of digitMatch) {
              const pos = calculateSinglePosition(d)
              if (pos >= 1 && pos <= 10) {
                grid[pos].push({ number: d, price: perDigitAmount })
              }
            }
          }
        }
      }
    } catch { /* skip unparseable */ }
  }
  return grid
}

function calculateGridTotals(grid: GridData): { [position: number]: number } {
  const totals: { [position: number]: number } = {}
  for (let i = 1; i <= 10; i++) {
    totals[i] = (grid[i] || []).reduce((sum, e) => sum + e.price, 0)
  }
  return totals
}

// ────────────────────────────────────────
// VIEW CARD INVENTORY PAGE (THE MOST CRITICAL)
// ────────────────────────────────────────
// 220 PANNA CHART — Hard-coded base template (exact layout)
// Rows  0–11 : SP  (Single Panna, 12 per column = 120 total)
// Row   12    : TP  (Triple Panna,  1 per column =  10 total)
// Rows 13–21 : DP  (Double Panna,  9 per column =  90 total)
// Columns map to ank 1-10 (ank 0 → column 10)
// ────────────────────────────────────────
const PANNA_220_CHART: string[][] = [
  // ─── SP (rows 0-11) ───
  ['128','129','120','130','140','123','124','125','126','127'],
  ['137','138','139','149','159','150','160','134','135','136'],
  ['146','147','148','158','168','169','179','170','180','145'],
  ['236','156','157','167','230','178','250','189','234','190'],
  ['245','237','238','239','249','240','269','260','270','235'],
  ['290','246','247','248','258','259','278','279','289','280'],
  ['380','345','256','257','267','268','340','350','360','370'],
  ['470','390','346','347','348','349','359','369','379','389'],
  ['489','480','490','356','357','358','368','378','450','460'],
  ['560','570','580','590','456','367','458','459','469','479'],
  ['579','589','670','680','690','457','467','468','478','569'],
  ['678','679','689','789','780','790','890','567','568','578'],
  // ─── TP (row 12) ───
  ['777','444','111','888','555','222','999','666','333','000'],
  // ─── DP (rows 13-21) ───
  ['119','110','166','112','113','114','115','116','117','118'],
  ['155','228','229','220','122','277','133','224','144','226'],
  ['227','255','337','266','177','330','188','233','199','244'],
  ['335','336','445','338','339','448','223','288','225','299'],
  ['344','499','355','446','366','466','377','440','388','334'],
  ['399','660','599','455','447','556','449','477','559','488'],
  ['588','688','779','699','799','880','557','558','577','668'],
  ['669','778','788','770','889','899','566','990','667','677'],
  ['100','200','300','400','500','600','700','800','900','550'],
]

// ────────────────────────────────────────
// CANVAS-BASED CHART RENDERER
// Draws the 220 Panna Chart directly onto a Canvas using the
// native 2D API — no CSS parsing, no html2canvas, works on all devices.
// ────────────────────────────────────────

function generateChartCanvas(params: {
  priceMap: { [panna: string]: number }
  pannaChart: string[][]
  inv: { date: string; time?: string; inventoryCode: { name: string } }
  tripleGrandTotal: number
  isMobile: boolean
  appliedPct: { less: number; add: number }
  // Super Admin "Deduct from Column Total" — a single amount subtracted
  // from every column total (and thus from the grand total). ANK/cell prices
  // in priceMap are NEVER modified.
  colDeduction?: number
  // Gap 8 — Per-column deduction/add
  perColDeduction?: { [ank: number]: number }
  perColAdd?: { [ank: number]: number }
  // Gap 10 — Style customization
  styleCustom?: { pannaColor?: string; rateColor?: string; headerBg?: string; totalBg?: string; fontFamily?: string }
}): HTMLCanvasElement {
  const {
    priceMap, pannaChart, inv,
    tripleGrandTotal, isMobile, appliedPct,
    colDeduction = 0,
    perColDeduction = {},
    perColAdd = {},
    styleCustom = {},
  } = params

  // ─── CONFIGURATION ───
  // Updated styling: panna in BLACK, rate in DARK BLUE, serif fonts for a
  // distinctive chart look across all downloads (image + WhatsApp share).
  // Uses "Liberation Serif" (Times-compatible, widely available on Linux)
  // and "DejaVu Sans" (clean sans-serif) — both ship with most distros.
  // Gap 10 — Apply style customization overrides
  const PANA_COLOR = styleCustom.pannaColor || '#000000'       // Black for panna numbers (ank)
  const RATE_COLOR = styleCustom.rateColor || '#1E3A8A'       // Dark blue for rates/amounts
  const HEADER_BG = styleCustom.headerBg || '#d0d0d0'
  const TOTAL_BG = styleCustom.totalBg || '#e8e8e8'
  const _fontFamily = styleCustom.fontFamily || 'serif'

  const DATA_FONT_SIZE = 43
  const DATA_FONT = `bold ${DATA_FONT_SIZE}px 'Liberation Serif', 'DejaVu Serif', ${_fontFamily}`
  const HEADER_FONT_SIZE = 28
  const HEADER_FONT = `bold ${HEADER_FONT_SIZE}px 'DejaVu Sans', ${_fontFamily}`
  const COL_HEADER_FONT_SIZE = 32
  const COL_HEADER_FONT = `bold ${COL_HEADER_FONT_SIZE}px 'DejaVu Sans', ${_fontFamily}`
  const TOTAL_FONT_SIZE = 30
  const TOTAL_FONT = `bold ${TOTAL_FONT_SIZE}px 'Liberation Serif', 'DejaVu Serif', ${_fontFamily}`
  const SEP_FONT_SIZE = 22
  const SEP_FONT = `bold ${SEP_FONT_SIZE}px 'DejaVu Sans', ${_fontFamily}`
  const PCT_FONT_SIZE = 22
  const PCT_FONT = `italic ${PCT_FONT_SIZE}px 'DejaVu Sans', ${_fontFamily}`

  const STROKE_WIDTH = 2
  const BORDER_COLOR = '#333333'
  const SEP_BG = '#f0f0f0'
  const SEP_TEXT_COLOR = '#555555'
  const PCT_COLOR = '#666666'
  const NO_PRICE_COLOR = '#bbbbbb'

  const scale = isMobile ? 1 : 2
  const maxRows = pannaChart.length   // 22
  const cols = 10

  // Measure the widest possible cell content to determine cell width
  // Worst case: "580 = 3050₹"
  const measureCanvas = document.createElement('canvas')
  const measureCtx = measureCanvas.getContext('2d')!
  measureCtx.font = DATA_FONT
  let maxCellTextWidth = 0
  for (let row = 0; row < maxRows; row++) {
    for (let c = 0; c < cols; c++) {
      const panna = pannaChart[row][c]
      const price = priceMap[panna]
      if (price !== undefined) {
        const textW = measureCtx.measureText(`${panna} = ${price}₹`).width
        if (textW > maxCellTextWidth) maxCellTextWidth = textW
      }
    }
  }
  // Ensure minimum cell width of 220px, or wider if content needs it
  const cellW = Math.max(220, Math.ceil(maxCellTextWidth + 20))
  const cellH = 46
  const headerH = 60
  const colHeaderH = 48
  const sepRowH = 32
  const padding = 24

  // Count separator rows (row 12 = TP, row 13 = DP)
  const sepCount = 2

  // Compute layout dimensions
  const chartW = cols * cellW
  const chartH = (maxRows * cellH) + colHeaderH + (sepCount * sepRowH)
  const colTotalsH = cellH + 8
  const grandTotalH = 52

  const totalW = chartW + padding * 2
  const totalH = padding + headerH + chartH + colTotalsH + grandTotalH + padding

  const canvas = document.createElement('canvas')
  canvas.width = Math.round(totalW * scale)
  canvas.height = Math.round(totalH * scale)
  const ctx = canvas.getContext('2d')!
  ctx.scale(scale, scale)

  // ─── Helper: draw bold text with stroke ───
  function drawText(text: string, x: number, y: number, color: string, fontStr: string, stroke: boolean = true) {
    ctx.font = fontStr
    ctx.textBaseline = 'middle'
    ctx.fillStyle = color
    if (stroke) {
      ctx.lineWidth = STROKE_WIDTH
      ctx.strokeStyle = color
      ctx.strokeText(text, x, y)
    }
    ctx.fillText(text, x, y)
  }

  // ─── Helper: draw horizontal line ───
  function hLine(y: number, x1: number, x2: number) {
    ctx.beginPath()
    ctx.moveTo(x1, y)
    ctx.lineTo(x2, y)
    ctx.stroke()
  }

  // ─── Helper: draw vertical line ───
  function vLine(x: number, y1: number, y2: number) {
    ctx.beginPath()
    ctx.moveTo(x, y1)
    ctx.lineTo(x, y2)
    ctx.stroke()
  }

  // ─── Helper: draw grid border for a row ───
  function drawRowBorders(y: number, h: number) {
    ctx.strokeStyle = BORDER_COLOR
    ctx.lineWidth = 1
    hLine(y, padding, padding + chartW)
    hLine(y + h, padding, padding + chartW)
    for (let c = 0; c <= cols; c++) {
      vLine(padding + c * cellW, y, y + h)
    }
  }

  // Background
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, totalW, totalH)

  let curY = padding

  // ─── HEADER ───
  // Gap 9 — Simplified header for download/share (date + time only, no game name)
  const simplifiedHeader = true
  const dateStr = formatDate(inv.date)
  if (simplifiedHeader) {
    const timeStr = inv.time ? ` Time: ${inv.time}` : ''
    drawText(`Date: ${dateStr}${timeStr}`, padding, curY + headerH / 2, PANA_COLOR, HEADER_FONT, true)
  } else {
    drawText(`Date: ${dateStr}  Game: ${inv.inventoryCode.name}`, padding, curY + headerH / 2, PANA_COLOR, HEADER_FONT, true)
  }
  if (appliedPct.less > 0 || appliedPct.add > 0) {
    let pctText = ''
    if (appliedPct.less > 0) pctText += `Less ${appliedPct.less}% `
    if (appliedPct.add > 0) pctText += `Add ${appliedPct.add}%`
    drawText(pctText, padding, curY + headerH - 8, PCT_COLOR, PCT_FONT, false)
  }
  curY += headerH

  // ─── COLUMN HEADERS (1-10) ───
  ctx.fillStyle = HEADER_BG
  ctx.fillRect(padding, curY, chartW, colHeaderH)
  drawRowBorders(curY, colHeaderH)

  ctx.textAlign = 'center'
  for (let c = 0; c < cols; c++) {
    drawText(String(c + 1), padding + c * cellW + cellW / 2, curY + colHeaderH / 2, PANA_COLOR, COL_HEADER_FONT, true)
  }
  ctx.textAlign = 'left'
  curY += colHeaderH

  // ─── CHART DATA ROWS ───
  for (let row = 0; row < maxRows; row++) {
    // Type separator rows
    if (row === 12) {
      // SP/TP separator
      ctx.fillStyle = SEP_BG
      ctx.fillRect(padding, curY, chartW, sepRowH)
      drawRowBorders(curY, sepRowH)
      ctx.textAlign = 'center'
      drawText('── TP ──', padding + chartW / 2, curY + sepRowH / 2, SEP_TEXT_COLOR, SEP_FONT, false)
      ctx.textAlign = 'left'
      curY += sepRowH
    } else if (row === 13) {
      // TP/DP separator
      ctx.fillStyle = SEP_BG
      ctx.fillRect(padding, curY, chartW, sepRowH)
      drawRowBorders(curY, sepRowH)
      ctx.textAlign = 'center'
      drawText('── DP ──', padding + chartW / 2, curY + sepRowH / 2, SEP_TEXT_COLOR, SEP_FONT, false)
      ctx.textAlign = 'left'
      curY += sepRowH
    }

    // Row background (alternating)
    const rowBg = row % 2 === 0 ? '#ffffff' : '#f8f8f8'
    ctx.fillStyle = rowBg
    ctx.fillRect(padding, curY, chartW, cellH)
    drawRowBorders(curY, cellH)

    // Cell content: panna in BLACK, rate in RED on ONE line
    for (let c = 0; c < cols; c++) {
      const panna = pannaChart[row][c]
      const price = priceMap[panna]
      const cellX = padding + c * cellW + 6
      const cellCenterY = curY + cellH / 2

      if (price !== undefined) {
        // Draw panna in BLACK
        ctx.font = DATA_FONT
        ctx.textBaseline = 'middle'
        ctx.textAlign = 'left'
        ctx.fillStyle = PANA_COLOR
        ctx.lineWidth = STROKE_WIDTH
        ctx.strokeStyle = PANA_COLOR
        ctx.strokeText(panna, cellX, cellCenterY)
        ctx.fillText(panna, cellX, cellCenterY)

        // Measure panna width to position rate right after it
        const pannaWidth = ctx.measureText(panna).width
        const rateText = ` = ${price}₹`

        // Draw rate in DARK BLUE immediately after panna
        ctx.fillStyle = RATE_COLOR
        ctx.strokeStyle = RATE_COLOR
        ctx.strokeText(rateText, cellX + pannaWidth + 2, cellCenterY)
        ctx.fillText(rateText, cellX + pannaWidth + 2, cellCenterY)
      } else {
        // No price — leave cell completely blank (panna hidden)
        // Previously drew the panna in light gray, but the user requested
        // that empty pannas be hidden entirely so only priced pannas show.
      }
    }
    curY += cellH
  }

  // ─── COLUMN TOTALS ───
  ctx.fillStyle = TOTAL_BG
  ctx.fillRect(padding, curY, chartW, colTotalsH)
  drawRowBorders(curY, colTotalsH)

  ctx.textAlign = 'center'
  let canvasGrandTotal = 0
  for (let c = 0; c < cols; c++) {
    let colTotal = 0
    for (let r = 0; r < maxRows; r++) {
      const panna = pannaChart[r][c]
      if (priceMap[panna] !== undefined) colTotal += priceMap[panna]
    }
    // Super Admin deduction — subtract uniform amount, floored at 0
    let displayColTotal = Math.max(0, colTotal - colDeduction)
    // Gap 8 — Apply per-column deductions and additions (column index is 1-based)
    const colIdx = c + 1
    const pcDeduct = perColDeduction[colIdx] || 0
    const pcAdd = perColAdd[colIdx] || 0
    displayColTotal = Math.max(0, displayColTotal - pcDeduct + pcAdd)
    canvasGrandTotal += displayColTotal
    drawText(`${displayColTotal}₹`, padding + c * cellW + cellW / 2, curY + colTotalsH / 2, RATE_COLOR, TOTAL_FONT, true)
  }
  ctx.textAlign = 'left'
  curY += colTotalsH

  // ─── GRAND TOTAL ───
  // Always use canvasGrandTotal which accounts for ALL adjustments
  // (uniform deduction + per-column deduct/add). Previous behavior that
  // fell back to tripleGrandTotal when no uniform deduction was active
  // is superseded — per-column adjustments MUST affect the grand total.
  const finalGrandTotal = canvasGrandTotal
  drawText(
    `TOTAL ${finalGrandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₹`,
    padding,
    curY + grandTotalH / 2,
    RATE_COLOR,
    TOTAL_FONT,
    true
  )
  curY += grandTotalH

  return canvas
}

// ────────────────────────────────────────
// BarChartPreview — small horizontal bar chart (10 bars max)
// used inside the Single/Double tabs to visualize amount distribution
// matches the HTML mockup's .chart-bar-container design
// ────────────────────────────────────────

function BarChartPreview({ data, emptyLabel = 'No data' }: { data: Array<{ num: string; amt: number }>; emptyLabel?: string }) {
  const max = Math.max(...data.map(d => d.amt), 1)
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-end gap-1.5 h-[100px] pb-4">
        {data.length === 0 ? (
          <div className="flex-1 text-center text-[12px] text-slate-400 self-center">{emptyLabel}</div>
        ) : data.map(d => {
          const h = d.amt > 0 ? Math.max((d.amt / max) * 90, 6) : 3
          const bg = d.amt > 0
            ? 'linear-gradient(180deg,#4F46E5,#818CF8)'
            : '#E2E8F0'
          return (
            <div
              key={d.num}
              className="flex-1 min-w-[20px] rounded-t-[3px] cursor-pointer hover:opacity-85 transition-opacity relative group"
              style={{ height: `${h}%`, background: bg }}
              title={`${d.num} = ₹${d.amt}`}
            >
              <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-semibold text-slate-500">
                {d.num}
              </span>
            </div>
          )
        })}
      </div>
      <div style={{ height: 8 }} />
    </div>
  )
}

// ────────────────────────────────────────

// Per-number customer attribution for consolidated Customer App rows.
// App bets land as ONE row per (game class × slot) for ALL customers —
// parsedData.byCustomer maps number → "Name (mobile)" → points. This
// renders each number as "380@150 (Rahul 100 · Priya 50)": names only,
// mobiles stay in the data. Non-app rows (byCustomer missing) unchanged.
function displayNameOnly(customerKey: string): string {
  const i = customerKey.lastIndexOf(' (')
  return i > 0 ? customerKey.slice(0, i) : customerKey
}

function withCustomerBreakdown(base: string, num: string, byCustomer?: Record<string, Record<string, number>>): string {
  const bc = byCustomer && byCustomer[num]
  if (!bc) return base
  const parts = Object.entries(bc)
    .map(([ck, pts]) => `${displayNameOnly(ck)} ${pts}`)
    .join(' · ')
  return parts ? `${base} (${parts})` : base
}


export function CardInventoryPage() {
  const { viewingInventoryId, currentUser, setCurrentPage } = useAppStore()
  const [inventory, setInventory] = useState<Record<string, unknown> | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [tab, setTab] = useState<'triple' | 'single' | 'double'>('triple')

  // Triple inventory form
  const [tripleMode, setTripleMode] = useState<'mix' | 'group' | 'common' | 'sangam'>('mix')
  const [vendorId, setVendorId] = useState('')
  const [whatsappContent, setWhatsappContent] = useState('')
  const [rate, setRate] = useState('')
  const [vendors, setVendors] = useState<Array<{ id: string; businessName: string }>>([])
  const [tripleList, setTripleList] = useState<Array<Record<string, unknown>>>([])
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')

  // Triple Group mode states
  const [tripleGroupType, setTripleGroupType] = useState('')
  const [tripleGroupRate, setTripleGroupRate] = useState('')
  const [tripleGroupAmount, setTripleGroupAmount] = useState('')
  // ── Group Input Mode: 'single' (series buttons + select) or 'batch' (textarea) ──
  const [groupInputMode, setGroupInputMode] = useState<'single' | 'batch'>('single')
  // ── Group Input Content (multiline textarea for batch mode) ──
  const [groupInputContent, setGroupInputContent] = useState('')
  // ── Group parsed preview state ──
  const [groupParsedPreview, setGroupParsedPreview] = useState<Array<{ number: string; price: number }>>([])
  // ── Single mode states: series buttons + select field ──
  const [tripleSeriesCards, setTripleSeriesCards] = useState<Set<number>>(new Set())
  const [tripleSelect, setTripleSelect] = useState('')
  // ── Batch mode states ──
  const [groupBatchMode, setGroupBatchMode] = useState(false)
  const [groupBatchRawText, setGroupBatchRawText] = useState('')
  const [groupBatchResult, setGroupBatchResult] = useState<GroupBatchResult | null>(null)

  // Triple Common mode states
  const [tripleCommonSeries, setTripleCommonSeries] = useState('')
  const [tripleCommonRate, setTripleCommonRate] = useState('')
  const [tripleCommonAmount, setTripleCommonAmount] = useState('')
  // ── Common Input Mode: 'single' (comma field) or 'batch' (bulk textarea) ──
  const [commonInputMode, setCommonInputMode] = useState<'single' | 'batch'>('single')
  const [commonBatchContent, setCommonBatchContent] = useState('')

  // Triple Sangam states (Half Sangam A / Half Sangam B / Full Sangam) —
  // direct input items in the Triple section, stored as type 'sangam'
  const [sangamKind, setSangamKind] = useState<'Half Sangam A' | 'Half Sangam B' | 'Full Sangam'>('Half Sangam A')
  const [sangamInputMode, setSangamInputMode] = useState<'single' | 'batch'>('single')
  const [sangamOpenDigit, setSangamOpenDigit] = useState('')
  const [sangamOpenPanna, setSangamOpenPanna] = useState('')
  const [sangamCloseDigit, setSangamCloseDigit] = useState('')
  const [sangamClosePanna, setSangamClosePanna] = useState('')
  const [sangamPoints, setSangamPoints] = useState('')
  const [sangamBatchContent, setSangamBatchContent] = useState('')

  // Single tab states
  const [singleVendorId, setSingleVendorId] = useState('')
  const [singleRate, setSingleRate] = useState('')
  const [singleAmount, setSingleAmount] = useState('')
  const [dsSelectSingle, setDsSelectSingle] = useState('') // Single mode input

  // Double tab states
  const [doubleVendorId, setDoubleVendorId] = useState('')
  const [doubleSeries, setDoubleSeries] = useState('')
  const [doubleRate, setDoubleRate] = useState('')
  const [doubleAmount, setDoubleAmount] = useState('')
  const [dsSelectDouble, setDsSelectDouble] = useState('') // Double mode input
  const [dsSeriesCards, setDsSeriesCards] = useState<Set<number>>(new Set()) // Series toggle buttons for Double mode
  const [dsList, setDsList] = useState<Array<Record<string, unknown>>>([])
  const [dsSubmitting, setDsSubmitting] = useState(false)
  const [dsExporting, setDsExporting] = useState(false)
  const [dsMessage, setDsMessage] = useState('')
  const [dsGridRate, setDsGridRate] = useState('')

  // DS Parsed grid states (per-tab)
  const [dsParsedEntries, setDsParsedEntries] = useState<ParsedEntry[]>([])
  const [dsSkippedNumbers, setDsSkippedNumbers] = useState<string[]>([])
  const [dsDroppedTokens, setDsDroppedTokens] = useState<string[]>([])
  const [dsGridData, setDsGridData] = useState<GridData | null>(null)

  // Double 10x10 grid state (for Milan-style dot format)
  const [dsDoubleGridData, setDsDoubleGridData] = useState<{ [key: string]: number } | null>(null) // key="00"-"99", value=rate
  const [dsDoubleParsedNumbers, setDsDoubleParsedNumbers] = useState<string[]>([]) // list of 2-digit numbers
  const [dsDoubleParsedRate, setDsDoubleParsedRate] = useState<number>(0)
  const [dsDoubleParsedVendor, setDsDoubleParsedVendor] = useState<string>('')

  // Chart modal
  const [showChartModal, setShowChartModal] = useState(false)
  const [chartMode, setChartMode] = useState<'full' | 'blank'>('full') // green=full, orange=blank
  const [chartBwMode, setChartBwMode] = useState(false)
  const [chartDownloading, setChartDownloading] = useState(false)
  const [chartSharing, setChartSharing] = useState(false)
  const [chartCopied, setChartCopied] = useState(false)
  const chartRef = useRef<HTMLDivElement>(null)
  // Gap 8 — Per-column deduction/add
  const [chartPerColDeduction, setChartPerColDeduction] = useState<{[ank: number]: number}>({})
  const [chartPerColAdd, setChartPerColAdd] = useState<{[ank: number]: number}>({})
  // Gap 10 — Chart style customization
  const [chartStyleCustom, setChartStyleCustom] = useState({
    pannaColor: '#000000',
    rateColor: '#1E3A8A',
    headerBg: '#d0d0d0',
    totalBg: '#e8e8e8',
    fontFamily: 'serif',
  })
  const [showStylePanel, setShowStylePanel] = useState(false)
  // Chart filter/controls
  const [chartFilter, setChartFilter] = useState<string>('all')
  const [chartLessPct, setChartLessPct] = useState('')
  const [chartAddPct, setChartAddPct] = useState('')
  const [chartAppliedPct, setChartAppliedPct] = useState<{ less: number; add: number }>({ less: 0, add: 0 })
  const [chartMarkedShared, setChartMarkedShared] = useState<Set<string>>(new Set())
  const [chartShowShared, setChartShowShared] = useState(true)
  const [chartHideShared, setChartHideShared] = useState(false)
  // ── Deduct from Column Total (Super Admin only) ──
  // A single amount that is subtracted from EVERY column total (and the grand total).
  // ANK/cell prices are NEVER modified — only the displayed/exported totals.
  const isMasterOrManager = currentUser?.role === 'super' || currentUser?.role === 'manager'
  const [chartColDeductionInput, setChartColDeductionInput] = useState('')
  const [chartColDeduction, setChartColDeduction] = useState(0)

  // useTransition wraps heavy state updates so React can yield to main thread
  // This prevents mobile freeze when chart recalculations run after submit
  const [, startTransition] = useTransition()

  // Defer tripleList and dsList for useMemo computations — this is the KEY optimization
  // for mobile freeze with 150+ entries. React will keep the OLD values during urgent renders
  // (like button clicks, form resets) and update the deferred values in the background.
  // This means the chart useMemo cascade runs AFTER the UI is responsive again.
  const deferredTripleList = useDeferredValue(tripleList)
  const deferredDsList = useDeferredValue(dsList)

  // Note: We intentionally do NOT redirect when viewingInventoryId is null.
  // The "No Inventory Selected" display below handles that case gracefully
  // without causing a race condition with store subscriptions.

  const fetchInventory = useCallback(() => {
    if (!viewingInventoryId) return
    setLoading(true)
    apiFetch(`/api/inventories/${viewingInventoryId}`)
      .then(d => {
        startTransition(() => { setInventory(d) })
        setLoading(false)
        setError('')
      })
      .catch((err) => { setError(err instanceof Error ? err.message : 'Failed to refresh inventory'); setLoading(false) })
  }, [viewingInventoryId])

  const fetchTripleList = useCallback(() => {
    if (!viewingInventoryId) return
    apiFetch(`/api/triple-inventories?inventoryId=${viewingInventoryId}`)
      .then(d => startTransition(() => setTripleList(d)))
      .catch(console.error)
  }, [viewingInventoryId])

  const fetchDsList = useCallback(() => {
    if (!viewingInventoryId) return
    apiFetch(`/api/double-single-inventories?inventoryId=${viewingInventoryId}`)
      .then(d => startTransition(() => setDsList(d)))
      .catch(console.error)
  }, [viewingInventoryId])

  useEffect(() => {
    if (!viewingInventoryId) return
    let cancelled = false
    apiFetch(`/api/inventories/${viewingInventoryId}`)
      .then(d => { if (!cancelled) { startTransition(() => setInventory(d)); setLoading(false); setError('') } })
      .catch((err) => { if (!cancelled) { setError(err instanceof Error ? err.message : 'Failed to load inventory'); setLoading(false) } })
    apiFetch(`/api/triple-inventories?inventoryId=${viewingInventoryId}`)
      .then(d => { if (!cancelled) startTransition(() => setTripleList(d)) })
      .catch(console.error)
    apiFetch(`/api/double-single-inventories?inventoryId=${viewingInventoryId}`)
      .then(d => { if (!cancelled) startTransition(() => setDsList(d)) })
      .catch(console.error)
    return () => { cancelled = true }
  }, [viewingInventoryId])

  useEffect(() => {
    apiFetch('/api/vendors').then(setVendors).catch(console.error)
  }, [])

  // Auto-calculate Single Amount: count of digits × rate
  useEffect(() => {
    if (tab === 'single') {
      const digits = dsSelectSingle.split('').filter(c => /^\d$/.test(c))
      const rate = parseFloat(singleRate) || 0
      if (digits.length > 0 && rate > 0) {
        setSingleAmount(String(digits.length * rate))
      } else if (digits.length === 0) {
        setSingleAmount('')
      }
    }
  }, [tab, dsSelectSingle, singleRate])

  const inv = inventory as {
    id: string; date: string; time: string | null; status: string; totalTxn: number; totalAmount: number; remaining: number; remark: string | null;
    inventoryCode: { id: string; name: string; market: string; type: string; code: string };
    cards: Array<{ position: number; value: string }>;
    tripleInventories: Array<Record<string, unknown>>;
  } | null

  // formatPanna is now defined at module level (above) for use in both
  // parseWhatsAppContent and component functions
  // PANNA_220_CHART is now defined at module level (above)

  // Generate all 220 pannas from the hard-coded chart (flat list)
  function generateAll220Pannas(): string[] {
    return PANNA_220_CHART.flat()
  }

  // Build 220 panna chart data using the hard-coded base template
  // Layout: rows 0-11 = SP, row 12 = TP, rows 13-21 = DP
  function build220ChartData(priceMap: { [panna: string]: number }) {
    const maxRows = PANNA_220_CHART.length // 22
    const rows: { panna: string; price: number | undefined; type: 'SP' | 'DP' | 'TP' }[][] = []

    // Build spByCol, dpByCol, tpByCol for downstream use
    const spByCol: { [col: number]: string[] } = {}
    const dpByCol: { [col: number]: string[] } = {}
    const tpByCol: { [col: number]: string[] } = {}
    for (let c = 1; c <= 10; c++) { spByCol[c] = []; dpByCol[c] = []; tpByCol[c] = [] }

    for (let row = 0; row < maxRows; row++) {
      const rowData: { panna: string; price: number | undefined; type: 'SP' | 'DP' | 'TP' }[] = []
      for (let col = 0; col < 10; col++) {
        const panna = PANNA_220_CHART[row][col]
        let type: 'SP' | 'DP' | 'TP'
        if (row < 12) type = 'SP'
        else if (row === 12) type = 'TP'
        else type = 'DP'

        // Populate spByCol/dpByCol/tpByCol
        const colNum = col + 1 // 1-indexed column
        if (type === 'SP') spByCol[colNum].push(panna)
        else if (type === 'TP') tpByCol[colNum].push(panna)
        else dpByCol[colNum].push(panna)

        rowData.push({
          panna,
          price: panna ? (priceMap[panna] !== undefined ? priceMap[panna] : undefined) : undefined,
          type
        })
      }
      rows.push(rowData)
    }

    // Calculate column totals
    const colTotals: { [col: number]: number } = {}
    for (let c = 1; c <= 10; c++) {
      colTotals[c] = 0
      const allCol = [...spByCol[c], ...tpByCol[c], ...dpByCol[c]]
      for (const p of allCol) {
        if (priceMap[p] !== undefined) colTotals[c] += priceMap[p]
      }
    }

    const grandTotal = Object.values(colTotals).reduce((s, v) => s + v, 0)
    const totalEntries = Object.keys(priceMap).length

    return { rows, colTotals, grandTotal, totalEntries, spByCol, dpByCol, tpByCol }
  }

  // Generate pannas for a Common mode series number
  // Series "XY" maps to all 3-digit pannas that contain both digit X and digit Y
  // If X == Y (like "11"), finds pannas with at least two X digits → 10 pannas
  // If X != Y (like "10"), finds pannas containing both X and Y → 10 pannas
  function generateCommonPannas(seriesStr: string): string[] {
    const allPannas = generateAll220Pannas()
    const d1 = parseInt(seriesStr[0])
    const d2 = parseInt(seriesStr[1])

    if (isNaN(d1) || isNaN(d2)) return []

    return allPannas.filter(panna => {
      const digits = panna.split('').map(Number)
      if (d1 === d2) {
        // Count occurrences of d1 in the panna — need at least 2
        const count = digits.filter(d => d === d1).length
        return count >= 2
      } else {
        // Panna must contain both d1 and d2
        return digits.includes(d1) && digits.includes(d2)
      }
    })
  }

  // Generate triples from a number by combining digits at positions
  function generateTriplesFromSelect(selectStr: string): string[] {
    const digits = selectStr.split('').filter(c => /^\d$/.test(c))
    if (digits.length < 3) return []
    const results: string[] = []
    for (let i = 0; i < digits.length - 2; i++) {
      for (let j = i + 1; j < digits.length - 1; j++) {
        for (let k = j + 1; k < digits.length; k++) {
          results.push(digits[i] + digits[j] + digits[k])
        }
      }
    }
    return results
  }

  // Generate SP (Single Panna) pannas for given ank digits
  // Each ank digit (0-9) maps to exactly 12 SP pannas where digitSum % 10 == ank
  function generateSPByAnk(ankDigits: number[]): string[] {
    const allPannas = generateAll220Pannas()
    // Filter to get only SP pannas (all 3 digits different)
    const spPannas = allPannas.filter(panna => {
      const d = panna.split('').map(Number)
      return d[0] !== d[1] && d[1] !== d[2] && d[0] !== d[2]
    })

    const result: string[] = []
    const seen = new Set<string>()
    for (const ank of ankDigits) {
      for (const panna of spPannas) {
        const d = panna.split('').map(Number)
        const sum = d.reduce((a, b) => a + b, 0)
        if (sum % 10 === ank && !seen.has(panna)) {
          seen.add(panna)
          result.push(panna)
        }
      }
    }
    return result
  }

  // Generate DP (Double Panna) pannas for given ank digits
  // Each ank digit (0-9) maps to exactly 9 DP pannas where digitSum % 10 == ank
  // DP: exactly 2 digits are the same, 1 is different
  function generateDPByAnk(ankDigits: number[]): string[] {
    const allPannas = generateAll220Pannas()
    // Filter to get only DP pannas (exactly 2 digits same, 1 different)
    const dpPannas = allPannas.filter(panna => {
      const d = panna.split('').map(Number)
      // DP: exactly one pair of digits is the same
      return (d[0] === d[1] && d[1] !== d[2]) || (d[1] === d[2] && d[0] !== d[1]) || (d[0] === d[2] && d[0] !== d[1])
    })

    const result: string[] = []
    const seen = new Set<string>()
    for (const ank of ankDigits) {
      for (const panna of dpPannas) {
        const d = panna.split('').map(Number)
        const sum = d.reduce((a, b) => a + b, 0)
        if (sum % 10 === ank && !seen.has(panna)) {
          seen.add(panna)
          result.push(panna)
        }
      }
    }
    return result
  }

  // Generate TP (Triple Panna) pannas for given ank digits
  // Each ank digit (0-9) maps to exactly 1 TP panna where digitSum % 10 == ank
  // TP: all 3 digits are the same
  function generateTPByAnk(ankDigits: number[]): string[] {
    const allPannas = generateAll220Pannas()
    // Filter to get only TP pannas (all 3 digits same)
    const tpPannas = allPannas.filter(panna => {
      const d = panna.split('').map(Number)
      return d[0] === d[1] && d[1] === d[2]
    })

    const result: string[] = []
    const seen = new Set<string>()
    for (const ank of ankDigits) {
      for (const panna of tpPannas) {
        const d = panna.split('').map(Number)
        const sum = d.reduce((a, b) => a + b, 0)
        if (sum % 10 === ank && !seen.has(panna)) {
          seen.add(panna)
          result.push(panna)
        }
      }
    }
    return result
  }

  // Get group card numbers (1-10) from group type
  function getGroupCards(series: string, groupType: string): number[] {
    const seriesNums = series.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n))
    if (seriesNums.length === 0) return []
    return seriesNums
  }

  // Generate pannas based on group type and selected digits
  // Digits are the actual digit values (0-9), e.g. [2, 5, 8, 0]
  function generateGroupPannas(digits: number[], groupType: string): string[] {
    const pannas: string[] = []
    const sorted = [...digits].sort((a, b) => a - b)

    // Helper: generate all C(n,3) SP (all-different-digit) combinations
    function generateSP(): string[] {
      const result: string[] = []
      for (let i = 0; i < sorted.length - 2; i++) {
        for (let j = i + 1; j < sorted.length - 1; j++) {
          for (let k = j + 1; k < sorted.length; k++) {
            result.push(String(sorted[i]) + String(sorted[j]) + String(sorted[k]))
          }
        }
      }
      return result
    }

    // Helper: generate all DP (2-same + 1-different) pannas
    function generateDP(): string[] {
      const result: string[] = []
      const seen = new Set<string>()
      for (const d of sorted) {
        for (const other of sorted) {
          if (other !== d) {
            const panna = [d, d, other].sort((a, b) => a - b).join('')
            if (!seen.has(panna)) {
              seen.add(panna)
              result.push(panna)
            }
          }
        }
      }
      return result
    }

    // Helper: generate all TP (all-same-digit) pannas
    function generateTP(): string[] {
      const result: string[] = []
      for (const d of sorted) {
        result.push(String(d).repeat(3))
      }
      return result
    }

    switch (groupType) {
      case 'SP':
        // SP Group: each selected digit represents an ank (0-9)
        // For each ank, there are exactly 12 SP pannas in the 220 chart
        pannas.push(...generateSPByAnk(sorted))
        break
      case 'DP':
        // DP Group: each selected digit represents an ank (0-9)
        // For each ank, there are exactly 9 DP pannas in the 220 chart
        pannas.push(...generateDPByAnk(sorted))
        break
      case 'TP':
        // TP Group: each selected digit represents an ank (0-9)
        // For each ank, there is exactly 1 TP panna in the 220 chart
        pannas.push(...generateTPByAnk(sorted))
        break
      case 'SPDP':
        // SP+DP: each ank gets 12 SP + 9 DP = 21 pannas
        pannas.push(...generateSPByAnk(sorted), ...generateDPByAnk(sorted))
        break
      case 'SPTP':
        // SP+TP: each ank gets 12 SP + 1 TP = 13 pannas
        pannas.push(...generateSPByAnk(sorted), ...generateTPByAnk(sorted))
        break
      case 'DPTP':
        // DP+TP: each ank gets 9 DP + 1 TP = 10 pannas
        pannas.push(...generateDPByAnk(sorted), ...generateTPByAnk(sorted))
        break
      case 'SPDPTP':
        // SP+DP+TP: each ank gets 12 SP + 9 DP + 1 TP = 22 pannas
        pannas.push(...generateSPByAnk(sorted), ...generateDPByAnk(sorted), ...generateTPByAnk(sorted))
        break
      case 'SP Motor':
        // SP Motor: data identical to SP — distinct group label (SP_MOTOR)
        pannas.push(...generateSPByAnk(sorted))
        break
      case 'DP Motor':
        // DP Motor: data identical to DP — distinct group label (DP_MOTOR)
        pannas.push(...generateDPByAnk(sorted))
        break
      case 'Motor Pana':
        // Motor Pana = all C(n,3) 3-digit combinations from selected digits
        pannas.push(...generateSP())
        break
      case '50 Chart':
        // 50 Chart: each digit is an ank → 5 pannas per ank from CHART_50_CUT
        for (const d of sorted) {
          const ank = d === 0 ? 10 : d
          const chartPannas = CHART_50_CUT.get(ank) || []
          pannas.push(...chartPannas)
        }
        break
      case '60 Chart':
        // 60 Chart: each digit is an ank → 6 pannas per ank from CHART_60_PANNAS
        for (const d of sorted) {
          const ank = d === 0 ? 10 : d
          const chartPannas = CHART_60_PANNAS.get(ank) || []
          pannas.push(...chartPannas)
        }
        break
      case '70 Chart':
        // 70 Chart: each digit is an ank → 7 pannas per ank from CHART_70_JODI7
        for (const d of sorted) {
          const ank = d === 0 ? 10 : d
          const chartPannas = CHART_70_JODI7.get(ank) || []
          pannas.push(...chartPannas)
        }
        break
      case '90 DP Chart':
        // 90 DP Chart: each digit is an ank → 9 DP pannas per ank from CHART_90_DP
        for (const d of sorted) {
          const ank = d === 0 ? 10 : d
          const chartPannas = CHART_90_DP.get(ank) || []
          pannas.push(...chartPannas)
        }
        break
      case '90 ABR Chart':
        // 90 ABR Chart: each digit is an ank → 9 SP pannas per ank from CHART_ABR9
        for (const d of sorted) {
          const ank = d === 0 ? 10 : d
          const chartPannas = CHART_ABR9_PANNAS.get(ank) || []
          pannas.push(...chartPannas)
        }
        break
      case '20 Chart':
      case '30 Chart':
      case '40 Chart': {
        // 20/30/40 Chart: each digit is an ank → that ank's fixed chart pannas
        // (2/3/4 per ank — operator-verbatim data in CHART_20/30/40_PANNAS)
        const chartMap = groupType === '20 Chart' ? CHART_20_PANNAS : groupType === '30 Chart' ? CHART_30_PANNAS : CHART_40_PANNAS
        for (const d of sorted) {
          const ank = d === 0 ? 10 : d
          pannas.push(...(chartMap.get(ank) || []))
        }
        break
      }
      case 'Family Set 4':
      case 'Family Set 6':
      case 'Family Set 8':
      case 'Family Chart': {
        // Family types: each 3-digit group in the select field is a family seed
        // Use buildGroupBatch which properly handles reverse lookup via resolveFamilyKey
        const seedStr = sorted.map(d => String(d)).join('')
        const option = groupType as GroupOption
        try {
          const batchResult = buildGroupBatch(option, seedStr, { rate: 0 })
          pannas.push(...getMergedEntries(batchResult).map(e => e.number))
        } catch {
          // fallback: empty
        }
        break
      }
      default:
        // Fallback: treat as Motor Pana
        pannas.push(...generateSP())
        break
    }

    return pannas
  }

  // Toggle a series card (1-10) and auto-update the Select field
  function toggleSeriesCard(card: number) {
    setTripleSeriesCards(prev => {
      const next = new Set(prev)
      if (next.has(card)) {
        next.delete(card)
      } else {
        next.add(card)
      }
      // Auto-update Select field: card 10 maps to digit 0
      const digits = Array.from(next).sort((a, b) => a - b).map(n => n === 10 ? 0 : n)
      setTripleSelect(digits.join(''))
      return next
    })
  }

  // Toggle a DS series card (1-10) and auto-update the Single Select field
  function toggleDsSeriesCard(card: number) {
    setDsSeriesCards(prev => {
      const next = new Set(prev)
      if (next.has(card)) {
        next.delete(card)
      } else {
        next.add(card)
      }
      // Auto-update Select field: card 10 maps to digit 0
      const digits = Array.from(next).sort((a, b) => a - b).map(n => n === 10 ? 0 : n)
      const selectVal = digits.join('')
      setDsSelectSingle(selectVal)
      // Auto-calculate Amount = count of digits × rate
      const rate = parseFloat(singleRate) || 0
      if (rate > 0 && digits.length > 0) {
        setSingleAmount(String(digits.length * rate))
      } else {
        setSingleAmount('')
      }
      return next
    })
  }

  const handleSubmitTriple = async () => {
    if (!viewingInventoryId) return
    if (submitting) return // prevent double-tap on mobile
    setSubmitting(true)
    setMessage('')

    // Dismiss virtual keyboard on mobile
    const activeEl = document.activeElement as HTMLElement
    if (activeEl && activeEl.blur) activeEl.blur()

    // Yield to let the UI update and keyboard dismiss on mobile
    await new Promise(resolve => setTimeout(resolve, 50))

    try {
      if (tripleMode === 'mix') {
        // Parse content directly — no separate Export step needed
        if (!whatsappContent.trim()) {
          setMessage('Please paste content first')
          setSubmitting(false)
          return
        }

        const defaultRate = parseFloat(rate) || 0
        // Phase 2 — use the FULL parser so we capture SKIPPED + DROPPED metadata
        // v4 fix: wrapped in try/catch with PARSER_TIMEOUT-aware error message.
        // Without this, ANY pathological input would freeze the tab forever.
        let parseResult: ParseResult
        const parseT0 = typeof performance !== 'undefined' ? performance.now() : Date.now()
        try {
          parseResult = parseWhatsAppContentFull(whatsappContent, tripleMode, defaultRate)
        } catch (parseErr) {
          const elapsed = Math.round((typeof performance !== 'undefined' ? performance.now() : Date.now()) - parseT0)
          const code = (parseErr as Error & { code?: string }).code
          if (code === 'PARSER_TIMEOUT') {
            console.error('[parser] TIME BUDGET EXCEEDED after', elapsed, 'ms')
            setMessage(
              `Input too complex — parser gave up after ${elapsed}ms. ` +
              `Try splitting the paste into smaller chunks (max ~500 lines each) and resubmitting.`
            )
          } else {
            console.error('[parser] parseWhatsAppContentFull threw:', parseErr)
            setMessage('Failed to parse content. Please simplify the input and try again.')
          }
          setSubmitting(false)
          return
        }
        const parseElapsed = Math.round((typeof performance !== 'undefined' ? performance.now() : Date.now()) - parseT0)
        parserDebug('submit: parse done', { entries: parseResult.entries.length, ms: parseElapsed })
        const activeEntries = parseResult.entries
        const activeGrid = buildGridFromParsed(activeEntries)

        if (activeEntries.length === 0) {
          setMessage('No valid entries found. Check your content format.')
          setSubmitting(false)
          return
        }

        // Separate active (with rate) and skipped (no rate) entries for display
        const validEntries = activeEntries.filter(e => !e.skipped)
        const skippedEntries = activeEntries.filter(e => e.skipped)

        const totals = calculateGridTotals(activeGrid)
        const grandTotal = Object.values(totals).reduce((sum, v) => sum + v, 0)

        // v4 fix: defensive body-size trimming to prevent Hostinger / mobile choke.
        // - details: cap at 30KB (anything more is re-parsable noise)
        // - parsedData.entries: cap at 500 entries (chart still aggregates correctly)
        const detailsForSave = whatsappContent.length > 30_000
          ? whatsappContent.slice(0, 30_000) + '\n[truncated]'
          : whatsappContent
        const entriesForSave = validEntries.length > 500
          ? validEntries.slice(0, 500)
          : validEntries

        const postBody = JSON.stringify({
          inventoryId: viewingInventoryId,
          vendorId: vendorId || null,
          type: 'mix',
          details: detailsForSave,
          parsedData: JSON.stringify({
            entries: entriesForSave,
            totalEntriesCount: validEntries.length,
            grid: activeGrid,
            totals,
            skipped: skippedEntries.map(e => e.number).slice(0, 200),
            skippedNumbers: parseResult.skippedNumbers,
            droppedTokens: parseResult.droppedTokens,
          }),
          rate: defaultRate,
          totalAmount: grandTotal,
          createdBy: currentUser?.username || 'admin1',
        })
        parserDebug('submit: POST body built', {
          bodyBytes: postBody.length,
          entries: entriesForSave.length,
          totalEntries: validEntries.length,
        })

        const postT0 = typeof performance !== 'undefined' ? performance.now() : Date.now()
        await apiFetch('/api/triple-inventories', {
          method: 'POST',
          body: postBody,
        })
        parserDebug('submit: POST done', { ms: Math.round((typeof performance !== 'undefined' ? performance.now() : Date.now()) - postT0) })

        // Phase 2 — record ParserException entries for SKIPPED/DROPPED records.
        // Non-fatal — if this fails the main save still succeeded.
        if (parseResult.skippedNumbers.length > 0 || parseResult.droppedTokens.length > 0) {
          await recordParserExceptions({
            uploadedBy: currentUser?.username || 'admin1',
            uploadedByUserId: currentUser?.id,
            market: inv?.inventoryCode?.market,
            inventoryCodeId: inv?.inventoryCode?.id,
            originalText: whatsappContent,
            skippedNumbers: parseResult.skippedNumbers,
            droppedTokens: parseResult.droppedTokens,
          })
        }
      } else if (tripleMode === 'group') {
        if (!tripleGroupType) {
          setMessage('Please select a Group type')
          setSubmitting(false)
          return
        }

        const groupRateVal = parseFloat(tripleGroupRate) || 0
        const groupAmountVal = parseFloat(tripleGroupAmount) || 0
        const mergedPannaMap = new Map<string, number>()
        let generatedPannas: string[]
        let detailsStr: string
        let parsedDataObj: Record<string, unknown>

        if (groupInputMode === 'single') {
          // ── SINGLE MODE: Series buttons + Select field (ank-based expansion) ──
          if (!tripleSelect.trim() && tripleSeriesCards.size === 0) {
            setMessage('Please select series cards or enter digits in Select field')
            setSubmitting(false)
            return
          }

          const selectDigits = tripleSelect.split('').filter(c => /^\d$/.test(c)).map(Number)
          const cards = Array.from(tripleSeriesCards).sort((a, b) => a - b)

          if (tripleGroupType === 'Motor Pana') {
            // Motor: generate all C(n,3) combinations from the digit string
            generatedPannas = generateGroupPannas(selectDigits, 'Motor Pana')
          } else if (['SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP', 'SP Motor', 'DP Motor'].includes(tripleGroupType)) {
            // SP/DP/TP: each digit in select is an ank reference
            generatedPannas = generateGroupPannas(selectDigits, tripleGroupType)
          } else if (['50 Chart', '60 Chart', '70 Chart', '90 DP Chart', '90 ABR Chart', '20 Chart', '30 Chart', '40 Chart'].includes(tripleGroupType)) {
            // Chart types: each digit in Select is an ank reference
            generatedPannas = generateGroupPannas(selectDigits, tripleGroupType)
          } else if (['Family Set 4', 'Family Set 6', 'Family Set 8', 'Family Chart'].includes(tripleGroupType)) {
            // Family types: the whole Select string is a seed (3-digit panna)
            const seedStr = tripleSelect.trim()
            const option = tripleGroupType as GroupOption
            const batchResult = buildGroupBatch(option, seedStr, { rate: groupRateVal })
            for (const entry of getMergedEntries(batchResult)) {
              const prev = mergedPannaMap.get(entry.number) || 0
              mergedPannaMap.set(entry.number, prev + entry.price)
            }
            generatedPannas = Array.from(mergedPannaMap.keys())
          } else {
            generatedPannas = []
          }

          // Build merged map for SP/DP/TP/Motor
          if (mergedPannaMap.size === 0) {
            for (const p of generatedPannas) {
              const prev = mergedPannaMap.get(p) || 0
              mergedPannaMap.set(p, prev + groupRateVal)
            }
          }

          // Build grid
          const grid: GridData = {}
          for (let i = 1; i <= 10; i++) grid[i] = []
          for (const [panna, rate] of mergedPannaMap) {
            const pos = calculateTriplePosition(panna)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: panna, price: rate })
            }
          }
          const totals = calculateGridTotals(grid)
          const gridTotal = Object.values(totals).reduce((sum, v) => sum + v, 0)
          const totalAmount = groupAmountVal > 0 ? groupAmountVal : gridTotal

          // Build a rich details string that captures the full submission context:
          //   - Card series (which 1-10 buttons were toggled, if any)
          //   - Group type (e.g. "Family Set 8")
          //   - The raw seed(s) entered in the Select field (so user can verify
          //     exactly what was submitted — previously this was missing)
          //   - Panna count + total amount (so the details column shows the
          //     outcome of the calculation, not just the input)
          const cardStr = cards.length > 0 ? cards.join(',') : '-'
          const seedStr = tripleSelect.trim() || '-'
          const pannaCount = mergedPannaMap.size
          detailsStr = `Card: ${cardStr} | Group: ${tripleGroupType} | Seed: ${seedStr} | Pannas: ${pannaCount} | Rate: ${groupRateVal} | Total: ${totalAmount}`
          parsedDataObj = {
            seriesCards: cards,
            select: tripleSelect,
            groupType: tripleGroupType,
            cards,
            generatedPannas,
            numbers: Array.from(mergedPannaMap.entries()).map(([number, price]) => ({ number, price })),
            grid,
            totals,
          }

          await apiFetch('/api/triple-inventories', {
            method: 'POST',
            body: JSON.stringify({
              inventoryId: viewingInventoryId,
              vendorId: vendorId || null,
              type: 'group',
              details: detailsStr,
              parsedData: JSON.stringify(parsedDataObj),
              rate: groupRateVal,
              totalAmount,
              createdBy: currentUser?.username || 'admin1',
            }),
          })
        } else {
          // ── BATCH MODE: Parse textarea content, then expand seeds ──
          if (!groupInputContent.trim()) {
            setMessage('Please paste content in the input area')
            setSubmitting(false)
            return
          }

          let parseResult: ParseResult
          try {
            parseResult = parseWhatsAppContentFull(groupInputContent, 'group', groupRateVal)
          } catch (parseErr) {
            const code = (parseErr as Error & { code?: string }).code
            if (code === 'PARSER_TIMEOUT') {
              setMessage('Input too complex — parser gave up. Try splitting into smaller chunks.')
            } else {
              setMessage('Failed to parse content. Please simplify the input and try again.')
            }
            setSubmitting(false)
            return
          }

          if (parseResult.entries.length === 0) {
            setMessage('No valid seeds found. Check your content format.')
            setSubmitting(false)
            return
          }

          for (const seedEntry of parseResult.entries) {
            if (seedEntry.skipped) continue
            const seedStr = seedEntry.number
            const seedRate = seedEntry.price
            const seedDigits = seedStr.split('').filter(c => /^\d$/.test(c)).map(Number)

            if (tripleGroupType === 'Motor Pana') {
              const motorPannas = generateGroupPannas(seedDigits, 'Motor Pana')
              for (const p of motorPannas) {
                const prev = mergedPannaMap.get(p) || 0
                mergedPannaMap.set(p, prev + seedRate)
              }
            } else if (['SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP', 'SP Motor', 'DP Motor'].includes(tripleGroupType)) {
              const pannas = generateGroupPannas(seedDigits, tripleGroupType)
              for (const p of pannas) {
                const prev = mergedPannaMap.get(p) || 0
                mergedPannaMap.set(p, prev + seedRate)
              }
            } else {
              const option = tripleGroupType as GroupOption
              const batchResult = buildGroupBatch(option, seedStr, { rate: seedRate })
              for (const entry of getMergedEntries(batchResult)) {
                const prev = mergedPannaMap.get(entry.number) || 0
                mergedPannaMap.set(entry.number, prev + entry.price)
              }
            }
          }

          // Build grid from merged pannas
          const grid: GridData = {}
          for (let i = 1; i <= 10; i++) grid[i] = []
          for (const [panna, rate] of mergedPannaMap) {
            const pos = calculateTriplePosition(panna)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: panna, price: rate })
            }
          }
          const totals = calculateGridTotals(grid)
          const gridTotal = Object.values(totals).reduce((sum, v) => sum + v, 0)
          const totalAmount = groupAmountVal > 0 ? groupAmountVal : gridTotal

          generatedPannas = Array.from(mergedPannaMap.keys())
          // Batch mode details: include the full panna count + total so the
          // details column reflects the actual calculation outcome. The raw
          // batch text is also included (truncated to 100 chars for the
          // details field — the full text is preserved in parsedData.inputContent).
          const batchPannaCount = mergedPannaMap.size
          const batchPreview = groupInputContent.length > 100
            ? groupInputContent.substring(0, 100) + '…'
            : groupInputContent
          detailsStr = `Card: - | Group: ${tripleGroupType} | Batch: ${batchPreview} | Pannas: ${batchPannaCount} | Rate: ${groupRateVal} | Total: ${totalAmount}`

          await apiFetch('/api/triple-inventories', {
            method: 'POST',
            body: JSON.stringify({
              inventoryId: viewingInventoryId,
              vendorId: vendorId || null,
              type: 'group',
              details: detailsStr,
              parsedData: JSON.stringify({
                seriesCards: [],
                select: '',
                groupType: tripleGroupType,
                cards: [],
                generatedPannas,
                numbers: Array.from(mergedPannaMap.entries()).map(([number, price]) => ({ number, price })),
                grid,
                totals,
                inputContent: groupInputContent.substring(0, 500),
                skippedNumbers: parseResult.skippedNumbers,
                droppedTokens: parseResult.droppedTokens,
              }),
              rate: groupRateVal,
              totalAmount,
              createdBy: currentUser?.username || 'admin1',
            }),
          })
        }
      } else if (tripleMode === 'common') {
        // ── COMMON MODE — supports two input styles ──
        // 1. 'single' (original): comma-separated series in the Series field
        // 2. 'batch' (new): bulk textarea where each line is
        //      [series tokens] [= rate]
        //    e.g. "00,10,11,12 = 100" or "00 10 11" (uses the Rate field)
        //    or one series per line "00=50". Series tokens are 2-digit numbers
        //    (00-99). Each series expands to its 10-panna family.
        let seriesNums: string[] = []
        let seriesRateMap: Record<string, number> = {}

        if (commonInputMode === 'batch') {
          if (!commonBatchContent.trim()) {
            setMessage('Please paste series content in the batch input area')
            setSubmitting(false)
            return
          }
          const defaultRate = parseFloat(tripleCommonRate) || 0
          const lines = commonBatchContent.split('\n').map(l => l.trim()).filter(l => l.length > 0)
          for (const line of lines) {
            // Strip WhatsApp metadata header if present
            let workLine = line
            const hm = workLine.match(WA_HEADER_RE)
            if (hm) workLine = (hm[2] || '').trim()
            if (!workLine || /^total/i.test(workLine) || /^[=\-+_*#]{3,}$/.test(workLine)) continue
            // Split "SERIES_LIST = RATE" (also "SERIES_LIST : RATE" / "SERIES_LIST - RATE")
            const eqSplit = workLine.split(/[=:]\s*|\s+-\s+/)
            const seriesPart = eqSplit[0] || ''
            let lineRate = defaultRate
            if (eqSplit.length >= 2) {
              const r = parseInt((eqSplit[1] || '').replace(/[^\d]/g, ''), 10)
              if (!isNaN(r) && r > 0) lineRate = r
            }
            // Extract 2-digit series tokens from the series part
            const tokens = seriesPart.split(/[\s,;.\-+/]+/).map(t => t.trim()).filter(t => /^\d{1,2}$/.test(t))
            for (const tok of tokens) {
              const padded = tok.padStart(2, '0')
              if (!seriesNums.includes(padded)) {
                seriesNums.push(padded)
              }
              seriesRateMap[padded] = lineRate  // last line wins if series repeated
            }
          }
          if (seriesNums.length === 0) {
            setMessage('No valid 2-digit series numbers found in batch content (e.g. "00,10,11 = 100")')
            setSubmitting(false)
            return
          }
        } else {
          if (!tripleCommonSeries.trim()) {
            setMessage('Please enter series numbers')
            setSubmitting(false)
            return
          }
          // Parse series numbers — each must be 2 digits (00-99)
          seriesNums = tripleCommonSeries.split(',').map(s => s.trim()).filter(s => /^\d{1,2}$/.test(s))
          if (seriesNums.length === 0) {
            setMessage('Please enter valid 2-digit series numbers (00-99)')
            setSubmitting(false)
            return
          }
        }

        const commonRateVal = parseFloat(tripleCommonRate) || 0
        const commonAmountVal = parseFloat(tripleCommonAmount) || 0

        // Generate pannas for each series number
        // Each series maps to exactly 10 pannas → total = 10 × rate per series.
        // In batch mode each series may carry its own rate (seriesRateMap);
        // in single mode every series uses the shared Rate field.
        const allCommonPannas: string[] = []
        const allCommonEntries: Array<{ number: string; price: number }> = []
        const seriesPannaMap: Record<string, string[]> = {}
        for (const series of seriesNums) {
          const paddedSeries = series.padStart(2, '0')
          const pannas = generateCommonPannas(paddedSeries)
          seriesPannaMap[paddedSeries] = pannas
          const seriesRate = commonInputMode === 'batch' ? (seriesRateMap[paddedSeries] ?? commonRateVal) : commonRateVal
          for (const p of pannas) {
            allCommonPannas.push(p)
            allCommonEntries.push({ number: p, price: seriesRate })
          }
        }

        // Total = sum of per-panna prices (respects per-series rates),
        // OR the manually specified Amount if provided
        let totalAmount = commonAmountVal
        if (totalAmount === 0) {
          totalAmount = allCommonEntries.reduce((s, e) => s + e.price, 0)
        }

        const seriesDisplay = seriesNums.join(',')
        const detailsStr = commonInputMode === 'batch'
          ? `Common (Batch): ${seriesDisplay} | Series: ${seriesNums.length} | Pannas: ${allCommonPannas.length} | Total: ${totalAmount}`
          : `Common: ${seriesDisplay} | Series: ${seriesNums.length} | Pannas: ${allCommonPannas.length} | Total: ${totalAmount}`
        // Create grid entries from generated pannas
        const gridEntries = allCommonEntries
        const grid: GridData = {}
        for (let i = 1; i <= 10; i++) grid[i] = []
        for (const entry of gridEntries) {
          const pos = calculateTriplePosition(entry.number)
          if (pos >= 1 && pos <= 10) {
            grid[pos].push(entry)
          }
        }
        const totals = calculateGridTotals(grid)

        await apiFetch('/api/triple-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId: viewingInventoryId,
            vendorId: vendorId || null,
            type: 'common',
            details: detailsStr,
            parsedData: JSON.stringify({
              series: seriesDisplay,
              seriesPannaMap,
              seriesRateMap,
              generatedPannas: allCommonPannas,
              numbers: gridEntries,
              grid,
              totals,
              batchInput: commonInputMode === 'batch' ? commonBatchContent : undefined,
            }),
            rate: commonRateVal,
            totalAmount,
            createdBy: currentUser?.username || 'admin1',
          }),
        })
      } else if (tripleMode === 'sangam') {
        // ── SANGAM ENTRY (Half Sangam A / Half Sangam B / Full Sangam) ──
        // Direct Triple-section items. Composite numbers ("X-PPP", "PPP-X",
        // "PPP-QQQ") are stored under type 'sangam'; position grids skip
        // them naturally so ERP charts stay clean.
        const entries: Array<{ num: string; points: number; label: string }> = []
        const lbl = sangamKind === 'Half Sangam A' ? 'HS-A' : sangamKind === 'Half Sangam B' ? 'HS-B' : 'FS'
        if (sangamInputMode === 'single') {
          const pts = parseInt(sangamPoints) || 0
          if (pts <= 0) { setMessage('Enter points for the entry'); setSubmitting(false); return }
          if (sangamKind === 'Half Sangam A') {
            if (!/^\d$/.test(sangamOpenDigit) || !/^\d{3}$/.test(sangamClosePanna)) {
              setMessage('Half Sangam A needs a 1-digit open and a 3-digit close panna'); setSubmitting(false); return
            }
            entries.push({ num: `${sangamOpenDigit}-${sangamClosePanna}`, points: pts, label: lbl })
          } else if (sangamKind === 'Half Sangam B') {
            if (!/^\d{3}$/.test(sangamOpenPanna) || !/^\d$/.test(sangamCloseDigit)) {
              setMessage('Half Sangam B needs a 3-digit open panna and a 1-digit close'); setSubmitting(false); return
            }
            entries.push({ num: `${sangamOpenPanna}-${sangamCloseDigit}`, points: pts, label: lbl })
          } else {
            if (!/^\d{3}$/.test(sangamOpenPanna) || !/^\d{3}$/.test(sangamClosePanna)) {
              setMessage('Full Sangam needs two 3-digit pannas'); setSubmitting(false); return
            }
            entries.push({ num: `${sangamOpenPanna}-${sangamClosePanna}`, points: pts, label: lbl })
          }
        } else {
          for (const rawLine of sangamBatchContent.split(/\r?\n/)) {
            const line = rawLine.trim()
            if (!line) continue
            const mm = line.match(/^(\d{1,3})-(\d{1,3})\s*[=*]\s*(\d+)$/)
            if (!mm) { setMessage(`Invalid line: "${line}" (expected ${lbl} NUM-NUM=points)`); setSubmitting(false); return }
            const a = mm[1], b = mm[2], pts = parseInt(mm[3])
            if (sangamKind === 'Half Sangam A' && (a.length !== 1 || b.length !== 3)) {
              setMessage(`Invalid ${lbl} pair: "${line}" — open digit + close panna`); setSubmitting(false); return
            }
            if (sangamKind === 'Half Sangam B' && (a.length !== 3 || b.length !== 1)) {
              setMessage(`Invalid ${lbl} pair: "${line}" — open panna + close digit`); setSubmitting(false); return
            }
            if (sangamKind === 'Full Sangam' && (a.length !== 3 || b.length !== 3)) {
              setMessage(`Invalid ${lbl} pair: "${line}" — open panna + close panna`); setSubmitting(false); return
            }
            if (pts <= 0) { setMessage(`Invalid points: "${line}"`); setSubmitting(false); return }
            entries.push({ num: `${a}-${b}`, points: pts, label: lbl })
          }
          if (!entries.length) { setMessage('Enter at least one batch line'); setSubmitting(false); return }
        }
        const total = entries.reduce((a, e) => a + e.points, 0)
        const detailsStr = `${sangamKind} entry — ` + entries.map(e => `${e.num}=${e.points}\u20B9`).join(', ')
        await apiFetch('/api/triple-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId: viewingInventoryId,
            vendorId: vendorId || null,
            type: 'sangam',
            details: detailsStr.slice(0, 30000),
            parsedData: JSON.stringify({
              sangamKind,
              entries: entries.map(e => ({ number: e.num, price: e.points, sangam: true, label: e.label })),
              numbers: entries.map(e => ({ number: e.num, price: e.points })),
              totalEntriesCount: entries.length,
            }),
            rate: 0,
            totalAmount: total,
            createdBy: currentUser?.username || 'admin1',
          }),
        })
        setSangamOpenDigit(''); setSangamOpenPanna(''); setSangamCloseDigit(''); setSangamClosePanna('')
        setSangamPoints(''); setSangamBatchContent('')
      }

      setMessage('Triple inventory submitted successfully!')
      // Reset all triple form states immediately (lightweight)
      setWhatsappContent('')
        setGroupInputContent('')
      setRate('')
      setVendorId('')
      setTripleSeriesCards(new Set())
      setTripleSelect('')
      setTripleGroupType('')
      setTripleGroupRate('')
      setTripleGroupAmount('')
      setTripleCommonSeries('')
      setTripleCommonRate('')
      setTripleCommonAmount('')
      setCommonBatchContent('')
      setSubmitting(false) // unblock button immediately
      // Defer heavy data fetches so UI stays responsive on mobile
      // useDeferredValue on tripleList/dsList + startTransition in fetch callbacks
      // ensures chart recalculations don't block touch events
      setTimeout(() => {
        fetchTripleList()
        fetchInventory()
      }, 150)
      return // early return since we already set submitting=false
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed to submit')
    }
    setSubmitting(false)
  }

  const handleResetTriple = () => {
    setWhatsappContent('')
    setRate('')
    setVendorId('')
    setTripleMode('mix')
    setMessage('')
    setTripleSeriesCards(new Set())
    setTripleSelect('')
    setTripleGroupType('')
    setTripleGroupRate('')
    setTripleGroupAmount('')
    setGroupBatchMode(false)
    setGroupBatchRawText('')
    setGroupBatchResult(null)
    setTripleCommonSeries('')
    setTripleCommonRate('')
    setTripleCommonAmount('')
    setCommonInputMode('single')
    setCommonBatchContent('')
    setSangamKind('Half Sangam A')
    setSangamInputMode('single')
    setSangamOpenDigit(''); setSangamOpenPanna(''); setSangamCloseDigit(''); setSangamClosePanna('')
    setSangamPoints(''); setSangamBatchContent('')
  }

  const handleDeleteTriple = async (id: string) => {
    if (!confirm('Delete this entry?')) return
    try {
      await apiFetch(`/api/triple-inventories/${id}`, { method: 'DELETE' })
      fetchTripleList()
      fetchInventory()
    } catch (err) { alert('Failed to delete entry: ' + (err instanceof Error ? err.message : 'Unknown error')) }
  }

  // ── Entry Edit (Triple + Double/Single lists) ──
  // Opens a modal pre-filled with the entry's number=price lines; saving PUTs
  // the corrected data and the API stamps isUpdated/updatedBy so the list can
  // show an "Updated" tag when wrong inputs have been corrected.
  const [editingEntry, setEditingEntry] = useState<{ kind: 'triple' | 'ds'; id: string; type: string } | null>(null)
  const [editTextArea, setEditTextArea] = useState('')
  const [editRate, setEditRate] = useState('')
  const [editSaving, setEditSaving] = useState(false)
  const [editMessage, setEditMessage] = useState('')

  const openEditTriple = (item: { id: string; type: string; parsedData: string; rate: number }) => {
    let lines: string[] = []
    try {
      const pd = JSON.parse(item.parsedData || '{}')
      if (Array.isArray(pd.numbers) && pd.numbers.length > 0) {
        lines = pd.numbers.map((n: { number: string; price: number }) => `${n.number}=${n.price}`)
      } else if (Array.isArray(pd.generatedPannas) && pd.generatedPannas.length > 0) {
        lines = pd.generatedPannas.map((n: string) => `${n}=${item.rate || 0}`)
      }
    } catch { /* leave empty */ }
    if (lines.length === 0) {
      // Fall back to details text so the user still has something editable
      lines = [item.type === 'amount' ? '(amount entry — not editable)' : '']
    }
    setEditingEntry({ kind: 'triple', id: item.id, type: item.type })
    setEditTextArea(lines.join('\n'))
    setEditRate(String(item.rate || ''))
    setEditMessage('')
  }

  const openEditDs = (item: { id: string; type: string; parsedData: string; rate: number }) => {
    let lines: string[] = []
    try {
      const pd = JSON.parse(item.parsedData || '{}')
      if (Array.isArray(pd.numbers) && pd.numbers.length > 0) {
        lines = pd.numbers.map((n: { number: string; price: number }) => `${n.number}=${n.price}`)
      }
    } catch { /* leave empty */ }
    setEditingEntry({ kind: 'ds', id: item.id, type: item.type })
    setEditTextArea(lines.join('\n'))
    setEditRate(String(item.rate || ''))
    setEditMessage('')
  }

  // Parse the edit textarea back into number/price pairs — accepts the same
  // flexible "number=price" separators as the main parser (=, -, :, space).
  const parseEditLines = (raw: string): Array<{ number: string; price: number }> => {
    const out: Array<{ number: string; price: number }> = []
    for (const line of raw.split('\n').map(l => l.trim()).filter(l => l.length > 0)) {
      const m = line.match(/^(\d{1,4})\s*[=\-:.]+\s*(\d+)\s*(?:₹|rs)?\s*$/i) || line.match(/^(\d{1,4})\s+(\d+)\s*$/)
      if (m) {
        const price = parseInt(m[2], 10)
        if (price > 0) out.push({ number: m[1], price })
      }
    }
    return out
  }

  const saveEntryEdit = async () => {
    if (!editingEntry || editSaving) return
    const numbers = parseEditLines(editTextArea)
    if (numbers.length === 0) {
      setEditMessage('No valid number=price lines found (e.g. "128=100")')
      return
    }
    setEditSaving(true)
    setEditMessage('')
    try {
      const rateVal = parseFloat(editRate) || 0
      if (editingEntry.kind === 'triple') {
        await apiFetch(`/api/triple-inventories/${editingEntry.id}`, {
          method: 'PUT',
          body: JSON.stringify({ numbers, rate: rateVal }),
        })
        setTimeout(() => { fetchTripleList(); fetchInventory() }, 100)
      } else {
        await apiFetch(`/api/double-single-inventories/${editingEntry.id}`, {
          method: 'PUT',
          body: JSON.stringify({ numbers, rate: rateVal }),
        })
        setTimeout(() => { fetchDsList(); fetchInventory() }, 100)
      }
      setEditingEntry(null)
    } catch (err) {
      setEditMessage(err instanceof Error ? err.message : 'Failed to save changes')
    }
    setEditSaving(false)
  }

  // ── Double/Single/Amount helpers ──

  // BUG 1 FIX: buildDsGrid now accepts an optional type filter so the Double 10×10
  // chart grid ONLY contains double entries (previously single entries leaked into it
  // because only 'amount' was excluded).
  function buildDsGrid(dsListParam: typeof dsList, typeFilter?: 'single' | 'double'): { [key: string]: number } {
    const grid: { [key: string]: number } = {}
    for (let i = 0; i <= 99; i++) {
      grid[String(i).padStart(2, '0')] = 0
    }
    for (const entry of dsListParam) {
      const e = entry as { type: string; parsedData: string; details: string; totalAmount: number; rate: number }
      if (e.type === 'amount') continue
      // BUG 1 FIX: skip entries that don't match the requested type filter
      if (typeFilter && e.type !== typeFilter) continue
      try {
        const pd = JSON.parse(e.parsedData)
        if (pd.numbers && Array.isArray(pd.numbers) && pd.numbers.length > 0) {
          for (const num of pd.numbers) {
            const key = String(num.number).padStart(2, '0')
            if (grid[key] !== undefined) {
              grid[key] += num.price
            }
          }
        } else if (e.details && e.details.trim()) {
          // Fallback: parse the details field when parsedData is empty
          const parsedEntries = parseWhatsAppContent(e.details, e.type)
          for (const entry of parsedEntries) {
            const key = String(entry.number).padStart(2, '0')
            if (grid[key] !== undefined) {
              grid[key] += entry.price
            }
          }
        }
      } catch { /* skip unparseable */ }
    }
    return grid
  }

  // Memoized version to avoid recomputing on every render
  // BUG 1 FIX: pass 'double' typeFilter so the 10×10 grid only contains double entries
  const memoizedDsGrid = useMemo(() => buildDsGrid(deferredDsList, 'double'), [deferredDsList])

  function isDoubleDigitSame(numStr: string): boolean {
    return numStr.length === 2 && numStr[0] === numStr[1]
  }

  const handleDsSubmit = async () => {
    if (!viewingInventoryId) return
    if (dsSubmitting) return // prevent double-tap on mobile
    setDsSubmitting(true)
    setDsMessage('')

    // Dismiss virtual keyboard on mobile
    const activeEl = document.activeElement as HTMLElement
    if (activeEl && activeEl.blur) activeEl.blur()

    // Yield to let the UI update and keyboard dismiss on mobile
    await new Promise(resolve => setTimeout(resolve, 50))

    try {
      if (tab === 'single') {
        if (!dsSelectSingle.trim()) { setDsMessage('Please enter numbers or paste content in Select (Single)'); setDsSubmitting(false); return }
        const rateVal = parseFloat(singleRate) || 0
        
        // Try parsing as WhatsApp format first
        let entries = parseWhatsAppContent(dsSelectSingle, 'single', rateVal)
        let numbers: Array<{ number: string; price: number }>
        
        if (entries.length > 0) {
          // Filter only single-digit numbers for single mode
          const singleEntries = entries.filter(e => /^\d$/.test(e.number))
          if (singleEntries.length > 0) {
            numbers = singleEntries.map(e => ({ number: e.number, price: e.price }))
          } else {
            // Use all parsed entries as-is (some might be multi-digit but user entered them)
            numbers = entries.map(e => ({ number: e.number, price: e.price }))
          }
        } else {
          // Fallback: parse as raw digits (comma separated or just a string of digits)
          const digits: string[] = dsSelectSingle.includes(',')
            ? dsSelectSingle.split(',').map(n => n.trim()).filter(n => /^\d$/.test(n))
            : dsSelectSingle.split('').filter(c => /^\d$/.test(c))
          if (digits.length === 0) { setDsMessage('No valid digits found'); setDsSubmitting(false); return }
          numbers = digits.map(d => ({ number: d, price: rateVal }))
        }
        
        const totalAmount = numbers.reduce((sum, n) => sum + n.price, 0)
        const detailsStr = `Card: ${numbers.map(n => n.number).join(',')} Single:`

        await apiFetch('/api/double-single-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId: viewingInventoryId,
            vendorId: singleVendorId || null,
            type: 'single',
            details: detailsStr,
            parsedData: JSON.stringify({ numbers }),
            rate: rateVal,
            totalAmount,
            createdBy: currentUser?.username || 'admin1',
          }),
        })
      } else if (tab === 'double') {
        if (!dsSelectDouble.trim()) { setDsMessage('Please enter numbers or paste content in Select (Double)'); setDsSubmitting(false); return }

        let numbers: Array<{ number: string; price: number }>
        let rateVal = parseFloat(doubleRate) || 0

        // ── PRIMARY: Use the same WhatsApp parser as triple tab ──
        // This handles 19+ formats including "12=100", "12-100", "12 100",
        // "12.34.56=200", "12,34,56=100", WhatsApp metadata headers, etc.
        const waEntries = parseWhatsAppContent(dsSelectDouble, 'double', rateVal)
        const waFiltered = waEntries.filter(e => /^\d{2}$/.test(e.number))

        if (waFiltered.length > 0) {
          // WhatsApp parser succeeded — use its entries
          numbers = waFiltered.map(e => ({ number: e.number, price: e.price }))
          // If parser found a rate, use it (only if user didn't specify one)
          if (rateVal === 0 && waFiltered[0]) {
            rateVal = waFiltered[0].price
          }
        } else {
          // ── FALLBACK 1: Milan-style dot format (rare, kept for compat) ──
          const dotParsed = parseDoubleDotFormat(dsSelectDouble)
          if (dotParsed.entries.length > 0) {
            const fallbackRate = parseFloat(doubleRate) || 0
            numbers = dotParsed.entries.map(e => ({
              number: e.number,
              price: e.price > 0 ? e.price : fallbackRate,
            }))
            rateVal = dotParsed.rate || rateVal
          } else {
            // ── FALLBACK 2: Space/comma-separated 2-digit numbers ──
            const rawNums = dsSelectDouble.split(/[\s,]+/).filter(n => /^\d{2}$/.test(n.trim())).map(n => n.trim())
            if (rawNums.length === 0) { setDsMessage('No valid 2-digit numbers found. Try pasting WhatsApp data with format like "12=100" or "12.34.56=200"'); setDsSubmitting(false); return }
            numbers = rawNums.map(n => ({ number: n, price: rateVal }))
          }
        }

        const totalAmount = numbers.reduce((sum, n) => sum + n.price, 0)
        const cardNums = numbers.map(n => n.number).join(',')
        const detailsStr = `Card: ${cardNums} Double:`

        await apiFetch('/api/double-single-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId: viewingInventoryId,
            vendorId: doubleVendorId || null,
            type: 'double',
            details: detailsStr,
            parsedData: JSON.stringify({ numbers, series: doubleSeries || dsDoubleParsedVendor || undefined }),
            rate: rateVal,
            totalAmount,
            createdBy: currentUser?.username || 'admin1',
          }),
        })
      }

      // Phase 2 — record ParserException entries for any SKIPPED/DROPPED records
      // that were captured during the Export step (single/double modes only).
      // Non-fatal — if this fails, the main save still succeeded.
      if (dsSkippedNumbers.length > 0 || dsDroppedTokens.length > 0) {
        const dsOriginalText = tab === 'single' ? dsSelectSingle : dsSelectDouble
        await recordParserExceptions({
          uploadedBy: currentUser?.username || 'admin1',
          uploadedByUserId: currentUser?.id,
          market: inv?.inventoryCode?.market,
          inventoryCodeId: inv?.inventoryCode?.id,
          originalText: dsOriginalText,
          skippedNumbers: dsSkippedNumbers,
          droppedTokens: dsDroppedTokens,
        })
      }

      setDsMessage('Submitted successfully!')
      if (tab === 'single') handleSingleReset(); else handleDoubleReset()
      setDsSubmitting(false) // unblock button immediately
      // Defer heavy data fetches so UI stays responsive on mobile
      setTimeout(() => {
        fetchDsList()
        fetchInventory()
      }, 150)
      return // early return since we already set dsSubmitting=false
    } catch (err: unknown) {
      setDsMessage(err instanceof Error ? err.message : 'Failed to submit')
    }
    setDsSubmitting(false)
  }

  const handleDsExport = async () => {
    // Use dsSelectSingle or dsSelectDouble based on current tab
    const content = tab === 'single' ? dsSelectSingle : dsSelectDouble
    if (!content.trim()) return

    setDsExporting(true)
    // Yield to let UI update on mobile
    await new Promise(resolve => setTimeout(resolve, 50))

    try {
      if (tab === 'double') {
        // Try Milan-style dot format first
        const dotParsed = parseDoubleDotFormat(content)
        if (dotParsed.entries.length > 0) {
          // Build 10x10 grid for double using per-number rates
          const grid: { [key: string]: number } = {}
          for (let i = 0; i <= 99; i++) grid[String(i).padStart(2, '0')] = 0
          const fallbackRate = parseFloat(doubleRate) || 0
          for (const e of dotParsed.entries) {
            grid[e.number] = (grid[e.number] || 0) + (e.price > 0 ? e.price : fallbackRate)
          }
          // Auto-fill rate and vendor if found
          if (dotParsed.rate > 0 && !doubleRate) setDoubleRate(String(dotParsed.rate))
          if (dotParsed.vendorName && !doubleSeries) setDoubleSeries(dotParsed.vendorName)
          // Calculate total amount from per-number rates
          const totalAmount = dotParsed.entries.reduce((sum, e) => sum + (e.price > 0 ? e.price : fallbackRate), 0)
          setDoubleAmount(String(totalAmount))
          const entries = dotParsed.entries.map(e => ({
            number: e.number,
            price: e.price > 0 ? e.price : fallbackRate,
          }))
          // Wrap heavy state updates in startTransition to keep UI responsive on mobile
          startTransition(() => {
            setDsDoubleGridData(grid)
            setDsDoubleParsedNumbers(dotParsed.entries.map(e => e.number))
            setDsDoubleParsedRate(dotParsed.rate || fallbackRate)
            setDsDoubleParsedVendor(dotParsed.vendorName)
            setDsParsedEntries(entries)
            setDsGridData(buildGridFromParsedByMode(entries, 'double'))
          })
          return
        }
      }

      const dsRateVal = tab === 'single' ? (parseFloat(singleRate) || 0) : (parseFloat(doubleRate) || 0)
      const result = parseWhatsAppContentFull(content, tab, dsRateVal)
      const entries = result.entries
      const grid = buildGridFromParsedByMode(entries, tab as 'single' | 'double')
      // Wrap heavy state updates in startTransition to keep UI responsive on mobile
      startTransition(() => {
        setDsParsedEntries(entries)
        setDsSkippedNumbers(result.skippedNumbers)
        setDsDroppedTokens(result.droppedTokens)
        setDsGridData(grid)
        if (tab === 'double') {
          // Build 10x10 grid from parsed entries for ---, .rs, and other formats
          const doubleGrid: { [key: string]: number } = {}
          for (let i = 0; i <= 99; i++) doubleGrid[String(i).padStart(2, '0')] = 0
          for (const e of entries) {
            if (/^\d{2}$/.test(e.number)) {
              doubleGrid[e.number] = (doubleGrid[e.number] || 0) + e.price
            }
          }
          setDsDoubleGridData(doubleGrid)
          setDsDoubleParsedNumbers(entries.filter(e => /^\d{2}$/.test(e.number)).map(e => e.number))
          const totalAmt = entries.reduce((s, e) => s + e.price, 0)
          setDoubleAmount(String(totalAmt))
        }
      })
    } finally {
      setDsExporting(false)
    }
  }

  // Shared change handler for the Single bulk textarea — used by BOTH manual
  // typing/pasting and speech-to-text dictation (logic identical to the previous
  // inline onChange — only extracted, not changed).
  const handleSingleContentChange = (raw: string) => {
    setDsSelectSingle(raw)
    // Auto-calculate amount from single digits
    const rate = parseFloat(singleRate) || 0
    if (rate > 0) {
      try {
        const parsed = parseWhatsAppContentFull(raw, 'single', rate)
        const validEntries = parsed.entries.filter(e => !e.skipped && /^\d$/.test(e.number))
        if (validEntries.length > 0) {
          setSingleAmount(String(validEntries.length * rate))
        } else {
          // Fallback: count raw digits
          const digits = raw.split('').filter(c => /^\d$/.test(c))
          if (digits.length > 0) {
            setSingleAmount(String(digits.length * rate))
          } else {
            setSingleAmount('')
          }
        }
      } catch {
        const digits = raw.split('').filter(c => /^\d$/.test(c))
        if (digits.length > 0) {
          setSingleAmount(String(digits.length * rate))
        } else {
          setSingleAmount('')
        }
      }
    } else {
      setSingleAmount('')
    }
  }

  const handleSingleReset = () => {
    setSingleVendorId('')
    setSingleRate('')
    setSingleAmount('')
    setDsSelectSingle('')
    setDsMessage('')
    setDsParsedEntries([])
    setDsSkippedNumbers([])
    setDsDroppedTokens([])
    setDsGridData(null)
  }

  const handleDoubleReset = () => {
    setDoubleVendorId('')
    setDoubleSeries('')
    setDoubleRate('')
    setDoubleAmount('')
    setDsSelectDouble('')
    setDsSeriesCards(new Set())
    setDsMessage('')
    setDsDoubleGridData(null)
    setDsDoubleParsedNumbers([])
    setDsDoubleParsedRate(0)
    setDsDoubleParsedVendor('')
  }

  const handleDeleteDs = async (id: string) => {
    if (!confirm('Delete this entry?')) return
    try {
      await apiFetch(`/api/double-single-inventories/${id}`, { method: 'DELETE' })
      fetchDsList()
      fetchInventory()
    } catch (err) { alert('Failed to delete entry: ' + (err instanceof Error ? err.message : 'Unknown error')) }
  }

  const handleDeleteInventory = async () => {
    if (!inv || !confirm('Delete this entire inventory?')) return
    try {
      await apiFetch(`/api/inventories/${inv.id}`, { method: 'DELETE' })
      useAppStore.getState().setViewingInventoryId(null)
      useAppStore.getState().setCurrentPage('inv-list')
    } catch (err) { alert('Failed to delete inventory: ' + (err instanceof Error ? err.message : 'Unknown error')) }
  }

  const openChart = (mode: 'full' | 'blank') => {
    setChartMode(mode)
    setChartBwMode(true) // Default to B&W mode as per reference design
    setChartFilter('all')
    setChartLessPct('')
    setChartAddPct('')
    setChartAppliedPct({ less: 0, add: 0 })
    setChartMarkedShared(new Set())
    setChartShowShared(true)
    setChartHideShared(false)
    setChartColDeduction(0)
    setChartColDeductionInput('')
    setChartPerColDeduction({})
    setChartPerColAdd({})
    setShowChartModal(true)
  }

  const handleDownloadChart = async () => {
    if (!inv) { setChartDownloading(false); return }
    setChartDownloading(true)
    // Yield to let UI update on mobile before heavy canvas generation
    await new Promise(resolve => setTimeout(resolve, 50))
    try {
      const priceMap = chartPriceMap
      const isMobile = window.innerWidth < 768
      const canvas = generateChartCanvas({
        priceMap,
        pannaChart: PANNA_220_CHART,
        inv: { date: inv.date, time: inv.time ?? undefined, inventoryCode: inv.inventoryCode },
        tripleGrandTotal,
        isMobile,
        appliedPct: chartAppliedPct,
        colDeduction: chartColDeduction,
        perColDeduction: chartPerColDeduction,
        perColAdd: chartPerColAdd,
        styleCustom: chartStyleCustom,
      })

      // Download — await the blob to avoid race condition with finally block
      const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'))
      if (!blob) { setChartDownloading(false); return }

      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      const gameName = inv.inventoryCode?.name || 'chart'
      const dateStr = inv.date ? formatDate(inv.date) : 'unknown'
      link.download = `Date_${dateStr}_Game_${gameName}.png`
      link.href = url
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      // Phase 2 — log chart revision (save action)
      await logChartRevision({
        chartId: inv.id,
        action: 'save',
        summary: `Downloaded chart image: ${gameName} (${dateStr})`,
        newData: {
          mode: chartMode,
          bw: chartBwMode,
          filter: chartFilter,
          appliedPct: chartAppliedPct,
          markedShared: Array.from(chartMarkedShared),
          grandTotal: adjustedGrandTotal,
        },
      })
    } catch (err) {
      console.error('Download failed:', err)
      alert('Download failed. Please try again.')
    } finally {
      setChartDownloading(false)
    }
  }

  const handleShareChart = async () => {
    if (!inv) { setChartSharing(false); return }
    setChartSharing(true)
    // Yield to let UI update on mobile before heavy canvas generation
    await new Promise(resolve => setTimeout(resolve, 50))
    try {
      const priceMap = chartPriceMap
      const isMobile = window.innerWidth < 768
      const canvas = generateChartCanvas({
        priceMap,
        pannaChart: PANNA_220_CHART,
        inv: { date: inv.date, time: inv.time ?? undefined, inventoryCode: inv.inventoryCode },
        tripleGrandTotal,
        isMobile,
        appliedPct: chartAppliedPct,
        colDeduction: chartColDeduction,
        perColDeduction: chartPerColDeduction,
        perColAdd: chartPerColAdd,
        styleCustom: chartStyleCustom,
      })

      // Try Web Share API first (mobile-friendly)
      if (navigator.share && navigator.canShare) {
        const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'))
        if (blob) {
          const gameName = inv?.inventoryCode?.name || 'Game'
          const file = new File([blob], `Chart_${gameName}.png`, { type: 'image/png' })
          const shareData = { files: [file], title: 'Chart View', text: `Chart for ${gameName}` }
          if (navigator.canShare(shareData)) {
            let sharedOk = false
            try {
              await navigator.share(shareData)
              setChartCopied(true)
              setTimeout(() => setChartCopied(false), 2500)
              sharedOk = true
            } catch (shareErr: unknown) {
              if (shareErr instanceof Error && shareErr.name !== 'AbortError') {
                // Fallback to clipboard
                await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
                setChartCopied(true)
                setTimeout(() => setChartCopied(false), 2500)
                sharedOk = true
              }
            }
            if (sharedOk) {
              // Phase 2 — log chart revision (share action)
              await logChartRevision({
                chartId: inv.id,
                action: 'share',
                summary: `Shared chart image: ${gameName} (web share API)`,
                newData: { method: 'web_share', mode: chartMode, appliedPct: chartAppliedPct, grandTotal: adjustedGrandTotal },
              })
            }
            setChartSharing(false)
            return
          }
        }
      }

      // Fallback: copy to clipboard
      const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'))
      if (blob) {
        let sharedOk = false
        try {
          await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
          setChartCopied(true)
          setTimeout(() => setChartCopied(false), 2500)
          sharedOk = true
        } catch {
          // Last resort: download
          const url = URL.createObjectURL(blob)
          const link = document.createElement('a')
          link.download = `Chart_${inv?.inventoryCode?.name || 'chart'}.png`
          link.href = url
          document.body.appendChild(link)
          link.click()
          document.body.removeChild(link)
          URL.revokeObjectURL(url)
          sharedOk = true
        }
        if (sharedOk) {
          // Phase 2 — log chart revision (share action — clipboard fallback)
          await logChartRevision({
            chartId: inv.id,
            action: 'share',
            summary: `Shared chart image: ${inv?.inventoryCode?.name || 'chart'} (clipboard fallback)`,
            newData: { method: 'clipboard', mode: chartMode, appliedPct: chartAppliedPct, grandTotal: adjustedGrandTotal },
          })
        }
      }
    } catch (err) {
      console.error('Share failed:', err)
      alert('Share failed. Try using the Download button instead.')
    } finally {
      setChartSharing(false)
    }
  }

  // Share single/double data via WhatsApp in text format
  // BUG 2 FIX: Only share data for the currently active tab (single/double).
  // BUG 3 FIX: Apply chartAppliedPct percentage adjustments to amounts before sharing.
  const handleShareWhatsApp = async (type: 'double' | 'single') => {
    if (!inv) return
    try {
      const gameName = inv?.inventoryCode?.name || 'Game'
      const dateStr = inv?.date ? formatDate(inv.date) : ''
      let text = ''

      if (type === 'single') {
        // BUG 2 FIX: Only include single entries when type === 'single'
        // Single format: 0=7700₹ per line, positions 1-9 then 0 (shown as 10 but displayed as 0)
        const lines: string[] = []
        for (let pos = 1; pos <= 10; pos++) {
          let val = singleTotals[pos] || 0
          // BUG 3 FIX: Apply % adjustment (same formula used for chart display)
          if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
          if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
          // Position 10 = digit 0
          const displayNum = pos === 10 ? 0 : pos
          lines.push(`${displayNum}=${val}₹`)
        }
        // BUG 3 FIX: Apply % adjustment to grand total too
        let total = singleGrandTotal
        if (chartAppliedPct.less > 0) total = Math.round(total * (1 - chartAppliedPct.less / 100))
        if (chartAppliedPct.add > 0) total = Math.round(total * (1 + chartAppliedPct.add / 100))
        text = lines.join('\n') + '\n\n\n===========\n' + total + ' ₹'
      } else {
        // BUG 2 FIX: Only include double entries when type === 'double'
        // (memoizedDsGrid already filters by type='double' after BUG 1 FIX)
        // Double format: group by first digit, show only non-zero entries
        // e.g., 33=770₹ / 37=770₹ per group with blank lines between groups
        const dsGrid = memoizedDsGrid
        const groups: string[] = []

        for (let firstDigit = 1; firstDigit <= 9; firstDigit++) {
          const groupLines: string[] = []
          for (let secondDigit = 0; secondDigit <= 9; secondDigit++) {
            const key = `${firstDigit}${secondDigit}`
            let val = dsGrid[key] || 0
            // BUG 3 FIX: Apply % adjustment (same formula used for chart display)
            if (val > 0) {
              if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
              if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
              groupLines.push(`${key}=${val}₹`)
            }
          }
          // Also check 0X combinations where first digit is 0
          // (e.g., 01, 02, etc. — these are handled in the 0-group)
          if (groupLines.length > 0) {
            groups.push(groupLines.join('\n'))
          }
        }

        // Handle 0X group (first digit = 0)
        const zeroGroupLines: string[] = []
        for (let secondDigit = 0; secondDigit <= 9; secondDigit++) {
          const key = `0${secondDigit}`
          let val = dsGrid[key] || 0
          if (val > 0) {
            // BUG 3 FIX: Apply % adjustment
            if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
            if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
            zeroGroupLines.push(`${key}=${val}₹`)
          }
        }
        if (zeroGroupLines.length > 0) {
          groups.push(zeroGroupLines.join('\n'))
        }

        // BUG 3 FIX: Apply % adjustment to grand total
        let total = Object.values(dsGrid).reduce((sum, v) => sum + v, 0)
        if (chartAppliedPct.less > 0) total = Math.round(total * (1 - chartAppliedPct.less / 100))
        if (chartAppliedPct.add > 0) total = Math.round(total * (1 + chartAppliedPct.add / 100))
        text = groups.join('\n\n\n') + '\n\n\n===========\n' + total + ' ₹'
      }

      // Try Web Share API first (mobile-friendly)
      if (navigator.share) {
        try {
          await navigator.share({
            title: `${type === 'double' ? 'Double' : 'Single'} - ${gameName}`,
            text: text,
          })
          return
        } catch (shareErr: unknown) {
          if (shareErr instanceof Error && shareErr.name === 'AbortError') return
          // Fall through to WhatsApp URL
        }
      }

      // Fallback: open WhatsApp with text
      const waText = encodeURIComponent(text)
      window.open(`https://wa.me/?text=${waText}`, '_blank')
    } catch (err) {
      console.error('WhatsApp share failed:', err)
    }
  }

  // ── Gap 7: WhatsApp text sharing for Triple (Group/Common/Mix/Amount) chart data ──
  const handleShareWhatsAppTriple = async () => {
    if (!inv) return
    try {
      const gameName = inv?.inventoryCode?.name || 'Game'
      const dateStr = inv?.date ? formatDate(inv.date) : ''
      const timeStr = (inv as any)?.time || ''

      // Build the 220 chart price map (same logic as chart rendering)
      const priceMap: { [panna: string]: number } = {}
      for (let pos = 1; pos <= 10; pos++) {
        for (const entry of (adjustedChartGrid[pos] || [])) {
          if (entry.number.length === 3) {
            if (chartHideShared && chartMarkedShared.has(entry.number)) continue
            priceMap[entry.number] = (priceMap[entry.number] || 0) + entry.price
          }
        }
      }

      // Apply percentage adjustments
      const adjustedPriceMap: { [panna: string]: number } = {}
      for (const [panna, price] of Object.entries(priceMap)) {
        let val = price
        if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
        if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
        adjustedPriceMap[panna] = val
      }

      // Format: Group by ank (column), list pannas with prices per ank
      const lines: string[] = [`📅 ${dateStr} ${timeStr} | ${gameName}`, '']
      for (let ank = 1; ank <= 10; ank++) {
        const ankPannas = PANNA_220_CHART.flat().filter(p => {
          const sum = p.split('').reduce((s, d) => s + Number(d), 0)
          const a = sum % 10 === 0 ? 10 : sum % 10
          return a === ank
        })
        const ankEntries = ankPannas.filter(p => adjustedPriceMap[p] !== undefined && adjustedPriceMap[p] > 0)
        if (ankEntries.length === 0) continue
        const ankTotal = ankEntries.reduce((sum, p) => sum + adjustedPriceMap[p], 0)
        lines.push(`━━━ Ank ${ank === 10 ? 0 : ank} ━━━`)
        for (const p of ankEntries) {
          lines.push(`${p} = ${adjustedPriceMap[p]}₹`)
        }
        lines.push(`Total: ${ankTotal}₹`)
        lines.push('')
      }
      lines.push(`GRAND TOTAL: ${adjustedGrandTotal.toLocaleString('en-IN')} ₹`)

      const text = lines.join('\n')

      // Share via WhatsApp or clipboard
      if (navigator.share) {
        try {
          await navigator.share({ text, title: `Chart: ${gameName}` })
        } catch (shareErr: unknown) {
          if (shareErr instanceof Error && shareErr.name === 'AbortError') return
          await navigator.clipboard.writeText(text)
          setChartCopied(true)
          setTimeout(() => setChartCopied(false), 2500)
        }
      } else {
        await navigator.clipboard.writeText(text)
        setChartCopied(true)
        setTimeout(() => setChartCopied(false), 2500)
      }

      await logChartRevision({
        chartId: inv.id,
        action: 'share',
        summary: `Shared triple chart as WhatsApp text: ${gameName}`,
        newData: { method: 'whatsapp_text', mode: chartMode, appliedPct: chartAppliedPct, grandTotal: adjustedGrandTotal },
      })
    } catch (err) {
      console.error('WhatsApp share failed:', err)
    }
  }

  // ── ALL computations and hooks MUST be before any early returns ──

  // Chart data - combine ALL entries (triple + double/single) for chart
  // Memoized to avoid recomputing on every render (was causing mobile freeze)
  // Uses deferredTripleList/deferredDsList so chart recalculation doesn't block urgent UI
  const tripleEntries = deferredTripleList as Array<{ parsedData: string; details: string; type: string; totalAmount: number; rate: number; vendorId: string | null; vendor?: { businessName: string } }>

  const chartGrid: GridData = useMemo(() => {
    const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now()
    const grid: GridData = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: [], 9: [], 10: [] }

    // ── Render-path cap (v4 fix) ──
    // When a user has hundreds of saved entries, recomputing this on every
    // render freezes the tab. Cap at MAX_RENDER_TRIPLES most-recent entries.
    const tripleEntriesCapped = tripleEntries.length > MAX_RENDER_TRIPLES
      ? tripleEntries.slice(0, MAX_RENDER_TRIPLES)
      : tripleEntries

    // Add triple entries
    for (const te of tripleEntriesCapped) {
      try {
        const pd = JSON.parse(te.parsedData)
        if (pd.grid) {
          for (let pos = 1; pos <= 10; pos++) {
            if (pd.grid[pos]) {
              // BUG FIX: normalize pannas to canonical form (0 at end) so they
              // match PANNA_220_CHART lookups in the chart canvas/preview.
              // Motor-generated pannas store 0 at the start (e.g. "045")
              // but the chart expects "450".
              const normalized = pd.grid[pos].map((e: { number: string; price: number }) => ({
                number: normalizePanna(e.number), price: e.price
              }))
              grid[pos] = [...(grid[pos] || []), ...normalized]
            }
          }
        } else if (pd.numbers && Array.isArray(pd.numbers) && pd.numbers.length > 0) {
          for (const entry of pd.numbers) {
            const normNum = normalizePanna(entry.number)
            const pos = calculateTriplePosition(normNum)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: normNum, price: entry.price })
            }
          }
        } else if (pd.entries && Array.isArray(pd.entries) && pd.entries.length > 0) {
          for (const entry of pd.entries) {
            const normNum = normalizePanna(entry.number)
            const pos = calculateTriplePosition(normNum)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: normNum, price: entry.price })
            }
          }
        } else if (te.details && te.details.trim() && te.type !== 'amount') {
          const parsedEntries = parseWhatsAppContent(te.details, te.type)
          for (const entry of parsedEntries) {
            const normNum = normalizePanna(entry.number)
            const pos = calculateTriplePosition(normNum)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: normNum, price: entry.price })
            }
          }
        }
      } catch {
        // skip unparseable
      }
    }

    // Add double/single entries (capped for render-path performance — v4 fix)
    const dsEntriesAll = deferredDsList as Array<{ type: string; parsedData: string; details: string; totalAmount: number }>
    const dsEntries = dsEntriesAll.length > MAX_RENDER_DS ? dsEntriesAll.slice(0, MAX_RENDER_DS) : dsEntriesAll
    for (const de of dsEntries) {
      if (de.type === 'amount') continue
      try {
        const pd = JSON.parse(de.parsedData)
        if (pd.numbers && Array.isArray(pd.numbers) && pd.numbers.length > 0) {
          for (const num of pd.numbers) {
            const n = num as { number: string; price: number }
            const pos = de.type === 'single' ? calculateSinglePosition(n.number) : calculateDoublePosition(n.number)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: n.number, price: n.price })
            }
          }
        } else if (pd.entries && Array.isArray(pd.entries) && pd.entries.length > 0) {
          for (const entry of pd.entries) {
            const pos = de.type === 'single' ? calculateSinglePosition(entry.number) : calculateDoublePosition(entry.number)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: entry.number, price: entry.price })
            }
          }
        } else if (de.details && de.details.trim()) {
          const parsedEntries = parseWhatsAppContent(de.details, de.type)
          for (const entry of parsedEntries) {
            const pos = de.type === 'single' ? calculateSinglePosition(entry.number) : calculateDoublePosition(entry.number)
            if (pos >= 1 && pos <= 10) {
              grid[pos].push({ number: entry.number, price: entry.price })
            }
          }
        }
      } catch {
        // skip unparseable
      }
    }

    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now()
    parserDebug('chartGrid useMemo', {
      triples: tripleEntriesCapped.length,
      ds: dsEntries.length,
      ms: Math.round(t1 - t0),
    })
    return grid
  }, [deferredTripleList, deferredDsList])

  const chartTotals = calculateGridTotals(chartGrid)
  const chartGrandTotal = Object.values(chartTotals).reduce((sum, v) => sum + v, 0)

  // Apply percentage adjustments (must be before chartPriceMap which references it)
  const adjustedChartGrid: GridData = useMemo(() => {
    const grid: GridData = {}
    for (let i = 1; i <= 10; i++) {
      grid[i] = (chartGrid[i] || []).map(entry => {
        let price = entry.price
        if (chartAppliedPct.less > 0) price = Math.round(price * (1 - chartAppliedPct.less / 100))
        if (chartAppliedPct.add > 0) price = Math.round(price * (1 + chartAppliedPct.add / 100))
        return { number: entry.number, price }
      })
    }
    return grid
  }, [chartGrid, chartAppliedPct])

  // NOTE: adjustedGrandTotal is defined below (after displayColTotals) to account for
  // both Less%/Add% AND per-column deduct/add. Do not redeclare here.

  // Build price map from adjustedChartGrid (only triple/3-digit entries)
  // Memoized to avoid recomputing on every chart operation (download/share)
  const chartPriceMap = useMemo(() => {
    const priceMap: { [panna: string]: number } = {}
    for (let pos = 1; pos <= 10; pos++) {
      for (const entry of (adjustedChartGrid[pos] || [])) {
        if (entry.number.length === 3) {
          if (chartHideShared && chartMarkedShared.has(entry.number)) continue
          priceMap[entry.number] = (priceMap[entry.number] || 0) + entry.price
        }
      }
    }
    return priceMap
  }, [adjustedChartGrid, chartHideShared, chartMarkedShared])

  // Compute filtered chart grid based on chartFilter
  const filteredPositions = useMemo(() => {
    const f = chartFilter
    if (f === 'all') return [1,2,3,4,5,6,7,8,9,10]
    if (f.startsWith('top')) {
      const n = parseInt(f.replace('top', ''))
      // Sort positions by total descending, take top N
      return Object.entries(chartTotals)
        .sort(([,a],[,b]) => b - a)
        .slice(0, n)
        .map(([k]) => parseInt(k))
    }
    if (f.startsWith('col') && f.includes('-')) {
      const [start, end] = f.replace('col', '').split('-').map(Number)
      const positions: number[] = []
      for (let i = start; i <= end; i++) positions.push(i)
      return positions
    }
    if (f.startsWith('col')) {
      const n = parseInt(f.replace('col', ''))
      return [n]
    }
    return [1,2,3,4,5,6,7,8,9,10]
  }, [chartFilter, chartTotals])

  // Triple-only (3-digit panna) totals for the 220 chart
  const tripleChartTotals = useMemo(() => {
    const totals: { [pos: number]: number } = {}
    for (let i = 1; i <= 10; i++) totals[i] = 0
    for (let pos = 1; pos <= 10; pos++) {
      for (const entry of (adjustedChartGrid[pos] || [])) {
        if (entry.number.length === 3) {
          totals[pos] += entry.price
        }
      }
    }
    return totals
  }, [adjustedChartGrid])
  const tripleGrandTotal = Object.values(tripleChartTotals).reduce((sum, v) => sum + v, 0)

  // ── Deduct from Column Total (Super Admin only) ──
  // Apply the uniform deduction to every column total (floored at 0).
  // ANK/cell prices in adjustedChartGrid / chartPriceMap are NEVER touched.
  // These display* values are what the on-screen totals and the exported canvas use.
  const displayColTotals: { [pos: number]: number } = useMemo(() => {
    const out: { [pos: number]: number } = {}
    for (let p = 1; p <= 10; p++) {
      out[p] = Math.max(0, (tripleChartTotals[p] || 0) - chartColDeduction)
    }
    return out
  }, [tripleChartTotals, chartColDeduction])
  const displayGrandTotal = Object.values(displayColTotals).reduce((sum, v) => sum + v, 0)

  // ── Fully-adjusted grand total ──
  // Accounts for BOTH the uniform column deduction AND per-column deduct/add.
  // This is the value shown on-screen and in all exports (download, WhatsApp, clipboard).
  // Previous behavior (grand total ignored per-column adjustments) is superseded.
  const adjustedGrandTotal = useMemo(() => {
    let total = 0
    for (let p = 1; p <= 10; p++) {
      const colBase = Math.max(0, (tripleChartTotals[p] || 0) - chartColDeduction)
      const perColDeduct = chartPerColDeduction[p] || 0
      const perColAdd = chartPerColAdd[p] || 0
      total += Math.max(0, colBase - perColDeduct + perColAdd)
    }
    return total
  }, [tripleChartTotals, chartColDeduction, chartPerColDeduction, chartPerColAdd])

  // TOTAL FOR SINGLE - sum up single inventory entries per position
  const singleTotals = useMemo(() => {
    const totals: { [pos: number]: number } = {}
    for (let i = 1; i <= 10; i++) totals[i] = 0
    const dsEntriesAll = deferredDsList as Array<{ type: string; parsedData: string; details: string }>
    const dsEntries = dsEntriesAll.length > MAX_RENDER_DS ? dsEntriesAll.slice(0, MAX_RENDER_DS) : dsEntriesAll
    for (const de of dsEntries) {
      if (de.type !== 'single') continue
      try {
        const pd = JSON.parse(de.parsedData)
        if (pd.numbers && Array.isArray(pd.numbers)) {
          for (const num of pd.numbers) {
            const n = num as { number: string; price: number }
            const pos = calculateSinglePosition(n.number)
            if (pos >= 1 && pos <= 10) totals[pos] += n.price
          }
        }
      } catch { /* skip */ }
    }
    return totals
  }, [deferredDsList])

  const singleGrandTotal = Object.values(singleTotals).reduce((sum, v) => sum + v, 0)

  // Memoized saved price map for the "Saved Triple Position Grid" section
  // Previously this was an IIFE that recomputed on every render, causing mobile freeze
  const savedTriplePriceMap = useMemo(() => {
    const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now()
    const priceMap: { [panna: string]: number } = {}
    // Render-path cap (v4 fix): only process the most recent MAX_RENDER_TRIPLES entries
    const tripleEntriesCapped = tripleEntries.length > MAX_RENDER_TRIPLES
      ? tripleEntries.slice(0, MAX_RENDER_TRIPLES)
      : tripleEntries
    for (const te of tripleEntriesCapped) {
      try {
        const pd = JSON.parse(te.parsedData)
        if (pd.entries && Array.isArray(pd.entries) && pd.entries.length > 0) {
          for (const entry of pd.entries) {
            const e = entry as { number: string; price: number }
            if (e.number.length === 3) {
              const norm = normalizePanna(e.number)
              priceMap[norm] = (priceMap[norm] || 0) + e.price
            }
          }
        } else if (pd.grid && Object.values(pd.grid).some((arr: unknown) => Array.isArray(arr) && arr.length > 0)) {
          for (let pos = 1; pos <= 10; pos++) {
            if (pd.grid[pos] && Array.isArray(pd.grid[pos])) {
              for (const entry of pd.grid[pos]) {
                const e = entry as { number: string; price: number }
                if (e.number.length === 3) {
                  const norm = normalizePanna(e.number)
                  priceMap[norm] = (priceMap[norm] || 0) + e.price
                }
              }
            }
          }
        } else if (pd.numbers && Array.isArray(pd.numbers) && pd.numbers.length > 0) {
          for (const entry of pd.numbers) {
            const e = entry as { number: string; price: number }
            if (e.number.length === 3) {
              const norm = normalizePanna(e.number)
              priceMap[norm] = (priceMap[norm] || 0) + e.price
            }
          }
        } else if (pd.generatedPannas && Array.isArray(pd.generatedPannas) && pd.generatedPannas.length > 0) {
          const rate = pd.rate || te.rate || 0
          for (const panna of pd.generatedPannas) {
            if (typeof panna === 'string' && panna.length === 3) {
              const norm = normalizePanna(panna)
              priceMap[norm] = (priceMap[norm] || 0) + (rate as number)
            }
          }
        }
      } catch { /* skip unparseable */ }
    }
    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now()
    parserDebug('savedTriplePriceMap useMemo', {
      triples: tripleEntriesCapped.length,
      pannas: Object.keys(priceMap).length,
      ms: Math.round(t1 - t0),
    })
    return priceMap
  }, [deferredTripleList])

  // Memoized saved chart data for the "Triple Position Grid (Saved)" section
  const savedTripleChartData = useMemo(() => {
    if (Object.keys(savedTriplePriceMap).length === 0) return null
    return build220ChartData(savedTriplePriceMap)
  }, [savedTriplePriceMap])

  // Track if chart data is stale (deferred values haven't caught up yet)
  // This is true briefly after a submit, while React processes the heavy useMemo cascade
  const chartIsStale = deferredTripleList !== tripleList || deferredDsList !== dsList

  // ── Early returns AFTER all hooks ──

  if (!viewingInventoryId) {
    return (
      <div className="p-7 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-16 h-16 bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl flex items-center justify-center mb-4">
          <ClipboardList size={28} className="text-[#9CA3AF]" />
        </div>
        <h2 className="font-cinzel text-lg text-[#9CA3AF] mb-2">No Inventory Selected</h2>
        <p className="text-[13px] text-[#9CA3AF] mb-4">Select an inventory from the list to view details</p>
        <GoldButton onClick={() => setCurrentPage('inv-list')}>
          <List size={14} /> Go to Inventory List
        </GoldButton>
      </div>
    )
  }

  if (loading) return (
    <div className="p-7">
      <div className="flex items-center justify-center min-h-[40vh]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-[#3730A3] border-t-transparent rounded-full animate-spin" />
          <span className="text-[13px] text-[#9CA3AF]">Loading inventory...</span>
        </div>
      </div>
    </div>
  )
  if (!inv) return (
    <div className="p-7 flex flex-col items-center justify-center min-h-[60vh]">
      <div className="w-16 h-16 bg-[rgba(220,38,38,0.1)] border border-[rgba(220,38,38,0.3)] rounded-2xl flex items-center justify-center mb-4">
        <AlertTriangle size={28} className="text-[#DC2626]" />
      </div>
      <h2 className="font-cinzel text-lg text-[#DC2626] mb-2">{error || 'Inventory Not Found'}</h2>
      <p className="text-[13px] text-[#9CA3AF] mb-4">{error ? 'An error occurred while loading the inventory' : 'This inventory may have been deleted'}</p>
      <GoldButton onClick={() => setCurrentPage('inv-list')}>
        <List size={14} /> Back to Inventory List
      </GoldButton>
    </div>
  )

  return (
    <div className="p-4 md:p-7 pb-36 md:pb-7 animate-in fade-in duration-300 max-w-[1280px] mx-auto">
      {/* ── Entry Header Card (gradient indigo, matches HTML mockup design) ── */}
      <div
        className="mb-4 rounded-xl overflow-hidden relative"
        style={{ background: 'linear-gradient(135deg,#4F46E5 0%,#4338CA 100%)' }}
      >
        {/* Decorative circles */}
        <div
          className="absolute pointer-events-none rounded-full"
          style={{ top: '-30%', right: '-10%', width: 200, height: 200, background: 'rgba(255,255,255,0.06)' }}
        />
        <div
          className="absolute pointer-events-none rounded-full"
          style={{ bottom: '-40%', left: '30%', width: 160, height: 160, background: 'rgba(255,255,255,0.04)' }}
        />
        <div className="relative z-10 p-5 md:p-6 text-white">
          {/* Breadcrumb + Actions */}
          <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
            <nav className="flex items-center gap-2 text-[12px]">
              <button
                onClick={() => { useAppStore.getState().setViewingInventoryId(null); setCurrentPage('inv-list') }}
                className="flex items-center gap-1 text-indigo-200 hover:text-white transition-colors font-semibold"
              >
                <ChevronLeft size={14} /> Lists Inventory
              </button>
              <span className="text-indigo-300">&raquo;</span>
              <span className="text-white font-semibold">View</span>
            </nav>
            <div className="flex items-center gap-2">
              <button
                onClick={() => openChart('full')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-emerald-500/90 hover:bg-emerald-500 text-white transition-all"
                title="Open Chart (Full Data)"
              >
                <BarChart3 size={13} /> Open Chart
              </button>
              <button
                onClick={() => openChart('blank')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-amber-500/90 hover:bg-amber-500 text-white transition-all"
                title="Open Blank Chart"
              >
                <BarChart3 size={13} /> Blank Chart
              </button>
              <button
                onClick={handleDeleteInventory}
                className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-red-500/90 hover:bg-red-500 text-white transition-all"
                title="Delete Inventory"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>

          {/* Title + Status */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
            <div>
              <h1 className="text-lg md:text-xl font-extrabold leading-tight">View Entry Inventory</h1>
              <p className="text-[12px] text-indigo-200 font-medium mt-0.5">
                Manage single, double &amp; triple inventory for this entry
              </p>
            </div>
            <span
              className={`self-start sm:self-auto inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                inv.status === 'open'
                  ? 'bg-white/20 text-white'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              {inv.status.toUpperCase()}
            </span>
          </div>

          {/* Detail Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Entry ID', value: inv.id.slice(-5).toUpperCase() },
              { label: 'Market', value: inv.inventoryCode.name },
              { label: 'Date', value: formatDate(inv.date) },
              { label: 'Total Amount', value: formatCurrency(inv.totalAmount || inv.totalTxn) },
            ].map(item => (
              <div key={item.label}>
                <div className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">
                  {item.label}
                </div>
                <div className="text-sm font-bold mt-0.5">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Modern Tab Bar ── */}
      <div
        className="flex border-b-2 border-slate-200 bg-white rounded-t-xl overflow-hidden mb-0"
        role="tablist"
      >
        {(['single', 'double', 'triple'] as const).map(t => {
          const isActive = tab === t
          const label = t === 'single' ? 'Single' : t === 'double' ? 'Double (Jodi)' : 'Triple'
          return (
            <button
              key={t}
              role="tab"
              aria-selected={isActive}
              onClick={() => setTab(t)}
              className={`flex-1 px-4 py-3 text-[12px] font-semibold tracking-wide transition-all relative ${
                isActive ? 'text-indigo-600 bg-white' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              {label}
              {isActive && (
                <span
                  className="absolute bottom-[-2px] left-[20%] right-[20%] h-[2px] rounded-full"
                  style={{ background: '#4F46E5' }}
                />
              )}
            </button>
          )
        })}
      </div>
      <div className="bg-white border border-t-0 border-slate-200 rounded-b-xl p-4 md:p-5 mb-4">
        {/* Tab content injected below */}
        {tab === 'triple' && (
          <>
            {/* Add Triple Inventory Section */}
            <SectionCard title="Add Triple Inventory">
            {/* Direct item selector — no "Group" umbrella: every chart type is its
                own item under the Triple section (Mix, Common, SP … Family Chart,
                Half Sangam A/B, Full Sangam). */}
            <div className="mb-4">
              <div className="flex flex-wrap gap-1.5">
                {TRIPLE_DIRECT_ITEMS.map(item => {
                  const active =
                    (item === 'Mix' && tripleMode === 'mix') ||
                    (item === 'Common' && tripleMode === 'common') ||
                    (TRIPLE_GROUP_ITEMS.includes(item) && tripleMode === 'group' && tripleGroupType === item) ||
                    (TRIPLE_SANGAM_ITEMS.includes(item) && tripleMode === 'sangam' && sangamKind === (item as typeof sangamKind))
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => {
                        if (item === 'Mix') setTripleMode('mix')
                        else if (item === 'Common') setTripleMode('common')
                        else if (TRIPLE_GROUP_ITEMS.includes(item)) { setTripleMode('group'); setTripleGroupType(item) }
                        else { setTripleMode('sangam'); setSangamKind(item as typeof sangamKind) }
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-[11.5px] font-semibold border transition-all ${
                        active
                          ? 'bg-[#0284C7] text-white border-[#0284C7] shadow-sm'
                          : 'bg-white text-[#6B7280] border-[#E5E7EB] hover:border-[#0284C7] hover:text-[#0284C7]'
                      }`}
                    >{item}</button>
                  )
                })}
              </div>
            </div>

            {/* ── MIX MODE ── */}
            {tripleMode === 'mix' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <FormField label="Customer">
                    <FormSelect value={vendorId} onChange={e => setVendorId(e.target.value)}>
                      <option value="">&mdash; No Customer &mdash;</option>
                      {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
                    </FormSelect>
                  </FormField>
                  <FormField label="Rate (Mix then 0)">
                    <FormInput
                      type="number"
                      placeholder="Rate"
                      value={rate}
                      onChange={e => setRate(e.target.value)}
                    />
                  </FormField>
                </div>

                <FormField label="Paste Content" className="mb-4">
                  <div className="flex justify-end mb-1">
                    <DictationFormatButton
                      groupSize={3}
                      getValue={() => whatsappContent}
                      onText={setWhatsappContent}
                    />
                  </div>
                  <textarea
                    value={whatsappContent}
                    onChange={e => setWhatsappContent(e.target.value)}
                    onBlur={e => { const f = autoFormatDictation(e.target.value, 3); if (f !== null) setWhatsappContent(f) }}
                    placeholder="Paste WhatsApp content here...&#10;Example:&#10;370=30₹&#10;270=20₹&#10;124*500₹&#10;130*100₹"
                    rows={8}
                    className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] placeholder:text-[#9CA3AF] w-full resize-y font-mono"
                  />
                </FormField>
              </>
            )}

            {/* ── GROUP MODE ── */}
            {tripleMode === 'group' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <FormField label="Customer">
                    <FormSelect value={vendorId} onChange={e => setVendorId(e.target.value)}>
                      <option value="">&mdash; No Customer &mdash;</option>
                      {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
                    </FormSelect>
                  </FormField>
                  <FormField label="Type (pick from the items above)">
                    <div className="h-[38px] flex items-center px-3 rounded-lg border border-[#E5E7EB] bg-[#F8FAFC] text-[13px] font-bold text-[#111827]">
                      {tripleGroupType || '—'}
                    </div>
                  </FormField>
                </div>

                {/* Input Mode Toggle: Single | Batch */}
                <div className="flex gap-1 mb-4 p-1 bg-[#F5F6FA] rounded-lg w-fit">
                  <button
                    type="button"
                    onClick={() => setGroupInputMode('single')}
                    className={`px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all ${
                      groupInputMode === 'single'
                        ? 'bg-[#FFFFFF] text-[#3730A3] shadow-sm'
                        : 'text-[#6B7280] hover:text-[#3730A3]'
                    }`}
                  >
                    Single
                  </button>
                  <button
                    type="button"
                    onClick={() => setGroupInputMode('batch')}
                    className={`px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all ${
                      groupInputMode === 'batch'
                        ? 'bg-[#FFFFFF] text-[#3730A3] shadow-sm'
                        : 'text-[#6B7280] hover:text-[#3730A3]'
                    }`}
                  >
                    Batch
                  </button>
                </div>

                {groupInputMode === 'single' ? (
                  <>
                    {/* Series toggle buttons: 1× through 10× */}
                    <div className="mb-4">
                      <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] mb-2 block">Series</label>
                      <div className="flex flex-wrap gap-2">
                        {[1,2,3,4,5,6,7,8,9,10].map(card => {
                          const isSelected = tripleSeriesCards.has(card)
                          return (
                            <button
                              key={card}
                              type="button"
                              onClick={() => toggleSeriesCard(card)}
                              className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition-all border ${
                                isSelected
                                  ? 'bg-[#0284C7] text-white border-[#0284C7] shadow-[0_2px_8px_rgba(2,132,199,0.3)]'
                                  : 'bg-[#FFFFFF] text-[#6B7280] border-[#E5E7EB] hover:border-[#0284C7] hover:text-[#0284C7]'
                              }`}
                            >
                              {card} ×
                            </button>
                          )
                        })}
                      </div>
                    </div>

                    {/* Select field + Rate/Amount */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <FormField label={(() => {
                        const t = tripleGroupType
                        if (t === 'SP') return 'Select (Ank digits 0-9, each = 12 SP pannas)'
                        if (t === 'DP') return 'Select (Ank digits 0-9, each = 9 DP pannas)'
                        if (t === 'TP') return 'Select (Ank digits 0-9, each = 1 TP panna)'
                        if (t === 'SPDP') return 'Select (Ank digits 0-9, each = 21 SP+DP pannas)'
                        if (t === 'SPTP') return 'Select (Ank digits 0-9, each = 13 SP+TP pannas)'
                        if (t === 'DPTP') return 'Select (Ank digits 0-9, each = 10 DP+TP pannas)'
                        if (t === 'SPDPTP') return 'Select (Ank digits 0-9, each = 22 SP+DP+TP pannas)'
                        if (t === 'Motor Pana') return 'Select (Digits for Motor Pana combinations)'
                        if (t === '50 Chart' || t === '60 Chart' || t === '70 Chart' || t === '90 ABR Chart' || t === '90 DP Chart') return 'Select (Ank digits 0-9, each = one ank column)'
                        if (t === 'Family Set 4' || t === 'Family Set 6' || t === 'Family Set 8') return 'Select (3-digit panna seed)'
                        return 'Select'
                      })()}>
                        <FormInput
                          placeholder={(() => {
                            const t = tripleGroupType
                            if (t === 'SP') return 'Each digit = ank column with 12 SP pannas'
                            if (t === 'DP') return 'Each digit = ank column with 9 DP pannas'
                            if (t === 'TP') return 'Each digit = ank column with 1 TP panna'
                            if (t === 'Motor Pana') return 'Digits for Motor Pana combinations'
                            if (t?.includes('Chart') || t?.includes('Family')) return 'Seed digits or panna reference'
                            return 'Digits auto-filled from Series, or type manually'
                          })()}
                          value={tripleSelect}
                          onChange={e => setTripleSelect(e.target.value)}
                        />
                      </FormField>
                      <div className="flex items-end gap-4">
                        <FormField label="Rate" className="flex-1">
                          <FormInput
                            type="number"
                            placeholder="Rate"
                            value={tripleGroupRate}
                            onChange={e => setTripleGroupRate(e.target.value)}
                          />
                        </FormField>
                        <FormField label="Amount" className="flex-1">
                          <FormInput
                            type="number"
                            placeholder="Amount"
                            value={tripleGroupAmount}
                            onChange={e => setTripleGroupAmount(e.target.value)}
                          />
                        </FormField>
                      </div>
                    </div>

                    {/* Preview group grid - shows generated pannas in correct columns */}
                    {tripleSelect.trim() && tripleGroupType && (() => {
                      const selectDigits = tripleSelect.split('').filter(c => /^\d$/.test(c)).map(Number)
                      const rateVal = parseFloat(tripleGroupRate) || 0
                      const amtVal = parseFloat(tripleGroupAmount) || 0

                      // previewEntries holds { number, price } pairs that reflect the
                      // ACTUAL merged rates (after dedup for Family Set, after
                      // merge-by-sum for SP/DP/TP). Using this — instead of just
                      // `rateVal` per panna — guarantees the preview total matches
                      // the totalAmount that will be stored on submit.
                      let previewEntries: Array<{ number: string; price: number }> = []
                      let previewPannas: string[]
                      if (tripleGroupType === 'Motor Pana') {
                        previewPannas = generateGroupPannas(selectDigits, 'Motor Pana')
                        previewEntries = previewPannas.map(p => ({ number: p, price: rateVal }))
                      } else if (['SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP', 'SP Motor', 'DP Motor'].includes(tripleGroupType)) {
                        previewPannas = generateGroupPannas(selectDigits, tripleGroupType)
                        previewEntries = previewPannas.map(p => ({ number: p, price: rateVal }))
                      } else if (['50 Chart', '60 Chart', '70 Chart', '90 DP Chart', '90 ABR Chart', '20 Chart', '30 Chart', '40 Chart'].includes(tripleGroupType)) {
                        // Chart types: each digit in Select is an ank reference
                        previewPannas = generateGroupPannas(selectDigits, tripleGroupType)
                        previewEntries = previewPannas.map(p => ({ number: p, price: rateVal }))
                      } else if (['Family Set 4', 'Family Set 6', 'Family Set 8', 'Family Chart'].includes(tripleGroupType)) {
                        // Family types: the whole Select string is a seed (3-digit panna)
                        // Use buildGroupBatch so the preview matches the submit path exactly,
                        // including the family-key dedup that prevents double-counting when
                        // two seeds resolve to the same family (e.g. "123 128" both → family 123).
                        const seedStr = tripleSelect.trim()
                        const option = tripleGroupType as GroupOption
                        try {
                          const batchResult = buildGroupBatch(option, seedStr, { rate: rateVal })
                          previewEntries = getMergedEntries(batchResult)
                          previewPannas = previewEntries.map(e => e.number)
                        } catch {
                          previewPannas = []
                          previewEntries = []
                        }
                      } else {
                        previewPannas = []
                        previewEntries = []
                      }

                      // gridTotal = sum of all merged rates (matches what submit stores)
                      const gridTotal = previewEntries.reduce((s, e) => s + e.price, 0)
                      const total = amtVal > 0 ? amtVal : gridTotal
                      const previewGrid: GridData = {}
                      for (let i = 1; i <= 10; i++) previewGrid[i] = []
                      for (const entry of previewEntries) {
                        const pos = calculateTriplePosition(entry.number)
                        if (pos >= 1 && pos <= 10) {
                          previewGrid[pos].push({ number: entry.number, price: entry.price })
                        }
                      }
                      return (
                        <div className="mb-4">
                          <div className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] mb-3">
                            Group Preview &mdash; {tripleGroupType} ({previewPannas.length} pannas{['SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP', 'SP Motor', 'DP Motor'].includes(tripleGroupType) ? `, ${selectDigits.length} ank × ${tripleGroupType === 'SP' ? '12 SP' : tripleGroupType === 'DP' ? '9 DP' : tripleGroupType === 'TP' ? '1 TP' : 'pannas'}` : ''})
                          </div>
                          {/* Show per-ank breakdown for SP type */}
                          {tripleGroupType === 'SP' && (
                            <div className="mb-3 space-y-1">
                              {[...selectDigits].sort((a, b) => a - b).map(digit => {
                                const ankPannas = generateSPByAnk([digit])
                                return (
                                  <div key={digit} className="text-[11px]">
                                    <span className="text-[#0284C7] font-mono font-bold">Ank {digit}</span>
                                    <span className="text-[#9CA3AF] mx-1">&rarr;</span>
                                    <span className="text-[#111827] font-mono">[{ankPannas.join(', ')}]</span>
                                    <span className="text-[#D97706] ml-2">({ankPannas.length} pannas)</span>
                                  </div>
                                )
                              })}
                            </div>
                          )}
                          <div className="overflow-x-auto">
                            <table className="w-full text-[13px] border border-[#E5E7EB] rounded-lg overflow-hidden">
                              <thead>
                                <tr className="bg-[#F5F6FA]">
                                  {[1,2,3,4,5,6,7,8,9,10].map(n => (
                                    <th key={n} className="px-2 py-2 text-center text-[12px] font-bold text-[#0284C7] border-r border-[#E5E7EB] last:border-r-0 min-w-[80px]">{n}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                                    <td key={pos} className="px-2 py-2 align-top border-r border-[#E5E7EB] last:border-r-0 bg-[#FFFFFF] min-h-[60px]">
                                      {previewGrid[pos]?.map((entry, idx) => (
                                        <div key={idx} className="text-[11px] mb-1">
                                          <span className="text-[#111827] font-mono">{entry.number}</span>
                                          {entry.price > 0 && <span className="text-[#D97706] ml-1">= {entry.price}₹</span>}
                                        </div>
                                      ))}
                                      {(!previewGrid[pos] || previewGrid[pos].length === 0) && (
                                        <span className="text-[#9CA3AF] text-[10px]">-</span>
                                      )}
                                    </td>
                                  ))}
                                </tr>
                                <tr className="bg-[#F5F6FA]">
                                  {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                                    <td key={pos} className="px-2 py-2 text-center text-[12px] font-bold text-[#D97706] border-r border-[#E5E7EB] last:border-r-0 font-mono">
                                      {(previewGrid[pos] || []).reduce((sum, e) => sum + e.price, 0)}₹
                                    </td>
                                  ))}
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div className="mt-3 flex items-center gap-4 text-[13px]">
                            <span className="text-[#9CA3AF]">Total Pannas: {previewPannas.length}</span>
                            <span className="text-[#D97706] font-mono font-bold text-[16px]">₹ {total.toLocaleString('en-IN')}</span>
                          </div>
                        </div>
                      )
                    })()}
                  </>
                ) : (
                  <>
                    {/* Batch Mode: textarea + Rate/Amount */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <FormField label="Rate (default for seeds without rate)" className="flex-1">
                        <FormInput
                          type="number"
                          placeholder="Rate"
                          value={tripleGroupRate}
                          onChange={e => setTripleGroupRate(e.target.value)}
                        />
                      </FormField>
                      <FormField label="Amount (override total)" className="flex-1">
                        <FormInput
                          type="number"
                          placeholder="Amount"
                          value={tripleGroupAmount}
                          onChange={e => setTripleGroupAmount(e.target.value)}
                        />
                      </FormField>
                    </div>

                    <FormField label="Paste Content" className="mb-4">
                      <div className="flex justify-end mb-1">
                        <DictationFormatButton
                          groupSize={null}
                          getValue={() => groupInputContent}
                          onText={setGroupInputContent}
                        />
                      </div>
                      <textarea
                        value={groupInputContent}
                        onChange={e => setGroupInputContent(e.target.value)}
                        onBlur={e => { const f = autoFormatDictation(e.target.value, null); if (f !== null) setGroupInputContent(f) }}
                        placeholder={"Paste WhatsApp content here....\nExample (Motor):\nSpdpmo\n12489=50₹\n14679=30₹\n\nExample (SP):\n5=50₹\n3=30₹\n128=20₹"}
                        rows={8}
                        className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] placeholder:text-[#9CA3AF] w-full resize-y font-mono"
                      />
                    </FormField>

                    {/* Live preview of parsed seeds */}
                    {groupInputContent.trim() && tripleGroupType && (() => {
                      const defaultRate = parseFloat(tripleGroupRate) || 0
                      try {
                        const parsed = parseWhatsAppContentFull(groupInputContent, 'group', defaultRate)
                        const validSeeds = parsed.entries.filter(e => !e.skipped)
                        const skippedSeeds = parsed.entries.filter(e => e.skipped)
                        return (
                          <div className="mb-4">
                            <div className="flex flex-wrap gap-2 mb-2">
                              {validSeeds.length > 0 && (
                                <span className="text-[11px] px-2 py-1 rounded-full bg-[rgba(5,150,105,0.1)] text-[#059669] font-semibold">
                                  ✓ {validSeeds.length} valid seed{validSeeds.length !== 1 ? 's' : ''}
                                </span>
                              )}
                              {skippedSeeds.length > 0 && (
                                <span className="text-[11px] px-2 py-1 rounded-full bg-[rgba(217,119,6,0.1)] text-[#D97706] font-semibold">
                                  ⚠ {skippedSeeds.length} skipped
                                </span>
                              )}
                              {parsed.droppedTokens.length > 0 && (
                                <span className="text-[11px] px-2 py-1 rounded-full bg-[rgba(220,38,38,0.1)] text-[#DC2626] font-semibold">
                                  ✗ {parsed.droppedTokens.length} invalid
                                </span>
                              )}
                            </div>
                            {validSeeds.length > 0 && (
                              <div className="flex flex-wrap gap-1.5">
                                {validSeeds.map((s, i) => (
                                  <span key={i} className="text-[11px] px-2 py-0.5 rounded-full bg-[rgba(5,150,105,0.1)] text-[#059669] font-mono">
                                    {s.number}={s.price}₹
                                  </span>
                                ))}
                              </div>
                            )}
                            {skippedSeeds.length > 0 && (
                              <div className="mt-2 p-2 rounded-lg bg-[rgba(217,119,6,0.05)] border border-[rgba(217,119,6,0.2)]">
                                <div className="text-[10px] font-semibold text-[#D97706] mb-1">Skipped (no rate):</div>
                                <div className="flex flex-wrap gap-1">
                                  {skippedSeeds.map((s, i) => (
                                    <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-[rgba(217,119,6,0.1)] text-[#D97706] font-mono">{s.number}</span>
                                  ))}
                                </div>
                              </div>
                            )}
                            {parsed.droppedTokens.length > 0 && (
                              <div className="mt-2 p-2 rounded-lg bg-[rgba(220,38,38,0.05)] border border-[rgba(220,38,38,0.2)]">
                                <div className="text-[10px] font-semibold text-[#DC2626] mb-1">Invalid tokens:</div>
                                <div className="flex flex-wrap gap-1">
                                  {parsed.droppedTokens.slice(0, 10).map((t, i) => (
                                    <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-[rgba(220,38,38,0.1)] text-[#DC2626] font-mono">&ldquo;{t}&rdquo;</span>
                                  ))}
                                  {parsed.droppedTokens.length > 10 && (
                                    <span className="text-[10px] text-[#9CA3AF]">+{parsed.droppedTokens.length - 10} more</span>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        )
                      } catch {
                        return <div className="text-[11px] text-[#DC2626] mb-4">Parser error &mdash; input too complex</div>
                      }
                    })()}
                  </>
                )}
              </>
            )}

            {/* ── SANGAM MODES (Half Sangam A / Half Sangam B / Full Sangam) ── */}
            {tripleMode === 'sangam' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <FormField label="Customer">
                    <FormSelect value={vendorId} onChange={e => setVendorId(e.target.value)}>
                      <option value="">&mdash; No Customer &mdash;</option>
                      {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
                    </FormSelect>
                  </FormField>
                  <FormField label="Type">
                    <div className="h-[38px] flex items-center px-3 rounded-lg border border-[#E5E7EB] bg-[#F8FAFC] text-[13px] font-bold text-[#111827]">
                      {sangamKind}
                    </div>
                  </FormField>
                </div>

                <div className="flex gap-1 mb-4 p-1 bg-[#F5F6FA] rounded-lg w-fit">
                  <button type="button" onClick={() => setSangamInputMode('single')}
                    className={`px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all ${sangamInputMode === 'single' ? 'bg-[#FFFFFF] text-[#3730A3] shadow-sm' : 'text-[#6B7280] hover:text-[#3730A3]'}`}>Single</button>
                  <button type="button" onClick={() => setSangamInputMode('batch')}
                    className={`px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all ${sangamInputMode === 'batch' ? 'bg-[#FFFFFF] text-[#3730A3] shadow-sm' : 'text-[#6B7280] hover:text-[#3730A3]'}`}>Batch</button>
                </div>

                {sangamInputMode === 'single' ? (
                  <>
                    <div className="text-[11.5px] text-[#6B7280] mb-3 bg-[#F8FAFC] border border-[#E5E7EB] rounded-lg px-3 py-2">
                      {sangamKind === 'Half Sangam A' && <>Half Sangam A = <b>Open digit + Close panna</b> — wins when the open digit and the declared close panna both match (e.g. 1-347).</>}
                      {sangamKind === 'Half Sangam B' && <>Half Sangam B = <b>Open panna + Close digit</b> — wins when the declared open panna and the close digit both match (e.g. 137-1).</>}
                      {sangamKind === 'Full Sangam' && <>Full Sangam = <b>Open panna + Close panna</b> — wins when both declared pannas match (e.g. 137-347).</>}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                      {(sangamKind === 'Half Sangam A') ? (
                        <>
                          <FormField label="Open Digit (1)"><FormInput maxLength={1} placeholder="e.g. 1" value={sangamOpenDigit} onChange={e => setSangamOpenDigit(e.target.value.replace(/\D/g, ''))} /></FormField>
                          <FormField label="Close Panna (3)"><FormInput maxLength={3} placeholder="e.g. 347" value={sangamClosePanna} onChange={e => setSangamClosePanna(e.target.value.replace(/\D/g, ''))} /></FormField>
                        </>
                      ) : null}
                      {(sangamKind === 'Half Sangam B') ? (
                        <>
                          <FormField label="Open Panna (3)"><FormInput maxLength={3} placeholder="e.g. 137" value={sangamOpenPanna} onChange={e => setSangamOpenPanna(e.target.value.replace(/\D/g, ''))} /></FormField>
                          <FormField label="Close Digit (1)"><FormInput maxLength={1} placeholder="e.g. 1" value={sangamCloseDigit} onChange={e => setSangamCloseDigit(e.target.value.replace(/\D/g, ''))} /></FormField>
                        </>
                      ) : null}
                      {(sangamKind === 'Full Sangam') ? (
                        <>
                          <FormField label="Open Panna (3)"><FormInput maxLength={3} placeholder="e.g. 137" value={sangamOpenPanna} onChange={e => setSangamOpenPanna(e.target.value.replace(/\D/g, ''))} /></FormField>
                          <FormField label="Close Panna (3)"><FormInput maxLength={3} placeholder="e.g. 347" value={sangamClosePanna} onChange={e => setSangamClosePanna(e.target.value.replace(/\D/g, ''))} /></FormField>
                        </>
                      ) : null}
                      <FormField label="Points (₹)"><FormInput type="number" placeholder="e.g. 100" value={sangamPoints} onChange={e => setSangamPoints(e.target.value.replace(/\D/g, ''))} /></FormField>
                    </div>
                    {(() => {
                      const num = sangamKind === 'Half Sangam A'
                        ? (sangamOpenDigit && sangamClosePanna ? `${sangamOpenDigit}-${sangamClosePanna}` : '')
                        : sangamKind === 'Half Sangam B'
                          ? (sangamOpenPanna && sangamCloseDigit ? `${sangamOpenPanna}-${sangamCloseDigit}` : '')
                          : (sangamOpenPanna && sangamClosePanna ? `${sangamOpenPanna}-${sangamClosePanna}` : '')
                      const lbl = sangamKind === 'Half Sangam A' ? 'HS-A' : sangamKind === 'Half Sangam B' ? 'HS-B' : 'FS'
                      return num ? (
                        <div className="mb-4 flex items-center gap-2 text-[12px]">
                          <span className="text-[#6B7280] font-semibold">Entry:</span>
                          <span className="font-mono font-bold bg-[#EFF6FF] text-[#1D4ED8] rounded px-2 py-1">{lbl} {num}</span>
                          {sangamPoints ? <span className="font-mono text-[#B45309] font-bold">× {sangamPoints}₹</span> : null}
                        </div>
                      ) : null
                    })()}
                  </>
                ) : (
                  <>
                    <FormField label="Batch Content — one entry per line: X-PPP=points" className="mb-4">
                      <textarea
                        value={sangamBatchContent}
                        onChange={e => setSangamBatchContent(e.target.value)}
                        placeholder={sangamKind === 'Half Sangam A'
                          ? '1-347=100\n7-128=50'
                          : sangamKind === 'Half Sangam B'
                            ? '137-1=100\n380-7=50'
                            : '137-347=100\n128-246=50'}
                        rows={7}
                        className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] placeholder:text-[#9CA3AF] w-full resize-y font-mono"
                      />
                    </FormField>
                    <p className="text-[11px] text-[#6B7280] mb-4">
                      {sangamKind === 'Half Sangam A' && 'Format: open digit + close panna = points (X-PPP=pts)'}
                      {sangamKind === 'Half Sangam B' && 'Format: open panna + close digit = points (PPP-X=pts)'}
                      {sangamKind === 'Full Sangam' && 'Format: open panna + close panna = points (PPP-QQQ=pts)'}
                    </p>
                  </>
                )}
              </>
            )}
            {/* ── COMMON MODE ── */}
            {tripleMode === 'common' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <FormField label="Customer">
                    <FormSelect value={vendorId} onChange={e => setVendorId(e.target.value)}>
                      <option value="">&mdash; No Customer &mdash;</option>
                      {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
                    </FormSelect>
                  </FormField>
                  <FormField label="Rate (Mix then 0)">
                    <FormInput
                      type="number"
                      placeholder="Rate (Mix then 0)"
                      value={tripleCommonRate}
                      onChange={e => setTripleCommonRate(e.target.value)}
                    />
                  </FormField>
                  <FormField label="Amount">
                    <FormInput
                      type="number"
                      placeholder="Amount"
                      value={tripleCommonAmount}
                      onChange={e => setTripleCommonAmount(e.target.value)}
                    />
                  </FormField>
                </div>

                {/* Input Mode Toggle: Single | Batch (bulk paste) */}
                <div className="flex gap-1 mb-4 p-1 bg-[#F5F6FA] rounded-lg w-fit">
                  <button
                    type="button"
                    onClick={() => setCommonInputMode('single')}
                    className={`px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all ${
                      commonInputMode === 'single'
                        ? 'bg-[#FFFFFF] text-[#3730A3] shadow-sm'
                        : 'text-[#6B7280] hover:text-[#3730A3]'
                    }`}
                  >
                    Single
                  </button>
                  <button
                    type="button"
                    onClick={() => setCommonInputMode('batch')}
                    className={`px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all ${
                      commonInputMode === 'batch'
                        ? 'bg-[#FFFFFF] text-[#3730A3] shadow-sm'
                        : 'text-[#6B7280] hover:text-[#3730A3]'
                    }`}
                  >
                    Batch
                  </button>
                </div>

                {commonInputMode === 'single' ? (
                  <FormField label="Series (2-digit numbers 00-99)">
                    <FormInput
                      placeholder="Enter 00,10,11,12,13,14,15"
                      value={tripleCommonSeries}
                      onChange={e => setTripleCommonSeries(e.target.value)}
                    />
                  </FormField>
                ) : (
                  <div className="mb-4">
                    <label className="block text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF] mb-1">
                      Batch Series Content (bulk paste)
                    </label>
                    <textarea
                      value={commonBatchContent}
                      onChange={e => setCommonBatchContent(e.target.value)}
                      placeholder={"One line per group:\n00,10,11,12 = 100\n13,14,15 = 200\n16 17 18\n(use the Rate field above for lines without a rate)"}
                      rows={5}
                      className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-[13px] text-slate-900 outline-none transition-all focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 placeholder:text-slate-400 w-full resize-y font-mono"
                    />
                    <p className="text-[11px] text-[#9CA3AF] mt-1">
                      Each line: series numbers (00-99) separated by comma/space, optionally followed by <span className="font-mono">= rate</span>. Lines without a rate use the Rate field. Each series expands to its 10-panna family.
                    </p>
                  </div>
                )}

                {/* Preview common grid — shows pannas mapped from series numbers.
                    Works for BOTH input modes: resolves the series list + per-series
                    rates the same way the submit handler does, so the preview total
                    always matches what gets stored. */}
                {(() => {
                  // Resolve series + rates from the active input mode
                  let seriesNums: string[] = []
                  const seriesRateMap: Record<string, number> = {}
                  const rateVal = parseFloat(tripleCommonRate) || 0
                  if (commonInputMode === 'batch') {
                    if (commonBatchContent.trim()) {
                      const lines = commonBatchContent.split('\n').map(l => l.trim()).filter(l => l.length > 0)
                      for (const line of lines) {
                        let workLine = line
                        const hm = workLine.match(WA_HEADER_RE)
                        if (hm) workLine = (hm[2] || '').trim()
                        if (!workLine || /^total/i.test(workLine) || /^[=\-+_*#]{3,}$/.test(workLine)) continue
                        const eqSplit = workLine.split(/[=:]\s*|\s+-\s+/)
                        const seriesPart = eqSplit[0] || ''
                        let lineRate = rateVal
                        if (eqSplit.length >= 2) {
                          const r = parseInt((eqSplit[1] || '').replace(/[^\d]/g, ''), 10)
                          if (!isNaN(r) && r > 0) lineRate = r
                        }
                        const tokens = seriesPart.split(/[\s,;.\-+/]+/).map(t => t.trim()).filter(t => /^\d{1,2}$/.test(t))
                        for (const tok of tokens) {
                          const padded = tok.padStart(2, '0')
                          if (!seriesNums.includes(padded)) seriesNums.push(padded)
                          seriesRateMap[padded] = lineRate
                        }
                      }
                    }
                  } else if (tripleCommonSeries.trim()) {
                    seriesNums = tripleCommonSeries.split(',').map(s => s.trim()).filter(s => /^\d{1,2}$/.test(s))
                  }
                  if (seriesNums.length === 0) return null
                  const amtVal = parseFloat(tripleCommonAmount) || 0
                  // Generate pannas for each series with per-series rates
                  const allEntries: Array<{ number: string; price: number }> = []
                  const seriesPannaMap: Record<string, string[]> = {}
                  for (const series of seriesNums) {
                    const paddedSeries = series.padStart(2, '0')
                    const pannas = generateCommonPannas(paddedSeries)
                    seriesPannaMap[paddedSeries] = pannas
                    const seriesRate = commonInputMode === 'batch' ? (seriesRateMap[paddedSeries] ?? rateVal) : rateVal
                    for (const p of pannas) {
                      allEntries.push({ number: p, price: seriesRate })
                    }
                  }
                  // Build preview grid from generated pannas
                  const previewGrid: GridData = {}
                  for (let i = 1; i <= 10; i++) previewGrid[i] = []
                  for (const entry of allEntries) {
                    const pos = calculateTriplePosition(entry.number)
                    if (pos >= 1 && pos <= 10) {
                      previewGrid[pos].push(entry)
                    }
                  }
                  const gridTotal = allEntries.reduce((s, e) => s + e.price, 0)
                  const total = amtVal > 0 ? amtVal : gridTotal
                  return (
                    <div className="mb-4">
                      <div className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] mb-3">
                        Common Preview {commonInputMode === 'batch' ? '(Batch) ' : ''}&mdash; {seriesNums.length} series &times; 10 pannas each = {allEntries.length} pannas
                      </div>
                      {/* Show series-to-panna mapping */}
                      <div className="mb-3 space-y-1">
                        {seriesNums.map(series => {
                          const padded = series.padStart(2, '0')
                          const pannas = seriesPannaMap[padded] || []
                          return (
                            <div key={padded} className="text-[11px]">
                              <span className="text-[#0284C7] font-mono font-bold">{padded}</span>
                              {commonInputMode === 'batch' && seriesRateMap[padded] > 0 && (
                                <span className="text-[#D97706] ml-1.5 font-mono">@{seriesRateMap[padded]}₹</span>
                              )}
                              <span className="text-[#9CA3AF] mx-1">&rarr;</span>
                              <span className="text-[#111827] font-mono">[{pannas.join(', ')}]</span>
                            </div>
                          )
                        })}
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-[13px] border border-[#E5E7EB] rounded-lg overflow-hidden">
                          <thead>
                            <tr className="bg-[#FFFFFF]">
                              {[1,2,3,4,5,6,7,8,9,10].map(n => (
                                <th key={n} className="px-2 py-2 text-center text-[12px] font-bold text-[#0284C7] border-r border-[#E5E7EB] last:border-r-0 min-w-[80px]">{n}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                                <td key={pos} className="px-2 py-2 align-top border-r border-[#E5E7EB] last:border-r-0 bg-[#FFFFFF] min-h-[60px]">
                                  {previewGrid[pos]?.map((entry, idx) => (
                                    <div key={idx} className="text-[11px] mb-1">
                                      <span className="text-[#111827] font-mono">{entry.number}</span>
                                      {entry.price > 0 && <span className="text-[#3730A3] ml-1">={entry.price}₹</span>}
                                    </div>
                                  ))}
                                  {(!previewGrid[pos] || previewGrid[pos].length === 0) && (
                                    <span className="text-[#9CA3AF] text-[10px]">-</span>
                                  )}
                                </td>
                              ))}
                            </tr>
                            <tr className="bg-[#FFFFFF]">
                              {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                                <td key={pos} className="px-2 py-2 text-center text-[12px] font-bold text-[#3730A3] border-r border-[#E5E7EB] last:border-r-0 font-mono">
                                  {(previewGrid[pos] || []).reduce((sum, e) => sum + e.price, 0)}₹
                                </td>
                              ))}
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-3 flex items-center gap-4 text-[13px]">
                        <span className="text-[#9CA3AF]">Total Pannas: {allEntries.length}</span>
                        <span className="text-[#3730A3] font-mono font-bold text-[16px]">₹ {total.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  )
                })()}
              </>
            )}

            {message && (
              <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('success') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>
                {message}
              </div>
            )}

            <div className="flex gap-2.5">
              <BlueButton onClick={handleSubmitTriple} disabled={submitting || (tripleMode === 'mix' && !whatsappContent.trim()) || (tripleMode === 'group' && ((groupInputMode === 'single' && (!tripleSelect.trim() || !tripleGroupType)) || (groupInputMode === 'batch' && (!groupInputContent.trim() || !tripleGroupType)))) || (tripleMode === 'common' && ((commonInputMode === 'single' && !tripleCommonSeries.trim()) || (commonInputMode === 'batch' && !commonBatchContent.trim()))) || (tripleMode === 'sangam' && ((sangamInputMode === 'single' && !sangamPoints.trim()) || (sangamInputMode === 'batch' && !sangamBatchContent.trim())))}>
                <Check size={14} /> Submit
              </BlueButton>
              <OutlineButton onClick={handleResetTriple}>
                <RotateCcw size={14} /> Reset
              </OutlineButton>
            </div>
          </SectionCard>

          {/* Saved Triple Position Grid */}
          {savedTripleChartData && (() => {
            const { rows, colTotals, grandTotal, totalEntries } = savedTripleChartData

            return (
              <SectionCard title="Triple Position Grid (Saved)" headerRight={
                chartIsStale ? <span className="text-[11px] text-[#D97706] animate-pulse">Updating chart...</span> : undefined
              }>
                <div className="overflow-x-auto">
                  <table className="w-full text-[13px] border border-[#E5E7EB] rounded-lg overflow-hidden">
                    <thead>
                      <tr className="bg-[#FFFFFF]">
                        {[1,2,3,4,5,6,7,8,9,10].map(n => (
                          <th key={n} className="px-2 py-2 text-center text-[12px] font-bold text-[#0284C7] border-r border-[#E5E7EB] last:border-r-0 min-w-[85px]">{n}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((rowData, rowIdx) => {
                        const rowHasData = rowData.some(cell => cell.panna && cell.price !== undefined)
                        if (!rowHasData) return null
                        const isTypeSeparator = rowIdx === 12 || rowIdx === 13

                        return (
                          <React.Fragment key={rowIdx}>
                            {isTypeSeparator && rowHasData && (
                              <tr>
                                <td colSpan={10} className="px-2 py-0.5 bg-[#F5F6FA] border-r border-[#E5E7EB]">
                                  <span className="text-[9px] font-bold uppercase tracking-widest text-[#9CA3AF]">
                                    {rowIdx === 12 ? '── TP ──' : '── DP ──'}
                                  </span>
                                </td>
                              </tr>
                            )}
                            <tr className={rowIdx % 2 === 0 ? 'bg-[#FFFFFF]' : 'bg-[#F5F6FA]'}>
                              {rowData.map((cell, colIdx) => {
                                if (!cell.panna) return <td key={colIdx} className="px-2 py-1 border-r border-[#E5E7EB] last:border-r-0" />
                                if (cell.price === undefined) {
                                  return <td key={colIdx} className="px-2 py-1 border-r border-[#E5E7EB] last:border-r-0" />
                                }
                                return (
                                  <td key={colIdx} className="px-2 py-1 border-r border-[#E5E7EB] last:border-r-0 bg-[rgba(55,48,163,0.04)]">
                                    <div className="text-[11px] leading-tight">
                                      <span className="font-mono text-[#111827] font-semibold">{cell.panna}</span>
                                      <span className="text-[#3730A3] ml-1 font-mono">={cell.price}₹</span>
                                    </div>
                                  </td>
                                )
                              })}
                            </tr>
                          </React.Fragment>
                        )
                      })}
                      <tr className="bg-[#FFFFFF]">
                        {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                          <td key={pos} className="px-2 py-2 text-center text-[12px] font-bold text-[#3730A3] border-r border-[#E5E7EB] last:border-r-0 font-mono">
                            {colTotals[pos] || 0}₹
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="mt-3 flex items-center gap-4 text-[13px]">
                  <span className="text-[#9CA3AF]">Grand Total:</span>
                  <span className="text-[#0284C7] font-mono font-bold text-[16px]">₹ {grandTotal.toLocaleString('en-IN')}</span>
                  <span className="text-[#9CA3AF] ml-4">Entries: {totalEntries}</span>
                </div>
              </SectionCard>
            )
          })()}

          {/* List Triple Inventory Table */}
          <SectionCard title="List Triple Inventory">
            <div className="overflow-x-auto -mx-5 -mb-5">
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                    {['Sr. No.', 'ID', 'Customer', 'Type', 'Details', 'Qty', 'Rate', 'Total Amount', 'Option'].map(h => (
                      <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tripleList.length === 0 ? (
                    <tr><td colSpan={9} className="text-center py-8 text-[#9CA3AF]">No triple inventory entries</td></tr>
                  ) : tripleList.map((ti, i) => {
                    const item = ti as {
                      id: string; type: string; details: string; parsedData: string; rate: number; totalAmount: number;
                      vendor: { businessName: string } | null; vendorId: string | null;
                      isUpdated?: boolean; updatedBy?: string | null;
                    }
                    // Parse extra info from parsedData
                    // We build a rich detailDisplay that includes the seed, panna
                    // count, and the FULL list of generated pannas (with rates).
                    // The cell below uses whitespace-normal + break-words so long
                    // content wraps instead of being truncated.
                    let detailDisplay = item.details || ''
                    let fullPannaList = ''
                    let qtyDisplay = '-'
                    let typeColor = 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]'
                    let isAppRow = false
                    try {
                      const pd = JSON.parse(item.parsedData || '{}')
                      isAppRow = pd.source === 'customer-app'
                      // Build the full panna list with rates for the expandable view.
                      // Consolidated Customer App rows also show WHO bet each number.
                      if (Array.isArray(pd.numbers) && pd.numbers.length > 0) {
                        fullPannaList = pd.numbers
                          .map((n: { number: string; price: number }) =>
                            withCustomerBreakdown(`${canonicalPanna(n.number)}@${n.price}`, n.number, pd.byCustomer))
                          .join('  ')
                      } else if (Array.isArray(pd.generatedPannas) && pd.generatedPannas.length > 0) {
                        fullPannaList = pd.generatedPannas.map((g: string) => canonicalPanna(g)).join('  ')
                      }
                      if (item.type === 'group' && (pd.select || pd.generatedPannas)) {
                        const pannaCount = pd.generatedPannas ? pd.generatedPannas.length : (pd.numbers ? pd.numbers.length : (pd.select ? pd.select.split(',').filter((s: string) => /^\d+$/.test(s.trim())).length : 0))
                        qtyDisplay = String(pannaCount)
                        typeColor = 'bg-[rgba(217,119,6,0.1)] text-[#D97706]'
                      } else if (item.type === 'common' && pd.series) {
                        // Show total generated pannas (10 per series)
                        const pannaCount = pd.generatedPannas ? pd.generatedPannas.length : (pd.numbers ? pd.numbers.length : pd.series.split(',').filter((s: string) => /^\d+$/.test(s.trim())).length * 10)
                        qtyDisplay = String(pannaCount)
                        typeColor = 'bg-[rgba(5,150,105,0.1)] text-[#059669]'
                      } else if (item.type === 'amount') {
                        qtyDisplay = '-'
                        typeColor = 'bg-[rgba(55,48,163,0.1)] text-[#3730A3]'
                      } else if (item.type === 'mix') {
                        const entries = pd.entries || []
                        qtyDisplay = String(entries.length)
                        typeColor = 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]'
                      }
                    } catch { /* use defaults */ }
                    return (
                      <tr key={item.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)] transition-colors align-top">
                        <td className="px-3.5 py-3"><span className="bg-[#FFFFFF] border border-[#E5E7EB] rounded px-1.5 py-0.5 font-mono text-[11px] text-[#6B7280]">{i + 1}</span></td>
                        <td className="px-3.5 py-3 font-mono text-[11px] text-[#6B7280]">{item.id.slice(-5).toUpperCase()}</td>
                        <td className="px-3.5 py-3 text-[#6B7280]">{isAppRow
                          ? <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 font-bold border border-sky-200">App</span>
                          : (item.vendor?.businessName || 'Not Assign')}</td>
                        <td className="px-3.5 py-3">
                          <span className={`text-[11px] px-2 py-0.5 rounded-full capitalize font-semibold ${typeColor}`}>{item.type}</span>
                          {item.isUpdated && (
                            <span className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 font-bold border border-amber-200" title={item.updatedBy ? `Edited by ${item.updatedBy}` : 'Entry was edited'}>
                              Updated{item.updatedBy ? ` · ${item.updatedBy}` : ''}
                            </span>
                          )}
                        </td>
                        <td className="px-3.5 py-3 text-[#111827] text-[12px] min-w-[320px] max-w-[640px]">
                          {/* Details line — wraps naturally, no truncation */}
                          <div className="break-words whitespace-normal leading-relaxed">{detailDisplay}</div>
                          {/* Full panna list — shown in a muted monospace block so the
                              user can see the complete submitted data at a glance. */}
                          {fullPannaList && (
                            <div className="mt-1.5 pt-1.5 border-t border-dashed border-[#E5E7EB] font-mono text-[11px] text-[#6B7280] break-words whitespace-normal leading-relaxed">
                              {fullPannaList}
                            </div>
                          )}
                        </td>
                        <td className="px-3.5 py-3 font-mono text-[12px] text-[#6B7280]">{qtyDisplay}</td>
                        <td className="px-3.5 py-3 font-mono text-[12px]">{item.rate}</td>
                        <td className="px-3.5 py-3 font-mono text-[12px] text-[#3730A3]">{formatCurrency(item.totalAmount)}</td>
                        <td className="px-3.5 py-3">
                          <div className="flex items-center gap-2">
                            <button onClick={() => openEditTriple(item)} className="text-[#0284C7] hover:text-indigo-700 text-[12px] font-semibold transition-colors">
                              Edit
                            </button>
                            <button onClick={() => handleDeleteTriple(item.id)} className="text-[#0284C7] hover:text-[#DC2626] text-[12px] font-semibold transition-colors">
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </>
      )}

      {tab === 'single' && (
        <>
            {/* ── SINGLE TAB — modern 2-column layout (form + chart preview) ── */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              {/* Left: Add Single Inventory Form */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200">
                  <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Add Single Inventory</h3>
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Customer</label>
                    <FormSelect value={singleVendorId} onChange={e => setSingleVendorId(e.target.value)}>
                      <option value="">&mdash; No Customer &mdash;</option>
                      {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
                    </FormSelect>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Rate</label>
                      <FormInput
                        type="number"
                        placeholder="Rate"
                        value={singleRate}
                        onChange={e => setSingleRate(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Amount</label>
                      <FormInput
                        type="number"
                        placeholder="Auto-calculated"
                        value={singleAmount}
                        onChange={e => setSingleAmount(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500">Paste Content (Bulk)</label>
                      <DictationFormatButton
                        groupSize={1}
                        getValue={() => dsSelectSingle}
                        onText={handleSingleContentChange}
                      />
                    </div>
                    <textarea
                      value={dsSelectSingle}
                      onChange={e => handleSingleContentChange(e.target.value)}
                      onBlur={e => { const f = autoFormatDictation(e.target.value, 1); if (f !== null) handleSingleContentChange(f) }}
                      placeholder={"Paste WhatsApp content here...\nExample:\n5=50₹\n3=30₹\n7=20₹\n\nOr just digits: 13469"}
                      rows={4}
                      className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-[13px] text-slate-900 outline-none transition-all focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 placeholder:text-slate-400 w-full resize-y font-mono"
                    />
                  </div>
                  <button
                    onClick={handleDsExport}
                    disabled={dsExporting || !dsSelectSingle.trim()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {dsExporting ? 'Processing...' : 'Export / Preview'}
                  </button>

                  {/* Generated Grid (Single Position) — keep existing logic */}
                  {dsGridData && (
                    <div className="mt-2 p-3 rounded-lg bg-indigo-50/40 border border-indigo-100">
                      <div className="text-[11px] font-semibold uppercase tracking-wider text-indigo-700 mb-2">
                        Generated Grid (Single Position)
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-[12px] border border-slate-200 rounded-md overflow-hidden">
                          <thead>
                            <tr className="bg-white">
                              {[1,2,3,4,5,6,7,8,9,10].map(n => (
                                <th key={n} className="px-2 py-1.5 text-center text-[11px] font-bold border-r border-slate-200 last:border-r-0 min-w-[70px] text-indigo-600">{n}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                                <td key={pos} className="px-2 py-1.5 align-top border-r border-slate-200 last:border-r-0 bg-white min-h-[40px]">
                                  {dsGridData[pos]?.map((entry, idx) => (
                                    <div key={idx} className="text-[10px] mb-0.5">
                                      <span className="text-slate-700 font-mono">{entry.number}</span>
                                      <span className="ml-1 text-indigo-600 font-semibold">₹{entry.price}</span>
                                    </div>
                                  ))}
                                  {(!dsGridData[pos] || dsGridData[pos].length === 0) && (
                                    <span className="text-slate-300 text-[10px]">-</span>
                                  )}
                                </td>
                              ))}
                            </tr>
                            <tr className="bg-white">
                              {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                                <td key={pos} className="px-2 py-1.5 text-center text-[11px] font-bold border-r border-slate-200 last:border-r-0 font-mono text-indigo-700">
                                  {(dsGridData[pos] || []).reduce((sum, e) => sum + e.price, 0)}
                                </td>
                              ))}
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-[12px]">
                        <span className="text-slate-500">Total:</span>
                        <span className="font-mono font-bold text-[14px] text-indigo-700">₹ {Object.values(dsGridData).flat().reduce((sum, e) => sum + e.price, 0).toLocaleString('en-IN')}</span>
                      </div>
                      {dsSkippedNumbers.length > 0 && (
                        <div className="mt-2 p-2 rounded border border-amber-200 bg-amber-50 text-[11px]">
                          <span className="text-amber-700 font-semibold">SKIPPED: </span>
                          <span className="text-amber-600 font-mono">{dsSkippedNumbers.join(', ')}</span>
                        </div>
                      )}
                      {dsDroppedTokens.length > 0 && (
                        <div className="mt-2 p-2 rounded border border-red-200 bg-red-50 text-[11px]">
                          <span className="text-red-700 font-semibold">DROPPED: </span>
                          <span className="text-red-500 font-mono">{dsDroppedTokens.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {dsMessage && tab === 'single' && (
                    <div className={`text-[12px] px-3 py-2 rounded-lg ${dsMessage.includes('success') || dsMessage.includes('Submitted') ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>
                      {dsMessage}
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={handleDsSubmit}
                      disabled={dsSubmitting || !dsSelectSingle.trim()}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-semibold bg-gradient-to-r from-indigo-600 to-indigo-500 text-white hover:from-indigo-700 hover:to-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
                    >
                      <Check size={13} /> Submit
                    </button>
                    <button
                      onClick={handleSingleReset}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-semibold border border-slate-300 text-slate-600 hover:border-indigo-400 hover:text-indigo-600 transition-all"
                    >
                      <RotateCcw size={13} /> Reset
                    </button>
                  </div>
                </div>
              </div>

              {/* Right: Single Chart Preview */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                  <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Single Chart</h3>
                  <span className="text-[10px] text-slate-400 font-medium">0-9</span>
                </div>
                <div className="p-4">
                  <BarChartPreview
                    data={Array.from({ length: 10 }, (_, i) => {
                      const digit = i
                      // Sum amounts for entries with this single digit
                      const savedEntries = (dsList as Array<Record<string, unknown>>)
                        .filter(item => item.type === 'single')
                        .flatMap(item => {
                          try {
                            const pd = JSON.parse(item.parsedData as string)
                            return pd.numbers || []
                          } catch { return [] }
                        })
                      const liveEntries = dsParsedEntries.filter(e => /^\d$/.test(e.number) && parseInt(e.number) === digit)
                      const saved = savedEntries.filter((n: { number: string }) => parseInt(n.number) === digit)
                        .reduce((s: number, n: { price: number }) => s + n.price, 0)
                      const live = liveEntries.reduce((s, e) => s + e.price, 0)
                      return { num: String(digit), amt: saved + live }
                    })}
                    emptyLabel="Paste content to see chart"
                  />
                  <div className="mt-4 pt-3 border-t border-slate-100 text-[12px] text-slate-500">
                    <div className="flex justify-between">
                      <span>Numbers count:</span>
                      <span className="font-semibold text-slate-700">
                        {(dsList as Array<Record<string, unknown>>)
                          .filter(item => item.type === 'single')
                          .flatMap(item => {
                            try { return JSON.parse(item.parsedData as string).numbers || [] } catch { return [] }
                          }).length}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Submitted Single Entry Table */}
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden mb-4">
              <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Submitted Single Entry</h3>
                <span className="text-[10px] text-slate-400 font-medium">
                  {(dsList as Array<Record<string, unknown>>).filter(item => item.type === 'single').length} records
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[13px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      {['#', 'Customer', 'Number', 'Amount', 'Time', 'Action'].map(h => (
                        <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-slate-500 whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const singleEntries = (dsList as Array<Record<string, unknown>>).filter(item => item.type === 'single')
                      if (singleEntries.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="text-center py-8 text-slate-400">
                              No single entries submitted yet
                            </td>
                          </tr>
                        )
                      }
                      let idx = 0
                      return singleEntries.flatMap(item => {
                        const typed = item as {
                          id: string; details: string; parsedData: string; rate: number; totalAmount: number;
                          vendor: { businessName: string } | null; createdAt: string
                        }
                        let numbers: Array<{ number: string; price: number }> = []
                        try {
                          const pd = JSON.parse(typed.parsedData)
                          if (pd.numbers && Array.isArray(pd.numbers)) numbers = pd.numbers
                        } catch { /* ignore */ }
                        if (numbers.length === 0) {
                          idx++
                          return [(
                            <tr key={typed.id} className="border-b border-slate-100 hover:bg-indigo-50/40 transition-colors">
                              <td className="px-3.5 py-3"><span className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 font-mono text-[11px] text-slate-500">{idx}</span></td>
                              <td className="px-3.5 py-3 text-slate-700 font-medium">{typed.vendor?.businessName || '—'}</td>
                              <td className="px-3.5 py-3 text-slate-400">—</td>
                              <td className="px-3.5 py-3 font-semibold text-slate-900">₹{typed.totalAmount}</td>
                              <td className="px-3.5 py-3 text-slate-400 text-[11px]">{new Date(typed.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</td>
                              <td className="px-3.5 py-3">
                                <button onClick={() => handleDeleteDs(typed.id)} className="text-red-600 hover:bg-red-50 text-[11px] font-semibold px-2 py-1 rounded transition-colors">Delete</button>
                              </td>
                            </tr>
                          )]
                        }
                        return numbers.map((n, i) => {
                          idx++
                          return (
                            <tr key={typed.id + '-' + i} className="border-b border-slate-100 hover:bg-indigo-50/40 transition-colors">
                              <td className="px-3.5 py-3"><span className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 font-mono text-[11px] text-slate-500">{idx}</span></td>
                              <td className="px-3.5 py-3 text-slate-700 font-medium">{typed.vendor?.businessName || (i === 0 ? '—' : '↑')}</td>
                              <td className="px-3.5 py-3"><span className="font-bold text-indigo-600">{n.number}</span></td>
                              <td className="px-3.5 py-3 font-semibold text-slate-900">₹{n.price}</td>
                              <td className="px-3.5 py-3 text-slate-400 text-[11px]">{i === 0 ? new Date(typed.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : ''}</td>
                              <td className="px-3.5 py-3">
                                {i === 0 && (
                                  <button onClick={() => handleDeleteDs(typed.id)} className="text-red-600 hover:bg-red-50 text-[11px] font-semibold px-2 py-1 rounded transition-colors">Delete</button>
                                )}
                              </td>
                            </tr>
                          )
                        })
                      })
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
        </>
      )}

      {tab === 'double' && (
        <>
            {/* ── DOUBLE TAB — modern 2-column layout (form + chart preview) ── */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              {/* Left: Add Double Inventory Form — modernized */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200">
                  <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Add Double Inventory</h3>
                </div>
                <div className="p-4 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Customer</label>
                      <FormSelect value={doubleVendorId} onChange={e => setDoubleVendorId(e.target.value)}>
                        <option value="">&mdash; No Customer &mdash;</option>
                        {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
                      </FormSelect>
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Series</label>
                      <FormInput
                        type="text"
                        placeholder="Vendor name (optional)"
                        value={doubleSeries}
                        onChange={e => setDoubleSeries(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500">Paste Content (Bulk)</label>
                      <DictationFormatButton
                        groupSize={2}
                        getValue={() => dsSelectDouble}
                        onText={setDsSelectDouble}
                      />
                    </div>
                    <textarea
                      value={dsSelectDouble}
                      onChange={e => setDsSelectDouble(e.target.value)}
                      onBlur={e => { const f = autoFormatDictation(e.target.value, 2); if (f !== null) setDsSelectDouble(f) }}
                      placeholder={"e.g. 41=1100, 23=800, 56=500\n\nOr Milan-style:\nMilan\n23.42.72.82.92.02.\n.....=500rs"}
                      rows={4}
                      className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-[13px] text-slate-900 outline-none transition-all focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 placeholder:text-slate-400 w-full resize-y font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Rate</label>
                      <FormInput
                        type="number"
                        placeholder="Auto-filled from content"
                        value={doubleRate}
                        onChange={e => setDoubleRate(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Amount</label>
                      <FormInput
                        type="number"
                        placeholder="Auto-calculated"
                        value={doubleAmount}
                        onChange={e => setDoubleAmount(e.target.value)}
                      />
                    </div>
                  </div>
                  <button
                    onClick={handleDsExport}
                    disabled={dsExporting || !dsSelectDouble.trim()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {dsExporting ? 'Processing...' : 'Export / Preview'}
                  </button>

                  {/* Generated 10x10 Grid (preview) — modernized */}
                  {dsDoubleGridData && (
                    <div className="mt-2 p-3 rounded-lg bg-amber-50/40 border border-amber-100">
                      <div className="text-[11px] font-semibold uppercase tracking-wider text-amber-700 mb-2">
                        Preview (10×10) — {dsDoubleParsedVendor || 'No Customer'} &middot; Rate: ₹{dsDoubleParsedRate} &middot; Numbers: {dsDoubleParsedNumbers.length}
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-[12px] border border-slate-200 rounded-md overflow-hidden">
                          <thead>
                            <tr className="bg-white">
                              <th className="px-2 py-1.5 text-center text-[10px] font-bold text-slate-400 border-r border-b border-slate-200 min-w-[32px]">#</th>
                              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => (
                                <th key={c} className="px-1 py-1.5 text-center text-[10px] font-bold text-amber-600 border-r border-b border-slate-200 last:border-r-0 min-w-[60px]">{c === 10 ? '0' : c}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {Array.from({ length: 10 }, (_, rowIdx) => {
                              const secondDigit = rowIdx
                              return (
                                <tr key={rowIdx}>
                                  <td className="px-2 py-1.5 text-center text-[10px] font-bold text-amber-600 bg-white border-r border-b border-slate-200">{secondDigit}</td>
                                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => {
                                    const firstDigit = c === 10 ? 0 : c
                                    const num = String(firstDigit * 10 + secondDigit).padStart(2, '0')
                                    const val = dsDoubleGridData[num] || 0
                                    const isVisible = val > 0
                                    return (
                                      <td key={c} className={`px-1 py-1 text-center border-r border-b border-slate-200 last:border-r-0 ${isVisible ? 'bg-amber-50' : 'bg-white'}`}>
                                        {isVisible ? (
                                          <span className="text-[10px] font-mono text-amber-700 font-bold">{val}₹</span>
                                        ) : (
                                          <span className="text-[9px] font-mono text-slate-300">{num}</span>
                                        )}
                                      </td>
                                    )
                                  })}
                                </tr>
                              )
                            })}
                            <tr className="bg-white">
                              <td className="px-2 py-1.5 text-center text-[10px] font-bold text-indigo-700 border-r border-t border-slate-200">TOT</td>
                              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => {
                                const firstDigit = c === 10 ? 0 : c
                                let colTotal = 0
                                for (let row = 0; row < 10; row++) {
                                  const num = String(firstDigit * 10 + row).padStart(2, '0')
                                  colTotal += dsDoubleGridData[num] || 0
                                }
                                return (
                                  <td key={c} className="px-2 py-1.5 text-center text-[10px] font-bold font-mono text-indigo-700 border-r border-t border-slate-200 last:border-r-0">
                                    {colTotal > 0 ? `${colTotal}₹` : '0₹'}
                                  </td>
                                )
                              })}
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-[12px]">
                        <span className="text-slate-500">Grand Total:</span>
                        <span className="font-mono font-bold text-[14px] text-amber-700">₹ {Object.values(dsDoubleGridData).reduce((sum, v) => sum + v, 0).toLocaleString('en-IN')}</span>
                      </div>
                      {dsSkippedNumbers.length > 0 && (
                        <div className="mt-2 p-2 rounded border border-amber-200 bg-amber-50 text-[11px]">
                          <span className="text-amber-700 font-semibold">SKIPPED: </span>
                          <span className="text-amber-600 font-mono">{dsSkippedNumbers.join(', ')}</span>
                        </div>
                      )}
                      {dsDroppedTokens.length > 0 && (
                        <div className="mt-2 p-2 rounded border border-red-200 bg-red-50 text-[11px]">
                          <span className="text-red-700 font-semibold">DROPPED: </span>
                          <span className="text-red-500 font-mono">{dsDroppedTokens.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {dsMessage && tab === 'double' && (
                    <div className={`text-[12px] px-3 py-2 rounded-lg ${dsMessage.includes('success') || dsMessage.includes('Submitted') ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>
                      {dsMessage}
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={handleDsSubmit}
                      disabled={dsSubmitting || !dsSelectDouble.trim()}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-semibold bg-gradient-to-r from-indigo-600 to-indigo-500 text-white hover:from-indigo-700 hover:to-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
                    >
                      <Check size={13} /> Submit
                    </button>
                    <button
                      onClick={handleDoubleReset}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-semibold border border-slate-300 text-slate-600 hover:border-indigo-400 hover:text-indigo-600 transition-all"
                    >
                      <RotateCcw size={13} /> Reset
                    </button>
                  </div>
                </div>
              </div>

              {/* Right: Double Chart Bar Preview */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                  <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Double (Jodi) Chart</h3>
                  <span className="text-[10px] text-slate-400 font-medium">Top 10 by amount</span>
                </div>
                <div className="p-4">
                  <BarChartPreview
                    data={(() => {
                      // Build aggregated amounts per jodi (00-99) from saved + live entries
                      const savedMap: { [key: string]: number } = {}
                      const liveMap: { [key: string]: number } = {}
                      for (const item of dsList as Array<Record<string, unknown>>) {
                        if (item.type !== 'double') continue
                        try {
                          const pd = JSON.parse(item.parsedData as string)
                          if (pd.numbers && Array.isArray(pd.numbers)) {
                            for (const n of pd.numbers) {
                              if (/^\d{2}$/.test(String(n.number))) {
                                savedMap[n.number] = (savedMap[n.number] || 0) + n.price
                              }
                            }
                          }
                        } catch { /* ignore */ }
                      }
                      for (const e of dsParsedEntries) {
                        if (/^\d{2}$/.test(e.number)) {
                          liveMap[e.number] = (liveMap[e.number] || 0) + e.price
                        }
                      }
                      // Combine and take top 10 by amount
                      const combined: { [key: string]: number } = {}
                      for (const k of new Set([...Object.keys(savedMap), ...Object.keys(liveMap)])) {
                        combined[k] = (savedMap[k] || 0) + (liveMap[k] || 0)
                      }
                      const arr = Object.entries(combined)
                        .map(([num, amt]) => ({ num, amt }))
                        .sort((a, b) => b.amt - a.amt)
                        .slice(0, 10)
                      return arr
                    })()}
                    emptyLabel="Paste content to see chart"
                  />
                  <div className="mt-4 pt-3 border-t border-slate-100 text-[12px] text-slate-500">
                    <div className="flex justify-between">
                      <span>Total jodis:</span>
                      <span className="font-semibold text-slate-700">
                        {(() => {
                          const set = new Set<string>()
                          for (const item of dsList as Array<Record<string, unknown>>) {
                            if (item.type !== 'double') continue
                            try {
                              const pd = JSON.parse(item.parsedData as string)
                              if (pd.numbers && Array.isArray(pd.numbers)) {
                                for (const n of pd.numbers) {
                                  if (/^\d{2}$/.test(String(n.number))) set.add(n.number)
                                }
                              }
                            } catch { /* ignore */ }
                          }
                          for (const e of dsParsedEntries) {
                            if (/^\d{2}$/.test(e.number)) set.add(e.number)
                          }
                          return set.size
                        })()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Submitted Double Entry Table */}
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden mb-4">
              <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Submitted Double Entry</h3>
                <span className="text-[10px] text-slate-400 font-medium">
                  {(dsList as Array<Record<string, unknown>>).filter(item => item.type === 'double').length} records
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[13px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      {['#', 'Customer', 'Jodi', 'Amount', 'Time', 'Action'].map(h => (
                        <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-slate-500 whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const doubleEntries = (dsList as Array<Record<string, unknown>>).filter(item => item.type === 'double')
                      if (doubleEntries.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="text-center py-8 text-slate-400">
                              No double entries submitted yet
                            </td>
                          </tr>
                        )
                      }
                      let idx = 0
                      return doubleEntries.flatMap(item => {
                        const typed = item as {
                          id: string; details: string; parsedData: string; rate: number; totalAmount: number;
                          vendor: { businessName: string } | null; createdAt: string
                        }
                        let numbers: Array<{ number: string; price: number }> = []
                        try {
                          const pd = JSON.parse(typed.parsedData)
                          if (pd.numbers && Array.isArray(pd.numbers)) numbers = pd.numbers
                        } catch { /* ignore */ }
                        if (numbers.length === 0) {
                          idx++
                          return [(
                            <tr key={typed.id} className="border-b border-slate-100 hover:bg-indigo-50/40 transition-colors">
                              <td className="px-3.5 py-3"><span className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 font-mono text-[11px] text-slate-500">{idx}</span></td>
                              <td className="px-3.5 py-3 text-slate-700 font-medium">{typed.vendor?.businessName || '—'}</td>
                              <td className="px-3.5 py-3 text-slate-400">—</td>
                              <td className="px-3.5 py-3 font-semibold text-slate-900">₹{typed.totalAmount}</td>
                              <td className="px-3.5 py-3 text-slate-400 text-[11px]">{new Date(typed.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</td>
                              <td className="px-3.5 py-3">
                                <button onClick={() => handleDeleteDs(typed.id)} className="text-red-600 hover:bg-red-50 text-[11px] font-semibold px-2 py-1 rounded transition-colors">Delete</button>
                              </td>
                            </tr>
                          )]
                        }
                        return numbers.map((n, i) => {
                          idx++
                          return (
                            <tr key={typed.id + '-' + i} className="border-b border-slate-100 hover:bg-indigo-50/40 transition-colors">
                              <td className="px-3.5 py-3"><span className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 font-mono text-[11px] text-slate-500">{idx}</span></td>
                              <td className="px-3.5 py-3 text-slate-700 font-medium">{typed.vendor?.businessName || (i === 0 ? '—' : '↑')}</td>
                              <td className="px-3.5 py-3"><span className="font-bold text-indigo-600">{n.number}</span></td>
                              <td className="px-3.5 py-3 font-semibold text-slate-900">₹{n.price}</td>
                              <td className="px-3.5 py-3 text-slate-400 text-[11px]">{i === 0 ? new Date(typed.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : ''}</td>
                              <td className="px-3.5 py-3">
                                {i === 0 && (
                                  <button onClick={() => handleDeleteDs(typed.id)} className="text-red-600 hover:bg-red-50 text-[11px] font-semibold px-2 py-1 rounded transition-colors">Delete</button>
                                )}
                              </td>
                            </tr>
                          )
                        })
                      })
                    })()}
                  </tbody>
                </table>
              </div>
            </div>

          {/* 10x10 Checkbox Grid for Double (manual edit + export) */}
          <SectionCard title="Checkbox Grid (10×10)" headerRight={
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[#9CA3AF]">Rate</span>
                <input
                  type="number"
                  value={dsGridRate}
                  onChange={e => setDsGridRate(e.target.value)}
                  placeholder="Rate"
                  className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-md px-2 py-1 text-[12px] text-[#111827] outline-none w-20 focus:border-[#3730A3]"
                />
                <BlueButton onClick={() => {
                  const grid = memoizedDsGrid
                  let output = ''
                  for (let r = 0; r < 10; r++) {
                    for (let c = 1; c <= 10; c++) {
                      const firstDigit = c === 10 ? 0 : c
                      const num = String(firstDigit * 10 + r).padStart(2, '0')
                      const val = grid[num]
                      if (val > 0) output += `${num}=${val}\n`
                    }
                  }
                  if (output) {
                    navigator.clipboard.writeText(output).then(() => alert('Grid copied to clipboard!')).catch(() => alert(output))
                  } else {
                    alert('No entries in grid')
                  }
                }}><Download size={12} /> Export</BlueButton>
              </div>
            }>
              <div className="overflow-x-auto">
                <table className="w-full text-[12px] border border-[#E5E7EB] rounded-lg overflow-hidden">
                  <thead>
                    <tr className="bg-[#FFFFFF]">
                      <th className="px-2 py-2 text-center text-[11px] font-bold text-[#9CA3AF] border-r border-b border-[#E5E7EB] min-w-[36px]">#</th>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => (
                        <th key={c} className="px-1 py-2 text-center text-[11px] font-bold text-[#D97706] border-r border-b border-[#E5E7EB] last:border-r-0 min-w-[70px]">{c === 10 ? '0' : c}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const dsGrid = memoizedDsGrid
                      return Array.from({ length: 10 }, (_, rowIdx) => {
                        const secondDigit = rowIdx
                        return (
                          <tr key={rowIdx}>
                            <td className="px-2 py-2 text-center text-[11px] font-bold text-[#D97706] bg-[#FFFFFF] border-r border-b border-[#E5E7EB]">{secondDigit}</td>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => {
                              const firstDigit = c === 10 ? 0 : c
                              const num = String(firstDigit * 10 + secondDigit).padStart(2, '0')
                              const val = dsGrid[num] || 0
                              const isVisible = val > 0
                              return (
                                <td key={c} className={`px-1 py-1.5 text-center border-r border-b border-[#E5E7EB] last:border-r-0 ${isVisible ? 'bg-[rgba(217,119,6,0.08)]' : 'bg-[#FFFFFF]'}`}>
                                  {isVisible ? (
                                    <span className="text-[11px] font-mono text-[#D97706] font-bold">{num} = {val}₹</span>
                                  ) : (
                                    <span className="text-[10px] font-mono text-[#D1D5DB]">{num} =</span>
                                  )}
                                </td>
                              )
                            })}
                          </tr>
                        )
                      })
                    })()}
                    {/* Column totals row */}
                    {(() => {
                      const dsGrid = memoizedDsGrid
                      const colTotals: number[] = []
                      for (let c = 1; c <= 10; c++) {
                        const firstDigit = c === 10 ? 0 : c
                        let total = 0
                        for (let row = 0; row < 10; row++) {
                          const num = String(firstDigit * 10 + row).padStart(2, '0')
                          total += dsGrid[num] || 0
                        }
                        colTotals.push(total)
                      }
                      const grandTotal = colTotals.reduce((s, v) => s + v, 0)
                      return (
                        <>
                          <tr className="bg-[#FFFFFF]">
                            <td className="px-2 py-2 text-center text-[11px] font-bold text-[#3730A3] border-r border-t border-[#E5E7EB]">TOT</td>
                            {colTotals.map((ct, i) => (
                              <td key={i} className="px-2 py-2 text-center text-[11px] font-bold font-mono text-[#3730A3] border-r border-t border-[#E5E7EB] last:border-r-0">
                                {ct > 0 ? `${ct}₹` : '0₹'}
                              </td>
                            ))}
                          </tr>
                          <tr className="bg-[#FFFFFF]">
                            <td colSpan={11} className="px-2 py-2 text-center text-[12px] font-bold font-mono text-[#3730A3] border-t border-[#E5E7EB]">
                              TOTAL {grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₹
                            </td>
                          </tr>
                        </>
                      )
                    })()}
                  </tbody>
                </table>
              </div>
            </SectionCard>
        </>
      )}

      {(tab === 'single' || tab === 'double') && (
        <>
          {/* Saved Position Grids (Single + Double combined) */}
          {(() => {
            const savedSingleGrid = buildDsPositionGridFromList(dsList, 'single')
            const savedDoubleGrid = buildDsPositionGridFromList(dsList, 'double')
            const hasSingleData = Object.values(savedSingleGrid).some(arr => arr.length > 0)
            const hasDoubleData = Object.values(savedDoubleGrid).some(arr => arr.length > 0)
            return (hasSingleData || hasDoubleData) ? (
              <SectionCard title="Position Grid (Saved)">
                {hasSingleData && (
                  <div className="mb-4">
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-[#059669] mb-3">Single</div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-[13px] border border-[#E5E7EB] rounded-lg overflow-hidden">
                        <thead>
                          <tr className="bg-[#FFFFFF]">
                            {[1,2,3,4,5,6,7,8,9,10].map(n => (
                              <th key={n} className="px-2 py-2 text-center text-[12px] font-bold text-[#059669] border-r border-[#E5E7EB] last:border-r-0 min-w-[80px]">{n}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                              <td key={pos} className="px-2 py-2 align-top border-r border-[#E5E7EB] last:border-r-0 bg-[#FFFFFF] min-h-[60px]">
                                {savedSingleGrid[pos]?.map((entry, idx) => (
                                  <div key={idx} className="text-[11px] mb-1">
                                    <span className="text-[#111827] font-mono">{entry.number}</span>
                                    <span className="text-[#059669] ml-1">₹{entry.price}</span>
                                  </div>
                                ))}
                                {(!savedSingleGrid[pos] || savedSingleGrid[pos].length === 0) && (
                                  <span className="text-[#9CA3AF] text-[10px]">-</span>
                                )}
                              </td>
                            ))}
                          </tr>
                          <tr className="bg-[#FFFFFF]">
                            {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                              <td key={pos} className="px-2 py-2 text-center text-[12px] font-bold text-[#059669] border-r border-[#E5E7EB] last:border-r-0 font-mono">
                                {(savedSingleGrid[pos] || []).reduce((sum, e) => sum + e.price, 0)}
                              </td>
                            ))}
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
                {hasDoubleData && (
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-[#D97706] mb-3">Double</div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-[13px] border border-[#E5E7EB] rounded-lg overflow-hidden">
                        <thead>
                          <tr className="bg-[#FFFFFF]">
                            {[1,2,3,4,5,6,7,8,9,10].map(n => (
                              <th key={n} className="px-2 py-2 text-center text-[12px] font-bold text-[#D97706] border-r border-[#E5E7EB] last:border-r-0 min-w-[80px]">{n}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                              <td key={pos} className="px-2 py-2 align-top border-r border-[#E5E7EB] last:border-r-0 bg-[#FFFFFF] min-h-[60px]">
                                {savedDoubleGrid[pos]?.map((entry, idx) => (
                                  <div key={idx} className="text-[11px] mb-1">
                                    <span className="text-[#111827] font-mono">{entry.number}</span>
                                    <span className="text-[#D97706] ml-1">₹{entry.price}</span>
                                  </div>
                                ))}
                                {(!savedDoubleGrid[pos] || savedDoubleGrid[pos].length === 0) && (
                                  <span className="text-[#9CA3AF] text-[10px]">-</span>
                                )}
                              </td>
                            ))}
                          </tr>
                          <tr className="bg-[#FFFFFF]">
                            {[1,2,3,4,5,6,7,8,9,10].map(pos => (
                              <td key={pos} className="px-2 py-2 text-center text-[12px] font-bold text-[#D97706] border-r border-[#E5E7EB] last:border-r-0 font-mono">
                                {(savedDoubleGrid[pos] || []).reduce((sum, e) => sum + e.price, 0)}
                              </td>
                            ))}
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </SectionCard>
            ) : null
          })()}

          {/* List Double Single Inventory — Combined Table */}
          <SectionCard title="List Double Single Inventory">
            <div className="overflow-x-auto -mx-5 -mb-5">
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                    {['Sr. No.', 'ID', 'Customer', 'Type', 'Details', 'Rate', 'Total Amount', 'Option'].map(h => (
                      <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {dsList.length === 0 ? (
                    <tr><td colSpan={8} className="text-center py-8 text-[#9CA3AF]">No entries yet</td></tr>
                  ) : dsList.map((dsi, i) => {
                    const item = dsi as {
                      id: string; type: string; details: string; parsedData: string; rate: number; totalAmount: number;
                      vendor: { businessName: string } | null; vendorId: string | null;
                      isUpdated?: boolean; updatedBy?: string | null;
                    }
                    let formattedDetails = item.details || ''
                    let fullNumbersList = ''
                    let isAppRow = false
                    try {
                      const pd = JSON.parse(item.parsedData)
                      isAppRow = pd.source === 'customer-app'
                      if (pd.amount !== undefined) {
                        formattedDetails = `Amount: ₹${pd.amount}`
                      } else if (pd.numbers && Array.isArray(pd.numbers) && pd.numbers.length > 0) {
                        const typeLabel = item.type === 'single' ? 'Single' : item.type === 'double' ? 'Double' : 'Amount'
                        // Show the full card list + type label + count + total so
                        // the details column reflects the complete submission.
                        const numStr = pd.numbers.map((n: { number: string }) => n.number).join(',')
                        formattedDetails = `Card: ${numStr} | ${typeLabel} | Count: ${pd.numbers.length} | Rate: ${item.rate} | Total: ${item.totalAmount}`
                        // Full per-number breakdown with rates — consolidated app
                        // rows also show WHO bet each number (customer names)
                        fullNumbersList = pd.numbers
                          .map((n: { number: string; price?: number }) =>
                            withCustomerBreakdown(`${n.number}@${n.price ?? item.rate}`, n.number, pd.byCustomer))
                          .join('  ')
                      }
                    } catch { /* use raw details */ }
                    const typeColor = item.type === 'single' ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : item.type === 'double' ? 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]' : 'bg-[rgba(55,48,163,0.1)] text-[#3730A3]'
                    return (
                      <tr key={item.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)] transition-colors align-top">
                        <td className="px-3.5 py-3"><span className="bg-[#FFFFFF] border border-[#E5E7EB] rounded px-1.5 py-0.5 font-mono text-[11px] text-[#6B7280]">{i + 1}</span></td>
                        <td className="px-3.5 py-3 font-mono text-[11px] text-[#6B7280]">{item.id.slice(-5).toUpperCase()}</td>
                        <td className="px-3.5 py-3">{isAppRow
                          ? <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 font-bold border border-sky-200">App</span>
                          : (item.vendor?.businessName || 'Not Assign')}</td>
                        <td className="px-3.5 py-3"><span className={`text-[11px] px-2 py-0.5 rounded-full capitalize ${typeColor}`}>{item.type}</span>
                          {item.isUpdated && (
                            <span className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 font-bold border border-amber-200" title={item.updatedBy ? `Edited by ${item.updatedBy}` : 'Entry was edited'}>
                              Updated{item.updatedBy ? ` · ${item.updatedBy}` : ''}
                            </span>
                          )}
                        </td>
                        <td className="px-3.5 py-3 text-[#111827] text-[12px] min-w-[280px] max-w-[640px]">
                          {/* Summary line — wraps naturally, no truncation */}
                          <div className="break-words whitespace-normal leading-relaxed">{formattedDetails}</div>
                          {/* Full per-number breakdown with rates */}
                          {fullNumbersList && (
                            <div className="mt-1.5 pt-1.5 border-t border-dashed border-[#E5E7EB] font-mono text-[11px] text-[#6B7280] break-words whitespace-normal leading-relaxed">
                              {fullNumbersList}
                            </div>
                          )}
                        </td>
                        <td className="px-3.5 py-3 font-mono text-[12px]">{item.rate}</td>
                        <td className="px-3.5 py-3 font-mono text-[12px] text-[#3730A3]">{formatCurrency(item.totalAmount)}</td>
                        <td className="px-3.5 py-3">
                          <div className="flex items-center gap-2">
                            <button onClick={() => openEditDs(item)} className="text-[#0284C7] hover:text-indigo-700 text-[12px] font-semibold transition-colors">
                              Edit
                            </button>
                            <button onClick={() => handleDeleteDs(item.id)} className="w-7 h-7 rounded-md flex items-center justify-center text-[#DC2626] hover:bg-[rgba(220,38,38,0.1)] border border-transparent hover:border-[rgba(220,38,38,0.3)] transition-all"><Trash2 size={14} /></button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </>
      )}

      </div>{/* end tab panel container */}

      {/* Chart Modal */}
      <Modal open={showChartModal} onClose={() => setShowChartModal(false)} title={chartMode === 'full' ? 'Chart' : 'Double & Single Chart'} wide>
        <div className="space-y-4">
          {/* Chart action buttons */}
          <div className="flex gap-2 flex-wrap items-center">
            <BlueButton onClick={handleDownloadChart} disabled={chartDownloading}>
              <Download size={14} /> {chartDownloading ? 'Saving...' : 'Download Image'}
            </BlueButton>
            <button
              onClick={handleShareChart}
              disabled={chartSharing}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-semibold transition-all ${
                chartCopied
                  ? 'bg-[#0284C7] text-white'
                  : 'bg-[#059669] text-white hover:bg-[#047857]'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {chartCopied ? <CheckCircle2 size={14} /> : chartSharing ? <RefreshCw size={14} className="animate-spin" /> : <Share2 size={14} />}
              {chartCopied ? 'Copied!' : chartSharing ? 'Sharing...' : 'Share Image'}
            </button>
            <BlueButton onClick={() => { fetchTripleList(); fetchDsList() }}><RefreshCw size={14} /> Reload</BlueButton>
            {/* Gap 10 — Style button */}
            <button
              onClick={() => setShowStylePanel(prev => !prev)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-[#7C3AED] text-white hover:bg-[#6D28D9] transition-all"
            >
              <Palette size={14} /> Style
            </button>
            {/* B&W Mode Dropdown */}
            <select
              value={chartBwMode ? 'bw' : 'color'}
              onChange={e => setChartBwMode(e.target.value === 'bw')}
              className="px-3 py-2 rounded-lg text-[13px] font-semibold border bg-[#FFFFFF] border-[#E5E7EB] text-[#6B7280] cursor-pointer hover:border-[#0284C7] transition-all"
            >
              <option value="bw">Default</option>
              <option value="color">Color</option>
            </select>
          </div>

          {/* Gap 10 — Chart Style Customization Panel */}
          {showStylePanel && (
            <div className="mt-2 p-3 border border-[#E5E7EB] rounded-lg bg-[#F9FAFB]">
              <div className="text-[12px] font-semibold text-[#111827] mb-2">Chart Style Customization</div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-[#6B7280]">Panna Color</label>
                  <input type="color" value={chartStyleCustom.pannaColor} onChange={e => setChartStyleCustom(s => ({ ...s, pannaColor: e.target.value }))} className="w-full h-8" />
                </div>
                <div>
                  <label className="text-[10px] text-[#6B7280]">Rate Color</label>
                  <input type="color" value={chartStyleCustom.rateColor} onChange={e => setChartStyleCustom(s => ({ ...s, rateColor: e.target.value }))} className="w-full h-8" />
                </div>
                <div>
                  <label className="text-[10px] text-[#6B7280]">Header BG</label>
                  <input type="color" value={chartStyleCustom.headerBg} onChange={e => setChartStyleCustom(s => ({ ...s, headerBg: e.target.value }))} className="w-full h-8" />
                </div>
                <div>
                  <label className="text-[10px] text-[#6B7280]">Total BG</label>
                  <input type="color" value={chartStyleCustom.totalBg} onChange={e => setChartStyleCustom(s => ({ ...s, totalBg: e.target.value }))} className="w-full h-8" />
                </div>
                <div>
                  <label className="text-[10px] text-[#6B7280]">Font</label>
                  <select value={chartStyleCustom.fontFamily} onChange={e => setChartStyleCustom(s => ({ ...s, fontFamily: e.target.value }))} className="w-full text-[11px] p-1 border rounded">
                    <option value="serif">Serif</option>
                    <option value="sans-serif">Sans-Serif</option>
                    <option value="monospace">Monospace</option>
                  </select>
                </div>
              </div>
              <button onClick={() => setChartStyleCustom({ pannaColor: '#000000', rateColor: '#1E3A8A', headerBg: '#d0d0d0', totalBg: '#e8e8e8', fontFamily: 'serif' })} className="mt-2 text-[10px] text-[#3730A3] underline">Reset to Defaults</button>
            </div>
          )}

          {/* Chart content - captured for download/share */}
          <div ref={chartRef} className={`rounded-lg ${chartBwMode ? 'bg-white' : 'bg-[#FFFFFF]'} p-3 min-w-[850px]`}>
            {/* Chart info header */}
            <div className={`text-[14px] font-bold pb-2 mb-2 ${chartBwMode ? 'text-black border-b border-gray-400' : 'text-[#111827] border-b border-[#E5E7EB]'}`}>
              Date:{formatDate(inv.date)}{inv.time ? ` Time:${inv.time}` : ''}
            </div>

            {/* Chart Grid - Full or Blank depending on mode */}
            {chartMode === 'full' ? (() => {
              // Build price lookup from adjustedChartGrid (aggregate duplicate pannas)
              const chartPriceMap: { [panna: string]: number } = {}
              for (let pos = 1; pos <= 10; pos++) {
                for (const entry of (adjustedChartGrid[pos] || [])) {
                  if (entry.number.length === 3) {
                    if (chartHideShared && chartMarkedShared.has(entry.number)) continue
                    chartPriceMap[entry.number] = (chartPriceMap[entry.number] || 0) + entry.price
                  }
                }
              }

              const chartData = build220ChartData(chartPriceMap)
              const { rows } = chartData

              // Calculate column totals for filtered positions.
              // When a Super Admin has applied a "Deduct from Column Total",
              // we subtract the uniform deduction here (floored at 0).
              // ANK/cell prices in `rows` are NEVER modified — only this totals row.
              const chartColTotals: { [col: number]: number } = {}
              for (const pos of filteredPositions) {
                let raw = 0
                const rowData = rows.map(r => r[pos - 1])
                for (const cell of rowData) {
                  if (cell.price !== undefined) raw += cell.price
                }
                // Apply uniform deduction
                let total = Math.max(0, raw - chartColDeduction)
                // Gap 8 — Apply per-column deductions and additions
                const perColDeduct = chartPerColDeduction[pos] || 0
                const perColAdd = chartPerColAdd[pos] || 0
                total = Math.max(0, total - perColDeduct + perColAdd)
                chartColTotals[pos] = total
              }

              return (
                <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
                  <thead>
                    <tr className={chartBwMode ? 'bg-gray-200' : 'bg-[#FFFFFF]'}>
                      {filteredPositions.map(n => (
                        <th key={n} className={`px-2 py-2 text-center text-[14px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400 bg-gray-200' : 'text-[#0284C7] border-[#E5E7EB] bg-[#FFFFFF]'} border`}>{n}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((fullRowData, rowIdx) => {
                      // Filter to only show columns in filteredPositions
                      const rowData = filteredPositions.map(pos => fullRowData[pos - 1])
                      const rowHasData = rowData.some(cell => cell.panna && cell.price !== undefined)
                      if (!rowHasData) return null

                      const isTypeSeparator = rowIdx === 12 || rowIdx === 13

                      return (
                        <React.Fragment key={rowIdx}>
                          {isTypeSeparator && rowHasData && (
                            <tr>
                              <td colSpan={filteredPositions.length} className={`px-2 py-0.5 ${chartBwMode ? 'bg-gray-100 border-gray-400' : 'bg-[#F5F6FA] border-[#E5E7EB]'} border`}>
                                <span className={`text-[9px] font-bold uppercase tracking-widest ${chartBwMode ? 'text-gray-500' : 'text-[#9CA3AF]'}`}>
                                  {rowIdx === 12 ? '── TP ──' : '── DP ──'}
                                </span>
                              </td>
                            </tr>
                          )}
                          <tr className={rowIdx % 2 === 0 ? (chartBwMode ? 'bg-white' : 'bg-[#FFFFFF]') : (chartBwMode ? 'bg-gray-50' : 'bg-[#F5F6FA]')}>
                            {rowData.map((cell, colIdx) => {
                              const pos = filteredPositions[colIdx]
                              if (!cell.panna) return <td key={pos} className={`px-2 py-1 ${chartBwMode ? 'border-gray-400' : 'border-[#E5E7EB]'} border`} />
                              const isShared = chartMarkedShared.has(cell.panna)
                              if (cell.price === undefined) {
                                return <td key={pos} className={`px-2 py-1 ${chartBwMode ? 'border-gray-400' : 'border-[#E5E7EB]'} border`} />
                              }
                              return (
                                <td key={pos} className={`px-2 py-1 ${chartBwMode ? 'border-gray-400 bg-gray-50' : 'border-[#E5E7EB] bg-[rgba(55,48,163,0.04)]'} border ${isShared ? 'opacity-50' : ''}`}>
                                  <div className="text-[11px] leading-tight text-center">
                                    <span className={`font-mono ${chartBwMode ? 'text-black' : 'text-[#111827]'} font-semibold`}>{cell.panna}</span>
                                    <span className={chartBwMode ? 'text-black' : 'text-[#6B7280]'}> = </span>
                                    <span className={`font-mono ${chartBwMode ? 'text-red-600' : 'text-[#3730A3]'} font-semibold`}>{cell.price}₹</span>
                                  </div>
                                </td>
                              )
                            })}
                          </tr>
                        </React.Fragment>
                      )
                    })}
                    {/* Per-column TOTAL row */}
                    <tr className={chartBwMode ? 'bg-gray-100' : 'bg-[#FFFFFF]'}>
                      {filteredPositions.map(pos => (
                        <td key={pos} className={`px-2 py-2 text-center text-[12px] font-bold font-mono ${chartBwMode ? 'text-black border-gray-400 bg-gray-100' : 'text-[#3730A3] border-[#E5E7EB] bg-[#FFFFFF]'} border`}>
                          {chartColTotals[pos] ? `${chartColTotals[pos]}₹` : '0₹'}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              )
            })() : (
              <>
                {/* Blank chart - empty grid */}
                <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
                  <thead>
                    <tr className={chartBwMode ? 'bg-gray-200' : 'bg-[#FFFFFF]'}>
                      {filteredPositions.map(n => (
                        <th key={n} className={`px-2 py-2 text-center text-[14px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400 bg-gray-200' : 'text-[#0284C7] border-[#E5E7EB] bg-[#FFFFFF]'} border`}>{n}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      {filteredPositions.map(pos => (
                        <td key={pos} className={`px-2 py-4 ${chartBwMode ? 'bg-white border-gray-400' : 'bg-[#FFFFFF] border-[#E5E7EB]'} border`}>
                          <div className={`text-[10px] text-center ${chartBwMode ? 'text-gray-300' : 'text-[#D1D5DB]'}`}>-</div>
                        </td>
                      ))}
                    </tr>
                    {/* TOTAL row (0) */}
                    <tr className={chartBwMode ? 'bg-gray-100' : 'bg-[#FFFFFF]'}>
                      {filteredPositions.map(pos => (
                        <td key={pos} className={`px-2 py-2 text-center text-[12px] font-bold font-mono ${chartBwMode ? 'text-black border-gray-400 bg-gray-100' : 'text-[#3730A3] border-[#E5E7EB] bg-[#FFFFFF]'} border`}>
                          0₹
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </>
            )}

            {/* Grand Total */}
            {chartMode === 'full' ? (
              <>
                <div className={`text-[15px] font-bold pt-2 mt-2 ${chartBwMode ? 'text-black border-t border-gray-400' : 'text-[#111827] border-t border-[#E5E7EB]'}`}>
                  TOTAL FOR ALL {adjustedGrandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₹
                </div>
                {/* FULL CHART: TOTAL FOR SINGLE section */}
                {(() => {
                  const hasAnySingle = Object.values(singleTotals).some(v => v > 0)
                  if (!hasAnySingle) return null
                  return (
                    <div className={`mt-3 pt-2 ${chartBwMode ? 'border-t border-gray-300' : 'border-t border-[#E5E7EB]'}`}>
                      <div className={`text-[12px] font-bold mb-2 ${chartBwMode ? 'text-black' : 'text-[#111827]'}`}>TOTAL FOR SINGLE</div>
                      <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
                        <thead>
                          <tr className={chartBwMode ? 'bg-gray-200' : 'bg-[#FFFFFF]'}>
                            {[1,2,3,4,5,6,7,8,9,10].map(n => (
                              <th key={n} className={`px-2 py-1.5 text-center text-[12px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#0284C7] border-[#E5E7EB]'} border`}>{n === 10 ? 0 : n}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            {[1,2,3,4,5,6,7,8,9,10].map(pos => {
                              let val = singleTotals[pos] || 0
                              if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
                              if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
                              return (
                                <td key={pos} className={`px-2 py-1.5 text-center text-[11px] font-mono ${chartBwMode ? 'text-black border-gray-400' : 'text-[#111827] border-[#E5E7EB]'} border`}>
                                  {val > 0 ? `${val}₹` : '0₹'}
                                </td>
                              )
                            })}
                          </tr>
                          <tr className={chartBwMode ? 'bg-gray-100' : 'bg-[#FFFFFF]'}>
                            <td colSpan={10} className={`px-2 py-1.5 text-center text-[12px] font-bold font-mono ${chartBwMode ? 'text-black border-gray-400' : 'text-[#3730A3] border-[#E5E7EB]'} border`}>
                              TOTAL {(() => {
                                let total = singleGrandTotal
                                if (chartAppliedPct.less > 0) total = Math.round(total * (1 - chartAppliedPct.less / 100))
                                if (chartAppliedPct.add > 0) total = Math.round(total * (1 + chartAppliedPct.add / 100))
                                return total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                              })()} ₹
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  )
                })()}
                {/* FULL CHART: Double 10×10 grid section */}
                {(() => {
                  const savedDsGrid = memoizedDsGrid
                  const hasAnyDouble = Object.values(savedDsGrid).some(v => v > 0)
                  if (!hasAnyDouble) return null
                  // Apply percentage adjustments
                  const adjustedDsGrid: { [key: string]: number } = {}
                  for (const key of Object.keys(savedDsGrid)) {
                    let val = savedDsGrid[key]
                    if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
                    if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
                    adjustedDsGrid[key] = val
                  }
                  const doubleColTotals: { [col: number]: number } = {}
                  for (let c = 1; c <= 10; c++) {
                    doubleColTotals[c] = 0
                    const firstDigit = c === 10 ? 0 : c
                    for (let row = 0; row < 10; row++) {
                      const num = String(firstDigit * 10 + row).padStart(2, '0')
                      doubleColTotals[c] += adjustedDsGrid[num] || 0
                    }
                  }
                  const doubleGrandTotal = Object.values(doubleColTotals).reduce((sum, v) => sum + v, 0)
                  return (
                    <div className={`mt-3 pt-2 ${chartBwMode ? 'border-t border-gray-300' : 'border-t border-[#E5E7EB]'}`}>
                      <div className={`text-[12px] font-bold mb-2 ${chartBwMode ? 'text-black' : 'text-[#111827]'}`}>TOTAL FOR DOUBLE</div>
                      <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
                        <thead>
                          <tr className={chartBwMode ? 'bg-gray-200' : 'bg-[#FFFFFF]'}>
                            <th className={`px-1.5 py-1.5 text-center text-[10px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#9CA3AF] border-[#E5E7EB]'} border min-w-[28px]`}>#</th>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => (
                              <th key={c} className={`px-1 py-1.5 text-center text-[10px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#D97706] border-[#E5E7EB]'} border min-w-[50px]`}>{c === 10 ? '0' : c}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {Array.from({ length: 10 }, (_, rowIdx) => {
                            const secondDigit = rowIdx
                            return (
                              <tr key={rowIdx}>
                                <td className={`px-1 py-1 text-center text-[9px] font-bold ${chartBwMode ? 'text-gray-600 border-gray-400' : 'text-[#D97706] border-[#E5E7EB]'} border`}>{secondDigit}</td>
                                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => {
                                  const firstDigit = c === 10 ? 0 : c
                                  const num = String(firstDigit * 10 + secondDigit).padStart(2, '0')
                                  const val = adjustedDsGrid[num] || 0
                                  const isVisible = val > 0
                                  return (
                                    <td key={c} className={`px-0.5 py-0.5 text-center border ${isVisible ? (chartBwMode ? 'bg-gray-100' : 'bg-[rgba(217,119,6,0.06)]') : ''} ${chartBwMode ? 'border-gray-400' : 'border-[#E5E7EB]'}`}>
                                      {isVisible ? (
                                        <span className={`text-[9px] font-mono font-bold ${chartBwMode ? 'text-black' : 'text-[#D97706]'}`}>{num} = {val}₹</span>
                                      ) : (
                                        <span className={`text-[8px] font-mono ${chartBwMode ? 'text-gray-300' : 'text-[#D1D5DB]'}`}>{num} =</span>
                                      )}
                                    </td>
                                  )
                                })}
                              </tr>
                            )
                          })}
                          <tr className={chartBwMode ? 'bg-gray-100' : 'bg-[#FFFFFF]'}>
                            <td className={`px-1 py-1 text-center text-[9px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#3730A3] border-[#E5E7EB]'} border`}>=</td>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => (
                              <td key={c} className={`px-1 py-1 text-center text-[9px] font-bold font-mono ${chartBwMode ? 'text-black border-gray-400' : 'text-[#3730A3] border-[#E5E7EB]'} border`}>
                                {doubleColTotals[c] > 0 ? `${doubleColTotals[c]}₹` : '0₹'}
                              </td>
                            ))}
                          </tr>
                        </tbody>
                      </table>
                      <div className={`text-[11px] font-bold mt-1 ${chartBwMode ? 'text-black' : 'text-[#111827]'}`}>
                        TOTAL {doubleGrandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₹
                      </div>
                    </div>
                  )
                })()}
              </>
            ) : (
              <>
                <div className={`text-[15px] font-bold pt-2 mt-2 ${chartBwMode ? 'text-black border-t border-gray-400' : 'text-[#111827] border-t border-[#E5E7EB]'}`}>
                  TOTAL 0.00 ₹
                </div>
                {/* TOTAL FOR SINGLE section (blank chart mode) */}
                <div className={`mt-3 pt-2 ${chartBwMode ? 'border-t border-gray-300' : 'border-t border-[#E5E7EB]'}`}>
                  <div className={`text-[12px] font-bold mb-2 ${chartBwMode ? 'text-black' : 'text-[#111827]'}`}>TOTAL FOR SINGLE</div>
                  <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
                    <thead>
                      <tr className={chartBwMode ? 'bg-gray-200' : 'bg-[#FFFFFF]'}>
                        {[1,2,3,4,5,6,7,8,9,10].map(n => (
                          <th key={n} className={`px-2 py-1.5 text-center text-[12px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#0284C7] border-[#E5E7EB]'} border`}>{n === 10 ? 0 : n}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        {[1,2,3,4,5,6,7,8,9,10].map(pos => {
                          let val = singleTotals[pos] || 0
                          if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
                          if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
                          return (
                            <td key={pos} className={`px-2 py-1.5 text-center text-[11px] font-mono ${chartBwMode ? 'text-black border-gray-400' : 'text-[#111827] border-[#E5E7EB]'} border`}>
                              {val > 0 ? `${val}₹` : '0₹'}
                            </td>
                          )
                        })}
                      </tr>
                      <tr className={chartBwMode ? 'bg-gray-100' : 'bg-[#FFFFFF]'}>
                        <td colSpan={10} className={`px-2 py-1.5 text-center text-[12px] font-bold font-mono ${chartBwMode ? 'text-black border-gray-400' : 'text-[#3730A3] border-[#E5E7EB]'} border`}>
                          TOTAL {(() => {
                            let total = singleGrandTotal
                            if (chartAppliedPct.less > 0) total = Math.round(total * (1 - chartAppliedPct.less / 100))
                            if (chartAppliedPct.add > 0) total = Math.round(total * (1 + chartAppliedPct.add / 100))
                            return total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                          })()} ₹
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                {/* DOUBLE 10×10 CHART section (blank chart mode) */}
                {(() => {
                  const savedDsGrid = memoizedDsGrid
                  const hasAnyDouble = Object.values(savedDsGrid).some(v => v > 0)
                  // Apply percentage adjustments
                  const adjustedDsGrid: { [key: string]: number } = {}
                  for (const key of Object.keys(savedDsGrid)) {
                    let val = savedDsGrid[key]
                    if (chartAppliedPct.less > 0) val = Math.round(val * (1 - chartAppliedPct.less / 100))
                    if (chartAppliedPct.add > 0) val = Math.round(val * (1 + chartAppliedPct.add / 100))
                    adjustedDsGrid[key] = val
                  }
                  // Calculate column totals for double
                  const doubleColTotals: { [col: number]: number } = {}
                  for (let c = 1; c <= 10; c++) {
                    doubleColTotals[c] = 0
                    const firstDigit = c === 10 ? 0 : c
                    for (let row = 0; row < 10; row++) {
                      const num = String(firstDigit * 10 + row).padStart(2, '0')
                      doubleColTotals[c] += adjustedDsGrid[num] || 0
                    }
                  }
                  const doubleGrandTotal = Object.values(doubleColTotals).reduce((sum, v) => sum + v, 0)
                  if (!hasAnyDouble && doubleGrandTotal === 0) return null
                  return (
                    <div className={`mt-3 pt-2 ${chartBwMode ? 'border-t border-gray-300' : 'border-t border-[#E5E7EB]'}`}>
                      <div className={`text-[12px] font-bold mb-2 ${chartBwMode ? 'text-black' : 'text-[#111827]'}`}>TOTAL FOR DOUBLE</div>
                      <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
                        <thead>
                          <tr className={chartBwMode ? 'bg-gray-200' : 'bg-[#FFFFFF]'}>
                            <th className={`px-1.5 py-1.5 text-center text-[10px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#9CA3AF] border-[#E5E7EB]'} border min-w-[28px]`}>#</th>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => (
                              <th key={c} className={`px-1 py-1.5 text-center text-[10px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#D97706] border-[#E5E7EB]'} border min-w-[50px]`}>{c === 10 ? '0' : c}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {Array.from({ length: 10 }, (_, rowIdx) => {
                            const secondDigit = rowIdx
                            return (
                              <tr key={rowIdx}>
                                <td className={`px-1 py-1 text-center text-[9px] font-bold ${chartBwMode ? 'text-gray-600 border-gray-400' : 'text-[#D97706] border-[#E5E7EB]'} border`}>{secondDigit}</td>
                                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => {
                                  const firstDigit = c === 10 ? 0 : c
                                  const num = String(firstDigit * 10 + secondDigit).padStart(2, '0')
                                  const val = adjustedDsGrid[num] || 0
                                  const isVisible = val > 0
                                  return (
                                    <td key={c} className={`px-0.5 py-0.5 text-center border ${isVisible ? (chartBwMode ? 'bg-gray-100' : 'bg-[rgba(217,119,6,0.06)]') : ''} ${chartBwMode ? 'border-gray-400' : 'border-[#E5E7EB]'}`}>
                                      {isVisible ? (
                                        <span className={`text-[9px] font-mono font-bold ${chartBwMode ? 'text-black' : 'text-[#D97706]'}`}>{num} = {val}₹</span>
                                      ) : (
                                        <span className={`text-[8px] font-mono ${chartBwMode ? 'text-gray-300' : 'text-[#D1D5DB]'}`}>{num} =</span>
                                      )}
                                    </td>
                                  )
                                })}
                              </tr>
                            )
                          })}
                          {/* Column totals */}
                          <tr className={chartBwMode ? 'bg-gray-100' : 'bg-[#FFFFFF]'}>
                            <td className={`px-1 py-1 text-center text-[9px] font-bold ${chartBwMode ? 'text-gray-800 border-gray-400' : 'text-[#3730A3] border-[#E5E7EB]'} border`}>=</td>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(c => (
                              <td key={c} className={`px-1 py-1 text-center text-[9px] font-bold font-mono ${chartBwMode ? 'text-black border-gray-400' : 'text-[#3730A3] border-[#E5E7EB]'} border`}>
                                {doubleColTotals[c] > 0 ? `${doubleColTotals[c]}₹` : '0₹'}
                              </td>
                            ))}
                          </tr>
                        </tbody>
                      </table>
                      <div className={`text-[11px] font-bold mt-1 ${chartBwMode ? 'text-black' : 'text-[#111827]'}`}>
                        TOTAL {doubleGrandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₹
                      </div>
                    </div>
                  )
                })()}
              </>
            )}
          </div>

          {/* Bottom Controls */}
          <div className={`space-y-3 p-3 rounded-lg ${chartBwMode ? 'bg-gray-50 border border-gray-300' : 'bg-[#FFFFFF] border border-[#E5E7EB]'}`}>
            {/* Filter Radio Buttons */}
            <div>
              <div className={`text-[11px] font-semibold uppercase tracking-wider mb-2 ${chartBwMode ? 'text-gray-600' : 'text-[#9CA3AF]'}`}>Filter</div>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'All', value: 'all' },
                  { label: 'Top 10', value: 'top10' },
                  { label: 'Top 20', value: 'top20' },
                  { label: 'Top 30', value: 'top30' },
                  { label: 'Col 1', value: 'col1' },
                  { label: 'Col 2', value: 'col2' },
                  { label: 'Col 3', value: 'col3' },
                  { label: 'Col 4', value: 'col4' },
                  { label: 'Col 5', value: 'col5' },
                  { label: 'Col 6', value: 'col6' },
                  { label: 'Col 7', value: 'col7' },
                  { label: 'Col 8', value: 'col8' },
                  { label: 'Col 9', value: 'col9' },
                  { label: 'Col 10', value: 'col10' },
                  { label: 'Col 1-2', value: 'col1-2' },
                  { label: 'Col 3-4', value: 'col3-4' },
                  { label: 'Col 5-6', value: 'col5-6' },
                  { label: 'Col 7-8', value: 'col7-8' },
                  { label: 'Col 9-10', value: 'col9-10' },
                  { label: 'Col 1-5', value: 'col1-5' },
                  { label: 'Col 1-6', value: 'col1-6' },
                  { label: 'Col 6-10', value: 'col6-10' },
                ].map(opt => (
                  <label key={opt.value} className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="chartFilter"
                      checked={chartFilter === opt.value}
                      onChange={() => setChartFilter(opt.value)}
                      className="accent-[#0284C7]"
                    />
                    <span className={`text-[11px] ${chartBwMode ? 'text-gray-700' : 'text-[#6B7280]'}`}>{opt.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Share & Shared Controls */}
            <div className="flex flex-wrap gap-2 items-center">
              <select
                className={`px-2 py-1.5 rounded-lg text-[12px] border ${chartBwMode ? 'bg-white border-gray-300 text-gray-800' : 'bg-[#FFFFFF] border-[#E5E7EB] text-[#6B7280]'}`}
                defaultValue="every"
              >
                <option value="every">Every No.</option>
              </select>
              <BlueButton onClick={handleShareChart} disabled={chartSharing}>
                <Share2 size={12} /> Share
              </BlueButton>
              <button
                onClick={() => handleShareWhatsApp('double')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-[#059669] text-white hover:bg-[#047857] transition-all"
              >
                <MessageCircle size={12} /> WhatsApp (Double)
              </button>
              <button
                onClick={() => handleShareWhatsApp('single')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-[#0284C7] text-white hover:bg-[#0369A1] transition-all"
              >
                <MessageCircle size={12} /> WhatsApp (Single)
              </button>
              <button
                onClick={handleShareWhatsAppTriple}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-[#7C3AED] text-white hover:bg-[#6D28D9] transition-all"
              >
                <MessageCircle size={12} /> WhatsApp (Triple)
              </button>
              <button
                onClick={() => {
                  // Mark visible entries as shared
                  const newShared = new Set(chartMarkedShared)
                  for (let pos = 1; pos <= 10; pos++) {
                    for (const entry of (adjustedChartGrid[pos] || [])) {
                      newShared.add(entry.number)
                    }
                  }
                  setChartMarkedShared(newShared)
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-[#DC2626] text-white hover:bg-[#B91C1C] transition-all"
              >
                <Check size={12} /> Mark as shared
              </button>
              <button
                onClick={() => setChartHideShared(!chartHideShared)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold transition-all ${
                  chartHideShared
                    ? 'bg-[#D1D5DB] text-white'
                    : chartBwMode ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' : 'bg-[#FFFFFF] text-[#6B7280] hover:bg-[#E5E7EB]'
                }`}
              >
                {chartHideShared ? 'Show Shared' : 'Hide Shared'}
              </button>
            </div>

            {/* Percentage Less / Add */}
            <div className="flex flex-wrap gap-3 items-center">
              <div className="flex items-center gap-1.5">
                <span className={`text-[11px] font-semibold ${chartBwMode ? 'text-gray-600' : 'text-[#9CA3AF]'}`}>Enter Less %</span>
                <input
                  type="number"
                  value={chartLessPct}
                  onChange={e => setChartLessPct(e.target.value)}
                  placeholder="0"
                  className={`w-16 px-2 py-1 rounded text-[12px] border ${chartBwMode ? 'bg-white border-gray-300 text-gray-800' : 'bg-[#FFFFFF] border-[#E5E7EB] text-[#111827]'}`}
                />
                <button
                  onClick={() => {
                    const val = parseFloat(chartLessPct) || 0
                    setChartAppliedPct(prev => ({ ...prev, less: val }))
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[12px] font-semibold bg-[#0284C7] text-white hover:bg-[#0369A1] transition-all"
                >
                  Less
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`text-[11px] font-semibold ${chartBwMode ? 'text-gray-600' : 'text-[#9CA3AF]'}`}>Enter Add %</span>
                <input
                  type="number"
                  value={chartAddPct}
                  onChange={e => setChartAddPct(e.target.value)}
                  placeholder="0"
                  className={`w-16 px-2 py-1 rounded text-[12px] border ${chartBwMode ? 'bg-white border-gray-300 text-gray-800' : 'bg-[#FFFFFF] border-[#E5E7EB] text-[#111827]'}`}
                />
                <button
                  onClick={() => {
                    const val = parseFloat(chartAddPct) || 0
                    setChartAppliedPct(prev => ({ ...prev, add: val }))
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[12px] font-semibold bg-[#059669] text-white hover:bg-[#047857] transition-all"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Deduct from Column Total — Super Admin / Manager only */}
            {isMasterOrManager && (
              <div className="flex flex-wrap gap-3 items-center p-3 rounded-lg border border-dashed border-[#D97706] bg-[rgba(217,119,6,0.05)]">
                <div className="flex items-center gap-1.5">
                  <span className={`text-[11px] font-semibold uppercase tracking-wider ${chartBwMode ? 'text-gray-600' : 'text-[#92400E]'}`}>
                    Deduct from Column Total ₹
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={chartColDeductionInput}
                    onChange={e => setChartColDeductionInput(e.target.value)}
                    placeholder="0"
                    className={`w-24 px-2 py-1 rounded text-[12px] border ${chartBwMode ? 'bg-white border-gray-300 text-gray-800' : 'bg-[#FFFFFF] border-[#E5E7EB] text-[#111827]'} outline-none focus:border-[#D97706]`}
                  />
                  <button
                    onClick={() => {
                      const val = Math.max(0, parseFloat(chartColDeductionInput) || 0)
                      setChartColDeduction(val)
                      // Phase 2 — log chart revision (manual_override action)
                      if (inv) {
                        logChartRevision({
                          chartId: inv.id,
                          action: 'manual_override',
                          summary: `Applied column-total deduction of ₹${val}`,
                          previousData: { colDeduction: chartColDeduction },
                          newData: { colDeduction: val, appliedPct: chartAppliedPct },
                        })
                      }
                    }}
                    className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[12px] font-semibold bg-[#D97706] text-white hover:bg-[#92400E] transition-all"
                  >
                    Apply
                  </button>
                  <button
                    onClick={() => {
                      const prev = chartColDeduction
                      setChartColDeduction(0)
                      setChartColDeductionInput('')
                      setChartPerColDeduction({})
                      setChartPerColAdd({})
                      if (inv) {
                        logChartRevision({
                          chartId: inv.id,
                          action: 'manual_override',
                          summary: `Reset column-total deduction (was ₹${prev})`,
                          previousData: { colDeduction: prev },
                          newData: { colDeduction: 0 },
                        })
                      }
                    }}
                    disabled={chartColDeduction === 0 && chartColDeductionInput === ''}
                    className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[12px] font-semibold bg-[#6B7280] text-white hover:bg-[#4B5563] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    Reset
                  </button>
                </div>
                {chartColDeduction > 0 && (
                  <span className={`text-[11px] font-medium ${chartBwMode ? 'text-gray-700' : 'text-[#92400E]'}`}>
                    Active: −₹{chartColDeduction.toLocaleString('en-IN')} per column · Grand Total ₹{adjustedGrandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                )}
              </div>
            )}

            {/* Gap 8 — Per-Column Deduct/Add */}
            {isMasterOrManager && (
              <div className="mt-2 p-3 rounded-lg border border-dashed border-[#3730A3] bg-[rgba(55,48,163,0.05)]">
                <div className="text-[11px] font-semibold text-[#6B7280] mb-1">Per-Column Adjustments (Ank 1-10)</div>
                <div className="grid grid-cols-5 gap-1">
                  {filteredPositions.map(ank => (
                    <div key={ank} className="flex items-center gap-1">
                      <span className="text-[10px] font-mono text-[#3730A3] w-4">{ank === 10 ? 0 : ank}</span>
                      <input
                        type="number"
                        placeholder="-0"
                        value={chartPerColDeduction[ank] || ''}
                        onChange={e => setChartPerColDeduction(prev => ({ ...prev, [ank]: Number(e.target.value) || 0 }))}
                        className="w-14 text-[10px] px-1 py-0.5 border border-[#E5E7EB] rounded bg-red-50 text-red-700"
                      />
                      <input
                        type="number"
                        placeholder="+0"
                        value={chartPerColAdd[ank] || ''}
                        onChange={e => setChartPerColAdd(prev => ({ ...prev, [ank]: Number(e.target.value) || 0 }))}
                        className="w-14 text-[10px] px-1 py-0.5 border border-[#E5E7EB] rounded bg-green-50 text-green-700"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Bottom Action Buttons */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => {
                  const prevPct = chartAppliedPct
                  const prevShared = new Set(chartMarkedShared)
                  const prevDeduction = chartColDeduction
                  setChartMarkedShared(new Set())
                  setChartAppliedPct({ less: 0, add: 0 })
                  setChartLessPct('')
                  setChartAddPct('')
                  setChartColDeduction(0)
                  setChartColDeductionInput('')
                  setChartPerColDeduction({})
                  setChartPerColAdd({})
                  // Phase 2 — log chart revision (reset action)
                  if (inv) {
                    logChartRevision({
                      chartId: inv.id,
                      action: 'reset',
                      summary: 'Reset chart adjustments (cleared marked-shared + percentage adjustments + column deduction)',
                      previousData: { appliedPct: prevPct, markedShared: Array.from(prevShared), colDeduction: prevDeduction },
                      newData: { appliedPct: { less: 0, add: 0 }, markedShared: [], colDeduction: 0 },
                    })
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold bg-[#059669] text-white hover:bg-[#047857] transition-all"
              >
                <Check size={12} /> Mark All Not Shared
              </button>
              <BlueButton onClick={() => {
                // Apply any pending percentage values and recalculate
                const prevPct = chartAppliedPct
                const lessVal = chartLessPct ? parseFloat(chartLessPct) || 0 : chartAppliedPct.less
                const addVal = chartAddPct ? parseFloat(chartAddPct) || 0 : chartAppliedPct.add
                setChartAppliedPct({ less: lessVal, add: addVal })
                // Also refresh data from server
                fetchTripleList(); fetchDsList()
                // Phase 2 — log chart revision (regenerate action)
                if (inv) {
                  logChartRevision({
                    chartId: inv.id,
                    action: 'regenerate',
                    summary: `Recalculated chart totals with adjustments: less ${lessVal}%, add ${addVal}%, perColDeduction=${JSON.stringify(chartPerColDeduction)}, perColAdd=${JSON.stringify(chartPerColAdd)}, adjustedGrandTotal=${adjustedGrandTotal}`,
                    previousData: { appliedPct: prevPct },
                    newData: { appliedPct: { less: lessVal, add: addVal }, filter: chartFilter, perColDeduction: chartPerColDeduction, perColAdd: chartPerColAdd, adjustedGrandTotal },
                  })
                }
              }}>
                <RefreshCw size={12} /> Calculate Total
              </BlueButton>
            </div>
          </div>
        </div>
      </Modal>

      {/* ── Entry Edit Modal (Triple + Double/Single lists) ── */}
      {editingEntry && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40" onClick={() => !editSaving && setEditingEntry(null)}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-[14px] font-bold text-slate-900">
                Edit Entry <span className="text-[#6B7280] font-medium capitalize">({editingEntry.kind === 'triple' ? 'Triple' : editingEntry.type})</span>
              </h3>
              <button onClick={() => !editSaving && setEditingEntry(null)} className="text-slate-400 hover:text-slate-600 text-[18px] leading-none">&times;</button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-[12px] text-[#6B7280]">
                Correct the submitted data below — one <span className="font-mono">number=price</span> per line.
                Saving re-calculates the total and marks this entry as <span className="text-amber-700 font-semibold">Updated</span>.
              </p>
              <div>
                <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Entries</label>
                <textarea
                  value={editTextArea}
                  onChange={e => setEditTextArea(e.target.value)}
                  rows={8}
                  className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-[13px] text-slate-900 outline-none transition-all focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 w-full resize-y font-mono"
                  placeholder={'128=100\n137=100\n178=100'}
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-1">Rate</label>
                <FormInput
                  type="number"
                  placeholder="Rate"
                  value={editRate}
                  onChange={e => setEditRate(e.target.value)}
                />
              </div>
              {/* Live preview of the edited calculation */}
              {(() => {
                const nums = parseEditLines(editTextArea)
                if (nums.length === 0) return null
                const total = nums.reduce((s, n) => s + n.price, 0)
                return (
                  <div className="p-3 rounded-lg bg-[rgba(55,48,163,0.04)] border border-[#E5E7EB] text-[12px] flex items-center gap-4">
                    <span className="text-[#6B7280]">New total:</span>
                    <span className="font-mono font-bold text-[#3730A3] text-[14px]">₹ {total.toLocaleString('en-IN')}</span>
                    <span className="text-[#6B7280]">({nums.length} entries)</span>
                  </div>
                )
              })()}
              {editMessage && (
                <div className="text-[12px] px-3 py-2 rounded-lg bg-red-50 text-red-700">{editMessage}</div>
              )}
              <div className="flex gap-2.5 justify-end pt-1">
                <OutlineButton onClick={() => setEditingEntry(null)} disabled={editSaving}>Cancel</OutlineButton>
                <BlueButton onClick={saveEntryEdit} disabled={editSaving}>
                  {editSaving ? 'Saving...' : 'Save Changes'}
                </BlueButton>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Bottom Action Bar — Material Design bottom toolbar, sits ABOVE MobileBottomNav (h-16=64px) */}
      <div className="md:hidden fixed bottom-16 left-0 right-0 z-[51] bg-white/95 backdrop-blur-sm border-t border-[#E5E7EB] shadow-[0_-2px_10px_rgba(0,0,0,0.08)]">
        <div className="flex items-center justify-around px-4 py-2">
          <button onClick={() => openChart('full')} className="flex flex-col items-center justify-center min-w-[48px] min-h-[48px] gap-1 active:opacity-70 transition-opacity" title="Open Chart (Full Data)">
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#059669]/10">
              <BarChart3 size={20} className="text-[#059669]" />
            </span>
            <span className="text-[10px] font-medium text-[#059669]">Open</span>
          </button>
          <button onClick={() => openChart('blank')} className="flex flex-col items-center justify-center min-w-[48px] min-h-[48px] gap-1 active:opacity-70 transition-opacity" title="Open Blank Chart">
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#D97706]/10">
              <BarChart3 size={20} className="text-[#D97706]" />
            </span>
            <span className="text-[10px] font-medium text-[#D97706]">Blank</span>
          </button>
          <button onClick={handleDeleteInventory} className="flex flex-col items-center justify-center min-w-[48px] min-h-[48px] gap-1 active:opacity-70 transition-opacity" title="Delete Inventory">
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#DC2626]/10">
              <Trash2 size={20} className="text-[#DC2626]" />
            </span>
            <span className="text-[10px] font-medium text-[#DC2626]">Delete</span>
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Page-level access guard (access-control.ts is the ONE source of truth) ──
// Even if a deep link / stale hash points an agent at an admin page, the
// renderer refuses — the sidebar hiding is cosmetic, THIS is the enforcement.
function PageAccessDenied({ compact }: { compact?: boolean }) {
  return (
    <div className={compact ? 'flex-1 flex items-center justify-center p-6' : 'p-7'}>
      <div className="max-w-md w-full bg-white border border-[#E5E7EB] rounded-2xl p-8 text-center mx-auto" style={{ boxShadow: '0 1px 3px rgba(0,0,0,.06)' }}>
        <div className="w-14 h-14 rounded-full bg-[#FEE2E2] flex items-center justify-center mx-auto mb-4">
          <ShieldAlert size={26} className="text-[#DC2626]" />
        </div>
        <h2 className="font-cinzel text-[18px] font-bold text-[#111827] mb-2">Access Denied</h2>
        <p className="text-[12.5px] text-[#6B7280] leading-relaxed">
          Your role does not have permission to open this page. It is reserved for Super Admin / Admin accounts.
        </p>
        <p className="text-[11px] text-[#9CA3AF] mt-3">
          If you believe you need this access, please ask the Super Admin.
        </p>
      </div>
    </div>
  )
}

export default function HomePage() {
  const { currentPage, sidebarOpen, setSidebarOpen, isLoggedIn, setCurrentPage, viewingInventoryId, mobileTab, setMobileTab, currentUser } = useAppStore()
  const [inventoryCount, setInventoryCount] = useState(0)
  const [initializing, setInitializing] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const [subscriptionChecked, setSubscriptionChecked] = useState(false)

  // Detect mobile viewport
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768)
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [])

  // Sync mobileTab when currentPage changes (e.g., from desktop navigation)
  useEffect(() => {
    if (isMobile && isLoggedIn) {
      const tab = getMobileTabForPage(currentPage)
      if (tab !== mobileTab) {
        setMobileTab(tab)
      }
    }
  }, [currentPage, isMobile, isLoggedIn, mobileTab, setMobileTab])

  // Check localStorage for existing session
  useEffect(() => {
    const checkAuth = () => {
      try {
        const stored = localStorage.getItem('erp_user')
        if (stored) {
          const user = JSON.parse(stored)
          useAppStore.getState().login(user)
        }
      } catch {
        // ignore
      }
      setInitializing(false)
    }
    checkAuth()
  }, [])

  // ── Subscription gate: check if non-master user has active subscription ──
  useEffect(() => {
    if (isLoggedIn && currentUser && currentUser.role !== 'super' && !subscriptionChecked) {
      apiFetch('/api/user-subscriptions/check')
        .then((data: any) => {
          if (!data.hasAccess && currentPage !== 'paywall') {
            setCurrentPage('paywall')
          }
          setSubscriptionChecked(true)
        })
        .catch(() => {
          setSubscriptionChecked(true)
        })
    }
  }, [isLoggedIn, currentUser, subscriptionChecked, currentPage, setCurrentPage])

  // Master users always have access — skip subscription check
  const effectiveSubscriptionChecked = currentUser?.role === 'super' ? true : subscriptionChecked

  useEffect(() => {
    if (isLoggedIn) {
      apiFetch('/api/inventories?limit=1').then(d => setInventoryCount(d.total || 0)).catch(console.error)
    }
  }, [currentPage, isLoggedIn])

  // ── URL hash breadcrumbs: sync currentPage with window.location.hash ──
  // On mount: if hash is set, restore that page. On page change: update hash.
  useEffect(() => {
    if (!isLoggedIn) return
    // Restore from hash on initial mount
    const restored = pageFromHash()
    if (restored && restored !== currentPage) {
      setCurrentPage(restored as PageName)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoggedIn])

  useEffect(() => {
    if (!isLoggedIn) return
    syncHashForPage(currentPage)
  }, [isLoggedIn, currentPage])

  if (initializing) {
    return (
      <div className="min-h-screen bg-[#F5F6FA] flex items-center justify-center">
        <div className="text-[#3730A3] font-cinzel text-lg">Loading...</div>
      </div>
    )
  }

  if (!isLoggedIn || currentPage === 'login') {
    if (isMobile) return <MobileLoginPage />
    return <LoginPage />
  }

  const renderPage = () => {
    // ── RBAC page guard: role → page matrix (access-control.ts) ──
    if (!canAccessPage(currentUser?.role, currentPage)) return <PageAccessDenied />
    switch (currentPage) {
      case 'dashboard': return <DashboardPage />
      case 'inv-new': return <NewInventoryPage />
      case 'inv-list': return <InventoryListPage />
      case 'card-view': return <CardInventoryPage key={viewingInventoryId} />
      case 'unified-entry': return <UnifiedEntryPage />
      case 'vendor': return <UnifiedCustomerListPage />
      case 'configure': return <ConfigurePage />
      case 'starlines': return <StarlinesPage />
      case 'chart-data': return <ChartDataPage />
      case 'market-results': return <MarketResultsPage />
      case 'game-management': return <GameManagementPage />
      case 'game-allocation': return <GameAllocationPage />
      case 'users': return <UsersPage />
      // ── Phase 2: System Management ──
      case 'sys-mgmt-users': return <UsersPage />
      case 'sys-mgmt-markets': return <MarketPermissionsPage />
      case 'sys-mgmt-activity': return <UserActivityPage />
      case 'sys-mgmt-locked': return <LockedUsersPage />
      case 'sys-mgmt-parser-ex': return <ParserExceptionsPage />
      case 'sys-mgmt-parser-cfg': return <ParserConfigPage />
      case 'sys-mgmt-chart-revs': return <ChartRevisionsPage />
      case 'sys-mgmt-pending': return <PendingSignupsPage />
      // ── Subscription & Payments ──
      case 'sub-plans': return <SubscriptionPlansPage />
      case 'sub-users': return <UserSubscriptionsPage />
      case 'sub-payments': return <PaymentsPage />
      case 'paywall': return <PaywallPage />
      // ── Hierarchy ──
      case 'hierarchy-managers': return <HierarchyManagersPage />
      case 'hierarchy-agents': return <HierarchyAgentsPage />
      case 'hierarchy-customers': return <HierarchyCustomersPage />
      // ── Customer App management ──
      case 'app-customers': return <AppCustomersPage />
      case 'app-bids': return <AppBidsPage />
      case 'app-funds': return <FundRequestsPage />
      case 'app-notify': return <AppNotificationsPage />
      case 'app-content': return <AppContentPage />
      case 'app-build': return <AppBuildPage />
      // ── Expansion: Chitthi Generator + WhatsApp Management panel ──
      case 'chitthi': return <ChitthiPage />
      case 'wa-dashboard': return <WhatsAppDashboardPage />
      case 'wa-messages': return <WhatsAppMessagesPage />
      case 'wa-templates': return <WhatsAppTemplatesPage />
      case 'wa-approvals': return <WhatsAppApprovalsPage />
      case 'wa-learning': return <WhatsAppLearningPage />
      case 'wa-mappings': return <WhatsAppMappingsPage />
      // ── Expansion: Agent Commission (commission on what customers PLAY) ──
      case 'agent-commission': return <AgentCommissionPage />
      default: return <DashboardPage />
    }
  }

  // ── Mobile shell rendering ──
  if (isMobile) {
    const showBack = currentPage !== 'dashboard'
    const pageSubtitle = (() => {
      if (currentPage === 'dashboard') {
        const now = new Date()
        return now.toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' })
      }
      return undefined
    })()

    // Determine FAB action based on current mobile tab
    const fabAction = () => {
      switch (mobileTab) {
        case 'home': setCurrentPage('inv-new'); break
        case 'smart-entry': setCurrentPage('inv-new'); break
        case 'inventory': setCurrentPage('inv-new'); break
        case 'vendors': setCurrentPage('vendor'); break
        case 'profile': setCurrentPage('configure'); break
      }
    }

    // Use mobile-specific Material Design pages for each tab
    const mobileContent = (() => {
      // ── RBAC page guard (mobile): same matrix as desktop ──
      if (!canAccessPage(currentUser?.role, currentPage)) return <PageAccessDenied compact />
      switch (currentPage) {
        case 'dashboard': return <MobileDashboardPage />
        case 'inv-new': return <MobileNewCardPage />
        case 'inv-list': return <MobileCardListPage />
        case 'card-view': return <div className="flex-1 overflow-y-auto pb-20"><CardInventoryPage key={viewingInventoryId} /></div>
        case 'unified-entry': return <div className="flex-1 overflow-y-auto pb-20"><UnifiedEntryPage /></div>
        case 'chitthi': return <div className="flex-1 overflow-y-auto pb-20"><ChitthiPage /></div>
        case 'vendor': return <MobileKhatriPage />
        case 'users': case 'configure': case 'sys-mgmt-users': case 'sys-mgmt-markets': 
        case 'sys-mgmt-activity': case 'sys-mgmt-locked': case 'sys-mgmt-parser-ex': 
        case 'sys-mgmt-parser-cfg': case 'sys-mgmt-chart-revs': case 'sys-mgmt-pending':
        case 'sub-plans': case 'sub-users': case 'sub-payments':
        case 'hierarchy-managers': case 'hierarchy-agents': case 'hierarchy-customers':
        case 'app-customers': case 'app-bids': case 'app-funds': case 'market-results':
        case 'starlines': case 'chart-data':
        case 'game-management': case 'game-allocation':
          return <MobileProfilePage />
        // ── WhatsApp Management panel: real pages on mobile too ──
        case 'wa-dashboard': return <div className="flex-1 overflow-y-auto pb-20"><WhatsAppDashboardPage /></div>
        case 'wa-messages': return <div className="flex-1 overflow-y-auto pb-20"><WhatsAppMessagesPage /></div>
        case 'wa-templates': return <div className="flex-1 overflow-y-auto pb-20"><WhatsAppTemplatesPage /></div>
        case 'wa-approvals': return <div className="flex-1 overflow-y-auto pb-20"><WhatsAppApprovalsPage /></div>
        case 'wa-learning': return <div className="flex-1 overflow-y-auto pb-20"><WhatsAppLearningPage /></div>
        case 'wa-mappings': return <div className="flex-1 overflow-y-auto pb-20"><WhatsAppMappingsPage /></div>
        case 'agent-commission': return <div className="flex-1 overflow-y-auto pb-20"><AgentCommissionPage /></div>
        case 'app-notify': return <div className="flex-1 overflow-y-auto pb-20"><AppNotificationsPage /></div>
        case 'app-content': return <div className="flex-1 overflow-y-auto pb-20"><AppContentPage /></div>
        case 'app-build': return <div className="flex-1 overflow-y-auto pb-20"><AppBuildPage /></div>
        case 'paywall': return <MobilePaywallPage />
        default: return <MobileDashboardPage />
      }
    })()

    return (
      <div className="flex flex-col h-screen bg-[#F5F6FA]">
        {/* Top App Bar */}
        <MobileTopBar
          pageTitle={PAGE_TITLES[currentPage] || 'Dashboard'}
          pageSubtitle={pageSubtitle}
          showBack={showBack}
          onBack={() => setCurrentPage('dashboard')}
        />
        {/* Content */}
        {mobileContent}
        {/* FAB */}
        <MobileFAB onClick={fabAction} />
        {/* Bottom Navigation */}
        <MobileBottomNav mobileTab={mobileTab} setMobileTab={setMobileTab} />
      </div>
    )
  }

  // ── Desktop layout (unchanged) ──
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] grid-rows-[56px_1fr] min-h-screen">
      <div className="col-span-1 lg:col-span-2">
        <Topbar inventoryCount={inventoryCount} />
      </div>
      <div className="hidden lg:block overflow-y-auto">
        <Sidebar inventoryCount={inventoryCount} />
      </div>
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <div className="fixed left-0 top-0 bottom-0 w-60 z-50">
            <Sidebar inventoryCount={inventoryCount} />
          </div>
        </div>
      )}
      <main className="overflow-y-auto bg-[#F5F6FA]">
        {renderPage()}
      </main>
    </div>
  )
}
