'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'

/**
 * Agent Access Link Activation Page
 * 
 * When an Agent opens their access link (e.g., /agent/access/<token>),
 * this page:
 * 1. Calls the activation API
 * 2. On success: stores the user in localStorage and redirects to the main app
 * 3. On failure: shows the error message (invalid link, revoked, device mismatch, etc.)
 */
export default function AgentAccessPage() {
  const params = useParams()
  const router = useRouter()
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading')
  const [message, setMessage] = useState('')
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const token = params.token as string
    if (!token) {
      setStatus('error')
      setMessage('Invalid access link — no token provided.')
      return
    }

    const activate = async () => {
      try {
        const res = await fetch(`/api/agent/access/${token}`)
        const data = await res.json()

        if (!res.ok) {
          setStatus('error')
          setMessage(data.error || 'Access link activation failed.')
          return
        }

        // Success — store the user in localStorage like the normal login
        if (data.user) {
          localStorage.setItem('erp_user', JSON.stringify(data.user))
          setUser(data.user)
          setStatus('success')
          setMessage(data.message || 'Agent access activated successfully!')

          // Redirect to the main app after a brief delay
          setTimeout(() => {
            router.push('/merp')
          }, 1500)
        }
      } catch (err) {
        setStatus('error')
        setMessage('Failed to activate access link. Please check your internet connection.')
      }
    }

    activate()
  }, [params.token, router])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4 text-center">
        {/* Logo */}
        <div className="mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl mx-auto flex items-center justify-center mb-4">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016C16.896 5.312 14.655 3.5 12 3.5c-2.655 0-4.896 1.812-5.618 4.484z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Satta Matka God</h1>
          <p className="text-slate-500 mt-1">Agent Access Portal</p>
        </div>

        {/* Status */}
        {status === 'loading' && (
          <div className="py-8">
            <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto mb-4" />
            <p className="text-slate-600">Activating your access link...</p>
          </div>
        )}

        {status === 'success' && (
          <div className="py-6">
            <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <p className="text-green-700 font-semibold text-lg mb-2">{message}</p>
            {user && (
              <p className="text-slate-500">Welcome, {user.name || user.username}!</p>
            )}
            <p className="text-slate-400 text-sm mt-4">Redirecting to dashboard...</p>
          </div>
        )}

        {status === 'error' && (
          <div className="py-6">
            <div className="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <p className="text-red-700 font-semibold mb-2">Access Denied</p>
            <p className="text-slate-600 text-sm">{message}</p>
            <p className="text-slate-400 text-xs mt-4">
              If you believe this is an error, contact your administrator.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
