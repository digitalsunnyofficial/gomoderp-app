import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// ──────────────────────────────────────────────────────────
// PUBLIC APK SERVING — /apk/<any-name>.apk
// Serves the operator's uploaded release build (ERP ▸ App Build)
// at the canonical URL customers already know:
//     https://<domain>/apk/sm-gomod.apk
// Any *.apk path resolves to the single latest uploaded artifact,
// so links shared with customers never break when a new build is
// uploaded. If nothing has been uploaded yet the request 404s
// (a static file placed on the server by the host still wins if
// the web server serves /apk/* before the app).
// ──────────────────────────────────────────────────────────

export const dynamic = 'force-dynamic'

const APK_CONTENT_TYPE = 'application/vnd.android.package-archive'
const CANONICAL_NAME = 'sm-gomod.apk'

function notFound(message: string) {
  return new NextResponse(message, {
    status: 404,
    headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
  })
}

async function serve(): Promise<NextResponse> {
  let apk
  try {
    apk = await db.apkArtifact.findFirst({ orderBy: { updatedAt: 'desc' } })
  } catch {
    return notFound('APK store unavailable — try again shortly.')
  }
  if (!apk) {
    return notFound('No APK has been uploaded yet. The operator can upload it in ERP ▸ App Build (APK).')
  }
  const bytes = new Uint8Array(apk.data)
  return new NextResponse(bytes, {
    status: 200,
    headers: {
      'Content-Type': APK_CONTENT_TYPE,
      'Content-Length': String(bytes.length),
      'Content-Disposition': `attachment; filename="${CANONICAL_NAME}"`,
      // never cache — a freshly uploaded build must reach customers instantly
      'Cache-Control': 'no-store, must-revalidate',
      'X-Content-Type-Options': 'nosniff',
    },
  })
}

export async function GET(_request: NextRequest, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params
  if (!/\.apk$/i.test(decodeURIComponent(file || ''))) return notFound('Not found')
  return serve()
}

// HEAD — powers the landing page's live "Verified" probe (no body).
export async function HEAD(_request: NextRequest, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params
  if (!/\.apk$/i.test(decodeURIComponent(file || ''))) return new NextResponse(null, { status: 404 })
  let apk
  try {
    apk = await db.apkArtifact.findFirst({ orderBy: { updatedAt: 'desc' } })
  } catch {
    return new NextResponse(null, { status: 500 })
  }
  if (!apk) return new NextResponse(null, { status: 404 })
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Content-Type': APK_CONTENT_TYPE,
      'Content-Length': String(apk.size),
      'Cache-Control': 'no-store, must-revalidate',
    },
  })
}
