import type { Metadata, Viewport } from 'next'
import { Crown, Shield } from 'lucide-react'
import { DownloadCta } from '@/components/public/DownloadCta'

// ──────────────────────────────────────────────────────────
// /customerapp — the OFFICIAL app download link.
// Shared with customers as https://<domain>/customerapp — opens a
// mobile-friendly page whose only job is to deliver the APK
// (public/downloads/satta-matka-god.apk) and walk the customer
// through the 2-step install. The old /download link keeps
// redirecting to the landing page.
// ──────────────────────────────────────────────────────────

export const metadata: Metadata = {
  title: 'Download the App — Satta Matka God',
  description: 'Official Satta Matka God Android app — direct APK download and install guide.',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0B0F1A',
}

export default function CustomerAppDownloadPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0B0F1A] text-white">
      {/* ambient gold glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[720px] h-[520px] rounded-full blur-3xl bg-[radial-gradient(closest-side,rgba(245,196,81,0.14),transparent)]" />
      </div>

      {/* ── HEADER ── */}
      <header className="relative z-10 flex flex-col items-center text-center px-6 pt-14 pb-8">
        <div className="w-16 h-16 rounded-[20px] bg-gradient-to-br from-[#F5C451] to-[#C89212] flex items-center justify-center shadow-[0_8px_32px_rgba(245,196,81,0.4)] mb-5">
          <Crown size={30} className="text-[#1A1305]" />
        </div>
        <h1 className="text-[30px] md:text-[38px] font-black leading-tight tracking-tight">
          Satta Matka <span className="bg-gradient-to-r from-[#F5C451] to-[#E8A820] bg-clip-text text-transparent">God</span>
        </h1>
        <p className="text-[14px] text-[rgba(255,255,255,0.6)] mt-2 max-w-sm leading-relaxed">
          Official Android app — live markets, instant results, UPI wallet and notifications in one app.
        </p>
      </header>

      {/* ── DOWNLOAD CTA ── */}
      <section className="relative z-10 flex-1 w-full max-w-md mx-auto px-6">
        <DownloadCta />

        {/* install steps */}
        <div className="mt-10 space-y-3">
          {[
            { n: '1', t: 'Download', d: 'Tap the Download button above — the app file (APK) is saved to your phone.' },
            { n: '2', t: 'Allow & Install', d: 'Open the file. When Android asks, allow "Install from this source", then tap Install.' },
            { n: '3', t: 'Register & Play', d: 'Sign up with your name and mobile number — your account is approved by the operator in minutes.' },
          ].map(s => (
            <div key={s.n} className="flex gap-4 items-start rounded-2xl p-4 bg-[rgba(255,255,255,0.035)] border border-[rgba(255,255,255,0.07)]">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5C451] to-[#C89212] text-[#1A1305] font-black text-[14px] flex items-center justify-center shrink-0">{s.n}</div>
              <div>
                <div className="text-[14px] font-bold">{s.t}</div>
                <p className="text-[12.5px] text-[rgba(255,255,255,0.5)] leading-relaxed mt-0.5">{s.d}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 rounded-2xl p-4 bg-[rgba(245,196,81,0.06)] border border-[rgba(245,196,81,0.2)] flex gap-3 items-start">
          <Shield size={17} className="text-[#F5C451] shrink-0 mt-0.5" />
          <p className="text-[12.5px] text-[rgba(255,255,255,0.6)] leading-relaxed">
            <strong className="text-white">Play Protect note:</strong> this is a direct APK (not from the Play Store). If Android shows an unknown-source warning, choose <em>Install anyway</em> — the app is official and safe.
          </p>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="relative z-10 mt-12 border-t border-[rgba(255,255,255,0.07)] py-6 px-6 flex items-center justify-center">
        <span className="text-[12px] text-[rgba(255,255,255,0.4)]">© 2026 Satta Matka God · Official app download</span>
      </footer>
    </div>
  )
}
