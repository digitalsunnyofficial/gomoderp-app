import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { appWalletMove } from '@/lib/app-auth'
import { notifyCustomer } from '@/lib/push/expo-push'
import { logActivity } from '@/lib/audit'

// ──────────────────────────────────────────────────────────
// UPI AUTO-VERIFY WEBHOOK (operator rule 2026-10, "auto
// capture"): the payment feed posts every business-UPI credit
// here and matching PENDING deposits are approved + credited
// AUTOMATICALLY — no manual UTR checking.
//
// Feeders:
//  · Payment-watch automation on the operator's phone
//    (MacroDroid / Tasker reading the UPI-credit heads-up or
//    SMS of the BUSINESS UPI app) → POST JSON.
//  · A payment-gateway webhook (Razorpay/Cashfree style) can
//    post the same shape through a small adapter.
//
// POST body:
//  { secret, amount, utr?, note?, payerVpa?, source? }
//    secret  — must equal AppPaymentSetting.autoVerifySecret
//    amount  — credited amount in ₹ (1 point = ₹1)
//    utr     — bank UTR / txn id when available (strong match)
//    note    — payment note if visible (may carry our SMG ref)
//
// Matching (oldest pending first, within the configured window):
//  1. UTR hit      — pending request whose utr == utr (or ref in note)
//  2. Ref in note  — pending request whose utr (our ref) appears in note
//  3. Amount+time  — exact-amount pending request inside the window
// The matched request is approved in a transaction (guarded on
// status=pending so a replay can never double-credit), the wallet
// is credited, the customer is notified in-app + push.
// ──────────────────────────────────────────────────────────

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const settings = await db.appPaymentSetting.findUnique({ where: { id: 'primary' } })
    if (!settings?.autoCredit) {
      return NextResponse.json({ error: 'Auto-credit is OFF — enable it in ERP ▸ Payment Management' }, { status: 409 })
    }
    if (!settings.autoVerifySecret || String(body.secret || '') !== settings.autoVerifySecret) {
      return NextResponse.json({ error: 'Invalid secret' }, { status: 401 })
    }
    const amount = Number(body.amount)
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: 'amount (₹) required' }, { status: 400 })
    }
    const utr = String(body.utr || '').trim()
    const note = String(body.note || '').trim()
    const source = String(body.source || 'automation').slice(0, 40)

    const windowMin = Math.max(1, settings.autoCreditWindowMin || 30)
    const since = new Date(Date.now() - windowMin * 60_000)

    // Oldest-first pending UPI deposits inside the matching window
    const pendings = await db.appFundRequest.findMany({
      where: { status: 'pending', method: 'UPI', amount, createdAt: { gte: since } },
      orderBy: { createdAt: 'asc' },
      take: 50,
    })
    if (!pendings.length) {
      return NextResponse.json({ ok: false, matched: false, reason: 'No pending deposit matches this amount in the window' }, { status: 200 })
    }

    // Strong match: UTR equality or our SMG ref appearing in the note
    const refHit = utr
      ? pendings.find(p => p.utr === utr || (note && note.includes(p.utr)))
      : pendings.find(p => note && note.includes(p.utr))
    const target = refHit || pendings[0]

    // Guarded approve — status must still be pending (replay safety)
    const by = 'auto-verify'
    const approved = await db.$transaction(async (tx) => {
      const upd = await tx.appFundRequest.updateMany({
        where: { id: target.id, status: 'pending' },
        data: { status: 'approved', processedBy: by, processedAt: new Date(), note: `Auto-credited via ${source}${utr ? ' · UTR ' + utr : ''}` },
      })
      if (upd.count === 0) return null
      await appWalletMove(tx as never, target.customerId, 'deposit', target.amount,
        `Fund auto-approved (${target.utr})`)
      return true
    })
    if (!approved) {
      return NextResponse.json({ ok: false, matched: false, reason: 'Deposit was already processed' }, { status: 200 })
    }

    await notifyCustomer({
      customerId: target.customerId, icon: 'arrow-down-circle',
      text: `Your deposit of ₹${target.amount.toLocaleString('en-IN')} was credited automatically`,
      pushTitle: 'Deposit credited',
    })
    await logActivity({
      username: by, action: 'fund_auto_approve', entity: 'app_fund_request', entityId: target.id,
      recordsAffected: 1, metadata: { amount: target.amount, utr: utr || target.utr, source, matchedBy: refHit ? 'ref/utr' : 'amount+time' },
    })
    return NextResponse.json({ ok: true, matched: true, fundId: target.id, amount: target.amount })
  } catch (err) {
    console.error('upi auto-verify POST error', err)
    return NextResponse.json({ error: 'Could not process payment feed' }, { status: 500 })
  }
}

// GET — health/config probe for the feeder setup (never leaks the secret)
export async function GET() {
  const settings = await db.appPaymentSetting.findUnique({
    where: { id: 'primary' },
    select: { autoCredit: true, autoCreditWindowMin: true },
  })
  return NextResponse.json({
    ok: true,
    autoCredit: settings?.autoCredit || false,
    windowMin: settings?.autoCreditWindowMin || 30,
    expects: { secret: 'string', amount: 'number', utr: 'string?', note: 'string?', source: 'string?' },
  })
}
