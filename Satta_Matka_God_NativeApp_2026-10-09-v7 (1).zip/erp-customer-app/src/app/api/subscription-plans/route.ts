import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getSessionFromRequest } from '@/lib/session'

// Mutation guard — verifies the SIGNED ERP session cookie directly (server-
// verified, impossible to spoof). This route sits in the proxy's PUBLIC list
// so the plan catalog can be read without a session; plan MANAGEMENT is a
// Super Admin / Admin capability only — never an agent one (access-control.ts).
async function planSessionRole(request: Request): Promise<string> {
  try {
    const session = await getSessionFromRequest(request as never)
    return session?.role || ''
  } catch {
    return ''
  }
}
function forbiddenPlan() {
  return NextResponse.json({ error: 'Admin access required — subscription plans are managed by the Super Admin / Admin only' }, { status: 403 })
}

// GET /api/subscription-plans — list all plans
export async function GET(request: Request) {
  try {
    const plans = await db.subscriptionPlan.findMany({
      orderBy: { price: 'asc' },
    })
    return NextResponse.json(plans)
  } catch (error) {
    console.error('GET subscription-plans error:', error)
    return NextResponse.json({ error: 'Failed to fetch plans' }, { status: 500 })
  }
}

// POST /api/subscription-plans — create a new plan (Super Admin / Admin only)
export async function POST(request: Request) {
  try {
    if (!['super', 'manager', 'master'].includes(await planSessionRole(request))) {
      return forbiddenPlan()
    }
    const body = await request.json()
    const { name, label, durationDays, price, currency, isActive, features } = body
    if (!name || !label || !durationDays || price === undefined) {
      return NextResponse.json({ error: 'name, label, durationDays, and price are required' }, { status: 400 })
    }
    const plan = await db.subscriptionPlan.create({
      data: {
        name,
        label,
        durationDays: Number(durationDays),
        price: Number(price),
        currency: currency || 'INR',
        isActive: isActive !== false,
        features: features ? JSON.stringify(features) : null,
      },
    })
    return NextResponse.json(plan, { status: 201 })
  } catch (error: any) {
    if (error?.code === 'P2002') {
      return NextResponse.json({ error: 'Plan name already exists' }, { status: 409 })
    }
    console.error('POST subscription-plans error:', error)
    return NextResponse.json({ error: 'Failed to create plan' }, { status: 500 })
  }
}
