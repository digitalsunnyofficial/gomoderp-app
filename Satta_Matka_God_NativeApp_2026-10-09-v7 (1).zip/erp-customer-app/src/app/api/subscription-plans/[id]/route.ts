import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getSessionFromRequest } from '@/lib/session'

// Mutation guard — verifies the SIGNED ERP session cookie directly (server-
// verified, impossible to spoof). Plan management is never an agent
// capability (access-control.ts).
async function planSessionRole(request: Request): Promise<string> {
  try {
    const session = await getSessionFromRequest(request as never)
    return session?.role || ''
  } catch {
    return ''
  }
}
function forbiddenPlan() {
  return NextResponse.json({ error: 'Admin access required — subscription plans are managed by the Super Admin / Admin only' }, { status: 403 })
}

// GET /api/subscription-plans/[id] — get a specific plan
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const plan = await db.subscriptionPlan.findUnique({ where: { id } })
    if (!plan) return NextResponse.json({ error: 'Plan not found' }, { status: 404 })
    return NextResponse.json(plan)
  } catch (error) {
    console.error('GET subscription-plan error:', error)
    return NextResponse.json({ error: 'Failed to fetch plan' }, { status: 500 })
  }
}

// PUT /api/subscription-plans/[id] — update a plan (Super Admin / Admin only)
export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    if (!['super', 'manager', 'master'].includes(await planSessionRole(request))) {
      return forbiddenPlan()
    }
    const { id } = await params
    const body = await request.json()
    const updateData: Record<string, any> = {}
    if (body.label !== undefined) updateData.label = body.label
    if (body.durationDays !== undefined) updateData.durationDays = Number(body.durationDays)
    if (body.price !== undefined) updateData.price = Number(body.price)
    if (body.currency !== undefined) updateData.currency = body.currency
    if (body.isActive !== undefined) updateData.isActive = body.isActive
    if (body.features !== undefined) updateData.features = JSON.stringify(body.features)
    if (body.name !== undefined) updateData.name = body.name

    const plan = await db.subscriptionPlan.update({ where: { id }, data: updateData })
    return NextResponse.json(plan)
  } catch (error: any) {
    if (error?.code === 'P2025') {
      return NextResponse.json({ error: 'Plan not found' }, { status: 404 })
    }
    console.error('PUT subscription-plan error:', error)
    return NextResponse.json({ error: 'Failed to update plan' }, { status: 500 })
  }
}

// DELETE /api/subscription-plans/[id] — delete a plan (Super Admin / Admin only)
export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    if (!['super', 'manager', 'master'].includes(await planSessionRole(request))) {
      return forbiddenPlan()
    }
    const { id } = await params
    // Check if any subscriptions use this plan
    const subCount = await db.userSubscription.count({ where: { planId: id } })
    if (subCount > 0) {
      // Instead of deleting, just deactivate
      await db.subscriptionPlan.update({ where: { id }, data: { isActive: false } })
      return NextResponse.json({ message: 'Plan deactivated (has existing subscriptions)' })
    }
    await db.subscriptionPlan.delete({ where: { id } })
    return NextResponse.json({ message: 'Plan deleted' })
  } catch (error: any) {
    if (error?.code === 'P2025') {
      return NextResponse.json({ error: 'Plan not found' }, { status: 404 })
    }
    console.error('DELETE subscription-plan error:', error)
    return NextResponse.json({ error: 'Failed to delete plan' }, { status: 500 })
  }
}
