import { db } from '@/lib/db'
import { readAuthContext, logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

// GET - List all pending_approval users (Master/Manager only)
// Rule: Managers (Admins) see ONLY pending Agent requests.
//       Pending Admin (requestedRole='manager') requests are Master-Admin-only.
export async function GET(request: Request) {
  try {
    const authCtx = readAuthContext(request)
    if (authCtx.role !== 'super' && authCtx.role !== 'manager') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const pendingUsers = await db.user.findMany({
      where: {
        status: 'pending_approval',
        // Manager can only review agent (requestedRole 'user') requests
        ...(authCtx.role === 'manager' ? { requestedRole: 'user' } : {}),
      },
      select: { id: true, username: true, name: true, email: true, phone: true, requestedRole: true, createdAt: true, role: true },
      orderBy: { createdAt: 'asc' },
    })
    
    return NextResponse.json({ users: pendingUsers })
  } catch (error) {
    console.error('GET pending users error:', error)
    return NextResponse.json({ error: 'Failed to fetch pending users' }, { status: 500 })
  }
}
