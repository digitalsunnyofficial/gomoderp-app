import { db } from '@/lib/db'
import { logActivity, readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await db.user.findUnique({
      where: { id },
      include: { permissions: true },
    })
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    // passwordPlain is an intentional Super-Admin-only view/edit feature —
    // never leak it to other roles (same policy as the users list route).
    const { password, passwordPlain, ...safeUser } = user
    const authCtx = readAuthContext(request)
    const body = authCtx.role === 'super' ? { ...safeUser, passwordPlain } : safeUser
    return NextResponse.json(body)
  } catch (error) {
    console.error('GET user error:', error)
    return NextResponse.json({ error: 'Failed to fetch user' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { username, password, role, name, status, assignedMarkets, managerId, commissionRate, updatedBy } = body

    // Password changes are Super Admin only (password view/edit feature)
    if (password) {
      const authCtx = readAuthContext(request)
      if (authCtx.role !== 'super') {
        return NextResponse.json({ error: 'Forbidden — only Super Admin can change passwords' }, { status: 403 })
      }
    }

    const existing = await db.user.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Role changes are Super Admin only (privilege-escalation guard)
    if (role && role !== existing.role) {
      const authCtxRole = readAuthContext(request).role
      if (authCtxRole !== 'super') {
        return NextResponse.json({ error: 'Forbidden — only Super Admin can change roles' }, { status: 403 })
      }
    }

    const updateData: Record<string, unknown> = {}
    if (username) updateData.username = username
    if (password) {
      updateData.password = await bcrypt.hash(password, 10)
      updateData.passwordPlain = password // keep plaintext copy in sync for Super Admin view
    }
    if (role) updateData.role = role
    if (name !== undefined) updateData.name = name || null
    if (status) updateData.status = status
    if (Array.isArray(assignedMarkets)) {
      updateData.assignedMarkets = Array.from(new Set(
        assignedMarkets.map((m: string) => String(m).trim().toLowerCase()).filter(Boolean)
      )).join(',')
    }
    if (managerId !== undefined) updateData.managerId = managerId || null
    // Commission rate override (agents) — Super Admin only, mirrors the
    // dedicated Agent Commission page action "set_agent_rate".
    if (commissionRate !== undefined) {
      // NOTE: role comes from the proxy-set x-session-role header (same
      // pattern as the funds/commissions routes) — NOT readAuthContext,
      // which reads x-user-role (never set by this project's proxy).
      if ((request.headers.get('x-session-role') || '') !== 'super') {
        return NextResponse.json({ error: 'Forbidden — only Super Admin can change commission rates' }, { status: 403 })
      }
      if (commissionRate === null || commissionRate === '') {
        updateData.commissionRate = null
      } else {
        const r = Number(commissionRate)
        if (!Number.isFinite(r) || r < 0 || r > 100) {
          return NextResponse.json({ error: 'Commission rate must be between 0 and 100 (or null)' }, { status: 400 })
        }
        updateData.commissionRate = r
      }
    }

    const user = await db.user.update({
      where: { id },
      data: updateData,
      include: { permissions: true },
    })

    if (updatedBy) {
      await logActivity({
        userId: id,
        username: updatedBy,
        action: 'update',
        entity: 'user',
        entityId: id,
        metadata: {
          username: existing.username,
          changedFields: Object.keys(updateData),
        },
      })
    }

    const { password: _p, passwordPlain: _pp, ...safeUser } = user
    return NextResponse.json(safeUser)
  } catch (error) {
    console.error('PUT user error:', error)
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 })
  }
}

/**
 * DELETE /api/users/[id]
 * Phase 2: Soft-delete by locking the account instead of hard delete.
 * Pass ?hard=true to actually remove the user (admin only, destructive).
 * Pass lockedBy=USER&reason=TEXT in the query to record who locked.
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const hard = searchParams.get('hard') === 'true'
    const lockedBy = searchParams.get('lockedBy') || 'admin'
    const reason = searchParams.get('reason') || 'Account locked via delete action (soft-delete)'

    const existing = await db.user.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    if (existing.role === 'super' && !hard) {
      return NextResponse.json({ error: 'Cannot delete a super admin. Use explicit lock or remove role first.' }, { status: 400 })
    }

    if (hard) {
      // Destructive hard delete — removes user and cascades to permissions.
      // Activities, chart revisions, and parser exceptions keep the userId as null
      // (SetNull on FK), preserving historical audit trail.
      await db.userPermission.deleteMany({ where: { userId: id } })
      await db.user.delete({ where: { id } })
      await logActivity({
        username: lockedBy,
        action: 'delete_hard',
        entity: 'user',
        entityId: id,
        metadata: { deletedUsername: existing.username },
      })
      return NextResponse.json({ success: true, mode: 'hard' })
    }

    // Soft delete = lock
    const updated = await db.user.update({
      where: { id },
      data: {
        isLocked: true,
        lockedAt: new Date(),
        lockedBy,
        lockReason: reason,
      },
    })

    await logActivity({
      userId: id,
      username: lockedBy,
      action: 'lock',
      entity: 'user',
      entityId: id,
      metadata: { lockedUsername: existing.username, reason },
    })

    const { password, ..._ } = updated
    return NextResponse.json({ success: true, mode: 'soft', user: _ })
  } catch (error) {
    console.error('DELETE user error:', error)
    return NextResponse.json({ error: 'Failed to delete/lock user' }, { status: 500 })
  }
}
