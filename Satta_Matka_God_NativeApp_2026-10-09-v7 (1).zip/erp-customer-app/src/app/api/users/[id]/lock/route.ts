import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * POST /api/users/[id]/lock
 * Locks a user account (soft-delete). User cannot login or perform actions.
 * Historical data created by the user remains intact.
 *
 * Body: { lockedBy, lockReason }
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { lockedBy, lockReason } = body

    if (!lockedBy) {
      return NextResponse.json({ error: 'lockedBy (username) is required' }, { status: 400 })
    }

    const existing = await db.user.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    if (existing.role === 'super') {
      return NextResponse.json({ error: 'Cannot lock a super admin account' }, { status: 400 })
    }

    if (existing.isLocked) {
      return NextResponse.json({ error: 'User is already locked' }, { status: 400 })
    }

    const updated = await db.user.update({
      where: { id },
      data: {
        isLocked: true,
        lockedAt: new Date(),
        lockedBy,
        lockReason: lockReason || 'No reason provided',
      },
    })

    await logActivity({
      userId: id,
      username: lockedBy,
      action: 'lock',
      entity: 'user',
      entityId: id,
      metadata: { lockedUsername: existing.username, reason: lockReason || null },
    })

    const { password, ...safeUser } = updated
    return NextResponse.json(safeUser)
  } catch (error) {
    console.error('POST user-lock error:', error)
    return NextResponse.json({ error: 'Failed to lock user' }, { status: 500 })
  }
}

/**
 * DELETE /api/users/[id]/lock
 * Unlocks a user account.
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const unlockedBy = searchParams.get('unlockedBy') || 'unknown'

    const existing = await db.user.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    if (!existing.isLocked) {
      return NextResponse.json({ error: 'User is not locked' }, { status: 400 })
    }

    const updated = await db.user.update({
      where: { id },
      data: {
        isLocked: false,
        lockedAt: null,
        lockedBy: null,
        lockReason: null,
      },
    })

    await logActivity({
      userId: id,
      username: unlockedBy,
      action: 'unlock',
      entity: 'user',
      entityId: id,
      metadata: { unlockedUsername: existing.username },
    })

    const { password, ...safeUser } = updated
    return NextResponse.json(safeUser)
  } catch (error) {
    console.error('DELETE user-lock error:', error)
    return NextResponse.json({ error: 'Failed to unlock user' }, { status: 500 })
  }
}
