import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const permissions = await db.userPermission.findMany({
      where: { userId: id },
    })
    return NextResponse.json(permissions)
  } catch (error) {
    console.error('GET permissions error:', error)
    return NextResponse.json({ error: 'Failed to fetch permissions' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { permissions } = body // Array of { inventoryCode, canView, canEdit, canDelete }

    if (!Array.isArray(permissions)) {
      return NextResponse.json({ error: 'Permissions must be an array' }, { status: 400 })
    }

    // Delete existing and recreate
    await db.userPermission.deleteMany({ where: { userId: id } })

    if (permissions.length > 0) {
      await db.userPermission.createMany({
        data: permissions.map((p: { inventoryCode: string; canView?: boolean; canEdit?: boolean; canDelete?: boolean }) => ({
          userId: id,
          inventoryCode: p.inventoryCode,
          canView: p.canView ?? true,
          canEdit: p.canEdit ?? false,
          canDelete: p.canDelete ?? false,
        })),
      })
    }

    const updated = await db.userPermission.findMany({ where: { userId: id } })
    return NextResponse.json(updated)
  } catch (error) {
    console.error('PUT permissions error:', error)
    return NextResponse.json({ error: 'Failed to update permissions' }, { status: 500 })
  }
}
