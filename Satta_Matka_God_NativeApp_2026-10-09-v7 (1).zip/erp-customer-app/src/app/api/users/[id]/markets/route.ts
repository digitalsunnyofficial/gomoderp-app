import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * GET /api/users/[id]/markets
 * Returns the user's assigned markets as an array of strings.
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await db.user.findUnique({ where: { id }, select: { assignedMarkets: true } })
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    const markets = (user.assignedMarkets || '').split(',').map(s => s.trim()).filter(Boolean)
    return NextResponse.json({ markets })
  } catch (error) {
    console.error('GET user-markets error:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

/**
 * PUT /api/users/[id]/markets
 * Updates the user's assigned markets.
 * Body: { markets: string[], updatedBy: string }
 */
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { markets, updatedBy } = body

    if (!Array.isArray(markets)) {
      return NextResponse.json({ error: 'markets must be an array' }, { status: 400 })
    }
    if (!updatedBy) {
      return NextResponse.json({ error: 'updatedBy is required' }, { status: 400 })
    }

    const existing = await db.user.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Sanitize: trim, dedupe, lowercase, filter empties
    const cleanMarkets = Array.from(new Set(
      markets.map((m: string) => String(m).trim().toLowerCase()).filter(Boolean)
    ))
    const csv = cleanMarkets.join(',')

    const updated = await db.user.update({
      where: { id },
      data: { assignedMarkets: csv },
    })

    await logActivity({
      userId: id,
      username: updatedBy,
      action: 'update_markets',
      entity: 'user',
      entityId: id,
      metadata: {
        username: existing.username,
        previous: existing.assignedMarkets,
        new: csv,
      },
    })

    const { password, ...safeUser } = updated
    return NextResponse.json({ user: safeUser, markets: cleanMarkets })
  } catch (error) {
    console.error('PUT user-markets error:', error)
    return NextResponse.json({ error: 'Failed to update markets' }, { status: 500 })
  }
}
