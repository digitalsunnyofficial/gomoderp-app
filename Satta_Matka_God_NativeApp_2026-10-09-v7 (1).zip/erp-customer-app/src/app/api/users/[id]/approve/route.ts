import { db } from '@/lib/db'
import { readAuthContext, logActivity, getAuthUser } from '@/lib/audit'
import { NextResponse } from 'next/server'

// POST - Approve a pending user (set status to 'active')
// DELETE - Reject a pending user (set status to 'rejected')
// Approval rules:
//   - Agent signup (requestedRole 'user'): Master OR Manager (Admin) can approve
//   - Admin signup (requestedRole 'manager'): ONLY Master can approve
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authCtx = await getAuthUser(request)
    if (!authCtx || (authCtx.role !== 'super' && authCtx.role !== 'manager')) {
      return NextResponse.json({ error: 'Forbidden — Master or Manager role required' }, { status: 403 })
    }
    
    const { id } = await params
    const user = await db.user.findUnique({ where: { id } })
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    if (user.status !== 'pending_approval') {
      return NextResponse.json({ error: 'User is not pending approval' }, { status: 400 })
    }
    // Only Super Admin can approve Admin-role signups
    if (user.requestedRole === 'manager' && authCtx.role !== 'super') {
      return NextResponse.json({ error: 'Forbidden — only Super Admin can approve Admin signups' }, { status: 403 })
    }
    
    const updated = await db.user.update({
      where: { id },
      data: {
        status: 'active',
        // Set actual role based on requestedRole (only super admin can assign master role)
        ...(user.requestedRole === 'manager' ? { role: 'manager' } : {}),
      },
    })
    
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'approve_user',
      entity: 'user',
      entityId: id,
      metadata: { approvedUsername: user.username, previousStatus: 'pending_approval', newStatus: 'active' },
    })
    
    const { password: _, ...safeUser } = updated
    return NextResponse.json(safeUser)
  } catch (error) {
    console.error('POST approve user error:', error)
    return NextResponse.json({ error: 'Failed to approve user' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authCtx = await getAuthUser(request)
    if (!authCtx || (authCtx.role !== 'super' && authCtx.role !== 'manager')) {
      return NextResponse.json({ error: 'Forbidden — Master or Manager role required' }, { status: 403 })
    }
    
    const { id } = await params
    const user = await db.user.findUnique({ where: { id } })
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    if (user.status !== 'pending_approval') {
      return NextResponse.json({ error: 'User is not pending approval' }, { status: 400 })
    }
    // Only Super Admin can reject Admin-role signups
    if (user.requestedRole === 'manager' && authCtx.role !== 'super') {
      return NextResponse.json({ error: 'Forbidden — only Super Admin can reject Admin signups' }, { status: 403 })
    }
    
    const updated = await db.user.update({
      where: { id },
      data: { status: 'rejected' },
    })
    
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'reject_user',
      entity: 'user',
      entityId: id,
      metadata: { rejectedUsername: user.username, previousStatus: 'pending_approval', newStatus: 'rejected' },
    })
    
    const { password: _, ...safeUser } = updated
    return NextResponse.json(safeUser)
  } catch (error) {
    console.error('DELETE reject user error:', error)
    return NextResponse.json({ error: 'Failed to reject user' }, { status: 500 })
  }
}
