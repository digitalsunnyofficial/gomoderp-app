import { db } from '@/lib/db'
import { logActivity, readAuthContext, userListIsolationFilter } from '@/lib/audit'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'

export async function GET(request: Request) {
  try {
    const authCtx = readAuthContext(request)

    // Data isolation: manager sees only own agents, agent sees only self
    const userFilter = userListIsolationFilter(authCtx)

    const users = await db.user.findMany({
      where: userFilter,
      include: { permissions: true },
      orderBy: { createdAt: 'desc' },
    })
    // Don't return password hash; expose passwordPlain ONLY to master (for password view/edit)
    const safeUsers = users.map(({ password, ...rest }) => {
      if (authCtx.role !== 'super') {
        const { passwordPlain, ...safe } = rest as Record<string, unknown>
        return safe
      }
      return rest
    })
    return NextResponse.json(safeUsers)
  } catch (error) {
    console.error('GET users error:', error)
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Only Super Admin / Manager may create system users (matches UI access:
    // System Users page is only reachable from the Super Admin nav).
    const authCtx = readAuthContext(request)
    if (authCtx.role !== 'super' && authCtx.role !== 'manager') {
      return NextResponse.json({ error: 'Forbidden — only Super Admin or Manager can create users' }, { status: 403 })
    }

    const body = await request.json()
    const { username, password, role, name, permissions, assignedMarkets, managerId, createdBy } = body

    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password are required' }, { status: 400 })
    }

    const hashedPassword = await bcrypt.hash(password, 10)

    // Normalize assignedMarkets to a CSV string
    const marketsCsv = Array.isArray(assignedMarkets)
      ? Array.from(new Set(assignedMarkets.map((m: string) => String(m).trim().toLowerCase()).filter(Boolean))).join(',')
      : ''

    const user = await db.user.create({
      data: {
        username,
        password: hashedPassword,
        passwordPlain: password, // plaintext copy so Super Admin can view/edit passwords
        role: role || 'user',
        name: name || null,
        assignedMarkets: marketsCsv,
        managerId: managerId || null,
        ...(permissions && {
          permissions: {
            create: permissions.map((p: { inventoryCode: string; canView?: boolean; canEdit?: boolean; canDelete?: boolean }) => ({
              inventoryCode: p.inventoryCode,
              canView: p.canView ?? true,
              canEdit: p.canEdit ?? false,
              canDelete: p.canDelete ?? false,
            }))
          }
        }),
      },
      include: { permissions: true },
    })

    if (createdBy) {
      await logActivity({
        userId: user.id,
        username: createdBy,
        action: 'create',
        entity: 'user',
        entityId: user.id,
        metadata: { newUsername: username, role: role || 'user', markets: marketsCsv },
      })
    }

    const { password: _pw, passwordPlain: _pp, ...safeUser } = user
    return NextResponse.json(safeUser, { status: 201 })
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create user'
    if (msg.includes('Unique')) {
      return NextResponse.json({ error: 'Username already exists' }, { status: 409 })
    }
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
