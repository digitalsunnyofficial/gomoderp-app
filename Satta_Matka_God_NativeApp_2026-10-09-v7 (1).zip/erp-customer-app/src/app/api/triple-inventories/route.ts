import { db } from '@/lib/db'
import { logActivity, getAuthUser, canAccessMarket, dataIsolationFilter } from '@/lib/audit'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const inventoryId = searchParams.get('inventoryId')

    if (!inventoryId) {
      return NextResponse.json({ error: 'inventoryId is required' }, { status: 400 })
    }

    // Phase 2 — verify market access to parent inventory
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const parentInv = await db.inventory.findUnique({
      where: { id: inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    // ── Data isolation: admin (manager) sees only own + own agents' entries;
    // agent sees only own entries. Master sees all. ──
    const dFilter = await dataIsolationFilter(authCtx, 'createdBy')
    let tripleInventories
    if (dFilter.createdBy && dFilter.createdBy === '__none__') {
      tripleInventories = []
    } else if (dFilter.createdBy && dFilter.createdBy !== undefined) {
      // Single-creator filter — wrap in AND
      tripleInventories = await db.tripleInventory.findMany({
        where: { AND: [{ inventoryId }, dFilter] },
        include: { vendor: true },
        orderBy: { createdAt: 'desc' },
      })
    } else {
      // Empty filter (master) — return all for this inventory
      tripleInventories = await db.tripleInventory.findMany({
        where: { inventoryId },
        include: { vendor: true },
        orderBy: { createdAt: 'desc' },
      })
    }

    return NextResponse.json(tripleInventories)
  } catch (error) {
    console.error('GET triple-inventories error:', error)
    return NextResponse.json({ error: 'Failed to fetch triple inventories' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { inventoryId, vendorId, type, details, parsedData, rate, totalAmount, createdBy } = body

    if (!inventoryId || !details || !createdBy) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Phase 2 — verify market access to parent inventory
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const parentInv = await db.inventory.findUnique({
      where: { id: inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    const tripleInventory = await db.tripleInventory.create({
      data: {
        inventoryId,
        vendorId: vendorId || null,
        type: type || 'mix',
        details,
        parsedData: parsedData || '{}',
        rate: rate || 0,
        totalAmount: totalAmount || 0,
        createdBy,
      },
      include: { vendor: true },
    })

    // Update inventory totalAmount
    const allTriples = await db.tripleInventory.findMany({
      where: { inventoryId },
    })
    const newTotal = allTriples.reduce((sum, t) => sum + t.totalAmount, 0)
    await db.inventory.update({
      where: { id: inventoryId },
      data: { totalAmount: newTotal, totalTxn: newTotal },
    })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || createdBy,
      action: 'create',
      entity: 'triple_inventory',
      entityId: tripleInventory.id,
      market: parentInv.inventoryCode.market,
      recordsAffected: 1,
      metadata: { inventoryId, type: type || 'mix', totalAmount: totalAmount || 0 },
    })

    return NextResponse.json(tripleInventory, { status: 201 })
  } catch (error) {
    console.error('POST triple-inventory error:', error)
    return NextResponse.json({ error: 'Failed to create triple inventory' }, { status: 500 })
  }
}
