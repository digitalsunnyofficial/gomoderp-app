import { db } from '@/lib/db'
import { logActivity, getAuthUser, canAccessMarket } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * PUT /api/triple-inventories/[id]
 *
 * Edit an existing triple inventory entry from the list UI.
 *
 * Accepts:
 *   - numbers: Array<{ number: string; price: number }>  (the corrected panna list)
 *   - rate: number                                     (per-panna rate)
 *   - vendorId?: string | null                         (optional customer re-assign)
 *
 * The route rebuilds parsedData.numbers/grid/totals from the edited numbers,
 * recomputes totalAmount as the sum of all number prices, stamps
 * isUpdated=true + updatedBy, and refreshes the parent inventory total.
 * Non-master users can only edit entries they (or their agents) created.
 */
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { numbers, rate, vendorId, detailsAppend } = body

    const tripleInv = await db.tripleInventory.findUnique({ where: { id } })
    if (!tripleInv) {
      return NextResponse.json({ error: 'Triple inventory not found' }, { status: 404 })
    }

    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const parentInv = await db.inventory.findUnique({
      where: { id: tripleInv.inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Parent inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    // Data isolation — master can edit anything; manager can edit own + own
    // agents' entries; agent can edit only own entries.
    if (authCtx.role !== 'super') {
      let allowed: string[] = []
      if (authCtx.role === 'manager' && authCtx.userId) {
        const agents = await db.user.findMany({
          where: { managerId: authCtx.userId, status: 'active' },
          select: { username: true },
        })
        allowed = [authCtx.username || '', ...agents.map(a => a.username)].filter(Boolean)
      } else {
        allowed = [authCtx.username || ''].filter(Boolean)
      }
      if (!allowed.includes(tripleInv.createdBy)) {
        return NextResponse.json(
          { error: 'You can only edit entries created by you or your agents' },
          { status: 403 }
        )
      }
    }

    // Validate numbers payload
    if (!Array.isArray(numbers)) {
      return NextResponse.json({ error: 'numbers must be an array' }, { status: 400 })
    }
    const cleanNumbers = numbers
      .map((n: { number: unknown; price: unknown }) => ({
        number: String(n?.number ?? '').trim(),
        price: Math.max(0, Number(n?.price) || 0),
      }))
      .filter((n: { number: string }) => /^\d{1,4}$/.test(n.number))
    if (cleanNumbers.length === 0) {
      return NextResponse.json({ error: 'No valid panna entries found (need number=price per line)' }, { status: 400 })
    }

    const newRate = Math.max(0, Number(rate) || 0)

    // Rebuild parsedData — keep type-specific metadata, replace numbers/grid/totals
    let pd: Record<string, unknown> = {}
    try { pd = JSON.parse(tripleInv.parsedData || '{}') } catch { pd = {} }
    pd.numbers = cleanNumbers
    pd.generatedPannas = cleanNumbers.map((n: { number: string }) => n.number)

    // Rebuild grid (10-column ank layout) + totals
    const grid: Record<number, Array<{ number: string; price: number }>> = {}
    for (let i = 1; i <= 10; i++) grid[i] = []
    for (const n of cleanNumbers as Array<{ number: string; price: number }>) {
      let sum = 0
      for (const ch of n.number) sum += parseInt(ch)
      const ank = sum % 10
      const pos = ank === 0 ? 10 : ank
      grid[pos].push({ number: n.number, price: n.price })
    }
    const totals: Record<number, number> = {}
    let totalAmount = 0
    for (let i = 1; i <= 10; i++) {
      totals[i] = grid[i].reduce((s, e) => s + e.price, 0)
      totalAmount += totals[i]
    }
    pd.grid = grid
    pd.totals = totals

    // Update details to reflect the edit
    let details = tripleInv.details
    if (typeof detailsAppend === 'string' && detailsAppend.trim()) {
      details = `${detailsAppend.trim()} (edited)`
    }

    const updated = await db.tripleInventory.update({
      where: { id },
      data: {
        details,
        parsedData: JSON.stringify(pd),
        rate: newRate,
        totalAmount,
        vendorId: vendorId === undefined ? tripleInv.vendorId : (vendorId || null),
        isUpdated: true,
        updatedBy: authCtx.username || tripleInv.createdBy,
      },
      include: { vendor: true },
    })

    // Refresh parent inventory totals
    const allTriples = await db.tripleInventory.findMany({
      where: { inventoryId: tripleInv.inventoryId },
    })
    const newTotal = allTriples.reduce((sum, t) => sum + t.totalAmount, 0)
    await db.inventory.update({
      where: { id: tripleInv.inventoryId },
      data: { totalAmount: newTotal, totalTxn: newTotal },
    })

    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'update',
      entity: 'triple_inventory',
      entityId: id,
      market: parentInv.inventoryCode.market,
      metadata: {
        inventoryId: tripleInv.inventoryId,
        oldTotal: tripleInv.totalAmount,
        newTotal: totalAmount,
        pannaCount: cleanNumbers.length,
      },
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error('PUT triple-inventory error:', error)
    return NextResponse.json({ error: 'Failed to update triple inventory' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const tripleInv = await db.tripleInventory.findUnique({ where: { id } })
    if (!tripleInv) {
      return NextResponse.json({ error: 'Triple inventory not found' }, { status: 404 })
    }

    // Phase 2 — verify market access via parent inventory
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const parentInv = await db.inventory.findUnique({
      where: { id: tripleInv.inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Parent inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    await db.tripleInventory.delete({ where: { id } })

    // Update inventory totalAmount
    const allTriples = await db.tripleInventory.findMany({
      where: { inventoryId: tripleInv.inventoryId },
    })
    const newTotal = allTriples.reduce((sum, t) => sum + t.totalAmount, 0)
    await db.inventory.update({
      where: { id: tripleInv.inventoryId },
      data: { totalAmount: newTotal, totalTxn: newTotal },
    })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'delete',
      entity: 'triple_inventory',
      entityId: id,
      market: parentInv.inventoryCode.market,
      metadata: { inventoryId: tripleInv.inventoryId, type: tripleInv.type },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE triple-inventory error:', error)
    return NextResponse.json({ error: 'Failed to delete triple inventory' }, { status: 500 })
  }
}
