import { NextResponse } from 'next/server'
import { marketCronTick } from '@/lib/market-cron'

// ──────────────────────────────────────────────────────────
// MARKET CRON HOOK — manual / external trigger for the same
// tick the internal scheduler runs every minute.
// Local calls are allowed; external ones must pass ?key=<CRON_SECRET>.
// ──────────────────────────────────────────────────────────

async function run(req: Request) {
  const url = new URL(req.url)
  const key = url.searchParams.get('key')
  const secret = process.env.CRON_SECRET || 'mb-cron'
  const host = req.headers.get('host') || ''
  const isLocal = host.includes('localhost') || host.includes('127.0.0.1')
  if (!isLocal && key !== secret) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  try {
    const r = await marketCronTick()
    return NextResponse.json({ ok: true, ...r, at: new Date().toISOString() })
  } catch (err) {
    console.error('cron markets error', err)
    return NextResponse.json({ error: 'cron failed' }, { status: 500 })
  }
}

export async function GET(request: Request) { return run(request) }
export async function POST(request: Request) { return run(request) }
