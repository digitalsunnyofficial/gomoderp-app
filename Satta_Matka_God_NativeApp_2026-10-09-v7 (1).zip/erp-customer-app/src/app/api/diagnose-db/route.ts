import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'

export const dynamic = 'force-dynamic'

export async function GET() {
  const results: any = {
    timestamp: new Date().toISOString(),
    cwd: process.cwd(),
    env_DATABASE_URL: process.env.DATABASE_URL,
    NODE_ENV: process.env.NODE_ENV,
    user: process.env.USER || process.env.LOGNAME || 'unknown',
    platform: process.platform,
    checks: []
  }

  // 1. Check env DATABASE_URL
  const envUrl = process.env.DATABASE_URL
  if (envUrl) {
    const filePath = envUrl.replace(/^file:/, '')
    const exists = fs.existsSync(filePath)
    let stat = null
    let accessErr = null
    try {
      stat = fs.statSync(filePath)
    } catch (e: any) {
      accessErr = e.message
    }
    let readable = false
    let writable = false
    try {
      fs.accessSync(filePath, fs.constants.R_OK)
      readable = true
    } catch {}
    try {
      fs.accessSync(filePath, fs.constants.W_OK)
      writable = true
    } catch {}
    results.checks.push({
      name: 'env DATABASE_URL file',
      path: filePath,
      exists,
      isFile: stat?.isFile() ?? false,
      size: stat?.size ?? 0,
      readable,
      writable,
      error: accessErr
    })
    // Check parent directory permissions
    const parentDir = path.dirname(filePath)
    try {
      const parentStat = fs.statSync(parentDir)
      let parentReadable = false, parentWritable = false, parentExec = false
      try { fs.accessSync(parentDir, fs.constants.R_OK); parentReadable = true } catch {}
      try { fs.accessSync(parentDir, fs.constants.W_OK); parentWritable = true } catch {}
      try { fs.accessSync(parentDir, fs.constants.X_OK); parentExec = true } catch {}
      results.checks.push({
        name: 'parent directory of DATABASE_URL',
        path: parentDir,
        exists: true,
        isDir: parentStat.isDirectory(),
        mode: parentStat.mode.toString(8),
        readable: parentReadable,
        writable: parentWritable,
        executable: parentExec,
        note: parentWritable ? 'OK - SQLite can create journal files' : 'FAIL - SQLite needs write access here'
      })
    } catch (e: any) {
      results.checks.push({
        name: 'parent directory of DATABASE_URL',
        path: parentDir,
        exists: false,
        error: e.message
      })
    }
  } else {
    results.checks.push({ name: 'env DATABASE_URL', error: 'NOT SET' })
  }

  // 2. Walk up from cwd looking for db/custom.db
  let dir = process.cwd()
  const candidates: any[] = []
  for (let i = 0; i < 8; i++) {
    const candidate = path.join(dir, 'db', 'custom.db')
    const exists = fs.existsSync(candidate)
    candidates.push({
      dir,
      candidate,
      exists,
      isFile: exists ? fs.statSync(candidate).isFile() : false,
      size: exists ? fs.statSync(candidate).size : 0
    })
    if (exists) {
      results.dbFoundAt = candidate
      results.checks.push({
        name: 'auto-detect found db',
        path: candidate,
        exists: true,
        size: fs.statSync(candidate).size,
        readable: (() => { try { fs.accessSync(candidate, fs.constants.R_OK); return true } catch { return false } })(),
        writable: (() => { try { fs.accessSync(candidate, fs.constants.W_OK); return true } catch { return false } })()
      })
      break
    }
    const parent = path.dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  results.walkUpChecks = candidates

  // 3. List contents of cwd
  try {
    results.cwdContents = fs.readdirSync(process.cwd()).map(name => {
      const p = path.join(process.cwd(), name)
      try {
        const s = fs.statSync(p)
        return { name, type: s.isDirectory() ? 'dir' : 'file', size: s.size, mode: s.mode.toString(8) }
      } catch {
        return { name, type: 'unknown' }
      }
    })
  } catch (e: any) {
    results.cwdContentsError = e.message
  }

  // 4. List contents of cwd/db if it exists
  const dbDir = path.join(process.cwd(), 'db')
  if (fs.existsSync(dbDir)) {
    try {
      results.dbDirContents = fs.readdirSync(dbDir).map(name => {
        const p = path.join(dbDir, name)
        try {
          const s = fs.statSync(p)
          return { name, type: s.isDirectory() ? 'dir' : 'file', size: s.size, mode: s.mode.toString(8) }
        } catch {
          return { name, type: 'unknown' }
        }
      })
    } catch (e: any) {
      results.dbDirError = e.message
    }
  } else {
    results.dbDirExists = false
  }

  // 5. Try to actually query the database
  try {
    const { PrismaClient } = require('@prisma/client')
    const prisma = new PrismaClient({ log: ['error', 'warn'] })
    const userCount = await prisma.user.count()
    results.prismaTest = { success: true, userCount }
    await prisma.$disconnect()
  } catch (e: any) {
    results.prismaTest = { success: false, error: e.message, code: e.code }
  }

  return NextResponse.json(results, { status: 200 })
}
