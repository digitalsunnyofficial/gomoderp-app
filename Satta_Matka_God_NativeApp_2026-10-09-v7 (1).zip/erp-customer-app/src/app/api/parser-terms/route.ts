import { db } from '@/lib/db'
import { logActivity, getAuthUser } from '@/lib/audit'
import { isSuperRole } from '@/lib/roles'
import { NextResponse } from 'next/server'
import { normalizeTerm, GROUP_OPTION_ORDER } from '@/lib/matka/term-registry'

export const dynamic = 'force-dynamic'

const VALID_CATEGORIES = new Set<string>([...GROUP_OPTION_ORDER, 'mix', 'common'])

/**
 * GET /api/parser-terms — list dictionary terms (custom, admin-taught).
 * Public to any logged-in user (the Smart Entry page needs it for parsing).
 */
export async function GET() {
  try {
    const terms = await db.parserTerm.findMany({
      where: { isActive: true },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json(terms)
  } catch (error) {
    console.error('GET parser-terms error:', error)
    return NextResponse.json({ error: 'Failed to fetch parser terms' }, { status: 500 })
  }
}

/**
 * POST /api/parser-terms — teach the dictionary a new term (manual evolution).
 * Body: { term, category, note?, createdBy }
 * Super Admin / Admin only — term additions change how future entries route.
 */
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { term, category, note, createdBy } = body

    if (!term || typeof term !== 'string' || !category) {
      return NextResponse.json({ error: 'term and category are required' }, { status: 400 })
    }
    if (!VALID_CATEGORIES.has(category)) {
      return NextResponse.json(
        { error: `category must be one of: ${[...VALID_CATEGORIES].join(', ')}` },
        { status: 400 }
      )
    }

    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!isSuperRole(authCtx.role) && authCtx.role !== 'manager') {
      return NextResponse.json({ error: 'Forbidden — admin roles only' }, { status: 403 })
    }

    const normalized = normalizeTerm(term)
    if (!normalized) {
      return NextResponse.json({ error: 'term normalizes to empty' }, { status: 400 })
    }

    const upserted = await db.parserTerm.upsert({
      where: { term: normalized },
      update: { category, isActive: true, note: note || null, createdBy: createdBy || authCtx.username },
      create: {
        term: normalized,
        category,
        note: note || null,
        createdBy: createdBy || authCtx.username,
      },
    })

    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || createdBy || 'unknown',
      action: 'PARSER_TERM_ADD',
      recordsAffected: 1,
      metadata: { term: normalized, category },
    })

    return NextResponse.json(upserted, { status: 201 })
  } catch (error) {
    console.error('POST parser-terms error:', error)
    return NextResponse.json({ error: 'Failed to save parser term' }, { status: 500 })
  }
}
