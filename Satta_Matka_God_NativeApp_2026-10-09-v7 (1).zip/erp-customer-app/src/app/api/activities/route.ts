import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { requireMaster } from '@/lib/auth'

// GET /api/activities — master only
// Query params:
//   ?userId=...        — filter by user
//   ?action=...        — filter by action type
//   ?market=...        — filter by market
//   ?from=ISO&to=ISO   — date range
//   ?page=1&limit=50   — pagination
//   ?summary=true      — return aggregated stats instead of rows
export async function GET(request: Request) {
  const guard = await requireMaster(request)
  if (!guard.ok) return guard.response

  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const action = searchParams.get('action')
    const market = searchParams.get('market')
    const from = searchParams.get('from')
    const to = searchParams.get('to')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')
    const summary = searchParams.get('summary') === 'true'

    const where: Record<string, unknown> = {}
    if (userId) where.userId = userId
    if (action) where.action = action
    if (market) where.market = market
    if (from || to) {
      where.createdAt = {}
      if (from) (where.createdAt as { gte?: Date }).gte = new Date(from)
      if (to) (where.createdAt as { lte?: Date }).lte = new Date(to)
    }

    if (summary) {
      // Aggregated per-user stats
      const perUser = await db.userActivity.groupBy({
        by: ['userId', 'username'],
        where,
        _count: { _all: true },
        _max: { createdAt: true },
        orderBy: { _count: { id: 'desc' } },
      })

      // Per-market
      const perMarket = await db.userActivity.groupBy({
        by: ['market'],
        where,
        _count: { _all: true },
      })

      // Per-action
      const perAction = await db.userActivity.groupBy({
        by: ['action'],
        where,
        _count: { _all: true },
      })

      // Total records affected
      const totals = await db.userActivity.aggregate({
        where,
        _sum: { recordsAffected: true },
        _count: { _all: true },
      })

      return NextResponse.json({
        perUser: perUser.map(u => ({
          userId: u.userId,
          username: u.username,
          totalActions: u._count._all,
          lastActivity: u._max.createdAt,
        })),
        perMarket: perMarket.map(m => ({ market: m.market, count: m._count._all })),
        perAction: perAction.map(a => ({ action: a.action, count: a._count._all })),
        totalActions: totals._count._all,
        totalRecordsAffected: totals._sum.recordsAffected || 0,
      })
    }

    const [activities, total] = await Promise.all([
      db.userActivity.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.userActivity.count({ where }),
    ])

    return NextResponse.json({ data: activities, total, page, limit })
  } catch (error) {
    console.error('GET activities error:', error)
    return NextResponse.json({ error: 'Failed to fetch activities' }, { status: 500 })
  }
}
