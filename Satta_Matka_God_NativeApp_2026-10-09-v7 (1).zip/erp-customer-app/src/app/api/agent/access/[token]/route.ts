import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { setSessionCookie } from '@/lib/session'
import { ROLES, normalizeRole } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'
import crypto from 'crypto'

/**
 * GET /api/agent/access/:token — Activate or validate an Agent access link
 * 
 * This is the endpoint hit when an Agent opens their access link.
 * 
 * Flow:
 * 1. Hash the supplied token
 * 2. Find matching AgentAccessLink
 * 3. Validate (not revoked, not expired, user exists and is active Agent)
 * 4. Device binding: first use binds the device, subsequent uses must match
 * 5. Create authenticated session
 * 6. Return user data for client-side redirect
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  try {
    const { token } = await params

    if (!token || token.length < 10) {
      return NextResponse.json({ error: 'This Agent access link is invalid.' }, { status: 401 })
    }

    // Step 1: Hash the token
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex')

    // Step 2: Find matching link
    const accessLink = await db.agentAccessLink.findUnique({
      where: { tokenHash },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true,
            name: true,
            status: true,
            isLocked: true,
            assignedMarkets: true,
            permissions: true,
          },
        },
      },
    })

    if (!accessLink) {
      await logActivity({
        username: 'anonymous',
        action: 'agent_link_invalid',
        entity: 'user',
        metadata: { tokenPrefix: token.substring(0, 8) + '...' },
      })
      return NextResponse.json({ error: 'This Agent access link is invalid.' }, { status: 401 })
    }

    // Step 3: Validate
    if (accessLink.revokedAt) {
      return NextResponse.json({ error: 'This Agent access link has been revoked. Ask your admin for a new link.' }, { status: 401 })
    }

    if (accessLink.expiresAt && accessLink.expiresAt < new Date()) {
      return NextResponse.json({ error: 'This Agent access link has expired. Ask your admin for a new link.' }, { status: 401 })
    }

    if (!accessLink.user) {
      return NextResponse.json({ error: 'This Agent access link is invalid.' }, { status: 401 })
    }

    const agent = accessLink.user
    const normalizedRole = normalizeRole(agent.role)

    if (normalizedRole !== ROLES.AGENT) {
      return NextResponse.json({ error: 'This link is not associated with an Agent account.' }, { status: 401 })
    }

    if (agent.isLocked) {
      return NextResponse.json({ error: 'This Agent account is locked.' }, { status: 403 })
    }

    if (agent.status !== 'active') {
      return NextResponse.json({ error: 'This Agent account is not active.' }, { status: 403 })
    }

    // Step 4: Device binding
    const deviceId = extractDeviceId(request)

    if (!accessLink.boundDeviceId) {
      // First activation — bind this device
      await db.agentAccessLink.update({
        where: { id: accessLink.id },
        data: {
          boundDeviceId: deviceId,
          activatedAt: new Date(),
          lastUsedAt: new Date(),
        },
      })
    } else if (accessLink.boundDeviceId !== deviceId) {
      // Different device — reject
      await logActivity({
        userId: agent.id,
        username: agent.username,
        action: 'agent_link_device_mismatch',
        entity: 'user',
        entityId: agent.id,
        metadata: {
          expectedDevice: accessLink.boundDeviceId.substring(0, 8) + '...',
          actualDevice: deviceId.substring(0, 8) + '...',
        },
      })
      return NextResponse.json({ error: 'This link is already active on another device. Ask your admin to generate a new link.' }, { status: 403 })
    } else {
      // Same device — update last used
      await db.agentAccessLink.update({
        where: { id: accessLink.id },
        data: { lastUsedAt: new Date() },
      })
    }

    // Step 5: Create authenticated session
    await logActivity({
      userId: agent.id,
      username: agent.username,
      action: 'agent_link_activated',
      entity: 'user',
      entityId: agent.id,
    })

    // Build the safe user object (without password)
    const { permissions, ...userWithoutPerms } = agent
    const safeUser = {
      ...userWithoutPerms,
      role: normalizedRole,
      permissions,
    }

    // Create response with user data and set session cookie
    const response = NextResponse.json({
      user: safeUser,
      message: 'Agent access activated successfully',
      redirect: '/',
    })

    // Set the same signed session cookie that the normal login uses
    return setSessionCookie(response, {
      id: agent.id,
      username: agent.username,
      role: normalizedRole,
    })
  } catch (error) {
    console.error('GET agent/access error:', error)
    return NextResponse.json({ error: 'Access link activation failed' }, { status: 500 })
  }
}

/**
 * Extract a device identifier from the request.
 * Uses a combination of fingerprint headers or generates one from IP + user-agent hash.
 */
function extractDeviceId(request: Request): string {
  // Check for explicit device-id header (from the client app)
  const explicitDeviceId = request.headers.get('x-device-id')
  if (explicitDeviceId) return explicitDeviceId

  // Build a device fingerprint from available headers
  const userAgent = request.headers.get('user-agent') || 'unknown'
  const acceptLanguage = request.headers.get('accept-language') || ''
  const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown'

  // Hash the combination to create a stable device ID
  const raw = `${userAgent}|${acceptLanguage}|${ip}`
  return crypto.createHash('sha256').update(raw).digest('hex')
}
