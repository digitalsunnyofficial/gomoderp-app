import { db } from '@/lib/db'
import { readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * GET /api/managers/stats
 * Returns team-scoped statistics for all managers (or a specific manager via ?managerId=).
 * Includes: card codes accessible, inventory counts, settlement counts, activity counts,
 * vendor counts, and recent activity for each manager's team.
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const managerId = searchParams.get('managerId') || null
    const authCtx = readAuthContext(request)

    // Only master and manager can access this endpoint
    if (!authCtx.isMaster && authCtx.role !== 'manager') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Get all managers (or specific one)
    const whereClause: Record<string, unknown> = { role: 'manager' }
    if (managerId) whereClause.id = managerId

    const managers = await db.user.findMany({
      where: whereClause,
      select: {
        id: true,
        username: true,
        name: true,
        assignedMarkets: true,
        status: true,
        isLocked: true,
        createdAt: true,
        teamMembers: {
          select: {
            id: true,
            username: true,
            name: true,
            role: true,
            status: true,
            isLocked: true,
            assignedMarkets: true,
            permissions: {
              select: {
                inventoryCode: true,
                canView: true,
                canEdit: true,
                canDelete: true,
              }
            }
          }
        },
      },
    })

    // Get all inventory codes for card code details
    const allCodes = await db.inventoryCode.findMany({
      orderBy: { code: 'asc' },
      select: { id: true, code: true, name: true, market: true, type: true, status: true }
    })

    // Build stats per manager
    const managerStats = await Promise.all(managers.map(async (mgr) => {
      const teamMemberIds = mgr.teamMembers.map(t => t.id)
      const teamUsernames = mgr.teamMembers.map(t => t.username)

      // Count inventories created by team members
      const inventoryCount = teamMemberIds.length > 0
        ? await db.inventory.count({
            where: { createdBy: { in: teamUsernames } }
          })
        : 0

      // Total inventory count
      const totalInventoryCount = await db.inventory.count()

      // Settlement count
      const settlementCount = await db.settlement.count()

      // Vendor count
      const vendorCount = await db.vendor.count()

      // Triple inventory count
      const tripleCount = await db.tripleInventory.count()

      // DS inventory count
      const dsCount = await db.doubleSingleInventory.count()

      // Recent activity for team members (last 50)
      const recentActivity = teamMemberIds.length > 0
        ? await db.userActivity.findMany({
            where: { userId: { in: teamMemberIds } },
            orderBy: { createdAt: 'desc' },
            take: 50,
            select: {
              id: true,
              userId: true,
              username: true,
              action: true,
              entity: true,
              entityId: true,
              market: true,
              createdAt: true,
            }
          })
        : []

      // Activity summary by action type (last 7 days)
      const sevenDaysAgo = new Date()
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

      const activityByAction = teamMemberIds.length > 0
        ? await db.userActivity.groupBy({
            by: ['action'],
            where: {
              userId: { in: teamMemberIds },
              createdAt: { gte: sevenDaysAgo },
            },
            _count: { action: true },
          })
        : []

      // Card codes that team members have permissions for
      const teamPerms = mgr.teamMembers.flatMap(t =>
        t.permissions.map(p => p.inventoryCode)
      )
      const accessibleCodes = allCodes.filter(c =>
        teamPerms.includes(c.code) || authCtx.isMaster
      )

      // Recent inventories by team (last 10)
      const recentInventories = teamMemberIds.length > 0
        ? await db.inventory.findMany({
            where: { createdBy: { in: teamUsernames } },
            include: {
              inventoryCode: { select: { code: true, name: true, market: true } },
              cards: { select: { position: true, value: true } },
            },
            orderBy: { createdAt: 'desc' },
            take: 10,
          })
        : []

      return {
        manager: {
          id: mgr.id,
          username: mgr.username,
          name: mgr.name,
          assignedMarkets: mgr.assignedMarkets,
          status: mgr.status,
          isLocked: mgr.isLocked,
          createdAt: mgr.createdAt,
        },
        teamSize: mgr.teamMembers.length,
        teamMembers: mgr.teamMembers,
        stats: {
          inventoryCount,
          totalInventoryCount,
          settlementCount,
          vendorCount,
          tripleCount,
          dsCount,
        },
        activityByAction,
        recentActivity,
        accessibleCodes,
        recentInventories,
      }
    }))

    return NextResponse.json({
      allCodes,
      managers: managerStats,
    })
  } catch (error) {
    console.error('GET managers/stats error:', error)
    return NextResponse.json({ error: 'Failed to fetch manager stats' }, { status: 500 })
  }
}
