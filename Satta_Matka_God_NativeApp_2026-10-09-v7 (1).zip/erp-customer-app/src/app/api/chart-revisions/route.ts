import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * GET /api/chart-revisions?chartId=...
 * Returns revision history for a chart, newest first.
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const chartId = searchParams.get('chartId')
    const editedBy = searchParams.get('editedBy')
    const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 200)

    const where: Record<string, unknown> = {}
    if (chartId) where.chartId = chartId
    if (editedBy) where.editedBy = editedBy

    const revisions = await db.chartRevision.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json(revisions)
  } catch (error) {
    console.error('GET chart-revisions error:', error)
    return NextResponse.json({ error: 'Failed to fetch chart revisions' }, { status: 500 })
  }
}

/**
 * POST /api/chart-revisions
 * Records a new chart revision. Called when admin saves, regenerates, or manually
 * edits a chart.
 *
 * Body: { chartId, editedBy, editedByUserId, action, previousData, newData, summary }
 */
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { chartId, editedBy, editedByUserId, action, previousData, newData, summary } = body

    if (!chartId || !editedBy || !action) {
      return NextResponse.json({ error: 'chartId, editedBy, action are required' }, { status: 400 })
    }

    const revision = await db.chartRevision.create({
      data: {
        chartId,
        editedBy,
        editedByUserId: editedByUserId || null,
        action,
        previousData: previousData ? JSON.stringify(previousData) : '{}',
        newData: newData ? JSON.stringify(newData) : '{}',
        summary: summary || null,
      },
    })

    // Also log to user activity
    await logActivity({
      userId: editedByUserId || null,
      username: editedBy,
      action: `chart_${action}`,
      entity: 'chart',
      entityId: chartId,
      metadata: { revisionId: revision.id, summary: summary || null },
    })

    return NextResponse.json(revision, { status: 201 })
  } catch (error) {
    console.error('POST chart-revisions error:', error)
    return NextResponse.json({ error: 'Failed to record chart revision' }, { status: 500 })
  }
}
