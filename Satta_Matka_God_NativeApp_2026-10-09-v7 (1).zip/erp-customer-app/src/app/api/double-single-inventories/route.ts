import { db } from '@/lib/db'
import { logActivity, getAuthUser, canAccessMarket, dataIsolationFilter } from '@/lib/audit'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const inventoryId = searchParams.get('inventoryId')

    if (!inventoryId) {
      return NextResponse.json({ error: 'inventoryId is required' }, { status: 400 })
    }

    // Phase 2 — verify market access
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const parentInv = await db.inventory.findUnique({
      where: { id: inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    // ── Data isolation: admin (manager) sees only own + own agents' entries;
    // agent sees only own entries. Master sees all. ──
    const dFilter = await dataIsolationFilter(authCtx, 'createdBy')
    let doubleSingleInventories
    if (dFilter.createdBy && dFilter.createdBy === '__none__') {
      doubleSingleInventories = []
    } else if (dFilter.createdBy && dFilter.createdBy !== undefined) {
      doubleSingleInventories = await db.doubleSingleInventory.findMany({
        where: { AND: [{ inventoryId }, dFilter] },
        include: { vendor: true },
        orderBy: { createdAt: 'desc' },
      })
    } else {
      doubleSingleInventories = await db.doubleSingleInventory.findMany({
        where: { inventoryId },
        include: { vendor: true },
        orderBy: { createdAt: 'desc' },
      })
    }

    return NextResponse.json(doubleSingleInventories)
  } catch (error) {
    console.error('GET double-single-inventories error:', error)
    return NextResponse.json({ error: 'Failed to fetch double single inventories' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { inventoryId, vendorId, type, details, parsedData, rate, totalAmount, createdBy } = body

    if (!inventoryId || !createdBy) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Phase 2 — verify market access
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const parentInv = await db.inventory.findUnique({
      where: { id: inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    const doubleSingleInventory = await db.doubleSingleInventory.create({
      data: {
        inventoryId,
        vendorId: vendorId || null,
        type: type || 'single',
        details: details || '',
        parsedData: parsedData || '{}',
        rate: rate || 0,
        totalAmount: totalAmount || 0,
        createdBy,
      },
      include: { vendor: true },
    })

    // Update inventory totalAmount — sum all triple + double-single entries
    const allTriples = await db.tripleInventory.findMany({
      where: { inventoryId },
    })
    const allDs = await db.doubleSingleInventory.findMany({
      where: { inventoryId },
    })
    const tripleTotal = allTriples.reduce((sum, t) => sum + t.totalAmount, 0)
    const dsTotal = allDs.reduce((sum, d) => sum + d.totalAmount, 0)
    const newTotal = tripleTotal + dsTotal
    await db.inventory.update({
      where: { id: inventoryId },
      data: { totalAmount: newTotal, totalTxn: newTotal },
    })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || createdBy,
      action: 'create',
      entity: 'double_single_inventory',
      entityId: doubleSingleInventory.id,
      market: parentInv.inventoryCode.market,
      recordsAffected: 1,
      metadata: { inventoryId, type: type || 'single', totalAmount: totalAmount || 0 },
    })

    return NextResponse.json(doubleSingleInventory, { status: 201 })
  } catch (error) {
    console.error('POST double-single-inventory error:', error)
    return NextResponse.json({ error: 'Failed to create double single inventory' }, { status: 500 })
  }
}
