import { db } from '@/lib/db'
import { logActivity, getAuthUser, canAccessMarket } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * PUT /api/double-single-inventories/[id]
 *
 * Edit an existing single/double inventory entry from the list UI.
 *
 * Accepts:
 *   - numbers: Array<{ number: string; price: number }>  (the corrected number list)
 *   - rate: number                                     (per-number rate)
 *   - vendorId?: string | null                         (optional customer re-assign)
 *
 * The route rebuilds parsedData.numbers, recomputes totalAmount as the sum of
 * all number prices, stamps isUpdated=true + updatedBy, and refreshes the
 * parent inventory total. Non-master users can only edit entries they (or
 * their agents) created.
 */
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { numbers, rate, vendorId } = body

    const dsInv = await db.doubleSingleInventory.findUnique({ where: { id } })
    if (!dsInv) {
      return NextResponse.json({ error: 'Double single inventory not found' }, { status: 404 })
    }

    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const parentInv = await db.inventory.findUnique({
      where: { id: dsInv.inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Parent inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    // Data isolation — master can edit anything; manager can edit own + own
    // agents' entries; agent can edit only own entries.
    if (authCtx.role !== 'super') {
      let allowed: string[] = []
      if (authCtx.role === 'manager' && authCtx.userId) {
        const agents = await db.user.findMany({
          where: { managerId: authCtx.userId, status: 'active' },
          select: { username: true },
        })
        allowed = [authCtx.username || '', ...agents.map(a => a.username)].filter(Boolean)
      } else {
        allowed = [authCtx.username || ''].filter(Boolean)
      }
      if (!allowed.includes(dsInv.createdBy)) {
        return NextResponse.json(
          { error: 'You can only edit entries created by you or your agents' },
          { status: 403 }
        )
      }
    }

    // Validate numbers payload — entry type dictates digit length
    if (!Array.isArray(numbers)) {
      return NextResponse.json({ error: 'numbers must be an array' }, { status: 400 })
    }
    const digitLen = dsInv.type === 'single' ? 1 : 2
    const cleanNumbers = numbers
      .map((n: { number: unknown; price: unknown }) => ({
        number: String(n?.number ?? '').trim(),
        price: Math.max(0, Number(n?.price) || 0),
      }))
      .filter((n: { number: string }) => new RegExp(`^\\d{${digitLen}}$`).test(n.number))
    if (cleanNumbers.length === 0) {
      return NextResponse.json(
        { error: `No valid entries found (need ${digitLen}-digit number=price per line)` },
        { status: 400 }
      )
    }

    const newRate = Math.max(0, Number(rate) || 0)

    // Rebuild parsedData — keep metadata, replace numbers
    let pd: Record<string, unknown> = {}
    try { pd = JSON.parse(dsInv.parsedData || '{}') } catch { pd = {} }
    pd.numbers = cleanNumbers

    const totalAmount = (cleanNumbers as Array<{ price: number }>).reduce((s, n) => s + n.price, 0)

    const updated = await db.doubleSingleInventory.update({
      where: { id },
      data: {
        parsedData: JSON.stringify(pd),
        rate: newRate,
        totalAmount,
        vendorId: vendorId === undefined ? dsInv.vendorId : (vendorId || null),
        isUpdated: true,
        updatedBy: authCtx.username || dsInv.createdBy,
      },
      include: { vendor: true },
    })

    // Refresh parent inventory totals — sum of triple + double-single entries
    const allTriples = await db.tripleInventory.findMany({
      where: { inventoryId: dsInv.inventoryId },
    })
    const allDs = await db.doubleSingleInventory.findMany({
      where: { inventoryId: dsInv.inventoryId },
    })
    const tripleTotal = allTriples.reduce((sum, t) => sum + t.totalAmount, 0)
    const dsTotal = allDs.reduce((sum, d) => sum + d.totalAmount, 0)
    const newTotal = tripleTotal + dsTotal
    await db.inventory.update({
      where: { id: dsInv.inventoryId },
      data: { totalAmount: newTotal, totalTxn: newTotal },
    })

    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'update',
      entity: 'double_single_inventory',
      entityId: id,
      market: parentInv.inventoryCode.market,
      metadata: {
        inventoryId: dsInv.inventoryId,
        oldTotal: dsInv.totalAmount,
        newTotal: totalAmount,
        numberCount: cleanNumbers.length,
      },
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error('PUT double-single-inventory error:', error)
    return NextResponse.json({ error: 'Failed to update double single inventory' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const dsInv = await db.doubleSingleInventory.findUnique({ where: { id } })
    if (!dsInv) {
      return NextResponse.json({ error: 'Double single inventory not found' }, { status: 404 })
    }

    // Phase 2 — verify market access via parent inventory
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const parentInv = await db.inventory.findUnique({
      where: { id: dsInv.inventoryId },
      include: { inventoryCode: true },
    })
    if (!parentInv) {
      return NextResponse.json({ error: 'Parent inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, parentInv.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${parentInv.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    await db.doubleSingleInventory.delete({ where: { id } })

    // Update inventory totalAmount — recalculate from all remaining entries
    const allTriples = await db.tripleInventory.findMany({
      where: { inventoryId: dsInv.inventoryId },
    })
    const allDs = await db.doubleSingleInventory.findMany({
      where: { inventoryId: dsInv.inventoryId },
    })
    const tripleTotal = allTriples.reduce((sum, t) => sum + t.totalAmount, 0)
    const dsTotal = allDs.reduce((sum, d) => sum + d.totalAmount, 0)
    const newTotal = tripleTotal + dsTotal
    await db.inventory.update({
      where: { id: dsInv.inventoryId },
      data: { totalAmount: newTotal, totalTxn: newTotal },
    })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'delete',
      entity: 'double_single_inventory',
      entityId: id,
      market: parentInv.inventoryCode.market,
      metadata: { inventoryId: dsInv.inventoryId, type: dsInv.type },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE double-single-inventory error:', error)
    return NextResponse.json({ error: 'Failed to delete double single inventory' }, { status: 500 })
  }
}
