import { db, databaseUrl } from '@/lib/db'
import { NextResponse } from 'next/server'

/**
 * GET /api/health
 * Returns database connection status, resolved DB path, and basic counts.
 * Used for production debugging on shared hosting (Hostinger etc.)
 */
export async function GET() {
  const startedAt = Date.now()
  const result: Record<string, unknown> = {
    ok: false,
    timestamp: new Date().toISOString(),
    databaseUrl: databaseUrl,
    env: {
      NODE_ENV: process.env.NODE_ENV || 'development',
      RAW_DATABASE_URL: process.env.DATABASE_URL || '(not set)',
      HOSTNAME: process.env.HOSTNAME || '(not set)',
      PORT: process.env.PORT || '(not set)',
      cwd: typeof process !== 'undefined' ? process.cwd() : '(unknown)',
    },
    checks: {} as Record<string, unknown>,
  }

  // Check 1: Can we reach the DB at all?
  try {
    await db.$queryRaw`SELECT 1 AS ok`
    result.checks.dbConnection = { ok: true, latencyMs: Date.now() - startedAt }
  } catch (err) {
    result.checks.dbConnection = {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      errorName: err instanceof Error ? err.constructor.name : 'Unknown',
    }
    return NextResponse.json(result, { status: 500 })
  }

  // Check 2: Are critical tables present and non-empty?
  try {
    const userCount = await db.user.count()
    const inventoryCount = await db.inventory.count()
    const inventoryCodeCount = await db.inventoryCode.count()
    result.checks.tables = {
      ok: true,
      users: userCount,
      inventories: inventoryCount,
      inventoryCodes: inventoryCodeCount,
    }

    // Check 3: Is there at least one super admin?
    const masterCount = await db.user.count({ where: { role: 'super' } })
    result.checks.masterAdmin = {
      ok: masterCount > 0,
      count: masterCount,
      hint: masterCount === 0
        ? 'No super admin found. Run `bunx prisma db seed` to create admin1/admin123.'
        : undefined,
    }

    result.ok = userCount > 0 && masterCount > 0
  } catch (err) {
    result.checks.tables = {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      hint: 'Tables may not be migrated. Run `bunx prisma db push` to create them.',
    }
    return NextResponse.json(result, { status: 500 })
  }

  return NextResponse.json(result)
}
