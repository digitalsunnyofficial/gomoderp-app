import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * GET /api/parser-exceptions/[id]
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const exception = await db.parserException.findUnique({ where: { id } })
    if (!exception) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }
    return NextResponse.json(exception)
  } catch (error) {
    console.error('GET parser-exception error:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

/**
 * PATCH /api/parser-exceptions/[id]
 * Resolve / ignore / re-resolve an exception.
 *
 * Body: { status, resolution, resolutionData, resolvedBy, resolvedByUserId }
 */
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, resolution, resolutionData, resolvedBy, resolvedByUserId } = body

    if (!status || !['open', 'resolved', 'ignored'].includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
    }

    const update: Record<string, unknown> = { status }
    if (resolution) {
      update.resolution = resolution
      update.resolvedBy = resolvedBy || null
      update.resolvedAt = new Date()
      if (resolutionData !== undefined) {
        update.resolutionData = typeof resolutionData === 'string' ? resolutionData : JSON.stringify(resolutionData)
      }
    }

    const updated = await db.parserException.update({ where: { id }, data: update })

    // Log to activity feed
    if (resolvedBy) {
      await logActivity({
        userId: resolvedByUserId || null,
        username: resolvedBy,
        action: 'parser_resolve',
        entity: 'parser_exception',
        entityId: id,
        metadata: { status, resolution, market: updated.market || null },
      })
    }

    return NextResponse.json(updated)
  } catch (error) {
    console.error('PATCH parser-exception error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

/**
 * DELETE /api/parser-exceptions/[id]
 * Hard delete a parser exception (admin only — typically you want PATCH to ignored).
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    await db.parserException.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE parser-exception error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
