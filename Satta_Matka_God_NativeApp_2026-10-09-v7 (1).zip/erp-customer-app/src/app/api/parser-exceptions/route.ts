import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * GET /api/parser-exceptions
 * Query params:
 *   - status: "open" | "resolved" | "ignored" | "all" (default open)
 *   - uploadedBy: filter by username
 *   - market: filter by market
 *   - kind: "skipped" | "dropped"
 *   - limit, offset
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') || 'open'
    const uploadedBy = searchParams.get('uploadedBy')
    const market = searchParams.get('market')
    const kind = searchParams.get('kind')
    const limit = Math.min(parseInt(searchParams.get('limit') || '200'), 500)
    const offset = parseInt(searchParams.get('offset') || '0')

    const where: Record<string, unknown> = {}
    if (status !== 'all') where.status = status
    if (uploadedBy) where.uploadedBy = uploadedBy
    if (market) where.market = market
    if (kind) where.kind = kind

    const [exceptions, total, openCount, resolvedCount, ignoredCount] = await Promise.all([
      db.parserException.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.parserException.count({ where }),
      db.parserException.count({ where: { status: 'open' } }),
      db.parserException.count({ where: { status: 'resolved' } }),
      db.parserException.count({ where: { status: 'ignored' } }),
    ])

    return NextResponse.json({
      exceptions,
      total,
      summary: { open: openCount, resolved: resolvedCount, ignored: ignoredCount },
    })
  } catch (error) {
    console.error('GET parser-exceptions error:', error)
    return NextResponse.json({ error: 'Failed to fetch parser exceptions' }, { status: 500 })
  }
}

/**
 * POST /api/parser-exceptions
 * Create a new parser exception record. Typically called from the frontend
 * when the parser produces SKIPPED or DROPPED entries.
 */
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      uploadedBy,
      uploadedByUserId,
      originalText,
      market,
      inventoryCodeId,
      reason,
      kind = 'skipped',
      rawNumber,
      parsedData,
    } = body

    if (!uploadedBy || !originalText || !reason) {
      return NextResponse.json(
        { error: 'uploadedBy, originalText, reason are required' },
        { status: 400 }
      )
    }

    const exception = await db.parserException.create({
      data: {
        uploadedBy,
        uploadedByUserId: uploadedByUserId || null,
        originalText,
        market: market || null,
        inventoryCodeId: inventoryCodeId || null,
        reason,
        kind,
        rawNumber: rawNumber || null,
        parsedData: parsedData || null,
        status: 'open',
      },
    })

    return NextResponse.json(exception, { status: 201 })
  } catch (error) {
    console.error('POST parser-exceptions error:', error)
    return NextResponse.json({ error: 'Failed to create parser exception' }, { status: 500 })
  }
}
