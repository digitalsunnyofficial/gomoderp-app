import { NextResponse } from 'next/server'

/**
 * GET /api/auth/validate
 * Protected endpoint (requires session cookie via proxy.ts) used to verify
 * that the client's session cookie is still valid. Returns 200 + session info
 * if valid; proxy.ts returns 401 if the cookie is missing/expired.
 */
export async function GET(request: Request) {
  // The proxy middleware has already validated the session cookie.
  // Extract session info from the headers that proxy.ts injects.
  const userId = request.headers.get('x-session-userid') || ''
  const username = request.headers.get('x-session-username') || ''
  const role = request.headers.get('x-session-role') || ''

  return NextResponse.json({
    valid: true,
    userId,
    username,
    role,
  })
}
