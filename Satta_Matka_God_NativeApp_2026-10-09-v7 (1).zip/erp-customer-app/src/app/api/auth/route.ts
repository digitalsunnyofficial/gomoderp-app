import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { setSessionCookie } from '@/lib/session'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import crypto from 'crypto'

async function verifyPassword(plain: string, stored: string): Promise<boolean> {
  // Support both plaintext (legacy) and bcrypt-hashed passwords
  if (stored.startsWith('$2b$') || stored.startsWith('$2a$')) {
    return bcrypt.compare(plain, stored)
  }
  return plain === stored
}

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json()
    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password required' }, { status: 400 })
    }
    const user = await db.user.findUnique({
      where: { username },
      include: {
        permissions: true,
      },
    })
    if (!user || !(await verifyPassword(password, user.password))) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    }

    // ── Phase 2: enforce lock ──
    if (user.isLocked) {
      await logActivity({
        userId: user.id,
        username: user.username,
        action: 'login_blocked_locked',
        entity: 'user',
        entityId: user.id,
        metadata: { reason: user.lockReason || 'Account locked' },
      })
      return NextResponse.json(
        { error: `Account is locked. Reason: ${user.lockReason || 'No reason provided'}. Contact administrator.` },
        { status: 403 }
      )
    }

    if (user.status === 'pending_approval') {
      return NextResponse.json({ error: 'Your account is pending approval. Please wait for an administrator to approve your signup.' }, { status: 403 })
    }
    if (user.status === 'rejected') {
      return NextResponse.json({ error: 'Your signup was rejected. Please contact an administrator.' }, { status: 403 })
    }
    if (user.status !== 'active') {
      return NextResponse.json({ error: 'Account is inactive' }, { status: 403 })
    }

    // ── Phase 2: log successful login ──
    await logActivity({
      userId: user.id,
      username: user.username,
      action: 'login',
      entity: 'user',
      entityId: user.id,
    })

    // ── Single device login: invalidate existing sessions for agent/manager ──
    if (user.role !== 'super') {
      // Delete all existing sessions for this user (single device enforcement)
      try {
        if (db.userSession) await db.userSession.deleteMany({ where: { userId: user.id } })
      } catch { /* graceful degradation if UserSession model not available */ }
    }
    // Create a new session record
    const sessionToken = crypto.randomBytes(32).toString('hex')
    const userAgent = request.headers.get('user-agent') || 'unknown'
    const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown'
    try {
      if (db.userSession) {
        await db.userSession.create({
          data: {
            userId: user.id,
            token: sessionToken,
            deviceInfo: userAgent.substring(0, 200),
            ipAddress: ip.substring(0, 45),
          },
        })
      }
    } catch { /* graceful degradation if UserSession model not available */ }

    // ── Auto-apply 7-day trial for non-master users on first login ──
    if (user.role !== 'super') {
      const existingSub = await db.userSubscription.findFirst({
        where: { userId: user.id },
      })
      if (!existingSub) {
        // No subscription ever — auto-apply trial
        const trialPlan = await db.subscriptionPlan.findFirst({
          where: { name: 'trial', isActive: true },
        })
        if (trialPlan) {
          const now = new Date()
          const endDate = new Date(now)
          endDate.setDate(endDate.getDate() + trialPlan.durationDays)
          await db.userSubscription.create({
            data: {
              userId: user.id,
              planId: trialPlan.id,
              startDate: now,
              endDate,
              status: 'active',
              paymentStatus: 'completed',
              amountPaid: 0,
              activatedBy: 'system',
            },
          })
        }
      }
    }

    const { password: _, ...safeUser } = user
    const response = NextResponse.json(safeUser)
    // Set signed session cookie so the proxy.ts auth gate accepts subsequent /api/* calls
    const finalResponse = await setSessionCookie(response, {
      id: user.id,
      username: user.username,
      role: user.role,
    }, sessionToken)

    // Register session in the global registry for single-device enforcement
    // (best-effort, won't block login if it fails)
    try {
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'
      await fetch(`${baseUrl}/api/auth/register-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, token: sessionToken }),
      })
    } catch {
      // Fail silently — single-device enforcement degrades gracefully
    }

    return finalResponse
  } catch (error) {
    console.error('POST auth error:', error)
    return NextResponse.json({ error: 'Authentication failed' }, { status: 500 })
  }
}
