import { NextResponse } from 'next/server'
import { clearSessionCookie } from '@/lib/session'

export async function POST() {
  try {
    const response = NextResponse.json({ ok: true })
    return clearSessionCookie(response)
  } catch (error) {
    console.error('POST logout error:', error)
    return NextResponse.json({ error: 'Logout failed' }, { status: 500 })
  }
}
