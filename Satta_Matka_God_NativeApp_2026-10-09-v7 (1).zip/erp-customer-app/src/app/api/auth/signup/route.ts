import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'

/**
 * POST /api/auth/signup
 *
 * Public signup endpoint. ALWAYS creates a 'user' (agent) role record with
 * status 'pending_approval'. The signup form does not let the user pick
 * admin/master roles — every signup is an agent.
 *
 * Auto-assignment: agent signups are linked to the DEFAULT ADMIN (the
 * 'manager' role user with username='admin2') via managerId. This way
 * super admin + default admin can both see and approve incoming
 * standalone agents from one place.
 *
 * Approval flow:
 *   - Super admin can approve + escalate role to 'manager' if needed
 *   - Default admin can approve agent signups under them (keeps role='user')
 */
export async function POST(request: Request) {
  try {
    const { username, password, name, email, phone } = await request.json()

    if (!username || !password || !name || !email || !phone) {
      return NextResponse.json({ error: 'All fields are required: username, password, name, email, phone' }, { status: 400 })
    }
    if (username.length < 3 || password.length < 4) {
      return NextResponse.json({ error: 'Username must be 3+ chars, password 4+ chars' }, { status: 400 })
    }

    // Check if username already exists
    const existing = await db.user.findUnique({ where: { username } })
    if (existing) {
      return NextResponse.json({ error: 'Username already taken' }, { status: 409 })
    }

    // Look up the default admin (manager role, username='admin2') to assign
    // the new standalone agent to. If not found, leave managerId null — the
    // super admin will still see the signup in the pending list.
    const defaultAdmin = await db.user.findFirst({
      where: { username: 'admin2', role: 'manager', status: 'active' },
      select: { id: true, username: true },
    })

    const hashedPassword = await bcrypt.hash(password, 10)

    // Create user with pending_approval status
    // Role is always 'user' (agent); admin assigns actual role on approval
    const user = await db.user.create({
      data: {
        username,
        password: hashedPassword,
        passwordPlain: password, // plaintext copy so Super Admin can view/edit passwords
        name: name || null,
        email: email || null,
        phone: phone || null,
        requestedRole: 'user', // always 'user' for public signup
        role: 'user',
        status: 'pending_approval',
        assignedMarkets: '',
        managerId: defaultAdmin?.id || null, // link to default admin
      },
    })

    // Audit log
    await logActivity({
      userId: user.id,
      username: user.username,
      action: 'signup',
      entity: 'user',
      entityId: user.id,
      metadata: {
        status: 'pending_approval',
        name,
        email,
        phone,
        requestedRole: 'user',
        assignedToDefaultAdmin: !!defaultAdmin,
        defaultAdminUsername: defaultAdmin?.username || null,
      },
    })

    return NextResponse.json({
      message: 'Signup successful! Your account is pending approval by an administrator.',
      userId: user.id,
      status: 'pending_approval'
    }, { status: 201 })
  } catch (error) {
    console.error('POST signup error:', error)
    return NextResponse.json({ error: 'Signup failed' }, { status: 500 })
  }
}
