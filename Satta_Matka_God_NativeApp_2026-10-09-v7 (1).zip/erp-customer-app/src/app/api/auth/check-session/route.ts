import { db } from '@/lib/db'
import { getSessionFromRequest } from '@/lib/session'
import { NextResponse } from 'next/server'

// Lightweight session validation — checks if the session DB record exists
// Used by proxy.ts for single-device enforcement
export async function GET(request: Request) {
  try {
    const session = await getSessionFromRequest(request as any)
    if (!session) {
      return NextResponse.json({ valid: false }, { status: 401 })
    }

    // Master users bypass session DB check (can be on multiple devices)
    if (session.role === 'super') {
      return NextResponse.json({ valid: true, role: session.role })
    }

    // For non-master users, check if a session DB record exists
    // The session ID (sid) is embedded in the cookie token
    // We verify it exists in the database
    const sessionRecord = await db.userSession.findFirst({
      where: { userId: session.id },
      select: { id: true },
    })

    if (!sessionRecord) {
      return NextResponse.json({ valid: false, reason: 'session_expired' }, { status: 401 })
    }

    // Update lastSeen
    await db.userSession.update({
      where: { id: sessionRecord.id },
      data: { lastSeen: new Date() },
    })

    return NextResponse.json({ valid: true, role: session.role })
  } catch {
    // If DB is unreachable, allow the request through (fail-open for reliability)
    return NextResponse.json({ valid: true })
  }
}
