import { NextResponse } from 'next/server'

// Session registration endpoint — called by auth route after login
// to register the new session in the proxy's in-memory registry
// POST /api/auth/register-session { userId, token }
export async function POST(request: Request) {
  try {
    const { userId, token } = await request.json()
    if (!userId || !token) {
      return NextResponse.json({ error: 'Missing userId or token' }, { status: 400 })
    }
    // Store in KV or pass through to proxy
    // Since proxy.ts is in the same process, we use a fetch to self
    // to communicate. But actually, the proxy and API routes share the same
    // process memory in Next.js, so we can use a global variable.
    
    // Use a global on globalThis that the proxy can read
    const g = globalThis as Record<string, unknown>
    if (!g.__sessionRegistry) g.__sessionRegistry = new Map<string, string>()
    const registry = g.__sessionRegistry as Map<string, string>
    registry.set(userId, token)
    
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
