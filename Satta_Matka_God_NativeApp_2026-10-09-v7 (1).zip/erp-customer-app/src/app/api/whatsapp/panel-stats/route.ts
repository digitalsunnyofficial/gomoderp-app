// WhatsApp Management panel — Dashboard statistics.
//
//   GET /api/whatsapp/panel-stats — master/manager only.
//
// Everything the WhatsApp Dashboard shows in one call:
//   totals (in/out/pending/approved/rejected/failed replies/transactions),
//   7-day daily series, approval funnel, top customers by volume,
//   unknown-label pressure (what the bot could not read), learning/bot
//   evolution summary, reply latency, and computed optimization suggestions.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { getParserVersion } from '@/lib/whatsapp/pipeline'
import { waConfig } from '@/lib/whatsapp/meta'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

function dayKey(d: Date): string {
  // IST day boundaries (the operator's business timezone)
  const ist = new Date(d.getTime() + 330 * 60000)
  return ist.toISOString().slice(0, 10)
}

interface UnknownAgg { label: string; count: number }

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }

    const now = Date.now()
    const since7d = new Date(now - 7 * 86400000)
    const since30d = new Date(now - 30 * 86400000)

    // ── Totals ──
    const [inbound, outbound, pending, approved, rejected, failedOutbound, txAgg] = await Promise.all([
      db.whatsAppMessage.count({ where: { direction: 'in' } }),
      db.whatsAppMessage.count({ where: { direction: 'out' } }),
      db.whatsAppApproval.count({ where: { status: 'pending' } }),
      db.whatsAppApproval.count({ where: { status: 'approved' } }),
      db.whatsAppApproval.count({ where: { status: 'rejected' } }),
      db.whatsAppMessage.count({ where: { direction: 'out', status: 'failed' } }),
      db.whatsAppTransaction.aggregate({ where: { status: 'active' }, _count: true, _sum: { total: true } }),
    ])

    // ── 7-day daily series (in/out/rejected per IST day) ──
    const recentRows = await db.whatsAppMessage.findMany({
      where: { createdAt: { gte: since7d } },
      select: { direction: true, status: true, createdAt: true },
    })
    const days: Array<{ date: string; inbound: number; outbound: number; rejected: number }> = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now - i * 86400000)
      days.push({ date: dayKey(d), inbound: 0, outbound: 0, rejected: 0 })
    }
    const dayMap = new Map(days.map(d => [d.date, d]))
    for (const r of recentRows) {
      const bucket = dayMap.get(dayKey(r.createdAt))
      if (!bucket) continue
      if (r.direction === 'in') bucket.inbound++
      else bucket.outbound++
      if (r.direction === 'in' && r.status === 'rejected') bucket.rejected++
    }

    // ── Top customers by message volume (last 30 days) ──
    const rows30 = await db.whatsAppMessage.findMany({
      where: { createdAt: { gte: since30d } },
      select: { customerId: true, vendorId: true, phone: true, direction: true, groupId: true },
    })
    const customerIds = [...new Set(rows30.map(r => r.customerId).filter(Boolean))] as string[]
    const vendorIds = [...new Set(rows30.map(r => r.vendorId).filter(Boolean))] as string[]
    const apps = customerIds.length
      ? await db.appCustomer.findMany({ where: { id: { in: customerIds } }, select: { id: true, name: true, mobile: true, agentName: true } })
      : []
    const vendors = vendorIds.length
      ? await db.vendor.findMany({ where: { id: { in: vendorIds } }, select: { id: true, businessName: true, mobileNo: true } })
      : []
    const nameMap = new Map<string, { name: string; agentName: string | null }>()
    for (const a of apps) nameMap.set(a.id, { name: a.name, agentName: a.agentName })
    for (const v of vendors) nameMap.set(v.id, { name: v.businessName, agentName: null })

    const perKey = new Map<string, { key: string; name: string; agentName: string | null; inbound: number; outbound: number }>()
    for (const r of rows30) {
      const key = r.customerId || r.vendorId || (r.groupId ? `group:${r.groupId}` : `phone:${r.phone}`)
      let entry = perKey.get(key)
      if (!entry) {
        const meta = r.customerId || r.vendorId ? nameMap.get(r.customerId || r.vendorId || '') : undefined
        entry = {
          key,
          name: meta?.name || (r.groupId ? `Group …${r.groupId.slice(-8)}` : r.phone),
          agentName: meta?.agentName || null,
          inbound: 0,
          outbound: 0,
        }
        perKey.set(key, entry)
      }
      if (r.direction === 'in') entry.inbound++
      else entry.outbound++
    }
    const topCustomers = [...perKey.values()]
      .sort((a, b) => (b.inbound + b.outbound) - (a.inbound + a.outbound))
      .slice(0, 10)

    // ── Unknown-label pressure (what the bot could not read) ──
    const learningRows = await db.parserLearningLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 300,
      select: { rawInput: true, status: true, sampleCount: true, ruleDefinition: true, reviewedAt: true, context: true },
    })
    const unknownAgg = new Map<string, UnknownAgg>()
    for (const l of learningRows) {
      if (l.status === 'applied' || l.status === 'dismissed') continue
      const prev = unknownAgg.get(l.rawInput)
      unknownAgg.set(l.rawInput, { label: l.rawInput, count: (prev?.count || 0) + 1 })
    }
    const unknownLabels = [...unknownAgg.values()].sort((a, b) => b.count - a.count).slice(0, 8)

    // ── Bot evolution (learning library) ──
    const [openCount, appliedCount, dismissedCount] = await Promise.all([
      db.parserLearningLog.count({ where: { status: { notIn: ['applied', 'dismissed'] } } }),
      db.parserLearningLog.count({ where: { status: 'applied' } }),
      db.parserLearningLog.count({ where: { status: 'dismissed' } }),
    ])
    const appliedRows = learningRows.filter(l => l.status === 'applied').slice(0, 6)
    const recentActivations = appliedRows.map(l => {
      let term = l.rawInput
      let category: string | null = null
      try {
        const def = l.ruleDefinition ? JSON.parse(l.ruleDefinition) as { term?: string; category?: string } : null
        if (def?.term) term = def.term
        if (def?.category) category = def.category
      } catch { /* keep rawInput */ }
      return { term, category, at: l.reviewedAt }
    })
    const parserVersion = await getParserVersion()

    // ── Reply latency (outbound − inbound over the last 100 linked pairs) ──
    const outRows = await db.whatsAppMessage.findMany({
      where: { direction: 'out', replyToId: { not: null } },
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: { replyToId: true, createdAt: true },
    })
    const inIds = [...new Set(outRows.map(r => r.replyToId!).filter(Boolean))]
    const inRows = inIds.length
      ? await db.whatsAppMessage.findMany({ where: { id: { in: inIds } }, select: { id: true, createdAt: true } })
      : []
    const inMap = new Map(inRows.map(r => [r.id, r.createdAt]))
    let latencySum = 0
    let latencyN = 0
    for (const o of outRows) {
      const inAt = o.replyToId ? inMap.get(o.replyToId) : undefined
      if (!inAt) continue
      const delta = o.createdAt.getTime() - inAt.getTime()
      if (delta >= 0 && delta < 86_400_000) { latencySum += delta; latencyN++ }
    }

    // ── Optimization suggestions (computed, never auto-applied) ──
    const suggestions: Array<{ severity: 'info' | 'warn'; text: string; page?: string }> = []
    if (failedOutbound > 0) {
      suggestions.push({ severity: 'warn', text: `${failedOutbound} reply(ies) failed to deliver — retry them so customers get their confirmations.`, page: 'wa-messages' })
    }
    if (pending > 10) {
      suggestions.push({ severity: 'warn', text: `Approval backlog: ${pending} vyapar waiting — review the queue to keep confirmations fast.`, page: 'wa-approvals' })
    }
    const topUnknown = unknownLabels[0]
    if (topUnknown && topUnknown.count >= 2) {
      suggestions.push({ severity: 'info', text: `"${topUnknown.label}" appeared ${topUnknown.count}× unread — define a rule to teach the parser.`, page: 'wa-learning' })
    }
    const decided = approved + rejected
    if (decided >= 5 && rejected / decided > 0.3) {
      suggestions.push({ severity: 'info', text: `${Math.round((rejected / decided) * 100)}% of decided vyapar were rejected — share the expected format with senders.`, page: 'wa-learning' })
    }
    if (appliedCount > 0) {
      suggestions.push({ severity: 'info', text: `Bot evolved ${appliedCount}× — parser is now v${parserVersion}. Recent rule activations are on the Learning page.`, page: 'wa-learning' })
    }
    if (suggestions.length === 0) {
      suggestions.push({ severity: 'info', text: 'Channel healthy — no action needed right now.' })
    }

    const cfg = await db.appConfig.findUnique({ where: { key: 'whatsapp_approval' } })

    return NextResponse.json({
      mode: waConfig().live ? 'live' : 'sandbox',
      approvalMode: (cfg?.value || 'on').toLowerCase() !== 'off' ? 'on' : 'off',
      parserVersion,
      totals: {
        inbound, outbound, pending, approved, rejected, failedOutbound,
        transactions: txAgg._count,
        txAmount: txAgg._sum.total || 0,
      },
      daily: days,
      topCustomers,
      unknownLabels,
      learning: { open: openCount, applied: appliedCount, dismissed: dismissedCount, recentActivations },
      latency: latencyN ? { avgMs: Math.round(latencySum / latencyN), sampled: latencyN } : null,
      suggestions,
    })
  } catch (error) {
    console.error('GET whatsapp panel-stats error:', error)
    return NextResponse.json({ error: 'Failed to compute panel stats' }, { status: 500 })
  }
}
