// POST /api/whatsapp/retry-outbound — retry a FAILED outbound reply.
// Spec: if the ERP transaction succeeded but WhatsApp delivery failed, the
// transaction stays successful and the outbound message is retried
// separately. Never creates a second transaction.
// Master/manager only.
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { retryOutbound } from '@/lib/whatsapp/pipeline'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const body = await request.json().catch(() => null)
    const outboundId = String(body?.outboundId || '').trim()
    if (!outboundId) {
      return NextResponse.json({ error: 'outboundId is required' }, { status: 400 })
    }
    const result = await retryOutbound(outboundId)
    if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 })
    return NextResponse.json(result)
  } catch (error) {
    console.error('POST whatsapp retry-outbound error:', error)
    return NextResponse.json({ error: 'Retry failed' }, { status: 500 })
  }
}
