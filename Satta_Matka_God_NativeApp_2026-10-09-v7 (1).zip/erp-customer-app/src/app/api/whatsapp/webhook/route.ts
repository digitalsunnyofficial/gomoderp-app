// ────────────────────────────────────────────────────────────
// WhatsApp Cloud API webhook — PUBLIC route (Meta calls this).
//
//   GET  /api/whatsapp/webhook  — Meta subscription verification
//        (hub.mode=subscribe & hub.verify_token & hub.challenge)
//   POST /api/whatsapp/webhook  — inbound messages + delivery statuses
//
// Inbound text messages run through the shared pipeline
// (src/lib/whatsapp/pipeline.ts) which parses the vyapar with the
// Smart Entry engine and auto-replies with the vyapar summary.
// Always answers 200 fast (Meta retries on failures); errors are
// recorded on the stored rows instead.
// ────────────────────────────────────────────────────────────
import { NextResponse } from 'next/server'
import { waConfig, verifyMetaSignature } from '@/lib/whatsapp/meta'
import { processInbound } from '@/lib/whatsapp/pipeline'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const url = new URL(request.url)
  const mode = url.searchParams.get('hub.mode')
  const token = url.searchParams.get('hub.verify_token')
  const challenge = url.searchParams.get('hub.challenge')
  const cfg = waConfig()

  if (mode === 'subscribe' && token && token === cfg.verifyToken) {
    return new NextResponse(challenge || '', { status: 200 })
  }
  return new NextResponse('Forbidden', { status: 403 })
}

interface MetaWebhookBody {
  object?: string
  entry?: Array<{
    changes?: Array<{
      value?: {
        metadata?: { phone_number_id?: string; display_phone_number?: string }
        contacts?: Array<{ profile?: { name?: string }; wa_id?: string }>
        messages?: Array<{
          from?: string
          id?: string
          timestamp?: string
          type?: string
          text?: { body?: string }
          context?: { from?: string; id?: string; forwarded?: boolean } // forwarded/reply metadata — original sender
          group_id?: string // provider group chat id when the message came from a group
        }>
        statuses?: Array<{ id?: string; status?: string }>
        group_id?: string // some provider payloads carry the group id on the value
      }
    }>
  }>
}

export async function POST(request: Request) {
  const raw = await request.text().catch(() => '')

  // Optional payload signature verification (WHATSAPP_APP_SECRET)
  const sigOk = await verifyMetaSignature(raw, request.headers.get('x-hub-signature-256'))
  if (!sigOk) return NextResponse.json({ error: 'invalid signature' }, { status: 401 })

  let body: MetaWebhookBody
  try {
    body = JSON.parse(raw) as MetaWebhookBody
  } catch {
    return NextResponse.json({ received: true }) // malformed → ack anyway
  }

  try {
    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        const value = change.value
        if (!value) continue

        // ── Inbound customer messages ──
        for (const msg of value.messages || []) {
          const phone = msg.from || value.contacts?.[0]?.wa_id || ''
          const profileName = value.contacts?.[0]?.profile?.name || ''
          const textBody = msg.text?.body || ''
          if (!phone) continue
          // ── v3 metadata: group chats + forwarded messages ──
          // Group identity = the provider's immutable Group ID (never the
          // group name). Forwarded messages keep the ORIGINAL sender.
          const groupId = (msg.group_id || value.group_id || '').trim()
          const isForwarded = msg.context?.forwarded === true
          const forwardedFrom = isForwarded ? (msg.context?.from || '') : ''
          if (msg.type && msg.type !== 'text') {
            // Media/location etc. — store for the inbox, no auto-parse yet
            await db.whatsAppMessage.create({
              data: {
                direction: 'in',
                phone: phone.replace(/\D/g, ''),
                profileName,
                waMessageId: msg.id || null,
                body: `[${msg.type} message — not readable as vyapar]`,
                status: 'rejected',
                error: 'unsupported message type',
                groupId: groupId || null,
                senderPhone: phone.replace(/\D/g, ''),
                senderName: profileName,
                forwardedFrom: forwardedFrom ? forwardedFrom.replace(/\D/g, '') : null,
              },
            })
            continue
          }
          // Sequential processing keeps per-customer ordering stable
          await processInbound({
            phone,
            profileName,
            text: textBody,
            waMessageId: msg.id,
            groupId: groupId || undefined,
            forwardedFrom: forwardedFrom || undefined,
            senderPhone: groupId ? phone : undefined,
            senderName: groupId ? profileName : undefined,
            providerTimestamp: msg.timestamp || undefined,
          }).catch(err => console.error('[whatsapp] pipeline error:', err))
        }

        // ── Delivery statuses for our outbound replies ──
        for (const st of value.statuses || []) {
          if (!st.id) continue
          const mapped = st.status === 'failed' ? 'failed'
            : st.status === 'read' ? 'read'
            : st.status === 'delivered' ? 'delivered'
            : 'sent'
          await db.whatsAppMessage.updateMany({
            where: { waMessageId: st.id, direction: 'out' },
            data: { status: mapped },
          }).catch(() => undefined)
        }
      }
    }
  } catch (err) {
    console.error('[whatsapp] webhook error:', err)
  }

  return NextResponse.json({ received: true })
}
