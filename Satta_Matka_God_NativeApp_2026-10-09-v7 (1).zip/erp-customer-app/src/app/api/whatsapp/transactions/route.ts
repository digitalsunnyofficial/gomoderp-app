// GET /api/whatsapp/transactions — WhatsApp vyapar transactions for the ERP.
// Master/manager only: every row carries the customer → agent attribution
// ("customer A of agent A") and the parse bucket digest (single/double/triple).
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const rows = await db.whatsAppTransaction.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: { _count: { select: { lines: true } } },
    })
    return NextResponse.json(rows)
  } catch (error) {
    console.error('GET whatsapp transactions error:', error)
    return NextResponse.json({ error: 'Failed to fetch transactions' }, { status: 500 })
  }
}
