// POST /api/whatsapp/learning/[id] — learning-library lifecycle (intake spec):
//   { action: "review" }                        → mark reviewed
//   { action: "define", term, category }        → attach a proposed ParserTerm rule
//   { action: "test" }                          → test the proposed rule against
//                                                 historical WhatsApp messages
//   { action: "activate" }                      → create the ParserTerm (the ONLY
//                                                 way a rule reaches production),
//                                                 bump parser_version, mark applied
//   { action: "dismiss" }                       → dismissed (kept for audit)
// Production parser rules NEVER change automatically — every activation is an
// explicit administrator action here. Master/manager only.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { parseUnifiedEntry } from '@/lib/matka/entry-parser'
import { normalizeTerm, GROUP_OPTION_ORDER } from '@/lib/matka/term-registry'
import { bumpParserVersion } from '@/lib/whatsapp/pipeline'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

const VALID_CATEGORIES = new Set<string>([...GROUP_OPTION_ORDER, 'mix', 'common'])

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json().catch(() => null)
    const action = String(body?.action || '').toLowerCase()
    const candidate = await db.parserLearningLog.findUnique({ where: { id } })
    if (!candidate) return NextResponse.json({ error: 'Learning candidate not found' }, { status: 404 })

    if (action === 'review') {
      const row = await db.parserLearningLog.update({
        where: { id },
        data: { status: 'reviewed', reviewedBy: user.username, reviewedAt: new Date() },
      })
      return NextResponse.json(row)
    }

    if (action === 'dismiss') {
      const row = await db.parserLearningLog.update({
        where: { id },
        data: { status: 'dismissed', reviewedBy: user.username, reviewedAt: new Date() },
      })
      await logActivity({ username: user.username, action: 'learning_dismiss', entity: 'parser_learning', entityId: id, metadata: { rawInput: candidate.rawInput } })
      return NextResponse.json(row)
    }

    if (action === 'define') {
      const term = normalizeTerm(String(body?.term || candidate.rawInput))
      const category = String(body?.category || '').trim()
      if (!term) return NextResponse.json({ error: 'term normalizes to empty' }, { status: 400 })
      if (!VALID_CATEGORIES.has(category)) {
        return NextResponse.json({ error: `category must be one of: ${[...VALID_CATEGORIES].join(', ')}` }, { status: 400 })
      }
      const row = await db.parserLearningLog.update({
        where: { id },
        data: {
          status: candidate.status === 'pending' ? 'reviewed' : candidate.status,
          reviewedBy: user.username,
          reviewedAt: new Date(),
          ruleDefinition: JSON.stringify({ term, category }),
        },
      })
      return NextResponse.json(row)
    }

    if (action === 'test') {
      // Test the proposed rule against historical inbound messages that contain
      // the candidate line: how many messages change, and what the new parse
      // yields — WITHOUT touching production rules.
      const rule = candidate.ruleDefinition ? JSON.parse(candidate.ruleDefinition) as { term: string; category: string } : null
      if (!rule) return NextResponse.json({ error: 'Define the rule first (term + category)' }, { status: 400 })
      const activeTerms = await db.parserTerm.findMany({ where: { isActive: true }, select: { term: true, category: true } })
      const withRule = [...activeTerms, { term: rule.term, category: rule.category }]
      const messages = await db.whatsAppMessage.findMany({
        where: { direction: 'in', body: { contains: candidate.rawInput.split(/\s+/)[0] } },
        orderBy: { createdAt: 'desc' },
        take: 100,
        select: { id: true, body: true, marketName: true },
      })
      let matched = 0
      const samples: Array<{ messageId: string; before: string; after: string }> = []
      for (const m of messages) {
        const before = parseUnifiedEntry(m.body, 100, activeTerms)
        const after = parseUnifiedEntry(m.body, 100, withRule)
        const beforeTotal = before.singles.length + before.doubles.length + before.triples.length + before.common.length + before.groups.reduce((s, g) => s + g.entries.length, 0)
        const afterTotal = after.singles.length + after.doubles.length + after.triples.length + after.common.length + after.groups.reduce((s, g) => s + g.entries.length, 0)
        const beforeAmt = [...before.singles, ...before.doubles, ...before.triples, ...before.common].reduce((s, e) => s + e.amount, 0) + before.groups.reduce((s, g) => s + g.entries.reduce((x, e) => x + e.amount, 0), 0)
        const afterAmt = [...after.singles, ...after.doubles, ...after.triples, ...after.common].reduce((s, e) => s + e.amount, 0) + after.groups.reduce((s, g) => s + g.entries.reduce((x, e) => x + e.amount, 0), 0)
        if (afterTotal > beforeTotal || afterAmt > beforeAmt) {
          matched++
          if (samples.length < 5) {
            samples.push({
              messageId: m.id,
              before: `0 entries parsed (₹${beforeAmt})`,
              after: `${afterTotal} entries parsed (₹${afterAmt})`,
            })
          }
        }
      }
      const testResults = JSON.stringify({ testedAt: new Date().toISOString(), scanned: messages.length, matched, samples })
      const row = await db.parserLearningLog.update({
        where: { id },
        data: { testResults, status: candidate.status === 'pending' ? 'reviewed' : candidate.status, reviewedBy: user.username, reviewedAt: new Date() },
      })
      return NextResponse.json({ ...row, testSummary: { scanned: messages.length, matched, samples } })
    }

    if (action === 'activate') {
      if (candidate.status === 'applied') return NextResponse.json({ error: 'Candidate already applied' }, { status: 409 })
      const rule = candidate.ruleDefinition ? JSON.parse(candidate.ruleDefinition) as { term: string; category: string } : null
      if (!rule) return NextResponse.json({ error: 'Define the rule first (term + category)' }, { status: 400 })
      // One source of truth: the rule becomes a ParserTerm (same dictionary
      // the Smart Entry page and the pipeline both read).
      const existing = await db.parserTerm.findUnique({ where: { term: rule.term } })
      const termRow = existing
        ? await db.parserTerm.update({ where: { term: rule.term }, data: { category: rule.category, isActive: true } })
        : await db.parserTerm.create({
            data: {
              term: rule.term,
              category: rule.category,
              note: `learned from WhatsApp: "${candidate.rawInput}"`,
              isActive: true,
              createdBy: user.username,
            },
          })
      // Historical reconstruction marker: the rule set changed → bump version.
      const parserVersion = await bumpParserVersion()
      const row = await db.parserLearningLog.update({
        where: { id },
        data: { status: 'applied', reviewedBy: user.username, reviewedAt: new Date(), activatedTermId: termRow.id },
      })
      await logActivity({ username: user.username, action: 'learning_activate', entity: 'parser_term', entityId: termRow.id, metadata: { term: rule.term, category: rule.category, parserVersion } })
      return NextResponse.json({ ...row, term: termRow, parserVersion })
    }

    return NextResponse.json({ error: 'action must be review | define | test | activate | dismiss' }, { status: 400 })
  } catch (error) {
    console.error('POST whatsapp learning/[id] error:', error)
    return NextResponse.json({ error: 'Learning action failed' }, { status: 500 })
  }
}
