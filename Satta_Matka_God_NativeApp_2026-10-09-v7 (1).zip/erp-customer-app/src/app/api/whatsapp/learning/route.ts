// GET /api/whatsapp/learning — learning candidates (unknown input patterns).
// Per the intake spec: unknown patterns are STORED as candidates; production
// parser rules never change automatically. An administrator reviews a
// candidate, defines a rule, tests it against historical messages, then
// activates it (→ ParserTerm + parser_version bump).
// Master/manager only.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const url = new URL(request.url)
    const status = (url.searchParams.get('status') || '').toLowerCase()
    const where = ['pending', 'reviewed', 'applied', 'dismissed'].includes(status) ? { status } : {}
    const rows = await db.parserLearningLog.findMany({
      where,
      orderBy: [{ status: 'asc' }, { sampleCount: 'desc' }, { createdAt: 'desc' }],
      take: 200,
    })
    const version = await db.appConfig.findUnique({ where: { key: 'parser_version' } })
    return NextResponse.json({ data: rows, parserVersion: parseInt(version?.value || '1', 10) || 1 })
  } catch (error) {
    console.error('GET whatsapp learning error:', error)
    return NextResponse.json({ error: 'Failed to fetch learning candidates' }, { status: 500 })
  }
}
