// Send a WhatsApp template to a customer (Templates page → "Send").
//
//   POST /api/whatsapp/templates/[id]/send
//   Body: { customerId? , phone?, params? } — exactly one target:
//     customerId → app customer (or ERP vendor) resolved for the number
//     phone      → raw WhatsApp number (digits, any formatting)
//   params: { [variableName]: value } substituted into the {{tokens}}.
//
// Master/manager only (agents have no WhatsApp access). The send reuses the
// SAME outbound path as the pipeline replies (sendWhatsAppText → sandbox
// fallback) and records the outbound row so per-customer history and the
// Messages page show it. Template usageCount / lastUsedAt are bumped.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { sendWhatsAppText } from '@/lib/whatsapp/meta'
import { renderTemplate, parseVariables, recordTemplateUse } from '@/lib/whatsapp/templates'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

function digitsOf(s: string): string {
  return (s || '').replace(/\D/g, '')
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const { id } = await params
    const template = await db.whatsAppTemplate.findUnique({ where: { id } })
    if (!template) return NextResponse.json({ error: 'Template not found' }, { status: 404 })
    if (!template.isActive) return NextResponse.json({ error: 'Template is inactive — activate it first' }, { status: 400 })

    const body = await request.json().catch(() => null) as {
      customerId?: string; phone?: string; params?: Record<string, string>
    } | null
    const varParams = body?.params && typeof body.params === 'object' ? body.params : {}

    // Resolve the target number + customer linkage.
    let phone = body?.phone ? digitsOf(body.phone) : ''
    let customerId: string | null = null
    let vendorId: string | null = null
    let customerName: string | null = null
    if (body?.customerId) {
      const app = await db.appCustomer.findUnique({ where: { id: body.customerId }, select: { id: true, name: true, mobile: true } })
      if (app) {
        customerId = app.id
        customerName = app.name
        phone = digitsOf(app.mobile)
      } else {
        const vendor = await db.vendor.findUnique({ where: { id: body.customerId }, select: { id: true, businessName: true, mobileNo: true } })
        if (vendor) {
          vendorId = vendor.id
          customerName = vendor.businessName
          phone = digitsOf(vendor.mobileNo)
        }
      }
      if (!phone) return NextResponse.json({ error: 'Customer has no WhatsApp number on file' }, { status: 400 })
    } else if (phone) {
      const app = await db.appCustomer.findFirst({ where: { mobile: phone }, select: { id: true, name: true } })
      if (app) { customerId = app.id; customerName = app.name }
    }
    if (!phone) return NextResponse.json({ error: 'A customer or phone number is required' }, { status: 400 })

    // Auto-fill variable samples the operator left blank (from the template's
    // variable list) so preview === what the customer receives.
    const vars = parseVariables(template.variables)
    const filled: Record<string, string> = {}
    for (const v of vars) filled[v.name] = varParams[v.name] ?? v.sample ?? ''
    const finalBody = renderTemplate(template.bodyText, filled)

    const send = await sendWhatsAppText(phone, finalBody)
    const outbound = await db.whatsAppMessage.create({
      data: {
        direction: 'out',
        phone,
        body: finalBody,
        customerId,
        vendorId,
        status: send.sandbox ? 'sandbox' : send.ok ? 'sent' : 'failed',
        waMessageId: send.wamid || null,
        error: send.error || null,
      },
    })
    await recordTemplateUse(template.id)
    return NextResponse.json({
      data: {
        outboundId: outbound.id,
        status: outbound.status,
        phone,
        customerName,
        body: finalBody,
      },
    })
  } catch (error) {
    console.error('POST whatsapp templates/[id]/send error:', error)
    return NextResponse.json({ error: 'Failed to send template' }, { status: 500 })
  }
}
