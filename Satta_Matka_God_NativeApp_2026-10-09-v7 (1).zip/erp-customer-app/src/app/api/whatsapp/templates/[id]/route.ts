// Single WhatsApp template — update / deactivate (super admin only).
//
//   PUT    /api/whatsapp/templates/[id] — edit name/category/language/body/
//                                         variables, or toggle isActive
//   DELETE /api/whatsapp/templates/[id] — soft-deactivate (audit-safe;
//                                         pipeline defaults stay restorable)
//
// Body for PUT: any of { name, category, language, bodyText, variables,
// isActive }. When bodyText changes without explicit variables, the variable
// list is re-derived from the {{tokens}} found in the new body.
import { db } from '@/lib/db'
import { getSessionFromRequest } from '@/lib/session'
import { isSuperRole } from '@/lib/roles'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'
import { TEMPLATE_CATEGORIES, extractVariables, parseVariables } from '@/lib/whatsapp/templates'

export const dynamic = 'force-dynamic'

async function requireSuper(request: Request): Promise<{ username: string } | null> {
  // Template management is channel configuration — super admin only.
  // Verify the SIGNED session cookie (not client headers) AND the role.
  const session = await getSessionFromRequest(request as never)
  if (!session?.username || !isSuperRole(session.role)) return null
  return { username: session.username }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const superUser = await requireSuper(request)
    if (!superUser) return NextResponse.json({ error: 'Super admin only' }, { status: 403 })
    const { id } = await params
    const existing = await db.whatsAppTemplate.findUnique({ where: { id } })
    if (!existing) return NextResponse.json({ error: 'Template not found' }, { status: 404 })

    const body = await request.json().catch(() => null) as {
      name?: string; category?: string; language?: string; bodyText?: string
      variables?: Array<{ name: string; sample: string }>; isActive?: boolean
    } | null
    if (!body) return NextResponse.json({ error: 'Invalid body' }, { status: 400 })

    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if (body.category && TEMPLATE_CATEGORIES.includes(body.category as never)) data.category = body.category
    if (typeof body.language === 'string' && body.language.trim()) data.language = body.language.trim()
    if (typeof body.bodyText === 'string' && body.bodyText.trim()) data.bodyText = body.bodyText
    if (Array.isArray(body.variables)) {
      data.variables = JSON.stringify(
        body.variables
          .filter(v => v && typeof v.name === 'string' && v.name.trim())
          .map(v => ({ name: v.name.trim(), sample: typeof v.sample === 'string' ? v.sample : '' })),
      )
    } else if (typeof data.bodyText === 'string') {
      data.variables = JSON.stringify(extractVariables(data.bodyText as string).map(n => ({ name: n, sample: '' })))
    }
    if (typeof body.isActive === 'boolean') data.isActive = body.isActive

    const updated = await db.whatsAppTemplate.update({ where: { id }, data })
    await logActivity({ username: superUser.username, action: 'update', entity: 'whatsapp_template', entityId: id, metadata: { name: updated.name, isActive: updated.isActive, category: updated.category } })
    return NextResponse.json({ data: { ...updated, variableList: parseVariables(updated.variables) } })
  } catch (error) {
    console.error('PUT whatsapp templates/[id] error:', error)
    return NextResponse.json({ error: 'Failed to update template' }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const superUser = await requireSuper(request)
    if (!superUser) return NextResponse.json({ error: 'Super admin only' }, { status: 403 })
    const { id } = await params
    const existing = await db.whatsAppTemplate.findUnique({ where: { id } })
    if (!existing) return NextResponse.json({ error: 'Template not found' }, { status: 404 })
    // Soft-deactivate — usage history and wording stay in the audit trail.
    const updated = await db.whatsAppTemplate.update({ where: { id }, data: { isActive: false } })
    await logActivity({ username: superUser.username, action: 'update', entity: 'whatsapp_template', entityId: id, metadata: { deactivated: updated.name } })
    return NextResponse.json({ data: { id, isActive: updated.isActive } })
  } catch (error) {
    console.error('DELETE whatsapp templates/[id] error:', error)
    return NextResponse.json({ error: 'Failed to deactivate template' }, { status: 500 })
  }
}
