// WhatsApp message templates (WhatsApp Management panel).
//
//   GET  /api/whatsapp/templates — list all + ensure the 4 pipeline defaults
//                                  exist (master/manager)
//   POST /api/whatsapp/templates — create a template (super admin only)
//
// Categories follow the Meta Cloud API convention:
//   utility | marketing | authentication
// Pipeline-default templates carry key ∈ vyapar_ack | tx_success |
// rejection_notice | invalid_notice and must stay unique. Custom templates
// have key = null and are sendable to any customer from the Templates page.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { getSessionFromRequest } from '@/lib/session'
import { isSuperRole } from '@/lib/roles'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'
import {
  TEMPLATE_CATEGORIES,
  ensureDefaultTemplates,
  extractVariables,
  parseVariables,
} from '@/lib/whatsapp/templates'

export const dynamic = 'force-dynamic'

async function requireSuper(request: Request): Promise<{ username: string } | null> {
  // Template management is channel configuration — super admin only.
  // Verify the SIGNED session cookie (not client headers) AND the role.
  const session = await getSessionFromRequest(request as never)
  if (!session?.username || !isSuperRole(session.role)) return null
  return { username: session.username }
}

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    // Fresh system → materialize the editable pipeline defaults (idempotent,
    // never overwrites operator edits; shipped inactive).
    await ensureDefaultTemplates()
    const rows = await db.whatsAppTemplate.findMany({ orderBy: [{ key: 'asc' }, { createdAt: 'desc' }] })
    const counts: Record<string, number> = { utility: 0, marketing: 0, authentication: 0, total: rows.length }
    for (const r of rows) {
      if (r.category in counts) counts[r.category]++
    }
    return NextResponse.json({
      data: rows.map(r => ({ ...r, variableList: parseVariables(r.variables) })),
      counts,
    })
  } catch (error) {
    console.error('GET whatsapp templates error:', error)
    return NextResponse.json({ error: 'Failed to fetch templates' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const superUser = await requireSuper(request)
    if (!superUser) return NextResponse.json({ error: 'Super admin only' }, { status: 403 })
    const body = await request.json().catch(() => null) as {
      name?: string; category?: string; language?: string; bodyText?: string
      variables?: Array<{ name: string; sample: string }>; key?: string | null
    } | null
    const name = body?.name?.trim()
    const bodyText = body?.bodyText ?? ''
    if (!name || !bodyText.trim()) {
      return NextResponse.json({ error: 'Name and body text are required' }, { status: 400 })
    }
    const category = TEMPLATE_CATEGORIES.includes(body?.category as never) ? body!.category! : 'utility'
    let variables = '[]'
    if (Array.isArray(body?.variables)) {
      variables = JSON.stringify(
        body!.variables
          .filter(v => v && typeof v.name === 'string' && v.name.trim())
          .map(v => ({ name: v.name.trim(), sample: typeof v.sample === 'string' ? v.sample : '' })),
      )
    } else {
      // Derive from {{tokens}} present in the body so the editor stays in sync.
      variables = JSON.stringify(extractVariables(bodyText).map(n => ({ name: n, sample: '' })))
    }
    // key: only the 4 pipeline slots may be keyed; null for custom templates.
    const allowedKeys = ['vyapar_ack', 'tx_success', 'rejection_notice', 'invalid_notice']
    const key = body?.key && allowedKeys.includes(body.key) ? body.key : null
    if (key) {
      const exists = await db.whatsAppTemplate.findUnique({ where: { key } })
      if (exists) return NextResponse.json({ error: `A template already occupies the "${key}" slot` }, { status: 409 })
    }
    const created = await db.whatsAppTemplate.create({
      data: { name, key, category, language: body?.language?.trim() || 'en', bodyText, variables, isActive: false, createdBy: superUser.username },
    })
    await logActivity({ username: superUser.username, action: 'create', entity: 'whatsapp_template', entityId: created.id, metadata: { name, category, key } })
    return NextResponse.json({ data: created })
  } catch (error) {
    console.error('POST whatsapp templates error:', error)
    return NextResponse.json({ error: 'Failed to create template' }, { status: 500 })
  }
}
