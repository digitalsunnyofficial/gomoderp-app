// GET /api/whatsapp/inbox — latest WhatsApp conversations for the ERP inbox.
// Master/manager only (agents use Smart Entry / Chitthi Generator).
// Each row is enriched with the customer → agent attribution so master admin
// sees WHICH customer of WHICH agent sent the vyapar.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const rows = await db.whatsAppMessage.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    // ── Attribution enrichment: phone/customer → name + agent snapshot ──
    const customerIds = [...new Set(rows.map(r => r.customerId).filter(Boolean))] as string[]
    const vendorIds = [...new Set(rows.map(r => r.vendorId).filter(Boolean))] as string[]
    const apps: Array<{ id: string; name: string; mobile: string; agentUsername: string | null; agentName: string | null }> = customerIds.length
      ? await db.appCustomer.findMany({
          where: { id: { in: customerIds } },
          select: { id: true, name: true, mobile: true, agentUsername: true, agentName: true },
        })
      : []
    const vendors: Array<{ id: string; businessName: string; mobileNo: string; createdBy: string }> = vendorIds.length
      ? await db.vendor.findMany({
          where: { id: { in: vendorIds } },
          select: { id: true, businessName: true, mobileNo: true, createdBy: true },
        })
      : []
    const agentNames = [...new Set([
      ...apps.map(a => a.agentUsername).filter(Boolean),
      ...vendors.map(v => v.createdBy).filter(Boolean),
    ])] as string[]
    const agents = agentNames.length
      ? await db.user.findMany({ where: { username: { in: agentNames } }, select: { username: true, name: true } })
      : []
    const agentNameOf = (username: string | null) => {
      if (!username) return null
      const u = agents.find(a => a.username === username)
      return u?.name || u?.username || username
    }
    const appMap = new Map(apps.map(a => [a.id, a]))
    const vendorMap = new Map(vendors.map(v => [v.id, v]))

    return NextResponse.json(rows.map(r => {
      const app = r.customerId ? appMap.get(r.customerId) : null
      const vendor = r.vendorId ? vendorMap.get(r.vendorId) : null
      return {
        ...r,
        customerName: app?.name || vendor?.businessName || null,
        agentName: agentNameOf(app?.agentUsername || vendor?.createdBy || null),
      }
    }))
  } catch (error) {
    console.error('GET whatsapp inbox error:', error)
    return NextResponse.json({ error: 'Failed to fetch inbox' }, { status: 500 })
  }
}
