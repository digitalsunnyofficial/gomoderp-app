// PUT/DELETE /api/whatsapp/group-mappings/[id] — update or retire a mapping.
// Super Admin only (channel configuration). DELETE is a soft deactivate so
// historical messages keep their group context.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { getSessionFromRequest } from '@/lib/session'
import { isSuperRole } from '@/lib/roles'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

async function requireSuper(request: Request): Promise<boolean> {
  // Super Admin only (channel configuration): verify the SIGNED session
  // cookie AND that the session role is super.
  const session = await getSessionFromRequest(request as never)
  return !!session && isSuperRole(session.role)
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    if (!(await requireSuper(request))) {
      return NextResponse.json({ error: 'Super Admin only' }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json().catch(() => null)
    const data: Record<string, unknown> = {}
    if (body?.groupLabel !== undefined) data.groupLabel = String(body.groupLabel).trim()
    if (body?.note !== undefined) data.note = String(body.note).trim()
    if (body?.isActive !== undefined) data.isActive = Boolean(body.isActive)
    if (body?.customerId !== undefined || body?.vendorId !== undefined) {
      const customerId = String(body?.customerId || '').trim()
      const vendorId = String(body?.vendorId || '').trim()
      if (customerId && vendorId) {
        return NextResponse.json({ error: 'Map the group to exactly ONE customer' }, { status: 400 })
      }
      if (customerId) {
        const app = await db.appCustomer.findUnique({ where: { id: customerId } })
        if (!app) return NextResponse.json({ error: 'App customer not found' }, { status: 400 })
      }
      if (vendorId) {
        const vendor = await db.vendor.findUnique({ where: { id: vendorId } })
        if (!vendor) return NextResponse.json({ error: 'ERP customer not found' }, { status: 400 })
      }
      data.customerId = customerId || null
      data.vendorId = vendorId || null
    }
    if (!Object.keys(data).length) {
      return NextResponse.json({ error: 'Nothing to update' }, { status: 400 })
    }

    const row = await db.whatsAppGroupMapping.update({ where: { id }, data })
    await logActivity({ username: user.username, action: 'update', entity: 'whatsapp_group_mapping', entityId: id, metadata: data })
    return NextResponse.json(row)
  } catch (error) {
    console.error('PUT whatsapp group-mappings/[id] error:', error)
    return NextResponse.json({ error: 'Failed to update group mapping' }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    if (!(await requireSuper(request))) {
      return NextResponse.json({ error: 'Super Admin only' }, { status: 403 })
    }

    const { id } = await params
    // Soft deactivate — historical messages keep their group context.
    const row = await db.whatsAppGroupMapping.update({
      where: { id },
      data: { isActive: false },
    })
    await logActivity({ username: user.username, action: 'delete', entity: 'whatsapp_group_mapping', entityId: id, metadata: { groupId: row.groupId, soft: true } })
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('DELETE whatsapp group-mappings/[id] error:', error)
    return NextResponse.json({ error: 'Failed to remove group mapping' }, { status: 500 })
  }
}
