// WhatsApp Group → customer mapping (intake & approval spec):
// "Configure each WhatsApp Group ID against exactly one ERP
// customer/context. Do not infer group identity from the group name; use
// the provider's immutable Group ID."
//
//   GET  /api/whatsapp/group-mappings — list (master/manager)
//   POST /api/whatsapp/group-mappings — create (super admin only)
//
// Body: { groupId, groupLabel?, customerId? , vendorId?, note? }
// Exactly one of customerId / vendorId must be set.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { getSessionFromRequest } from '@/lib/session'
import { isSuperRole } from '@/lib/roles'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

async function requireSuper(request: Request): Promise<{ username: string } | null> {
  // Group mapping is channel configuration — super admin only. The route is
  // behind ERP auth; verify the SIGNED session cookie (not client headers)
  // AND that the session role is super.
  const session = await getSessionFromRequest(request as never)
  if (!session?.username || !isSuperRole(session.role)) return null
  return { username: session.username }
}

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const rows = await db.whatsAppGroupMapping.findMany({
      orderBy: { createdAt: 'desc' },
    })
    // Enrich with the mapped customer names
    const customerIds = [...new Set(rows.map(r => r.customerId).filter(Boolean))] as string[]
    const vendorIds = [...new Set(rows.map(r => r.vendorId).filter(Boolean))] as string[]
    const apps: Array<{ id: string; name: string; mobile: string }> = customerIds.length
      ? await db.appCustomer.findMany({ where: { id: { in: customerIds } }, select: { id: true, name: true, mobile: true } })
      : []
    const vendors: Array<{ id: string; businessName: string; mobileNo: string }> = vendorIds.length
      ? await db.vendor.findMany({ where: { id: { in: vendorIds } }, select: { id: true, businessName: true, mobileNo: true } })
      : []
    const appMap = new Map(apps.map(a => [a.id, a]))
    const vendorMap = new Map(vendors.map(v => [v.id, v]))
    return NextResponse.json(rows.map(r => ({
      ...r,
      customerName: r.customerId ? appMap.get(r.customerId)?.name || null : null,
      customerMobile: r.customerId ? appMap.get(r.customerId)?.mobile || null : null,
      vendorName: r.vendorId ? vendorMap.get(r.vendorId)?.businessName || null : null,
      vendorMobile: r.vendorId ? vendorMap.get(r.vendorId)?.mobileNo || null : null,
    })))
  } catch (error) {
    console.error('GET whatsapp group-mappings error:', error)
    return NextResponse.json({ error: 'Failed to fetch group mappings' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const superUser = await requireSuper(request)
    if (!superUser) {
      return NextResponse.json({ error: 'Super Admin only' }, { status: 403 })
    }

    const body = await request.json().catch(() => null)
    const groupId = String(body?.groupId || '').trim()
    const groupLabel = String(body?.groupLabel || '').trim()
    const customerId = String(body?.customerId || '').trim()
    const vendorId = String(body?.vendorId || '').trim()
    const note = String(body?.note || '').trim()

    if (!groupId) {
      return NextResponse.json({ error: 'groupId (the provider Group ID) is required — never the group name' }, { status: 400 })
    }
    if (!customerId && !vendorId) {
      return NextResponse.json({ error: 'Select the customer (app) or ERP customer this group belongs to' }, { status: 400 })
    }
    if (customerId && vendorId) {
      return NextResponse.json({ error: 'Map the group to exactly ONE customer' }, { status: 400 })
    }
    if (customerId) {
      const app = await db.appCustomer.findUnique({ where: { id: customerId } })
      if (!app) return NextResponse.json({ error: 'App customer not found' }, { status: 400 })
    }
    if (vendorId) {
      const vendor = await db.vendor.findUnique({ where: { id: vendorId } })
      if (!vendor) return NextResponse.json({ error: 'ERP customer not found' }, { status: 400 })
    }
    const dup = await db.whatsAppGroupMapping.findUnique({ where: { groupId } })
    if (dup) {
      return NextResponse.json({ error: 'This Group ID is already mapped — each Group ID maps to exactly one customer' }, { status: 409 })
    }

    const row = await db.whatsAppGroupMapping.create({
      data: { groupId, groupLabel, customerId: customerId || null, vendorId: vendorId || null, note: note || null, createdBy: user.username },
    })
    await logActivity({ username: user.username, action: 'create', entity: 'whatsapp_group_mapping', entityId: row.id, metadata: { groupId, groupLabel } })
    return NextResponse.json(row, { status: 201 })
  } catch (error) {
    console.error('POST whatsapp group-mappings error:', error)
    return NextResponse.json({ error: 'Failed to create group mapping' }, { status: 500 })
  }
}
