// POST /api/whatsapp/simulate — run an inbound WhatsApp message through the
// real pipeline without Meta (sandbox testing from the ERP WhatsApp Inbox).
// Master/manager only. Supports group chats (Group ID + member sender) and
// forwarded messages (original sender) so the full intake model is testable.
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'
import { processInbound } from '@/lib/whatsapp/pipeline'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const body = await request.json().catch(() => null)
    const phone = String(body?.phone ?? '').trim()
    const text = String(body?.text ?? '')
    const name = String(body?.name ?? '').trim()
    const groupId = String(body?.groupId ?? '').trim()
    const groupLabel = String(body?.groupLabel ?? '').trim()
    const forwardedFrom = String(body?.forwardedFrom ?? '').trim()
    if (!phone || !text) {
      return NextResponse.json({ error: 'phone and text are required' }, { status: 400 })
    }
    const result = await processInbound({
      phone,
      profileName: name || 'Sandbox Tester',
      text,
      // no waMessageId — sandbox messages are always processed
      groupId: groupId || undefined,
      groupLabel: groupLabel || undefined,
      senderPhone: groupId ? phone : undefined,
      senderName: groupId ? (name || 'Group Member') : undefined,
      forwardedFrom: forwardedFrom || undefined,
    })
    return NextResponse.json(result)
  } catch (error) {
    console.error('POST whatsapp simulate error:', error)
    return NextResponse.json({ error: 'Simulation failed' }, { status: 500 })
  }
}
