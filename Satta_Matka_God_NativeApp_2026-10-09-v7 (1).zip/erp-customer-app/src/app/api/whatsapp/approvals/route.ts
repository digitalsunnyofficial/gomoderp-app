// GET /api/whatsapp/approvals?status=pending|approved|rejected|all
// Admin Manager approval queue for WhatsApp vyapar (intake & approval spec).
// Every valid parsed message lands here FIRST; only approval creates the
// ERP transaction. Master/manager only (agents have no WhatsApp access).
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }

    const url = new URL(request.url)
    const status = (url.searchParams.get('status') || 'pending').toLowerCase()
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '100', 10) || 100, 500)
    const where = ['pending', 'approved', 'rejected'].includes(status) ? { status } : {}

    const rows = await db.whatsAppApproval.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: { message: { select: { phone: true, profileName: true, providerTimestamp: true, parserVersion: true } } },
    })

    // Approval-mode state for the UI banner
    const cfg = await db.appConfig.findUnique({ where: { key: 'whatsapp_approval' } })
    const approvalMode = (cfg?.value || 'on').toLowerCase() !== 'off' ? 'on' : 'off'

    return NextResponse.json({
      approvalMode,
      data: rows.map(a => ({
        id: a.id,
        messageId: a.messageId,
        groupId: a.groupId,
        senderPhone: a.senderPhone,
        senderName: a.senderName,
        customerId: a.customerId,
        vendorId: a.vendorId,
        customerName: a.customerName,
        agentUsername: a.agentUsername,
        agentName: a.agentName,
        marketCode: a.marketCode,
        marketName: a.marketName,
        session: a.session,
        rawMessage: a.rawMessage,
        parseSummary: a.parseSummary,
        parsedSnapshot: a.parsedSnapshot,
        total: a.total,
        validationStatus: a.validationStatus,
        validationNotes: a.validationNotes,
        parserVersion: a.parserVersion,
        status: a.status,
        approvedBy: a.approvedBy,
        approvedAt: a.approvedAt,
        rejectedBy: a.rejectedBy,
        rejectedAt: a.rejectedAt,
        rejectionReason: a.rejectionReason,
        txId: a.txId,
        txNumber: a.txNumber,
        createdAt: a.createdAt,
        messagePhone: a.message?.phone || null,
        messageProfileName: a.message?.profileName || null,
      })),
    })
  } catch (error) {
    console.error('GET whatsapp approvals error:', error)
    return NextResponse.json({ error: 'Failed to fetch approvals' }, { status: 500 })
  }
}
