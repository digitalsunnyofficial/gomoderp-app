// POST /api/whatsapp/approvals/[id] — explicit Approve / Reject decision.
//   { action: "approve" }               → creates the ERP transaction, then
//                                         sends the documented confirmation
//                                         reply (only after the tx commits)
//   { action: "reject", reason: "..." } → audit intact, precise notice back
// Master/manager only. Idempotent-safe: non-pending rows are refused.
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { approveWhatsAppApproval, rejectWhatsAppApproval } from '@/lib/whatsapp/pipeline'
import { logActivity } from '@/lib/audit'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json().catch(() => null)
    const action = String(body?.action || '').toLowerCase()

    if (action === 'approve') {
      const existing = await db.whatsAppApproval.findUnique({ where: { id } })
      if (!existing) return NextResponse.json({ error: 'Approval not found' }, { status: 404 })
      if (existing.status !== 'pending') {
        return NextResponse.json({ error: `Approval is already ${existing.status}` }, { status: 409 })
      }
      const outcome = await approveWhatsAppApproval(id, user.username)
      if (!outcome.ok) return NextResponse.json({ error: outcome.error }, { status: 400 })
      await logActivity({
        username: user.username,
        action: 'whatsapp_approve',
        entity: 'whatsapp_approval',
        entityId: id,
        metadata: { txNumber: outcome.txNumber, customerName: existing.customerName },
      }).catch(() => undefined)
      return NextResponse.json(outcome)
    }

    if (action === 'reject') {
      const reason = String(body?.reason || '').trim()
      if (!reason) {
        return NextResponse.json({ error: 'A rejection reason is required' }, { status: 400 })
      }
      const existing = await db.whatsAppApproval.findUnique({ where: { id } })
      if (!existing) return NextResponse.json({ error: 'Approval not found' }, { status: 404 })
      if (existing.status !== 'pending') {
        return NextResponse.json({ error: `Approval is already ${existing.status}` }, { status: 409 })
      }
      const outcome = await rejectWhatsAppApproval(id, user.username, reason)
      if (!outcome.ok) return NextResponse.json({ error: outcome.error }, { status: 400 })
      await logActivity({
        username: user.username,
        action: 'whatsapp_reject',
        entity: 'whatsapp_approval',
        entityId: id,
        metadata: { reason, customerName: existing.customerName },
      }).catch(() => undefined)
      return NextResponse.json(outcome)
    }

    return NextResponse.json({ error: 'action must be approve or reject' }, { status: 400 })
  } catch (error) {
    console.error('POST whatsapp approvals/[id] error:', error)
    return NextResponse.json({ error: 'Approval action failed' }, { status: 500 })
  }
}
