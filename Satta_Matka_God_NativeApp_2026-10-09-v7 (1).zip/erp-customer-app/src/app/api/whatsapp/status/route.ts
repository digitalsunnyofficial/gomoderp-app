// GET /api/whatsapp/status — WhatsApp channel configuration state for the ERP UI.
// Master/manager only.
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { waConfig } from '@/lib/whatsapp/meta'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Not permitted' }, { status: 403 })
    }
    const cfg = waConfig()
    return NextResponse.json({
      mode: cfg.live ? 'live' : 'sandbox',
      verifyTokenSet: Boolean(process.env.WHATSAPP_VERIFY_TOKEN),
      tokenSet: Boolean(cfg.token),
      phoneNumberIdSet: Boolean(cfg.phoneNumberId),
      signatureCheck: Boolean(cfg.appSecret),
      webhookPath: '/api/whatsapp/webhook',
    })
  } catch (error) {
    console.error('GET whatsapp status error:', error)
    return NextResponse.json({ error: 'Failed to read status' }, { status: 500 })
  }
}
