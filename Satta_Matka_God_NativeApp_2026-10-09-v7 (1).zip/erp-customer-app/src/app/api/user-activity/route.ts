import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

/**
 * GET /api/user-activity
 * Query params:
 *   - userId: filter by user
 *   - username: filter by username
 *   - action: filter by action type
 *   - entity: filter by entity type
 *   - market: filter by market
 *   - limit: default 100, max 500
 *   - offset: default 0
 *   - from: ISO date string
 *   - to: ISO date string
 *
 * Returns: { activities, total, summary }
 * summary contains per-user and per-action aggregates
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const username = searchParams.get('username')
    const action = searchParams.get('action')
    const entity = searchParams.get('entity')
    const market = searchParams.get('market')
    const limit = Math.min(parseInt(searchParams.get('limit') || '100'), 500)
    const offset = parseInt(searchParams.get('offset') || '0')
    const from = searchParams.get('from')
    const to = searchParams.get('to')

    const where: Record<string, unknown> = {}
    if (userId) where.userId = userId
    if (username) where.username = username
    if (action) where.action = action
    if (entity) where.entity = entity
    if (market) where.market = market
    if (from || to) {
      where.createdAt = {}
      if (from) (where.createdAt as Record<string, unknown>).gte = new Date(from)
      if (to) (where.createdAt as Record<string, unknown>).lte = new Date(to)
    }

    const [activities, total, byAction, byUser, byEntity] = await Promise.all([
      db.userActivity.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.userActivity.count({ where }),
      // Prisma v6 groupBy has quirks with implicit orderBy/take — keep calls minimal
      db.userActivity.groupBy({
        by: ['action'],
        where,
        _count: true,
      }),
      db.userActivity.groupBy({
        by: ['username'],
        where,
        _count: true,
      }),
      db.userActivity.groupBy({
        by: ['entity'],
        where,
        _count: true,
      }),
    ])

    // Sort aggregations by count (descending) in JS
    const sortByCount = <T extends { _count: number }>(a: T, b: T) => b._count - a._count

    return NextResponse.json({
      activities,
      total,
      summary: {
        byAction: [...byAction].sort(sortByCount).map(b => ({ action: b.action, count: b._count })),
        byUser: [...byUser].sort(sortByCount).slice(0, 20).map(b => ({ username: b.username, count: b._count })),
        byEntity: [...byEntity].sort(sortByCount).map(b => ({ entity: b.entity, count: b._count })),
      },
    })
  } catch (error) {
    console.error('GET user-activity error:', error)
    return NextResponse.json({ error: 'Failed to fetch activity log' }, { status: 500 })
  }
}

/**
 * POST /api/user-activity
 * Records a new activity entry. Typically called from the frontend for actions
 * the backend doesn't otherwise capture (logout, page views, etc.).
 */
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, username, action, entity, entityId, market, recordsAffected, metadata, ipAddress } = body

    if (!username || !action) {
      return NextResponse.json({ error: 'username and action are required' }, { status: 400 })
    }

    const activity = await db.userActivity.create({
      data: {
        userId: userId || null,
        username,
        action,
        entity: entity || '',
        entityId: entityId || null,
        market: market || null,
        recordsAffected: recordsAffected || 1,
        metadata: metadata ? JSON.stringify(metadata) : '{}',
        ipAddress: ipAddress || null,
      },
    })

    return NextResponse.json(activity, { status: 201 })
  } catch (error) {
    console.error('POST user-activity error:', error)
    return NextResponse.json({ error: 'Failed to record activity' }, { status: 500 })
  }
}
