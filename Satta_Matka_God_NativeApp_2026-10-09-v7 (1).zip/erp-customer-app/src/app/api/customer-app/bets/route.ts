import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'
import {
  slotAccepting, starHourAccepting, starlineAccepting, istDate, isStarline,
  starlineName, RATE_LBL, marketWindowToday, marketDisplayName, type BetType,
} from '@/lib/matka/app-engine'
import { GAME_RATES } from '@/lib/matka/games-engine'
import { canonicalPanna } from '@/lib/matka/chart-definitions'
import { mirrorBetsToErpInventory } from '@/lib/matka/erp-mirror'
import { accruePlayCommission } from '@/lib/app-tree'

const DEFAULT_MIN_POINTS = 10
const VALID_MAIN: BetType[] = ['single', 'jodi', 'sp', 'dp', 'tp', 'hs', 'hsb', 'fs']
const VALID_STAR: BetType[] = ['single', 'oddeven', 'sp', 'dp', 'tp']

// Canonical panna representation — EVERY stored number uses the operator
// chart spelling: digits ascending with 0 last (595→559, 012→120, 515→155,
// 733→337). Settlement is digit-set based, so this is presentation-only and
// keeps entry lists, boards, my-bids and ERP mirrors on ONE representation.
function canonNum(type: string, num: string): string {
  const n = String(num || '').trim()
  if (type === 'sp' || type === 'dp' || type === 'tp') return canonicalPanna(n)
  if (type === 'hs' || type === 'hsb' || type === 'fs') {
    // composites "X-PPP" / "PPP-X" / "PPP-QQQ" — canonicalize panna segments
    return n.split('-').map(s => (/^\d{3}$/.test(s) ? canonicalPanna(s) : s)).join('-')
  }
  return n
}

function numLabel(type: string, num: string): string {
  if (type === 'hs') return 'H.Sngm A ' + num
  if (type === 'hsb') return 'H.Sngm B ' + num
  if (type === 'fs') return 'F.Sngm ' + num
  return (RATE_LBL[type] || type) + ' ' + num
}

// GET /api/customer-app/bets?status=pending|won|lost|all — my bids
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  const url = new URL(request.url)
  const status = url.searchParams.get('status') || 'all'
  const where: Record<string, unknown> = { customerId: customer.id }
  if (status !== 'all') where.status = status
  const bets = await db.appBet.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 200,
  })
  // ── Session-qualified identity: enrich every bet with the canonical
  // display name ("Sridevi Day Open") from the ONE market source. ──
  const marketRows = await db.appMarket.findMany()
  const nameByCode = new Map(marketRows.map(m => [m.code, marketDisplayName(m)]))
  const enriched = bets.map(b => ({
    ...b,
    marketName: nameByCode.get(b.marketCode) || b.marketName,
  }))
  const counts = {
    all: await db.appBet.count({ where: { customerId: customer.id } }),
    pending: await db.appBet.count({ where: { customerId: customer.id, status: 'pending' } }),
    won: await db.appBet.count({ where: { customerId: customer.id, status: 'won' } }),
    lost: await db.appBet.count({ where: { customerId: customer.id, status: 'lost' } }),
  }
  return NextResponse.json({ bets: enriched, counts })
}

// POST /api/customer-app/bets — place the bet slip (vyapar)
// body: { items: [{ marketCode, slot, type, num, points, gameCode?, clientRequestId? }] }
// clientRequestId makes every placement replay-safe: a network retry of the
// same slip is detected and ignored (no double debit, no double board points).
export async function POST(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const { items } = await request.json()
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'Enter points in the boxes first' }, { status: 400 })
    }
    if (!customer.canBet) {
      return NextResponse.json({ error: 'Betting disabled for your account — contact support' }, { status: 403 })
    }

    const fresh = await db.appCustomer.findUnique({ where: { id: customer.id } })
    if (!fresh || fresh.status === 'blocked') {
      return NextResponse.json({ error: 'Your account has been blocked — contact support' }, { status: 403 })
    }

    const today = istDate()
    const now = new Date()
    const validated: Array<{
      marketCode: string; marketName: string; betDate: string; slot: string
      type: string; num: string; gameCode: string | null; points: number; rate: number
      clientRequestId: string | null
    }> = []

    for (const it of items as Array<{ marketCode?: string; slot?: string; type?: string; num?: string; points?: number; gameCode?: string; clientRequestId?: string }>) {
      const { marketCode, slot, type, num, points, gameCode } = it
      if (!marketCode || !type || !num || !points) {
        return NextResponse.json({ error: 'Invalid bid item' }, { status: 400 })
      }
      if (!Number.isFinite(points) || points < DEFAULT_MIN_POINTS) {
        return NextResponse.json({ error: `Minimum ${DEFAULT_MIN_POINTS} points per bid (${numLabel(type, num)})` }, { status: 400 })
      }
      if (isStarline(marketCode)) {
        const hour = Number(marketCode.slice(2))
        if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
          return NextResponse.json({ error: 'Invalid starline game' }, { status: 400 })
        }
        if (!(VALID_STAR as string[]).includes(type) || slot !== 'open') {
          return NextResponse.json({ error: 'Invalid starline bid type' }, { status: 400 })
        }
        // Managed starline (ERP-created) — honor its ON/OFF switch, custom
        // name, result minute and bet-closing window. Legacy fallback when
        // the hour has no AppStarline row (accept until the hour strikes).
        const slRow = await db.appStarline.findUnique({ where: { code: marketCode } })
        if (slRow && (!slRow.isOn || !slRow.isActive)) {
          return NextResponse.json({ error: `${slRow.name} is closed — pick a later starline` }, { status: 400 })
        }
        const slName = slRow?.name || starlineName(hour)
        if (slRow) {
          if (!starlineAccepting(slRow, now)) {
            return NextResponse.json({ error: `${slName} is closed — betting stopped ${slRow.betClosingMinutes} min before the result time` }, { status: 400 })
          }
        } else {
          // When the operator manages starlines (any active row exists), only
          // configured hours are bettable — no implicit legacy hours.
          const managed = await db.appStarline.count({ where: { isActive: true } })
          if (managed > 0) {
            return NextResponse.json({ error: `${slName} is not available — pick one of the listed starlines` }, { status: 400 })
          }
          if (!starHourAccepting(hour, now)) {
            return NextResponse.json({ error: `${slName} is closed — pick a later hour` }, { status: 400 })
          }
        }
        validated.push({
          marketCode, marketName: slName, betDate: today,
          slot: 'open', type, num: canonNum(type, String(num)), gameCode: gameCode || null,
          points, rate: GAME_RATES[type] ?? 9.5,
          clientRequestId: it.clientRequestId ? String(it.clientRequestId) : null,
        })
      } else {
        const market = await db.appMarket.findUnique({ where: { code: marketCode } })
        if (!market || !market.isActive) {
          return NextResponse.json({ error: 'Market not available: ' + marketCode }, { status: 400 })
        }
        if (!(VALID_MAIN as string[]).includes(type)) {
          return NextResponse.json({ error: 'Invalid bid type' }, { status: 400 })
        }
        // ── Result-declared lockout, PER COMPONENT ──
        // Declaring the Open panna locks open-session games only; the Close
        // panna locks close-session + jodi/sangam (their outcome becomes known
        // with the close digits). The other session keeps accepting bets.
        const declared = await db.appResult.findUnique({
          where: { marketCode_resultDate: { marketCode, resultDate: today } },
          select: { id: true, openPanna: true, closePanna: true },
        })
        if (declared) {
          // Session follows the slot the client sent — classic TP books slot
          // 'close' from its own UI; motor expansions carry tp-class rows
          // (111/222/333) in whichever session the customer is playing.
          const decSlot = type === 'jodi' ? 'jodi' : (type === 'hs' || type === 'hsb' || type === 'fs') ? 'hs' : (slot === 'close' ? 'close' : 'open')
          const outcomeKnown = decSlot === 'open' ? !!declared.openPanna : !!declared.closePanna
          if (outcomeKnown) {
            return NextResponse.json(
              { error: `${market.name} ${decSlot === 'open' ? 'Open' : 'Close'} result has been declared — betting for this session is closed` },
              { status: 400 }
            )
          }
        }
        // ── Weekly schedule: today's window (master OFF / weekly-off day blocks all) ──
        const w = marketWindowToday(market, now)
        if (!w.on) {
          return NextResponse.json(
            { error: `${market.name} is closed today (weekly schedule) — check the market timings` },
            { status: 400 }
          )
        }
        // ── Game allocation: rate + min-points from the per-market allocation ──
        let rate: number | undefined
        let minPoints = DEFAULT_MIN_POINTS
        if (gameCode) {
          const alloc = await db.gameAllocation.findFirst({
            where: { marketCode, isActive: true, game: { code: gameCode, isActive: true } },
            include: { game: true },
          })
          if (alloc) {
            rate = alloc.rate ?? alloc.game.defaultRate
            minPoints = alloc.minPoints || DEFAULT_MIN_POINTS
          }
        }
        if (points < minPoints) {
          return NextResponse.json({ error: `Minimum ${minPoints} points per bid (${numLabel(type, num)})` }, { status: 400 })
        }
        const s = type === 'jodi' ? 'jodi' : (type === 'hs' || type === 'hsb' || type === 'fs') ? 'hs' : type === 'tp' ? 'close' : (slot === 'close' ? 'close' : 'open')
        const sessioned = ['single', 'sp', 'dp', 'tp'].includes(type)
        if (type === 'tp') {
          // ── Triple Pana window (operator rule 2026-10): TP settles on the
          // CLOSE panna, but it is bettable through the WHOLE betting window —
          // the open session AND the close session — exactly like the classic
          // matka book. Blocked only once both sessions stop accepting. ──
          const openAcc = slotAccepting(w.openTime, w.closeTime, 'open', now, market.betClosingMinutes)
          const closeAcc = slotAccepting(w.openTime, w.closeTime, 'close', now, market.betClosingMinutes)
          if (!openAcc && !closeAcc) {
            return NextResponse.json(
              { error: `Betting is closed for ${market.name} (bets stop ${market.betClosingMinutes} min before the close time)` },
              { status: 400 }
            )
          }
        } else if (sessioned && !slotAccepting(w.openTime, w.closeTime, s as 'open' | 'close', now, market.betClosingMinutes)) {
          return NextResponse.json(
            { error: `Betting is closed for the ${s} session of ${market.name} (closes ${market.betClosingMinutes} min before time)` },
            { status: 400 }
          )
        }
        // ── Jodi session rule (2026-09): jodi = open digit + close digit —
        // it can only be placed while the OPEN session is accepting. Blocked
        // on close-session market rows entirely, and once the open window
        // ends (close session begins / open result declared). ──
        if (type === 'jodi' && (market.session === 'close' || !slotAccepting(w.openTime, w.closeTime, 'open', now, market.betClosingMinutes))) {
          return NextResponse.json(
            { error: `Jodi is available only during the Open session of ${market.name} — jodi combines the open + close digits` },
            { status: 400 }
          )
        }
        const finalRate = rate ?? (GAME_RATES[type] ?? 0)
        validated.push({
          marketCode, marketName: marketDisplayName(market), betDate: today,
          slot: s, type, num: canonNum(type, String(num)), gameCode: gameCode || null,
          points, rate: finalRate,
          clientRequestId: it.clientRequestId ? String(it.clientRequestId) : null,
        })
      }
    }

    // ── Idempotency: drop items whose clientRequestId was already placed ──
    const novel: typeof validated = []
    let duplicates = 0
    for (const v of validated) {
      if (v.clientRequestId) {
        const dup = await db.appBet.findFirst({ where: { customerId: fresh.id, clientRequestId: v.clientRequestId }, select: { id: true } })
        if (dup) { duplicates++; continue }
      }
      novel.push(v)
    }
    if (!novel.length) {
      return NextResponse.json({
        ok: true, placedCount: 0, total: 0, duplicates,
        wallet: fresh.wallet, bets: [], mirrorNote: '',
        note: 'All bids were already placed (duplicate submission ignored)',
      })
    }

    const total = novel.reduce((a, b) => a + b.points, 0)
    if (total > fresh.wallet) {
      return NextResponse.json({ error: 'Insufficient wallet points — Add Points first' }, { status: 400 })
    }

    // Atomic placement: debit wallet once, write bets + ledger rows,
    // and file the agent PLAY commission (X% of points played) for every
    // placed bet — one ledger row per bet, inside the same transaction so
    // a play can never exist without its commission (and vice versa).
    // Deposits never earn commission (operator rule 2026-10): a win only
    // refills the wallet, and the NEXT play earns commission again.
    let commissionFiled = 0
    const placed = await db.$transaction(async (tx) => {
      const updated = await tx.appCustomer.update({
        where: { id: fresh.id, wallet: { gte: total } },
        data: { wallet: { decrement: total } },
      })
      let running = fresh.wallet // balance before the first debit
      const rows: Array<Record<string, unknown>> = []
      for (const b of novel) {
        running -= b.points
        const bet = await tx.appBet.create({ data: { ...b, customerId: fresh.id } })
        rows.push(bet)
        await tx.appTransaction.create({
          data: {
            customerId: fresh.id, type: 'bet', amount: -b.points,
            balanceAfter: running,
            remark: `${RATE_LBL[b.type]} ${b.num} · ${b.marketName}`,
          },
        })
        if (await accruePlayCommission(tx, bet, fresh)) commissionFiled++
      }
      return { bets: rows, wallet: updated.wallet }
    })

    // ── ERP mirror (single source of vyapar) ──
    // App bets land in the ERP Entry List and feed the ERP single/double/
    // triple charts exactly like a WhatsApp paste. Runs after the bet
    // transaction commits; a mirror failure never blocks the placement.
    let mirrorNote = ''
    try {
      const mirror = await mirrorBetsToErpInventory(
        novel.map(b => ({ marketCode: b.marketCode, marketName: b.marketName, betDate: b.betDate, slot: b.slot, type: b.type, num: b.num, points: b.points, gameCode: b.gameCode })),
        customer.name || 'Customer',
        customer.mobile || '',
      )
      mirrorNote = mirror.ok ? ` · ERP entry: ${mirror.rows} row${mirror.rows === 1 ? '' : 's'}` : ' · ERP mirror skipped'
    } catch (mirrorErr) {
      console.error('erp mirror threw', mirrorErr)
      mirrorNote = ' · ERP mirror skipped'
    }

    return NextResponse.json({
      ok: true,
      placedCount: placed.bets.length,
      total,
      duplicates,
      wallet: placed.wallet,
      bets: placed.bets,
      commissionFiled,
      mirrorNote,
    })
  } catch (err) {
    console.error('app bets POST error', err)
    return NextResponse.json({ error: 'Could not place bids — please try again' }, { status: 500 })
  }
}
