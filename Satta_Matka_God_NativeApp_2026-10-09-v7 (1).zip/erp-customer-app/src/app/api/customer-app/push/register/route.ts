// ────────────────────────────────────────────────────────────────────────────
// POST /api/customer-app/push/register   (Task 31 — native app push)
//   Auth: Bearer <AppSession token>
//   Body: { token: "ExponentPushToken[...]" }
//   → stores the ExpoPushToken on AppCustomer.pushToken
// DELETE → clears it (called on app logout, best-effort)
// GET    → { registered: boolean } so the app can show push status
// ────────────────────────────────────────────────────────────────────────────
import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'
import { isValidExpoPushToken, pushEnabled } from '@/lib/push/expo-push'

export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  return NextResponse.json({
    registered: !!customer.pushToken,
    enabled: pushEnabled(),
  })
}

export async function POST(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const { token } = await request.json()
    if (!isValidExpoPushToken(token)) {
      return NextResponse.json(
        { error: 'Valid ExpoPushToken required (ExponentPushToken[...])' },
        { status: 400 },
      )
    }
    await db.appCustomer.update({
      where: { id: customer.id },
      data: { pushToken: token.trim() },
    })
    return NextResponse.json({ ok: true, registered: true })
  } catch (err) {
    console.error('push register error', err)
    return NextResponse.json({ error: 'Could not register for push' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    await db.appCustomer.update({
      where: { id: customer.id },
      data: { pushToken: null },
    })
    return NextResponse.json({ ok: true, registered: false })
  } catch (err) {
    console.error('push deregister error', err)
    return NextResponse.json({ error: 'Could not deregister push' }, { status: 500 })
  }
}
