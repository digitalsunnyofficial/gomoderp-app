import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'

// ──────────────────────────────────────────────────────────
// UPI INTENT — native app "Pay with PhonePe / Paytm / GPay".
// Creates the PENDING deposit request server-side (so the
// operator already sees it) and returns a ready-made UPI deep
// link the app opens with Linking.openURL():
//   upi://pay?pa=<vpa>&pn=<name>&am=<amt>&cu=INR&tn=<ref>
// The ref (tn) doubles as the tracking note; the wallet is
// credited when the payment feed confirms it via
// POST /api/upi/auto-verify (or admin approval as fallback).
// ──────────────────────────────────────────────────────────

export async function POST(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const { amount, app: upiApp } = await request.json()
    const amt = Number(amount)
    if (!Number.isFinite(amt) || amt <= 0) {
      return NextResponse.json({ error: 'Enter a valid amount' }, { status: 400 })
    }
    const settings = await db.appPaymentSetting.findUnique({ where: { id: 'primary' } })
    if (!settings?.upiId) {
      return NextResponse.json({ error: 'UPI payments are not configured yet — use the QR flow' }, { status: 400 })
    }
    if (amt < settings.minDeposit) {
      return NextResponse.json({ error: `Minimum deposit is ₹${settings.minDeposit}` }, { status: 400 })
    }

    // Stable tracking ref — also stored as the request UTR so admin /
    // auto-verify can reconcile the payment to this exact request.
    const ref = `SMG${customer.id.slice(-6).toUpperCase()}${Date.now().toString().slice(-8)}`
    const fund = await db.appFundRequest.create({
      data: {
        customerId: customer.id,
        amount: amt,
        method: 'UPI',
        utr: ref,
        note: `UPI intent${upiApp ? ' · ' + String(upiApp) : ''} — awaiting payment confirmation`,
      },
    })

    const params = new URLSearchParams({
      pa: settings.upiId,
      pn: settings.payeeName || 'Merchant',
      am: amt.toFixed(2),
      cu: 'INR',
      tn: ref,
    })
    const upiUri = `upi://pay?${params.toString()}`
    return NextResponse.json({
      ok: true, fundId: fund.id, ref, amount: amt, upiUri,
      upiId: settings.upiId, payeeName: settings.payeeName,
    })
  } catch (err) {
    console.error('customer-app upi-intent POST error', err)
    return NextResponse.json({ error: 'Could not start the UPI payment' }, { status: 500 })
  }
}
