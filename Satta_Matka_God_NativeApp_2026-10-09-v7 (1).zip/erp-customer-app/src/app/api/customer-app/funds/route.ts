import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'

// GET /api/customer-app/funds — my deposit requests
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  const funds = await db.appFundRequest.findMany({
    where: { customerId: customer.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  return NextResponse.json({ funds })
}

// POST /api/customer-app/funds — submit a deposit request (approved by admin)
export async function POST(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const { amount, method, utr } = await request.json()
    const amt = Number(amount)
    const ps = await db.appPaymentSetting.findUnique({ where: { id: 'primary' } })
    const min = ps?.minDeposit || 100
    if (!amt || amt < min) {
      return NextResponse.json({ error: `Minimum deposit ₹${min}` }, { status: 400 })
    }
    if (!String(utr || '').trim()) {
      return NextResponse.json({ error: 'Enter the UTR / transaction reference' }, { status: 400 })
    }
    const fund = await db.appFundRequest.create({
      data: {
        customerId: customer.id,
        amount: amt,
        method: method === 'Bank Transfer' ? 'Bank Transfer' : 'UPI',
        utr: String(utr || '—').trim() || '—',
        status: 'pending',
      },
    })
    return NextResponse.json({ ok: true, fund })
  } catch (err) {
    console.error('app funds POST error', err)
    return NextResponse.json({ error: 'Could not submit request' }, { status: 500 })
  }
}
