import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { newAppToken, appSessionExpiry, toSafeCustomer } from '@/lib/app-auth'

// POST /api/customer-app/auth/login — mobile + password
export async function POST(request: Request) {
  try {
    const { mobile, password } = await request.json()
    if (!mobile || !password) {
      return NextResponse.json({ error: 'Mobile number and password are required' }, { status: 400 })
    }
    const customer = await db.appCustomer.findUnique({ where: { mobile: String(mobile) } })
    if (!customer || !(await bcrypt.compare(String(password), customer.password))) {
      return NextResponse.json({ error: 'Invalid mobile number or password' }, { status: 401 })
    }
    if (customer.status === 'blocked') {
      return NextResponse.json({ error: 'Your account has been blocked — contact support' }, { status: 403 })
    }
    if (customer.approvalStatus === 'pending') {
      return NextResponse.json({ error: 'Your account is awaiting approval from the admin — you will be able to log in once approved' }, { status: 403 })
    }
    if (customer.approvalStatus === 'rejected') {
      return NextResponse.json({ error: 'Your registration was not approved — contact support' }, { status: 403 })
    }
    await db.appCustomer.update({
      where: { id: customer.id },
      data: { lastLoginAt: new Date(), deviceInfo: request.headers.get('user-agent') || 'unknown' },
    })
    const token = newAppToken()
    await db.appSession.create({
      data: {
        token,
        customerId: customer.id,
        deviceInfo: request.headers.get('user-agent') || 'unknown',
        ipAddress: request.headers.get('x-forwarded-for') || 'unknown',
        expiresAt: appSessionExpiry(),
      },
    })
    return NextResponse.json({ token, customer: toSafeCustomer(customer) })
  } catch (err) {
    console.error('app login error', err)
    return NextResponse.json({ error: 'Login failed — please try again' }, { status: 500 })
  }
}
