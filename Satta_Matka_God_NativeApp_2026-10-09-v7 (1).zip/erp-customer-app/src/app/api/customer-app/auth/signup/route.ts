import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { newAppToken, appSessionExpiry, toSafeCustomer, isSignupApprovalRequired } from '@/lib/app-auth'
import { applyAgentTree } from '@/lib/app-tree'

// POST /api/customer-app/auth/signup — customer self-registration from the app.
// Behaviour is governed by the Master Admin signup-approval toggle
// (AppConfig key "signup_approval_required", managed from ERP ▸ Customer List):
//   ON  (default) → the signup stays "pending" until a superior approves it
//                   from the ERP Customer List; no session is issued.
//   OFF           → the account is approved instantly and the customer is
//                   logged in straight from registration (session token issued).
export async function POST(request: Request) {
  try {
    const { name, mobile, password, referral } = await request.json()
    if (!name || !mobile || !password) {
      return NextResponse.json({ error: 'Name, mobile and password are required' }, { status: 400 })
    }
    if (!/^\d{10}$/.test(String(mobile))) {
      return NextResponse.json({ error: 'Enter a valid 10-digit mobile number' }, { status: 400 })
    }
    if (String(password).length < 6) {
      return NextResponse.json({ error: 'Password must be at least 6 characters' }, { status: 400 })
    }
    const existing = await db.appCustomer.findUnique({ where: { mobile: String(mobile) } })
    if (existing) {
      return NextResponse.json({ error: 'This mobile number is already registered — please log in' }, { status: 409 })
    }
    const approvalRequired = await isSignupApprovalRequired()
    const hashed = await bcrypt.hash(String(password), 10)
    const customer = await db.appCustomer.create({
      data: {
        name: String(name).trim(),
        mobile: String(mobile),
        password: hashed,
        status: 'active',
        approvalStatus: approvalRequired ? 'pending' : 'approved',
        approvedBy: approvalRequired ? null : 'auto — approval toggle off',
        approvedAt: approvalRequired ? null : new Date(),
        deviceInfo: request.headers.get('user-agent') || 'unknown',
      },
    })

    // ── Agent tree filing — "customer A of agent A" ──
    // A signup WITH a referral is filed under that agent; without one, under
    // the configured default agent (the operator's documented business rule).
    // Never blocks the signup itself.
    try {
      await applyAgentTree(customer.id, typeof referral === 'string' ? referral : null)
    } catch (treeErr) {
      console.error('agent tree filing failed (signup continues)', treeErr)
    }
    // Re-read so the response carries the filed agent (used by the app profile).
    const filed = await db.appCustomer.findUnique({ where: { id: customer.id } })

    // ── Toggle OFF: instant access — issue the session right here ──
    if (!approvalRequired) {
      const token = newAppToken()
      await db.appSession.create({
        data: {
          token,
          customerId: customer.id,
          deviceInfo: request.headers.get('user-agent') || 'unknown',
          ipAddress: request.headers.get('x-forwarded-for') || 'unknown',
          expiresAt: appSessionExpiry(),
        },
      })
      await db.appNotification.create({
        data: { customerId: customer.id, icon: 'gem', text: 'Welcome to Satta Matka God! Your account is ready — enjoy the games.' },
      })
      await db.appCustomer.update({
        where: { id: customer.id },
        data: { lastLoginAt: new Date() },
      })
      return NextResponse.json({
        pendingApproval: false,
        message: 'Welcome! Your account has been created.',
        token,
        customer: toSafeCustomer(filed || customer),
      })
    }

    // ── Toggle ON (default): approval flow — no session yet ──
    await db.appNotification.create({
      data: { customerId: customer.id, icon: 'gem', text: 'Welcome to Satta Matka God! Your account is awaiting approval — you will be notified once approved.' },
    })
    return NextResponse.json({
      pendingApproval: true,
      message: 'Registration submitted. Your account is awaiting approval.',
      customer: { id: customer.id, name: customer.name, mobile: customer.mobile, agentName: filed?.agentName || null },
    })
  } catch (err) {
    console.error('app signup error', err)
    return NextResponse.json({ error: 'Signup failed — please try again' }, { status: 500 })
  }
}
