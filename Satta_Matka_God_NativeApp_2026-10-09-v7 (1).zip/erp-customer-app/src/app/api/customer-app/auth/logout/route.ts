import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// POST /api/customer-app/auth/logout — invalidate the current Bearer session
export async function POST(request: Request) {
  const auth = request.headers.get('authorization') || ''
  const token = auth.toLowerCase().startsWith('bearer ') ? auth.slice(7).trim() : ''
  if (token) {
    await db.appSession.deleteMany({ where: { token } }).catch(() => {})
  }
  return NextResponse.json({ ok: true })
}
