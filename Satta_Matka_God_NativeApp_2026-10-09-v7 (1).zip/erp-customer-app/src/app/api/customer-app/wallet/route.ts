import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'

// GET /api/customer-app/wallet — balance + recent ledger
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  const [txns, pendingFunds, pendingWithdraws] = await Promise.all([
    db.appTransaction.findMany({
      where: { customerId: customer.id },
      orderBy: { createdAt: 'desc' },
      take: 100,
    }),
    db.appFundRequest.findMany({
      where: { customerId: customer.id, status: 'pending' },
      orderBy: { createdAt: 'desc' },
    }),
    db.appWithdrawRequest.findMany({
      where: { customerId: customer.id, status: 'pending' },
      orderBy: { createdAt: 'desc' },
    }),
  ])
  return NextResponse.json({
    wallet: customer.wallet,
    transactions: txns,
    pendingFunds,
    pendingWithdraws,
  })
}
