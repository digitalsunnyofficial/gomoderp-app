import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { getAppCustomer, appUnauthorized, toSafeCustomer } from '@/lib/app-auth'

// GET /api/customer-app/me — current customer profile + wallet
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  return NextResponse.json({ customer: toSafeCustomer(customer) })
}

// PATCH /api/customer-app/me — change password and/or language
export async function PATCH(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const body = await request.json()
    const { oldPassword, newPassword, language } = body

    // Language-only update (used by the post-login language screen + profile switcher)
    if (!oldPassword && !newPassword) {
      if (typeof language === 'string' && ['en', 'hi', 'gu', 'mr'].includes(language)) {
        await db.appCustomer.update({ where: { id: customer.id }, data: { language } })
        return NextResponse.json({ ok: true, language })
      }
      return NextResponse.json({ error: 'Nothing to update' }, { status: 400 })
    }

    if (!oldPassword || !newPassword) {
      return NextResponse.json({ error: 'Old and new passwords are required' }, { status: 400 })
    }
    if (String(newPassword).length < 6) {
      return NextResponse.json({ error: 'New password must be at least 6 characters' }, { status: 400 })
    }
    const full = await db.appCustomer.findUnique({ where: { id: customer.id } })
    if (!full || !(await bcrypt.compare(String(oldPassword), full.password))) {
      return NextResponse.json({ error: 'Current password is incorrect' }, { status: 403 })
    }
    const hashed = await bcrypt.hash(String(newPassword), 10)
    await db.appCustomer.update({ where: { id: customer.id }, data: { password: hashed } })
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('app me PATCH error', err)
    return NextResponse.json({ error: 'Could not update profile' }, { status: 500 })
  }
}
