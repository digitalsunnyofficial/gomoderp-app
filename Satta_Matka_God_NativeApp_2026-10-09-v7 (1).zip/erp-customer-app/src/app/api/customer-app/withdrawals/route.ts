import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'

// GET /api/customer-app/withdrawals — my withdrawal requests
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  const withdrawals = await db.appWithdrawRequest.findMany({
    where: { customerId: customer.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  return NextResponse.json({ withdrawals })
}

// POST /api/customer-app/withdrawals — request withdrawal (amount held immediately)
export async function POST(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const { amount } = await request.json()
    const amt = Number(amount)
    if (!amt || amt < 500) {
      return NextResponse.json({ error: 'Minimum withdrawal ₹500' }, { status: 400 })
    }
    const fresh = await db.appCustomer.findUnique({ where: { id: customer.id } })
    if (!fresh) return appUnauthorized()
    if (!fresh.canWithdraw) {
      return NextResponse.json({ error: 'Withdrawals disabled for your account' }, { status: 403 })
    }
    if (amt > fresh.wallet) {
      return NextResponse.json({ error: 'Amount exceeds wallet balance' }, { status: 400 })
    }
    // Hold immediately: debit wallet + ledger + request row (atomic)
    const result = await db.$transaction(async (tx) => {
      const updated = await tx.appCustomer.update({
        where: { id: fresh.id, wallet: { gte: amt } },
        data: { wallet: { decrement: amt } },
      })
      await tx.appTransaction.create({
        data: {
          customerId: fresh.id, type: 'withdraw_hold', amount: -amt,
          balanceAfter: updated.wallet, remark: 'Withdrawal request (hold)',
        },
      })
      const w = await tx.appWithdrawRequest.create({
        data: { customerId: fresh.id, amount: amt, status: 'pending' },
      })
      return { w, wallet: updated.wallet }
    })
    return NextResponse.json({ ok: true, withdrawal: result.w, wallet: result.wallet })
  } catch (err) {
    console.error('app withdrawals POST error', err)
    return NextResponse.json({ error: 'Could not submit request' }, { status: 500 })
  }
}
