import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'
import { deriveDigit, istDate, marketDisplayName } from '@/lib/matka/app-engine'

// GET /api/customer-app/results?market=code  — last 35 days of a market
// GET /api/customer-app/results?market=code&months=12 — up to 12 months back
//   (charts month navigation; additive param — no param keeps the 35-day default)
// GET /api/customer-app/results?starline=1   — today's starline board
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  const url = new URL(request.url)
  const market = url.searchParams.get('market')
  const starline = url.searchParams.get('starline')

  if (starline) {
    const rows = await db.appResult.findMany({
      where: { marketCode: { startsWith: 'st' }, resultDate: istDate() },
      orderBy: { marketCode: 'asc' },
    })
    return NextResponse.json({
      board: rows.map(r => ({
        hour: Number(r.marketCode.slice(2)),
        panna: r.openPanna,
        digit: r.openPanna ? deriveDigit(r.openPanna) : null,
      })),
    })
  }

  if (!market) return NextResponse.json({ error: 'market required' }, { status: 400 })
  // months=1..12 → since = first day of (months-1) months ago (aligned with the
  // chart's month navigation); anything else keeps the historical 35-day window.
  const monthsRaw = Number(url.searchParams.get('months') || '0')
  const months = Number.isFinite(monthsRaw) && monthsRaw >= 1 && monthsRaw <= 12 ? Math.floor(monthsRaw) : 0
  const now = new Date()
  const since = months
    ? istDate(new Date(now.getFullYear(), now.getMonth() - (months - 1), 1))
    : istDate(new Date(Date.now() - 35 * 86400000))
  const rows = await db.appResult.findMany({
    where: { marketCode: market, resultDate: { gte: since } },
    orderBy: { resultDate: 'desc' },
    ...(months ? { take: 400 } : {}),
  })
  const marketRow = await db.appMarket.findUnique({ where: { code: market } })
  return NextResponse.json({
    marketName: marketRow ? marketDisplayName(marketRow) : market,
    results: rows,
  })
}
