import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'

// GET /api/customer-app/notifications — personal + broadcast, latest 50
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  const notifications = await db.appNotification.findMany({
    where: { OR: [{ customerId: customer.id }, { customerId: null }] },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  return NextResponse.json({ notifications })
}
