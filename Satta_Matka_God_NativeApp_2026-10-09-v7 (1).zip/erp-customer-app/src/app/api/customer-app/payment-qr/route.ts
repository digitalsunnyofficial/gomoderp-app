import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized } from '@/lib/app-auth'

// GET /api/customer-app/payment-qr — business QR for the deposit modal (app side)
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  let s = await db.appPaymentSetting.findUnique({ where: { id: 'primary' } })
  if (!s) s = await db.appPaymentSetting.create({ data: { id: 'primary' } })
  return NextResponse.json({
    upiId: s.upiId,
    payeeName: s.payeeName,
    qrImage: s.qrImage,
    note: s.note,
    minDeposit: s.minDeposit,
    pointRate: 1, // 1 point = ₹1
  })
}
