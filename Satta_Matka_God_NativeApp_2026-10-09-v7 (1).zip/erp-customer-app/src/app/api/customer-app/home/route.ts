import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAppCustomer, appUnauthorized, toSafeCustomer } from '@/lib/app-auth'
import { slotAccepting, starHourAccepting, starlineAccepting, deriveDigit, istDate, marketWindowToday, marketDisplayName } from '@/lib/matka/app-engine'

// GET /api/customer-app/home — everything the home screen needs in one call
export async function GET(request: Request) {
  const customer = await getAppCustomer(request)
  if (!customer) return appUnauthorized()
  try {
    const [markets, cfgRows, todayResults, yesterdayResults, starBoard, allocations, myBetsToday, starlines] = await Promise.all([
      db.appMarket.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } }),
      db.appConfig.findMany({ where: { key: { in: ['notice', 'banners'] } } }),
      db.appResult.findMany({ where: { resultDate: istDate() } }),
      db.appResult.findMany({ where: { resultDate: istDate(new Date(Date.now() - 86400000)) } }),
      db.appResult.findMany({
        where: { marketCode: { startsWith: 'st' }, resultDate: istDate() },
        orderBy: { marketCode: 'asc' },
      }),
      db.gameAllocation.findMany({
        where: { isActive: true, game: { isActive: true } },
        include: { game: true },
        orderBy: { marketCode: 'asc' },
      }),
      // the customer's own bids per market today — powers the win/loss result prompt
      db.appBet.groupBy({
        by: ['marketCode', 'status'],
        where: { customerId: customer.id, betDate: istDate(), marketCode: { not: { startsWith: 'st' } } },
        _count: { _all: true },
        _sum: { points: true, win: true },
      }),
      // ERP-managed starlines — the operator creates one or many, each with
      // its own result time; OFF/disabled starlines are hidden from the app
      db.appStarline.findMany({
        where: { isActive: true, isOn: true },
        orderBy: [{ hour: 'asc' }, { minute: 'asc' }],
      }),
    ])
    const cfg = Object.fromEntries(cfgRows.map(r => [r.key, r.value]))
    const now = new Date()

    // Allocated games grouped per market
    const gamesByMarket: Record<string, Array<{ code: string; name: string; base: string; session: string; expansion: string; icon: string; erpMapping: string; rate: number; minPoints: number }>> = {}
    for (const a of allocations) {
      if (a.game.session !== 'both' && a.game.session !== 'open' && a.game.session !== 'close') continue
      ;(gamesByMarket[a.marketCode] ||= []).push({
        code: a.game.code, name: a.game.name, base: a.game.base,
        session: a.game.session, expansion: a.game.expansion, icon: a.game.icon,
        erpMapping: a.game.erpMapping,
        rate: a.rate ?? a.game.defaultRate, minPoints: a.minPoints,
      })
    }

    // Per-market summary of the customer's own bids today
    const myByMarket: Record<string, { bids: number; staked: number; winAmount: number; won: number; lost: number }> = {}
    for (const g of myBetsToday) {
      const s = (myByMarket[g.marketCode] ||= { bids: 0, staked: 0, winAmount: 0, won: 0, lost: 0 })
      s.bids += g._count._all
      s.staked += g._sum.points || 0
      s.winAmount += g._sum.win || 0
      if (g.status === 'won') s.won = g._count._all
      if (g.status === 'lost') s.lost = g._count._all
    }

    const marketsView = markets.map(m => {
      const declaredToday = todayResults.some(r => r.marketCode === m.code)
      const w = marketWindowToday(m, now)
      const tr = todayResults.find(r => r.marketCode === m.code) || null
      return {
        id: m.id, code: m.code, name: m.name, category: m.category,
        phase: m.phase || 'day', session: m.session || 'both',
        displayName: marketDisplayName(m),
        openTime: w.openTime, closeTime: w.closeTime,
        betClosingMinutes: m.betClosingMinutes,
        marketStatus: m.marketStatus,
        isOn: m.isOn && w.on,
        // Per-component accepting: declaring the Open panna locks only the open
        // session; the close session keeps accepting until ITS result is out.
        openAccepting: !(tr && tr.openPanna) && w.on && slotAccepting(w.openTime, w.closeTime, 'open', now, m.betClosingMinutes),
        closeAccepting: !(tr && tr.closePanna) && w.on && slotAccepting(w.openTime, w.closeTime, 'close', now, m.betClosingMinutes),
        resultDeclared: declaredToday,
        todayResult: tr ? {
          openPanna: tr.openPanna, closePanna: tr.closePanna,
          openDigit: tr.openDigit, closeDigit: tr.closeDigit,
          jodi: tr.jodi, declaredAt: tr.declaredAt, updatedAt: tr.updatedAt,
        } : null,
        mySummary: myByMarket[m.code] || { bids: 0, staked: 0, winAmount: 0, won: 0, lost: 0 },
        games: gamesByMarket[m.code] || [],
      }
    })

    // Latest results per market: today's if declared, else yesterday's
    const latest = markets.map(m => {
      const t = todayResults.find(r => r.marketCode === m.code)
      const y = yesterdayResults.find(r => r.marketCode === m.code)
      const r = t || y
      return r ? {
        marketCode: m.code, marketName: marketDisplayName(m), date: r.resultDate,
        open: r.openPanna ? `${r.openPanna}-${r.openDigit}` : '---',
        close: r.closePanna ? `${r.closePanna}-${r.closeDigit}` : '---',
        jodi: r.jodi,
      } : null
    }).filter(Boolean)

    const nextHour = (now.getHours() + 1) % 24
    // Result stamp: changes whenever any today-result is (re)declared — lets
    // the app detect corrections immediately and re-show the result popup.
    const resultsStamp = todayResults.reduce<string>((max, r) => {
      const t = r.updatedAt instanceof Date ? r.updatedAt.toISOString() : String(r.updatedAt)
      return t > max ? t : max
    }, '')
    return NextResponse.json({
      customer: toSafeCustomer(customer),
      resultsStamp,
      notice: cfg.notice || 'Welcome to Satta Matka God — play responsibly.',
      banners: cfg.banners ? JSON.parse(cfg.banners) : [],
      markets: marketsView,
      latestResults: latest,
      starline: {
        nextHour,
        nextAccepting: starHourAccepting(nextHour),
        board: starBoard.map(r => ({
          hour: Number(r.marketCode.slice(2)),
          panna: r.openPanna,
          digit: r.openPanna ? deriveDigit(r.openPanna) : null,
        })),
        // configured starlines with today's declared result (if any)
        starlines: starlines.map(sl => {
          const r = starBoard.find(b => b.marketCode === sl.code)
          return {
            code: sl.code, name: sl.name, hour: sl.hour, minute: sl.minute,
            betClosingMinutes: sl.betClosingMinutes,
            accepting: starlineAccepting(sl, now),
            panna: r?.openPanna || null,
            digit: r?.openPanna ? deriveDigit(r.openPanna) : null,
          }
        }),
      },
    })
  } catch (err) {
    console.error('app home error', err)
    return NextResponse.json({ error: 'Could not load home' }, { status: 500 })
  }
}
