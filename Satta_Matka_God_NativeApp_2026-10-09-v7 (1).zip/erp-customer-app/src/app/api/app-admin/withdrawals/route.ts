import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { appWalletMove } from '@/lib/app-auth'
import { notifyCustomer } from '@/lib/push/expo-push' // Task 31 native-app push

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/withdrawals — withdrawal requests
export async function GET(request: Request) {
  const url = new URL(request.url)
  const status = url.searchParams.get('status') || 'all'
  const withdrawals = await db.appWithdrawRequest.findMany({
    where: status === 'all' ? undefined : { status },
    orderBy: { createdAt: 'desc' },
    take: 300,
  })
  const ids = [...new Set(withdrawals.map(w => w.customerId))]
  const customers = await db.appCustomer.findMany({
    where: { id: { in: ids } },
    select: { id: true, name: true, mobile: true, wallet: true },
  })
  const cmap = Object.fromEntries(customers.map(c => [c.id, c]))
  return NextResponse.json({
    withdrawals: withdrawals.map(w => ({
      ...w,
      customerName: cmap[w.customerId]?.name || '—',
      customerMobile: cmap[w.customerId]?.mobile || '',
      customerWallet: cmap[w.customerId]?.wallet ?? 0,
    })),
  })
}

// POST /api/app-admin/withdrawals — mark paid or reject (refund hold)
// body: { id, action: 'paid' | 'reject', note? }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const { id, action, note } = await request.json()
    if (!id || !['paid', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'id and action (paid/reject) required' }, { status: 400 })
    }
    const w = await db.appWithdrawRequest.findUnique({ where: { id } })
    if (!w) return NextResponse.json({ error: 'Request not found' }, { status: 404 })
    if (w.status !== 'pending') {
      return NextResponse.json({ error: `Request already ${w.status}` }, { status: 400 })
    }
    const by = request.headers.get('x-session-username') || 'admin'

    if (action === 'paid') {
      await db.appWithdrawRequest.update({
        where: { id },
        data: { status: 'paid', processedBy: by, processedAt: new Date(), note: note || null },
      })
      await db.appTransaction.create({
        data: {
          customerId: w.customerId, type: 'withdraw_paid', amount: 0,
          balanceAfter: (await db.appCustomer.findUnique({ where: { id: w.customerId } }))?.wallet || 0,
          remark: `Withdrawal ₹${w.amount.toLocaleString('en-IN')} paid`,
        },
      })
      await notifyCustomer({
        customerId: w.customerId, icon: 'arrow-up-circle',
        text: `Your withdrawal of ₹${w.amount.toLocaleString('en-IN')} has been paid`,
        pushTitle: 'Withdrawal paid',
      })
    } else {
      // Refund the held amount
      await db.$transaction(async (tx) => {
        await tx.appWithdrawRequest.update({
          where: { id },
          data: { status: 'rejected', processedBy: by, processedAt: new Date(), note: note || null },
        })
        await appWalletMove(tx as never, w.customerId, 'withdraw_refund', w.amount,
          `Withdrawal rejected — amount refunded`)
      })
      await notifyCustomer({
        customerId: w.customerId, icon: 'alert-triangle',
        text: `Your withdrawal of ₹${w.amount.toLocaleString('en-IN')} was rejected — amount refunded to wallet`,
        pushTitle: 'Withdrawal rejected',
      })
    }
    await logActivity({
      username: by, action: `withdrawal_${action}`, entity: 'app_withdraw_request', entityId: id,
      recordsAffected: 1, metadata: { amount: w.amount },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('app-admin withdrawals POST error', err)
    return NextResponse.json({ error: 'Could not process request' }, { status: 500 })
  }
}
