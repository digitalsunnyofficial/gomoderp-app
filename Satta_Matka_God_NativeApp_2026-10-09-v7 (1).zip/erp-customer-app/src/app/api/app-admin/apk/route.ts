import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// ──────────────────────────────────────────────────────────
// APP BUILD (APK) — operator uploads the release APK from the
// ERP; the landing page + /customerapp serve it at the canonical
// URL /apk/sm-gomod.apk (see src/app/apk/[file]/route.ts).
// The bytes are stored in the DB (ApkArtifact) so the upload
// survives every redeploy — the SQLite file is the one artifact
// that is always restored. Exactly ONE row is kept.
// ──────────────────────────────────────────────────────────

const MAX_APK_BYTES = 150 * 1024 * 1024 // 150 MB — far above any Expo release APK

// GET /api/app-admin/apk — metadata only (never the bytes)
export async function GET(request: Request) {
  const role = roleOf(request)
  if (role !== 'super' && role !== 'manager') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
  }
  const apk = await db.apkArtifact.findFirst({ orderBy: { updatedAt: 'desc' } })
  if (!apk) return NextResponse.json({ hasApk: false })
  return NextResponse.json({
    hasApk: true,
    apk: {
      fileName: apk.fileName,
      size: apk.size,
      versionLabel: apk.versionLabel,
      uploadedBy: apk.uploadedBy,
      uploadedAt: apk.uploadedAt,
      updatedAt: apk.updatedAt,
    },
  })
}

// POST /api/app-admin/apk — multipart upload (Super Admin only)
// fields: file (the .apk binary), versionLabel (optional string)
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const form = await request.formData()
    const file = form.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'Choose an APK file to upload' }, { status: 400 })
    }
    const name = (file.name || '').trim()
    if (!/\.apk$/i.test(name)) {
      return NextResponse.json({ error: 'Only .apk files are accepted' }, { status: 400 })
    }
    if (file.size < 1024) {
      return NextResponse.json({ error: 'This file is too small to be a real APK' }, { status: 400 })
    }
    if (file.size > MAX_APK_BYTES) {
      return NextResponse.json({ error: 'APK is larger than the 150 MB limit' }, { status: 400 })
    }
    const versionLabel = String(form.get('versionLabel') || '').trim().slice(0, 80)
    const bytes = Buffer.from(await file.arrayBuffer())

    // sanity: an APK is a ZIP — the local file header magic is "PK\x03\x04"
    if (!(bytes[0] === 0x50 && bytes[1] === 0x4b)) {
      return NextResponse.json({ error: 'This is not a valid APK (not a ZIP package)' }, { status: 400 })
    }

    const uploadedBy = request.headers.get('x-session-username') || 'admin'
    await db.apkArtifact.deleteMany({})
    const apk = await db.apkArtifact.create({
      data: { fileName: name, size: bytes.length, versionLabel, data: bytes, uploadedBy },
    })
    await logActivity({
      username: uploadedBy,
      action: 'upload',
      entity: 'apk',
      entityId: apk.id,
      recordsAffected: 1,
      metadata: { fileName: name, size: bytes.length, versionLabel },
    }).catch(() => {})
    return NextResponse.json({
      ok: true,
      apk: { fileName: apk.fileName, size: apk.size, versionLabel: apk.versionLabel, uploadedAt: apk.uploadedAt },
    })
  } catch {
    return NextResponse.json({ error: 'Upload failed — try again' }, { status: 500 })
  }
}

// DELETE /api/app-admin/apk — remove the uploaded build (Super Admin only).
// The landing page button keeps working if a static file exists on the server;
// otherwise the download reports unavailable until a new upload.
export async function DELETE(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  const gone = await db.apkArtifact.deleteMany({})
  await logActivity({
    username: request.headers.get('x-session-username') || 'admin',
    action: 'delete',
    entity: 'apk',
    recordsAffected: gone.count,
  }).catch(() => {})
  return NextResponse.json({ ok: true })
}
