import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/payment-settings — business QR + UPI config (ERP side)
// The auto-verify secret is masked unless the caller is Super Admin.
export async function GET(request: Request) {
  let s = await db.appPaymentSetting.findUnique({ where: { id: 'primary' } })
  if (!s) s = await db.appPaymentSetting.create({ data: { id: 'primary' } })
  const isSuper = roleOf(request) === 'super'
  const settings = isSuper ? s : { ...s, autoVerifySecret: s.autoVerifySecret ? '••••••••' : '' }
  return NextResponse.json({ settings })
}

// POST /api/app-admin/payment-settings — upload / update the business QR (Super Admin)
// body: { upiId?, payeeName?, qrImage?, note?, minDeposit? }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const data: Record<string, unknown> = { updatedBy: request.headers.get('x-session-username') || 'admin' }
    if (typeof body.upiId === 'string') data.upiId = body.upiId.trim()
    if (typeof body.payeeName === 'string') data.payeeName = body.payeeName.trim()
    if (typeof body.note === 'string') data.note = body.note.trim()
    if (body.minDeposit !== undefined) {
      const md = Number(body.minDeposit)
      if (!Number.isFinite(md) || md < 1) {
        return NextResponse.json({ error: 'Minimum deposit must be at least ₹1' }, { status: 400 })
      }
      data.minDeposit = md
    }
    if (typeof body.qrImage === 'string') {
      if (body.qrImage && !/^data:image\/(png|jpe?g|webp);base64,/.test(body.qrImage)) {
        return NextResponse.json({ error: 'QR must be a PNG / JPG / WEBP image' }, { status: 400 })
      }
      if (body.qrImage.length > 2_500_000) {
        return NextResponse.json({ error: 'QR image too large — keep it under ~1.5 MB' }, { status: 400 })
      }
      data.qrImage = body.qrImage
    }
    // ── UPI auto-capture config ──
    if (typeof body.autoCredit === 'boolean') data.autoCredit = body.autoCredit
    if (typeof body.autoVerifySecret === 'string') {
      // "••••" mask round-trips as "keep current" — never overwrite with dots
      if (body.autoVerifySecret.trim() && !/^[•\.]+$/.test(body.autoVerifySecret.trim())) {
        data.autoVerifySecret = body.autoVerifySecret.trim()
      }
    }
    if (body.autoCreditWindowMin !== undefined) {
      const w = Number(body.autoCreditWindowMin)
      if (!Number.isFinite(w) || w < 1 || w > 720) {
        return NextResponse.json({ error: 'Matching window must be 1–720 minutes' }, { status: 400 })
      }
      data.autoCreditWindowMin = Math.round(w)
    }
    if (data.autoCredit === true) {
      const cur = await db.appPaymentSetting.findUnique({ where: { id: 'primary' } })
      const effSecret = data.autoVerifySecret ?? cur?.autoVerifySecret ?? ''
      if (!effSecret) {
        return NextResponse.json({ error: 'Set a webhook secret before enabling auto-credit' }, { status: 400 })
      }
    }
    const settings = await db.appPaymentSetting.upsert({
      where: { id: 'primary' },
      create: { id: 'primary', ...data },
      update: data,
    })
    await logActivity({
      username: String(data.updatedBy), action: 'payment_settings_update', entity: 'app_payment_settings',
      recordsAffected: 1, metadata: { upiId: settings.upiId, qrUpdated: typeof body.qrImage === 'string' },
    })
    return NextResponse.json({ ok: true, settings })
  } catch (err) {
    console.error('payment-settings POST error', err)
    return NextResponse.json({ error: 'Could not save payment settings' }, { status: 500 })
  }
}
