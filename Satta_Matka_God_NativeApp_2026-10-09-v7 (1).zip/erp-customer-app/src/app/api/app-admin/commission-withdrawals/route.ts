import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'

// ──────────────────────────────────────────────────────────
// AGENT COMMISSION WITHDRAWALS (operator rule 2026-10)
// Complete payout flow for the commission agents EARN:
//   1. Agent requests a cash-out (POST) — amount is validated
//      against AVAILABLE = Σ(pending commission) − Σ(pending
//      withdrawal requests), so commission can never be
//      double-withdrawn.
//   2. Master admin approves (PUT paid) — the underlying
//      AgentCommission rows are marked PAID oldest-first (FIFO)
//      inside one transaction, exactly covering the amount.
//      Rejecting simply closes the request (nothing was locked).
// Agent = ERP role "user" (x-session-role headers, same as the
// commissions API). Super sees everything.
// ──────────────────────────────────────────────────────────

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}
function usernameOf(request: Request): string {
  return request.headers.get('x-session-username') || 'admin'
}

// Available cash-out for one agent = pending commission − pending requests
export async function availableFor(agentUsername: string): Promise<number> {
  const [earned, requested] = await Promise.all([
    db.agentCommission.aggregate({
      where: { agentUsername, status: 'pending' }, _sum: { amount: true },
    }),
    db.agentCommissionWithdrawal.aggregate({
      where: { agentUsername, status: 'pending' }, _sum: { amount: true },
    }),
  ])
  return Math.max(0, (earned._sum.amount || 0) - (requested._sum.amount || 0))
}

// GET — agent: own requests + available · master: all requests
export async function GET(request: Request) {
  const role = roleOf(request)
  const isAgent = role === 'user'
  const me = usernameOf(request)
  const where = isAgent ? { agentUsername: me } : undefined
  const [rows, agents] = await Promise.all([
    db.agentCommissionWithdrawal.findMany({ where, orderBy: { createdAt: 'desc' }, take: 200 }),
    isAgent ? Promise.resolve([]) : db.user.findMany({
      where: { role: 'user' }, select: { username: true, name: true },
    }),
  ])
  // Available: the agent sees their own; master sees one per agent
  const usernames = isAgent ? [me] : agents.map(a => a.username)
  const availEntries = await Promise.all(usernames.map(async u => [u, await availableFor(u)] as const))
  return NextResponse.json({
    withdrawals: rows,
    available: isAgent ? availEntries[0][1] : Object.fromEntries(availEntries),
    scope: isAgent ? 'self' : 'all',
  })
}

// POST — agent (role "user") files a withdrawal request
// body: { amount, method?, payoutTo? }
export async function POST(request: Request) {
  const role = roleOf(request)
  const me = usernameOf(request)
  if (role !== 'user' && role !== 'super') {
    return NextResponse.json({ error: 'Agents only — masters pay out from this queue instead' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const amount = Number(body.amount)
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: 'Enter a valid withdrawal amount' }, { status: 400 })
    }
    const method = ['UPI', 'Bank Transfer'].includes(body.method) ? body.method : 'UPI'
    const payoutTo = String(body.payoutTo || '').trim()

    const agent = await db.user.findFirst({ where: { username: me, role: 'user' } })
    if (role === 'user' && !agent) {
      return NextResponse.json({ error: 'Agent account not found' }, { status: 404 })
    }
    const available = await availableFor(me)
    if (amount > available) {
      return NextResponse.json({ error: `Amount exceeds your available commission (₹${available.toLocaleString('en-IN', { maximumFractionDigits: 2 })})` }, { status: 400 })
    }
    const row = await db.agentCommissionWithdrawal.create({
      data: {
        agentUsername: me,
        agentName: agent?.name || null,
        amount, method,
        payoutTo: payoutTo || null,
      },
    })
    await logActivity({
      username: me, action: 'commission_withdraw_request', entity: 'agent_commission_withdrawal', entityId: row.id,
      metadata: { amount, method, payoutTo },
    })
    return NextResponse.json({ ok: true, withdrawal: row, available: available - amount })
  } catch (err) {
    console.error('commission-withdrawals POST error', err)
    return NextResponse.json({ error: 'Could not file the withdrawal request' }, { status: 500 })
  }
}

// PUT — master admin processes a request: paid | reject
// body: { id, action: 'paid' | 'reject', note? }
export async function PUT(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const { id, action, note } = await request.json()
    if (!id || !['paid', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'id and action (paid/reject) required' }, { status: 400 })
    }
    const w = await db.agentCommissionWithdrawal.findUnique({ where: { id } })
    if (!w) return NextResponse.json({ error: 'Request not found' }, { status: 404 })
    if (w.status !== 'pending') {
      return NextResponse.json({ error: `Request already ${w.status}` }, { status: 400 })
    }
    const by = usernameOf(request)

    if (action === 'paid') {
      // FIFO-cover: settle the agent's pending commission rows PAID oldest-
      // first until the requested amount is covered EXACTLY — a partially
      // covered row is split (covered part → paid, remainder → stays pending
      // as its own row) so the commission ledger always equals the payouts.
      // Guarded inside one transaction; insufficient balance aborts cleanly.
      const done = await db.$transaction(async (tx) => {
        const upd = await tx.agentCommissionWithdrawal.updateMany({
          where: { id, status: 'pending' },
          data: { status: 'paid', processedBy: by, processedAt: new Date(), adminNote: note || null },
        })
        if (upd.count === 0) return null
        const pend = await tx.agentCommission.findMany({
          where: { agentUsername: w.agentUsername, status: 'pending' },
          orderBy: { createdAt: 'asc' },
        })
        let need = w.amount
        let settled = 0
        for (const row of pend) {
          if (need <= 0.001) break
          if (row.amount <= need + 0.001) {
            // fully covered
            await tx.agentCommission.update({
              where: { id: row.id },
              data: { status: 'paid', paidAt: new Date(), paidBy: by, note: `Paid via withdrawal ${id.slice(-8).toUpperCase()}` },
            })
            need -= row.amount
            settled++
          } else {
            // partial cover → split: this row shrinks to the covered part
            // (marked paid) and the remainder stays pending as a new row
            await tx.agentCommission.update({
              where: { id: row.id },
              data: { amount: need, status: 'paid', paidAt: new Date(), paidBy: by, note: `Paid via withdrawal ${id.slice(-8).toUpperCase()} (partial)` },
            })
            await tx.agentCommission.create({
              data: {
                agentUsername: row.agentUsername, agentName: row.agentName,
                customerId: row.customerId, customerName: row.customerName, customerMobile: row.customerMobile,
                source: row.source, betId: null, fundRequestId: null,
                baseAmount: row.baseAmount, marketName: row.marketName, detail: row.detail,
                rate: row.rate, amount: row.amount - need,
                status: 'pending', note: `Remainder after withdrawal ${id.slice(-8).toUpperCase()}`,
              },
            })
            need = 0
            settled++
          }
        }
        if (need > 0.001) {
          throw new Error(`INSUFFICIENT:${settled}`)
        }
        return settled
      })
      if (done === null) {
        return NextResponse.json({ error: 'Request already processed' }, { status: 409 })
      }
      await logActivity({
        username: by, action: 'commission_withdraw_paid', entity: 'agent_commission_withdrawal', entityId: id,
        metadata: { amount: w.amount, agentUsername: w.agentUsername, commissionRows: done },
      })
      return NextResponse.json({ ok: true, commissionRows: done })
    }

    // reject — nothing was locked; just close the request
    await db.agentCommissionWithdrawal.update({
      where: { id },
      data: { status: 'rejected', processedBy: by, processedAt: new Date(), adminNote: note || 'Rejected by admin' },
    })
    await logActivity({
      username: by, action: 'commission_withdraw_reject', entity: 'agent_commission_withdrawal', entityId: id,
      metadata: { amount: w.amount, agentUsername: w.agentUsername, note: note || null },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    const msg = err instanceof Error ? err.message : ''
    if (msg.startsWith('INSUFFICIENT')) {
      return NextResponse.json({ error: 'Agent no longer has enough pending commission (rows were cancelled?) — reject the request instead' }, { status: 409 })
    }
    console.error('commission-withdrawals PUT error', err)
    return NextResponse.json({ error: 'Could not process the request' }, { status: 500 })
  }
}
