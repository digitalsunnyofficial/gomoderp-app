import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// Guard: ERP session required (proxy)
function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/customers/detail?id=… — everything about one app customer
// on a single page: profile, history (bids + ledger), withdrawal data,
// winning data, loss data and overall data.
export async function GET(request: Request) {
  if (!['super', 'manager'].includes(roleOf(request))) {
    return NextResponse.json({ error: 'Access denied' }, { status: 403 })
  }
  const url = new URL(request.url)
  const id = url.searchParams.get('id') || ''
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })

  const customer = await db.appCustomer.findUnique({ where: { id } })
  if (!customer) return NextResponse.json({ error: 'Customer not found' }, { status: 404 })

  const [bets, transactions, funds, withdrawals, agg, wonAgg, lostAgg, typeAgg] = await Promise.all([
    db.appBet.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 150 }),
    db.appTransaction.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 100 }),
    db.appFundRequest.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    db.appWithdrawRequest.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    db.appBet.aggregate({
      where: { customerId: id },
      _count: { _all: true }, _sum: { points: true, win: true },
    }),
    db.appBet.aggregate({
      where: { customerId: id, status: 'won' },
      _count: { _all: true }, _sum: { points: true, win: true },
    }),
    db.appBet.aggregate({
      where: { customerId: id, status: 'lost' },
      _count: { _all: true }, _sum: { points: true, win: true },
    }),
    db.appBet.groupBy({
      by: ['type'],
      where: { customerId: id },
      _count: { _all: true }, _sum: { points: true, win: true },
    }),
  ])

  const staked = agg._sum.points || 0
  const won = wonAgg._sum.win || 0
  const stakedLost = lostAgg._sum.points || 0
  const deposited = transactions.filter(t => t.type === 'deposit' || t.type === 'admin_credit').reduce((a, t) => a + t.amount, 0)
  const withdrawn = withdrawals.filter(w => w.status === 'paid').reduce((a, w) => a + w.amount, 0)
  const withdrawPending = withdrawals.filter(w => w.status === 'pending').reduce((a, w) => a + w.amount, 0)

  return NextResponse.json({
    profile: {
      id: customer.id, name: customer.name, mobile: customer.mobile,
      wallet: customer.wallet, status: customer.status,
      approvalStatus: customer.approvalStatus, approvedBy: customer.approvedBy,
      approvedAt: customer.approvedAt, canBet: customer.canBet, canWithdraw: customer.canWithdraw,
      deviceInfo: customer.deviceInfo, lastLoginAt: customer.lastLoginAt, createdAt: customer.createdAt,
    },
    overall: {
      wallet: customer.wallet,
      bids: agg._count._all,
      staked,
      won,
      wonBids: wonAgg._count._all,
      lostBids: lostAgg._count._all,
      stakedLost,
      net: won - staked, // payout minus stakes
      deposited,
      withdrawn,
      withdrawPending,
      pendingFunds: funds.filter(f => f.status === 'pending').length,
    },
    byType: typeAgg.map(t => ({
      type: t.type, bids: t._count._all, staked: t._sum.points || 0, won: t._sum.win || 0,
    })),
    bets, transactions, funds, withdrawals,
  })
}
