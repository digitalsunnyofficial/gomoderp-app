import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { appWalletMove } from '@/lib/app-auth'
import { logActivity } from '@/lib/audit'

// Guard: ERP session required (proxy). Mutations: super only.
function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}
function forbidden() {
  return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
}

// GET /api/app-admin/customers — app customer directory with stats.
// DATA ISOLATION (access-control.ts): Super Admin / Admin see the whole
// directory; AGENTS see ONLY the customers filed under their own agent code
// (AppCustomer.agentUsername = session username). An agent who onboarded
// nobody therefore sees an empty list — never the system-wide directory.
export async function GET(request: Request) {
  const role = roleOf(request)
  if (!role) {
    return NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 })
  }
  const isAdmin = role === 'super' || role === 'manager'
  const sessionUsername = request.headers.get('x-session-username') || ''

  const url = new URL(request.url)
  const search = (url.searchParams.get('search') || '').trim()
  const searchWhere = search ? { OR: [
    { name: { contains: search } },
    { mobile: { contains: search } },
  ] } : undefined
  const where = isAdmin ? searchWhere : {
    ...(searchWhere || {}),
    agentUsername: sessionUsername,
  }
  const customers = await db.appCustomer.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 300,
  })
  const ids = customers.map(c => c.id)
  const [betGroups, pendingFunds, pendingWithdraws] = await Promise.all([
    db.appBet.groupBy({
      by: ['customerId'],
      where: { customerId: { in: ids } },
      _count: { _all: true },
      _sum: { points: true, win: true },
    }),
    db.appFundRequest.groupBy({
      by: ['customerId'],
      where: { customerId: { in: ids }, status: 'pending' },
      _count: { _all: true },
    }),
    db.appWithdrawRequest.groupBy({
      by: ['customerId'],
      where: { customerId: { in: ids }, status: 'pending' },
      _count: { _all: true },
    }),
  ])
  const betMap = Object.fromEntries(betGroups.map(g => [g.customerId, g]))
  const fundMap = Object.fromEntries(pendingFunds.map(g => [g.customerId, g._count._all]))
  const wdMap = Object.fromEntries(pendingWithdraws.map(g => [g.customerId, g._count._all]))
  return NextResponse.json({
    customers: customers.map(c => {
      const b = betMap[c.id]
      return {
        id: c.id, name: c.name, mobile: c.mobile, wallet: c.wallet,
        status: c.status, canBet: c.canBet, canWithdraw: c.canWithdraw,
        approvalStatus: c.approvalStatus,
        approvedBy: c.approvedBy, approvedAt: c.approvedAt,
        createdAt: c.createdAt, lastLoginAt: c.lastLoginAt,
        // ── Agent filing ("customer A of agent A") ──
        referral: c.referral, agentUsername: c.agentUsername, agentName: c.agentName,
        betsCount: b?._count._all || 0,
        totalStaked: b?._sum.points || 0,
        totalWon: b?._sum.win || 0,
        pendingFunds: fundMap[c.id] || 0,
        pendingWithdraws: wdMap[c.id] || 0,
      }
    }),
  })
}

// PATCH /api/app-admin/customers — toggle flags / block / approve / reset password
// body: { id, canBet?, canWithdraw?, status?, action?: 'approve'|'reject'|'reset_password', newPassword? }
export async function PATCH(request: Request) {
  if (roleOf(request) !== 'super') return forbidden()
  try {
    const body = await request.json()
    const { id, canBet, canWithdraw, status, action, newPassword } = body
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const by = request.headers.get('x-session-username') || 'admin'

    // ── Approval flow (same superior-approval semantics as ERP signups) ──
    if (action === 'approve' || action === 'reject') {
      const approvalStatus = action === 'approve' ? 'approved' : 'rejected'
      const updated = await db.appCustomer.update({
        where: { id },
        data: { approvalStatus, approvedBy: by, approvedAt: new Date() },
      })
      await db.appNotification.create({
        data: {
          customerId: id, icon: action === 'approve' ? 'check' : 'alert-triangle',
          text: action === 'approve'
            ? 'Your account has been approved — welcome to Satta Matka God! Add points and start playing.'
            : 'Your registration was not approved. Please contact support.',
        },
      })
      await logActivity({
        username: by, action: `customer_${action}`, entity: 'app_customer', entityId: id,
        metadata: { mobile: updated.mobile },
      })
      return NextResponse.json({ ok: true, customer: updated })
    }

    // ── Password reset (ERP side; customer can also change it in-app) ──
    if (action === 'reset_password') {
      if (!newPassword || String(newPassword).length < 6) {
        return NextResponse.json({ error: 'New password must be at least 6 characters' }, { status: 400 })
      }
      const hashed = await bcrypt.hash(String(newPassword), 10)
      const updated = await db.appCustomer.update({ where: { id }, data: { password: hashed } })
      // kill sessions so the new password takes effect immediately
      await db.appSession.deleteMany({ where: { customerId: id } })
      await logActivity({
        username: by, action: 'customer_reset_password', entity: 'app_customer', entityId: id,
        metadata: { mobile: updated.mobile },
      })
      return NextResponse.json({ ok: true })
    }

    const data: Record<string, unknown> = {}
    if (typeof canBet === 'boolean') data.canBet = canBet
    if (typeof canWithdraw === 'boolean') data.canWithdraw = canWithdraw
    if (status === 'active' || status === 'blocked') data.status = status
    const updated = await db.appCustomer.update({ where: { id }, data })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'update', entity: 'app_customer', entityId: id,
      metadata: { data },
    })
    return NextResponse.json({ ok: true, customer: updated })
  } catch (err) {
    console.error('app-admin customers PATCH error', err)
    return NextResponse.json({ error: 'Update failed' }, { status: 500 })
  }
}

// POST /api/app-admin/customers — manual wallet adjustment
// body: { id, amount (+/-), remark }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') return forbidden()
  try {
    const { id, amount, remark } = await request.json()
    const amt = Number(amount)
    if (!id || !Number.isFinite(amt) || amt === 0) {
      return NextResponse.json({ error: 'id and non-zero amount required' }, { status: 400 })
    }
    const fresh = await db.appCustomer.findUnique({ where: { id } })
    if (!fresh) return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    if (amt < 0 && fresh.wallet + amt < 0) {
      return NextResponse.json({ error: 'Adjustment would make wallet negative' }, { status: 400 })
    }
    const balance = await db.$transaction(async (tx) =>
      appWalletMove(tx as never, id,
        amt > 0 ? 'admin_credit' : 'admin_debit', amt,
        amt > 0 ? `Admin credit — ${remark || 'manual adjustment'}` : `Admin debit — ${remark || 'manual adjustment'}`)
    )
    await db.appNotification.create({
      data: {
        customerId: id, icon: amt > 0 ? 'plus-circle' : 'minus-circle',
        text: `Wallet ${amt > 0 ? 'credited' : 'debited'} ₹${Math.abs(amt).toLocaleString('en-IN')} by admin`,
      },
    })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'wallet_adjust', entity: 'app_customer', entityId: id,
      metadata: { amount: amt, remark },
    })
    return NextResponse.json({ ok: true, wallet: balance })
  } catch (err) {
    console.error('app-admin customers POST error', err)
    return NextResponse.json({ error: 'Adjustment failed' }, { status: 500 })
  }
}
