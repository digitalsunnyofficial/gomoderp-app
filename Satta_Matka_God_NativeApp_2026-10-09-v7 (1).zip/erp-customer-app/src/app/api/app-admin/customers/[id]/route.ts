import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// ──────────────────────────────────────────────────────────
// CUSTOMER 360 — everything about ONE customer on one page:
// profile + tree + wallet + betting totals (win/loss/net) +
// deposits, withdrawals, full ledger, market-wise staking and
// recent bids. Powers the consolidated Customer List page.
// ──────────────────────────────────────────────────────────

// GET /api/app-admin/customers/[id] — full customer dossier
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const role = roleOf(request)
  if (role !== 'super' && role !== 'manager') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
  }
  const { id } = await params
  const customer = await db.appCustomer.findUnique({ where: { id } })
  if (!customer) return NextResponse.json({ error: 'Customer not found' }, { status: 404 })

  const [betsAgg, deposits, withdrawals, txns, recentBets, marketGroups, notifications] = await Promise.all([
    db.appBet.aggregate({
      where: { customerId: id },
      _count: { _all: true },
      _sum: { points: true, win: true },
    }),
    db.appFundRequest.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    db.appWithdrawRequest.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    db.appTransaction.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 80 }),
    db.appBet.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 40 }),
    db.appBet.groupBy({
      by: ['marketCode', 'marketName'],
      where: { customerId: id },
      _count: { _all: true },
      _sum: { points: true, win: true },
    }),
    db.appNotification.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' }, take: 15 }),
  ])

  const statusGroups = await db.appBet.groupBy({
    by: ['status'],
    where: { customerId: id },
    _count: { _all: true },
    _sum: { points: true, win: true },
  })
  const st = Object.fromEntries(statusGroups.map(g => [g.status, g]))

  const staked = betsAgg._sum.points || 0
  const won = betsAgg._sum.win || 0

  return NextResponse.json({
    customer: {
      id: customer.id, name: customer.name, mobile: customer.mobile,
      wallet: customer.wallet, status: customer.status,
      approval: customer.approvalStatus, approvalStatus: customer.approvalStatus,
      approvedBy: customer.approvedBy, approvedAt: customer.approvedAt,
      canBet: customer.canBet, canWithdraw: customer.canWithdraw,
      lang: customer.language, langChosen: Boolean(customer.language),
      referral: customer.referral,
      agentUsername: customer.agentUsername, agentName: customer.agentName,
      adminUsername: customer.adminUsername, adminName: customer.adminName,
      deviceInfo: customer.deviceInfo,
      lastLoginAt: customer.lastLoginAt, createdAt: customer.createdAt,
    },
    totals: {
      bets: betsAgg._count._all,
      staked,
      won,
      net: won - staked,                 // + = customer profit, − = house profit
      pending: st.pending?._count._all || 0,
      pendingStake: st.pending?._sum.points || 0,
      lost: st.lost?._count._all || 0,
      lostStake: st.lost?._sum.points || 0,
      wonBets: st.won?._count._all || 0,
      depositsApproved: deposits.filter(d => d.status === 'approved').reduce((a, b) => a + b.amount, 0),
      withdrawalsPaid: withdrawals.filter(w => w.status === 'paid').reduce((a, b) => a + b.amount, 0),
      pendingDeposits: deposits.filter(d => d.status === 'pending').length,
      pendingWithdrawals: withdrawals.filter(w => w.status === 'pending').length,
    },
    deposits,
    withdrawals,
    ledger: txns,
    recentBets,
    markets: marketGroups.map(g => ({
      marketCode: g.marketCode, marketName: g.marketName,
      bets: g._count._all, staked: g._sum.points || 0, won: g._sum.win || 0,
    })),
    notifications,
  })
}
