import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { AGENT_COMMISSION_RATE_KEY, DEFAULT_AGENT_COMMISSION_RATE, globalCommissionRate } from '@/lib/app-tree'

// ── Agent Commission API ─────────────────────────────────────
// GET  — ledger + rollups + config. Scoped: role "user" (agent) sees ONLY
//        their own rows; master/manager see everything (config included
//        only for super/manager). Commission is filed on PLAY (one row per
//        placed bet); customerRollup gives the per-customer detailed report
//        for both master and agent views.
// PUT  — super only: mark_paid | cancel | set_global_rate | set_agent_rate
//        Body: { action, id?, note?, rate?, agentUsername? }

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}
function usernameOf(request: Request): string {
  return request.headers.get('x-session-username') || 'admin'
}

export async function GET(request: Request) {
  const role = roleOf(request)
  const isAgent = role === 'user'
  const where = isAgent ? { agentUsername: usernameOf(request) } : undefined

  const [rows, pendingAgg, paidAgg, agentRollup, customerRollup] = await Promise.all([
    db.agentCommission.findMany({ where, orderBy: { createdAt: 'desc' }, take: 500 }),
    db.agentCommission.aggregate({ where: { ...where, status: 'pending' }, _count: { _all: true }, _sum: { amount: true } }),
    db.agentCommission.aggregate({ where: { ...where, status: 'paid' }, _count: { _all: true }, _sum: { amount: true } }),
    db.agentCommission.groupBy({
      by: ['agentUsername'],
      where: { ...(where || {}), status: { in: ['pending', 'paid'] } },
      _sum: { amount: true, baseAmount: true },
      _count: { _all: true },
    }),
    db.agentCommission.groupBy({
      by: ['customerId', 'agentUsername'],
      where: { ...(where || {}), status: { in: ['pending', 'paid'] } },
      _sum: { amount: true, baseAmount: true },
      _count: { _all: true },
    }),
  ])

  // Customer names for the per-customer rollup (detailed report)
  const rollupCustomerIds = customerRollup.map(r => r.customerId)
  const rollupCustomers = rollupCustomerIds.length
    ? await db.appCustomer.findMany({
        where: { id: { in: rollupCustomerIds } },
        select: { id: true, name: true, mobile: true, wallet: true },
      })
    : []
  const rcmap = Object.fromEntries(rollupCustomers.map(c => [c.id, c]))

  // Agents directory (master/manager only — agents never see the list)
  const [agents, globalRateCfg] = await Promise.all([
    isAgent ? Promise.resolve([]) : db.user.findMany({
      where: { role: 'user', isLocked: false },
      select: { id: true, username: true, name: true, commissionRate: true, status: true },
      orderBy: { createdAt: 'asc' },
    }),
    isAgent ? Promise.resolve(null) : db.appConfig.findUnique({ where: { key: AGENT_COMMISSION_RATE_KEY } }),
  ])

  return NextResponse.json({
    commissions: rows,
    summary: {
      pendingCount: pendingAgg._count._all,
      pendingAmount: pendingAgg._sum.amount || 0,
      paidCount: paidAgg._count._all,
      paidAmount: paidAgg._sum.amount || 0,
    },
    agentRollup: agentRollup.map(r => ({
      agentUsername: r.agentUsername,
      totalCommission: r._sum.amount || 0,
      totalPlayed: r._sum.baseAmount || 0,
      count: r._count._all,
    })),
    customerRollup: customerRollup
      .map(r => ({
        customerId: r.customerId,
        agentUsername: r.agentUsername,
        customerName: rcmap[r.customerId]?.name || '—',
        customerMobile: rcmap[r.customerId]?.mobile || '',
        wallet: rcmap[r.customerId]?.wallet ?? 0,
        played: r._sum.baseAmount || 0,
        commission: r._sum.amount || 0,
        count: r._count._all,
      }))
      .sort((a, b) => b.commission - a.commission),
    agents: agents.map(a => ({
      id: a.id, username: a.username, name: a.name,
      commissionRate: a.commissionRate, status: a.status,
    })),
    // Effective global rate: what the admin set, or the built-in default 2%
    // when nothing is configured yet (operator rule 2026-10).
    globalRate: isAgent ? DEFAULT_AGENT_COMMISSION_RATE : await globalCommissionRate(),
    globalRateIsDefault: isAgent ? true : !globalRateCfg,
    scope: isAgent ? 'self' : 'all',
  })
}

export async function PUT(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const { action, id, note, rate, agentUsername } = body
    const by = usernameOf(request)

    // ── Global default rate ──
    if (action === 'set_global_rate') {
      const r = Number(rate)
      if (!Number.isFinite(r) || r < 0 || r > 100) {
        return NextResponse.json({ error: 'Rate must be between 0 and 100' }, { status: 400 })
      }
      await db.appConfig.upsert({
        where: { key: AGENT_COMMISSION_RATE_KEY },
        update: { value: String(r) },
        create: { key: AGENT_COMMISSION_RATE_KEY, value: String(r) },
      })
      await logActivity({
        username: by, action: 'commission_global_rate', entity: 'app_config', entityId: AGENT_COMMISSION_RATE_KEY,
        metadata: { rate: r },
      })
      return NextResponse.json({ ok: true, globalRate: r })
    }

    // ── Per-agent override (null clears the override → global default) ──
    if (action === 'set_agent_rate') {
      if (!agentUsername) return NextResponse.json({ error: 'agentUsername required' }, { status: 400 })
      const agent = await db.user.findFirst({ where: { username: agentUsername, role: 'user' } })
      if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 })
      const override = rate === null || rate === '' ? null : Number(rate)
      if (override !== null && (!Number.isFinite(override) || override < 0 || override > 100)) {
        return NextResponse.json({ error: 'Override must be between 0 and 100 (or empty for global)' }, { status: 400 })
      }
      await db.user.update({ where: { id: agent.id }, data: { commissionRate: override } })
      await logActivity({
        username: by, action: 'commission_agent_rate', entity: 'user', entityId: agent.id,
        metadata: { agentUsername, override },
      })
      return NextResponse.json({ ok: true, agentUsername, commissionRate: override })
    }

    // ── Ledger row actions ──
    if (!['mark_paid', 'cancel'].includes(action)) {
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 })
    }
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const row = await db.agentCommission.findUnique({ where: { id } })
    if (!row) return NextResponse.json({ error: 'Commission row not found' }, { status: 404 })
    if (row.status !== 'pending') {
      return NextResponse.json({ error: `Row already ${row.status}` }, { status: 400 })
    }

    const status = action === 'mark_paid' ? 'paid' : 'cancelled'
    const updated = await db.agentCommission.update({
      where: { id },
      data: {
        status,
        paidAt: action === 'mark_paid' ? new Date() : null,
        paidBy: action === 'mark_paid' ? by : null,
        note: note || (action === 'cancel' ? 'Cancelled by admin' : row.note),
      },
    })
    await logActivity({
      username: by, action: `commission_${action}`, entity: 'agent_commission', entityId: id,
      metadata: { agentUsername: row.agentUsername, amount: row.amount, note: note || null },
    })
    return NextResponse.json({ ok: true, commission: updated })
  } catch (err) {
    console.error('app-admin commissions PUT error', err)
    return NextResponse.json({ error: 'Could not process request' }, { status: 500 })
  }
}
