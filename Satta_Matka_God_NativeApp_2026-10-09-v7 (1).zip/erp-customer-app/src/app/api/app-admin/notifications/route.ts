import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { sendExpoPush, pushEnabled } from '@/lib/push/expo-push'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// ────────────────────────────────────────────────────────────────────────────
// App Notifications — master-admin management of native-app notifications.
//
// Reuses the EXISTING AppNotification convention (see
// /api/customer-app/notifications): a row with customerId = null is a
// BROADCAST that every customer's Notifications screen already displays;
// per-customer rows stay personal. Push goes through the Task-31 Expo push
// layer (exp.host → FCM) — fire-and-forget, never breaks this API.
//
// GET  — broadcast history + audience counts + agent list (for the composer).
// POST — compose & send:
//        { text, icon?, audience, agentUsername?, customerId? }
//        audience: 'all'      → one broadcast row + push to every customer
//                    'approved' → per-customer rows (approved only)
//                    'pending'  → per-customer rows (awaiting approval)
//                    'agent'    → per-customer rows for one agent's customers
//                    'customer' → single personal row
// ────────────────────────────────────────────────────────────────────────────

// GET /api/app-admin/notifications
export async function GET(request: Request) {
  const [broadcasts, total, approved, pending, pushRegistered, agents, users] = await Promise.all([
    db.appNotification.findMany({
      where: { customerId: null },
      orderBy: { createdAt: 'desc' },
      take: 50,
    }),
    db.appCustomer.count(),
    db.appCustomer.count({ where: { approvalStatus: 'approved' } }),
    db.appCustomer.count({ where: { approvalStatus: 'pending' } }),
    db.appCustomer.count({ where: { pushToken: { not: null } } }),
    db.appCustomer.groupBy({
      by: ['agentUsername'],
      where: { agentUsername: { not: null } },
      _count: { _all: true },
    }),
    db.user.findMany({
      where: { role: 'user' },
      select: { username: true, name: true },
    }),
  ])

  const uname = new Map(agents.map(a => [a.agentUsername as string, a._count._all]))
  const nameOf = new Map(users.map(u => [u.username, u.name]))
  const agentList = [...uname.entries()]
    .map(([username, count]) => ({
      username,
      name: nameOf.get(username) || null,
      customers: count,
    }))
    .sort((a, b) => b.customers - a.customers)

  return NextResponse.json({
    broadcasts,
    counts: { total, approved, pending, pushRegistered, pushEnabled: pushEnabled() },
    agents: agentList,
  })
}

// POST /api/app-admin/notifications
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const text = typeof body.text === 'string' ? body.text.trim() : ''
    const icon = typeof body.icon === 'string' && body.icon.trim() ? body.icon.trim() : 'megaphone'
    const audience: string = body.audience || 'all'
    const by = request.headers.get('x-session-username') || 'admin'

    if (!text) return NextResponse.json({ error: 'text is required' }, { status: 400 })
    if (text.length > 500) return NextResponse.json({ error: 'text too long (max 500 chars)' }, { status: 400 })
    if (!['all', 'approved', 'pending', 'agent', 'customer'].includes(audience)) {
      return NextResponse.json({ error: 'audience must be all | approved | pending | agent | customer' }, { status: 400 })
    }
    if (audience === 'agent' && !body.agentUsername) {
      return NextResponse.json({ error: 'agentUsername required for audience "agent"' }, { status: 400 })
    }
    if (audience === 'customer' && !body.customerId) {
      return NextResponse.json({ error: 'customerId required for audience "customer"' }, { status: 400 })
    }

    // ── Resolve recipients ──
    type Rec = { id: string; pushToken: string | null }
    let recipients: Rec[] = []
    let broadcastRow = false

    if (audience === 'all') {
      broadcastRow = true
      recipients = await db.appCustomer.findMany({
        where: { pushToken: { not: null } },
        select: { id: true, pushToken: true },
      })
    } else {
      const where =
        audience === 'approved' ? { approvalStatus: 'approved' } :
        audience === 'pending' ? { approvalStatus: 'pending' } :
        audience === 'agent' ? { agentUsername: String(body.agentUsername) } :
        { id: String(body.customerId) }
      recipients = await db.appCustomer.findMany({
        where, select: { id: true, pushToken: true },
      })
    }

    // ── In-app rows (customerId:null = broadcast, every customer sees it) ──
    if (broadcastRow) {
      await db.appNotification.create({ data: { customerId: null, icon, text } })
    } else if (recipients.length) {
      await db.appNotification.createMany({
        data: recipients.map(r => ({ customerId: r.id, icon, text })),
      })
    }

    // ── Push (fire-and-forget semantics; safe when no tokens / disabled) ──
    const tokens = [...new Set(recipients.map(r => r.pushToken).filter(Boolean) as string[])]
    const push = tokens.length
      ? await sendExpoPush(tokens.map(to => ({ to, title: 'Satta Matka God', body: text, sound: 'default' as const, channelId: 'default', data: { kind: 'admin-broadcast' } })))
      : { delivered: 0, failed: 0, skipped: true }

    await logActivity({
      userId: by, username: by, action: 'create', entity: 'app-notification',
      entityId: `audience:${audience}`, recordsAffected: broadcastRow ? 0 : recipients.length,
      metadata: { audience, icon, text: text.slice(0, 120), push },
    }).catch(() => {})

    return NextResponse.json({
      ok: true,
      audience,
      notified: broadcastRow ? 'all customers (broadcast row)' : recipients.length,
      push,
    })
  } catch (err) {
    console.error('app-admin/notifications POST error:', err)
    return NextResponse.json({ error: 'Failed to send notification' }, { status: 500 })
  }
}

// DELETE /api/app-admin/notifications?id=... — retract a broadcast row
// (removes the in-app message; pushes already delivered cannot be recalled).
export async function DELETE(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  const id = new URL(request.url).searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  const row = await db.appNotification.findUnique({ where: { id } })
  if (!row) return NextResponse.json({ error: 'Notification not found' }, { status: 404 })
  if (row.customerId) {
    return NextResponse.json({ error: 'Only broadcast rows can be retracted here' }, { status: 400 })
  }
  await db.appNotification.delete({ where: { id } })
  const by = request.headers.get('x-session-username') || 'admin'
  await logActivity({
    userId: by, username: by, action: 'delete', entity: 'app-notification',
    entityId: id, recordsAffected: 1, metadata: { text: row.text.slice(0, 120) },
  }).catch(() => {})
  return NextResponse.json({ ok: true })
}
