import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { DEFAULT_RATES } from '@/lib/app-tree'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

const CONFIG_KEYS = ['notice', 'banners', 'deposit_account', 'rates', 'default_agent', 'notice_title']

// GET /api/app-admin/config — customer-app configuration (content, rates, default agent)
export async function GET() {
  const rows = await db.appConfig.findMany({ where: { key: { in: CONFIG_KEYS } } })
  const map: Record<string, string> = Object.fromEntries(rows.map(r => [r.key, r.value]))
  let rates = DEFAULT_RATES
  try { if (map.rates) rates = { ...DEFAULT_RATES, ...JSON.parse(map.rates) } } catch { /* keep defaults */ }
  let deposit: Record<string, string> = {}
  try { if (map.deposit_account) deposit = JSON.parse(map.deposit_account) } catch { /* keep empty */ }
  let banners: Array<Record<string, string>> = []
  try { if (map.banners) banners = JSON.parse(map.banners) } catch { /* keep empty */ }
  // Agents eligible to be the default agent / reassign target
  const agents = await db.user.findMany({
    where: { role: 'user', isLocked: false },
    select: { username: true, name: true, phone: true, managerId: true },
    orderBy: { username: 'asc' },
  })
  const admins = await db.user.findMany({
    where: { role: { in: ['super', 'manager'] } },
    select: { username: true, name: true, role: true },
    orderBy: { username: 'asc' },
  })
  return NextResponse.json({
    notice: map.notice || '',
    noticeTitle: map.notice_title || '',
    banners, deposit, rates,
    defaultAgent: map.default_agent || '',
    agents, admins,
  })
}

// PUT /api/app-admin/config — update configuration (Super Admin only)
export async function PUT(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const updates: Array<{ key: string; value: string }> = []

    if (typeof body.notice === 'string') updates.push({ key: 'notice', value: body.notice })
    if (typeof body.noticeTitle === 'string') updates.push({ key: 'notice_title', value: body.noticeTitle })
    if (typeof body.defaultAgent === 'string') updates.push({ key: 'default_agent', value: body.defaultAgent.trim() })
    if (body.deposit && typeof body.deposit === 'object') {
      updates.push({ key: 'deposit_account', value: JSON.stringify(body.deposit) })
    }
    if (body.rates && typeof body.rates === 'object') {
      updates.push({ key: 'rates', value: JSON.stringify(body.rates) })
    }
    if (Array.isArray(body.banners)) {
      updates.push({ key: 'banners', value: JSON.stringify(body.banners) })
    }
    if (!updates.length) return NextResponse.json({ error: 'Nothing to update' }, { status: 400 })

    for (const u of updates) {
      await db.appConfig.upsert({
        where: { key: u.key },
        create: { ...u, updatedBy: request.headers.get('x-session-username') || 'admin' },
        update: { value: u.value, updatedBy: request.headers.get('x-session-username') || 'admin' },
      })
    }
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'update', entity: 'app_config', entityId: updates.map(u => u.key).join(','),
      metadata: { keys: updates.map(u => u.key) },
    })
    return NextResponse.json({ ok: true, updated: updates.map(u => u.key) })
  } catch (err) {
    console.error('app-admin config PUT error', err)
    return NextResponse.json({ error: 'Update failed' }, { status: 500 })
  }
}
