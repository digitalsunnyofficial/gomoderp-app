import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { appWalletMove } from '@/lib/app-auth'
import { sendCustomerPush, sendPushToCustomers } from '@/lib/push/expo-push' // Task 31 native-app push
import {
  deriveDigit, isValidPanna, istDate, isStarline, starlineName, betWins, starBetWins,
  marketDisplayName,
} from '@/lib/matka/app-engine'
import { canonicalPanna } from '@/lib/matka/chart-definitions'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/results — declared results (optionally by market)
export async function GET(request: Request) {
  const url = new URL(request.url)
  const market = url.searchParams.get('market') || ''
  const results = await db.appResult.findMany({
    where: market ? { marketCode: market } : undefined,
    orderBy: { resultDate: 'desc' },
    take: 300,
  })
  const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
  return NextResponse.json({ results, markets })
}

// POST /api/app-admin/results — declare a result and settle bids.
// body: { marketCode, resultDate?, openPanna?, closePanna? }
//
// ── ATOMIC RESULT TRANSACTION ──
// Result upsert + settlement + wallet movements + notifications run in ONE
// prisma.$transaction; every status transition is guarded
// (updateMany where status = expected) so concurrent declares can never
// double-credit a wallet.
//
// ── CORRECTION / RE-SETTLEMENT ──
// Re-declaring with CHANGED pannas is a correction: the result version is
// incremented and EVERY bet settled under the previous version is
// re-evaluated — false winners are reversed (win_reversal ledger entry),
// true winners are credited, partial payout deltas are adjusted. Nothing is
// physically deleted; the version history is the audit trail.
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const marketCode = String(body.marketCode || '')
    const resultDate = String(body.resultDate || istDate())
    const openPanna = body.openPanna ? String(body.openPanna) : null
    const closePanna = body.closePanna ? String(body.closePanna) : null

    if (!marketCode) return NextResponse.json({ error: 'marketCode required' }, { status: 400 })
    if (!openPanna && !closePanna) {
      return NextResponse.json({ error: 'Declare at least the Open panna (or Close panna)' }, { status: 400 })
    }
    for (const [label, p] of [['Open', openPanna], ['Close', closePanna]] as const) {
      if (p && !isValidPanna(p)) {
        return NextResponse.json({ error: `${label} panna "${p}" is not a valid 3-digit panna` }, { status: 400 })
      }
    }

    const market = await db.appMarket.findUnique({ where: { code: marketCode } })
    const isStar = isStarline(marketCode)
    if (!isStar && !market) {
      return NextResponse.json({ error: 'Unknown market: ' + marketCode }, { status: 400 })
    }
    // ── Session-qualified identity ("Sridevi Day Open"), never the bare name ──
    const displayName = isStar
      ? starlineName(Number(marketCode.slice(2)))
      : marketDisplayName(market!)
    const baseName = isStar ? displayName : market!.name

    // ── Canonical spelling at the source: every declared panna is stored in
    // the operator chart convention (digits ascending, 0 last: 012→120).
    // All readers (app results, boards, jodi derivation) inherit one form.
    const effOpen = isStar ? (openPanna ? canonicalPanna(openPanna) : (closePanna ? canonicalPanna(closePanna) : null)) : (openPanna ? canonicalPanna(openPanna) : null)
    const effClose = isStar ? null : (closePanna ? canonicalPanna(closePanna) : null)

    const openDigit = effOpen ? deriveDigit(effOpen) : null
    const closeDigit = effClose ? deriveDigit(effClose) : null
    const jodi = openDigit && closeDigit ? openDigit + closeDigit : null

    const declaredBy = request.headers.get('x-session-username') || 'admin'

    // Push notifications for the native app are collected inside the atomic
    // transaction and only SENT after commit (Task 31) — a failed push can
    // never roll back a result declaration.
    const pushQueue: { customerId: string; title: string; body: string }[] = []

    // ── ATOMIC RESULT TRANSACTION ──
    const outcome = await db.$transaction(async (tx) => {
      const existing = await tx.appResult.findUnique({
        where: { marketCode_resultDate: { marketCode, resultDate } },
      })
      // A correction OVERWRITES an already-declared component with a different
      // value. Completing a partial declare (close arrives for the first time)
      // is NOT a correction — it's the normal open→close flow.
      const isCorrection =
        !!existing &&
        ((effOpen !== null && existing.openPanna !== null && existing.openPanna !== effOpen) ||
          (effClose !== null && existing.closePanna !== null && existing.closePanna !== effClose))

      // Upsert result (close declared later merges into the same row).
      const result = existing
        ? await tx.appResult.update({
            where: { id: existing.id },
            data: {
              openPanna: effOpen ?? undefined,
              closePanna: effClose ?? undefined,
              openDigit: openDigit ?? undefined,
              closeDigit: closeDigit ?? undefined,
              jodi: jodi ?? undefined,
              declaredBy,
              marketName: displayName,
              state: 'declared',
              ...(isCorrection ? { version: { increment: 1 } } : {}),
            },
          })
        : await tx.appResult.create({
            data: {
              marketCode, marketName: displayName, resultDate,
              openPanna: effOpen, closePanna: effClose,
              openDigit, closeDigit, jodi,
              declaredBy, version: 1, state: 'declared',
            },
          })

      // ── Settlement scope ──
      // Normal declare → pending bets only.
      // Correction → every bet settled under the previous version + pending.
      const bets = await tx.appBet.findMany({
        where: isCorrection
          ? { marketCode, betDate: resultDate, OR: [{ status: 'pending' }, { resultId: existing!.id }] }
          : { marketCode, betDate: resultDate, status: 'pending' },
      })

      const full = { openPanna: effOpen, closePanna: effClose, openDigit, closeDigit, jodi }
      let wonCount = 0, lostCount = 0, totalWin = 0, skipped = 0
      let reversedCount = 0, reversedAmount = 0, creditedCount = 0, creditedAmount = 0

      for (const bet of bets) {
        // Which bets are decidable with what has been declared?
        // (classic TP books slot 'close'; motor tp rows follow their slot)
        const needsClose = ['jodi', 'hs', 'hsb', 'fs'].includes(bet.type) || bet.slot === 'close'
        if (needsClose && !effClose && !isStar) { skipped++; continue }

        const win = isStar ? starBetWins(bet, effOpen!) : betWins(bet, full)
        const winAmt = bet.points * bet.rate

        // ── First settlement (guarded pending → won/lost) ──
        if (bet.status === 'pending') {
          if (win) {
            const upd = await tx.appBet.updateMany({
              where: { id: bet.id, status: 'pending' },
              data: { status: 'won', win: winAmt, settledAt: new Date(), resultId: result.id },
            })
            if (upd.count === 0) { skipped++; continue } // concurrent settle — never double-credit
            await appWalletMove(tx as never, bet.customerId, 'win', winAmt,
              `Won ${bet.type.toUpperCase()} ${bet.num} · ${bet.marketName}`)
            const winText = `You won ₹${winAmt.toLocaleString('en-IN')} — ${bet.type.toUpperCase()} ${bet.num} · ${bet.marketName}`
            await tx.appNotification.create({
              data: { customerId: bet.customerId, icon: 'trophy', text: winText },
            })
            pushQueue.push({ customerId: bet.customerId, title: 'Winner', body: winText })
            wonCount++; totalWin += winAmt
          } else {
            const upd = await tx.appBet.updateMany({
              where: { id: bet.id, status: 'pending' },
              data: { status: 'lost', win: 0, settledAt: new Date(), resultId: result.id },
            })
            if (upd.count === 0) { skipped++; continue }
            lostCount++
          }
          continue
        }

        // ── Correction re-settlement (bet already settled under V(n-1)) ──
        if (!isCorrection) continue
        if (win) {
          if (bet.status === 'won') {
            const delta = winAmt - bet.win
            if (delta > 0) {
              await tx.appBet.update({
                where: { id: bet.id, status: 'won' },
                data: { win: winAmt, settledAt: new Date(), resultId: result.id },
              })
              await appWalletMove(tx as never, bet.customerId, 'win', delta,
                `Winner payout adjusted +₹${delta.toLocaleString('en-IN')} (result corrected) · ${bet.marketName}`)
              creditedCount++; creditedAmount += delta
            } else if (delta < 0) {
              await tx.appBet.update({
                where: { id: bet.id, status: 'won' },
                data: { win: winAmt, settledAt: new Date(), resultId: result.id },
              })
              await appWalletMove(tx as never, bet.customerId, 'win_reversal', delta,
                `Winner payout adjusted ₹${delta.toLocaleString('en-IN')} (result corrected) · ${bet.marketName}`)
              reversedCount++; reversedAmount += -delta
            }
            // delta === 0 → payout unchanged, no ledger noise
          } else {
            // previously lost → new winner under the corrected result
            const upd = await tx.appBet.updateMany({
              where: { id: bet.id, status: 'lost' },
              data: { status: 'won', win: winAmt, settledAt: new Date(), resultId: result.id },
            })
            if (upd.count === 0) { skipped++; continue }
            await appWalletMove(tx as never, bet.customerId, 'win', winAmt,
              `Won ${bet.type.toUpperCase()} ${bet.num} (corrected result) · ${bet.marketName}`)
            const corrWinText = `Result corrected — you won ₹${winAmt.toLocaleString('en-IN')} (${bet.type.toUpperCase()} ${bet.num} · ${bet.marketName})`
            await tx.appNotification.create({
              data: { customerId: bet.customerId, icon: 'trophy', text: corrWinText },
            })
            pushQueue.push({ customerId: bet.customerId, title: 'Result corrected — Winner', body: corrWinText })
            wonCount++; totalWin += winAmt; creditedCount++; creditedAmount += winAmt
          }
        } else {
          if (bet.status === 'won') {
            // false winner under the old result → reverse the payout
            const upd = await tx.appBet.updateMany({
              where: { id: bet.id, status: 'won' },
              data: { status: 'lost', win: 0, settledAt: new Date(), resultId: result.id },
            })
            if (upd.count === 0) { skipped++; continue }
            await appWalletMove(tx as never, bet.customerId, 'win_reversal', -bet.win,
              `Payout reversed ₹${bet.win.toLocaleString('en-IN')} — result corrected · ${bet.marketName}`)
            const revText = `Result corrected — the earlier ₹${bet.win.toLocaleString('en-IN')} payout for ${bet.type.toUpperCase()} ${bet.num} (${bet.marketName}) has been reversed`
            await tx.appNotification.create({
              data: { customerId: bet.customerId, icon: 'alert', text: revText },
            })
            pushQueue.push({ customerId: bet.customerId, title: 'Payout reversed', body: revText })
            lostCount++; reversedCount++; reversedAmount += bet.win
          }
          // already lost and still losing → no-op
        }
      }

      return {
        result, considered: bets.length, wonCount, lostCount, skipped, totalWin,
        isCorrection, reversedCount, reversedAmount, creditedCount, creditedAmount,
        pushes: pushQueue,
        previous: existing ? { openPanna: existing.openPanna, closePanna: existing.closePanna, version: existing.version } : null,
      }
    })

    const { result } = outcome

    // ── Native-app pushes (fire-and-forget, after commit — Task 31) ──
    for (const p of outcome.pushes) {
      void sendCustomerPush(p.customerId, p.title, p.body).catch(() => {})
    }

    await logActivity({
      username: declaredBy,
      action: outcome.isCorrection ? 'correct_result' : 'declare_result',
      entity: 'app_result', entityId: result.id,
      market: marketCode,
      recordsAffected: outcome.wonCount + outcome.lostCount,
      metadata: {
        resultDate, openPanna: effOpen, closePanna: effClose, version: result.version,
        previous: outcome.previous, wonCount: outcome.wonCount, lostCount: outcome.lostCount,
        totalWin: outcome.totalWin, reversedAmount: outcome.reversedAmount,
      },
    })

    // ── Broadcast (after commit): every customer gets a result notification ──
    let summaryText: string
    if (outcome.isCorrection) {
      const prev = outcome.previous
      const prevTxt = prev ? `${prev.openPanna ?? '—'}-${prev.closePanna ?? '—'}` : '—'
      // Merged values (result row after the update) — a component-level
      // correction shows the FULL corrected result, not just the changed leg.
      const newTxt = `${result.openPanna ?? '—'}-${result.closePanna ?? '—'}${result.jodi ? ` (Jodi ${result.jodi})` : ''}`
      summaryText = `RESULT CORRECTED — ${displayName}: previous ${prevTxt} → now ${newTxt}. All payouts have been recalculated.`
    } else if (isStar) {
      summaryText = `${displayName} result declared: ${effOpen} (${deriveDigit(effOpen!)})`
    } else if (effOpen && effClose) {
      summaryText = `${displayName} result declared: ${effOpen}-${effClose} (Jodi ${jodi})`
    } else if (effOpen) {
      summaryText = `${displayName} Open declared: ${effOpen}-${deriveDigit(effOpen)}`
    } else {
      summaryText = `${displayName} Close declared: ${effClose}-${deriveDigit(effClose as string)}`
    }
    const allCustomers = await db.appCustomer.findMany({
      where: { status: 'active', approvalStatus: 'approved' },
      select: { id: true },
    })
    if (allCustomers.length) {
      await db.appNotification.createMany({
        data: allCustomers.map(c => ({
          customerId: c.id, icon: outcome.isCorrection ? 'alert' : 'megaphone',
          text: summaryText.replace(/--+/g, '-'),
        })),
      })
      // Push broadcast to app users with a registered device (Task 31)
      void sendPushToCustomers(
        allCustomers.map(c => c.id),
        outcome.isCorrection ? `${displayName} — RESULT CORRECTED` : `${displayName} — Result declared`,
        summaryText.replace(/--+/g, '-'),
        { screen: 'home' },
      )
    }

    return NextResponse.json({
      ok: true,
      result,
      settlement: {
        considered: outcome.considered, won: outcome.wonCount, lost: outcome.lostCount,
        skipped: outcome.skipped, totalWin: outcome.totalWin,
        corrected: outcome.isCorrection, version: result.version,
        reversedCount: outcome.reversedCount, reversedAmount: outcome.reversedAmount,
        creditedCount: outcome.creditedCount, creditedAmount: outcome.creditedAmount,
      },
    })
  } catch (err) {
    console.error('app-admin results POST error', err)
    return NextResponse.json({ error: 'Could not declare result' }, { status: 500 })
  }
}
