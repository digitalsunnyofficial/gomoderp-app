import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { istDate, isStarline, starlineName, marketDisplayName } from '@/lib/matka/app-engine'
import { pannaKey, canonicalPanna } from '@/lib/matka/chart-definitions'

// ──────────────────────────────────────────────────────────
// MARKET CHARTS — aggregate every app order (bet) of a market
// + date into an inventory chart the operator can copy and
// send on WhatsApp to their superiors (market vyapar).
// ──────────────────────────────────────────────────────────

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

const SLOT_LBL: Record<string, string> = { open: 'Open', close: 'Close', jodi: 'Jodi', hs: 'Half Sangam', fs: 'Full Sangam' }
const TYPE_LBL: Record<string, string> = { single: 'Single Digit', jodi: 'Jodi', sp: 'Single Pana', dp: 'Double Pana', tp: 'Triple Pana', hs: 'Half Sangam', fs: 'Full Sangam', oddeven: 'Odd/Even' }

// GET /api/app-admin/market-charts?market=kalyan&date=2026-09-19
export async function GET(request: Request) {
  if (!['super', 'manager'].includes(roleOf(request))) {
    return NextResponse.json({ error: 'Access denied' }, { status: 403 })
  }
  const url = new URL(request.url)
  const market = url.searchParams.get('market') || ''
  const date = url.searchParams.get('date') || istDate()

  const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
  if (!market) {
    return NextResponse.json({ markets: markets.map(m => ({ code: m.code, name: m.name })), date, chart: null })
  }

  const bets = await db.appBet.findMany({
    where: { marketCode: market, betDate: date },
    orderBy: { createdAt: 'asc' },
  })

  const mkName = isStarline(market)
    ? starlineName(Number(market.slice(2)))
    : (markets.find(m => m.code === market)?.name || market)

  // Group: slot → type → num → { points, count }
  const groups: Record<string, Record<string, Record<string, { points: number; count: number }>>> = {}
  for (const b of bets) {
    const slot = b.slot || 'open'
    groups[slot] = groups[slot] || {}
    groups[slot][b.type] = groups[slot][b.type] || {}
    const cell = groups[slot][b.type][b.num] || { points: 0, count: 0 }
    cell.points += b.points
    cell.count += 1
    groups[slot][b.type][b.num] = cell
  }

  // Chart rows per slot+type sorted by points desc
  const sections = Object.entries(groups).map(([slot, types]) => ({
    slot,
    slotLabel: SLOT_LBL[slot] || slot,
    types: Object.entries(types).map(([type, nums]) => ({
      type,
      typeLabel: TYPE_LBL[type] || type,
      total: Object.values(nums).reduce((a, c) => a + c.points, 0),
      rows: Object.entries(nums)
        .map(([num, v]) => ({ num, points: v.points, count: v.count }))
        .sort((a, b) => b.points - a.points || a.num.localeCompare(b.num)),
    })).sort((a, b) => b.total - a.total),
  }))

  const grandTotal = bets.reduce((a, b) => a + b.points, 0)
  const bettorCount = new Set(bets.map(b => b.customerId)).size

  // ── MASTER BOARDS — the three market charts (single / double / triple) ──
  // Every app order lands here automatically: each game expands to standard
  // rows, so SP-Motor/Family/Chart-20 rows feed the triple board, jodi bets
  // feed the double board, single bets the single board. ERP entries (the
  // WhatsApp-paste channel + mirrored app bets, stored in the inventories of
  // the same market) are merged in too — one master chart per market, both
  // channels aggregated. Pannas aggregate by digit-set (pannaKey) so chart
  // spellings "038"/"380" merge into one cell, displayed in the operator's
  // canonical spelling. Layout mirrors the WhatsApp-paste grid: 10 ank
  // columns (1-9,0), numbers with points.
  interface Cell { pos: number; num: string; points: number; count: number }

  // ── ERP channel rows for the same market+date (one source of vyapar) ──
  // Merge key = the canonical market link (InventoryCode.marketCode); the
  // legacy code/name fallbacks keep pre-link historical cards visible.
  // Session bucketing: each card's InventoryCode.type decides whether its
  // points land on the OPEN or CLOSE boards — ERP rows no longer default
  // to the open boards.
  interface ErpNum { num: string; points: number; slot: 'open' | 'close'; kind: 'single' | 'double' | 'panna' }
  const erpNums: ErpNum[] = []
  try {
    const mkRow = markets.find(m => m.code === market)
    const mkDisplay = mkRow ? marketDisplayName(mkRow) : mkName
    const invs = await db.inventory.findMany({
      where: {
        date: {
          gte: new Date(date + 'T00:00:00.000Z'),
          lt: new Date(new Date(date + 'T00:00:00.000Z').getTime() + 86400000),
        },
        status: { not: 'deleted' },
        inventoryCode: {
          OR: [
            { marketCode: market },            // canonical market link (single source)
            { code: 'app_' + market },         // legacy mirrored app cards
            { market: { equals: mkName } },    // legacy: WhatsApp cards tagged with the base market name
            { name: { equals: mkDisplay } },   // legacy: cards named with the full session display name
          ],
        },
      },
      select: { id: true, inventoryCode: { select: { type: true } } },
    })
    if (invs.length) {
      const invIds = invs.map(i => i.id)
      const bucketById = new Map(invs.map(i => [i.id, i.inventoryCode.type]))
      const bucketOf = (invId: string): 'open' | 'close' => {
        const t = bucketById.get(invId)
        return t === 'close' || t === 'night-close' ? 'close' : 'open'
      }
      const [triples, doubles] = await Promise.all([
        db.tripleInventory.findMany({ where: { inventoryId: { in: invIds } }, select: { inventoryId: true, parsedData: true, type: true } }),
        db.doubleSingleInventory.findMany({ where: { inventoryId: { in: invIds } }, select: { inventoryId: true, parsedData: true, type: true } }),
      ])
      const pushNums = (raw: string, kind: ErpNum['kind'], bucket: 'open' | 'close') => {
        try {
          const pd = JSON.parse(raw || '{}') as {
            numbers?: Array<{ number?: string; price?: number }>
            entries?: Array<{ number?: string; price?: number }>
            source?: string
          }
          // Mirrored app-bet rows are ALREADY counted from AppBet above —
          // counting them again would double every app point on the boards
          // (the mirror is the ERP vyapar record, not a second chart source).
          if (pd.source === 'customer-app') return
          const list = Array.isArray(pd.numbers) && pd.numbers.length ? pd.numbers : (Array.isArray(pd.entries) ? pd.entries : [])
          for (const n of list) {
            if (!n || typeof n.number !== 'string' || !n.price) continue
            // sangam composites (X-PPP / PPP-X / PPP-QQQ) stay in typeSummary only
            if (n.number.includes('-')) continue
            erpNums.push({ num: n.number, points: Number(n.price), slot: bucket, kind })
          }
        } catch { /* ignore malformed rows */ }
      }
      for (const t of triples) {
        if (t.type === 'sangam') continue
        pushNums(t.parsedData, 'panna', bucketOf(t.inventoryId))
      }
      for (const d of doubles) {
        pushNums(d.parsedData, d.type === 'double' ? 'double' : 'single', bucketOf(d.inventoryId))
      }
    }
  } catch (erpErr) {
    console.error('market-charts ERP merge error', erpErr)
  }
  const posOfSum = (s: number) => (s % 10 === 0 ? 10 : s % 10)
  const mkAcc = () => ({ map: new Map<string, Cell>(), total: 0 })
  const accAdd = (acc: ReturnType<typeof mkAcc>, key: string, num: string, pos: number, points: number) => {
    const cell = acc.map.get(key)
    if (cell) { cell.points += points; cell.count += 1 }
    else acc.map.set(key, { pos, num, points, count: 1 })
    acc.total += points
  }
  const accCells = (acc: ReturnType<typeof mkAcc>): Cell[] =>
    [...acc.map.values()].sort((a, b) => b.points - a.points || a.num.localeCompare(b.num))

  const sOpen = mkAcc(), sClose = mkAcc(), jodiAcc = mkAcc(), tOpen = mkAcc(), tClose = mkAcc()
  for (const b of bets) {
    if (b.type === 'single') {
      const d = Number(b.num)
      if (!Number.isFinite(d) || d < 0 || d > 9) continue
      const pos = d === 0 ? 10 : d
      if (b.slot === 'close') accAdd(sClose, b.num, b.num, pos, b.points)
      else accAdd(sOpen, b.num, b.num, pos, b.points)
    } else if (b.type === 'jodi') {
      if (!/^\d{2}$/.test(b.num)) continue
      const sum = Number(b.num[0]) + Number(b.num[1])
      accAdd(jodiAcc, b.num, b.num, posOfSum(sum), b.points)
    } else if (b.type === 'sp' || b.type === 'dp' || b.type === 'tp') {
      const key = pannaKey(b.num)
      if (key.length !== 3) continue
      const sum = Number(b.num[0]) + Number(b.num[1]) + Number(b.num[2])
      const pos = posOfSum(sum)
      const disp = canonicalPanna(b.num)
      // Master boards bucket purely by the bet's session — motor tp rows
      // belong to the session they were played in
      if (b.slot === 'close') accAdd(tClose, key, disp, pos, b.points)
      else accAdd(tOpen, key, disp, pos, b.points)
    }
    // hs / hsb / fs are composite (open+close) — reported in typeSummary
  }
  // ERP channel merge (WhatsApp paste + mirrored app bets), session-bucketed
  for (const e of erpNums) {
    if (e.kind === 'single') {
      const d = Number(e.num)
      if (!Number.isFinite(d) || d < 0 || d > 9) continue
      const pos = d === 0 ? 10 : d
      if (e.slot === 'close') accAdd(sClose, e.num, e.num, pos, e.points)
      else accAdd(sOpen, e.num, e.num, pos, e.points)
    } else if (e.kind === 'double') {
      if (!/^\d{2}$/.test(e.num)) continue
      const sum = Number(e.num[0]) + Number(e.num[1])
      accAdd(jodiAcc, e.num, e.num, posOfSum(sum), e.points)
    } else if (e.kind === 'panna') {
      if (e.num.length !== 3) continue
      const key = pannaKey(e.num)
      if (key.length !== 3) continue
      const sum = Number(e.num[0]) + Number(e.num[1]) + Number(e.num[2])
      if (e.slot === 'close') accAdd(tClose, key, canonicalPanna(e.num), posOfSum(sum), e.points)
      else accAdd(tOpen, key, canonicalPanna(e.num), posOfSum(sum), e.points)
    }
  }
  const sub = (acc: ReturnType<typeof mkAcc>) => ({ cells: accCells(acc), total: acc.total })
  const boards = {
    single: { open: sub(sOpen), close: sub(sClose) },
    double: { jodi: sub(jodiAcc) },
    triple: { open: sub(tOpen), close: sub(tClose) },
  }

  // ── TYPE SUMMARY — customer entry calculation + win/loss per game type ──
  const TYPE_ORDER = ['single', 'jodi', 'sp', 'dp', 'tp', 'hs', 'hsb', 'fs', 'oddeven']
  const acc2: Record<string, { bids: number; staked: number; won: number; pendingCount: number; pendingPoints: number }> = {}
  for (const b of bets) {
    const s = (acc2[b.type] ||= { bids: 0, staked: 0, won: 0, pendingCount: 0, pendingPoints: 0 })
    s.bids += 1
    s.staked += b.points
    if (b.status === 'won') s.won += b.win
    else if (b.status === 'pending') { s.pendingCount += 1; s.pendingPoints += b.points }
  }
  const typeSummary = TYPE_ORDER.filter(t => acc2[t]).map(t => ({
    type: t,
    typeLabel: TYPE_LBL[t] || t,
    ...acc2[t],
    net: acc2[t].staked - acc2[t].won,
  }))

  // WhatsApp-ready text version
  const L: string[] = []
  L.push(`*${mkName}* — ${date}`)
  L.push(`Bettors: ${bettorCount} · Bids: ${bets.length} · Total: ${grandTotal} pts`)
  for (const s of sections) {
    L.push('')
    for (const t of s.types) {
      L.push(`${s.slotLabel} ${t.typeLabel} (${t.total} pts):`)
      for (const r of t.rows) {
        L.push(`${r.num} - ${r.points}${r.count > 1 ? ` (${r.count})` : ''}`)
      }
    }
  }
  const whatsappText = L.join('\n')

  return NextResponse.json({
    markets: markets.map(m => ({ code: m.code, name: m.name })),
    market: mkName, date, grandTotal, bettorCount, bidCount: bets.length,
    sections, whatsappText,
    boards, typeSummary,
  })
}
