import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/allocation?market=code — allocations (with game rows) for one market,
// or the whole matrix when no market given
export async function GET(request: Request) {
  const url = new URL(request.url)
  const market = url.searchParams.get('market')
  const [games, allocs, markets] = await Promise.all([
    db.game.findMany({ orderBy: { sortOrder: 'asc' } }),
    db.gameAllocation.findMany({
      where: market ? { marketCode: market } : undefined,
      orderBy: { marketCode: 'asc' },
    }),
    db.appMarket.findMany({ orderBy: { sortOrder: 'asc' }, select: { code: true, name: true, phase: true, session: true, isActive: true } }),
  ])
  return NextResponse.json({ games, allocations: allocs, markets })
}

// POST /api/app-admin/allocation — upsert one allocation (super only)
// body: { gameId, marketCode, isActive?, rate?, minPoints? }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const { gameId, marketCode } = body
    if (!gameId || !marketCode) return NextResponse.json({ error: 'gameId and marketCode are required' }, { status: 400 })
    const game = await db.game.findUnique({ where: { id: gameId } })
    if (!game) return NextResponse.json({ error: 'Game not found' }, { status: 404 })
    const mk = await db.appMarket.findUnique({ where: { code: marketCode } })
    if (!mk) return NextResponse.json({ error: 'Market not found' }, { status: 404 })

    let rate: number | null = null
    if (body.rate !== undefined && body.rate !== null && body.rate !== '') {
      const r = Number(body.rate)
      if (!Number.isFinite(r) || r <= 0 || r > 100000) {
        return NextResponse.json({ error: 'Rate must be a positive number' }, { status: 400 })
      }
      rate = r
    }
    let minPoints = 10
    if (body.minPoints !== undefined) {
      const m = Number(body.minPoints)
      if (!Number.isFinite(m) || m < 1 || m > 100000) {
        return NextResponse.json({ error: 'Min points must be between 1 and 100000' }, { status: 400 })
      }
      minPoints = Math.round(m)
    }

    const existing = await db.gameAllocation.findUnique({
      where: { gameId_marketCode: { gameId, marketCode } },
    })
    const data = {
      isActive: typeof body.isActive === 'boolean' ? body.isActive : existing?.isActive ?? true,
      rate,
      minPoints,
    }
    const alloc = existing
      ? await db.gameAllocation.update({ where: { id: existing.id }, data })
      : await db.gameAllocation.create({ data: { gameId, marketCode, ...data } })

    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'update', entity: 'game_allocation', entityId: alloc.id, market: marketCode,
      metadata: { game: game.code, ...data },
    })
    return NextResponse.json({ ok: true, allocation: alloc })
  } catch (err) {
    console.error('app-admin allocation POST error', err)
    return NextResponse.json({ error: 'Could not save allocation' }, { status: 500 })
  }
}
