import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { deriveDigit, isValidPanna, istDate } from '@/lib/matka/app-engine'

// ──────────────────────────────────────────────────────────
// CHART DATA — backend input for every market's Jodi & Panel
// chart. Entries are stored as AppResult rows (single source
// of truth) but are SILENT upserts: no settlement, no customer
// notifications, no betting lock. Only past dates are allowed
// — today's live result goes through the normal declare flow.
// The customer app's Results / Jodi Chart / Panel Chart read
// these rows directly.
// ──────────────────────────────────────────────────────────

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/chart-data?market=<code> — stored chart rows
export async function GET(request: Request) {
  const market = new URL(request.url).searchParams.get('market') || ''
  const results = await db.appResult.findMany({
    where: market ? { marketCode: market } : undefined,
    orderBy: { resultDate: 'desc' },
    take: 500,
  })
  return NextResponse.json({ results })
}

// POST /api/app-admin/chart-data — bulk backfill (silent)
// body: { marketCode, entries: [{ resultDate, openPanna?, closePanna? }] }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const marketCode = String(body.marketCode || '')
    const entries = Array.isArray(body.entries) ? body.entries : []
    if (!marketCode) return NextResponse.json({ error: 'marketCode required' }, { status: 400 })
    if (!entries.length) return NextResponse.json({ error: 'entries required' }, { status: 400 })

    const market = await db.appMarket.findUnique({ where: { code: marketCode } })
    if (!market) return NextResponse.json({ error: 'Market not found: ' + marketCode }, { status: 404 })

    const today = istDate()
    let updated = 0
    const skipped: string[] = []

    for (const e of entries as Array<{ resultDate?: string; openPanna?: string | null; closePanna?: string | null }>) {
      const resultDate = String(e.resultDate || '').trim()
      const open = String(e.openPanna || '').trim()
      const close = String(e.closePanna || '').trim()
      if (!/^\d{4}-\d{2}-\d{2}$/.test(resultDate)) { skipped.push(`${resultDate || '?'} (bad date)`); continue }
      if (resultDate >= today) { skipped.push(`${resultDate} (today/future — declare in Market Results)`); continue }
      if (open && !isValidPanna(open)) { skipped.push(`${resultDate} (bad open panna "${open}")`); continue }
      if (close && !isValidPanna(close)) { skipped.push(`${resultDate} (bad close panna "${close}")`); continue }
      if (!open && !close) { skipped.push(`${resultDate} (nothing entered)`); continue }

      const openDigit = open ? deriveDigit(open) : null
      const closeDigit = close ? deriveDigit(close) : null
      const jodi = openDigit && closeDigit ? openDigit + closeDigit : null

      await db.appResult.upsert({
        where: { marketCode_resultDate: { marketCode, resultDate } },
        create: {
          marketCode, marketName: market.name, resultDate,
          openPanna: open || null, closePanna: close || null,
          openDigit, closeDigit, jodi,
          declaredBy: 'chart-backfill',
        },
        update: {
          openPanna: open || null, closePanna: close || null,
          openDigit, closeDigit, jodi,
        },
      })
      updated++
    }

    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'create', entity: 'app_result', entityId: marketCode, market: marketCode,
      metadata: { chartBackfill: true, updated, skipped },
    })
    return NextResponse.json({ ok: true, updated, skipped })
  } catch (err) {
    console.error('chart-data POST error', err)
    return NextResponse.json({ error: 'Could not save chart data' }, { status: 500 })
  }
}
