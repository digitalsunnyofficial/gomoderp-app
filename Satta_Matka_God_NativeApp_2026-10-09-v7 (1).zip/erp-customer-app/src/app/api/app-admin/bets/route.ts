import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// GET /api/app-admin/bets — all app bids with filters
// ?status=&market=&customerId=&take=
export async function GET(request: Request) {
  const url = new URL(request.url)
  const status = url.searchParams.get('status') || 'all'
  const market = url.searchParams.get('market') || ''
  const customerId = url.searchParams.get('customerId') || ''
  const take = Math.min(Number(url.searchParams.get('take')) || 200, 500)

  const where: Record<string, unknown> = {}
  if (status !== 'all') where.status = status
  if (market) where.marketCode = market
  if (customerId) where.customerId = customerId

  const [bets, total, markets] = await Promise.all([
    db.appBet.findMany({ where, orderBy: { createdAt: 'desc' }, take }),
    db.appBet.count({ where }),
    db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } }),
  ])
  const customerIds = [...new Set(bets.map(b => b.customerId))]
  const customers = await db.appCustomer.findMany({
    where: { id: { in: customerIds } },
    select: { id: true, name: true, mobile: true },
  })
  const custMap = Object.fromEntries(customers.map(c => [c.id, c]))
  return NextResponse.json({
    bets: bets.map(b => ({
      ...b,
      customerName: custMap[b.customerId]?.name || '—',
      customerMobile: custMap[b.customerId]?.mobile || '',
    })),
    total,
    markets,
  })
}
