import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { appWalletMove } from '@/lib/app-auth'
import { notifyCustomer } from '@/lib/push/expo-push' // Task 31 native-app push
// NOTE (operator rule 2026-10): deposits do NOT earn agent commission.
// Agents earn commission on what their customers PLAY — the accrual lives
// in the bet placement transaction (src/app/api/customer-app/bets/route.ts
// → accruePlayCommission in src/lib/app-tree.ts).

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/funds — deposit requests (+ withdrawals when ?type=withdrawals)
export async function GET(request: Request) {
  const url = new URL(request.url)
  const status = url.searchParams.get('status') || 'all'
  const where = status === 'all' ? undefined : { status }
  const [funds, withdrawals] = await Promise.all([
    db.appFundRequest.findMany({ where, orderBy: { createdAt: 'desc' }, take: 300 }),
    db.appWithdrawRequest.findMany({ where, orderBy: { createdAt: 'desc' }, take: 300 }),
  ])
  const ids = [...new Set([...funds.map(f => f.customerId), ...withdrawals.map(w => w.customerId)])]
  const customers = await db.appCustomer.findMany({
    where: { id: { in: ids } },
    select: { id: true, name: true, mobile: true, wallet: true },
  })
  const cmap = Object.fromEntries(customers.map(c => [c.id, c]))
  const decorate = (r: Record<string, unknown>) => ({
    ...r,
    customerName: cmap[r.customerId as string]?.name || '—',
    customerMobile: cmap[r.customerId as string]?.mobile || '',
    customerWallet: cmap[r.customerId as string]?.wallet ?? 0,
  })
  return NextResponse.json({
    funds: funds.map(decorate),
    withdrawals: withdrawals.map(decorate),
  })
}

// POST /api/app-admin/funds — approve or reject a deposit
// body: { id, action: 'approve' | 'reject', note? }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const { id, action, note } = await request.json()
    if (!id || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'id and action (approve/reject) required' }, { status: 400 })
    }
    const fund = await db.appFundRequest.findUnique({ where: { id } })
    if (!fund) return NextResponse.json({ error: 'Request not found' }, { status: 404 })
    if (fund.status !== 'pending') {
      return NextResponse.json({ error: `Request already ${fund.status}` }, { status: 400 })
    }
    const by = request.headers.get('x-session-username') || 'admin'

    if (action === 'approve') {
      await db.$transaction(async (tx) => {
        await tx.appFundRequest.update({
          where: { id },
          data: { status: 'approved', processedBy: by, processedAt: new Date(), note: note || null },
        })
        await appWalletMove(tx as never, fund.customerId, 'deposit', fund.amount,
          `Fund approved (${fund.utr})`)
      })
      await notifyCustomer({
        customerId: fund.customerId, icon: 'arrow-down-circle',
        text: `Your deposit of ₹${fund.amount.toLocaleString('en-IN')} was approved`,
        pushTitle: 'Deposit approved',
      })
    } else {
      await db.appFundRequest.update({
        where: { id },
        data: { status: 'rejected', processedBy: by, processedAt: new Date(), note: note || null },
      })
      await notifyCustomer({
        customerId: fund.customerId, icon: 'alert-triangle',
        text: `Your deposit request of ₹${fund.amount.toLocaleString('en-IN')} was rejected${note ? ' — ' + note : ''}`,
        pushTitle: 'Deposit rejected',
      })
    }
    await logActivity({
      username: by, action: `fund_${action}`, entity: 'app_fund_request', entityId: id,
      recordsAffected: 1, metadata: { amount: fund.amount, utr: fund.utr },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('app-admin funds POST error', err)
    return NextResponse.json({ error: 'Could not process request' }, { status: 500 })
  }
}
