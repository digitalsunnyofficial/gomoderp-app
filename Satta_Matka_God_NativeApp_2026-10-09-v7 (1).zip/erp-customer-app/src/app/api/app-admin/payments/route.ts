import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { appWalletMove } from '@/lib/app-auth'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// ──────────────────────────────────────────────────────────
// PAYMENT MANAGEMENT — business QR gateway + points
// 1 point = ₹1. The customer scans the business QR (any UPI
// payment app opens), pays, submits the reference (UTR) in the
// app; the admin approves here and points are credited 1:1.
// ──────────────────────────────────────────────────────────

interface QrConfig {
  image?: string      // data URL of the business QR
  upi?: string        // UPI ID / business VPA
  payee?: string      // payee name embedded in the deep link
  note?: string       // instructions shown in the app
  updatedAt?: string
  updatedBy?: string
}

async function readQr(): Promise<QrConfig> {
  const row = await db.appConfig.findUnique({ where: { key: 'payment_qr' } })
  try { return row?.value ? (JSON.parse(row.value) as QrConfig) : {} } catch { return {} }
}

// GET /api/app-admin/payments — QR + summary + deposit ledger
export async function GET() {
  const [qr, funds, approvedAgg, todayAgg] = await Promise.all([
    readQr(),
    db.appFundRequest.findMany({ orderBy: [{ status: 'asc' }, { createdAt: 'desc' }], take: 300 }),
    db.appFundRequest.aggregate({ where: { status: 'approved' }, _sum: { amount: true }, _count: { _all: true } }),
    db.appFundRequest.aggregate({
      where: { status: 'approved', processedAt: { gte: new Date(Date.now() - 24 * 3600 * 1000) } },
      _sum: { amount: true }, _count: { _all: true },
    }),
  ])
  const ids = [...new Set(funds.map(f => f.customerId))]
  const customers = await db.appCustomer.findMany({
    where: { id: { in: ids } },
    select: { id: true, name: true, mobile: true, wallet: true },
  })
  const cmap = Object.fromEntries(customers.map(c => [c.id, c]))
  const pending = funds.filter(f => f.status === 'pending').length
  return NextResponse.json({
    qr: qr || {},
    summary: {
      pointsAdded24h: todayAgg._sum.amount || 0,
      deposits24h: todayAgg._count._all,
      pointsTotal: approvedAgg._sum.amount || 0,
      depositsTotal: approvedAgg._count._all,
      pending,
      pointRate: '1 Point = ₹1',
    },
    deposits: funds.map(f => ({
      ...f,
      customerName: cmap[f.customerId]?.name || '—',
      customerMobile: cmap[f.customerId]?.mobile || '',
      customerWallet: cmap[f.customerId]?.wallet ?? 0,
    })),
  })
}

// PUT /api/app-admin/payments — update the business QR (Super Admin, periodic refresh)
// body: { image?, upi?, payee?, note? }
export async function PUT(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const cur = await readQr()
    const next: QrConfig = {
      image: typeof body.image === 'string' ? body.image : cur.image,
      upi: typeof body.upi === 'string' ? body.upi.trim() : cur.upi,
      payee: typeof body.payee === 'string' ? body.payee.trim() : cur.payee,
      note: typeof body.note === 'string' ? body.note.trim() : cur.note,
      updatedAt: new Date().toISOString(),
      updatedBy: request.headers.get('x-session-username') || 'admin',
    }
    if (next.image && next.image.length > 900_000) {
      return NextResponse.json({ error: 'QR image too large — use an image under ~600KB' }, { status: 400 })
    }
    if (body.clearImage) next.image = ''
    const value = JSON.stringify(next)
    await db.appConfig.upsert({
      where: { key: 'payment_qr' },
      create: { key: 'payment_qr', value, updatedBy: next.updatedBy },
      update: { value, updatedBy: next.updatedBy },
    })
    await logActivity({
      username: next.updatedBy || 'admin', action: 'update', entity: 'payment_qr', entityId: 'payment_qr',
      metadata: { upi: next.upi, hasImage: !!next.image },
    })
    return NextResponse.json({ ok: true, qr: next })
  } catch (err) {
    console.error('app-admin payments PUT error', err)
    return NextResponse.json({ error: 'Could not save QR' }, { status: 500 })
  }
}

// POST /api/app-admin/payments — approve / reject a deposit (Super Admin)
// body: { id, action: 'approve' | 'reject', note? }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const { id, action, note } = await request.json()
    if (!id || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'id and action (approve/reject) required' }, { status: 400 })
    }
    const fund = await db.appFundRequest.findUnique({ where: { id } })
    if (!fund) return NextResponse.json({ error: 'Request not found' }, { status: 404 })
    if (fund.status !== 'pending') {
      return NextResponse.json({ error: `Request already ${fund.status}` }, { status: 400 })
    }
    const by = request.headers.get('x-session-username') || 'admin'

    if (action === 'approve') {
      await db.$transaction(async (tx) => {
        await tx.appFundRequest.update({
          where: { id },
          data: { status: 'approved', processedBy: by, processedAt: new Date(), note: note || null },
        })
        await appWalletMove(tx as never, fund.customerId, 'deposit', fund.amount,
          `Points added — payment approved (${fund.utr}) · 1 Point = ₹1`)
      })
      await db.appNotification.create({
        data: {
          customerId: fund.customerId, icon: 'arrow-down-circle',
          text: `${fund.amount.toLocaleString('en-IN')} Points added to your wallet (payment of ₹${fund.amount.toLocaleString('en-IN')} approved)`,
        },
      })
    } else {
      await db.appFundRequest.update({
        where: { id },
        data: { status: 'rejected', processedBy: by, processedAt: new Date(), note: note || null },
      })
      await db.appNotification.create({
        data: {
          customerId: fund.customerId, icon: 'alert-triangle',
          text: `Your payment request of ₹${fund.amount.toLocaleString('en-IN')} was rejected${note ? ' — ' + note : ''}`,
        },
      })
    }
    await logActivity({
      username: by, action: `fund_${action}`, entity: 'app_fund_request', entityId: id,
      recordsAffected: 1, metadata: { amount: fund.amount, utr: fund.utr },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('app-admin payments POST error', err)
    return NextResponse.json({ error: 'Could not process request' }, { status: 500 })
  }
}
