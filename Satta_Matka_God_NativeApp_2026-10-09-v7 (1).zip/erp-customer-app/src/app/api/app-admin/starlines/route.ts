import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'

// ──────────────────────────────────────────────────────────
// STARLINES MANAGEMENT — create / update / manage the short
// hourly games. Unlike markets (Name+Phase+Session formula),
// the operator can run one or many starlines, each with its
// own result time. Bets use the classic code "st<hour>" so
// the existing settlement + results engine is untouched.
// ──────────────────────────────────────────────────────────

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/starlines — all starlines ordered by result time
export async function GET() {
  const starlines = await db.appStarline.findMany({ orderBy: [{ hour: 'asc' }, { minute: 'asc' }] })
  return NextResponse.json({ starlines })
}

// POST /api/app-admin/starlines — create a starline
// body: { name?, hour, minute?, betClosingMinutes?, isOn? }
//   OR  { action: 'generate', name, fromHour, toHour, minute?, betClosingMinutes? }
//       → creates ONE ROW PER HOUR between fromHour..toHour (operator rule
//       2026-10: hourly starlines like "Main Star Line 09:05→08:05 PM" are
//       generated from a single config instead of hand-creating each hour).
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()

    // ── Hourly generator: one config → N hourly starline rows ──
    if (body.action === 'generate') {
      const name = String(body.name || '').trim()
      const fromHour = Number(body.fromHour)
      const toHour = Number(body.toHour)
      if (!name) return NextResponse.json({ error: 'Starline name is required (e.g. Main Star Line)' }, { status: 400 })
      if (!Number.isInteger(fromHour) || fromHour < 0 || fromHour > 23) {
        return NextResponse.json({ error: 'Start hour must be 0–23' }, { status: 400 })
      }
      if (!Number.isInteger(toHour) || toHour < 0 || toHour > 23) {
        return NextResponse.json({ error: 'End hour must be 0–23' }, { status: 400 })
      }
      if (toHour === fromHour) {
        return NextResponse.json({ error: 'Start and end hour cannot be the same' }, { status: 400 })
      }
      // The range may cross midnight (e.g. 9→20 same day; 21→2 wraps) —
      // hourly slots are generated following the clock from fromHour.
      const hours: number[] = []
      let h = fromHour
      while (true) {
        hours.push(h)
        if (h === toHour) break
        h = (h + 1) % 24
        if (hours.length >= 24) break
      }
      const minute = Number(body.minute) || 0
      if (!Number.isInteger(minute) || minute < 0 || minute > 59) {
        return NextResponse.json({ error: 'Result minute must be 0–59' }, { status: 400 })
      }
      const closingRaw = Number(body.betClosingMinutes)
      const closing = Number.isFinite(closingRaw) && closingRaw >= 0 && closingRaw <= 120 ? Math.round(closingRaw) : 5
      const mm = String(minute).padStart(2, '0')
      const twelve = (hh: number) => {
        const ampm = hh >= 12 ? 'PM' : 'AM'
        const hh12 = hh % 12 === 0 ? 12 : hh % 12
        return `${String(hh12).padStart(2, '0')}:${mm} ${ampm}`
      }

      let created = 0, skipped = 0
      const skippedNames: string[] = []
      let sortOrder = await db.appStarline.count()
      for (const hh of hours) {
        const code = 'st' + hh
        const dup = await db.appStarline.findUnique({ where: { code } })
        if (dup) { skipped++; skippedNames.push(dup.name); continue }
        await db.appStarline.create({
          data: {
            code,
            name: `${name} ${twelve(hh)}`,
            hour: hh,
            minute,
            betClosingMinutes: closing,
            isOn: true,
            sortOrder: ++sortOrder,
          },
        })
        created++
      }
      await logActivity({
        username: request.headers.get('x-session-username') || 'admin',
        action: 'generate_starlines', entity: 'app_starline', entityId: name,
        metadata: { name, fromHour, toHour, minute, created, skipped },
      })
      return NextResponse.json({
        ok: true, created, skipped, skippedNames,
        message: `Generated ${created} hourly starline${created === 1 ? '' : 's'} (${twelve(fromHour)} → ${twelve(toHour)})${skipped ? ` · ${skipped} hour(s) already existed and were kept` : ''}`,
      })
    }

    const hour = Number(body.hour)
    if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
      return NextResponse.json({ error: 'Result hour must be 0–23' }, { status: 400 })
    }
    const minute = Number(body.minute) || 0
    if (!Number.isInteger(minute) || minute < 0 || minute > 59) {
      return NextResponse.json({ error: 'Result minute must be 0–59' }, { status: 400 })
    }
    const code = 'st' + hour
    const dup = await db.appStarline.findUnique({ where: { code } })
    if (dup) {
      return NextResponse.json(
        { error: `A starline with the ${String(hour).padStart(2, '0')}:00 result hour already exists (${dup.name})` },
        { status: 409 }
      )
    }
    const closing = Number(body.betClosingMinutes)
    const count = await db.appStarline.count()
    const starline = await db.appStarline.create({
      data: {
        code,
        name: String(body.name || '').trim() || `Starline ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`,
        hour,
        minute,
        betClosingMinutes: Number.isFinite(closing) && closing >= 0 && closing <= 120 ? Math.round(closing) : 5,
        isOn: body.isOn === false ? false : true,
        sortOrder: count + 1,
      },
    })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'create', entity: 'app_starline', entityId: starline.id, market: code,
      metadata: { name: starline.name, hour, minute },
    })
    return NextResponse.json({ ok: true, starline })
  } catch (err) {
    console.error('app-admin starlines POST error', err)
    return NextResponse.json({ error: 'Could not create starline' }, { status: 500 })
  }
}

// PATCH /api/app-admin/starlines — update name / time / closing minutes / toggles
// body: { id, name?, hour?, minute?, betClosingMinutes?, isOn?, isActive? }
export async function PATCH(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const { id } = body
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const current = await db.appStarline.findUnique({ where: { id } })
    if (!current) return NextResponse.json({ error: 'Starline not found' }, { status: 404 })

    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if (body.hour !== undefined) {
      const hour = Number(body.hour)
      if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
        return NextResponse.json({ error: 'Result hour must be 0–23' }, { status: 400 })
      }
      if (hour !== current.hour) {
        const dup = await db.appStarline.findUnique({ where: { code: 'st' + hour } })
        if (dup) return NextResponse.json({ error: `Starline st${hour} already exists (${dup.name})` }, { status: 409 })
        data.hour = hour
        data.code = 'st' + hour
      }
    }
    if (body.minute !== undefined) {
      const minute = Number(body.minute)
      if (!Number.isInteger(minute) || minute < 0 || minute > 59) {
        return NextResponse.json({ error: 'Result minute must be 0–59' }, { status: 400 })
      }
      data.minute = minute
    }
    if (body.betClosingMinutes !== undefined) {
      const c = Number(body.betClosingMinutes)
      if (!Number.isFinite(c) || c < 0 || c > 120) {
        return NextResponse.json({ error: 'Bet closing minutes must be 0–120' }, { status: 400 })
      }
      data.betClosingMinutes = Math.round(c)
    }
    if (typeof body.isOn === 'boolean') data.isOn = body.isOn
    if (typeof body.isActive === 'boolean') data.isActive = body.isActive

    // Keep the auto-name in sync when the time changed, the name was never
    // customized AND the caller did not send an explicit name this request
    if ((data.hour !== undefined || data.minute !== undefined) && data.name === undefined) {
      const autoName = /^Starline \d{2}:\d{2}$/.test(current.name)
      if (autoName) {
        const h = (data.hour !== undefined ? Number(data.hour) : current.hour)
        const m = (data.minute !== undefined ? Number(data.minute) : current.minute)
        data.name = `Starline ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
      }
    }

    const starline = await db.appStarline.update({ where: { id }, data })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'update', entity: 'app_starline', entityId: id, market: starline.code,
      metadata: data,
    })
    return NextResponse.json({ ok: true, starline })
  } catch (err) {
    console.error('app-admin starlines PATCH error', err)
    return NextResponse.json({ error: 'Could not update starline' }, { status: 500 })
  }
}

// DELETE /api/app-admin/starlines?id= — remove a starline (super only)
export async function DELETE(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const id = new URL(request.url).searchParams.get('id') || ''
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const current = await db.appStarline.findUnique({ where: { id } })
    if (!current) return NextResponse.json({ error: 'Starline not found' }, { status: 404 })
    await db.appStarline.delete({ where: { id } })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'delete', entity: 'app_starline', entityId: id, market: current.code,
      metadata: { name: current.name, code: current.code },
    })
    return NextResponse.json({ ok: true, deleted: current.code })
  } catch (err) {
    console.error('app-admin starlines DELETE error', err)
    return NextResponse.json({ error: 'Could not delete starline' }, { status: 500 })
  }
}
