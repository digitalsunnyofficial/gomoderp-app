import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { GAME_CATALOG } from '@/lib/matka/games-engine'
import { logActivity } from '@/lib/audit'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/games — full catalog + allocation counts
export async function GET() {
  let rows = await db.game.findMany({ orderBy: { sortOrder: 'asc' } })
  // Auto-heal: seed any catalog game missing from the DB (new install or new game)
  const missing = GAME_CATALOG.filter(g => !rows.find(r => r.code === g.code))
  for (const g of missing) {
    await db.game.create({ data: { ...g } }).catch(() => {})
  }
  if (missing.length) rows = await db.game.findMany({ orderBy: { sortOrder: 'asc' } })
  const allocs = await db.gameAllocation.groupBy({ by: ['gameId'], _count: { gameId: true } })
  const countBy: Record<string, number> = {}
  for (const a of allocs) countBy[a.gameId] = a._count.gameId
  return NextResponse.json({ games: rows.map(g => ({ ...g, marketsAllocated: countBy[g.id] || 0 })) })
}

// PATCH /api/app-admin/games — edit name / defaultRate / isActive (super only)
export async function PATCH(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const { id } = body
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const data: Record<string, unknown> = {}
    if (typeof body.isActive === 'boolean') data.isActive = body.isActive
    if (body.defaultRate !== undefined) {
      const r = Number(body.defaultRate)
      if (!Number.isFinite(r) || r <= 0 || r > 100000) {
        return NextResponse.json({ error: 'Rate must be a positive number' }, { status: 400 })
      }
      data.defaultRate = r
    }
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    const game = await db.game.update({ where: { id }, data })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'update', entity: 'game', entityId: id,
      metadata: { code: game.code, ...data },
    })
    return NextResponse.json({ ok: true, game })
  } catch (err) {
    console.error('app-admin games PATCH error', err)
    return NextResponse.json({ error: 'Could not update game' }, { status: 500 })
  }
}
