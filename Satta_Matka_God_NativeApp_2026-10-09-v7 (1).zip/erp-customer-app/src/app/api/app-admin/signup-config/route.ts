import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { SIGNUP_APPROVAL_KEY } from '@/lib/app-auth'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/signup-config — current signup-approval toggle state.
// Super Admin / Admin only (it is a master-admin provision; agents never see
// the toggle). Only Super Admin can change it (PUT below).
export async function GET(request: Request) {
  if (!['super', 'manager', 'master'].includes(roleOf(request))) {
    return NextResponse.json({ error: 'Super Admin / Admin access required' }, { status: 403 })
  }
  const cfg = await db.appConfig
    .findUnique({ where: { key: SIGNUP_APPROVAL_KEY } })
    .catch(() => null)
  return NextResponse.json({
    // Missing setting → default behaviour: approval required
    signupApprovalRequired: cfg ? cfg.value !== 'false' : true,
    updatedAt: cfg?.updatedAt ?? null,
    updatedBy: cfg?.updatedBy ?? null,
  })
}

// PUT /api/app-admin/signup-config — toggle signup approval (Super Admin only)
// Body: { signupApprovalRequired: boolean }
export async function PUT(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    if (typeof body.signupApprovalRequired !== 'boolean') {
      return NextResponse.json({ error: 'signupApprovalRequired (boolean) is required' }, { status: 400 })
    }
    const value = body.signupApprovalRequired ? 'true' : 'false'
    const username = request.headers.get('x-session-username') || 'admin'
    await db.appConfig.upsert({
      where: { key: SIGNUP_APPROVAL_KEY },
      create: { key: SIGNUP_APPROVAL_KEY, value, updatedBy: username },
      update: { value, updatedBy: username },
    })
    await logActivity({
      username,
      action: 'update',
      entity: 'app_config',
      entityId: SIGNUP_APPROVAL_KEY,
      metadata: { signupApprovalRequired: body.signupApprovalRequired },
    })
    return NextResponse.json({ ok: true, signupApprovalRequired: body.signupApprovalRequired })
  } catch (err) {
    console.error('signup-config PUT error', err)
    return NextResponse.json({ error: 'Update failed' }, { status: 500 })
  }
}
