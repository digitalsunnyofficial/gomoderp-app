import { NextResponse } from 'next/server'
import { cronStatus } from '@/lib/cron'

function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

// GET /api/app-admin/cron — market automation bot status (super/manager)
export async function GET(request: Request) {
  const role = roleOf(request)
  if (role !== 'super' && role !== 'manager') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
  }
  const r = cronStatus()
  return NextResponse.json({
    running: r.running,
    startedAt: r.startedAt,
    lastTick: r.lastTick,
    ticks: r.ticks,
    intervalSeconds: 30,
    markets: Object.values(r.markets),
  })
}
