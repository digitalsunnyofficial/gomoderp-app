import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { istDate } from '@/lib/matka/app-engine'

// ──────────────────────────────────────────────────────────
// DASHBOARD API — vyapar book + customer app in one desk.
// ERP side: inventories (entries), breakdown, hisab, vendors.
// App side: today's bids, collected / paid / net, pending fund +
// withdraw requests, per-market P/L with result status.
// ──────────────────────────────────────────────────────────

function istDayBounds(dateStr: string) {
  const start = new Date(`${dateStr}T00:00:00+05:30`)
  const end = new Date(start.getTime() + 24 * 3600 * 1000)
  return { start, end }
}

export async function GET(request: Request) {
  const url = new URL(request.url)
  const dateParam = url.searchParams.get('date') || ''
  const today = /^\d{4}-\d{2}-\d{2}$/.test(dateParam) ? dateParam : istDate()
  const { start, end } = istDayBounds(today)

  const [
    entriesTotal,
    entriesToday,
    valueAgg,
    valueTodayAgg,
    recentEntries,
    settlementsTotal,
    settlementsSettled,
    activeVendors,
    dsToday,
    betsTodayAgg,
    paidTodayAgg,
    fundsPending,
    withdrawsPending,
    appCustomers,
    markets,
    todaysResults,
    perMarketAgg,
    recentFunds,
    activity,
  ] = await Promise.all([
    db.inventory.count(),
    db.inventory.count({ where: { date: { gte: start, lt: end } } }),
    db.inventory.aggregate({ _sum: { totalAmount: true } }),
    db.inventory.aggregate({ _sum: { totalAmount: true }, where: { date: { gte: start, lt: end } } }),
    db.inventory.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { inventoryCode: { select: { code: true, name: true, market: true, type: true } } },
    }),
    db.settlement.count(),
    db.settlement.count({ where: { status: 'settled' } }),
    db.vendor.count(),
    // breakdown for today: DS inventories (single/double) + triple totals
    db.doubleSingleInventory.findMany({
      where: { inventory: { date: { gte: start, lt: end } }, type: { in: ['single', 'double'] } },
      select: { type: true, totalAmount: true },
    }),
    db.appBet.aggregate({ _sum: { points: true }, _count: { _all: true }, where: { betDate: today } }),
    db.appBet.aggregate({ _sum: { win: true }, where: { betDate: today, status: 'won' } }),
    db.appFundRequest.count({ where: { status: 'pending' } }),
    db.appWithdrawRequest.count({ where: { status: 'pending' } }),
    db.appCustomer.count(),
    db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } }),
    db.appResult.findMany({ where: { resultDate: today } }),
    db.appBet.groupBy({
      by: ['marketCode'],
      where: { betDate: today },
      _count: { _all: true },
      _sum: { points: true, win: true },
    }),
    db.appFundRequest.findMany({
      orderBy: { createdAt: 'desc' },
      take: 4,
      include: { customer: { select: { name: true, mobile: true } } },
    }),
    db.userActivity.findMany({ orderBy: { createdAt: 'desc' }, take: 6 }),
  ])

  const breakdown = { single: 0, double: 0, triple: 0 }
  for (const row of dsToday) {
    if (row.type === 'single') breakdown.single += row.totalAmount
    else if (row.type === 'double') breakdown.double += row.totalAmount
  }
  const tripleToday = await db.tripleInventory.aggregate({
    _sum: { totalAmount: true },
    where: { inventory: { date: { gte: start, lt: end } } },
  })
  breakdown.triple = tripleToday._sum.totalAmount || 0

  const resultMap: Record<string, { status: string; open: string | null; close: string | null; jodi: string | null }> = {}
  for (const r of todaysResults) {
    resultMap[r.marketCode] = {
      status: r.openPanna && r.closePanna ? 'complete' : 'partial',
      open: r.openPanna ? `${r.openPanna}-${r.openDigit}` : null,
      close: r.closePanna ? `${r.closePanna}-${r.closeDigit}` : null,
      jodi: r.jodi,
    }
  }

  const pl = markets
    .filter(m => m.isActive)
    .map(m => {
      const agg = perMarketAgg.find(g => g.marketCode === m.code)
      const collected = agg?._sum.points || 0
      const paid = agg?._sum.win || 0
      return {
        code: m.code,
        name: m.name,
        category: m.category,
        openTime: m.openTime,
        closeTime: m.closeTime,
        bets: agg?._count._all || 0,
        collected,
        paid,
        net: collected - paid,
        result: resultMap[m.code] || null,
      }
    })

  return NextResponse.json({
    date: today,
    erp: {
      entriesTotal,
      entriesToday,
      valueTotal: valueAgg._sum.totalAmount || 0,
      valueToday: valueTodayAgg._sum.totalAmount || 0,
      breakdown,
      settlements: { total: settlementsTotal, settled: settlementsSettled },
      activeVendors,
      recentEntries: recentEntries.map(inv => ({
        id: inv.id,
        code: inv.inventoryCode?.code || '—',
        name: inv.inventoryCode?.name || '—',
        market: inv.inventoryCode?.market || '—',
        type: inv.inventoryCode?.type || '—',
        date: inv.date,
        status: inv.status,
        totalTxn: inv.totalTxn,
        total: inv.totalAmount,
        createdBy: inv.createdBy,
      })),
    },
    app: {
      betsToday: betsTodayAgg._count._all || 0,
      collectedToday: betsTodayAgg._sum.points || 0,
      paidToday: paidTodayAgg._sum.win || 0,
      netToday: (betsTodayAgg._sum.points || 0) - (paidTodayAgg._sum.win || 0),
      fundsPending,
      withdrawsPending,
      appCustomers,
      pl,
    },
    moneyIn: recentFunds.map(f => ({
      id: f.id,
      customerName: f.customer?.name || '—',
      customerMobile: f.customer?.mobile || '',
      amount: f.amount,
      utr: f.utr,
      status: f.status,
      createdAt: f.createdAt,
    })),
    activity: activity.map(a => ({
      id: a.id,
      username: a.username,
      action: a.action,
      entity: a.entity,
      entityId: a.entityId,
      createdAt: a.createdAt,
    })),
  })
}
