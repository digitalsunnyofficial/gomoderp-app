import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { deriveDigit, isStarline } from '@/lib/matka/app-engine'

// ──────────────────────────────────────────────────────────
// MARKET CHARTS FROM APP ENTRIES
//
// Business rule (per operator): when customers place their vyapar
// directly in the app (e.g. 10 customers betting Single/Jodi/SP/DP
// in Sridevi), the ERP must show ONE chart per market — every
// customer's entries merged into that market's chart, digit-wise /
// jodi-wise / panna-wise with amount totals. This endpoint builds
// exactly that chart on demand for any market + date.
// ──────────────────────────────────────────────────────────

// GET /api/app-admin/charts?market=shridevi&date=YYYY-MM-DD&customerId=<optional>
export async function GET(request: Request) {
  const url = new URL(request.url)
  const market = url.searchParams.get('market') || ''
  const date = url.searchParams.get('date') || ''
  const customerId = url.searchParams.get('customerId') || ''
  if (!market || !date) {
    return NextResponse.json({ error: 'market and date are required' }, { status: 400 })
  }

  const where: Record<string, unknown> = { marketCode: market, betDate: date }
  if (customerId) where.customerId = customerId

  const bets = await db.appBet.findMany({ where, orderBy: { createdAt: 'asc' } })
  const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
  const marketInfo = markets.find(m => m.code === market) || null

  // ── Aggregation buckets ──
  const openAnk = Array.from({ length: 10 }, () => 0)   // digit → amount (open slot)
  const closeAnk = Array.from({ length: 10 }, () => 0)  // digit → amount (close slot)
  const jodi = Array.from({ length: 100 }, () => 0)     // jodi index → amount
  const pannas: Record<string, { num: string; type: string; slot: string; amount: number; bets: number }> = {}
  const starAnk = Array.from({ length: 10 }, () => 0)   // starline single-digit totals
  const oddEven = { odd: 0, even: 0 }
  const custMap: Record<string, { id: string; name: string; mobile: string; bets: number; staked: number }> = {}

  for (const b of bets) {
    const amt = Number(b.points) || 0
    const cust = custMap[b.customerId] || {
      id: b.customerId, name: '—', mobile: '', bets: 0, staked: 0,
    }
    cust.bets++; cust.staked += amt
    custMap[b.customerId] = cust

    const star = isStarline(b.marketCode)
    if (b.type === 'single') {
      const d = Number(b.num)
      if (d >= 0 && d <= 9) {
        if (star) starAnk[d] += amt
        else if (b.slot === 'close') closeAnk[d] += amt
        else openAnk[d] += amt
      }
    } else if (b.type === 'jodi') {
      const n = Number(b.num)
      if (n >= 0 && n <= 99) jodi[n] += amt
    } else if (b.type === 'oddeven') {
      const key = b.num.toLowerCase() === 'odd' ? 'odd' : 'even'
      oddEven[key as 'odd' | 'even'] += amt
    } else {
      // sp / dp / tp pannas — keyed by number+slot; roll into their derived ank too
      const key = `${b.type}|${b.num}|${b.slot}`
      if (!pannas[key]) pannas[key] = { num: b.num, type: b.type, slot: b.slot, amount: 0, bets: 0 }
      pannas[key].amount += amt
      pannas[key].bets += 1
      if (!star) {
        const ank = Number(deriveDigit(b.num))
        if (ank >= 0 && ank <= 9) {
          if (b.slot === 'close') closeAnk[ank] += amt
          else openAnk[ank] += amt
        }
      } else {
        const ank = Number(deriveDigit(b.num))
        if (ank >= 0 && ank <= 9) starAnk[ank] += amt
      }
    }
  }

  // customer names in one query
  const ids = Object.keys(custMap)
  const customers = await db.appCustomer.findMany({
    where: { id: { in: ids } },
    select: { id: true, name: true, mobile: true },
  })
  for (const c of customers) {
    if (custMap[c.id]) { custMap[c.id].name = c.name; custMap[c.id].mobile = c.mobile }
  }

  const staked = bets.reduce((a, b) => a + (Number(b.points) || 0), 0)
  const potential = bets.reduce((a, b) => a + (Number(b.points) || 0) * (Number(b.rate) || 0), 0)

  // ── WhatsApp-ready vyapar chart ──
  // The operator forwards this text to the upper authority: the market's
  // whole vyapar as one chart (digit-wise, jodi-wise, panna-wise totals).
  const mkName = marketInfo?.name || market.toUpperCase()
  const W: string[] = []
  W.push(`*${mkName} — VYAPAR CHART*`)
  W.push(`_${date}_ · Bids: ${bets.length} · Customers: ${ids.length} · Total: ₹${staked.toLocaleString('en-IN')}`)
  const fmtAnk = (arr: number[], label: string) => {
    const nz = arr.map((v, i) => ({ i, v })).filter(x => x.v > 0)
    if (!nz.length) return
    W.push('')
    W.push(`*${label}*`)
    W.push(nz.map(x => `${x.i} → ₹${x.v.toLocaleString('en-IN')}`).join(' | '))
  }
  fmtAnk(openAnk, 'OPEN (Ank)')
  fmtAnk(closeAnk, 'CLOSE (Ank)')
  fmtAnk(starAnk, 'SINGLE (Ank)')
  const jodiNz = jodi.map((v, i) => ({ i, v })).filter(x => x.v > 0)
  if (jodiNz.length) {
    W.push('')
    W.push('*JODI*')
    W.push(jodiNz.map(x => `${String(x.i).padStart(2, '0')} → ₹${x.v.toLocaleString('en-IN')}`).join(' | '))
  }
  const panNz = Object.values(pannas).sort((a, b) => b.amount - a.amount)
  if (panNz.length) {
    W.push('')
    W.push('*PANNA*')
    for (const p of panNz.slice(0, 60)) {
      W.push(`${p.num} (${p.type.toUpperCase()} · ${p.slot}) → ₹${p.amount.toLocaleString('en-IN')}`)
    }
  }
  if (oddEven.odd || oddEven.even) {
    W.push('')
    W.push(`*ODD/EVEN* Odd ₹${oddEven.odd.toLocaleString('en-IN')} | Even ₹${oddEven.even.toLocaleString('en-IN')}`)
  }
  W.push('')
  W.push(`Potential payout: ₹${potential.toLocaleString('en-IN')}`)

  return NextResponse.json({
    market: marketInfo
      ? { code: marketInfo.code, name: marketInfo.name, openTime: marketInfo.openTime, closeTime: marketInfo.closeTime, isActive: marketInfo.isActive }
      : { code: market, name: isStarline(market) ? 'Starline ' + market.slice(2).padStart(2, '0') + ':00' : market, openTime: '', closeTime: '', isActive: true },
    date,
    isStarline: isStarline(market),
    counts: {
      bets: bets.length,
      customers: ids.length,
      staked,
      potential,
    },
    openAnk,
    closeAnk,
    starAnk,
    oddEven,
    jodi,
    pannas: Object.values(pannas).sort((a, b) => b.amount - a.amount),
    customers: Object.values(custMap).sort((a, b) => b.staked - a.staked),
    whatsapp: W.join('\n'),
  })
}
