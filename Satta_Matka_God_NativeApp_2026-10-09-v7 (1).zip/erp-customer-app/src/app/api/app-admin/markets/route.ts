import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { logActivity } from '@/lib/audit'
import { minsOf, istClock, marketWindowToday, parseWeekly, validDaySchedule, WEEKDAY_KEYS } from '@/lib/matka/app-engine'

// Guard: ERP session required (proxy). Mutations: super only.
function roleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

function validTime(t: unknown): t is string {
  return typeof t === 'string' && /^([01]?\d|2[0-3]):[0-5]\d$/.test(t)
}

// Market structure: Name + Phase (Day/Night) + Session (Open/Close) —
// e.g. "Main Bazaar Day Open". "both" keeps the classic Open+Close market.
function validPhase(p: unknown): p is string { return p === 'day' || p === 'night' || p === 'none' }
function validSession(s: unknown): s is string { return s === 'open' || s === 'close' || s === 'both' }

// Validate + normalize a weekly schedule payload.
// Accepts { "0": {on,open,close}, … } — days absent keep the default window.
function cleanWeekly(input: unknown): { ok: true; json: string } | { ok: false; error: string } {
  if (input === undefined || input === null) return { ok: true, json: '{}' }
  if (typeof input !== 'object' || Array.isArray(input)) return { ok: false, error: 'weeklySchedule must be an object' }
  const src = input as Record<string, unknown>
  const out: Record<string, { on: boolean; open: string; close: string }> = {}
  for (const k of Object.keys(src)) {
    if (!WEEKDAY_KEYS.includes(k)) return { ok: false, error: `Invalid day key "${k}" (0=Sunday … 6=Saturday)` }
    const d = src[k] as { on?: unknown; open?: unknown; close?: unknown }
    const on = !!d.on
    if (on) {
      if (!validTime(d.open) || !validTime(d.close)) {
        return { ok: false, error: `Invalid time for day ${k} (HH:MM required)` }
      }
      if (minsOf(d.open as string) >= minsOf(d.close as string)) {
        return { ok: false, error: `Day ${k}: Open time must be before Close time` }
      }
      out[k] = { on: true, open: d.open as string, close: d.close as string }
    } else {
      out[k] = { on: false, open: validTime(d.open) ? (d.open as string) : '00:00', close: validTime(d.close) ? (d.close as string) : '00:00' }
    }
  }
  return { ok: true, json: JSON.stringify(out) }
}

// GET /api/app-admin/markets — all app markets with live status (weekly-aware)
export async function GET(request: Request) {
  const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
  const cur = istClock().mins
  const withLive = markets.map(m => {
    const w = marketWindowToday(m)
    let live: string
    if (!w.on) live = 'off'
    else {
      const o = minsOf(w.openTime) - (m.betClosingMinutes || 0)
      const c = minsOf(w.closeTime) - (m.betClosingMinutes || 0)
      live = cur < o ? 'scheduled' : cur < c ? 'open' : 'closed'
    }
    return {
      ...m,
      liveStatus: live,
      todayOpen: w.openTime,
      todayClose: w.closeTime,
      weekly: parseWeekly(m.weeklySchedule),
    }
  })
  return NextResponse.json({ markets: withLive })
}

// POST /api/app-admin/markets — add a market (Name + Phase + Session + timings + weekly schedule at creation)
// body: { name, phase?, session?, code?, category?, openTime, closeTime, betClosingMinutes?, isOn?, weeklySchedule? }
export async function POST(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const name = String(body.name || '').trim()
    const openTime = body.openTime, closeTime = body.closeTime
    const phase = validPhase(body.phase) ? body.phase : 'day'
    const session = validSession(body.session) ? body.session : 'both'
    if (!name) return NextResponse.json({ error: 'Market name is required' }, { status: 400 })
    if (!validTime(openTime) || !validTime(closeTime)) {
      return NextResponse.json({ error: 'Open and Close times are required (HH:MM)' }, { status: 400 })
    }
    if (minsOf(openTime) >= minsOf(closeTime)) {
      return NextResponse.json({ error: 'Open time must be before Close time' }, { status: 400 })
    }
    // Duplicate guard: the same Name + Phase + Session combination can exist only once
    const dup = await db.appMarket.findFirst({
      where: { name: { equals: name, }, phase, session },
    })
    if (dup) {
      const sessLbl = session === 'both' ? 'Open + Close' : session === 'open' ? 'Open' : 'Close'
      return NextResponse.json(
        { error: `${name} ${phase === 'night' ? 'Night' : phase === 'day' ? 'Day' : ''} ${sessLbl} already exists (code ${dup.code})`.replace(/\s+/g, ' ') },
        { status: 409 }
      )
    }
    // Auto-derive a unique code from name + phase + session when not provided
    const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '')
    let code = String(body.code || '').trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '')
    if (!code) code = slug([name, phase === 'none' ? '' : phase, session === 'both' ? '' : session].filter(Boolean).join('_'))
    const existing = await db.appMarket.findUnique({ where: { code } })
    if (existing) return NextResponse.json({ error: `Market code "${code}" already exists` }, { status: 409 })

    const weekly = cleanWeekly(body.weeklySchedule)
    if (!weekly.ok) return NextResponse.json({ error: weekly.error }, { status: 400 })

    const closing = Number(body.betClosingMinutes)
    const count = await db.appMarket.count()
    const market = await db.appMarket.create({
      data: {
        code,
        name,
        phase,
        session,
        category: body.category === 'night' || phase === 'night' ? 'night' : 'regular',
        openTime, closeTime,
        betClosingMinutes: Number.isFinite(closing) && closing >= 0 && closing <= 120 ? Math.round(closing) : 5,
        isOn: body.isOn === false ? false : true,
        weeklySchedule: weekly.json,
        sortOrder: count + 1,
      },
    })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'create', entity: 'app_market', entityId: market.id, market: code,
      metadata: { name, phase, session, openTime, closeTime, betClosingMinutes: market.betClosingMinutes, weeklySchedule: weekly.json },
    })
    return NextResponse.json({ ok: true, market })
  } catch (err) {
    console.error('app-admin markets POST error', err)
    return NextResponse.json({ error: 'Could not create market' }, { status: 500 })
  }
}

// PATCH /api/app-admin/markets — update timings / weekly / closing minutes / toggles
// body: { id, openTime?, closeTime?, betClosingMinutes?, isActive?, isOn?, name?, category?, weeklySchedule? }
export async function PATCH(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const body = await request.json()
    const { id } = body
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const current = await db.appMarket.findUnique({ where: { id } })
    if (!current) return NextResponse.json({ error: 'Market not found' }, { status: 404 })

    const data: Record<string, unknown> = {}
    if (body.weeklySchedule !== undefined) {
      const weekly = cleanWeekly(body.weeklySchedule)
      if (!weekly.ok) return NextResponse.json({ error: weekly.error }, { status: 400 })
      data.weeklySchedule = weekly.json
    }
    const openTime = body.openTime ?? current.openTime
    const closeTime = body.closeTime ?? current.closeTime
    if (!validTime(openTime) || !validTime(closeTime)) {
      return NextResponse.json({ error: 'Invalid time format (HH:MM)' }, { status: 400 })
    }
    if (minsOf(openTime) >= minsOf(closeTime)) {
      return NextResponse.json({ error: 'Open time must be before Close time' }, { status: 400 })
    }
    data.openTime = openTime
    data.closeTime = closeTime
    if (body.betClosingMinutes !== undefined) {
      const c = Number(body.betClosingMinutes)
      if (!Number.isFinite(c) || c < 0 || c > 120) {
        return NextResponse.json({ error: 'Bet closing minutes must be 0–120' }, { status: 400 })
      }
      data.betClosingMinutes = Math.round(c)
    }
    if (typeof body.isActive === 'boolean') data.isActive = body.isActive
    if (typeof body.isOn === 'boolean') data.isOn = body.isOn
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if (validPhase(body.phase)) {
      data.phase = body.phase
      data.category = body.phase === 'night' ? 'night' : 'regular'
    }
    if (validSession(body.session)) data.session = body.session
    if (body.category === 'regular' || body.category === 'night') data.category = body.category

    const market = await db.appMarket.update({ where: { id }, data })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'update', entity: 'app_market', entityId: id, market: market.code,
      metadata: data,
    })
    return NextResponse.json({ ok: true, market })
  } catch (err) {
    console.error('app-admin markets PATCH error', err)
    return NextResponse.json({ error: 'Could not update market' }, { status: 500 })
  }
}

// DELETE /api/app-admin/markets?id= — remove a market record (super only).
// The market card + its game allocations are deleted; historical bets and
// declared results are kept (they store their own market name snapshot).
export async function DELETE(request: Request) {
  if (roleOf(request) !== 'super') {
    return NextResponse.json({ error: 'Super Admin access required' }, { status: 403 })
  }
  try {
    const id = new URL(request.url).searchParams.get('id') || ''
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const current = await db.appMarket.findUnique({ where: { id } })
    if (!current) return NextResponse.json({ error: 'Market not found' }, { status: 404 })

    await db.gameAllocation.deleteMany({ where: { marketCode: current.code } })
    await db.appMarket.delete({ where: { id } })
    await logActivity({
      username: request.headers.get('x-session-username') || 'admin',
      action: 'delete', entity: 'app_market', entityId: id, market: current.code,
      metadata: { name: current.name, phase: current.phase, session: current.session, code: current.code },
    })
    return NextResponse.json({ ok: true, deleted: current.code })
  } catch (err) {
    console.error('app-admin markets DELETE error', err)
    return NextResponse.json({ error: 'Could not delete market' }, { status: 500 })
  }
}
