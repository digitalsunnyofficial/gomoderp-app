import { db } from '@/lib/db'
import { readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'

// GET /api/user-subscriptions/check — check if current user has active access
export async function GET(request: Request) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.userId) {
      return NextResponse.json({ hasAccess: false, status: 'not_authenticated', daysRemaining: 0, planName: null })
    }

    // Master users always have access
    if (ctx.isMaster) {
      return NextResponse.json({ hasAccess: true, status: 'master', daysRemaining: 999, planName: 'Super Admin' })
    }

    // Find the user's active subscription
    const subscription = await db.userSubscription.findFirst({
      where: { userId: ctx.userId, status: 'active' },
      include: { plan: true },
      orderBy: { endDate: 'desc' },
    })

    if (!subscription) {
      // Check for grace period or expired
      const latestSub = await db.userSubscription.findFirst({
        where: { userId: ctx.userId },
        include: { plan: true },
        orderBy: { endDate: 'desc' },
      })
      if (latestSub) {
        const daysSinceExpiry = Math.floor((Date.now() - new Date(latestSub.endDate).getTime()) / (1000 * 60 * 60 * 24))
        return NextResponse.json({
          hasAccess: false,
          status: latestSub.status,
          daysRemaining: 0,
          planName: latestSub.plan?.label || null,
          expiredDaysAgo: daysSinceExpiry,
        })
      }
      return NextResponse.json({ hasAccess: false, status: 'no_subscription', daysRemaining: 0, planName: null })
    }

    const now = new Date()
    const endDate = new Date(subscription.endDate)
    const daysRemaining = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))

    // Check if subscription has actually expired
    if (endDate < now) {
      // Auto-expire it
      await db.userSubscription.update({
        where: { id: subscription.id },
        data: { status: 'expired' },
      })
      return NextResponse.json({
        hasAccess: false,
        status: 'expired',
        daysRemaining: 0,
        planName: subscription.plan?.label || null,
      })
    }

    return NextResponse.json({
      hasAccess: true,
      status: 'active',
      daysRemaining,
      planName: subscription.plan?.label || null,
      subscriptionId: subscription.id,
      endDate: subscription.endDate,
    })
  } catch (error) {
    console.error('GET user-subscriptions/check error:', error)
    return NextResponse.json({ hasAccess: false, status: 'error', daysRemaining: 0, planName: null }, { status: 500 })
  }
}
