import { db } from '@/lib/db'
import { readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'

// GET /api/user-subscriptions/[id] — get a specific subscription
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.userId) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }
    const { id } = await params
    const subscription = await db.userSubscription.findUnique({
      where: { id },
      include: { plan: true, user: { select: { id: true, username: true, name: true } } },
    })
    if (!subscription) return NextResponse.json({ error: 'Subscription not found' }, { status: 404 })
    // Non-admin users can only see their own
    if (!ctx.isMaster && subscription.userId !== ctx.userId) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }
    return NextResponse.json(subscription)
  } catch (error) {
    console.error('GET user-subscription error:', error)
    return NextResponse.json({ error: 'Failed to fetch subscription' }, { status: 500 })
  }
}

// PUT /api/user-subscriptions/[id] — update a subscription (activate, cancel, extend)
export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.isMaster) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }
    const { id } = await params
    const body = await request.json()
    const updateData: Record<string, any> = {}

    if (body.status !== undefined) updateData.status = body.status
    if (body.paymentStatus !== undefined) updateData.paymentStatus = body.paymentStatus
    if (body.paymentMethod !== undefined) updateData.paymentMethod = body.paymentMethod
    if (body.paymentRef !== undefined) updateData.paymentRef = body.paymentRef
    if (body.amountPaid !== undefined) updateData.amountPaid = Number(body.amountPaid)
    if (body.autoRenew !== undefined) updateData.autoRenew = body.autoRenew

    // Extend subscription by days
    if (body.extendDays) {
      const current = await db.userSubscription.findUnique({ where: { id } })
      if (current) {
        const currentEnd = new Date(current.endDate)
        const base = currentEnd > new Date() ? currentEnd : new Date()
        base.setDate(base.getDate() + Number(body.extendDays))
        updateData.endDate = base
        if (body.status === 'expired') updateData.status = 'active'
      }
    }

    // Change plan
    if (body.planId) {
      const plan = await db.subscriptionPlan.findUnique({ where: { id: body.planId } })
      if (!plan) return NextResponse.json({ error: 'Plan not found' }, { status: 404 })
      updateData.planId = body.planId
      // Recalculate end date from now
      const newEnd = new Date()
      newEnd.setDate(newEnd.getDate() + plan.durationDays)
      updateData.endDate = newEnd
      updateData.startDate = new Date()
    }

    const subscription = await db.userSubscription.update({
      where: { id },
      data: updateData,
      include: { plan: true, user: { select: { id: true, username: true, name: true } } },
    })
    return NextResponse.json(subscription)
  } catch (error: any) {
    if (error?.code === 'P2025') {
      return NextResponse.json({ error: 'Subscription not found' }, { status: 404 })
    }
    console.error('PUT user-subscription error:', error)
    return NextResponse.json({ error: 'Failed to update subscription' }, { status: 500 })
  }
}
