import { db } from '@/lib/db'
import { readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'

// GET /api/user-subscriptions — list all subscriptions (admin) or own subscription (user)
export async function GET(request: Request) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.userId) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const url = new URL(request.url)
    const userId = url.searchParams.get('userId')
    const status = url.searchParams.get('status')

    if (ctx.isMaster) {
      // Admin: can see all subscriptions or filter by userId/status
      const where: Record<string, any> = {}
      if (userId) where.userId = userId
      if (status) where.status = status

      const subscriptions = await db.userSubscription.findMany({
        where,
        include: {
          user: { select: { id: true, username: true, name: true, role: true } },
          plan: true,
        },
        orderBy: { createdAt: 'desc' },
      })
      return NextResponse.json(subscriptions)
    } else {
      // Regular user: only see their own subscriptions
      const subscriptions = await db.userSubscription.findMany({
        where: { userId: ctx.userId },
        include: { plan: true },
        orderBy: { createdAt: 'desc' },
      })
      return NextResponse.json(subscriptions)
    }
  } catch (error) {
    console.error('GET user-subscriptions error:', error)
    return NextResponse.json({ error: 'Failed to fetch subscriptions' }, { status: 500 })
  }
}

// POST /api/user-subscriptions — create a new subscription (admin only, or auto-trial)
export async function POST(request: Request) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.userId) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const body = await request.json()
    const { userId, planId, paymentMethod, paymentRef, amountPaid, activatedBy, autoRenew } = body

    // If not admin, only allow creating own subscription
    const targetUserId = ctx.isMaster ? (userId || ctx.userId) : ctx.userId

    // Validate plan exists
    const plan = await db.subscriptionPlan.findUnique({ where: { id: planId } })
    if (!plan) {
      return NextResponse.json({ error: 'Plan not found' }, { status: 404 })
    }
    if (!plan.isActive) {
      return NextResponse.json({ error: 'Plan is not active' }, { status: 400 })
    }

    // Check if user already has an active subscription
    const existingActive = await db.userSubscription.findFirst({
      where: { userId: targetUserId, status: 'active' },
    })
    if (existingActive) {
      return NextResponse.json({ error: 'User already has an active subscription', subscription: existingActive }, { status: 409 })
    }

    const now = new Date()
    const endDate = new Date(now)
    endDate.setDate(endDate.getDate() + plan.durationDays)

    const subscription = await db.userSubscription.create({
      data: {
        userId: targetUserId,
        planId,
        startDate: now,
        endDate,
        status: 'active',
        paymentStatus: plan.price === 0 ? 'completed' : (body.paymentStatus || 'pending'),
        paymentMethod: paymentMethod || null,
        paymentRef: paymentRef || null,
        amountPaid: amountPaid !== undefined ? Number(amountPaid) : plan.price,
        activatedBy: activatedBy || (ctx.isMaster ? ctx.username : null),
        autoRenew: autoRenew || false,
      },
      include: { plan: true, user: { select: { id: true, username: true, name: true } } },
    })

    return NextResponse.json(subscription, { status: 201 })
  } catch (error) {
    console.error('POST user-subscriptions error:', error)
    return NextResponse.json({ error: 'Failed to create subscription' }, { status: 500 })
  }
}
