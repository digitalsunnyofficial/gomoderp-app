// ────────────────────────────────────────────────────────────
// Chitthi Generator API — agents collect a customer's vyapar on the
// ground and submit it here; the system parses it with the SAME
// Smart Entry engine (parseUnifiedEntry) and renders the traditional
// handwritten chitthi slip as a JPG (share / print).
// ────────────────────────────────────────────────────────────
import { db } from '@/lib/db'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import { parseUnifiedEntry, type UnifiedParseResult } from '@/lib/matka/entry-parser'
import {
  buildChitthiContent,
  renderChitthiJpeg,
  chitthiStorageDir,
  istToday,
  slipDateDisplay,
} from '@/lib/chitthi/render'

export const dynamic = 'force-dynamic'

/** Custom dictionary terms (ParserTerm table) — same parity as Smart Entry. */
async function loadCustomTerms() {
  const rows = await db.parserTerm.findMany({ where: { isActive: true }, select: { term: true, category: true } })
  return rows
}

function summarizeParse(parse: UnifiedParseResult) {
  const sum = (arr: Array<{ amount: number }>) => arr.reduce((s, e) => s + e.amount, 0)
  const groups = parse.groups.map(g => ({
    option: g.option,
    count: g.entries.length,
    amount: sum(g.entries),
    invalid: g.invalid.length,
  }))
  const total =
    sum(parse.singles) + sum(parse.doubles) + sum(parse.triples) + sum(parse.common) +
    groups.reduce((s, g) => s + g.amount, 0)
  return {
    counts: {
      singles: { count: parse.singles.length, amount: sum(parse.singles) },
      doubles: { count: parse.doubles.length, amount: sum(parse.doubles) },
      triples: { count: parse.triples.length, amount: sum(parse.triples) },
      common: { count: parse.common.length, amount: sum(parse.common) },
      groups,
    },
    total,
    unknownLabels: parse.unknownLabels,
    skipped: parse.skipped,
  }
}

// GET /api/chitthi — recent chitthis (Super Admin / Admin only).
// Operator rule: agents must NOT have the Chitthi Generator (access-control.ts).
export async function GET(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Chitthi Generator is available to Super Admin / Admin accounts only' }, { status: 403 })
    }
    const rows = await db.chitthi.findMany({
      where: {},
      orderBy: { createdAt: 'desc' },
      take: 50,
    })
    return NextResponse.json(rows.map(r => ({
      ...r,
      imageUrl: `/api/chitthi/${r.id}/image`,
    })))
  } catch (error) {
    console.error('GET chitthi error:', error)
    return NextResponse.json({ error: 'Failed to fetch chitthis' }, { status: 500 })
  }
}

// POST /api/chitthi — parse + render + store a new chitthi
// Operator rule: agents must NOT have the Chitthi Generator (access-control.ts).
export async function POST(request: Request) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    const { user } = auth
    if (!isMasterOrAdminManager(user.role)) {
      return NextResponse.json({ error: 'Chitthi Generator is available to Super Admin / Admin accounts only' }, { status: 403 })
    }

    const body = await request.json().catch(() => null)
    const rawText = String(body?.rawText ?? '').trim()
    const market = String(body?.market ?? '').trim()
    if (!rawText) return NextResponse.json({ error: 'Vyapar text is required' }, { status: 400 })
    if (!market) return NextResponse.json({ error: 'Market is required' }, { status: 400 })

    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(body?.date ?? '')) ? String(body.date) : istToday()
    const defaultRate = Number.isFinite(Number(body?.defaultRate)) && Number(body.defaultRate) > 0
      ? Number(body.defaultRate) : 100

    // Customer — either picked from the ERP customer list or free text
    let customerName = String(body?.customerName ?? '').trim()
    let customerMobile = String(body?.customerMobile ?? '').trim()
    let vendorId: string | null = null
    if (body?.vendorId) {
      const vendor = await db.vendor.findUnique({ where: { id: String(body.vendorId) } })
      if (vendor) {
        vendorId = vendor.id
        customerName = customerName || vendor.businessName
        customerMobile = customerMobile || vendor.mobileNo
      }
    }
    if (!customerName) customerName = ''

    // Parse with the Smart Entry engine (one source of truth) + dictionary parity
    const customTerms = await loadCustomTerms()
    const parse = parseUnifiedEntry(rawText, defaultRate, customTerms)
    const summary = summarizeParse(parse)
    if (summary.total <= 0) {
      return NextResponse.json({ error: 'No readable vyapar found in the text', summary }, { status: 400 })
    }

    const content = buildChitthiContent(parse, market, slipDateDisplay(date), customerName || undefined)

    // Create the record, render with the record id as the jitter seed, persist
    const created = await db.chitthi.create({
      data: {
        vendorId,
        customerName,
        customerMobile,
        market,
        chitthiDate: date,
        rawText,
        parseSummary: JSON.stringify(summary),
        totalAmount: summary.total,
        fileName: 'pending',
        createdBy: user.username,
      },
    })

    const jpg = await renderChitthiJpeg(content, created.id)
    const fileName = `${created.id}.jpg`
    fs.writeFileSync(path.join(chitthiStorageDir(), fileName), jpg)
    await db.chitthi.update({ where: { id: created.id }, data: { fileName } })

    return NextResponse.json({
      id: created.id,
      imageUrl: `/api/chitthi/${created.id}/image`,
      total: summary.total,
      summary,
      createdAt: created.createdAt,
    })
  } catch (error) {
    console.error('POST chitthi error:', error)
    return NextResponse.json({ error: 'Failed to generate chitthi' }, { status: 500 })
  }
}
