// GET /api/chitthi/[id]/image — serve the rendered chitthi JPG.
// ?download=1 forces a file download (WhatsApp share / gallery save).
// Super Admin / Admin only — agents must not read chitthi slips (access-control.ts).
import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import { chitthiStorageDir } from '@/lib/chitthi/render'
import { requireAuth, isMasterOrAdminManager } from '@/lib/hierarchy-auth'

export const dynamic = 'force-dynamic'

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (!auth.ok) return auth.response
    if (!isMasterOrAdminManager(auth.user.role)) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }
    const { id } = await params
    const record = await db.chitthi.findUnique({ where: { id } })
    if (!record) return NextResponse.json({ error: 'Chitthi not found' }, { status: 404 })

    const filePath = path.join(chitthiStorageDir(), record.fileName)
    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ error: 'Chitthi image file missing' }, { status: 404 })
    }
    const buf = fs.readFileSync(filePath)
    const url = new URL(request.url)
    const download = url.searchParams.get('download') === '1'
    const safeName = `${record.market.replace(/[^a-zA-Z0-9]+/g, '-')}-${record.chitthiDate}.jpg`
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': 'image/jpeg',
        'Cache-Control': 'private, max-age=3600',
        ...(download ? { 'Content-Disposition': `attachment; filename="chitthi-${safeName}"` } : {}),
      },
    })
  } catch (error) {
    console.error('GET chitthi image error:', error)
    return NextResponse.json({ error: 'Failed to load chitthi image' }, { status: 500 })
  }
}
