import { db } from '@/lib/db'
import { logActivity, readAuthContext, getAuthUser, marketFilter, canAccessMarket, dataIsolationFilter } from '@/lib/audit'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''
    const status = searchParams.get('status') || ''

    // Phase 2 — filter by user's assigned markets
    const authCtx = readAuthContext(request)

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (search) {
      where.OR = [
        { remark: { contains: search } },
        { inventoryCode: { name: { contains: search } } },
      ]
    }
    // Apply market filter — non-master users only see inventories in their markets
    const mFilter = marketFilter(authCtx, 'inventoryCode.market')
    if (mFilter._none) {
      // No markets assigned — return empty result
      return NextResponse.json({ data: [], total: 0, page, limit })
    }
    Object.assign(where, mFilter)

    // Apply data isolation — manager sees own + agents', agent sees only own
    const dFilter = await dataIsolationFilter(authCtx, 'createdBy')
    if (dFilter.createdBy === '__none__') {
      return NextResponse.json({ data: [], total: 0, page, limit })
    }
    Object.assign(where, dFilter)

    const [inventories, total] = await Promise.all([
      db.inventory.findMany({
        where,
        include: { inventoryCode: true, cards: true },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.inventory.count({ where }),
    ])

    // Enrich with creator info (role + name) for display
    const creatorUsernames = [...new Set(inventories.map((inv: { createdBy: string }) => inv.createdBy).filter(Boolean))]
    const creators = creatorUsernames.length > 0
      ? await db.user.findMany({
          where: { username: { in: creatorUsernames } },
          select: { username: true, name: true, role: true, id: true, managerId: true },
        })
      : []
    const creatorMap = Object.fromEntries(creators.map((c: { username: string }) => [c.username, c]))

    const enrichedInventories = inventories.map((inv: Record<string, unknown>) => ({
      ...inv,
      creatorInfo: inv.createdBy ? creatorMap[inv.createdBy as string] || null : null,
    }))

    return NextResponse.json({ data: enrichedInventories, total, page, limit })
  } catch (error) {
    console.error('GET inventories error:', error)
    return NextResponse.json({ error: 'Failed to fetch inventories' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { date, inventoryCodeId, remark, cards, createdBy, time, totalAmount } = body

    if (!date || !inventoryCodeId || !createdBy) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Phase 2 — verify market access (DB-backed check)
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const invCode = await db.inventoryCode.findUnique({
      where: { id: inventoryCodeId },
      select: { id: true, market: true, name: true, code: true },
    })
    if (!invCode) {
      return NextResponse.json({ error: 'Inventory code not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, invCode.market)) {
      await logActivity({
        userId: authCtx.userId,
        username: authCtx.username || 'unknown',
        action: 'create_denied',
        entity: 'inventory',
        metadata: { reason: 'market_access', market: invCode.market, inventoryCodeId },
      })
      return NextResponse.json(
        { error: `You do not have access to market "${invCode.market}"` },
        { status: 403 }
      )
    }

    // Prevent duplicate: check if an inventory with the same code, date, and time already exists
    const dateObj = new Date(date)
    const startOfDay = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate())
    const endOfDay = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate() + 1)

    const existing = await db.inventory.findFirst({
      where: {
        inventoryCodeId,
        date: { gte: startOfDay, lt: endOfDay },
        time: time || null,
      },
    })
    if (existing) {
      return NextResponse.json({ error: 'An inventory for this code, date, and time already exists', existingId: existing.id }, { status: 409 })
    }

    // Calculate totalTxn from cards
    let totalTxn = 0
    if (cards && Array.isArray(cards)) {
      totalTxn = cards.reduce((sum: number, c: { value: string }) => {
        const val = parseFloat(c.value)
        return sum + (isNaN(val) ? 0 : val)
      }, 0)
    }

    const inventory = await db.inventory.create({
      data: {
        date: new Date(date),
        time: time || null,
        inventoryCodeId,
        remark: remark || null,
        totalTxn: totalAmount ? parseFloat(String(totalAmount)) : totalTxn,
        totalAmount: totalAmount ? parseFloat(String(totalAmount)) : 0,
        remaining: totalAmount ? parseFloat(String(totalAmount)) : totalTxn,
        createdBy,
        cards: cards ? {
          create: cards.map((c: { position: number; value: string }) => ({
            position: c.position,
            value: c.value,
          }))
        } : undefined,
      },
      include: { inventoryCode: true, cards: true },
    })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || createdBy,
      action: 'create',
      entity: 'inventory',
      entityId: inventory.id,
      market: invCode.market,
      recordsAffected: 1,
      metadata: { inventoryCodeId, date, time: time || null },
    })

    return NextResponse.json(inventory, { status: 201 })
  } catch (error) {
    console.error('POST inventory error:', error)
    return NextResponse.json({ error: 'Failed to create inventory' }, { status: 500 })
  }
}
