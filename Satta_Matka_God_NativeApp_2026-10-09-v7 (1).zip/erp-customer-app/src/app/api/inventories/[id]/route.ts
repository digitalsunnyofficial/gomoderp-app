import { db } from '@/lib/db'
import { logActivity, getAuthUser, canAccessMarket } from '@/lib/audit'
import { NextResponse } from 'next/server'

/**
 * Data isolation for a single inventory record.
 * Master: everything. Manager: own + own active agents' records.
 * Agent: only own records. Returns true when access is allowed.
 *
 * Keeps single-record access consistent with the isolated list views
 * (an inventory hidden from a user's list is also denied when fetched
 * directly by id).
 */
async function canAccessInventoryRecord(
  authCtx: { role: string; userId?: string; username?: string },
  createdBy: string
): Promise<boolean> {
  if (authCtx.role === 'super') return true
  let allowed: string[] = []
  if (authCtx.role === 'manager' && authCtx.userId) {
    const agents = await db.user.findMany({
      where: { managerId: authCtx.userId, status: 'active' },
      select: { username: true },
    })
    allowed = [authCtx.username || '', ...agents.map(a => a.username)].filter(Boolean)
  } else {
    allowed = [authCtx.username || ''].filter(Boolean)
  }
  return allowed.includes(createdBy)
}

// GET single inventory with related data
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Fetch inventory with basic includes separately to avoid memory issues with deep nesting
    const inventory = await db.inventory.findUnique({
      where: { id },
      include: {
        inventoryCode: true,
        cards: { orderBy: { position: 'asc' } },
      },
    })

    if (!inventory) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }

    // Phase 2 — verify market access
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!canAccessMarket(authCtx, inventory.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${inventory.inventoryCode.market}"` },
        { status: 403 }
      )
    }
    // Data isolation — non-master users can only open their own or their
    // agents' inventories (matches the isolated list views)
    if (!(await canAccessInventoryRecord(authCtx, inventory.createdBy))) {
      return NextResponse.json(
        { error: 'You do not have access to this inventory' },
        { status: 403 }
      )
    }

    // Fetch triple and double-single inventories separately
    const [tripleInventories, doubleSingleInventories] = await Promise.all([
      db.tripleInventory.findMany({
        where: { inventoryId: id },
        include: { vendor: true },
        orderBy: { createdAt: 'desc' },
      }),
      db.doubleSingleInventory.findMany({
        where: { inventoryId: id },
        include: { vendor: true },
        orderBy: { createdAt: 'desc' },
      }),
    ])

    return NextResponse.json({
      ...inventory,
      tripleInventories,
      doubleSingleInventories,
    })
  } catch (error) {
    console.error('GET inventory error:', error)
    return NextResponse.json({ error: 'Failed to fetch inventory' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { date, inventoryCodeId, status, remark, cards } = body

    // Phase 2 — verify access to current inventory's market
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const existing = await db.inventory.findUnique({
      where: { id },
      include: { inventoryCode: true },
    })
    if (!existing) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, existing.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${existing.inventoryCode.market}"` },
        { status: 403 }
      )
    }
    // If switching inventoryCode, also verify access to new market
    if (inventoryCodeId && inventoryCodeId !== existing.inventoryCodeId) {
      const newCode = await db.inventoryCode.findUnique({ where: { id: inventoryCodeId }, select: { market: true } })
      if (newCode && !canAccessMarket(authCtx, newCode.market)) {
        return NextResponse.json(
          { error: `You do not have access to market "${newCode.market}"` },
          { status: 403 }
        )
      }
    }

    // If cards are being updated, recalculate totals
    let totalTxn: number | undefined
    let remaining: number | undefined
    if (cards && Array.isArray(cards)) {
      totalTxn = cards.reduce((sum: number, c: { value: string }) => {
        const val = parseFloat(c.value)
        return sum + (isNaN(val) ? 0 : val)
      }, 0)
      remaining = status === 'closed' ? 0 : totalTxn
    }

    // Delete existing cards and recreate if cards provided
    if (cards) {
      await db.card.deleteMany({ where: { inventoryId: id } })
    }

    const inventory = await db.inventory.update({
      where: { id },
      data: {
        ...(date && { date: new Date(date) }),
        ...(inventoryCodeId && { inventoryCodeId }),
        ...(status && { status }),
        ...(remark !== undefined && { remark: remark || null }),
        ...(totalTxn !== undefined && { totalTxn }),
        ...(remaining !== undefined && { remaining }),
        ...(cards && {
          cards: {
            create: cards.map((c: { position: number; value: string }) => ({
              position: c.position,
              value: c.value,
            }))
          }
        }),
      },
      include: { inventoryCode: true, cards: { orderBy: { position: 'asc' } } },
    })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'update',
      entity: 'inventory',
      entityId: id,
      market: existing.inventoryCode.market,
      metadata: { fields: Object.keys(body) },
    })

    return NextResponse.json(inventory)
  } catch (error) {
    console.error('PUT inventory error:', error)
    return NextResponse.json({ error: 'Failed to update inventory' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Phase 2 — verify market access before deleting
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const existing = await db.inventory.findUnique({
      where: { id },
      include: { inventoryCode: true },
    })
    if (!existing) {
      return NextResponse.json({ error: 'Inventory not found' }, { status: 404 })
    }
    if (!canAccessMarket(authCtx, existing.inventoryCode.market)) {
      return NextResponse.json(
        { error: `You do not have access to market "${existing.inventoryCode.market}"` },
        { status: 403 }
      )
    }

    await db.tripleInventory.deleteMany({ where: { inventoryId: id } })
    await db.doubleSingleInventory.deleteMany({ where: { inventoryId: id } })
    await db.card.deleteMany({ where: { inventoryId: id } })
    await db.inventory.delete({ where: { id } })

    // Phase 2 — audit log
    await logActivity({
      userId: authCtx.userId,
      username: authCtx.username || 'unknown',
      action: 'delete',
      entity: 'inventory',
      entityId: id,
      market: existing.inventoryCode.market,
      metadata: { inventoryCodeId: existing.inventoryCodeId, date: existing.date },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE inventory error:', error)
    return NextResponse.json({ error: 'Failed to delete inventory' }, { status: 500 })
  }
}
