import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/parser-config — fetch all patterns and separators
export async function GET() {
  try {
    const patterns = await db.parserPattern.findMany({ orderBy: { priority: 'asc' } })
    const separators = await db.parserSeparator.findMany({ orderBy: { priority: 'asc' } })
    return NextResponse.json({ patterns, separators })
  } catch (error) {
    console.error('Parser config GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch parser config' }, { status: 500 })
  }
}

// POST /api/parser-config — create a new pattern or separator
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { type, data } = body

    if (type === 'pattern') {
      const pattern = await db.parserPattern.create({ data })
      return NextResponse.json(pattern, { status: 201 })
    } else if (type === 'separator') {
      const separator = await db.parserSeparator.create({ data })
      return NextResponse.json(separator, { status: 201 })
    } else {
      return NextResponse.json({ error: 'Invalid type. Use "pattern" or "separator"' }, { status: 400 })
    }
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create'
    console.error('Parser config POST error:', error)
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

// PUT /api/parser-config — update a pattern or separator
export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { type, id, data } = body

    if (type === 'pattern') {
      const pattern = await db.parserPattern.update({ where: { id }, data })
      return NextResponse.json(pattern)
    } else if (type === 'separator') {
      const separator = await db.parserSeparator.update({ where: { id }, data })
      return NextResponse.json(separator)
    } else {
      return NextResponse.json({ error: 'Invalid type' }, { status: 400 })
    }
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to update'
    console.error('Parser config PUT error:', error)
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

// DELETE /api/parser-config — delete a pattern or separator
export async function DELETE(request: Request) {
  try {
    const body = await request.json()
    const { type, id } = body

    if (type === 'pattern') {
      await db.parserPattern.delete({ where: { id } })
      return NextResponse.json({ success: true })
    } else if (type === 'separator') {
      await db.parserSeparator.delete({ where: { id } })
      return NextResponse.json({ success: true })
    } else {
      return NextResponse.json({ error: 'Invalid type' }, { status: 400 })
    }
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to delete'
    console.error('Parser config DELETE error:', error)
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
