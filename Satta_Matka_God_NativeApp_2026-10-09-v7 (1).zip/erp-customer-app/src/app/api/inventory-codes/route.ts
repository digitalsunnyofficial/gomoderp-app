import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const codes = await db.inventoryCode.findMany({ orderBy: { code: 'asc' } })
    return NextResponse.json(codes)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch inventory codes' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { code, name, market, type } = body
    if (!code || !name || !market || !type) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }
    const inventoryCode = await db.inventoryCode.create({
      data: { code, name, market, type }
    })
    return NextResponse.json(inventoryCode, { status: 201 })
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create inventory code'
    if (msg.includes('Unique')) {
      return NextResponse.json({ error: 'Code already exists' }, { status: 409 })
    }
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
