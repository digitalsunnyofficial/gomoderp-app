import { db } from '@/lib/db'
import { readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'

// GET /api/payments/[id] — get a specific payment
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.userId) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }
    const { id } = await params
    const payment = await db.payment.findUnique({
      where: { id },
      include: {
        subscription: {
          include: {
            user: { select: { id: true, username: true, name: true } },
            plan: true,
          },
        },
      },
    })
    if (!payment) return NextResponse.json({ error: 'Payment not found' }, { status: 404 })
    // Non-admin users can only see their own payments
    if (!ctx.isMaster && payment.subscription.userId !== ctx.userId) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }
    return NextResponse.json(payment)
  } catch (error) {
    console.error('GET payment error:', error)
    return NextResponse.json({ error: 'Failed to fetch payment' }, { status: 500 })
  }
}

// PUT /api/payments/[id] — update payment status (admin only)
export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.isMaster) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }
    const { id } = await params
    const body = await request.json()
    const updateData: Record<string, any> = {}

    if (body.status !== undefined) updateData.status = body.status
    if (body.reference !== undefined) updateData.reference = body.reference
    if (body.receiptNo !== undefined) updateData.receiptNo = body.receiptNo
    if (body.notes !== undefined) updateData.notes = body.notes
    if (body.processedBy !== undefined) updateData.processedBy = body.processedBy

    const payment = await db.payment.update({
      where: { id },
      data: updateData,
      include: {
        subscription: {
          include: {
            user: { select: { id: true, username: true, name: true } },
            plan: true,
          },
        },
      },
    })

    // Update subscription payment status if payment is completed
    if (body.status === 'completed') {
      await db.userSubscription.update({
        where: { id: payment.subscriptionId },
        data: { paymentStatus: 'completed' },
      })
    } else if (body.status === 'refunded') {
      await db.userSubscription.update({
        where: { id: payment.subscriptionId },
        data: { paymentStatus: 'refunded' },
      })
    }

    return NextResponse.json(payment)
  } catch (error: any) {
    if (error?.code === 'P2025') {
      return NextResponse.json({ error: 'Payment not found' }, { status: 404 })
    }
    console.error('PUT payment error:', error)
    return NextResponse.json({ error: 'Failed to update payment' }, { status: 500 })
  }
}
