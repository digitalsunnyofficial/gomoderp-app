import { db } from '@/lib/db'
import { readAuthContext } from '@/lib/audit'
import { NextResponse } from 'next/server'

// GET /api/payments — list all payments (admin) or own payments (user)
export async function GET(request: Request) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.userId) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const url = new URL(request.url)
    const status = url.searchParams.get('status')
    const method = url.searchParams.get('method')

    if (ctx.isMaster) {
      const where: Record<string, any> = {}
      if (status) where.status = status
      if (method) where.method = method

      const payments = await db.payment.findMany({
        where,
        include: {
          subscription: {
            include: {
              user: { select: { id: true, username: true, name: true } },
              plan: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      })
      return NextResponse.json(payments)
    } else {
      // Regular user: only see payments for their own subscriptions
      const userSubIds = await db.userSubscription.findMany({
        where: { userId: ctx.userId },
        select: { id: true },
      })
      const subIds = userSubIds.map(s => s.id)

      const payments = await db.payment.findMany({
        where: { subscriptionId: { in: subIds } },
        include: { subscription: { include: { plan: true } } },
        orderBy: { createdAt: 'desc' },
      })
      return NextResponse.json(payments)
    }
  } catch (error) {
    console.error('GET payments error:', error)
    return NextResponse.json({ error: 'Failed to fetch payments' }, { status: 500 })
  }
}

// POST /api/payments — create a payment record (admin only)
export async function POST(request: Request) {
  try {
    const ctx = readAuthContext(request)
    if (!ctx.isMaster) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const body = await request.json()
    const { subscriptionId, amount, method, status, reference, receiptNo, notes, processedBy } = body

    if (!subscriptionId || !amount || !method) {
      return NextResponse.json({ error: 'subscriptionId, amount, and method are required' }, { status: 400 })
    }

    // Validate subscription exists
    const subscription = await db.userSubscription.findUnique({
      where: { id: subscriptionId },
    })
    if (!subscription) {
      return NextResponse.json({ error: 'Subscription not found' }, { status: 404 })
    }

    // Generate receipt number if not provided
    const receipt = receiptNo || `RCP-${Date.now().toString(36).toUpperCase()}`

    const payment = await db.payment.create({
      data: {
        subscriptionId,
        amount: Number(amount),
        currency: body.currency || 'INR',
        method,
        status: status || 'completed',
        reference: reference || null,
        receiptNo: receipt,
        notes: notes || null,
        processedBy: processedBy || ctx.username,
      },
      include: {
        subscription: {
          include: {
            user: { select: { id: true, username: true, name: true } },
            plan: true,
          },
        },
      },
    })

    // Update subscription payment status if payment is completed
    if (payment.status === 'completed') {
      await db.userSubscription.update({
        where: { id: subscriptionId },
        data: { paymentStatus: 'completed', amountPaid: Number(amount) },
      })
    }

    return NextResponse.json(payment, { status: 201 })
  } catch (error) {
    console.error('POST payments error:', error)
    return NextResponse.json({ error: 'Failed to create payment' }, { status: 500 })
  }
}
