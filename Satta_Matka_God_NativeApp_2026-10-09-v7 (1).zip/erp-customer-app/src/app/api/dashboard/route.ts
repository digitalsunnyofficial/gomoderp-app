import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getAuthUser, marketFilter, dataIsolationFilter } from '@/lib/audit'

// Dashboard counters. NOTE: the former hisab/settlement counters
// (totalSettlements / totalWinningPaid) were removed together with the
// Hisab module (operator decision) — settlement happens at the
// customer/agent level now.
export async function GET(request: Request) {
  try {
    // ── Data isolation (fix: admin saw master-level inventory in dashboard) ──
    // Master sees everything; manager (admin) sees own + own agents' entries
    // limited to their assigned markets; agent sees only own entries in own
    // markets.
    const authCtx = await getAuthUser(request)
    if (!authCtx) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const mFilter = marketFilter(authCtx, 'inventoryCode.market')
    if (mFilter._none) {
      return NextResponse.json({
        totalInventories: 0,
        activeVendors: 0,
        recentInventories: [],
      })
    }

    const dFilter = await dataIsolationFilter(authCtx, 'createdBy')
    if (dFilter.createdBy === '__none__') {
      return NextResponse.json({
        totalInventories: 0,
        activeVendors: 0,
        recentInventories: [],
      })
    }

    const inventoryWhere = { ...mFilter, ...dFilter }

    // Vendors: restrict to those created within the user's isolation scope.
    const vendorWhere = dFilter.createdBy ? { createdBy: dFilter.createdBy } : {}

    const [totalInventories, activeVendors, inventories] = await Promise.all([
      db.inventory.count({ where: inventoryWhere }),
      db.vendor.count({ where: vendorWhere }),
      db.inventory.findMany({
        where: inventoryWhere,
        include: { inventoryCode: true },
        orderBy: { createdAt: 'desc' },
        take: 10,
      }),
    ])

    return NextResponse.json({
      totalInventories,
      activeVendors,
      recentInventories: inventories,
    })
  } catch (error) {
    console.error('GET dashboard error:', error)
    return NextResponse.json({ error: 'Failed to fetch dashboard data' }, { status: 500 })
  }
}
