import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// GET /api/subscriptions — list all subscriptions (admin) or current user's subscription
export async function GET(req: NextRequest) {
  try {
    const cookie = req.cookies.get('erp_session')
    if (!cookie?.value) {
      return NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 })
    }

    let session
    try {
      session = JSON.parse(cookie.value)
    } catch {
      return NextResponse.json({ error: 'Invalid session' }, { status: 401 })
    }

    const isAdmin = session.role === 'super'

    if (isAdmin) {
      // Admin: return all subscriptions
      const subscriptions = await prisma.$queryRaw`
        SELECT s.*, u.username, u.name as userName
        FROM Subscription s
        LEFT JOIN User u ON s.userId = u.id
        ORDER BY s.createdAt DESC
      ` as any[]
      return NextResponse.json({ subscriptions })
    } else {
      // User: return their own subscription
      const subscription = await prisma.$queryRaw`
        SELECT * FROM Subscription WHERE userId = ${session.id} ORDER BY createdAt DESC LIMIT 1
      ` as any[]
      return NextResponse.json({ subscription: subscription[0] || null })
    }
  } catch (error) {
    console.error('Subscriptions GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch subscriptions' }, { status: 500 })
  }
}

// POST /api/subscriptions — create or update a subscription
export async function POST(req: NextRequest) {
  try {
    const cookie = req.cookies.get('erp_session')
    if (!cookie?.value) {
      return NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 })
    }

    let session
    try {
      session = JSON.parse(cookie.value)
    } catch {
      return NextResponse.json({ error: 'Invalid session' }, { status: 401 })
    }

    const body = await req.json()
    const { userId, planType, amount, paymentStatus } = body

    const isAdmin = session.role === 'super'
    const targetUserId = isAdmin && userId ? userId : session.id

    if (!planType || !['trial', 'monthly', 'quarterly', 'semiannual', 'yearly'].includes(planType)) {
      return NextResponse.json({ error: 'Invalid plan type' }, { status: 400 })
    }

    // Calculate expiry date based on plan
    const now = new Date()
    const expiresAt = new Date(now)
    switch (planType) {
      case 'trial': expiresAt.setDate(expiresAt.getDate() + 7); break
      case 'monthly': expiresAt.setMonth(expiresAt.getMonth() + 1); break
      case 'quarterly': expiresAt.setMonth(expiresAt.getMonth() + 3); break
      case 'semiannual': expiresAt.setMonth(expiresAt.getMonth() + 6); break
      case 'yearly': expiresAt.setFullYear(expiresAt.getFullYear() + 1); break
    }

    // Upsert subscription
    await prisma.$executeRaw`
      INSERT INTO Subscription (id, userId, planType, amount, paymentStatus, startDate, endDate, createdAt, updatedAt)
      VALUES (${crypto.randomUUID()}, ${targetUserId}, ${planType}, ${amount || 0}, ${paymentStatus || 'pending'}, ${now.toISOString()}, ${expiresAt.toISOString()}, ${now.toISOString()}, ${now.toISOString()})
    `

    return NextResponse.json({ success: true, planType, expiresAt: expiresAt.toISOString() })
  } catch (error) {
    console.error('Subscriptions POST error:', error)
    return NextResponse.json({ error: 'Failed to create subscription' }, { status: 500 })
  }
}
