import { NextRequest, NextResponse } from 'next/server';

const LARAVEL_BASE = 'http://localhost:8000';

/**
 * Catch-all API proxy route for non-GET requests (POST, PUT, DELETE, PATCH).
 * Runs in the Node.js runtime with full access to request bodies
 * and response header manipulation.
 *
 * The middleware rewrites non-GET requests to /api/_proxy/<original-path>
 * so they hit this route handler.
 */

export async function POST(request: NextRequest) {
  return proxyRequest(request);
}

export async function PUT(request: NextRequest) {
  return proxyRequest(request);
}

export async function DELETE(request: NextRequest) {
  return proxyRequest(request);
}

export async function PATCH(request: NextRequest) {
  return proxyRequest(request);
}

async function proxyRequest(request: NextRequest) {
  // Extract the original path from the URL
  // URL format: /api/_proxy/<original-path>?<query>
  const url = new URL(request.url);
  const originalPath = url.pathname.replace('/api/_proxy', '') || '/';
  const targetUrl = `${LARAVEL_BASE}${originalPath}${url.search}`;

  // Build forwarded headers
  const headers = new Headers(request.headers);
  headers.set('Host', 'localhost:8000');
  headers.set('X-Forwarded-Host', request.headers.get('host') || 'localhost');
  headers.set(
    'X-Forwarded-Proto',
    url.protocol.replace(':', '') || 'https'
  );
  headers.set('X-Forwarded-Port', url.port || '443');
  headers.set(
    'X-Forwarded-For',
    request.headers.get('x-forwarded-for') || '127.0.0.1'
  );

  // Get request body
  let body: BodyInit | null = null;
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    body = await request.arrayBuffer();
    if ((body as ArrayBuffer).byteLength === 0) {
      body = null;
    }
  }

  try {
    const response = await fetch(targetUrl, {
      method: request.method,
      headers,
      body,
      redirect: 'manual', // Don't follow redirects — handle them ourselves
    });

    // Build response headers, rewriting as needed
    const responseHeaders = new Headers(response.headers);

    // Rewrite Location header for redirects
    const location = responseHeaders.get('Location');
    if (location) {
      responseHeaders.set(
        'Location',
        location.replace(/https?:\/\/localhost:8000/g, '')
      );
    }

    // Remove problematic headers
    responseHeaders.delete('transfer-encoding');
    responseHeaders.delete('content-encoding');
    responseHeaders.delete('content-length');

    // Check if this is an HTML response that needs URL rewriting
    const contentType = responseHeaders.get('content-type') || '';
    const isHtml = contentType.includes('text/html');

    if (isHtml) {
      let html = await response.text();
      html = html.replace(/https?:\/\/localhost:8000/g, '');
      return new NextResponse(html, {
        status: response.status,
        statusText: response.statusText,
        headers: responseHeaders,
      });
    } else {
      return new NextResponse(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers: responseHeaders,
      });
    }
  } catch (error) {
    console.error('[API Proxy Error]', error);
    return NextResponse.json(
      { error: 'Bad Gateway: Could not reach Laravel backend' },
      { status: 502 }
    );
  }
}
