import { db } from '@/lib/db'
import { requireAuth, getVisibleAgentIds, ROLES } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'

/**
 * GET /api/agents — List agents with hierarchy-based visibility
 * 
 * MASTER_ADMIN: all agents
 * ADMIN_MANAGER: agents in own hierarchy
 * AGENT: only self
 */
export async function GET(request: Request) {
  try {
    const authResult = await requireAuth(request)
    if (!authResult.ok) return authResult.response
    const { user } = authResult

    const visibleAgentIds = await getVisibleAgentIds(user)

    const agents = await db.user.findMany({
      where: {
        id: { in: visibleAgentIds },
        role: { in: [ROLES.AGENT, 'user'] }, // include legacy 'user' role
      },
      select: {
        id: true,
        username: true,
        name: true,
        role: true,
        status: true,
        isLocked: true,
        assignedMarkets: true,
        managerId: true,
        createdByUserId: true,
        createdByAdminManagerId: true,
        createdAt: true,
        accessLinks: {
          select: {
            id: true,
            issuedAt: true,
            activatedAt: true,
            revokedAt: true,
            lastUsedAt: true,
            boundDeviceId: true,
            expiresAt: true,
          },
          orderBy: { issuedAt: 'desc' },
          take: 1, // latest link only
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(agents)
  } catch (error) {
    console.error('GET agents error:', error)
    return NextResponse.json({ error: 'Failed to fetch agents' }, { status: 500 })
  }
}
