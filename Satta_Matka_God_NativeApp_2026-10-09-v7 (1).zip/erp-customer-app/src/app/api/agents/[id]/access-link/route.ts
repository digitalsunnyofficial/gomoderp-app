import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { requireAdminManagerOrMaster, canManageAccessLink, ROLES } from '@/lib/hierarchy-auth'
import { NextResponse } from 'next/server'
import crypto from 'crypto'

/**
 * POST /api/agents/:id/access-link — Generate or regenerate an Agent access link
 * 
 * Allowed:
 * - MASTER_ADMIN for any Agent
 * - ADMIN_MANAGER only for own Agents
 * 
 * Behavior:
 * 1. Revoke any current active link for the Agent
 * 2. Generate a cryptographically secure random token
 * 3. Store only the SHA-256 hash of the token
 * 4. Return the raw link exactly once
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authResult = await requireAdminManagerOrMaster(request)
    if (!authResult.ok) return authResult.response
    const { user: issuer } = authResult

    const { id: agentId } = await params

    // Verify the target is an Agent
    const agent = await db.user.findUnique({
      where: { id: agentId },
      select: { id: true, username: true, role: true, status: true, isLocked: true },
    })

    if (!agent) {
      return NextResponse.json({ error: 'Agent not found' }, { status: 404 })
    }

    const normalizedRole = agent.role === 'user' ? ROLES.AGENT : agent.role
    if (normalizedRole !== ROLES.AGENT) {
      return NextResponse.json({ error: 'Target user is not an Agent' }, { status: 400 })
    }

    // Check if the issuer can manage this agent's links
    const canManage = await canManageAccessLink(issuer, agentId)
    if (!canManage) {
      return NextResponse.json({ error: 'You cannot manage access links for this Agent' }, { status: 403 })
    }

    // Step 1: Revoke all current active links for this agent
    await db.agentAccessLink.updateMany({
      where: {
        userId: agentId,
        revokedAt: null, // only active (non-revoked) links
      },
      data: {
        revokedAt: new Date(),
      },
    })

    // Step 2: Generate a cryptographically secure random token (32 bytes = 64 hex chars)
    const rawToken = crypto.randomBytes(32).toString('hex')

    // Step 3: Hash the token for storage (SHA-256)
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex')

    // Step 4: Store the hashed link record
    const accessLink = await db.agentAccessLink.create({
      data: {
        userId: agentId,
        tokenHash,
        issuedByUserId: issuer.id,
        lastUsedAt: new Date(), // Set to now as sentinel; activatedAt remains null until first use
      },
    })

    // Step 5: Log the generation
    await logActivity({
      userId: issuer.id,
      username: issuer.username,
      action: 'agent_access_link_generated',
      entity: 'user',
      entityId: agentId,
      metadata: { agentUsername: agent.username, linkId: accessLink.id },
    })

    // Step 6: Return the raw link — this is the ONLY time it's available
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const rawLink = `${baseUrl}/agent/access/${rawToken}`

    return NextResponse.json({
      link: rawLink,
      linkId: accessLink.id,
      issuedAt: accessLink.issuedAt,
      warning: 'This raw link is shown only once. Copy it now. It cannot be retrieved later.',
    }, { status: 201 })
  } catch (error) {
    console.error('POST access-link error:', error)
    return NextResponse.json({ error: 'Failed to generate access link' }, { status: 500 })
  }
}
