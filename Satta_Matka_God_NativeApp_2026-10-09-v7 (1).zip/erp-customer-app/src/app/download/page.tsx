// /download — the public landing IS the download page now (operator brief:
// one landing page = app download + encrypted admin entry). Keep this route
// as a redirect so previously shared links and QR codes keep working.
import { redirect } from 'next/navigation'

export default function DownloadRedirectPage() {
  redirect('/')
}
