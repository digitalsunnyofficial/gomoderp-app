import type { Metadata, Viewport } from 'next'
import { Crown, Trophy, Wallet, Zap, Languages, Shield, Check, Smartphone, Bell, Users, Gamepad2 } from 'lucide-react'
import { DownloadCta } from '@/components/public/DownloadCta'
import { adminGateToken } from '@/lib/admin-gate'

// ──────────────────────────────────────────────────────────
// SATTA MATKA GOD — the ONE public page.
// Application download + a complete customer guide with real
// screenshots of every app screen + one encrypted link to the
// super admin login (footer). Per operator brief.
// ──────────────────────────────────────────────────────────

export const metadata: Metadata = {
  title: 'Satta Matka God — Official Android App & Guide',
  description: 'Download the official Satta Matka God Android app and learn how it works — register, add points, play markets, check results and withdraw, with screenshots of every screen.',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0B0F1A',
}

const HIGHLIGHTS = [
  { icon: Trophy, title: 'Live Markets', desc: 'Open/close markets with live rates, ticking countdowns and instant result declarations.' },
  { icon: Wallet, title: 'UPI Wallet', desc: 'Add points by scanning the business QR — credits reflect 1:1, withdraw anytime.' },
  { icon: Gamepad2, title: 'All Games Built In', desc: 'Single, Jodi, Single/Double/Triple Pana, Sangam, starline hourly games and more.' },
  { icon: Languages, title: 'Your Language', desc: 'English, Hindi, Gujarati and Marathi — pick during first login or change anytime.' },
]

const STEPS = [
  { n: '1', title: 'Download & Install', desc: 'Tap the Download button, open the APK file on your phone and tap Install (allow "Install from this source" when Android asks).' },
  { n: '2', title: 'Register Your Account', desc: 'Open the app and sign up with your name, 10-digit mobile number and a password. New accounts go to the operator for a quick approval.' },
  { n: '3', title: 'Pick Your Language', desc: 'Right after approval, choose English, हिंदी, ગુજરાતી or मराठी — the whole app switches instantly.' },
  { n: '4', title: 'Add Points (UPI)', desc: 'Tap ADD POINTS on Home, scan the business QR or copy the UPI ID, pay via any UPI app, then submit the amount + UTR. The operator approves it and your wallet updates.' },
  { n: '5', title: 'Play & Withdraw', desc: 'Open a market, pick a game, tap numbers, enter points and confirm. Wins are credited automatically. Withdraw extra points anytime — money comes back to your account.' },
]

// Screenshot gallery — real captures of the app (390×844 phone frames)
type Shot = { f: string; t: string; d: string }
const GROUPS: Array<{ id: string; icon: typeof Crown; title: string; blurb: string; shots: Shot[] }> = [
  {
    id: 'start',
    icon: Users,
    title: 'Getting Started — Login, Register & Language',
    blurb: 'New customers are up and running in under two minutes. Registration asks only for a name, mobile number and password — the operator approves the account, you pick a language, and you are in. Your login stays valid on this phone, so the next time you open the app you land straight on the home screen.',
    shots: [
      { f: '01-login', t: 'Login', d: 'Enter your mobile number and password — or switch language before logging in.' },
      { f: '02-register', t: 'Register', d: 'Sign up in seconds. Add an agent code if your agent gave you one.' },
      { f: '19-await-approval', t: 'Waiting for approval', d: 'The operator approves new accounts — this screen clears automatically.' },
      { f: '03-lang-ask', t: 'Choose language', d: 'English, हिंदी, ગુજરાતી or मराठी — changeable anytime from Profile.' },
    ],
  },
  {
    id: 'play',
    icon: Gamepad2,
    title: 'Home & Playing — Markets, Games & Bids',
    blurb: 'The home screen shows every market with live OPEN/CLOSE times, a running status bar and a ticking countdown, so you always know exactly when betting closes. Open a market to see all games with their rates — tap numbers (or paste a WhatsApp list), enter points per selection and confirm the slip. Every game works the same way: pick, enter points, confirm.',
    shots: [
      { f: '04-home', t: 'Home', d: 'Wallet, banners, notice and every market with live status and countdown.' },
      { f: '05-play-single', t: 'Play screen', d: 'Game tabs with rates, session picker and live time-left to bet.' },
      { f: '06-play-jodi', t: 'Pick numbers', d: 'Tap any numbers — Jodi, Pana, Sangam — and enter points on each.' },
      { f: '07-slip-confirm', t: 'Confirm slip', d: 'Review your bids and total, then confirm — the wallet debits instantly.' },
    ],
  },
  {
    id: 'results',
    icon: Trophy,
    title: 'Results & Charts — Never Miss a Declaration',
    blurb: 'Every declared result appears in the app the moment the operator publishes it — and a notification is pushed to your phone. The Results tab lists recent declarations per market, the Jodi and Panel charts show the full month history with repeating-number highlighting, and the Starline board tracks all 24 hourly games through the day.',
    shots: [
      { f: '10-results', t: 'Results', d: 'Latest declared results per market, newest first.' },
      { f: '11-jodi-chart', t: 'Jodi chart', d: 'Full month grid with red highlights on repeating jodis.' },
      { f: '12-panel-chart', t: 'Panel chart', d: 'Open–close panel rows for the selected market.' },
      { f: '13-starline-board', t: 'Starline board', d: 'All 24 hourly games — declared hours highlighted live.' },
      { f: '08-starline', t: 'Starline play', d: 'Bet on the running hourly game, single-digit grid with rates.' },
    ],
  },
  {
    id: 'wallet',
    icon: Wallet,
    title: 'Wallet — Add Points, Withdraw & History',
    blurb: 'Your wallet is points: 1 point = ₹1. Add points by paying the business QR through any UPI app and submitting the UTR — the operator approves and your balance updates with a full audit trail. Withdrawals put the amount on hold until the operator pays it out, and every transaction (bids, wins, deposits, withdrawals) is listed with a running balance.',
    shots: [
      { f: '15-wallet', t: 'Wallet', d: 'Balance, pending requests and the full transaction history.' },
      { f: '17-deposit-modal', t: 'Add points', d: 'Scan the business QR, pay in any UPI app, submit amount + UTR.' },
      { f: '16-withdraw-modal', t: 'Withdraw', d: 'Request a payout — the amount is held until it is paid to you.' },
      { f: '18-notifications', t: 'Notifications', d: 'Approvals, payouts, wins and results — all in one place.' },
    ],
  },
  {
    id: 'account',
    icon: Bell,
    title: 'My Bids & Profile',
    blurb: 'My Bids keeps every bet you have placed with live status — pending bids settle automatically the second results are declared, so winners never have to ask. The profile screen shows your account status, lets you switch language, change your password and jump to any section of the app.',
    shots: [
      { f: '09-mybids', t: 'My Bids', d: 'All / pending / won / lost filters with live settlement.' },
      { f: '14-profile', t: 'Profile', d: 'Account status, language switch, password change and quick links.' },
    ],
  },
]

function ShotCard({ s }: { s: Shot }) {
  return (
    <figure className="flex flex-col items-center">
      <div className="w-[186px] rounded-[26px] border-[5px] border-[#1E2637] bg-[#1E2637] shadow-[0_18px_50px_rgba(0,0,0,0.55)] overflow-hidden relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-4 bg-[#1E2637] rounded-b-xl z-10" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={`/how-it-works/${s.f}.png`} alt={s.t} width={390} height={844} loading="lazy"
          className="w-full h-auto block" />
      </div>
      <figcaption className="mt-3 text-center max-w-[200px]">
        <div className="text-[13px] font-bold text-white">{s.t}</div>
        <p className="text-[11.5px] text-[rgba(255,255,255,0.5)] leading-snug mt-0.5">{s.d}</p>
      </figcaption>
    </figure>
  )
}

export default function LandingPage() {
  const adminHref = '/g/' + adminGateToken()

  return (
    <div className="min-h-screen flex flex-col bg-[#0B0F1A] text-white">
      {/* ambient gold glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[720px] h-[520px] rounded-full blur-3xl bg-[radial-gradient(closest-side,rgba(245,196,81,0.14),transparent)]" />
        <div className="absolute bottom-0 right-0 w-[420px] h-[420px] rounded-full blur-3xl bg-[radial-gradient(closest-side,rgba(245,196,81,0.07),transparent)]" />
      </div>

      {/* ── NAV ── */}
      <nav className="relative z-10 max-w-5xl mx-auto w-full px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-[10px] bg-gradient-to-br from-[#F5C451] to-[#C89212] flex items-center justify-center shadow-[0_4px_16px_rgba(245,196,81,0.35)]">
            <Crown size={18} className="text-[#1A1305]" />
          </div>
          <div className="text-[15px] font-bold tracking-wide">Satta Matka God</div>
        </div>
        <div className="flex items-center gap-2">
          <a href="#guide" className="text-[13px] font-semibold text-[rgba(255,255,255,0.75)] px-4 py-1.5 rounded-lg hover:bg-[rgba(255,255,255,0.06)] transition-colors">
            How it works
          </a>
          <a href="#download" className="text-[13px] font-semibold text-[#F5C451] border border-[rgba(245,196,81,0.35)] px-4 py-1.5 rounded-lg hover:bg-[rgba(245,196,81,0.1)] transition-colors">
            Get the App
          </a>
        </div>
      </nav>

      {/* ── HERO / DOWNLOAD ── */}
      <section id="download" className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-6 py-16">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[rgba(245,196,81,0.1)] border border-[rgba(245,196,81,0.3)] text-[#F5C451] text-[12px] font-semibold mb-7">
          <Crown size={13} /> Official Android App
        </div>
        <h1 className="text-[42px] md:text-[64px] font-black leading-[1.05] tracking-tight mb-4">
          Satta Matka <span className="bg-gradient-to-r from-[#F5C451] to-[#E8A820] bg-clip-text text-transparent">God</span>
        </h1>
        <p className="text-[15px] md:text-[17px] text-[rgba(255,255,255,0.6)] max-w-xl mx-auto mb-10 leading-relaxed">
          All your markets, games and wallet in one app. Download, install, register and play in under two minutes — the full guide with screenshots is below.
        </p>

        <DownloadCta />

        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 mt-9 text-[12.5px] text-[rgba(255,255,255,0.5)]">
          <span className="flex items-center gap-1.5"><Check size={13} className="text-[#F5C451]" /> Official operator app</span>
          <span className="flex items-center gap-1.5"><Check size={13} className="text-[#F5C451]" /> Connects to the live server</span>
          <span className="flex items-center gap-1.5"><Check size={13} className="text-[#F5C451]" /> Free to install</span>
        </div>
      </section>

      {/* ── HIGHLIGHTS ── */}
      <section className="relative z-10 border-t border-[rgba(255,255,255,0.07)] py-12 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {HIGHLIGHTS.map(f => (
            <div key={f.title} className="rounded-2xl p-5 bg-[rgba(255,255,255,0.035)] border border-[rgba(255,255,255,0.07)]">
              <f.icon size={20} className="text-[#F5C451] mb-3" />
              <h3 className="text-[14px] font-bold mb-1">{f.title}</h3>
              <p className="text-[12px] text-[rgba(255,255,255,0.5)] leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── HOW THE APP WORKS — 5 STEPS ── */}
      <section id="guide" className="relative z-10 py-12 px-6 border-t border-[rgba(255,255,255,0.07)]">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-[24px] md:text-[30px] font-black text-center">How the App Works — <span className="text-[#F5C451]">5 Easy Steps</span></h2>
          <p className="text-[13.5px] text-[rgba(255,255,255,0.55)] text-center max-w-xl mx-auto mt-3 mb-9 leading-relaxed">
            Everything happens inside one app: you register, the operator approves you, you add points through UPI, play the markets and withdraw your winnings. Here is the complete journey from install to payout.
          </p>
          <div className="space-y-3">
            {STEPS.map(s => (
              <div key={s.n} className="flex gap-4 items-start rounded-2xl p-4 bg-[rgba(255,255,255,0.035)] border border-[rgba(255,255,255,0.07)]">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5C451] to-[#C89212] text-[#1A1305] font-black text-[14px] flex items-center justify-center shrink-0">{s.n}</div>
                <div>
                  <div className="text-[14px] font-bold">{s.title}</div>
                  <p className="text-[12.5px] text-[rgba(255,255,255,0.5)] leading-relaxed mt-0.5">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SCREENSHOT GUIDE — every screen ── */}
      <section className="relative z-10 py-14 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-4">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[rgba(245,196,81,0.1)] border border-[rgba(245,196,81,0.3)] text-[#F5C451] text-[12px] font-semibold">
              <Smartphone size={13} /> Every screen, shown
            </span>
          </div>
          <h2 className="text-[24px] md:text-[30px] font-black text-center mb-4">Complete Screenshot Guide</h2>
          <p className="text-[13.5px] text-[rgba(255,255,255,0.55)] text-center max-w-2xl mx-auto mb-12 leading-relaxed">
            These are real captures of the app — exactly what you will see on your phone. Scroll through each section below to see how login, playing, results, the wallet and your account work before you even install.
          </p>

          {GROUPS.map((g, gi) => (
            <div key={g.id} className={gi > 0 ? 'mt-14' : ''}>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-[rgba(245,196,81,0.1)] border border-[rgba(245,196,81,0.25)] flex items-center justify-center shrink-0">
                  <g.icon size={19} className="text-[#F5C451]" />
                </div>
                <h3 className="text-[18px] md:text-[21px] font-black">{g.title}</h3>
              </div>
              <p className="text-[13px] text-[rgba(255,255,255,0.55)] leading-relaxed max-w-3xl mb-7">{g.blurb}</p>
              <div className="flex flex-wrap justify-center md:justify-start gap-x-5 gap-y-8">
                {g.shots.map(s => <ShotCard key={s.f} s={s} />)}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── INSTALL HELP ── */}
      <section className="relative z-10 py-12 px-6 border-t border-[rgba(255,255,255,0.07)]">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-[22px] md:text-[26px] font-black text-center mb-8">Installation Help</h2>
          <div className="space-y-3">
            <div className="flex gap-4 items-start rounded-2xl p-4 bg-[rgba(255,255,255,0.035)] border border-[rgba(255,255,255,0.07)]">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5C451] to-[#C89212] text-[#1A1305] flex items-center justify-center shrink-0"><Shield size={17} /></div>
              <div>
                <div className="text-[14px] font-bold">Play Protect / unknown source</div>
                <p className="text-[12.5px] text-[rgba(255,255,255,0.5)] leading-relaxed mt-0.5">This is a direct APK, not a Play Store app. If Android warns about unknown sources, tap <em>Install anyway</em> — the app comes from your operator and connects only to the official server.</p>
              </div>
            </div>
            <div className="flex gap-4 items-start rounded-2xl p-4 bg-[rgba(255,255,255,0.035)] border border-[rgba(255,255,255,0.07)]">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5C451] to-[#C89212] text-[#1A1305] flex items-center justify-center shrink-0"><Zap size={17} /></div>
              <div>
                <div className="text-[14px] font-bold">Removed the app before?</div>
                <p className="text-[12.5px] text-[rgba(255,255,255,0.5)] leading-relaxed mt-0.5">Download the latest APK above and install over it — your account, wallet and history stay intact. Nothing needs to be re-registered.</p>
              </div>
            </div>
            <div className="flex gap-4 items-start rounded-2xl p-4 bg-[rgba(255,255,255,0.035)] border border-[rgba(255,255,255,0.07)]">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5C451] to-[#C89212] text-[#1A1305] flex items-center justify-center shrink-0"><Bell size={17} /></div>
              <div>
                <div className="text-[14px] font-bold">Allow notifications</div>
                <p className="text-[12.5px] text-[rgba(255,255,255,0.5)] leading-relaxed mt-0.5">When the app asks for notification permission on first launch, tap Allow — that is how deposit approvals, withdrawals, wins and result declarations reach you instantly.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="relative z-10 border-t border-[rgba(255,255,255,0.07)] py-7 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-[#F5C451] to-[#C89212] flex items-center justify-center">
              <Crown size={12} className="text-[#1A1305]" />
            </div>
            <span className="text-[12px] text-[rgba(255,255,255,0.4)]">© 2026 Satta Matka God · All rights reserved</span>
          </div>
          {/* The ONE encrypted super-admin entry — deliberately discreet */}
          <a
            href={adminHref}
            aria-label="Admin"
            title="Admin"
            className="text-[12px] text-[rgba(255,255,255,0.22)] hover:text-[rgba(255,255,255,0.5)] transition-colors"
          >
            ·
          </a>
        </div>
      </footer>
    </div>
  )
}
