import type { PageName } from '@/lib/store'
import { canAccessPage, type UiRole } from '@/lib/access-control'
import {
  LayoutDashboard, Plus, List, Layers,
  UserCircle, Settings,
  Shield, MapPin, Activity, Lock, AlertTriangle, BarChart3, UserPlus, Timer,
  Trophy, CreditCard, Wallet, Crown, Smartphone, FileImage, Percent, Bell,
  Gauge, MessagesSquare, FileText, ClipboardCheck, GraduationCap, Users, Megaphone, Package,
} from 'lucide-react'

// ────────────────────────────────────────
// NAV ITEMS (derived from the ONE access-control matrix)
//
// There is exactly ONE catalog below. The three per-role arrays are FILTERED
// through src/lib/access-control.ts (PAGE_ACCESS) — the same matrix the page
// renderer and the API guards use, so sidebar, rendering and backend can
// never drift apart.
//
// Sidebar information architecture:
//   1. Dashboard
//   2. Entry            → Smart Entry / Chitthi / New Entry / Entry List / App Bids
//   3. WhatsApp         → Dashboard / Messages / Templates / Approvals / Learning / Mappings
//   4. Control          → Admin List / Agent List
//   5. User Management  → System Users / Customer List / Locked Users / Pending Users
//   6. Market Management→ Markets / Starlines / Results / Charts / Games / Permissions
//   7. App Wallet       → Payment Management / Agent Commission
//   8. System Management→ User Activity / Parser Exceptions / Parser Configurations / Chart Revision
//   9. Subscriptions    → Plan / User Subscriptions / Payment
//   (+ Log Out in the Account footer)
//
// Note: the former "Hisab" section (New Hisab / Hisab Records / Customer
// Hisab) was REMOVED by operator decision — settlement happens at the
// customer/agent level. The old single WhatsApp Inbox tab became this
// dedicated WhatsApp panel.
// ────────────────────────────────────────

type NavItem = {
  id: PageName
  label: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  icon: any
  badge?: boolean
  /** Per-role label overrides (e.g. "Agent Commission" → agent sees "My Commission"). */
  labels?: Partial<Record<UiRole, string>>
}
type NavSectionDef = { section: string; /** Per-role section header overrides. */ sectionLabels?: Partial<Record<UiRole, string>>; items: NavItem[] }

const NAV_CATALOG: NavSectionDef[] = [
  { section: 'Dashboard', items: [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  ]},
  { section: 'Entry', items: [
    { id: 'unified-entry', label: 'Smart Entry', icon: Layers },
    { id: 'chitthi', label: 'Chitthi Generator', icon: FileImage },
    { id: 'inv-new', label: 'New Entry', icon: Plus },
    { id: 'inv-list', label: 'Entry List', icon: List, badge: true },
    { id: 'app-bids', label: 'App Bids', icon: Smartphone },
  ]},
  { section: 'WhatsApp', items: [
    { id: 'wa-dashboard', label: 'WhatsApp Dashboard', icon: Gauge },
    { id: 'wa-messages', label: 'Messages', icon: MessagesSquare },
    { id: 'wa-templates', label: 'Templates', icon: FileText },
    { id: 'wa-approvals', label: 'Approvals', icon: ClipboardCheck },
    { id: 'wa-learning', label: 'Bot Learning', icon: GraduationCap },
    { id: 'wa-mappings', label: 'Customer/Group Mapping', icon: Users },
  ]},
  { section: 'Control', items: [
    { id: 'hierarchy-managers', label: 'Admin List', icon: Crown },
    { id: 'hierarchy-agents', label: 'Agent List', icon: Shield },
  ]},
  { section: 'User Management', items: [
    { id: 'sys-mgmt-users', label: 'System Users', icon: Shield },
    { id: 'vendor', label: 'Customer List', icon: UserCircle },
    { id: 'sys-mgmt-locked', label: 'Locked Users', icon: Lock },
    { id: 'sys-mgmt-pending', label: 'Pending Users', icon: UserPlus },
  ]},
  { section: 'Market Management', items: [
    { id: 'configure', label: 'Markets', icon: Settings },
    { id: 'starlines', label: 'Starlines', icon: Timer },
    { id: 'market-results', label: 'Market Results', icon: Trophy },
    { id: 'chart-data', label: 'Jodi & Panel Chart Data', icon: BarChart3 },
    { id: 'game-management', label: 'Game Management', icon: Layers },
    { id: 'game-allocation', label: 'Game Allocation', icon: MapPin },
    { id: 'sys-mgmt-markets', label: 'Market Permissions', icon: MapPin },
  ]},
  { section: 'App Wallet', sectionLabels: { user: 'Commission' }, items: [
    { id: 'app-funds', label: 'Payment Management', icon: Wallet },
    { id: 'agent-commission', label: 'Agent Commission', icon: Percent, labels: { user: 'My Commission' } },
    { id: 'app-notify', label: 'App Notifications', icon: Bell },
    { id: 'app-content', label: 'App Content', icon: Megaphone },
    { id: 'app-build', label: 'App Build (APK)', icon: Package },
  ]},
  { section: 'System Management', items: [
    { id: 'sys-mgmt-activity', label: 'User Activity', icon: Activity },
    { id: 'sys-mgmt-parser-ex', label: 'Parser Exceptions', icon: AlertTriangle },
    { id: 'sys-mgmt-parser-cfg', label: 'Parser Configurations', icon: Settings },
    { id: 'sys-mgmt-chart-revs', label: 'Chart Revision', icon: BarChart3 },
  ]},
  { section: 'Subscriptions', items: [
    { id: 'sub-plans', label: 'Plan', icon: CreditCard },
    { id: 'sub-users', label: 'User Subscriptions', icon: Crown, labels: { user: 'My Subscription' } },
    { id: 'sub-payments', label: 'Payment', icon: Wallet },
  ]},
]

/** Build the sidebar for one role from the single catalog. */
function buildNav(role: UiRole) {
  return NAV_CATALOG
    .map(sec => ({
      section: sec.sectionLabels?.[role] ?? sec.section,
      items: sec.items
        .filter(it => canAccessPage(role, it.id))
        .map(it => ({ id: it.id, label: it.labels?.[role] ?? it.label, icon: it.icon, ...(it.badge ? { badge: true } : {}) })),
    }))
    .filter(sec => sec.items.length > 0)
}

export const NAV_ITEMS_MASTER = buildNav('super')
export const NAV_ITEMS_MANAGER = buildNav('manager')
export const NAV_ITEMS_USER = buildNav('user')

// ────────────────────────────────────────
// PAGE TITLES (Topbar breadcrumb + mobile top bar)
// ────────────────────────────────────────

export const PAGE_TITLES: Record<PageName, string> = {
  dashboard: 'Dashboard',
  'inv-new': 'New Entry',
  'inv-list': 'Entry List',
  'card-view': 'View Card',
  'unified-entry': 'Smart Entry',
  vendor: 'Customer List',
  configure: 'Markets',
  users: 'User Management',
  // Phase 2: System Management
  'sys-mgmt-users': 'System Users',
  'sys-mgmt-markets': 'Market Permissions',
  'sys-mgmt-activity': 'User Activity',
  'sys-mgmt-locked': 'Locked Users',
  'sys-mgmt-parser-ex': 'Parser Exceptions',
  'sys-mgmt-parser-cfg': 'Parser Configurations',
  'sys-mgmt-chart-revs': 'Chart Revision',
  'sys-mgmt-pending': 'Pending Users',
  // Subscription & Payments
  'sub-plans': 'Plan',
  'sub-users': 'User Subscriptions',
  'sub-payments': 'Payment',
  paywall: 'Subscription Required',
  // Website
  'landing-config': 'Landing Page',
  // Hierarchy
  'hierarchy-managers': 'Admin List',
  'hierarchy-agents': 'Agent List',
  'hierarchy-customers': 'Customer List',
  login: 'Login',
  // Customer App management
  'app-customers': 'App Customers',
  'app-bids': 'App Bids',
  'app-funds': 'Payment Management',
  'market-results': 'Market Results',
  'game-management': 'Game Management',
  'game-allocation': 'Game Allocation',
  starlines: 'Starlines',
  'chart-data': 'Jodi & Panel Chart Data',
  // Expansion: Chitthi + WhatsApp Management panel
  chitthi: 'Chitthi Generator',
  'wa-dashboard': 'WhatsApp Dashboard',
  'wa-messages': 'WhatsApp Messages',
  'wa-templates': 'WhatsApp Templates',
  'wa-approvals': 'WhatsApp Approvals',
  'wa-learning': 'WhatsApp Bot Learning',
  'wa-mappings': 'WhatsApp Customer/Group Mapping',
  // Expansion: agent commission
  'agent-commission': 'Agent Commission',
  // Native app notifications
  'app-notify': 'App Notifications',
  'app-content': 'App Content',
  'app-build': 'App Build (APK)',
}
