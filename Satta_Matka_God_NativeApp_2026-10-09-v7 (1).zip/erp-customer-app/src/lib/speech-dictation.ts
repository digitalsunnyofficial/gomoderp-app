// ────────────────────────────────────────────────────────────────────────────
// speech-dictation.ts — Spoken-text → ERP entry format engine (pure logic)
// ────────────────────────────────────────────────────────────────────────────
// POWERS THE GBOARD DICTATION FLOW:
//   A web page cannot invoke Gboard's speech engine directly (no browser API
//   exists for it), but Gboard voice typing TYPES its transcript into the
//   focused textarea like a keyboard. So the ERP uses Gboard as the
//   recognition engine and THIS module as the conversion layer:
//
//     user speaks via Gboard mic → raw words land in the textarea
//       "three seven zero barabar thirty rs two seven zero barabar twenty"
//     → converted automatically (Format button / on-blur) →
//       "370=30rs
//        270=20rs"
//
// RULES (per ERP requirements):
//   • ONLY digits 0-9 are recognized — every other spoken word is dropped
//   • Comma auto-placed after every N anks (N = groupSize):
//       single → 1 ("1,5,9") | double → 2 ("23,42,72") | triple → 3 ("123,432,879")
//       group  → null (no grouping; seeds are variable length)
//   • "equals" / "barabar" / "बराबर" places "="
//   • After "=", spoken digits are the amount and "rs" is appended automatically
//   • MULTI-ENTRY: saying "rs" / "rupees" / "रुपये" FINISHES the current entry;
//     the next spoken number starts a new entry on a new line. A second
//     "equals" (or a glued digit run like "270") after a completed amount also
//     starts a new entry — so one continuous dictation can carry many entries.
//   • Idempotent: already-formatted lines (digits , = rs ₹ . *) are never
//     touched, so Format can be pressed any number of times and manual/pasted
//     content is always safe.
// Output matches the format the existing WhatsApp parsers already accept,
// so NO parser/calculation changes are needed anywhere.
// Pure module — no React, no browser APIs — fully unit-testable.
// ────────────────────────────────────────────────────────────────────────────

// ── Devanagari numerals (Gboard Hindi often emits ०-९ instead of 0-9) ──────
const DEV_TO_ASCII: Record<string, string> = {
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
}
export function transliterateDevanagariDigits(s: string): string {
  return s.replace(/[०-९]/g, ch => DEV_TO_ASCII[ch] ?? ch)
}

// ── Digit word dictionaries (English + Hindi romanized + Devanagari) ───────
// Maps a spoken word (as transcribed) to a single digit 0-9.
const DIGIT_WORDS: Record<string, string> = {
  // English (unambiguous spellings only — homophones like to/for/oh are
  // deliberately excluded so ordinary English chatter is never digitized)
  zero: '0', one: '1', two: '2', three: '3', four: '4', five: '5',
  six: '6', seven: '7', eight: '8', nine: '9',
  // Hindi romanized (Hinglish) — what en-IN sessions often emit
  sunna: '0', sunnna: '0', shunya: '0', shoon: '0', sifar: '0', ziphar: '0',
  ek: '1', ekh: '1',
  do: '2',
  teen: '3', tin: '3', tinn: '3',
  char: '4', chaar: '4', chaari: '4',
  panch: '5', paanch: '5', panchh: '5',
  chhah: '6', chhahh: '6', chhe: '6', chah: '6', chha: '6',
  saat: '7', sat: '7',
  aath: '8', ath: '8',
  nau: '9', nao: '9',
  // Devanagari (what hi-IN sessions emit)
  'शून्य': '0', 'सुन्ना': '0', 'सिफ़र': '0', 'सिफर': '0', 'जीरो': '0',
  'एक': '1', 'दो': '2', 'तीन': '3', 'तिन': '3',
  'चार': '4', 'चार्': '4',
  'पांच': '5', 'पाँच': '5', 'पंच': '5', 'पाच': '5',
  'छह': '6', 'छः': '6', 'छे': '6', 'छ:': '6',
  'सात': '7', 'सत': '7',
  'आठ': '8', 'अठ': '8',
  'नौ': '9', 'नो': '9',
}

// Words meaning "=" (amount follows)
const EQUALS_WORDS = new Set([
  'equals', 'equal', 'equls', 'equels', 'eqal', 'ikual',
  'barabar', 'barbr', 'brabar', 'barbar', 'barabara', 'barabarh', 'baraabar',
  'बराबर', 'बरबर', 'बराबर्',
])

// Words meaning the amount is done — they CLOSE the current entry
// ("rs" is appended automatically; the next number starts a new entry)
const AMOUNT_END_WORDS = new Set([
  'rs', 'rupees', 'rupee', 'rupaye', 'rupya', 'rups',
  'रुपया', 'रुपये', 'रूपया', 'रुपिया',
])

// ── Compound amount words (for "one thousand", "panch hazaar", "पंद्रह सौ") ─
const UNITS_W: Record<string, number> = {
  one: 1, ek: 1, 'एक': 1,
  two: 2, do: 2, 'दो': 2,
  three: 3, teen: 3, 'तीन': 3,
  four: 4, char: 4, chaar: 4, 'चार': 4,
  five: 5, panch: 5, paanch: 5, 'पांच': 5, 'पाँच': 5,
  six: 6, chhah: 6, chhe: 6, 'छह': 6, 'छः': 6,
  seven: 7, saat: 7, 'सात': 7,
  eight: 8, aath: 8, 'आठ': 8,
  nine: 9, nau: 9, 'नौ': 9,
}
const TEENS_W: Record<string, number> = {
  ten: 10, dus: 10, das: 10, 'दस': 10,
  eleven: 11, gyarah: 11, 'ग्यारह': 11,
  twelve: 12, barah: 12, 'बारह': 12,
  thirteen: 13, terah: 13, 'तेरह': 13,
  fourteen: 14, chaudah: 14, chauda: 14, 'चौदह': 14,
  fifteen: 15, pandrah: 15, pandara: 15, 'पंद्रह': 15, 'पन्द्रह': 15,
  sixteen: 16, solah: 16, sola: 16, 'सोलह': 16,
  seventeen: 17, satrah: 17, 'सत्रह': 17,
  eighteen: 18, atharah: 18, athara: 18, 'अठारह': 18,
  nineteen: 19, unnees: 19, unnis: 19, 'उन्नीस': 19,
}
const TENS_W: Record<string, number> = {
  twenty: 20, bees: 20, bis: 20, 'बीस': 20,
  thirty: 30, tees: 30, tis: 30, 'तीस': 30,
  forty: 40, chalis: 40, chaalis: 40, 'चालीस': 40,
  fifty: 50, pachas: 50, pachaas: 50, 'पचास': 50,
  sixty: 60, saath: 60, sath: 60, 'साठ': 60,
  seventy: 70, sattar: 70, 'सत्तर': 70,
  eighty: 80, assi: 80, 'अस्सी': 80,
  ninety: 90, nabbe: 90, 'नब्बे': 90,
  // Hindi thirties/forties/fifties variants commonly transcribed
  paintis: 35, 'पैंतीस': 35,
  chauce: 34, 'चौंतीस': 34,
  chhattis: 36, 'छत्तीस': 36,
  paintalis: 45, pintalis: 45, 'पैंतालीस': 45,
  ektalis: 41, 'इकतालीस': 41,
  bayalis: 42, 'बयालीस': 42,
  tialis: 43, tetalis: 43, 'तियालीस': 43,
  unchas: 49, 'उनचास': 49,
  pachhattar: 75, 'पचहत्तर': 75,
  unyassi: 79, ekassi: 81, tirassi: 83, chaurassi: 84,
}

// Parse a small number (0-99) starting at tokens[i].
// Handles: unit | teen | tens | tens+unit (e.g. "twenty five")
function parseSmall(tokens: string[], i: number): { value: number; len: number } | null {
  const t = tokens[i]
  if (t === undefined) return null
  if (DIGIT_WORDS[t] !== undefined) {
    return { value: parseInt(DIGIT_WORDS[t], 10), len: 1 }
  }
  if (TEENS_W[t] !== undefined) return { value: TEENS_W[t], len: 1 }
  if (TENS_W[t] !== undefined) {
    const v = TENS_W[t]
    // "twenty five" → 25 (tens + unit, English style)
    const nxt = tokens[i + 1]
    if (nxt !== undefined && UNITS_W[nxt] !== undefined) {
      return { value: v + UNITS_W[nxt], len: 2 }
    }
    return { value: v, len: 1 }
  }
  return null
}

const SCALES_W: Record<string, number> = {
  hundred: 100, sau: 100, 'सौ': 100, 'सो': 100,
  thousand: 1000, hazaar: 1000, hazar: 1000, hezar: 1000, hajara: 1000,
  'हज़ार': 1000, 'हजार': 1000,
  lakh: 100000, lakhs: 100000, 'लाख': 100000,
  crore: 10000000, karod: 10000000, 'करोड़': 10000000, 'करोड': 10000000,
  million: 1000000,
}

// Parse a full number phrase starting at tokens[i].
// Grammar: a phrase is EITHER a single plain small number (1-99), a run of
// scaled segments, OR a bare scale followed by smalls:
//   "one thousand five hundred"  → [1000, 500]        → 1500
//   "do hazaar pachas"           → [2000, 50]         → 2050 (natural Hindi)
//   "hundred twenty three"       → [100, 23]          → 123  (bare scale start)
//   "hazaar pachas"              → [1000, 50]         → 1050
// Consecutive plain units ("ek do teen") do NOT chain — each stays a digit.
function parseNumberPhrase(tokens: string[], i: number): { value: number; len: number } | null {
  const segments: number[] = []
  let idx = i
  let scaled = false
  while (idx < tokens.length) {
    let small = parseSmall(tokens, idx)
    // Bare scale word starting a phrase ("hundred twenty three", "hazaar pachas")
    if (!small && segments.length === 0 && !scaled && SCALES_W[tokens[idx]] !== undefined) {
      segments.push(SCALES_W[tokens[idx]])
      idx++
      scaled = true
      continue
    }
    if (!small) break
    const after = idx + small.len
    const nextTok = tokens[after]
    if (nextTok !== undefined && SCALES_W[nextTok] !== undefined) {
      segments.push(small.value * SCALES_W[nextTok])
      idx = after + 1
      scaled = true
      continue // another scaled segment may follow ("one thousand five hundred")
    }
    if (!scaled) {
      // single plain small number (1-99) — the whole phrase
      return { value: small.value, len: small.len }
    }
    // ONE trailing plain small after scaled segments sums in ("2050")
    segments.push(small.value)
    idx = after
    break
  }
  if (segments.length === 0) return null
  return { value: segments.reduce((a, b) => a + b, 0), len: idx - i }
}

// Group an ank digit run with commas every `size` digits (size<=0 → no grouping)
function groupAnks(digits: string, size: number | null): string {
  if (!size || size <= 0 || digits.length <= size) return digits
  const parts: string[] = []
  for (let i = 0; i < digits.length; i += size) parts.push(digits.slice(i, i + size))
  return parts.join(',')
}

// Tokenize a transcript the same way buildDictationText does (for heuristics)
function tokenizeLikeEngine(text: string): string[] {
  return transliterateDevanagariDigits(text)
    .toLowerCase()
    .replace(/[.,!?;:"'`()\[\]{}\-–—₹]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
}

// Every word the engine understands (any position) — used to detect speech
const ALL_SPEECH_WORDS: Set<string> = (() => {
  const s = new Set<string>()
  for (const m of [DIGIT_WORDS, TEENS_W, TENS_W, UNITS_W, SCALES_W]) {
    for (const k of Object.keys(m)) s.add(k)
  }
  for (const k of EQUALS_WORDS) s.add(k)
  for (const k of AMOUNT_END_WORDS) s.add(k)
  return s
})()

// Does this line look like dictation (Gboard voice output) rather than a
// typed/pasted entry? Conservative by design — a line is only "spoken" when:
//   • it has ≥2 single digits separated by spaces ("1 2 3 4 3 2 8 7 9 = 500"),
//     which no manual entry format ever produces, OR
//   • it contains at least one word from the speech dictionaries
//     (en / Hinglish / Devanagari).
// Pure machine lines ("370=30₹", "23.42.72.", "13469", "1,5,9=1000rs",
// "41=1100, 23=800", "Milan", ".....=500rs") are NEVER considered spoken.
export function looksLikeSpokenLine(line: string): boolean {
  const t = transliterateDevanagariDigits(line.trim().toLowerCase())
  if (!t) return false
  // Gboard digit-only output: two or more spaced single digits
  const singles = t.match(/(?:^|\s)\d(?:\s|$)/g)
  if (singles && singles.length >= 2) return true
  // Machine-format check: after removing entry punctuation and "rs"/"₹"
  // markers, no letters remain → typed/pasted content → not speech
  const machine = t.replace(/₹/g, ' ').replace(/rs/g, ' ')
  if (!/[a-z\u0900-\u097F]/.test(machine)) return false
  // Speech-word check
  const tokens = tokenizeLikeEngine(t)
  return tokens.some(tok => ALL_SPEECH_WORDS.has(tok))
}

// Convert a raw speech transcript into the ERP entry format.
//   transcript: raw recognizer output (English/Hindi/Devanagari, words + digits)
//   groupSize:  digits per ank before a comma (1=single, 2=double, 3=triple, null=group)
// Returns e.g. "123,432,879=1000rs", "1,5,9=50rs" or "12489=50rs".
// Multi-entry: "370 barabar thirty rs two seven zero barabar twenty" →
//   "370=30rs\n270=20rs"  (say "rs" after each amount to finish the entry)
export function buildDictationText(transcript: string, groupSize: number | null): string {
  if (!transcript) return ''
  const rawTokens = transliterateDevanagariDigits(transcript)
    .toLowerCase()
    .replace(/[.,!?;:"'`()\[\]{}\-–—₹]/g, ' ')
    // glued "30rs" / "500rupees" → split so the terminator is its own token
    .replace(/(\d)\s*(rs|rupees|rupee|rupaye|rupya|rups)\b/g, '$1 $2')
    .replace(/=/g, ' = ') // keep "=" as its own token so it acts as the equals word
    .split(/\s+/)
    .filter(Boolean)

  const entries: string[] = []
  let cur = ''      // entry currently being built
  let anks = ''     // digit stream before "="
  let amount = ''   // digit stream after "="
  let eq = false

  const flushAnks = () => {
    if (anks) {
      cur += groupAnks(anks, groupSize)
      anks = ''
    }
  }

  // Seal the current entry (with its amount, if any) and start a new one
  const closeEntry = () => {
    if (eq && amount) cur += amount + 'rs'
    if (cur) entries.push(cur)
    anks = ''
    amount = ''
    eq = false
    cur = ''
  }

  let i = 0
  while (i < rawTokens.length) {
    const t = rawTokens[i]

    if (EQUALS_WORDS.has(t) || t === '=') {
      // "equals" after a completed amount ("…=30rs 456=…") → seal and start anew
      if (eq && amount) closeEntry()
      if (!eq) {
        flushAnks()
        cur += '='
        eq = true
      }
      i++
      continue
    }

    if (AMOUNT_END_WORDS.has(t)) {
      // "rs"/"rupees"/"रुपये" finishes the entry — the next number is a new one
      if (eq && amount) closeEntry()
      i++
      continue
    }

    // Compound number phrase first ("one thousand", "panch hazaar", "पंद्रह सौ")
    const phrase = parseNumberPhrase(rawTokens, i)
    if (phrase && phrase.len > 0) {
      const digits = String(phrase.value)
      if (eq) amount += digits
      else anks += digits
      i += phrase.len
      continue
    }

    if (DIGIT_WORDS[t] !== undefined) {
      const d = DIGIT_WORDS[t]
      if (eq) amount += d
      else anks += d
      i++
      continue
    }

    // Recognizer often emits digits directly ("123", "1,234") — keep the digits
    const digitRun = t.replace(/\D/g, '')
    if (digitRun) {
      // A glued digit run arriving after a completed amount starts a new entry
      // ("370=30 270=20" — user didn't say "rs" but clearly began the next seed)
      if (eq && amount) closeEntry()
      if (eq) amount += digitRun
      else anks += digitRun
    }
    // everything else is dropped — ONLY numbers are recognized
    i++
  }

  flushAnks()
  if (eq) cur += amount ? amount + 'rs' : ''
  if (cur) entries.push(cur)
  return entries.join('\n')
}

// ── Gboard flow: whole-textarea conversion ─────────────────────────────────
// Convert a block of textarea content LINE BY LINE:
//   • lines that look like dictation  → converted to entry format
//   • lines that look typed/pasted    → left byte-for-byte untouched
// Never merges or reorders user content — safe to press repeatedly.
export function formatDictationContent(raw: string, groupSize: number | null): string {
  if (!raw) return raw
  return raw
    .split('\n')
    .map(line => (looksLikeSpokenLine(line) ? buildDictationText(line, groupSize) : line))
    .join('\n')
}

// On-blur auto-convert: returns the converted block, or null when nothing in
// the content looks like dictation (caller keeps the original).
export function autoFormatDictation(raw: string, groupSize: number | null): string | null {
  if (!raw || !raw.trim()) return null
  const out = formatDictationContent(raw, groupSize)
  return out === raw ? null : out
}
