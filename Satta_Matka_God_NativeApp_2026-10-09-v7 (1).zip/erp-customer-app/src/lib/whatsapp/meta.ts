// ────────────────────────────────────────────────────────────
// WhatsApp Cloud API (Meta) — thin client + configuration state.
//
// The system works in two modes:
//   • LIVE — WHATSAPP_TOKEN + WHATSAPP_PHONE_NUMBER_ID set in .env:
//       webhooks receive customer vyapar and replies are actually sent
//       through the Graph API.
//   • SANDBOX — credentials not set yet: the webhook still accepts and
//       processes messages, and the auto-reply is generated and stored
//       (status "sandbox") so the operator can test the whole flow from
//       the ERP WhatsApp Inbox without a Meta account.
//
// Required env vars for live mode:
//   WHATSAPP_VERIFY_TOKEN    — the value to enter in Meta's webhook config
//   WHATSAPP_TOKEN           — permanent access token with whatsapp_business_messaging
//   WHATSAPP_PHONE_NUMBER_ID — the business phone number id from Meta dashboard
//   WHATSAPP_APP_SECRET      — optional; enables X-Hub-Signature-256 verification
// ────────────────────────────────────────────────────────────

const GRAPH_VERSION = 'v21.0'

export interface WhatsAppConfig {
  token: string
  phoneNumberId: string
  verifyToken: string
  appSecret: string
  /** true when the system can actually SEND replies through Meta */
  live: boolean
}

export function waConfig(): WhatsAppConfig {
  const token = process.env.WHATSAPP_TOKEN || ''
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID || ''
  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN || 'matka-erp-verify'
  const appSecret = process.env.WHATSAPP_APP_SECRET || ''
  return { token, phoneNumberId, verifyToken, appSecret, live: Boolean(token && phoneNumberId) }
}

export interface SendResult {
  ok: boolean
  sandbox: boolean
  wamid?: string // Meta message id when really sent
  error?: string
}

/** Send a plain text message to a customer's WhatsApp number. */
export async function sendWhatsAppText(phone: string, body: string): Promise<SendResult> {
  const cfg = waConfig()
  if (!cfg.live) {
    return { ok: true, sandbox: true }
  }
  try {
    const res = await fetch(`https://graph.facebook.com/${GRAPH_VERSION}/${cfg.phoneNumberId}/messages`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${cfg.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: phone,
        type: 'text',
        text: { preview_url: false, body },
      }),
      signal: AbortSignal.timeout(15000),
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) {
      return { ok: false, sandbox: false, error: data?.error?.message || `Graph API ${res.status}` }
    }
    const wamid = data?.messages?.[0]?.id
    return { ok: true, sandbox: false, wamid }
  } catch (err) {
    return { ok: false, sandbox: false, error: err instanceof Error ? err.message : 'send failed' }
  }
}

/** Verify X-Hub-Signature-256 when WHATSAPP_APP_SECRET is configured. */
export async function verifyMetaSignature(rawBody: string, header: string | null): Promise<boolean> {
  const cfg = waConfig()
  if (!cfg.appSecret) return true // signature verification not enabled
  if (!header || !header.startsWith('sha256=')) return false
  const { createHmac } = await import('crypto')
  const expected = 'sha256=' + createHmac('sha256', cfg.appSecret).update(rawBody, 'utf8').digest('hex')
  return expected === header
}
