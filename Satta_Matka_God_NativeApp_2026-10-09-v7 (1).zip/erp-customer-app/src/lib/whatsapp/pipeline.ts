// ────────────────────────────────────────────────────────────
// WhatsApp input channel pipeline (v3 — intake + approval, per the
// operator's intake & approval spec; legacy auto mode preserved via
// AppConfig "whatsapp_approval" = off).
//
// A registered WhatsApp NUMBER is one customer; a registered WhatsApp
// GROUP ID is also one customer (WhatsAppGroupMapping — identity comes
// from the provider's immutable Group ID, never the group name). For
// group messages the actual sender/member is stored SEPARATELY from the
// group customer. Messages forwarded by the internal pickup team keep
// the original sender metadata (forwardedFrom).
//
// Every inbound message is permanently stored EXACTLY as received
// (provider message ID, sender, group ID, provider timestamp, original
// text, parser version) BEFORE anything else runs — the raw row is the
// immutable audit snapshot and the idempotency anchor (waMessageId).
//
// Flow: webhook → store raw → resolve customer/group → resolve market →
// parseUnifiedEntry (the ONE Smart Entry engine) → validate →
//   • approval mode ON (default): WhatsAppApproval(pending) — NO ERP
//     record yet. Admin Manager approves → transaction created → reply
//     sent only AFTER the transaction commits. Reject → audit intact.
//   • approval mode OFF (legacy auto): transaction + reply immediately.
//
// Invalid input (syntax/number/amount/unsupported/ambiguous) NEVER
// creates a transaction: it is rejected with a precise reason and kept
// for audit. Unknown patterns are captured as learning candidates
// (ParserLearningLog) — production parser rules NEVER change
// automatically; a reviewed rule is tested on history, then activated
// (ParserTerm) with a parser_version bump stored on every message.
// ────────────────────────────────────────────────────────────
import { db } from '@/lib/db'
import { parseUnifiedEntry, type UnifiedParseResult } from '@/lib/matka/entry-parser'
import { lookupTerm, type CustomTerm } from '@/lib/matka/term-registry'
import { sendWhatsAppText } from './meta'
import { PIPELINE_TEMPLATE_KEYS, resolvePipelineTemplate } from './templates'

export interface InboundInput {
  phone: string          // WhatsApp number (any format; normalized to digits) — for group chats this is the chat target
  profileName?: string   // WhatsApp push name when available
  text: string
  waMessageId?: string   // Meta wamid — enables idempotent processing
  // ── v3: group + forwarding metadata (kept verbatim on the raw row) ──
  groupId?: string       // provider Group ID (immutable) — registers the chat as ONE customer
  groupLabel?: string    // group display name when available (hint only, never identity)
  senderPhone?: string   // ACTUAL sender when different (group member / forwarding team member)
  senderName?: string    // actual sender's push name
  forwardedFrom?: string // original sender when our pickup team forwarded the message
  providerTimestamp?: string | number // provider's own timestamp (unix seconds)
}

export interface ProcessResult {
  ok: boolean
  status: 'processed' | 'rejected' | 'duplicate' | 'pending_approval'
  reply: string
  inboundId?: string
  outboundId?: string
  summary?: ParseSummary
  customerName?: string
  marketName?: string
  txNumber?: number
  approvalId?: string
  reason?: string
}

export interface BucketSummary { count: number; amount: number }
export interface ParseSummary {
  counts: {
    singles: BucketSummary
    doubles: BucketSummary
    triples: BucketSummary
    common: BucketSummary
    groups: Array<{ option: string; count: number; amount: number; invalid: number }>
  }
  total: number
  unknownLabels: string[]
  skipped: string[]
}

function digitsOf(s: string): string {
  return (s || '').replace(/\D/g, '')
}

// ── Parser version (learning library) ──
// AppConfig "parser_version" — bumped ONLY when a reviewed learning
// candidate is activated into a ParserTerm. Stored on every processed
// message + approval so historical transactions can always be
// reconstructed with the exact rule set in effect.
export const PARSER_VERSION_KEY = 'parser_version'

export async function getParserVersion(): Promise<number> {
  const row = await db.appConfig.findUnique({ where: { key: PARSER_VERSION_KEY } })
  const n = parseInt(row?.value || '1', 10)
  return Number.isFinite(n) && n >= 1 ? n : 1
}

export async function bumpParserVersion(): Promise<number> {
  const next = (await getParserVersion()) + 1
  await db.appConfig.upsert({
    where: { key: PARSER_VERSION_KEY },
    create: { key: PARSER_VERSION_KEY, value: String(next) },
    update: { value: String(next) },
  })
  return next
}

/** Parse the vyapar text with the rule set in effect right now. */
async function parseWithActiveRules(text: string): Promise<UnifiedParseResult> {
  const customTerms = await db.parserTerm.findMany({
    where: { isActive: true },
    select: { term: true, category: true },
  })
  return parseUnifiedEntry(text, 100, customTerms)
}

// ── Learning candidates (spec: unknown patterns are stored, never auto-applied) ──
function normalizeLearningKey(line: string): string {
  return line.toLowerCase().replace(/\d+/g, '#').replace(/[^a-z#]+/g, ' ').trim().slice(0, 120)
}

/**
 * Upsert unknown labels / skipped lines as ParserLearningLog candidates.
 * Never throws into the pipeline; never changes production parser rules.
 */
async function captureLearningCandidates(
  parse: UnifiedParseResult,
  marketName: string | undefined,
  messageId: string,
): Promise<void> {
  const candidates = [...parse.unknownLabels, ...parse.skipped]
    .map(s => (s || '').trim())
    .filter(Boolean)
  const seen = new Set<string>()
  for (const raw of candidates) {
    const key = normalizeLearningKey(raw)
    if (!key || seen.has(key)) continue
    seen.add(key)
    try {
      const existing = await db.parserLearningLog.findFirst({ where: { rawInput: raw } })
      if (existing) {
        await db.parserLearningLog.update({
          where: { id: existing.id },
          data: { sampleCount: { increment: 1 }, lastMessageId: messageId },
        })
      } else {
        await db.parserLearningLog.create({
          data: {
            rawInput: raw,
            context: marketName ? `whatsapp · ${marketName}` : 'whatsapp',
            source: 'whatsapp',
            firstMessageId: messageId,
            lastMessageId: messageId,
          },
        })
      }
    } catch (e) {
      console.error('[whatsapp] learning capture failed:', e)
    }
  }
}

function istDateDisplay(): string {
  const now = new Date(Date.now() + 5.5 * 3600 * 1000)
  return now.toISOString().slice(0, 10).split('-').reverse().join('/')
}

interface ResolvedCustomer {
  kind: 'app' | 'vendor'
  id: string
  name: string
  blocked: boolean
  agentUsername: string | null
  agentName: string | null
  /** group chat context when the message came from a registered group */
  viaGroupId?: string
  viaGroupLabel?: string | null
}

/**
 * Resolve a WhatsApp GROUP to its configured customer — identity is the
 * provider's immutable Group ID looked up in WhatsAppGroupMapping; the
 * group NAME is never used for identity.
 */
async function resolveGroupCustomer(groupId: string): Promise<ResolvedCustomer | null> {
  const mapping = await db.whatsAppGroupMapping.findUnique({ where: { groupId } })
  if (!mapping || !mapping.isActive) return null
  if (mapping.customerId) {
    const app = await db.appCustomer.findUnique({ where: { id: mapping.customerId } })
    if (app) {
      return {
        kind: 'app', id: app.id, name: app.name, blocked: app.status === 'blocked',
        agentUsername: app.agentUsername, agentName: app.agentName,
        viaGroupId: groupId, viaGroupLabel: mapping.groupLabel || null,
      }
    }
  }
  if (mapping.vendorId) {
    const vendor = await db.vendor.findUnique({ where: { id: mapping.vendorId } })
    if (vendor) {
      let agentUsername: string | null = vendor.createdBy || null
      let agentName: string | null = null
      if (agentUsername) {
        const agent = await db.user.findFirst({
          where: { username: agentUsername },
          select: { name: true, username: true },
        })
        agentName = agent?.name || agent?.username || agentUsername
      }
      return {
        kind: 'vendor', id: vendor.id, name: vendor.businessName, blocked: false,
        agentUsername, agentName, viaGroupId: groupId, viaGroupLabel: mapping.groupLabel || null,
      }
    }
  }
  return null
}

/** Resolve the WhatsApp number to a registered customer (with agent attribution). */
async function resolveCustomer(phone: string): Promise<ResolvedCustomer | null> {
  const digits = digitsOf(phone)
  const last10 = digits.slice(-10)
  const app = await db.appCustomer.findFirst({
    where: { OR: [{ mobile: digits }, ...(last10 ? [{ mobile: last10 }] : [])] },
  })
  if (app) {
    return {
      kind: 'app', id: app.id, name: app.name, blocked: app.status === 'blocked',
      agentUsername: app.agentUsername, agentName: app.agentName,
    }
  }
  const vendor = await db.vendor.findFirst({
    where: { OR: [{ mobileNo: digits }, ...(last10 ? [{ mobileNo: last10 }] : [])] },
  })
  if (vendor) {
    // ERP customers are filed under the agent who added them (Vendor.createdBy
    // = agent username) — the operator's "customer lists registered under agent".
    let agentUsername: string | null = vendor.createdBy || null
    let agentName: string | null = null
    if (agentUsername) {
      const agent = await db.user.findFirst({
        where: { username: agentUsername },
        select: { name: true, username: true },
      })
      agentName = agent?.name || agent?.username || agentUsername
    }
    return { kind: 'vendor', id: vendor.id, name: vendor.businessName, blocked: false, agentUsername, agentName }
  }
  return null
}

interface MarketHit { code: string; name: string; matchedLine: string }

/**
 * Find the market the customer is playing for.
 * Looks for a market name inside the message lines ("Milan open", a bare
 * "Kalyan" line, or "Market: Milan"). Longest name wins; when a base name
 * matches several phases (Sridevi day/night) the customer's latest bet
 * breaks the tie.
 */
async function resolveMarket(text: string, customerId: string | null): Promise<MarketHit | null> {
  const markets = await db.appMarket.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: 'asc' },
    select: { code: true, name: true, phase: true },
  })
  if (!markets.length) return null
  const lines = text.split(/[\n\r]+/).map(l => l.trim()).filter(Boolean)
  const lowerLines = lines.map(l => l.toLowerCase())

  let latestBetCode: string | null = null
  if (customerId) {
    const bet = await db.appBet.findFirst({
      where: { customerId },
      orderBy: { createdAt: 'desc' },
      select: { marketCode: true },
    })
    latestBetCode = bet?.marketCode ?? null
  }

  const hits: Array<MarketHit & { latest: boolean; phaseBoost: boolean }> = []
  markets.forEach(m => {
    const nameLower = m.name.toLowerCase().trim()
    if (!nameLower) return
    lowerLines.forEach((line, lineIdx) => {
      if (line.includes(nameLower)) {
        // "Milan day" / "Milan night" / "milan day open" keyword agreement
        const phaseBoost = m.phase === 'day'
          ? /\bday\b/i.test(lines[lineIdx])
          : m.phase === 'night'
            ? /\bnight\b/i.test(lines[lineIdx])
            : true
        hits.push({
          code: m.code,
          name: m.phase === 'none' ? m.name : `${m.name} ${m.phase === 'day' ? 'Day' : 'Night'}`,
          matchedLine: lines[lineIdx],
          latest: m.code === latestBetCode,
          phaseBoost,
        })
      }
    })
  })
  if (!hits.length) return null
  // Best = agrees with day/night keyword, then the customer's own latest market,
  // then the operator's market order (stable sort keeps insertion order).
  const score = (h: { latest: boolean; phaseBoost: boolean }) => (h.latest ? 4 : 0) + (h.phaseBoost ? 2 : 0)
  hits.sort((a, b) => score(b) - score(a))
  const best = hits[0]
  return { code: best.code, name: best.name, matchedLine: best.matchedLine }
}

/**
 * Remove the market name from the message but KEEP any game label that shared
 * the line: "Milan open motor" → "open motor" (the motor header survives),
 * while "Milan day" → dropped (no digits, no known label) and
 * "Market: Milan" → dropped. Everything else passes through untouched.
 */
function stripMarketLines(text: string, marketLine: string, marketBaseName: string, customTerms: CustomTerm[]): string {
  const marketLineLower = marketLine.toLowerCase()
  const nameLower = marketBaseName.toLowerCase().trim()
  const out: string[] = []
  for (const rawLine of text.split(/[\n\r]+/)) {
    const t = rawLine.trim().toLowerCase()
    if (!t) continue
    if (t === marketLineLower || (nameLower && t.includes(nameLower))) {
      let rest = rawLine.trim().replace(/^\s*market\s*:\s*/i, '')
      if (nameLower) {
        const re = new RegExp(nameLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i')
        rest = rest.replace(re, ' ')
      }
      rest = rest.trim()
      if (!rest) continue
      if (/\d/.test(rest)) { out.push(rest); continue }
      // a surviving word-only remainder is kept ONLY when it is a known
      // game label ("open motor", "dp motor", …) — never chat noise
      const norm = rest.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
      if (norm && lookupTerm(norm, customTerms)) { out.push(rest) }
      continue
    }
    out.push(rawLine.trim())
  }
  return out.join('\n')
}

function summarize(parse: UnifiedParseResult): ParseSummary {
  const sum = (arr: Array<{ amount: number }>) => arr.reduce((s, e) => s + e.amount, 0)
  const groups = parse.groups.map(g => ({
    option: g.option,
    count: g.entries.length,
    amount: sum(g.entries),
    invalid: g.invalid.length,
  }))
  const total =
    sum(parse.singles) + sum(parse.doubles) + sum(parse.triples) + sum(parse.common) +
    groups.reduce((s, g) => s + g.amount, 0)
  return {
    counts: {
      singles: { count: parse.singles.length, amount: sum(parse.singles) },
      doubles: { count: parse.doubles.length, amount: sum(parse.doubles) },
      triples: { count: parse.triples.length, amount: sum(parse.triples) },
      common: { count: parse.common.length, amount: sum(parse.common) },
      groups,
    },
    total,
    unknownLabels: parse.unknownLabels,
    skipped: parse.skipped,
  }
}

// explicit money markers: "128=75", "150rs", seed,rate comma style "23457890,100"
const MONEY_RE = /(\d\s*(=|---|\*|x|×)\s*\d)|(\d+\s*(rs|₹|rupees))|(\d{4,10}\s*,\s*\d{1,5})/i

/** Compose the auto-generated vyapar information reply. */
export function buildVyaparReply(opts: {
  marketName: string
  session?: string
  summary: ParseSummary
  rateAssumed: boolean
  marketList?: string[]
}): string {
  if (opts.marketList) {
    return [
      'Welcome! Send your vyapar like this:',
      '',
      'Milan',
      '128=75',
      '139=75',
      '',
      'Available markets:',
      opts.marketList.join(', '),
    ].join('\n')
  }
  const L: string[] = []
  const sess = opts.session ? ` (${opts.session === 'open' ? 'Open' : 'Close'})` : ''
  L.push(`*Vyapar received — ${opts.marketName}${sess}*`)
  L.push(istDateDisplay())
  L.push('------------------------------')
  const c = opts.summary.counts
  if (c.singles.count) L.push(`Single: ${c.singles.count} nos = ₹${c.singles.amount}`)
  if (c.doubles.count) L.push(`Jodi: ${c.doubles.count} nos = ₹${c.doubles.amount}`)
  if (c.triples.count) L.push(`Panna: ${c.triples.count} nos = ₹${c.triples.amount}`)
  if (c.common.count) L.push(`Common: ${c.common.count} nos = ₹${c.common.amount}`)
  for (const g of c.groups) L.push(`${g.option}: ${g.count} nos = ₹${g.amount}`)
  L.push('------------------------------')
  L.push(`*Total: ₹${opts.summary.total}*`)
  if (opts.rateAssumed) L.push('(rate assumed ₹100 where not written)')
  if (opts.summary.unknownLabels.length) {
    L.push(`Note: could not read "${opts.summary.unknownLabels.join('", "')}" — our team will verify.`)
  }
  if (opts.summary.skipped.length) L.push(`Note: ${opts.summary.skipped.length} line(s) skipped.`)
  L.push('')
  L.push('Pls check and confirm. Best of luck!')
  return L.join('\n')
}

const UNREGISTERED_REPLY = [
  'This number is not registered with us.',
  '',
  'Please contact your agent to get your number registered, or place your vyapar from the customer app.',
].join('\n')

// ── Command grammar (doc §6-§9: Vyapar / Del / Result / Bal) ──
const CMD_DEL_RE = /^(?:del|delete)\s+(\d+)$/i
const CMD_RESULT_RE = /^result(?:\s+(.+))?$/i
const CMD_BAL_RE = /^(?:bal|balance)$/i
const CMD_PREFIX_RE = /^(?:del|delete|result|bal|balance)\b/i

const COMMAND_HELP_REPLY = [
  'Supported commands:',
  '',
  'Vyapar — send the market name + your entries (e.g. Milan, 128=75)',
  'Del <Transaction ID> — delete one of your transactions',
  'Result <market> — today\u2019s result for a market',
  'Bal — your vyapar report for today',
].join('\n')

/** IST calendar date "2026-10-02" (the ERP's resultDate format). */
function istToday(): string {
  return new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10)
}

/** UTC window covering today's IST calendar day. */
function istDayWindow(): { start: Date; end: Date } {
  const start = new Date(Date.parse(`${istToday()}T00:00:00Z`) - 5.5 * 3600 * 1000)
  return { start, end: new Date(start.getTime() + 24 * 3600 * 1000) }
}

function customerWhere(customer: ResolvedCustomer) {
  return customer.kind === 'app' ? { customerId: customer.id } : { vendorId: customer.id }
}

function fmtMoney(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(2)
}

/** One-line digest of parsed buckets for template variables ("Single 2 = ₹200\nDouble 45 = ₹100"). */
function bucketsLine(summary: ParseSummary): string {
  const parts: string[] = []
  for (const [k, v] of Object.entries(summary.counts || {})) {
    if (k === 'groups') continue
    const b = v as { count: number; amount: number }
    if (b.count > 0) parts.push(`${k} ${b.count} = ₹${fmtMoney(b.amount)}`)
  }
  const groups = (summary.counts as { groups?: Array<{ option: string; count: number; amount: number }> })?.groups || []
  for (const g of groups) parts.push(`${g.option} ${g.count} = ₹${fmtMoney(g.amount)}`)
  return parts.length ? parts.join('\n') + '\n' : ''
}

/** Del <ID> — VOID the customer's own active transaction (audit-safe, no hard delete). */
async function handleDeleteCommand(customer: ResolvedCustomer, phone: string, num: number) {
  const tx = await db.whatsAppTransaction.findUnique({ where: { txNumber: num } })
  const mine = tx && tx.status === 'active' &&
    ((customer.kind === 'app' && tx.customerId === customer.id) ||
     (customer.kind === 'vendor' && tx.vendorId === customer.id))
  if (!tx || !mine) {
    return {
      found: false,
      reply: `Transaction ${num} not found. Send "Del <Transaction ID>" from the same number that placed it.`,
    }
  }
  await db.whatsAppTransaction.update({
    where: { id: tx.id },
    data: { status: 'deleted', deletedBy: phone, deletedAt: new Date() },
  })
  return { found: true, reply: `Deleted Successful — Transaction ID ${num} Deleted` }
}

/** Result — today's declared result card for the market (authoritative AppResult). */
function buildResultReply(marketName: string, res: { openPanna: string | null; closePanna: string | null; openDigit: string | null; closeDigit: string | null; jodi: string | null } | null): string {
  if (!res) {
    return `Wait for Result — *${marketName}* result is not declared yet.`
  }
  const L = [`*${marketName} — Result ${istDateDisplay()}*`]
  const open = [res.openPanna, res.openDigit].filter(Boolean).join('-')
  const close = [res.closePanna, res.closeDigit].filter(Boolean).join('-')
  if (open) L.push(`Open: ${open}`)
  if (close) L.push(`Close: ${close}`)
  if (res.jodi) L.push(`Jodi: ${res.jodi}`)
  if (L.length === 1) L.push('* --')
  return L.join('\n')
}

/** Bal — the customer's own vyapar report for today (authoritative transaction data). */
async function buildBalReply(customer: ResolvedCustomer): Promise<string> {
  const { start, end } = istDayWindow()
  const txs = await db.whatsAppTransaction.findMany({
    where: { ...customerWhere(customer), status: 'active', createdAt: { gte: start, lt: end } },
    select: { marketName: true, session: true, total: true },
  })
  if (!txs.length) {
    return `No vyapar yet today (${istDateDisplay()}).\n\nSend your vyapar with the market name and this report will build up here.`
  }
  const groups = new Map<string, number>()
  let totalSale = 0
  for (const t of txs) {
    const key = `${t.marketName || 'Market'}${t.session ? ` (${t.session === 'open' ? 'Open' : 'Close'})` : ''}`
    groups.set(key, (groups.get(key) || 0) + t.total)
    totalSale += t.total
  }
  const L = [`*Balance Report — ${istDateDisplay()}*`, '------------------------------']
  for (const [k, v] of groups) L.push(`${k} : ${fmtMoney(v)}`)
  L.push('------------------------------')
  L.push(`Total Sale ${fmtMoney(totalSale)}`)
  L.push(`Transactions ${txs.length}`)
  return L.join('\n')
}

/** Atomic lines for the transaction record (doc "VyaparLine"). */
function txLinesFromParse(parse: UnifiedParseResult): Array<{ kind: string; number: string; amount: number }> {
  const out: Array<{ kind: string; number: string; amount: number }> = []
  for (const e of parse.singles) out.push({ kind: 'single', number: e.number, amount: e.amount })
  for (const e of parse.doubles) out.push({ kind: 'double', number: e.number, amount: e.amount })
  for (const e of parse.triples) out.push({ kind: 'triple', number: e.number, amount: e.amount })
  for (const e of parse.common) out.push({ kind: 'common', number: e.number, amount: e.amount })
  for (const g of parse.groups) {
    for (const e of g.entries) out.push({ kind: `group:${g.option}`, number: e.number, amount: e.amount })
  }
  return out
}

/** The customer's cumulative ACTIVE total for one market today (Grand Total). */
async function customerDayMarketTotal(customer: ResolvedCustomer, marketCode: string): Promise<number> {
  const { start, end } = istDayWindow()
  const agg = await db.whatsAppTransaction.aggregate({
    _sum: { total: true },
    where: { ...customerWhere(customer), marketCode, status: 'active', createdAt: { gte: start, lt: end } },
  })
  return agg._sum.total ?? 0
}

const ENTRY_LIST_LIMIT = 30

/**
 * Confirmation reply in the documented format:
 *   1 ==> Transaction Successful ✅
 *   Customer := Ramesh (Agent: Milan)
 *   Transaction ID := 2284
 *   Milan Day (Open) = Total 2500
 *   Grand Total 5130
 *   1=500 3=500 7=500 9=500 …
 * Grand Total = the customer's cumulative active total for this market today
 * (documented assumption — the doc leaves the accounting semantics open).
 */
export function buildTransactionReply(opts: {
  txNumber: number
  customerName: string
  agentName?: string | null
  marketName: string
  session?: string
  total: number
  grandTotal: number
  parse: UnifiedParseResult
  summary: ParseSummary
  rateAssumed: boolean
}): string {
  const L: string[] = []
  L.push('1 ==> Transaction Successful ✅')
  L.push(`Customer := ${opts.customerName}${opts.agentName ? ` (Agent: ${opts.agentName})` : ''}`)
  L.push(`Transaction ID := ${opts.txNumber}`)
  const sess = opts.session ? ` (${opts.session === 'open' ? 'Open' : 'Close'})` : ''
  L.push(`${opts.marketName}${sess} = Total ${fmtMoney(opts.total)}`)
  L.push(`Grand Total ${fmtMoney(opts.grandTotal)}`)

  const pairs = [
    ...opts.parse.singles,
    ...opts.parse.doubles,
    ...opts.parse.triples,
    ...opts.parse.common,
  ].map(e => `${e.number}=${e.amount}`)
  const c = opts.summary.counts
  if (pairs.length && pairs.length <= ENTRY_LIST_LIMIT) {
    L.push('')
    for (let i = 0; i < pairs.length; i += 5) L.push(pairs.slice(i, i + 5).join(' '))
    for (const g of c.groups) L.push(`${g.option}: ${g.count} nos = ₹${g.amount}`)
  } else {
    L.push('')
    if (c.singles.count) L.push(`Single: ${c.singles.count} nos = ₹${c.singles.amount}`)
    if (c.doubles.count) L.push(`Jodi: ${c.doubles.count} nos = ₹${c.doubles.amount}`)
    if (c.triples.count) L.push(`Panna: ${c.triples.count} nos = ₹${c.triples.amount}`)
    if (c.common.count) L.push(`Common: ${c.common.count} nos = ₹${c.common.amount}`)
    for (const g of c.groups) L.push(`${g.option}: ${g.count} nos = ₹${g.amount}`)
  }

  if (opts.rateAssumed) L.push('(rate assumed ₹100 where not written)')
  if (opts.summary.unknownLabels.length) {
    L.push(`Note: could not read "${opts.summary.unknownLabels.join('", "')}" — our team will verify.`)
  }
  if (opts.summary.skipped.length) L.push(`Note: ${opts.summary.skipped.length} line(s) skipped.`)
  L.push('')
  L.push('Pls check and confirm. Best of luck!')
  return L.join('\n')
}

const UNREADABLE_REPLY = [
  'We could not read any vyapar in your message.',
  '',
  'Send it like this:',
  'Milan',
  '128=75',
  '139=75',
  '35=100',
].join('\n')

/**
 * Process one inbound WhatsApp text message end-to-end.
 * Idempotent on waMessageId (Meta redelivers webhooks).
 */
export async function processInbound(input: InboundInput): Promise<ProcessResult> {
  const phone = digitsOf(input.phone)
  const text = (input.text || '').trim()

  // ── Idempotency — same wamid already processed → return stored result ──
  if (input.waMessageId) {
    const existing = await db.whatsAppMessage.findUnique({ where: { waMessageId: input.waMessageId } })
    if (existing) {
      const out = existing.replyToId
        ? await db.whatsAppMessage.findUnique({ where: { id: existing.replyToId } })
        : null
      return {
        ok: true,
        status: 'duplicate',
        reply: out?.body || '',
        inboundId: existing.id,
        outboundId: out?.id,
      }
    }
  }

  // ── Context resolution + immutable raw snapshot ──
  // Priority: registered Group ID → forwarded original sender → own number.
  // The raw row (with ALL provider metadata) is stored BEFORE any business
  // decision — it is the permanent, never-deleted audit snapshot.
  const senderPhone = digitsOf(input.senderPhone || '') || null
  const senderName = (input.senderName || '').trim() || null
  const groupId = (input.groupId || '').trim() || null
  const groupLabel = (input.groupLabel || '').trim() || null
  const forwardedFrom = digitsOf(input.forwardedFrom || '') || null
  const providerTs = input.providerTimestamp
    ? new Date(typeof input.providerTimestamp === 'number'
        ? input.providerTimestamp * (input.providerTimestamp > 1e12 ? 1 : 1000)
        : parseInt(String(input.providerTimestamp), 10) * 1000)
    : null

  let customer: ResolvedCustomer | null = null
  let contextError = ''
  if (groupId) {
    // Group chat: identity is the Group ID mapping — the member number is
    // stored separately as the sender and is NOT used to resolve customers.
    customer = await resolveGroupCustomer(groupId)
    if (!customer) {
      contextError = groupId
        ? `group ${groupId} is not registered`
        : 'unregistered group'
    }
  } else if (forwardedFrom) {
    // Forwarded by the internal pickup team: resolve the ORIGINAL sender as
    // the customer; the team member stays recorded as the sender.
    customer = await resolveCustomer(forwardedFrom)
    if (!customer) contextError = `forwarded original number ${forwardedFrom} is not registered`
  } else {
    customer = await resolveCustomer(phone)
    if (!customer) contextError = 'unregistered number'
  }

  const parserVersion = await getParserVersion()
  const inbound = await db.whatsAppMessage.create({
    data: {
      direction: 'in',
      phone,
      profileName: input.profileName || '',
      waMessageId: input.waMessageId || null,
      body: text,
      customerId: customer?.kind === 'app' ? customer.id : null,
      vendorId: customer?.kind === 'vendor' ? customer.id : null,
      status: 'received',
      groupId,
      groupLabel,
      senderPhone: senderPhone || (groupId || forwardedFrom ? phone : null),
      senderName,
      forwardedFrom,
      providerTimestamp: providerTs,
      parserVersion,
    },
  })

  // The reply goes back to the chat the message came from: the group chat
  // for group messages, the customer's number otherwise.
  const replyTarget = groupId || phone
  const respond = async (
    status: 'processed' | 'rejected' | 'pending_approval',
    reply: string,
    extra: { summary?: ParseSummary; marketCode?: string; marketName?: string; error?: string; approvalId?: string }
  ): Promise<ProcessResult> => {
    const send = await sendWhatsAppText(replyTarget, reply)
    const outbound = await db.whatsAppMessage.create({
      data: {
        direction: 'out',
        phone: replyTarget,
        body: reply,
        replyToId: inbound.id,
        status: send.sandbox ? 'sandbox' : send.ok ? 'sent' : 'failed',
        waMessageId: send.wamid || null,
        error: send.error || null,
        groupId,
        parserVersion,
      },
    })
    await db.whatsAppMessage.update({
      where: { id: inbound.id },
      data: {
        status,
        error: extra.error || null,
        marketCode: extra.marketCode || null,
        marketName: extra.marketName || null,
        parseSummary: extra.summary ? JSON.stringify(extra.summary) : '{}',
        approvalId: extra.approvalId || null,
      },
    })
    return {
      ok: status === 'processed',
      status,
      reply,
      inboundId: inbound.id,
      outboundId: outbound.id,
      summary: extra.summary,
      marketName: extra.marketName,
      approvalId: extra.approvalId,
      reason: extra.error,
    }
  }

  if (!customer) {
    // Precise rejection: name the exact problematic portion (the unregistered
    // group ID / forwarded number) and the expected setup.
    if (groupId && !forwardedFrom) {
      return respond('rejected',
        'This WhatsApp group is not registered with us.\n\nA group can only send vyapar after the admin maps this group to a customer. Please contact support.',
        { error: contextError })
    }
    if (forwardedFrom) {
      return respond('rejected',
        `This forwarded message is not registered with us (original sender ${forwardedFrom}).\n\nThe original sender's number must be registered before vyapar can be accepted.`,
        { error: contextError })
    }
    return respond('rejected', UNREGISTERED_REPLY, { error: contextError })
  }
  if (customer.kind === 'app' && customer.blocked) {
    return respond('rejected', 'Your account is blocked. Please contact your agent.', { error: 'customer blocked' })
  }
  if (!text) {
    return respond('rejected', UNREADABLE_REPLY, { error: 'empty message' })
  }

  // ── Command router (doc: Vyapar / Del / Result / Bal) ──
  // Commands match the WHOLE message only — vyapar text is never mistaken
  // for a command. Only registered customers reach this point.
  const delMatch = text.match(CMD_DEL_RE)
  if (delMatch) {
    if (groupId) {
      // Ownership ambiguity: a group has many members — deletion of the group
      // customer's transactions is only accepted from the registered number.
      return respond('rejected',
        'Del works only from the registered customer\u2019s own WhatsApp number — group members cannot delete transactions.',
        { error: `del ${delMatch[1]}: not allowed from group` })
    }
    const r = await handleDeleteCommand(customer, phone, parseInt(delMatch[1], 10))
    return respond(r.found ? 'processed' : 'rejected', r.reply, { error: r.found ? undefined : `del ${delMatch[1]}: not found` })
  }
  if (CMD_BAL_RE.test(text)) {
    const reply = await buildBalReply(customer)
    return respond('processed', reply, {})
  }
  if (CMD_RESULT_RE.test(text)) {
    // Market from the command text ("Result Milan"), else the customer's
    // latest WhatsApp transaction market, else their latest app bet.
    let marketCode: string | null = null
    let marketName: string | null = null
    const hit = await resolveMarket(text, customer.kind === 'app' ? customer.id : null)
    if (hit) {
      marketCode = hit.code
      marketName = hit.name
    } else {
      const tx = await db.whatsAppTransaction.findFirst({
        where: { ...customerWhere(customer), marketCode: { not: null } },
        orderBy: { createdAt: 'desc' },
        select: { marketCode: true, marketName: true },
      })
      if (tx) {
        marketCode = tx.marketCode
        marketName = tx.marketName
      } else if (customer.kind === 'app') {
        const bet = await db.appBet.findFirst({
          where: { customerId: customer.id },
          orderBy: { createdAt: 'desc' },
          select: { marketCode: true },
        })
        if (bet) {
          const mk = await db.appMarket.findUnique({ where: { code: bet.marketCode }, select: { name: true, phase: true } })
          if (mk) {
            marketCode = bet.marketCode
            marketName = mk.phase === 'none' ? mk.name : `${mk.name} ${mk.phase === 'day' ? 'Day' : 'Night'}`
          }
        }
      }
    }
    if (!marketCode) {
      const markets = await db.appMarket.findMany({
        where: { isActive: true }, orderBy: { sortOrder: 'asc' }, select: { name: true }, take: 14,
      })
      return respond('rejected', [
        'Which market\u2019s result? Send "Result <market>".',
        '',
        `Available: ${[...new Set(markets.map(m => m.name))].join(', ')}`,
      ].join('\n'), { error: 'result: no market' })
    }
    const res = await db.appResult.findFirst({
      where: { marketCode, resultDate: istToday(), state: 'declared' },
      orderBy: { version: 'desc' },
    })
    const reply = buildResultReply(marketName || marketCode, res)
    return respond('processed', reply, { marketCode, marketName: marketName || undefined })
  }
  if (CMD_PREFIX_RE.test(text) && !/\d/.test(text)) {
    // "Del", "Bal 12x", … — command-shaped but not valid → syntax guidance
    return respond('rejected', COMMAND_HELP_REPLY, { error: 'invalid command' })
  }

  // ── Market resolution ──
  const marketHit = await resolveMarket(text, customer.kind === 'app' ? customer.id : null)
  if (!marketHit) {
    const markets = await db.appMarket.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
      select: { name: true, phase: true },
      take: 14,
    })
    const reply = buildVyaparReply({
      marketName: '', summary: { counts: {} as ParseSummary['counts'], total: 0, unknownLabels: [], skipped: [] },
      rateAssumed: false,
      marketList: [...new Set(markets.map(m => m.name))],
    })
    return respond('rejected', reply, { error: 'no market found in message' })
  }

  // ── Session hint (open/close word in the market line) ──
  const sessionHint = /\bopen\b/i.test(marketHit.matchedLine) ? 'open'
    : /\bclose\b/i.test(marketHit.matchedLine) ? 'close' : undefined

  // ── Optional market-hours gate (AppConfig "whatsapp_market_check" = "on") ──
  // The doc allows rejection on closed markets "unless explicitly configured
  // otherwise" — ground agents collect vyapar around the clock, so the
  // permissive side is the default.
  const marketCheck = await db.appConfig.findUnique({ where: { key: 'whatsapp_market_check' } })
  if (marketCheck?.value === 'on') {
    const mk = await db.appMarket.findUnique({ where: { code: marketHit.code }, select: { marketStatus: true } })
    if (mk && (mk.marketStatus === 'closed' || mk.marketStatus === 'off')) {
      return respond('rejected', `*${marketHit.name}* is closed right now — vyapar is accepted during market hours only.`, { error: 'market closed', marketCode: marketHit.code, marketName: marketHit.name })
    }
  }

  // ── Parse the vyapar with the SAME Smart Entry engine (one source of truth) ──
  const customTerms = await db.parserTerm.findMany({
    where: { isActive: true },
    select: { term: true, category: true },
  })
  const vyaparText = stripMarketLines(text, marketHit.matchedLine, marketHit.name.split(' ')[0], customTerms)
  const parse = parseUnifiedEntry(vyaparText, 100, customTerms)
  const summary = summarize(parse)

  if (summary.total <= 0) {
    // Invalid input NEVER creates a transaction — precise reason + audit trail.
    await captureLearningCandidates(parse, marketHit.name, inbound.id)
    const detail = [...summary.unknownLabels, ...summary.skipped].slice(0, 3)
    return respond('rejected', detail.length
      ? `${UNREADABLE_REPLY}\n\nWe could not read: ${detail.join(', ')}`
      : UNREADABLE_REPLY,
      { error: detail.length ? `no readable vyapar: ${detail.join(' | ')}` : 'no readable vyapar', marketCode: marketHit.code, marketName: marketHit.name })
  }

  // Unknown patterns → learning candidates (never auto-applied to rules)
  await captureLearningCandidates(parse, marketHit.name, inbound.id)

  // Precise validation notes for the approval queue
  const validationNotes: string[] = []
  for (const label of summary.unknownLabels) {
    validationNotes.push(`Could not read "${label}" — expected a game label (single / jodi / panna / motor / …) or entries like 128=75.`)
  }
  for (const skip of summary.skipped) {
    validationNotes.push(`Skipped line "${skip}" — expected entries like 128=75, 23457890,100, or a known game label header.`)
  }
  const validationStatus = validationNotes.length ? 'warnings' : 'ok'
  const rateAssumed = !MONEY_RE.test(vyaparText)
  const summaryWithMeta = { ...summary, rateAssumed } as ParseSummary & { rateAssumed?: boolean }

  // ── Approval mode (AppConfig "whatsapp_approval", default ON) ──
  // Valid parsed messages go to the Admin Manager approval queue FIRST;
  // the ERP transaction is created only after an explicit approval.
  const approvalCfg = await db.appConfig.findUnique({ where: { key: APPROVAL_MODE_KEY } })
  const approvalOn = (approvalCfg?.value || 'on').toLowerCase() !== 'off'

  if (approvalOn) {
    const approval = await db.whatsAppApproval.create({
      data: {
        messageId: inbound.id,
        groupId,
        senderPhone: senderPhone || (groupId || forwardedFrom ? phone : null),
        senderName,
        customerId: customer.kind === 'app' ? customer.id : null,
        vendorId: customer.kind === 'vendor' ? customer.id : null,
        customerName: customer.name,
        agentUsername: customer.agentUsername,
        agentName: customer.agentName,
        marketCode: marketHit.code,
        marketName: marketHit.name,
        session: sessionHint ?? null,
        rawMessage: text,
        parseSummary: JSON.stringify(summaryWithMeta),
        parsedSnapshot: JSON.stringify(parse),
        total: summary.total,
        validationStatus,
        validationNotes: JSON.stringify(validationNotes),
        parserVersion,
        status: 'pending',
      },
    })
    // Template override: the operator's active "vyapar_ack" template wins;
    // otherwise the canonical built-in ack wording below is used.
    const ack =
      (await resolvePipelineTemplate(PIPELINE_TEMPLATE_KEYS.ack, {
        market_name: marketHit.name || 'the market',
        session: sessionHint === 'close' ? 'Close' : sessionHint === 'open' ? 'Open' : '—',
        buckets_line: bucketsLine(summary),
        total: fmtMoney(summary.total),
      }))?.body ?? buildPendingAckReply({
      marketName: marketHit.name,
      session: sessionHint,
      summary,
      rateAssumed,
    })
    const res = await respond('pending_approval', ack, {
      summary,
      marketCode: marketHit.code,
      marketName: marketHit.name,
      approvalId: approval.id,
    })
    res.customerName = customer.name
    return res
  }

  // ── Legacy auto mode ("whatsapp_approval" = off) — header + atomic lines in
  // ONE db transaction, sequential human Transaction ID, reply after commit.
  const created = await createTransactionRecord({
    messageId: inbound.id,
    customer,
    market: { code: marketHit.code, name: marketHit.name },
    session: sessionHint,
    rawMessage: text,
    parse,
    summary,
  })

  const grandTotal = await customerDayMarketTotal(customer, marketHit.code)
  const reply = buildTransactionReply({
    txNumber: created.txNumber,
    customerName: customer.name,
    agentName: customer.agentName,
    marketName: marketHit.name,
    session: sessionHint,
    total: summary.total,
    grandTotal,
    parse,
    summary,
    rateAssumed,
  })

  const res = await respond('processed', reply, {
    summary,
    marketCode: marketHit.code,
    marketName: marketHit.name,
  })
  res.customerName = customer.name
  res.txNumber = created.txNumber
  return res
}

// ────────────────────────────────────────────────────────────
// Approval workflow (v3) — used by the ERP Admin Manager API routes.
// Approve  → create the ERP transaction (the ONLY path that touches ERP
//            records) → send the documented confirmation reply AFTER the
//            transaction commits. A failed outbound NEVER rolls the
//            transaction back and NEVER creates a second one — the reply
//            is retried separately (retryOutbound).
// Reject   → audit record + original message stay intact; a precise
//            rejection notice goes back to the chat.
// ────────────────────────────────────────────────────────────

export const APPROVAL_MODE_KEY = 'whatsapp_approval'

/** Acknowledgment sent while the vyapar waits for approval (NOT a success claim). */
export function buildPendingAckReply(opts: {
  marketName: string
  session?: string
  summary: ParseSummary
  rateAssumed: boolean
}): string {
  const L: string[] = []
  const sess = opts.session ? ` (${opts.session === 'open' ? 'Open' : 'Close'})` : ''
  L.push(`*Vyapar received — ${opts.marketName}${sess}*`)
  L.push(istDateDisplay())
  L.push('------------------------------')
  const c = opts.summary.counts
  if (c.singles.count) L.push(`Single: ${c.singles.count} nos = ₹${c.singles.amount}`)
  if (c.doubles.count) L.push(`Jodi: ${c.doubles.count} nos = ₹${c.doubles.amount}`)
  if (c.triples.count) L.push(`Panna: ${c.triples.count} nos = ₹${c.triples.amount}`)
  if (c.common.count) L.push(`Common: ${c.common.count} nos = ₹${c.common.amount}`)
  for (const g of c.groups) L.push(`${g.option}: ${g.count} nos = ₹${g.amount}`)
  L.push('------------------------------')
  L.push(`*Total: ₹${opts.summary.total}*`)
  if (opts.rateAssumed) L.push('(rate assumed ₹100 where not written)')
  if (opts.summary.unknownLabels.length) {
    L.push(`Note: could not read "${opts.summary.unknownLabels.join('", "')}" — our team will verify.`)
  }
  if (opts.summary.skipped.length) L.push(`Note: ${opts.summary.skipped.length} line(s) skipped.`)
  L.push('')
  L.push('Your vyapar is pending approval. You will receive your Transaction ID once it is approved.')
  return L.join('\n')
}

/** Header + atomic lines in ONE db transaction (shared by auto mode and approval). */
async function createTransactionRecord(data: {
  messageId: string
  customer: ResolvedCustomer
  market: { code: string; name: string }
  session?: string
  rawMessage: string
  parse: UnifiedParseResult
  summary: ParseSummary
}) {
  return db.$transaction(async (tdb) => {
    const max = await tdb.whatsAppTransaction.aggregate({ _max: { txNumber: true } })
    const txNumber = (max._max.txNumber ?? 0) + 1
    const tx = await tdb.whatsAppTransaction.create({
      data: {
        txNumber,
        messageId: data.messageId,
        customerId: data.customer.kind === 'app' ? data.customer.id : null,
        vendorId: data.customer.kind === 'vendor' ? data.customer.id : null,
        customerName: data.customer.name,
        agentUsername: data.customer.agentUsername,
        agentName: data.customer.agentName,
        marketCode: data.market.code || null,
        marketName: data.market.name || null,
        session: data.session ?? null,
        rawMessage: data.rawMessage,
        parseSummary: JSON.stringify(data.summary),
        total: data.summary.total,
      },
    })
    const lines = txLinesFromParse(data.parse)
    if (lines.length) {
      await tdb.whatsAppTransactionLine.createMany({ data: lines.map(l => ({ txId: tx.id, kind: l.kind, number: l.number, amount: l.amount })) })
    }
    return tx
  })
}

export interface ApprovalOutcome {
  ok: boolean
  error?: string
  txNumber?: number
  replyStatus?: string // outbound reply status after the attempt
}

/** Approve a pending vyapar: create the ERP transaction, then reply. */
export async function approveWhatsAppApproval(approvalId: string, approvedBy: string): Promise<ApprovalOutcome> {
  const approval = await db.whatsAppApproval.findUnique({
    where: { id: approvalId },
    include: { message: true },
  })
  if (!approval) return { ok: false, error: 'Approval not found' }
  if (approval.status !== 'pending') return { ok: false, error: `Approval is already ${approval.status}` }

  const parse = JSON.parse(approval.parsedSnapshot) as UnifiedParseResult
  const summaryMeta = JSON.parse(approval.parseSummary || '{}') as ParseSummary & { rateAssumed?: boolean }
  const summary: ParseSummary = {
    counts: summaryMeta.counts,
    total: summaryMeta.total,
    unknownLabels: summaryMeta.unknownLabels || [],
    skipped: summaryMeta.skipped || [],
  }
  const customer: ResolvedCustomer = {
    kind: approval.customerId ? 'app' : 'vendor',
    id: (approval.customerId || approval.vendorId)!,
    name: approval.customerName,
    blocked: false,
    agentUsername: approval.agentUsername,
    agentName: approval.agentName,
  }
  const market = { code: approval.marketCode || '', name: approval.marketName || '' }

  // 1) ERP transaction commits FIRST (approval creates the only ERP record)
  const created = await createTransactionRecord({
    messageId: approval.messageId,
    customer,
    market,
    session: approval.session ?? undefined,
    rawMessage: approval.rawMessage,
    parse,
    summary,
  })

  // 2) Immutable decision snapshot on the approval row
  await db.whatsAppApproval.update({
    where: { id: approval.id },
    data: {
      status: 'approved',
      approvedBy,
      approvedAt: new Date(),
      txId: created.id,
      txNumber: created.txNumber,
    },
  })
  await db.whatsAppMessage.update({
    where: { id: approval.messageId },
    data: { status: 'processed' },
  })

  // 3) Reply ONLY after the transaction committed. If delivery fails the
  //    transaction stays successful and the reply is retried separately.
  const grandTotal = await customerDayMarketTotal(customer, market.code)
  // Template override: active "tx_success" template wins; otherwise the
  // canonical doc-format reply built below is used.
  const reply =
    (await resolvePipelineTemplate(PIPELINE_TEMPLATE_KEYS.approved, {
      tx_number: String(created.txNumber),
      details: `${market.name || 'the market'}${approval.session ? ` (${approval.session === 'open' ? 'Open' : 'Close'})` : ''} · Total ₹${fmtMoney(summary.total)}`,
      customer_name: approval.customerName,
      total: fmtMoney(summary.total),
    }))?.body ?? buildTransactionReply({
    txNumber: created.txNumber,
    customerName: approval.customerName,
    agentName: approval.agentName,
    marketName: market.name,
    session: approval.session ?? undefined,
    total: summary.total,
    grandTotal,
    parse,
    summary,
    rateAssumed: summaryMeta.rateAssumed ?? false,
  })
  const target = approval.groupId || approval.message.phone
  const send = await sendWhatsAppText(target, reply)
  const replyStatus = send.sandbox ? 'sandbox' : send.ok ? 'sent' : 'failed'
  await db.whatsAppMessage.create({
    data: {
      direction: 'out',
      phone: target,
      body: reply,
      replyToId: approval.messageId,
      status: replyStatus,
      waMessageId: send.wamid || null,
      error: send.error || null,
      groupId: approval.groupId,
      parserVersion: approval.parserVersion,
    },
  })

  return { ok: true, txNumber: created.txNumber, replyStatus }
}

/** Reject a pending vyapar: audit intact, precise notice back to the chat. */
export async function rejectWhatsAppApproval(approvalId: string, rejectedBy: string, reason: string): Promise<ApprovalOutcome> {
  const approval = await db.whatsAppApproval.findUnique({
    where: { id: approvalId },
    include: { message: true },
  })
  if (!approval) return { ok: false, error: 'Approval not found' }
  if (approval.status !== 'pending') return { ok: false, error: `Approval is already ${approval.status}` }
  if (!reason || !reason.trim()) return { ok: false, error: 'A rejection reason is required' }

  await db.whatsAppApproval.update({
    where: { id: approval.id },
    data: {
      status: 'rejected',
      rejectedBy,
      rejectedAt: new Date(),
      rejectionReason: reason.trim(),
    },
  })
  // The ORIGINAL message + audit record stay intact — only the status moves.
  await db.whatsAppMessage.update({
    where: { id: approval.messageId },
    data: { status: 'rejected', error: `rejected by admin: ${reason.trim()}` },
  })

  const target = approval.groupId || approval.message.phone
  // Template override: active "rejection_notice" template wins.
  const reply =
    (await resolvePipelineTemplate(PIPELINE_TEMPLATE_KEYS.rejected, {
      market_name: approval.marketName || 'the market',
      total: fmtMoney(approval.total),
      reason: reason.trim(),
    }))?.body ?? `Your vyapar for ${approval.marketName || 'the market'} (Total ₹${fmtMoney(approval.total)}) was not accepted.\n\nReason: ${reason.trim()}\n\nPlease contact your agent or send it again correctly.`
  const send = await sendWhatsAppText(target, reply)
  const replyStatus = send.sandbox ? 'sandbox' : send.ok ? 'sent' : 'failed'
  await db.whatsAppMessage.create({
    data: {
      direction: 'out',
      phone: target,
      body: reply,
      replyToId: approval.messageId,
      status: replyStatus,
      waMessageId: send.wamid || null,
      error: send.error || null,
      groupId: approval.groupId,
      parserVersion: approval.parserVersion,
    },
  })

  return { ok: true, replyStatus }
}

/**
 * Retry a failed outbound reply (spec: transaction stays successful; the
 * outbound message is retried separately; never a second transaction).
 */
export async function retryOutbound(outboundId: string): Promise<{ ok: boolean; error?: string; status?: string }> {
  const row = await db.whatsAppMessage.findUnique({ where: { id: outboundId } })
  if (!row || row.direction !== 'out') return { ok: false, error: 'Outbound message not found' }
  if (['sent', 'delivered', 'read', 'sandbox'].includes(row.status)) {
    return { ok: false, error: `Reply already ${row.status}` }
  }
  const send = await sendWhatsAppText(row.phone, row.body)
  const status = send.sandbox ? 'sandbox' : send.ok ? 'sent' : 'failed'
  await db.whatsAppMessage.update({
    where: { id: row.id },
    data: { status, error: send.error || null, waMessageId: send.wamid || row.waMessageId },
  })
  return { ok: true, status }
}
