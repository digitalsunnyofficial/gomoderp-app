// ────────────────────────────────────────────────────────────
// WhatsApp templates engine — WhatsApp Management panel.
//
// ONE place where outbound reply wording lives:
//   • Pipeline-default templates (keyed) — the pipeline resolves the ACTIVE
//     template by key before every reply and falls back to its built-in
//     wording when none is active, so the operator can customize every bot
//     reply from the Templates page without code changes.
//   • Custom templates (key = null) — utility / marketing / authentication,
//     sendable to any customer from the Templates page.
//
// Variables use {{name}} tokens; renderTemplate substitutes them from the
// params map (missing params render as empty strings, never "{{name}}").
// ────────────────────────────────────────────────────────────

import { db } from '@/lib/db'

/** Pipeline reply slots → their template keys. */
export const PIPELINE_TEMPLATE_KEYS = {
  ack: 'vyapar_ack',
  approved: 'tx_success',
  rejected: 'rejection_notice',
  invalid: 'invalid_notice',
} as const

export type PipelineTemplateKey =
  (typeof PIPELINE_TEMPLATE_KEYS)[keyof typeof PIPELINE_TEMPLATE_KEYS]

export const TEMPLATE_CATEGORIES = ['utility', 'marketing', 'authentication'] as const
export type TemplateCategory = (typeof TEMPLATE_CATEGORIES)[number]

export interface TemplateVariable {
  name: string
  sample: string
}

export interface ResolvedTemplate {
  templateId: string
  name: string
  category: string
  body: string
}

/** Substitute {{var}} tokens; unknown/missing vars become empty strings. */
export function renderTemplate(body: string, params: Record<string, string> = {}): string {
  return body.replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_m, name: string) => params[name] ?? '')
}

/** Extract {{var}} names used in a body (deduplicated, in order). */
export function extractVariables(body: string): string[] {
  const out: string[] = []
  for (const m of body.matchAll(/\{\{\s*([\w.-]+)\s*\}\}/g)) {
    if (!out.includes(m[1])) out.push(m[1])
  }
  return out
}

/**
 * Resolve the ACTIVE pipeline template for a key and render it.
 * Returns null when no active template exists → caller uses its built-in
 * wording (the pipeline's fallback texts are the canonical defaults).
 */
export async function resolvePipelineTemplate(
  key: PipelineTemplateKey,
  params: Record<string, string> = {},
): Promise<ResolvedTemplate | null> {
  const t = await db.whatsAppTemplate.findUnique({ where: { key } })
  if (!t || !t.isActive || !t.bodyText.trim()) return null
  // Fire-and-forget usage tracking — never blocks the reply.
  db.whatsAppTemplate
    .update({ where: { id: t.id }, data: { usageCount: { increment: 1 }, lastUsedAt: new Date() } })
    .catch(() => {})
  return {
    templateId: t.id,
    name: t.name,
    category: t.category,
    body: renderTemplate(t.bodyText, params),
  }
}

/** Record a manual send from the Templates page (usage stats). */
export async function recordTemplateUse(templateId: string): Promise<void> {
  await db.whatsAppTemplate
    .update({ where: { id: templateId }, data: { usageCount: { increment: 1 }, lastUsedAt: new Date() } })
    .catch(() => {})
}

/** Parse the variables JSON safely. */
export function parseVariables(raw: string | null | undefined): TemplateVariable[] {
  if (!raw || raw === '[]') return []
  try {
    const arr = JSON.parse(raw) as unknown
    if (!Array.isArray(arr)) return []
    return arr
      .filter((v): v is TemplateVariable =>
        !!v && typeof v === 'object' && typeof (v as TemplateVariable).name === 'string')
      .map(v => ({ name: v.name, sample: typeof v.sample === 'string' ? v.sample : '' }))
  } catch {
    return []
  }
}

/**
 * Idempotently create the four pipeline-default templates (utility). Only
 * inserts a key when it does not exist yet — operator edits are NEVER
 * overwritten. Called on Templates list load so a fresh system is fully
 * customizable out of the box.
 */
export async function ensureDefaultTemplates(createdBy = 'system'): Promise<void> {
  const defaults: Array<{
    key: PipelineTemplateKey
    name: string
    category: TemplateCategory
    bodyText: string
    variables: TemplateVariable[]
  }> = [
    {
      key: PIPELINE_TEMPLATE_KEYS.ack,
      name: 'Vyapar received (pending approval)',
      category: 'utility',
      bodyText: 'Vyapar received — {{market_name}} ({{session}})\n{{buckets_line}}Total ₹{{total}}\n\nYour entry is waiting for admin approval. You will get the Transaction confirmation right after approval.',
      variables: [
        { name: 'market_name', sample: 'Milan Day' },
        { name: 'session', sample: 'Open' },
        { name: 'buckets_line', sample: 'Single 2 = ₹200\n' },
        { name: 'total', sample: '250' },
      ],
    },
    {
      key: PIPELINE_TEMPLATE_KEYS.approved,
      name: 'Transaction successful',
      category: 'utility',
      bodyText: 'Transaction ID : {{tx_number}} ==> Transaction Successful ✅\n{{details}}',
      variables: [
        { name: 'tx_number', sample: '2284' },
        { name: 'details', sample: 'Milan Day (Open) · Total ₹250' },
      ],
    },
    {
      key: PIPELINE_TEMPLATE_KEYS.rejected,
      name: 'Vyapar rejected by admin',
      category: 'utility',
      bodyText: 'Your vyapar for {{market_name}} (Total ₹{{total}}) was not accepted.\n\nReason: {{reason}}\n\nPlease contact your agent or send it again correctly.',
      variables: [
        { name: 'market_name', sample: 'Milan Day' },
        { name: 'total', sample: '250' },
        { name: 'reason', sample: '45=abc — amount is not a number' },
      ],
    },
    {
      key: PIPELINE_TEMPLATE_KEYS.invalid,
      name: 'Unreadable vyapar (invalid input)',
      category: 'utility',
      bodyText: 'We could not read your vyapar.\n\nReason: {{reason}}\n\nExpected format:\nMarket name\n<number>=<amount>  (e.g. 45=100)\n\nNothing was recorded — please resend.',
      variables: [
        { name: 'reason', sample: 'no readable vyapar: hello (not a number)' },
      ],
    },
  ]
  for (const d of defaults) {
    const existing = await db.whatsAppTemplate.findUnique({ where: { key: d.key } })
    if (existing) continue
    await db.whatsAppTemplate.create({
      data: {
        name: d.name,
        key: d.key,
        category: d.category,
        language: 'en',
        bodyText: d.bodyText,
        variables: JSON.stringify(d.variables),
        // Shipped INACTIVE on purpose: while inactive the pipeline uses its
        // canonical built-in wording (e.g. the documented doc-format
        // "Transaction Successful" reply). The operator edits a template and
        // activates it to override — an explicit, visible choice.
        isActive: false,
        createdBy,
      },
    })
  }
}
