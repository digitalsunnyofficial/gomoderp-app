/**
 * Super-Admin Gate — the ONE encrypted link to the ERP login.
 *
 * The public landing page carries no visible admin entry. Instead the
 * operator uses a tokenised URL:
 *
 *     /g/<token>
 *
 * where <token> = HMAC-SHA256(ADMIN_GATE_SECRET, "super-admin-login")
 * rendered base64url. A valid token redirects to /merp (ERP login);
 * anything else 404s — the gate never reveals whether the path exists.
 *
 * Rotate the token by setting ADMIN_GATE_SECRET in the environment
 * (default works out of the box for local/VS Code evaluation).
 */
import { createHmac, timingSafeEqual } from 'crypto'

const GATE_SECRET = process.env.ADMIN_GATE_SECRET || 'satta-matka-god-gate-2026'
const GATE_PAYLOAD = 'super-admin-login'

export function adminGateToken(): string {
  return createHmac('sha256', GATE_SECRET).update(GATE_PAYLOAD).digest('base64url')
}

export function isValidAdminGateToken(token: string | undefined | null): boolean {
  if (!token) return false
  const expected = adminGateToken()
  const a = Buffer.from(String(token))
  const b = Buffer.from(expected)
  if (a.length !== b.length) return false
  return timingSafeEqual(a, b)
}
