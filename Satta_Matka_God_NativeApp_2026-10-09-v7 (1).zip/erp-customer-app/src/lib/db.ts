import { PrismaClient } from '@prisma/client'
import path from 'path'

/**
 * Resolve DATABASE_URL to an ABSOLUTE file path at runtime.
 *
 * Why: On Hostinger (and any production host) the standalone server runs from
 * `.next/standalone/` (or a deploy dir), but the `db/` folder may live at the
 * project root. A relative `file:./db/custom.db` would resolve against the
 * CWD, producing "Error code 14: Unable to open the database file".
 *
 * This resolver converts `file:./db/custom.db` →
 * `file:/absolute/path/to/<process.cwd()>/db/custom.db` so the DB is found
 * regardless of where the server is started from.
 *
 * For the seed script (which runs from `prisma/`), see prisma/seed.js — it
 * resolves against __dirname instead.
 */
function resolveDatabaseUrl(): string {
  let url = process.env.DATABASE_URL || 'file:./db/custom.db'
  if (url.startsWith('file:./')) {
    const relativePath = url.replace('file:', '')
    const absolutePath = path.resolve(process.cwd(), relativePath)
    url = `file:${absolutePath}`
  } else if (url.startsWith('file:') && !path.isAbsolute(url.replace('file:', ''))) {
    // Bare relative path like "file:db/custom.db" (no leading ./)
    const relativePath = url.replace('file:', '')
    const absolutePath = path.resolve(process.cwd(), relativePath)
    url = `file:${absolutePath}`
  }
  return url
}

const resolvedUrl = resolveDatabaseUrl()

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const databaseUrl = resolvedUrl

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['error'],
    datasources: {
      db: {
        url: resolvedUrl,
      },
    },
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db

// Graceful shutdown
if (typeof process !== 'undefined') {
  process.on('beforeExit', async () => {
    await db.$disconnect()
  })
}
