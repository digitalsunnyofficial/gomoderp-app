import { create } from 'zustand'

export type PageName =
  | 'dashboard'
  | 'inv-new'
  | 'inv-list'
  | 'card-view'
  | 'unified-entry'           // Unified Quick Entry (single+double+triple on one page)
  | 'vendor'
  | 'configure'
  | 'users'
  // ── Phase 2: System Management ──
  | 'sys-mgmt-users'           // Users (alias for users)
  | 'sys-mgmt-markets'         // Market Permissions
  | 'sys-mgmt-activity'        // User Activity
  | 'sys-mgmt-pending'         // Pending Signups
  | 'sys-mgmt-locked'          // Locked Users
  | 'sys-mgmt-parser-ex'       // Parser Exceptions
  | 'sys-mgmt-parser-cfg'      // Parser Configuration
  | 'sys-mgmt-chart-revs'      // Chart Revisions
  // ── Subscription & Payments ──
  | 'sub-plans'                 // Subscription Plans Management
  | 'sub-users'                 // User Subscriptions Management
  | 'sub-payments'              // Payments Management
  | 'paywall'                   // Paywall for non-subscribed users
  // ── Hierarchy ──
  | 'hierarchy-managers'        // Manager List
  | 'hierarchy-agents'          // Agent List
  | 'hierarchy-customers'       // Customer List
  | 'login'
  // ── Customer App management ──
  | 'app-customers'             // App Customers (Satta Matka God app users) — merged into Customer List, still reachable
  | 'app-bids'                  // App Bids + Declare Result
  | 'app-funds'                 // Payment Management (deposits / withdrawals / business QR)
  | 'market-results'            // Market Results — declare / update + declaration time
  | 'starlines'                 // Starlines management — create/update/manage hourly starlines
  | 'chart-data'                // Jodi & Panel chart data — backend input for all markets
  | 'game-management'           // Game catalog — rates, categories, ERP mappings
  | 'game-allocation'           // Per-market game allocation with rate/min-point overrides
  // ── Expansion: Chitthi Generator + WhatsApp Management panel ──
  | 'chitthi'                    // Chitthi Generator — agent-collected vyapar → handwritten JPG slip
  | 'wa-dashboard'               // WhatsApp panel — channel overview, bot evolution, optimization
  | 'wa-messages'                // WhatsApp panel — per-customer/group conversation management
  | 'wa-templates'               // WhatsApp panel — utility/marketing/authentication templates
  | 'wa-approvals'               // WhatsApp panel — approval queue, approved txs, rejected
  | 'wa-learning'                // WhatsApp panel — learning candidates + parser evolution
  | 'wa-mappings'                // WhatsApp panel — provider Group ID → customer mapping
  // ── Expansion: agent ↔ customer mapping + play commission ──
  | 'agent-commission'           // Agent Commission — X% on what the agent's customers PLAY
  | 'app-notify'                 // App Notifications — master-admin composer for the native app
  | 'app-content'                // App Content — notice marquee, banner sliders, bank details, default agent
  | 'app-build'                  // App Build (APK) — upload the release APK, served at /apk/sm-gomod.apk

interface AuthUser {
  id: string
  username: string
  role: string
  name: string
  // Phase 2 — present in API responses
  assignedMarkets?: string
  isLocked?: boolean
  lockedAt?: string | null
  lockedBy?: string | null
  lockReason?: string | null
  permissions?: Array<{
    id: string
    inventoryCode: string
    canView: boolean
    canEdit: boolean
    canDelete: boolean
  }>
}

export type MobileTab = 'home' | 'smart-entry' | 'inventory' | 'vendors' | 'profile'

interface AppState {
  currentPage: PageName
  setCurrentPage: (page: PageName) => void
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
  currentUser: AuthUser | null
  setCurrentUser: (user: AuthUser | null) => void
  isLoggedIn: boolean
  login: (user: AuthUser) => void
  logout: () => void
  viewingInventoryId: string | null
  setViewingInventoryId: (id: string | null) => void
  showChart: boolean
  setShowChart: (show: boolean) => void
  selectedInventoryForChart: string | null
  setSelectedInventoryForChart: (id: string | null) => void
  mobileTab: MobileTab
  setMobileTab: (tab: MobileTab) => void
}

export const useAppStore = create<AppState>((set) => ({
  currentPage: 'login',
  setCurrentPage: (page) => set({ currentPage: page }),
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  currentUser: null,
  setCurrentUser: (user) => set({ currentUser: user }),
  isLoggedIn: false,
  login: (user) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('erp_user', JSON.stringify(user))
    }
    set((state) => ({ currentUser: user, isLoggedIn: true, currentPage: state.currentPage === 'login' ? 'dashboard' : state.currentPage }))
  },
  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('erp_user')
    }
    set({ currentUser: null, isLoggedIn: false, currentPage: 'login' })
  },
  viewingInventoryId: null,
  setViewingInventoryId: (id) => set({ viewingInventoryId: id }),
  showChart: false,
  setShowChart: (show) => set({ showChart: show }),
  selectedInventoryForChart: null,
  setSelectedInventoryForChart: (id) => set({ selectedInventoryForChart: id }),
  mobileTab: 'home',
  setMobileTab: (tab) => set({ mobileTab: tab }),
}))
