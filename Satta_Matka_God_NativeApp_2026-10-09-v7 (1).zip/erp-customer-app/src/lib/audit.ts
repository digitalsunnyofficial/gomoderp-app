import { db } from './db'
import { isSuperRole } from './roles'

/**
 * Phase 2 — Audit logging helper.
 * Records a single entry in the UserActivity table.
 *
 * Usage:
 *   await logActivity({ userId, username, action: 'create', entity: 'inventory', entityId, market, recordsAffected: 1, metadata: { ... } })
 *
 * Errors are silently swallowed — audit logging must NEVER break the parent operation.
 */
export interface LogActivityInput {
  userId?: string | null
  username: string
  action: string // login, logout, create, update, delete, lock, unlock, upload, parse, chart_save, chart_regenerate, parser_resolve, etc.
  entity?: string // inventory, settlement, user, vendor, chart, parser_exception
  entityId?: string | null
  market?: string | null
  recordsAffected?: number
  metadata?: Record<string, unknown> | null
  ipAddress?: string | null
}

export async function logActivity(input: LogActivityInput): Promise<void> {
  try {
    await db.userActivity.create({
      data: {
        userId: input.userId ?? null,
        username: input.username,
        action: input.action,
        entity: input.entity ?? '',
        entityId: input.entityId ?? null,
        market: input.market ?? null,
        recordsAffected: input.recordsAffected ?? 1,
        metadata: input.metadata ? JSON.stringify(input.metadata) : '{}',
        ipAddress: input.ipAddress ?? null,
      },
    })
  } catch (err) {
    // Audit logging must never throw to the caller
    console.error('[audit] logActivity failed:', err)
  }
}

/**
 * Parse a comma-separated assignedMarkets string into an array.
 * Empty string → empty array. Whitespace trimmed.
 */
export function parseAssignedMarkets(csv: string | null | undefined): string[] {
  if (!csv) return []
  return csv.split(',').map(s => s.trim()).filter(Boolean)
}

/**
 * Check if a user has access to a given market.
 * Master users always have access. Regular users must have the market in their assignedMarkets list.
 */
export function hasMarketAccess(user: { role: string; assignedMarkets?: string | null } | null | undefined, market: string | null | undefined): boolean {
  if (!user) return false
  if (isSuperRole(user.role) || user.role === 'manager') return true
  if (!market) return false
  const markets = parseAssignedMarkets(user.assignedMarkets)
  return markets.includes(market)
}

/**
 * Extract user info from request headers for audit logging.
 * The frontend stores the current user in localStorage and sends minimal info via headers.
 */
export function getUserFromHeaders(request: Request): { userId?: string; username?: string } {
  const userId = request.headers.get('x-user-id') || undefined
  const username = request.headers.get('x-user-name') || undefined
  return { userId, username }
}

/**
 * Phase 2 — Auth context derived from request headers.
 * The frontend `apiFetch` injects these headers from localStorage.
 * For market access control we trust the role + assignedMarkets header,
 * BUT we also verify against the DB to ensure the user still exists and isn't locked.
 */
export interface AuthContext {
  userId: string | null
  username: string | null
  role: string | null
  assignedMarkets: string[] // parsed from CSV header
  marketsCsv: string
  isMaster: boolean
}

/**
 * Read auth context from headers WITHOUT a DB hit.
 * Fast path — used by read-only endpoints.
 *
 * HEADER PRECEDENCE (security fix): the proxy sets x-session-* headers from
 * the SIGNED ERP session cookie — those are server-verified and win. The
 * legacy x-user-* headers are client-set from localStorage (spoofable) and
 * are only used as a fallback for internal callers that don't go through
 * the proxy (tests, cron, server-to-server).
 */
export function readAuthContext(request: Request): AuthContext {
  const userId = request.headers.get('x-session-userid') || request.headers.get('x-user-id')
  const username = request.headers.get('x-session-username') || request.headers.get('x-user-name')
  const role = request.headers.get('x-session-role') || request.headers.get('x-user-role') || 'user'
  const marketsCsv = request.headers.get('x-user-markets') || ''
  const assignedMarkets = parseAssignedMarkets(marketsCsv)
  return {
    userId,
    username,
    role,
    assignedMarkets,
    marketsCsv,
    isMaster: isSuperRole(role) || role === 'manager',
  }
}

/**
 * Read auth context AND verify the user is still valid (exists + not locked).
 * Use this for mutation endpoints (POST/PUT/DELETE) where we want strict enforcement.
 * Returns null if the user is invalid or locked.
 */
export async function getAuthUser(request: Request): Promise<AuthContext | null> {
  const ctx = readAuthContext(request)
  if (!ctx.userId) return null
  try {
    const user = await db.user.findUnique({
      where: { id: ctx.userId },
      select: { id: true, isLocked: true, status: true, role: true, assignedMarkets: true },
    })
    if (!user) return null
    if (user.isLocked) return null
    if (user.status !== 'active') return null
    // Refresh role/markets from DB in case they changed since login
    return {
      ...ctx,
      role: user.role,
      assignedMarkets: parseAssignedMarkets(user.assignedMarkets),
      marketsCsv: user.assignedMarkets || '',
      isMaster: isSuperRole(user.role) || user.role === 'manager',
    }
  } catch {
    // DB error — fall back to header-trusted context (audit must not block)
    return ctx
  }
}

/**
 * Build a Prisma `where` clause fragment that filters records by the user's
 * assigned markets. Master users get `{}` (no filter).
 *
 * @param ctx auth context
 * @param marketFieldPath dot-path to the market field in the Prisma where clause.
 *        Examples:
 *          'inventoryCode.market' — for Inventory (relation: inventoryCode)
 *          'inventoryCode.market' — for Settlement (relation: inventoryCode, but optional)
 *          'market'               — for direct market field
 */
export function marketFilter(
  ctx: AuthContext,
  marketFieldPath: string = 'inventoryCode.market'
): Record<string, unknown> {
  if (ctx.isMaster) return {}
  if (ctx.assignedMarkets.length === 0) {
    // Non-master with no markets — deny everything by using an impossible condition
    return { _none: {} }
  }
  // For nested paths like 'inventoryCode.market', build a nested object
  const parts = marketFieldPath.split('.')
  if (parts.length === 1) {
    return { [parts[0]]: { in: ctx.assignedMarkets } }
  }
  // Build nested object bottom-up:
  // For 'inventoryCode.market' → { inventoryCode: { market: { in: [...] } } }
  let inner: Record<string, unknown> = { in: ctx.assignedMarkets }
  for (let i = parts.length - 1; i >= 0; i--) {
    inner = { [parts[i]]: inner }
  }
  return inner
}

/**
 * Convenience: check access to a single market string.
 */
export function canAccessMarket(ctx: AuthContext, market: string | null | undefined): boolean {
  if (ctx.isMaster) return true
  if (!market) return false
  return ctx.assignedMarkets.includes(market)
}

/**
 * Returns true only if the user has the 'manager' role (not master, not user).
 * Use this when manager has different permissions than master.
 */
export function isManagerOnly(ctx: AuthContext): boolean {
  return ctx.role === 'manager'
}

/**
 * Data isolation helper — returns a Prisma where clause that restricts data
 * to the current user's scope based on their role.
 *
 * Master: sees everything (returns {})
 * Manager: sees own data + data from agents under them
 * Agent/User: sees only own data
 *
 * @param ctx auth context
 * @param createdByField the field name to filter on (default: 'createdBy')
 * @returns Prisma-compatible where clause fragment
 */
export async function dataIsolationFilter(
  ctx: AuthContext,
  createdByField: string = 'createdBy'
): Promise<Record<string, unknown>> {
  // Master sees everything
  if (isSuperRole(ctx.role)) return {}
  
  if (ctx.role === 'manager' && ctx.userId) {
    // Manager sees own data + data from agents under them
    const agents = await db.user.findMany({
      where: { managerId: ctx.userId, status: 'active' },
      select: { username: true },
    })
    const allowedUsernames = [ctx.username, ...agents.map(a => a.username)].filter(Boolean) as string[]
    return { [createdByField]: { in: allowedUsernames } }
  }
  
  // Agent/user sees only own data
  if (ctx.username) {
    return { [createdByField]: ctx.username }
  }
  
  // No valid user context — deny everything
  return { [createdByField]: '__none__' }
}

/**
 * User isolation for user listing — restricts which users a manager can see.
 * Master: all users
 * Manager: only own agents (users where managerId = manager.id)
 * Agent: only self
 */
export function userListIsolationFilter(
  ctx: AuthContext
): Record<string, unknown> {
  if (isSuperRole(ctx.role)) return {}
  if (ctx.role === 'manager' && ctx.userId) {
    return { managerId: ctx.userId }
  }
  // Agent sees only self
  if (ctx.userId) {
    return { id: ctx.userId }
  }
  return { id: '__none__' }
}
