/**
 * roles.ts — Canonical role constants + helpers.
 *
 * 2026-09 rename: the top role is now "Super Admin" (DB value `super`),
 * formerly "Master Admin" (DB value `master`). Old values may still exist in
 * stale browser sessions or pre-migration databases, so every check accepts
 * both during the transition. New writes always use `super`.
 *
 *   DB value   Display        Notes
 *   ---------  -------------  --------------------------------
 *   super      Super Admin    top role, all markets, all actions
 *   manager    Admin          team management under Super Admin
 *   user       Agent          field role, market-scoped
 */

export const ROLE_SUPER = 'super'
export const ROLE_SUPER_LEGACY = 'master' // pre-rename value (read-compat only)
export const ROLE_MANAGER = 'manager'
export const ROLE_USER = 'user'

/** True when the role value is the Super Admin role (current or legacy). */
export function isSuperRole(role: string | null | undefined): boolean {
  return role === ROLE_SUPER || role === ROLE_SUPER_LEGACY
}

/** True when the role can manage teams: Super Admin or Admin (manager). */
export function isAdminRole(role: string | null | undefined): boolean {
  return isSuperRole(role) || role === ROLE_MANAGER
}

/** Display label for a DB role value. */
export function roleDisplayLabel(role: string | null | undefined): string {
  if (isSuperRole(role)) return 'Super Admin'
  if (role === ROLE_MANAGER) return 'Admin'
  return 'Agent'
}
