/**
 * parser-patterns.ts — Centralized, configurable parser pattern registry.
 *
 * This module defines ALL regex patterns used by the WhatsApp parser.
 * It can be extended dynamically from the DB (ParserPattern table) for
 * self-evolving behavior. Both built-in and custom patterns live here.
 *
 * NEW patterns added to handle the user's specific formats:
 *   - comma-separated + dot + amount + optional rs:  "00,02,60,67,66.1500rs"
 *   - space-separated + dot + amount + optional rs:  "00 02 60 67 66.1500rs"
 *   - single number + --- + amount:                  "07---2500"
 *   - dot-separated numbers + = + amount + rs:       "53.57.13.07=75rs"
 *   - comma-separated + dot + amount (NO rs):        "00,02,60,67,66.1500"
 */

// ──────────────────────────────────────────────────────────
// Type Definitions
// ──────────────────────────────────────────────────────────

export interface PatternDef {
  /** Unique machine name (also stored in DB) */
  name: string
  /** Human-readable label */
  label: string
  /** RegExp object */
  re: RegExp
  /** Priority — lower = tried first */
  priority: number
  /** Which game modes this applies to */
  appliesTo: 'single' | 'double' | 'triple' | 'all' | 'group'
  /** Example input for docs */
  example: string
  /** How it works */
  description: string
  /** How to extract pannas from the match */
  extract: 'numbers_from_group' | 'single_number' | 'pair_numbers'
  /** How to split the numbers capture group */
  numberSeparator: 'comma' | 'space' | 'dot' | 'none'
  /** Which capture group index holds the number(s) */
  numberGroupIndex: number
  /** Which capture group index holds the rate */
  rateGroupIndex: number
  /** For pair_numbers: second number group index */
  number2GroupIndex?: number
  /** Is this a built-in pattern? */
  isBuiltIn: boolean
}

// ──────────────────────────────────────────────────────────
// BUILT-IN PATTERNS (priority 10–89)
// These are shipped with the ERP and always available.
// ──────────────────────────────────────────────────────────

export const BUILT_IN_PATTERNS: PatternDef[] = [
  // ── PRIORITY 10–19: Group patterns (comma/space + separator + rate) ──

  {
    name: 'comma_dash_value',
    label: 'Comma-Separated + --- + Amount',
    re: /^((?:\d{1,3},)+\d{1,3})\s*[-–—]{2,}\s*(\d+)\s*$/,
    priority: 10,
    appliesTo: 'all',
    example: '61,81---2000',
    description: 'Comma-separated numbers (1/2/3-digit) followed by 2+ dashes and a shared value. Each number gets the same value.',
    extract: 'numbers_from_group',
    numberSeparator: 'comma',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'space_dash_value',
    label: 'Space-Separated + --- + Amount',
    re: /^((?:\d{1,3}\s+)+\d{1,3})\s*[-–—]{2,}\s*(\d+)\s*$/,
    priority: 11,
    appliesTo: 'all',
    example: '61 81---2000',
    description: 'Space-separated numbers followed by 2+ dashes and a shared value.',
    extract: 'numbers_from_group',
    numberSeparator: 'space',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── NEW: Comma/Space + dot + amount (+ optional rs) ──
  // "00,02,60,67,66.1500rs" or "00,02,60,67,66.1500"
  {
    name: 'comma_dot_amount_rs',
    label: 'Comma-Separated + Dot + Amount (optional rs)',
    re: /^((?:\d{1,3},)+\d{1,3})\s*\.\s*(\d+)\s*(?:rs)?\s*$/i,
    priority: 12,
    appliesTo: 'all',
    example: '00,02,60,67,66.1500rs',
    description: 'Comma-separated numbers followed by a dot, then amount with optional "rs" suffix. Handles: 00,02,60,67,66.1500rs and 00,02,60,67,66.1500',
    extract: 'numbers_from_group',
    numberSeparator: 'comma',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'space_dot_amount_rs',
    label: 'Space-Separated + Dot + Amount (optional rs)',
    re: /^((?:\d{1,3}\s+)+\d{1,3})\s*\.\s*(\d+)\s*(?:rs)?\s*$/i,
    priority: 13,
    appliesTo: 'all',
    example: '00 02 60 67 66.1500rs',
    description: 'Space-separated numbers followed by a dot, then amount with optional "rs" suffix.',
    extract: 'numbers_from_group',
    numberSeparator: 'space',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── NEW: Single/multi number + --- + amount (no comma required) ──
  // "07---2500" or "07----2500"
  {
    name: 'single_dash_value',
    label: 'Number + --- + Amount (no comma required)',
    re: /^(\d{1,3})\s*[-–—]{2,}\s*(\d+)\s*$/,
    priority: 14,
    appliesTo: 'all',
    example: '07---2500',
    description: 'A single number (1/2/3-digit) followed by 2+ dashes and an amount. Handles: 07---2500, 07----2500, 07—2500',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── NEW: Dot-separated numbers + = + amount + rs ──
  // "53.57.13.07=75rs" or "53.57.13.07=75"
  {
    name: 'dot_group_equals_rs',
    label: 'Dot-Separated Group + = + Amount (optional rs)',
    re: /^((?:\d{1,3}\.)+\d{1,3})\s*=\s*(\d+)\s*(?:rs)?\s*$/i,
    priority: 15,
    appliesTo: 'all',
    example: '53.57.13.07=75rs',
    description: 'Dot-separated numbers followed by = and amount with optional "rs". Handles: 53.57.13.07=75rs and 53.57.13.07=75',
    extract: 'numbers_from_group',
    numberSeparator: 'dot',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── NEW: Dot-separated numbers + . + amount + rs ──
  // "07.2500rs" or "07.2500" (single number with dot-rate)
  // This is already handled by DOT_RATE_RE below but this version
  // handles the rs suffix variant explicitly
  {
    name: 'number_dot_amount_rs',
    label: 'Number + Dot + Amount (optional rs, any digit length)',
    re: /^(\d{1,3})\.\s*(\d+)\s*(?:rs)?\s*$/i,
    priority: 16,
    appliesTo: 'all',
    example: '07.2500rs',
    description: 'A single number followed by a dot and amount with optional "rs". Handles: 07.2500rs, 07.2500, 07.20rs',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── PRIORITY 20–29: Paren/Bracket/Prefix patterns ──

  {
    name: 'paren_rate',
    label: '(NNN)RATE — Parentheses',
    re: /^\((\d{2,3})\)\s*(\d+)\s*$/,
    priority: 20,
    appliesTo: 'all',
    example: '(61)25',
    description: 'Panna in parentheses with rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'bracket_dash',
    label: '[NN]-RATE — Bracket Dash',
    re: /^\[(\d{2,3})\]\s*[-–]\s*(\d+)\s*$/,
    priority: 21,
    appliesTo: 'all',
    example: '[02]-30',
    description: 'Double/triple in brackets with dash and rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'rs_rate',
    label: 'NN-rsRATE — Dash + rs',
    re: /^(\d{2,3})\s*[-–]\s*rs\s*(\d+)\s*$/i,
    priority: 22,
    appliesTo: 'all',
    example: '42-rs20',
    description: 'Double/triple with dash, "rs", and rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'pair_eq',
    label: 'NN*NN=RATE — Pair Equals',
    re: /^(\d{2})\s*[*×xX]\s*(\d{2})\s*=\s*(\d+)\s*$/,
    priority: 23,
    appliesTo: 'double',
    example: '33*38=50',
    description: 'Two double numbers with star and equals rate. Both get the same rate.',
    extract: 'pair_numbers',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 3,
    number2GroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'star_eq',
    label: '*N=RATE — Star Prefix Equals',
    re: /^[*×xX]\s*(\d{1,3})\s*=\s*(\d+)\s*$/,
    priority: 24,
    appliesTo: 'all',
    example: '*1=20',
    description: 'Star/× prefix with equals and rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'x_dash',
    label: '×NNN-RATE — × Prefix Dash',
    re: /^[*×xX]\s*(\d{2,3})\s*[-–]\s*(\d+)\s*$/,
    priority: 25,
    appliesTo: 'all',
    example: '×990-25',
    description: 'Star/× prefix with dash and rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── PRIORITY 30–39: Group/space/equals patterns ──

  {
    name: 'dot_group_rs',
    label: 'Dot-Separated + ..... + Amount rs',
    re: /^((?:\d{2}\s*\.\s*)+\d{2})\s*\.{3,}\s*(\d+)\s*rs\s*$/i,
    priority: 30,
    appliesTo: 'double',
    example: '05 . 00 . 55 . 50 ..... 10 rs',
    description: 'Dot-separated doubles with multiple dots and trailing "rs" rate.',
    extract: 'numbers_from_group',
    numberSeparator: 'dot',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'group_rate',
    label: 'Space-Separated Group + =RATE',
    re: /^((?:\d{2,3}\s+)+\d{2,3})\s*=\s*(\d+)\s*$/,
    priority: 31,
    appliesTo: 'all',
    example: '44 49 94 99=25',
    description: 'Space-separated numbers with trailing =rate.',
    extract: 'numbers_from_group',
    numberSeparator: 'space',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'single_eq_rate',
    label: 'NNN =RATE — Single with Space Equals',
    re: /^(\d{2,3})\s+=\s*(\d+)\s*$/,
    priority: 32,
    appliesTo: 'all',
    example: '61 =50',
    description: 'Single number with space then =rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },

  // ── PRIORITY 40–59: Individual number + separator + rate ──

  {
    name: 'equals_rate',
    label: 'NNN=RATE — Equals',
    re: /^(\d{2,3})\s*=\s*(\d+)\s*$/,
    priority: 40,
    appliesTo: 'all',
    example: '64=40',
    description: 'Number with equals and rate.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'triple_x',
    label: 'NNN×RATE — Triple ×',
    re: /^(\d{3})\s*[×xX]\s*(\d+)\s*$/,
    priority: 41,
    appliesTo: 'triple',
    example: '579×10',
    description: 'Triple with ×/x/X separator.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'triple_star',
    label: 'NNN*RATE — Triple Star',
    re: /^(\d{3})\s*[*]\s*(\d+)\s*$/,
    priority: 42,
    appliesTo: 'triple',
    example: '149*200',
    description: 'Triple with star separator.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'double_x',
    label: 'NN×RATE — Double ×',
    re: /^(\d{2})\s*[×xX]\s*(\d+)\s*$/,
    priority: 43,
    appliesTo: 'double',
    example: '57×10',
    description: 'Double with ×/x/X separator.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'double_star',
    label: 'NN*RATE — Double Star',
    re: /^(\d{2})\s*[*]\s*(\d+)\s*$/,
    priority: 44,
    appliesTo: 'double',
    example: '64*20',
    description: 'Double with star separator.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'single_x',
    label: 'N×RATE — Single ×',
    re: /^(\d{1})\s*[×xX]\s*(\d+)\s*$/,
    priority: 45,
    appliesTo: 'single',
    example: '1×75',
    description: 'Single with ×/x/X separator.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'single_star',
    label: 'N*RATE — Single Star',
    re: /^(\d{1})\s*[×xX*]\s*(\d+)\s*$/,
    priority: 46,
    appliesTo: 'single',
    example: '4*350',
    description: 'Single with star/× separator.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'slash_dash',
    label: 'NN/-RATE — Slash Dash',
    re: /^(\d{2,3})\s*\/[-–]\s*(\d+)\s*$/,
    priority: 47,
    appliesTo: 'all',
    example: '03/-20',
    description: 'Double/triple with slash-dash.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'slash_rate',
    label: 'N/RATE — Slash',
    re: /^(\d{1,3})\s*\/\s*(\d+)\s*$/,
    priority: 48,
    appliesTo: 'all',
    example: '9/25',
    description: 'Single/double with slash.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'dot_dot',
    label: 'NN..RATE — Double Dot',
    re: /^(\d{2,3})\s*\.{2,}\s*(\d+)\s*$/,
    priority: 49,
    appliesTo: 'all',
    example: '08..10',
    description: 'Double-dot format.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'dot_rate',
    label: 'NN.RATE — Milan Dot',
    re: /^(\d{2})\.\s*(\d+)\s*$/,
    priority: 50,
    appliesTo: 'double',
    example: '02.20',
    description: 'Double with single dot (Milan style). Only matches exactly 2 digits before dot.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'triple_dash',
    label: 'NNN-RATE — Triple Dash',
    re: /^(\d{3})\s*[-–]\s*(\d+)\s*$/,
    priority: 51,
    appliesTo: 'triple',
    example: '199-30',
    description: 'Triple with dash.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'double_dash',
    label: 'NN-RATE — Double Dash',
    re: /^(\d{2})\s*[-–]\s*(\d+)\s*$/,
    priority: 52,
    appliesTo: 'double',
    example: '91-20',
    description: 'Double with dash.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
  {
    name: 'single_dash',
    label: 'N-RATE — Single Dash',
    re: /^(\d{1})\s*[-–]\s*(\d+)\s*$/,
    priority: 53,
    appliesTo: 'single',
    example: '1-250',
    description: 'Single with dash.',
    extract: 'single_number',
    numberSeparator: 'none',
    numberGroupIndex: 1,
    rateGroupIndex: 2,
    isBuiltIn: true,
  },
]

// ──────────────────────────────────────────────────────────
// PATTERN EXECUTION ENGINE
// ──────────────────────────────────────────────────────────

export interface ParsedEntry {
  number: string
  price: number
}

/**
 * Try all patterns (built-in + custom) against a single line.
 * Returns ParsedEntry[] if any pattern matches, or null.
 * Patterns are tried in priority order (lower first).
 */
export function parseWithPatterns(
  line: string,
  patterns: PatternDef[],
  mode: 'single' | 'double' | 'triple' | 'group'
): ParsedEntry[] | null {
  const trimmed = line.trim()
  if (!trimmed) return null

  // Sort by priority (already should be, but ensure)
  const sorted = [...patterns].sort((a, b) => a.priority - b.priority)

  for (const pattern of sorted) {
    if (!pattern.re) continue

    // Skip patterns that don't apply to this mode
    if (pattern.appliesTo !== 'all' && pattern.appliesTo !== mode) continue

    const m = trimmed.match(pattern.re)
    if (!m) continue

    const rate = parseInt(m[pattern.rateGroupIndex], 10)
    if (rate <= 0) continue

    if (pattern.extract === 'single_number') {
      return [{ number: m[pattern.numberGroupIndex], price: rate }]
    }

    if (pattern.extract === 'pair_numbers') {
      const n1 = m[pattern.numberGroupIndex]
      const n2 = m[pattern.number2GroupIndex!]
      return [{ number: n1, price: rate }, { number: n2, price: rate }]
    }

    if (pattern.extract === 'numbers_from_group') {
      const group = m[pattern.numberGroupIndex]
      let nums: string[] = []

      if (pattern.numberSeparator === 'comma') {
        nums = group.split(',').map((n: string) => n.trim()).filter((n: string) => /^\d{1,3}$/.test(n))
      } else if (pattern.numberSeparator === 'space') {
        nums = group.trim().split(/\s+/).filter((n: string) => /^\d{1,3}$/.test(n))
      } else if (pattern.numberSeparator === 'dot') {
        nums = group.split(/\s*\.\s*/).filter((n: string) => /^\d{1,3}$/.test(n))
      } else {
        // 'none' — single number
        nums = [group]
      }

      if (nums.length > 0) {
        return nums.map((n: string) => ({ number: n, price: rate }))
      }
    }
  }

  return null
}

/**
 * Convert a PatternDef to the format needed for DB seeding.
 */
export function patternDefToDB(p: PatternDef) {
  return {
    name: p.name,
    label: p.label,
    regex: p.re.source,
    flags: p.re.flags || 'i',
    priority: p.priority,
    isActive: true,
    isBuiltIn: true,
    appliesTo: p.appliesTo,
    example: p.example,
    description: p.description,
    captureGroups: p.extract === 'pair_numbers' ? 'number1,number2,rate' : (p.extract === 'numbers_from_group' ? 'numbers,rate' : 'number,rate'),
    numberSeparator: p.numberSeparator,
    createdBy: 'system',
  }
}

/**
 * Build a PatternDef from DB record (for custom patterns).
 */
export function dbToPatternDef(row: {
  name: string
  label: string
  regex: string
  flags: string
  priority: number
  isActive: boolean
  appliesTo: string
  example: string | null
  description: string | null
  captureGroups: string
  numberSeparator: string
}): PatternDef | null {
  if (!row.isActive) return null
  try {
    const re = new RegExp(row.regex, row.flags)
    const groups = row.captureGroups.split(',')
    const isPair = groups.includes('number1') && groups.includes('number2')
    const isGroup = groups.includes('numbers')
    const numberIdx = groups.indexOf(isGroup ? 'numbers' : 'number1') + 1
    const rateIdx = groups.indexOf('rate') + 1
    const number2Idx = isPair ? groups.indexOf('number2') + 1 : undefined

    return {
      name: row.name,
      label: row.label,
      re,
      priority: row.priority,
      appliesTo: row.appliesTo as PatternDef['appliesTo'],
      example: row.example || '',
      description: row.description || '',
      extract: isPair ? 'pair_numbers' : (isGroup ? 'numbers_from_group' : 'single_number'),
      numberSeparator: row.numberSeparator as PatternDef['numberSeparator'],
      numberGroupIndex: numberIdx,
      rateGroupIndex: rateIdx,
      number2GroupIndex: number2Idx,
      isBuiltIn: false,
    }
  } catch {
    return null // Invalid regex — skip
  }
}

// ──────────────────────────────────────────────────────────
// CONVENIENCE: Get all active patterns (built-in only, for page.tsx import)
// ──────────────────────────────────────────────────────────

export function getBuiltInPatterns(): PatternDef[] {
  return BUILT_IN_PATTERNS.filter(p => p.isBuiltIn)
}

/**
 * Quick test: parse a single line using built-in patterns only.
 * Useful for live preview and testing.
 */
export function quickParseLine(
  line: string,
  mode: 'single' | 'double' | 'triple' | 'group' = 'double'
): ParsedEntry[] | null {
  return parseWithPatterns(line, BUILT_IN_PATTERNS, mode)
}
