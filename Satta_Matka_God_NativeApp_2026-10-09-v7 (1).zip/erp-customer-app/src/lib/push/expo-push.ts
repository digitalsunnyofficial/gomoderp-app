// ────────────────────────────────────────────────────────────────────────────
// expo-push.ts — Push notifications for the native customer app (Task 31).
//
// The native app (satta-matka-god-native, Expo/React Native) registers an
// ExpoPushToken via POST /api/customer-app/push/register. Tokens are stored
// on AppCustomer.pushToken. Sending goes through the Expo Push API
// (exp.host), which relays to Firebase Cloud Messaging on Android — no
// firebase-admin or service-account JSON is needed server-side.
//
// Design rules:
//   - Push NEVER breaks an API flow: every send is fire-and-forget with a
//     full catch-all. Failures are logged, not thrown.
//   - No-op safety: customers without a token are skipped silently; the
//     whole channel can be disabled with env PUSH_ENABLED=false.
//   - notifyCustomer() keeps the existing in-app AppNotification behaviour
//     and adds the push on top, so call sites stay one-liners.
// ────────────────────────────────────────────────────────────────────────────
import { db } from '@/lib/db'

const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send'
const CHUNK_SIZE = 100 // Expo Push API max messages per request

export type ExpoPushMessage = {
  to: string
  title?: string
  body?: string
  data?: Record<string, unknown>
  sound?: 'default'
  // Android notification channel created by the app (expo-notifications)
  channelId?: string
}

export function pushEnabled(): boolean {
  return process.env.PUSH_ENABLED !== 'false'
}

export function isValidExpoPushToken(token: unknown): token is string {
  return typeof token === 'string' && /^Expo(nent)?PushToken\[[\w-]+\]$/.test(token.trim())
}

type PushTicket = { status: 'ok' } | { status: 'error'; message?: string }

async function postChunk(chunk: ExpoPushMessage[]): Promise<PushTicket[]> {
  const res = await fetch(EXPO_PUSH_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // Optional but recommended by Expo for higher rate limits
      'expo-sender-name': 'satta-matka-god',
      Accept: 'application/json',
    },
    body: JSON.stringify(chunk),
    signal: AbortSignal.timeout(10_000),
  })
  if (!res.ok) throw new Error(`Expo Push API ${res.status}`)
  const json = (await res.json()) as { data?: PushTicket[] }
  return json.data ?? []
}

// Fire-and-forget send. Returns a summary; never throws.
export async function sendExpoPush(messages: ExpoPushMessage[]): Promise<{
  delivered: number; failed: number; skipped: boolean
}> {
  if (!pushEnabled() || messages.length === 0) {
    return { delivered: 0, failed: 0, skipped: true }
  }
  let delivered = 0, failed = 0
  try {
    for (let i = 0; i < messages.length; i += CHUNK_SIZE) {
      const chunk = messages.slice(i, i + CHUNK_SIZE)
      const tickets = await postChunk(chunk)
      for (const t of tickets) {
        if (t.status === 'ok') delivered++
        else {
          failed++
          if (t.message) console.warn('expo-push ticket error:', t.message)
        }
      }
    }
  } catch (err) {
    // Count anything un-confirmed as failed; log and move on.
    failed += Math.max(0, messages.length - delivered - failed)
    console.warn('expo-push send error (non-fatal):', err instanceof Error ? err.message : err)
  }
  return { delivered, failed, skipped: false }
}

// Push to one customer (skips silently when they have no registered token).
export async function sendCustomerPush(
  customerId: string, title: string, body: string,
  data?: Record<string, unknown>,
): Promise<void> {
  if (!pushEnabled()) return
  try {
    const c = await db.appCustomer.findUnique({
      where: { id: customerId }, select: { pushToken: true },
    })
    if (!c?.pushToken) return
    await sendExpoPush([{
      to: c.pushToken, title, body, sound: 'default',
      channelId: 'default', data,
    }])
  } catch (err) {
    console.warn('sendCustomerPush error (non-fatal):', err instanceof Error ? err.message : err)
  }
}

// Push to many customers (e.g. result-declared broadcast). Dedupes tokens.
export async function sendPushToCustomers(
  customerIds: string[], title: string, body: string,
  data?: Record<string, unknown>,
): Promise<void> {
  if (!pushEnabled() || customerIds.length === 0) return
  try {
    const rows = await db.appCustomer.findMany({
      where: { id: { in: customerIds }, pushToken: { not: null } },
      select: { pushToken: true },
    })
    const tokens = [...new Set(rows.map(r => r.pushToken).filter(Boolean) as string[])]
    if (!tokens.length) return
    await sendExpoPush(tokens.map(to => ({
      to, title, body, sound: 'default' as const, channelId: 'default', data,
    })))
  } catch (err) {
    console.warn('sendPushToCustomers error (non-fatal):', err)
  }
}

// One-liner for existing call sites: writes the in-app AppNotification row
// (unchanged behaviour) and fires the push on top. Never throws.
export async function notifyCustomer(opts: {
  customerId: string
  icon: string
  text: string
  pushTitle?: string
  data?: Record<string, unknown>
}): Promise<void> {
  await db.appNotification.create({
    data: { customerId: opts.customerId, icon: opts.icon, text: opts.text },
  })
  await sendCustomerPush(
    opts.customerId,
    opts.pushTitle || 'Satta Matka God',
    opts.text,
    opts.data,
  )
}
