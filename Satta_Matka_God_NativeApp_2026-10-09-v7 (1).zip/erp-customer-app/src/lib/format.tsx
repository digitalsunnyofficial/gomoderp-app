import React from 'react'

// ────────────────────────────────────────
// MARKET COLORS
// ────────────────────────────────────────

export const MARKET_COLORS: Record<string, { bg: string; border: string; text: string; badge: string }> = {
  milan:     { bg: 'rgba(8,145,178,0.08)',   border: 'rgba(8,145,178,0.25)',   text: '#0891B2', badge: 'bg-[rgba(8,145,178,0.1)] text-[#0891B2]' },
  shridevi:  { bg: 'rgba(124,58,237,0.08)',  border: 'rgba(124,58,237,0.25)',  text: '#7C3AED', badge: 'bg-[rgba(124,58,237,0.1)] text-[#7C3AED]' },
  time:      { bg: 'rgba(5,150,105,0.08)',   border: 'rgba(5,150,105,0.25)',   text: '#059669', badge: 'bg-[rgba(5,150,105,0.1)] text-[#059669]' },
  kalyan:    { bg: 'rgba(217,119,6,0.08)',   border: 'rgba(217,119,6,0.25)',   text: '#D97706', badge: 'bg-[rgba(217,119,6,0.1)] text-[#D97706]' },
  rajdhani:  { bg: 'rgba(220,38,38,0.08)',   border: 'rgba(220,38,38,0.25)',   text: '#DC2626', badge: 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]' },
}

// ────────────────────────────────────────
// CUSTOM MARKETS
// ────────────────────────────────────────

export interface CustomMarket { label: string; color: string }
export const CUSTOM_MARKETS_STORAGE_KEY = 'erp_custom_markets_v1'
export const DEFAULT_CUSTOM_COLOR = '#9333EA'

export function loadCustomMarkets(): Record<string, CustomMarket> {
  if (typeof window === 'undefined') return {}
  try {
    const raw = window.localStorage.getItem(CUSTOM_MARKETS_STORAGE_KEY)
    if (!raw) return {}
    const parsed = JSON.parse(raw)
    if (parsed && typeof parsed === 'object') return parsed
  } catch { /* ignore */ }
  return {}
}

export function saveCustomMarkets(markets: Record<string, CustomMarket>): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(CUSTOM_MARKETS_STORAGE_KEY, JSON.stringify(markets))
  } catch { /* ignore */ }
}

export function getAllMarketKeys(): string[] {
  return [...Object.keys(MARKET_COLORS), ...Object.keys(loadCustomMarkets())]
}

export function getMarketLabel(key: string): string {
  if (MARKET_COLORS[key]) return key.charAt(0).toUpperCase() + key.slice(1)
  const custom = loadCustomMarkets()[key]
  return custom ? custom.label : key
}

// ────────────────────────────────────────
// FORMAT HELPERS
// ────────────────────────────────────────

export function formatCurrency(amount: number): string {
  if (amount >= 100000) return `₹ ${(amount / 100000).toFixed(1)}L`
  return `₹ ${amount.toLocaleString('en-IN')}`
}

export function formatDate(date: string | Date): string {
  const d = new Date(date)
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

export function formatDateTime(date: string | Date): string {
  const d = new Date(date)
  return d.toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
}

export function formatTime(date: string | Date): string {
  const d = new Date(date)
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
}

export function getCurrentTime(): string {
  const now = new Date()
  return now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
}

// Format panna digits: when 0 is part of the panna, it goes to the END
export function formatPanna(digits: number[]): string {
  if (digits.length > 0 && digits.every(d => d === 0)) {
    return digits.join('')
  }
  const sorted = [...digits].sort((a, b) => a - b)
  while (sorted.length > 0 && sorted[0] === 0) {
    sorted.shift()
    sorted.push(0)
  }
  return sorted.join('')
}

// Normalize a 3-digit number string to its 220 chart canonical form
export function normalizePanna(numStr: string): string {
  if (numStr.length !== 3) return numStr
  const digits = numStr.split('').map(Number)
  if (digits.some(d => isNaN(d))) return numStr
  return formatPanna(digits)
}

// ────────────────────────────────────────
// REUSABLE COMPONENTS
// ────────────────────────────────────────

export function MarketChip({ market, label }: { market: string; label: string }) {
  let colors = MARKET_COLORS[market]
  if (!colors) {
    const custom = loadCustomMarkets()[market]
    if (custom) {
      const hex = custom.color || DEFAULT_CUSTOM_COLOR
      const r = parseInt(hex.slice(1, 3), 16)
      const g = parseInt(hex.slice(3, 5), 16)
      const b = parseInt(hex.slice(5, 7), 16)
      colors = {
        bg: `rgba(${r},${g},${b},0.08)`,
        border: `rgba(${r},${g},${b},0.25)`,
        text: hex,
        badge: `bg-[rgba(${r},${g},${b},0.1)]`,
      }
    }
  }
  if (!colors) colors = MARKET_COLORS.shridevi
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border ${colors.badge || ''}`}
      style={{ background: colors.bg, borderColor: colors.border, color: colors.text }}
    >
      {label}
    </span>
  )
}

export function StatusBadge({ status }: { status: string }) {
  const config: Record<string, string> = {
    open: 'bg-[rgba(5,150,105,0.1)] text-[#059669]',
    closed: 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]',
    settled: 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]',
    pending: 'bg-[rgba(217,119,6,0.1)] text-[#D97706]',
  }
  const cls = config[status.toLowerCase()] || config.open
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${cls}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}
