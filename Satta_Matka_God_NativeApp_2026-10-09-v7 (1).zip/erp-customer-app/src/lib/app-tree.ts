import { db } from '@/lib/db'
import { RATE_LBL } from '@/lib/matka/app-engine'

// ──────────────────────────────────────────────────────────
// APP CUSTOMER HIERARCHY (Admin → Agent → Customer)
//
// Business rule (per operator):
//   • A customer who joins the app WITH an agent referral is filed
//     under that agent, and the agent's admin completes the tree.
//   • A customer who joins WITHOUT a referral falls under the
//     default agent (AppConfig key "default_agent") and that
//     agent's admin — the "default tree".
//   • If no default agent is configured / resolvable, the first
//     Super Admin becomes the direct admin of the customer.
// ──────────────────────────────────────────────────────────

export interface AgentTree {
  referral: string | null
  agentUsername: string | null
  agentName: string | null
  adminUsername: string | null
  adminName: string | null
}

async function firstSuperAdmin() {
  return db.user.findFirst({
    where: { role: 'super' },
    orderBy: { createdAt: 'asc' },
  })
}

async function resolveAgentByUsernameOrMobile(ref: string) {
  return db.user.findFirst({
    where: {
      role: 'user',
      isLocked: false,
      OR: [{ username: ref }, { phone: ref }],
    },
  })
}

export async function defaultAgentUsername(): Promise<string | null> {
  const cfg = await db.appConfig.findUnique({ where: { key: 'default_agent' } })
  const v = cfg?.value?.trim()
  return v || null
}

/** Resolve the full tree for a customer given an optional raw referral. */
export async function resolveAgentTree(referral?: string | null): Promise<AgentTree> {
  const raw = (referral || '').trim() || null
  let agent: { username: string; name: string | null; managerId: string | null } | null = null

  if (raw) {
    const found = await resolveAgentByUsernameOrMobile(raw)
    if (found) agent = { username: found.username, name: found.name, managerId: found.managerId }
  }
  if (!agent) {
    const def = await defaultAgentUsername()
    if (def) {
      const found = await db.user.findFirst({
        where: { role: 'user', username: def, isLocked: false },
      })
      if (found) agent = { username: found.username, name: found.name, managerId: found.managerId }
    }
  }

  if (agent) {
    const admin = agent.managerId
      ? await db.user.findUnique({ where: { id: agent.managerId } })
      : await firstSuperAdmin()
    return {
      referral: raw,
      agentUsername: agent.username,
      agentName: agent.name || agent.username,
      adminUsername: admin?.username || null,
      adminName: admin?.name || admin?.username || null,
    }
  }

  const superAdmin = await firstSuperAdmin()
  return {
    referral: raw,
    agentUsername: null,
    agentName: null,
    adminUsername: superAdmin?.username || null,
    adminName: superAdmin?.name || superAdmin?.username || null,
  }
}

/** Re-resolve and persist the tree for an existing customer (agent reassign). */
export async function applyAgentTree(customerId: string, referral?: string | null) {
  const tree = await resolveAgentTree(referral)
  return db.appCustomer.update({
    where: { id: customerId },
    data: {
      referral: tree.referral,
      agentUsername: tree.agentUsername,
      agentName: tree.agentName,
      adminUsername: tree.adminUsername,
      adminName: tree.adminName,
    },
  })
}

// ── Agent commission ───────────────────────────────────────
// Operator rule (2026-10): the agent earns X% of what their customers
// PLAY — NOT of what they deposit. Every placed bet (AppBet) is a play
// event: the wallet is debited and the agent's ledger is filed. A win
// only refills the customer wallet; the next play earns commission again.
// Rate precedence (ONE source of truth here):
//   1. The agent's own override (User.commissionRate, nullable)
//   2. The global rate the admin set (AppConfig "agent_commission_rate")
//   3. Nothing set anywhere → built-in default 2% (operator rule 2026-10:
//      "by default the rate will be 2%; when we set the percentage from
//      the admin then it will set"). Admin setting 0 explicitly = off.
export const AGENT_COMMISSION_RATE_KEY = 'agent_commission_rate'
export const DEFAULT_AGENT_COMMISSION_RATE = 2

export async function globalCommissionRate(): Promise<number> {
  const cfg = await db.appConfig.findUnique({ where: { key: AGENT_COMMISSION_RATE_KEY } })
  // Nothing set → built-in default (2%). A stored value is used as-is,
  // including an explicit 0 (admin deliberately turned commission off).
  if (!cfg || cfg.value === undefined || cfg.value === null || cfg.value === '') {
    return DEFAULT_AGENT_COMMISSION_RATE
  }
  const v = Number(cfg.value)
  return Number.isFinite(v) && v >= 0 ? v : DEFAULT_AGENT_COMMISSION_RATE
}

export async function resolveCommissionRate(agentUsername: string | null | undefined): Promise<number> {
  if (!agentUsername) return 0
  const agent = await db.user.findFirst({
    where: { username: agentUsername, role: 'user', isLocked: false },
    select: { commissionRate: true },
  })
  if (!agent) return 0
  // Explicit numeric override (including 0 = commission disabled for this
  // agent) wins; null/undefined override falls back to the global default.
  if (typeof agent.commissionRate === 'number') return agent.commissionRate
  return globalCommissionRate()
}

type CommissionDbLike = {
  agentCommission: { create: Function }
}

/**
 * File the play commission for ONE placed bet, inside the bet placement
 * transaction. Idempotent by construction: the caller creates exactly one
 * AppBet and passes it here once (betId is @unique in the ledger, so even
 * a bug-level double call can never file twice for the same bet).
 * Returns true when a commission row was created.
 */
export async function accruePlayCommission(
  client: CommissionDbLike,
  bet: { id: string; points: number; marketName: string; type: string; num: string },
  customer: {
    id: string; name: string | null; mobile: string | null
    agentUsername: string | null; agentName: string | null
  },
): Promise<boolean> {
  if (!customer.agentUsername) return false
  const rate = await resolveCommissionRate(customer.agentUsername)
  if (rate <= 0) return false
  await client.agentCommission.create({
    data: {
      agentUsername: customer.agentUsername,
      agentName: customer.agentName,
      customerId: customer.id,
      customerName: customer.name,
      customerMobile: customer.mobile,
      betId: bet.id,
      source: 'bet',
      baseAmount: bet.points,
      rate,
      amount: Math.round(bet.points * rate) / 100,
      marketName: bet.marketName,
      detail: `${RATE_LBL[bet.type] || bet.type} ${bet.num} · ${bet.marketName}`,
      status: 'pending',
    },
  })
  return true
}

// ── Configurable payout rates ──────────────────────────────
// The Payout Rates panel stores the live rate card in AppConfig
// "rates". Bets snapshot the rate at placement time, so editing
// rates only affects NEW bids (historic bids keep their rate).

export interface RateCard {
  main: { single: number; jodi: number; sp: number; dp: number; hs: number; fs: number }
  star: { single: number; oddeven: number; sp: number; dp: number; tp: number }
}

export const DEFAULT_RATES: RateCard = {
  main: { single: 9, jodi: 90, sp: 140, dp: 280, hs: 1500, fs: 8000 },
  star: { single: 9.5, oddeven: 1.95, sp: 140, dp: 280, tp: 700 },
}

export async function getRates(): Promise<RateCard> {
  const cfg = await db.appConfig.findUnique({ where: { key: 'rates' } })
  if (!cfg?.value) return DEFAULT_RATES
  try {
    const parsed = JSON.parse(cfg.value)
    return {
      main: { ...DEFAULT_RATES.main, ...(parsed.main || {}) },
      star: { ...DEFAULT_RATES.star, ...(parsed.star || {}) },
    }
  } catch {
    return DEFAULT_RATES
  }
}

export function rateFromCard(card: RateCard, marketCode: string, type: string): number {
  const fam = marketCode.startsWith('st') ? card.star : card.main
  return (fam as Record<string, number>)[type] ?? (marketCode.startsWith('st') ? card.star.single : card.main.single)
}
