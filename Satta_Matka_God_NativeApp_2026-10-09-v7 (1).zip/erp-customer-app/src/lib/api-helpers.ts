// ────────────────────────────────────────
// API HELPERS
// ────────────────────────────────────────

export async function apiFetch(url: string, options?: RequestInit) {
  let authHeaders: Record<string, string> = {}
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem('erp_user')
      if (raw) {
        const u = JSON.parse(raw)
        if (u && typeof u === 'object') {
          if (u.id) authHeaders['x-user-id'] = String(u.id)
          if (u.username) authHeaders['x-user-name'] = String(u.username)
          if (u.role) authHeaders['x-user-role'] = String(u.role)
          if (u.assignedMarkets !== undefined) authHeaders['x-user-markets'] = String(u.assignedMarkets || '')
        }
      }
    } catch { /* ignore parse errors */ }
  }

  const res = await fetch(url, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders,
      ...options?.headers,
    },
  })
  if (!res.ok) {
    if (res.status === 401) {
      if (url === '/api/auth' || url === '/api/auth/signup') {
        const err = await res.json().catch(() => ({ error: 'Unauthorized' }))
        throw new Error(err.error || 'Unauthorized')
      }
      if (typeof window !== 'undefined') {
        try { localStorage.removeItem('erp_user') } catch {}
      }
      throw new Error('Session expired — please log in again')
    }
    const err = await res.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(err.error || 'Request failed')
  }
  return res.json()
}

/**
 * Record ParserException entries for SKIPPED and DROPPED parser output.
 * Non-fatal — failures are just logged to console.
 */
export async function recordParserExceptions(params: {
  uploadedBy: string
  uploadedByUserId?: string
  market?: string | null
  inventoryCodeId?: string | null
  originalText: string
  skippedNumbers?: string[]
  droppedTokens?: string[]
}): Promise<void> {
  const { uploadedBy, uploadedByUserId, market, inventoryCodeId, originalText, skippedNumbers, droppedTokens } = params
  const skipCount = skippedNumbers?.length || 0
  const dropCount = droppedTokens?.length || 0
  if (skipCount === 0 && dropCount === 0) return

  const tasks: Promise<unknown>[] = []

  if (skipCount > 0 && skippedNumbers) {
    tasks.push(
      apiFetch('/api/parser-exceptions', {
        method: 'POST',
        body: JSON.stringify({
          uploadedBy,
          uploadedByUserId: uploadedByUserId || null,
          originalText: originalText.slice(0, 8000),
          market: market || null,
          inventoryCodeId: inventoryCodeId || null,
          reason: 'missing_rate',
          kind: 'skipped',
          rawNumber: skippedNumbers.join(',').slice(0, 500),
          parsedData: JSON.stringify({ skippedNumbers }),
        }),
      }).catch(err => console.error('[parser-exceptions] failed to record skipped:', err))
    )
  }

  if (dropCount > 0 && droppedTokens) {
    tasks.push(
      apiFetch('/api/parser-exceptions', {
        method: 'POST',
        body: JSON.stringify({
          uploadedBy,
          uploadedByUserId: uploadedByUserId || null,
          originalText: originalText.slice(0, 8000),
          market: market || null,
          inventoryCodeId: inventoryCodeId || null,
          reason: 'invalid_syntax',
          kind: 'dropped',
          rawNumber: droppedTokens.join(',').slice(0, 500),
          parsedData: JSON.stringify({ droppedTokens }),
        }),
      }).catch(err => console.error('[parser-exceptions] failed to record dropped:', err))
    )
  }

  await Promise.all(tasks)
}

/**
 * Log a chart revision to /api/chart-revisions.
 * Non-fatal — if this fails the chart action still succeeded.
 */
export async function logChartRevision(params: {
  chartId: string
  action: 'save' | 'share' | 'regenerate' | 'edit' | 'reset'
  summary?: string
  previousData?: Record<string, unknown>
  newData?: Record<string, unknown>
}): Promise<void> {
  let editedBy = 'unknown'
  let editedByUserId: string | undefined
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem('erp_user')
      if (raw) {
        const u = JSON.parse(raw)
        if (u && typeof u === 'object') {
          if (u.username) editedBy = String(u.username)
          if (u.id) editedByUserId = String(u.id)
        }
      }
    } catch { /* ignore */ }
  }
  try {
    await apiFetch('/api/chart-revisions', {
      method: 'POST',
      body: JSON.stringify({
        chartId: params.chartId,
        editedBy,
        editedByUserId: editedByUserId || null,
        action: params.action,
        previousData: params.previousData || null,
        newData: params.newData || null,
        summary: params.summary || null,
      }),
    })
  } catch (err) {
    console.error('[chart-revisions] failed to log:', err)
  }
}
