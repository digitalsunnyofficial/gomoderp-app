// ────────────────────────────────────────────────────────────
// Chitthi Generator — renders the traditional handwritten vyapar
// slip ("chitthi") as a JPEG that looks like the operator's sample:
// a hand holding a small paper slip with blue-ink handwriting,
// two columns of numbers with rates ("680×50"), underlined section
// headers and the grand total circled at the bottom.
//
// Implementation: @napi-rs/canvas (prebuilt binaries — runs on the
// sandbox, VS Code machines and Hostinger alike, no browser needed).
// The background photo (hand holding a blank slip) ships in
// public/chitthi/chitthi-bg.jpg; handwriting is the Caveat font
// shipped in public/chitthi/fonts/Caveat.ttf.
//
// Rendering is seeded — the same chitthi id always produces the same
// image, while different chitthis get different natural hand jitter.
// ────────────────────────────────────────────────────────────

import { createCanvas, GlobalFonts, loadImage, type SKRSContext2D } from '@napi-rs/canvas'
import path from 'path'
import fs from 'fs'
import type { UnifiedParseResult } from '@/lib/matka/entry-parser'

// ── Geometry of the writing area on the background photo (percentages) ──
// Tuned for public/chitthi/chitthi-bg.jpg (768×1344, tall slip held by hand).
const PAPER = { x0: 0.225, y0: 0.225, x1: 0.775, y1: 0.735 }
const BG_FILE = 'chitthi-bg.jpg'
const FONT_FAMILY = 'Caveat'

let fontRegistered = false
function ensureFont(): void {
  if (fontRegistered) return
  const fontPath = path.join(process.cwd(), 'public', 'chitthi', 'fonts', 'Caveat.ttf')
  if (fs.existsSync(fontPath)) {
    GlobalFonts.registerFromPath(fontPath, FONT_FAMILY)
  }
  fontRegistered = true
}

// ── Seeded PRNG (mulberry32) so re-renders of the same chitthi match ──
function makeRng(seedStr: string): () => number {
  let h = 1779033703 ^ seedStr.length
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353)
    h = (h << 13) | (h >>> 19)
  }
  let a = h >>> 0
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const INK = 'rgba(28, 44, 150, 0.92)'

// ── Content model ────────────────────────────────────────────

export interface ChitthiEntry {
  n: string // number as written (canonical spelling preserved)
  a: number // amount (rate) for this number
}

export interface ChitthiSection {
  /** Optional section header drawn with a hand underline (e.g. "Motor Pana") */
  label?: string
  /** Parsed entries for this section */
  entries: ChitthiEntry[]
}

export interface ChitthiContent {
  market: string
  date: string
  customerName?: string
  sections: ChitthiSection[]
  total: number
}

type FlatItem = { kind: 'label'; text: string } | { kind: 'line'; text: string }

function formatAmount(a: number): string {
  return Number.isInteger(a) ? String(a) : String(Math.round(a * 100) / 100)
}

/**
 * Build the chitthi content from a parseUnifiedEntry result.
 * Mirrors how operators write slips: numbers with their amounts,
 * grouped by game class, total at the bottom.
 */
export function buildChitthiContent(
  parse: UnifiedParseResult,
  market: string,
  date: string,
  customerName?: string
): ChitthiContent {
  const sections: ChitthiSection[] = []

  const push = (label: string, entries: Array<{ number: string; amount: number }>) => {
    if (entries.length) sections.push({ label, entries: entries.map(e => ({ n: e.number, a: e.amount })) })
  }

  push('Single', parse.singles)
  push('Jodi', parse.doubles)
  push('Panna', parse.triples)
  push('Common', parse.common)
  for (const g of parse.groups) push(g.option, g.entries)

  const total =
    parse.singles.concat(parse.doubles, parse.triples, parse.common).reduce((s, e) => s + e.amount, 0) +
    parse.groups.reduce((s, g) => s + g.entries.reduce((x, e) => x + e.amount, 0), 0)

  return { market, date, customerName, sections, total }
}

// ── Drawing helpers ──────────────────────────────────────────

function handLine(ctx: SKRSContext2D, rng: () => number, x: number, y: number, w: number): void {
  // Slightly wobbly hand-drawn underline (quadratic through a jittered mid point)
  const mx = x + w / 2 + (rng() - 0.5) * 4
  const my = y + 2 + (rng() - 0.5) * 3
  ctx.beginPath()
  ctx.moveTo(x, y + (rng() - 0.5) * 2)
  ctx.quadraticCurveTo(mx, my, x + w, y + (rng() - 0.5) * 2)
  ctx.stroke()
}

function drawTotal(ctx: SKRSContext2D, rng: () => number, cx: number, cy: number, total: number, size: number): void {
  const text = formatAmount(total)
  ctx.save()
  ctx.font = `600 ${Math.round(size * 1.5)}px ${FONT_FAMILY}`
  ctx.fillStyle = INK
  ctx.translate(cx, cy)
  ctx.rotate((rng() - 0.5) * 0.06)
  const w = ctx.measureText(text).width
  ctx.fillText(text, -w / 2, size * 0.5)
  // Hand-drawn ellipse (the operator circles the total)
  ctx.lineWidth = Math.max(2, size * 0.09)
  ctx.beginPath()
  const rx = w / 2 + size * 0.55
  const ry = size * 1.05
  ctx.moveTo(-rx + size * 0.2, 0)
  ctx.bezierCurveTo(-rx, -ry, rx, -ry, rx, 0)
  ctx.bezierCurveTo(rx, ry, -rx, ry, -rx + size * 0.2, 0)
  ctx.stroke()
  ctx.restore()
}

// ── Main renderer ────────────────────────────────────────────

/**
 * Render the chitthi JPEG. Returns the encoded JPEG buffer.
 * Throws when the background asset is missing (deployment error).
 */
export async function renderChitthiJpeg(content: ChitthiContent, seed = String(Date.now())): Promise<Buffer> {
  ensureFont()
  const bgPath = path.join(process.cwd(), 'public', 'chitthi', BG_FILE)
  if (!fs.existsSync(bgPath)) throw new Error(`Chitthi background missing: ${bgPath}`)
  const bg = await loadImage(bgPath)

  const W = bg.width, H = bg.height
  const areaX = PAPER.x0 * W, areaY = PAPER.y0 * H
  const areaW = (PAPER.x1 - PAPER.x0) * W
  const areaH = (PAPER.y1 - PAPER.y0) * H
  const colGap = areaW * 0.06

  const canvas = createCanvas(W, H)
  const ctx = canvas.getContext('2d')
  ctx.drawImage(bg, 0, 0, W, H)
  const rng = makeRng(seed + content.market + content.date + content.total)

  // Flatten sections. Long slips (like a 92-panna motor chitthi) are COMPACTED
  // the way operators write them: same-rate numbers share a line —
  // "234 237 245 ×100" — so everything still fits on the physical slip.
  const totalPerLine = content.sections.reduce((s, sec) => s + sec.entries.length + (sec.label ? 1 : 0), 0)
  const compact = totalPerLine > 40
  const items: FlatItem[] = []
  for (const s of content.sections) {
    if (s.label) items.push({ kind: 'label', text: s.label })
    if (!compact) {
      for (const e of s.entries) items.push({ kind: 'line', text: `${e.n}×${formatAmount(e.a)}` })
    } else {
      // Pack consecutive equal-amount entries, max 6 numbers per line —
      // reads like a real slip: "234 235 237 238 245 248×100"
      let count = 0
      let bufAmt: number | null = null
      let buf = ''
      const flush = () => {
        if (bufAmt !== null && buf) items.push({ kind: 'line', text: `${buf.trim()}×${formatAmount(bufAmt)}` })
        buf = ''
        bufAmt = null
        count = 0
      }
      for (const e of s.entries) {
        if (bufAmt !== null && (e.a !== bufAmt || count >= 6)) flush()
        bufAmt = e.a
        buf = `${buf}${e.n}  `
        count++
      }
      flush()
      if (!s.entries.length) items.push({ kind: 'line', text: '-' })
    }
  }
  if (!items.length) items.push({ kind: 'line', text: '-' })

  // Header metrics
  const headerSize = Math.round(areaH * 0.062)
  const customerSize = Math.round(headerSize * 0.62)
  const headerBlock = headerSize * 1.3 + (content.customerName ? customerSize * 1.25 : 0)

  // Pick the largest font size that fits in ≤ 2 columns
  const usableH = areaH - headerBlock - areaH * 0.13 // leave room for the circled total
  const candidates = [46, 42, 38, 34, 30, 27, 24, 21, 18, 16]
  let fontSize = candidates[candidates.length - 1]
  let rowsPerCol = 1
  let twoCols = false
  const colW = (isTwo: boolean) => (isTwo ? (areaW - colGap) / 2 : areaW)

  const probe = createCanvas(8, 8).getContext('2d')
  for (const size of candidates) {
    const l = size * 1.18
    const rows = Math.max(1, Math.floor(usableH / l))
    const cols = Math.ceil(items.length / rows)
    const cw = colW(cols > 1)
    probe.font = `${size}px ${FONT_FAMILY}`
    const widest = Math.max(...items.map(i => probe.measureText(i.text).width), size * 2)
    if (cols <= 2 && widest < cw) {
      fontSize = size
      rowsPerCol = rows
      twoCols = cols > 1
      break
    }
  }
  const lh = fontSize * 1.18
  const cw = colW(twoCols)

  // Header: market (left) + date (right) with hand underline, like "KB  14/5"
  ctx.fillStyle = INK
  ctx.strokeStyle = INK
  ctx.lineWidth = Math.max(1.4, fontSize * 0.055)
  ctx.textBaseline = 'alphabetic'

  ctx.font = `600 ${Math.round(headerSize * 1.12)}px ${FONT_FAMILY}`
  const jitterH = (rng() - 0.5) * 3
  ctx.save()
  ctx.translate(areaX + jitterH, areaY + headerSize)
  ctx.rotate((rng() - 0.5) * 0.02)
  const marketText = content.market.toUpperCase()
  ctx.fillText(marketText, 0, 0)
  ctx.font = `600 ${Math.round(headerSize)}px ${FONT_FAMILY}`
  const dateText = content.date
  const dateW = ctx.measureText(dateText).width
  ctx.fillText(dateText, areaW - dateW, 0)
  handLine(ctx, rng, 0, 6, areaW - 4)
  ctx.restore()

  let cursorY = areaY + headerSize * 1.3
  if (content.customerName) {
    ctx.font = `${customerSize}px ${FONT_FAMILY}`
    ctx.save()
    ctx.translate(areaX + (rng() - 0.5) * 2, cursorY + customerSize)
    ctx.rotate((rng() - 0.5) * 0.02)
    ctx.fillText(content.customerName, 0, 0)
    ctx.restore()
    cursorY += customerSize * 1.25
  }

  // Items — column by column (left column filled first), per-line hand jitter
  const colXs = twoCols ? [areaX, areaX + cw + colGap] : [areaX]
  ctx.font = `${fontSize}px ${FONT_FAMILY}`
  items.forEach((item, idx) => {
    const col = Math.min(Math.floor(idx / rowsPerCol), colXs.length - 1)
    const rowInCol = idx - col * rowsPerCol
    const x = colXs[col]
    const y = cursorY + rowInCol * lh + fontSize * 0.9

    ctx.save()
    ctx.translate(x + (rng() - 0.5) * 4, y + (rng() - 0.5) * 3)
    ctx.rotate((rng() - 0.5) * 0.035)
    if (item.kind === 'label') {
      ctx.font = `600 ${Math.round(fontSize * 0.92)}px ${FONT_FAMILY}`
      ctx.fillText(item.text, 0, 0)
      const w = ctx.measureText(item.text).width
      handLine(ctx, rng, 0, 3, w + 6)
      ctx.font = `${fontSize}px ${FONT_FAMILY}`
    } else if (compact) {
      ctx.fillText(item.text, 0, 0)
    } else {
      ctx.fillText(item.text, fontSize * 0.35, 0)
    }
    ctx.restore()
  })

  // Circled total — bottom-right of the writing area (like the sample's 800)
  drawTotal(ctx, rng, areaX + areaW * 0.72, areaY + areaH - areaH * 0.055, content.total, fontSize)

  const jpeg = await canvas.encode('jpeg', 88)
  return Buffer.from(jpeg)
}

/** Where rendered chitthi JPGs live (project-root relative, portable). */
export function chitthiStorageDir(): string {
  const dir = path.join(process.cwd(), 'storage', 'chitthi')
  fs.mkdirSync(dir, { recursive: true })
  return dir
}

/** IST date string YYYY-MM-DD for the slip default. */
export function istToday(): string {
  const now = new Date(Date.now() + 5.5 * 3600 * 1000)
  return now.toISOString().slice(0, 10)
}

/** Display date on the slip: DD/MM (traditional chitthi style). */
export function slipDateDisplay(iso: string): string {
  const [y, m, d] = iso.split('-')
  if (!y || !m || !d) return iso
  return `${d}/${m}`
}
