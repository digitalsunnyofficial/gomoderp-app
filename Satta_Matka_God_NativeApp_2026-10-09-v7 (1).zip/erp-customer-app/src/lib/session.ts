/**
 * Edge-safe session utilities ONLY.
 *
 * This file is imported by src/middleware.ts (Edge runtime) and must NOT
 * import anything that touches Prisma, fs, or process.on.
 * It also must NOT use Node's `crypto` module — use Web Crypto API instead.
 *
 * The DB-touching helpers (getCurrentUser, requireAuth, logActivity, etc.)
 * live in src/lib/auth.ts and are only imported by API routes (Node runtime).
 */
import { NextRequest, NextResponse } from 'next/server'
import { isSuperRole } from './roles'

const SESSION_COOKIE = 'erp_session'
const SESSION_SECRET = process.env.SESSION_SECRET || 'matka-erp-dev-secret-change-me-2026'

// Web Crypto API (works in both Edge and Node runtimes)
async function sign(payload: string): Promise<string> {
  const enc = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(SESSION_SECRET),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(payload))
  // Convert ArrayBuffer to hex
  const bytes = new Uint8Array(sig)
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('')
}

function base64Encode(s: string): string {
  return btoa(unescape(encodeURIComponent(s)))
}

function base64Decode(s: string): string {
  return decodeURIComponent(escape(atob(s)))
}

export async function createSessionToken(user: { id: string; username: string; role: string }, sessionDbId?: string): Promise<string> {
  const payload = JSON.stringify({ id: user.id, username: user.username, role: user.role, ts: Date.now(), sid: sessionDbId || '' })
  const b64 = base64Encode(payload)
  return `${b64}.${await sign(b64)}`
}

export async function verifySessionToken(token: string | undefined | null): Promise<{ id: string; username: string; role: string } | null> {
  if (!token || typeof token !== 'string') return null
  const parts = token.split('.')
  if (parts.length !== 2) return null
  const [b64, sig] = parts
  const expected = await sign(b64)
  if (sig.length !== expected.length) return null
  let diff = 0
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i)
  if (diff !== 0) return null
  try {
    const payload = JSON.parse(base64Decode(b64))
    if (!payload.id || !payload.username || !payload.role) return null
    return payload
  } catch {
    return null
  }
}

export async function setSessionCookie(response: NextResponse, user: { id: string; username: string; role: string }, sessionDbId?: string): Promise<NextResponse> {
  const token = await createSessionToken(user, sessionDbId)
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  })
  return response
}

export function clearSessionCookie(response: NextResponse): NextResponse {
  response.cookies.set(SESSION_COOKIE, '', { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 0 })
  return response
}

export async function getSessionFromRequest(req: NextRequest): Promise<{ id: string; username: string; role: string } | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value
  return verifySessionToken(token)
}

export function parseMarkets(raw: string | null | undefined): string[] {
  if (!raw) return []
  return raw.split(',').map(s => s.trim()).filter(Boolean)
}

export function canAccessMarket(user: { role: string; assignedMarkets: string }, market: string | null | undefined): boolean {
  if (!market) return true
  if (isSuperRole(user.role)) return true
  const markets = parseMarkets(user.assignedMarkets)
  return markets.includes(market) || markets.includes('*')
}

export const KNOWN_MARKETS = ['milan', 'shridevi', 'time', 'kalyan', 'rajdhani'] as const
export type MarketKey = typeof KNOWN_MARKETS[number]

