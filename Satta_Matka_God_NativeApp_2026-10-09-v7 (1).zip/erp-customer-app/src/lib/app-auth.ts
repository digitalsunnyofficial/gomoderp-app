import { db } from '@/lib/db'
import crypto from 'crypto'

// ──────────────────────────────────────────────────────────
// CUSTOMER APP AUTH — Bearer-token session helper
// ──────────────────────────────────────────────────────────

export const APP_SESSION_DAYS = 90

export function newAppToken(): string {
  return crypto.randomBytes(32).toString('hex')
}

export function appSessionExpiry(): Date {
  return new Date(Date.now() + APP_SESSION_DAYS * 24 * 3600 * 1000)
}

export interface AppCustomerSafe {
  id: string
  name: string
  mobile: string
  wallet: number
  status: string
  canBet: boolean
  canWithdraw: boolean
  language: string
  approvalStatus: string
  agentName?: string | null
  createdAt: Date
}

export function toSafeCustomer(c: {
  id: string; name: string; mobile: string; wallet: number
  status: string; canBet: boolean; canWithdraw: boolean
  language?: string | null; approvalStatus?: string; agentName?: string | null; createdAt: Date
}): AppCustomerSafe {
  return {
    id: c.id, name: c.name, mobile: c.mobile, wallet: c.wallet,
    status: c.status, canBet: c.canBet, canWithdraw: c.canWithdraw,
    language: c.language || '', approvalStatus: c.approvalStatus || 'approved',
    agentName: c.agentName || null, createdAt: c.createdAt,
  }
}

/** Resolve the AppCustomer from the Authorization: Bearer token. Returns null when invalid/expired/blocked. */
export async function getAppCustomer(request: Request) {
  const auth = request.headers.get('authorization') || ''
  const token = auth.toLowerCase().startsWith('bearer ') ? auth.slice(7).trim() : ''
  if (!token) return null
  const session = await db.appSession.findUnique({
    where: { token },
    include: { customer: true },
  })
  if (!session) return null
  if (session.expiresAt.getTime() < Date.now()) {
    await db.appSession.delete({ where: { id: session.id } }).catch(() => {})
    return null
  }
  if (session.customer.status === 'blocked') return null
  // Sliding expiry
  await db.appSession.update({
    where: { id: session.id },
    data: { expiresAt: appSessionExpiry() },
  }).catch(() => {})
  return session.customer
}

export function appUnauthorized() {
  return Response.json({ error: 'Please log in to continue' }, { status: 401 })
}

// ──────────────────────────────────────────────────────────
// SIGNUP APPROVAL TOGGLE — Master Admin provision
// ──────────────────────────────────────────────────────────
// AppConfig key "signup_approval_required":
//   "true"  (default) → new app signups stay "pending" until a superior
//                       approves them from the ERP Customer List (Task-2 flow)
//   "false"           → new signups are approved instantly and can log in
//                       straight from registration — no approval needed
// The toggle only affects NEW signups; existing pending customers are still
// approved/rejected manually from the Customer List.
export const SIGNUP_APPROVAL_KEY = 'signup_approval_required'

export async function isSignupApprovalRequired(): Promise<boolean> {
  const cfg = await db.appConfig
    .findUnique({ where: { key: SIGNUP_APPROVAL_KEY } })
    .catch(() => null)
  // Missing setting → current behaviour (approval required)
  return cfg ? cfg.value !== 'false' : true
}

/** Record a wallet transaction + update balance. Pass `tx` (Prisma transaction client) to run inside a transaction. */
export async function appWalletMove(
  client: DbLike,
  customerId: string,
  type: string,
  amount: number, // + credit, − debit
  remark: string
): Promise<number> {
  const customer = await client.appCustomer.update({
    where: { id: customerId },
    data: { wallet: { increment: amount } },
  })
  await client.appTransaction.create({
    data: { customerId, type, amount, balanceAfter: customer.wallet, remark },
  })
  return customer.wallet as number
}

type DbLike = {
  appCustomer: { update: Function }
  appTransaction: { create: Function }
}
