import { db } from '@/lib/db'
import { marketDisplayName } from '@/lib/matka/app-engine'

// ──────────────────────────────────────────────────────────
// ERP MIRROR — the single-source vyapar bridge.
// Every bet placed in the Customer App is mirrored into the
// ERP inventory system (Inventory → TripleInventory /
// DoubleSingleInventory rows), so app vyapar shows up in the
// ERP Entry List and feeds the ERP single/double/triple charts
// exactly like a WhatsApp paste would. One source of truth:
// the same central pipeline (Input → Normalize → … → Update
// Inventory) serves both channels.
//
// ── CANONICAL MARKET LINK ──
// AppMarket is THE single market source. Mirror rows never form
// a parallel market system: every derived InventoryCode carries
// `marketCode` = AppMarket.code and a full session display name
// ("Sridevi Day Open"). Legacy rows (created before the link)
// are migrated in place on first touch; historical rows without
// a marketCode stay untouched.
//
// ── CONSOLIDATED ENTRY (one list per market session) ──
// The Entry List holds ONE card per market session per day, and
// each card holds ONE row per (game class × slot) for the whole
// app channel — NOT one row per customer placement. Even 100+
// customers betting on Sridevi Day Open produce exactly one
// triple row + one single row + one double row. "Submitted By"
// on the card and its rows is the channel itself ("app"); who
// bet what lives INSIDE the row: parsedData.byCustomer maps
// number → customer → points and parsedData.customers lists
// every contributor. The ERP single/double/triple lists render
// that breakdown next to each number, and the final chart board
// is prepared from this single consolidated list.
// ──────────────────────────────────────────────────────────

export interface MirrorBet {
  marketCode: string
  marketName: string
  betDate: string // "2026-09-26" (IST)
  slot: string    // "open" | "close" | "jodi" | "hs" | "fs"
  type: string    // "single" | "jodi" | "sp" | "dp" | "tp" | "hs" | "hsb" | "fs"
  num: string
  points: number
  gameCode?: string | null
}

const SANGAM_TYPES = new Set(['hs', 'hsb', 'fs'])

// Submitted By for every mirrored card/row — the Customer App
// channel itself, not any single customer or operator account.
// Per-customer attribution lives inside the rows (byCustomer).
const APP_OWNER = 'app'

interface NumCell { number: string; price: number; count: number }

interface AppParsedData {
  entries?: Array<{ number: string; price: number; sangam?: boolean }>
  numbers?: Array<{ number: string; price: number }>
  byCustomer?: Record<string, Record<string, number>>
  customers?: string[]
  totalEntriesCount?: number
  source?: string
  marketCode?: string
  slot?: string
  gameCodes?: string[]
  [k: string]: unknown
}

function dayRange(isoDate: string): { start: Date; end: Date } {
  // Matches the ERP convention: new Date("YYYY-MM-DD") = midnight UTC
  const start = new Date(isoDate + 'T00:00:00.000Z')
  const end = new Date(start.getTime() + 86400000)
  return { start, end }
}

// AppMarket (name × phase × session) → ERP InventoryCode.type
function erpTypeFor(phase?: string | null, session?: string | null): string {
  const isNight = (phase || 'day') === 'night'
  const isClose = (session || 'open') === 'close'
  if (isNight) return isClose ? 'night-close' : 'night-open'
  return isClose ? 'close' : 'open'
}

/**
 * Resolve the canonical InventoryCode for an app market.
 * 1. Linked row via marketCode (canonical path).
 * 2. Legacy "app_<code>" row → migrate in place (set marketCode, refresh
 *    name/market/type to the canonical identity).
 * 3. Create the derived row, linked from birth.
 */
async function resolveInventoryCode(marketCode: string, displayName: string, baseName: string, erpType: string) {
  const linked = await db.inventoryCode.findFirst({ where: { marketCode } })
  if (linked) {
    // Keep identity fields fresh (rename-safe); marketCode stays the key.
    if (linked.name !== displayName || linked.market !== baseName || linked.type !== erpType) {
      await db.inventoryCode.update({
        where: { id: linked.id },
        data: { name: displayName, market: baseName, type: erpType },
      })
    }
    return linked
  }

  const codeId = `app_${marketCode}`
  const legacy = await db.inventoryCode.findUnique({ where: { code: codeId } })
  if (legacy) {
    await db.inventoryCode.update({
      where: { id: legacy.id },
      data: { name: displayName, market: baseName, type: erpType, marketCode },
    })
    return { ...legacy, name: displayName, market: baseName, type: erpType, marketCode }
  }

  return db.inventoryCode.create({
    data: {
      code: codeId,
      name: displayName,
      market: baseName,
      marketCode,
      type: erpType,
    },
  })
}

// Aggregate a bet subset: per-number totals + per-customer attribution.
// Numbers sort in ascending order so the consolidated row reads
// deterministically no matter which customer bet first.
function aggregateBets(bets: MirrorBet[], customerKey: string) {
  const m = new Map<string, NumCell>()
  const byCustomer: Record<string, Record<string, number>> = {}
  let count = 0
  for (const b of bets) {
    const cell = m.get(b.num) || { number: b.num, price: 0, count: 0 }
    cell.price += b.points
    cell.count += 1
    m.set(b.num, cell)
    const perNum = byCustomer[b.num] || (byCustomer[b.num] = {})
    perNum[customerKey] = (perNum[customerKey] || 0) + b.points
    count += 1
  }
  const cells = [...m.values()].sort((a, b) => a.number.localeCompare(b.number))
  return { cells, byCustomer, count }
}

// Merge incoming numbers into a row's existing numbers map
// (existing rows win the base values, incoming points are added).
function mergedNumbers(pd: AppParsedData, cells: NumCell[]): Array<{ number: string; price: number }> {
  const numMap = new Map<string, number>()
  for (const n of pd.numbers || []) {
    const p = Number(n.price || 0)
    if (!p) continue
    numMap.set(n.number, (numMap.get(n.number) || 0) + p)
  }
  for (const c of cells) numMap.set(c.number, (numMap.get(c.number) || 0) + c.price)
  return [...numMap.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([number, price]) => ({ number, price }))
}

// Deep-merge the incoming per-customer attribution into the row's map
function mergedByCustomer(pd: AppParsedData, inc: Record<string, Record<string, number>>) {
  const out: Record<string, Record<string, number>> = pd.byCustomer
    ? (JSON.parse(JSON.stringify(pd.byCustomer)) as Record<string, Record<string, number>>)
    : {}
  for (const [num, custs] of Object.entries(inc)) {
    out[num] = out[num] || {}
    for (const [ck, pts] of Object.entries(custs)) {
      out[num][ck] = (out[num][ck] || 0) + pts
    }
  }
  return out
}

/**
 * Mirror placed app bets into the ERP inventory system as ONE
 * consolidated entry per market session.
 * Best-effort AFTER the bet transaction commits: any failure logs and
 * returns { ok:false } WITHOUT blocking the customer's bet placement.
 */
export async function mirrorBetsToErpInventory(
  bets: MirrorBet[],
  customerName: string,
  customerMobile: string
): Promise<{ ok: boolean; rows: number; error?: string }> {
  try {
    if (!bets.length) return { ok: true, rows: 0 }
    const customerKey = customerMobile ? `${customerName} (${customerMobile})` : customerName

    // Group bets per market+date — one ERP inventory (card) per market/day
    const groups = new Map<string, MirrorBet[]>()
    for (const b of bets) {
      const key = `${b.marketCode}|${b.betDate}`
      const arr = groups.get(key) || []
      arr.push(b)
      groups.set(key, arr)
    }

    let rows = 0
    for (const [key, groupBets] of groups) {
      const [marketCode, betDate] = key.split('|')
      const isStar = marketCode.startsWith('st')

      // ── Canonical identity from the ONE market source ──
      const marketRow = isStar ? null : await db.appMarket.findUnique({ where: { code: marketCode } })
      const displayName = marketRow
        ? marketDisplayName(marketRow)
        : (groupBets[0].marketName || marketCode)
      const baseName = marketRow?.name || groupBets[0].marketName || marketCode
      const erpType = isStar ? 'open' : erpTypeFor(marketRow?.phase, marketRow?.session)

      const invCode = await resolveInventoryCode(marketCode, displayName, baseName, erpType)

      // ── Inventory: today's open card for that code (create when missing) ──
      const { start, end } = dayRange(betDate)
      let inventory = await db.inventory.findFirst({
        where: { inventoryCodeId: invCode.id, status: 'open', date: { gte: start, lt: end } },
        orderBy: { createdAt: 'desc' },
      })
      if (!inventory) {
        inventory = await db.inventory.create({
          data: {
            date: start,
            inventoryCodeId: invCode.id,
            status: 'open',
            remark: isStar ? `Customer App — Starline · ${displayName}` : `Customer App — auto card · ${displayName}`,
            createdBy: APP_OWNER,
          },
        })
      } else if (inventory.createdBy !== APP_OWNER) {
        // Older cards carried a single customer/operator name in Submitted
        // By — the consolidated entry belongs to the channel itself.
        await db.inventory.update({ where: { id: inventory.id }, data: { createdBy: APP_OWNER } })
        inventory = { ...inventory, createdBy: APP_OWNER }
      }

      // ── Route bets: panna classes → Triple, single/jodi → DoubleSingle,
      //    sangam composites → Triple with type 'sangam' ──
      const pannaBets = groupBets.filter(b => ['sp', 'dp', 'tp'].includes(b.type))
      const digitBets = groupBets.filter(b => ['single', 'jodi'].includes(b.type))
      const sangamBets = groupBets.filter(b => SANGAM_TYPES.has(b.type))

      const mkDetails = (what: string, custCount: number) =>
        `Customer App · ${displayName} · ${what} · ${custCount} customer${custCount === 1 ? '' : 's'}`

      // Split by slot FIRST — one consolidated row per (class × slot).
      // Classic TP books slot 'close' from an open-session screen, so a
      // card can legitimately hold both an open-slot and a close-slot
      // panna row; they must never merge.
      const bySlot = (list: MirrorBet[]): Array<[string, MirrorBet[]]> => {
        const m = new Map<string, MirrorBet[]>()
        for (const b of list) {
          const arr = m.get(b.slot) || []
          arr.push(b)
          m.set(b.slot, arr)
        }
        return [...m.entries()]
      }

      // Merge (or create) the consolidated Triple row for one class+slot.
      // Returns 1 (row written) so the caller can report activity.
      const mergeTripleRow = async (type: 'mix' | 'sangam', slot: string, sub: MirrorBet[], what: string): Promise<number> => {
        if (!sub.length) return 0
        const agg = aggregateBets(sub, customerKey)
        const numbers = agg.cells.map(c => ({ number: c.number, price: c.price }))
        const total = numbers.reduce((a, n) => a + n.price, 0)
        const gameCodes = [...new Set(sub.map(b => b.gameCode).filter(Boolean))] as string[]
        return db.$transaction(async (tx) => {
          const candidates = await tx.tripleInventory.findMany({ where: { inventoryId: inventory.id, type } })
          let target: (typeof candidates)[number] | null = null
          for (const r of candidates) {
            try {
              const pd = JSON.parse(r.parsedData || '{}') as AppParsedData
              if (pd.source === 'customer-app' && pd.marketCode === marketCode && (pd.slot || '') === slot) {
                target = r
                break
              }
            } catch { /* skip malformed rows */ }
          }
          if (!target) {
            await tx.tripleInventory.create({
              data: {
                inventoryId: inventory.id,
                vendorId: null,
                type,
                details: mkDetails(what, 1),
                parsedData: JSON.stringify({
                  entries: type === 'sangam' ? numbers.map(n => ({ ...n, sangam: true })) : numbers,
                  numbers,
                  byCustomer: agg.byCustomer,
                  customers: [customerKey],
                  totalEntriesCount: agg.count,
                  source: 'customer-app',
                  marketCode,
                  slot,
                  gameCodes,
                }),
                rate: 0,
                totalAmount: total,
                createdBy: APP_OWNER,
              },
            })
            return 1
          }
          const pd = JSON.parse(target.parsedData || '{}') as AppParsedData
          const merged = mergedNumbers(pd, agg.cells)
          const byCustomer = mergedByCustomer(pd, agg.byCustomer)
          const customers = [...new Set([...(pd.customers || []), customerKey])]
          const totalEntriesCount = (pd.totalEntriesCount || 0) + agg.count
          const gameCodesAll = [...new Set([...(pd.gameCodes || []), ...gameCodes])]
          const mergedTotal = merged.reduce((a, n) => a + n.price, 0)
          await tx.tripleInventory.update({
            where: { id: target.id },
            data: {
              details: mkDetails(what, customers.length),
              parsedData: JSON.stringify({
                ...pd,
                entries: type === 'sangam' ? merged.map(n => ({ ...n, sangam: true })) : merged,
                numbers: merged,
                byCustomer,
                customers,
                totalEntriesCount,
                gameCodes: gameCodesAll,
              }),
              totalAmount: mergedTotal,
            },
          })
          return 1
        }, { timeout: 20000, maxWait: 10000 })
      }

      // Merge (or create) the consolidated DoubleSingle row for one type+slot.
      const mergeDsRow = async (dsErpType: 'single' | 'double', slot: string, sub: MirrorBet[], what: string): Promise<number> => {
        if (!sub.length) return 0
        const agg = aggregateBets(sub, customerKey)
        const numbers = agg.cells.map(c => ({ number: c.number, price: c.price }))
        const total = numbers.reduce((a, n) => a + n.price, 0)
        const gameCodes = [...new Set(sub.map(b => b.gameCode).filter(Boolean))] as string[]
        return db.$transaction(async (tx) => {
          const candidates = await tx.doubleSingleInventory.findMany({ where: { inventoryId: inventory.id, type: dsErpType } })
          let target: (typeof candidates)[number] | null = null
          for (const r of candidates) {
            try {
              const pd = JSON.parse(r.parsedData || '{}') as AppParsedData
              if (pd.source === 'customer-app' && pd.marketCode === marketCode && (pd.slot || '') === slot) {
                target = r
                break
              }
            } catch { /* skip malformed rows */ }
          }
          if (!target) {
            await tx.doubleSingleInventory.create({
              data: {
                inventoryId: inventory.id,
                vendorId: null,
                type: dsErpType,
                details: mkDetails(what, 1),
                parsedData: JSON.stringify({
                  entries: numbers,
                  numbers,
                  byCustomer: agg.byCustomer,
                  customers: [customerKey],
                  totalEntriesCount: agg.count,
                  source: 'customer-app',
                  marketCode,
                  slot,
                  gameCodes,
                }),
                rate: 0,
                totalAmount: total,
                createdBy: APP_OWNER,
              },
            })
            return 1
          }
          const pd = JSON.parse(target.parsedData || '{}') as AppParsedData
          const merged = mergedNumbers(pd, agg.cells)
          const byCustomer = mergedByCustomer(pd, agg.byCustomer)
          const customers = [...new Set([...(pd.customers || []), customerKey])]
          const totalEntriesCount = (pd.totalEntriesCount || 0) + agg.count
          const gameCodesAll = [...new Set([...(pd.gameCodes || []), ...gameCodes])]
          const mergedTotal = merged.reduce((a, n) => a + n.price, 0)
          await tx.doubleSingleInventory.update({
            where: { id: target.id },
            data: {
              details: mkDetails(what, customers.length),
              parsedData: JSON.stringify({
                ...pd,
                entries: merged,
                numbers: merged,
                byCustomer,
                customers,
                totalEntriesCount,
                gameCodes: gameCodesAll,
              }),
              totalAmount: mergedTotal,
            },
          })
          return 1
        }, { timeout: 20000, maxWait: 10000 })
      }

      for (const [slot, sub] of bySlot(pannaBets)) {
        rows += await mergeTripleRow('mix', slot, sub, `${slot} panna bets`)
      }
      for (const [slot, sub] of bySlot(sangamBets)) {
        rows += await mergeTripleRow('sangam', slot, sub, 'sangam bets')
      }
      for (const dsType of ['single', 'jodi'] as const) {
        // app type "jodi" maps to the ERP DoubleSingleInventory type "double"
        const dsErpType = dsType === 'jodi' ? 'double' : 'single'
        const what = dsType === 'single' ? 'single bets' : 'jodi bets'
        for (const [slot, sub] of bySlot(digitBets.filter(b => b.type === dsType))) {
          rows += await mergeDsRow(dsErpType, slot, sub, what)
        }
      }

      // ── Parent inventory totals (ERP convention: totalAmount = Σ rows) ──
      const [allTriples, allDs] = await Promise.all([
        db.tripleInventory.findMany({ where: { inventoryId: inventory.id } }),
        db.doubleSingleInventory.findMany({ where: { inventoryId: inventory.id } }),
      ])
      const newTotal =
        allTriples.reduce((s, t) => s + t.totalAmount, 0) +
        allDs.reduce((s, t) => s + t.totalAmount, 0)
      await db.inventory.update({
        where: { id: inventory.id },
        data: { totalAmount: newTotal, totalTxn: newTotal },
      })
    }

    return { ok: true, rows }
  } catch (err) {
    console.error('ERP mirror error', err)
    return { ok: false, rows: 0, error: err instanceof Error ? err.message : 'mirror failed' }
  }
}
