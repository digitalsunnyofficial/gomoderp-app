// ──────────────────────────────────────────────────────────
// CUSTOMER APP ENGINE — pure data + functions shared by the
// customer-app APIs, the /app UI and the ERP admin panels.
// NO server-only imports here (must be client-safe).
// Ported 1:1 from the customer app prototype (deom.html).
// ──────────────────────────────────────────────────────────
import { pannaKey, pannaMatches } from './chart-definitions'

// SP (Single Panna) universe grouped by result digit
export const SP: Record<string, string> = {
  '0': '019,028,037,046,127,136,145,235,389,479,569,578',
  '1': '029,038,047,056,128,137,146,236,245,489,579,678',
  '2': '039,048,057,129,138,147,156,237,246,345,589,679',
  '3': '012,049,058,067,139,148,157,238,247,256,346,689',
  '4': '013,059,068,149,158,167,239,248,257,347,356,789',
  '5': '014,023,069,078,159,168,249,258,267,348,357,456',
  '6': '015,024,079,123,169,178,259,268,349,358,367,457',
  '7': '016,025,034,089,124,179,269,278,359,368,458,467',
  '8': '017,026,035,125,134,189,279,369,378,459,468,567',
  '9': '018,027,036,045,126,135,234,289,379,469,478,568',
}
export const SPB: Record<string, string[]> = Object.fromEntries(
  Object.entries(SP).map(([k, v]) => [k, v.split(',')])
)

// DP (Double Panna) universe grouped by result digit
export const DP: Record<string, string> = {
  '0': '118,226,334,442,550,668,776,884,992',
  '1': '001,119,227,335,443,551,669,885,993',
  '2': '002,110,228,336,552,660,778,886,994',
  '3': '003,229,337,445,553,661,779,887,995',
  '4': '004,112,220,338,446,554,662,770,996',
  '5': '005,113,221,339,447,663,771,889,997',
  '6': '006,114,330,448,556,664,772,880,998',
  '7': '007,115,223,331,449,557,665,773,881',
  '8': '008,116,224,332,440,558,774,882,990',
  '9': '009,117,225,441,559,667,775,883,991',
}
export const DPB: Record<string, string[]> = Object.fromEntries(
  Object.entries(DP).map(([k, v]) => [k, v.split(',')])
)

// TP (Triple Panna)
export const TP = ['000', '777', '444', '111', '888', '555', '222', '999', '666', '333']

// Payout rate cards
export const RATES = {
  main: { single: 9, jodi: 90, sp: 140, dp: 280, tp: 700, hs: 1500, hsb: 1500, fs: 8000 },
  star: { single: 9.5, oddeven: 1.95, sp: 140, dp: 280, tp: 700 },
} as const

export type BetType = 'single' | 'jodi' | 'sp' | 'dp' | 'tp' | 'oddeven' | 'hs' | 'hsb' | 'fs'

export const RATE_LBL: Record<string, string> = {
  single: 'Single', jodi: 'Jodi', sp: 'SP Pana', dp: 'DP Pana',
  hs: 'Half Sangam A', hsb: 'Half Sangam B', fs: 'Full Sangam', oddeven: 'Odd/Even', tp: 'TP Pana',
}

export const MAIN_TABS: Array<[BetType, string]> = [
  ['single', 'Single'], ['jodi', 'Jodi'], ['sp', 'SP Pana'],
  ['dp', 'DP Pana'], ['tp', 'TP Pana'], ['hs', 'Half Sngm'], ['fs', 'Full Sngm'],
]
export const STAR_TABS: Array<[string, string]> = [
  ['single', 'Single'], ['oddeven', 'Odd/Even'], ['sp', 'SP'],
  ['dp', 'DP'], ['tp', 'TP'], ['bulk', 'Ank Bulk'],
]

export function rateFor(marketCode: string | null | undefined, type: string): number {
  if (marketCode && marketCode.startsWith('st')) {
    return (RATES.star as Record<string, number>)[type] ?? RATES.star.single
  }
  return (RATES.main as Record<string, number>)[type] ?? 0
}

// Derive the result digit from a panna (sum of digits mod 10)
export function deriveDigit(panna: string): string {
  return String(panna.split('').reduce((a, c) => a + Number(c), 0) % 10)
}

// "HH:MM" → minutes since midnight
export function minsOf(t: string): number {
  const [h, m] = t.split(':').map(Number)
  return h * 60 + m
}

// IST clock — market windows are always evaluated in IST regardless of server TZ
export function istClock(now = new Date()): { h: number; m: number; mins: number } {
  const ist = new Date(now.getTime() + 5.5 * 3600 * 1000)
  const h = ist.getUTCHours(), m = ist.getUTCMinutes()
  return { h, m, mins: h * 60 + m }
}

// Is the open/close slot of a market accepting bids right now (IST)?
// Open slot accepts until (open time − closing minutes); close slot until (close time − closing minutes).
// closingMinutes defaults to 0 so legacy callers keep working.
export function slotAccepting(
  openTime: string, closeTime: string, slot: 'open' | 'close',
  now = new Date(), closingMinutes = 0
): boolean {
  const cur = istClock(now).mins
  const o = minsOf(openTime) - (closingMinutes || 0)
  const c = minsOf(closeTime) - (closingMinutes || 0)
  return slot === 'open' ? cur < o : cur >= o && cur < c
}

// Minutes remaining until the given slot stops accepting (can be negative)
export function minsLeftToClose(openTime: string, closeTime: string, slot: 'open' | 'close', now = new Date(), closingMinutes = 0): number {
  const cur = istClock(now).mins
  return (slot === 'open' ? minsOf(openTime) : minsOf(closeTime)) - (closingMinutes || 0) - cur
}

// Seconds remaining until the given slot stops accepting — drives the live
// countdown timer on the app home cards and the play screen (IST clock).
export function secsLeftToClose(openTime: string, closeTime: string, slot: 'open' | 'close', now = new Date(), closingMinutes = 0): number {
  const ist = new Date(now.getTime() + 5.5 * 3600 * 1000)
  const cur = ist.getUTCHours() * 3600 + ist.getUTCMinutes() * 60 + ist.getUTCSeconds()
  const [th, tm] = (slot === 'open' ? openTime : closeTime).split(':').map(Number)
  return th * 3600 + tm * 60 - (closingMinutes || 0) * 60 - cur
}

// 3725 → "1:02:05" · 125 → "02:05" (negative → "00:00")
export function fmtCountdown(totalSecs: number): string {
  const s = Math.max(0, Math.floor(totalSecs))
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60
  const mm = String(m).padStart(2, '0'), ssS = String(ss).padStart(2, '0')
  return h > 0 ? `${h}:${mm}:${ssS}` : `${mm}:${ssS}`
}

// ── Market identity: Name + Phase + Session → "Main Bazaar Day Open" ──
export const PHASE_LABEL: Record<string, string> = { day: 'Day', night: 'Night', none: '' }
export const SESSION_LABEL: Record<string, string> = { open: 'Open', close: 'Close', both: 'Open + Close' }

// Full display name for the market record ("Milan Day Open"), the card title
// drops the session suffix when the market runs both sessions ("Milan Day").
// Name parts already carrying the phase/session word ("Milan Day") are not doubled.
export function marketDisplayName(m: { name: string; phase?: string | null; session?: string | null }, withSession = true): string {
  const phase = PHASE_LABEL[m.phase || 'day'] || ''
  const lower = m.name.toLowerCase()
  const parts: string[] = [m.name]
  if (phase && !lower.includes(phase.toLowerCase())) parts.push(phase)
  if (withSession && m.session && m.session !== 'both') {
    const s = SESSION_LABEL[m.session] || ''
    const joined = parts.join(' ').toLowerCase()
    if (s && !joined.includes(s.toLowerCase())) parts.push(s)
  }
  return parts.join(' ')
}

// ── Weekly schedule ────────────────────────────────────────
// AppMarket.weeklySchedule is JSON: { "0": {on,open,close}, … } (0=Sunday).
// A missing/disabled day falls back to the market's default window
// (openTime/closeTime) unless the day is explicitly off.
export interface DaySchedule { on: boolean; open: string; close: string }
export type WeeklySchedule = Record<string, DaySchedule>

export const WEEKDAY_KEYS = ['0', '1', '2', '3', '4', '5', '6'] // 0 = Sunday (IST)
export const WEEKDAY_LABELS: Record<string, string> = {
  '0': 'Sunday', '1': 'Monday', '2': 'Tuesday', '3': 'Wednesday',
  '4': 'Thursday', '5': 'Friday', '6': 'Saturday',
}
export const WEEKDAY_SHORT: Record<string, string> = {
  '0': 'Sun', '1': 'Mon', '2': 'Tue', '3': 'Wed', '4': 'Thu', '5': 'Fri', '6': 'Sat',
}

export function parseWeekly(json: string | null | undefined): WeeklySchedule {
  try {
    const v = JSON.parse(json || '{}')
    return v && typeof v === 'object' ? v : {}
  } catch { return {} }
}

export function validDaySchedule(d: unknown): d is DaySchedule {
  const s = d as DaySchedule
  return !!s && typeof s === 'object'
    && typeof s.on === 'boolean'
    && typeof s.open === 'string' && /^([01]?\d|2[0-3]):[0-5]\d$/.test(s.open)
    && typeof s.close === 'string' && /^([01]?\d|2[0-3]):[0-5]\d$/.test(s.close)
}

// IST weekday index (0 = Sunday … 6 = Saturday)
export function istWeekday(now = new Date()): number {
  return new Date(now.getTime() + 5.5 * 3600 * 1000).getUTCDay()
}

// Resolved window for "today" (IST): the weekly entry when valid, else defaults
export function marketWindowToday(m: {
  openTime: string; closeTime: string; weeklySchedule?: string | null; isOn?: boolean
}, now = new Date()): { on: boolean; openTime: string; closeTime: string; weekly: boolean } {
  if (m.isOn === false) return { on: false, openTime: m.openTime, closeTime: m.closeTime, weekly: false }
  const wk = parseWeekly(m.weeklySchedule)
  const day = wk[String(istWeekday(now))]
  if (day && typeof day.on === 'boolean') {
    if (!day.on) return { on: false, openTime: m.openTime, closeTime: m.closeTime, weekly: true }
    if (validDaySchedule(day)) {
      return { on: true, openTime: day.open, closeTime: day.close, weekly: true }
    }
  }
  return { on: true, openTime: m.openTime, closeTime: m.closeTime, weekly: false }
}

// "14:30" → "02:30 PM" (AM/PM display used across ERP + app)
export function fmt12(t: string): string {
  if (!t || !t.includes(':')) return t || '—'
  const [h, m] = t.split(':').map(Number)
  const ampm = h >= 12 ? 'PM' : 'AM'
  const hh = h % 12 === 0 ? 12 : h % 12
  return String(hh).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ' ' + ampm
}

// Classify a 3-digit panna: all same → TP, two same → DP, else SP
export function classifyPanna(p: string): 'sp' | 'dp' | 'tp' {
  if (p.length !== 3) return 'sp'
  if (p[0] === p[1] && p[1] === p[2]) return 'tp'
  if (p[0] === p[1] || p[1] === p[2] || p[0] === p[2]) return 'dp'
  return 'sp'
}

// ── WhatsApp paste-data parser (customer app quick play) ──
// Accepts the operator's WhatsApp formats, one entry per line (or comma chains):
//   1,2,5 = 100          → three single bets of 100 each
//   128 = 50 / 128 - 50  → single entry
//   128-246 = 50         → full-sangam style panna pair (kept as-is)
//   70: 90 / 70 90       → jodi 70, 90 pts
export interface QuickParsed {
  num: string
  type: 'single' | 'jodi' | 'sp' | 'dp' | 'tp'
  points: number
  ok: boolean
  reason?: string
}

export function parseQuickData(text: string): { items: QuickParsed[]; errors: string[] } {
  const items: QuickParsed[] = []
  const errors: string[] = []
  const lines = String(text || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean)
  for (const line of lines) {
    // Sangam pairs like "128-246 = 50" need the explicit Sangam tab — flag with a clear reason
    const pair = line.match(/^(\d{3})\s*[-–]\s*(\d{3})\s*[=:]\s*(\d+)$/)
    if (pair) { errors.push(line + '  (panna pair — use the Sangam tab)'); continue }
    // strip common header prefixes like "Open -" / "Close:" at line start
    const cleaned = line.replace(/^(open|close|jodi|sp|dp|tp|single|double|triple)\s*[-:–]\s*/i, '').trim()
    // split "nums = pts" | "nums - pts" | "nums : pts"
    const m = cleaned.match(/^([\d,\s]+?)\s*[=:]\s*(\d+)\s*$/) || cleaned.match(/^([\d,]+?)\s*[-–]\s*(\d+)\s*$/)
    if (!m) { errors.push(line); continue }
    const numsPart = m[1].trim()
    const pts = Number(m[2])
    if (!pts || pts <= 0) { errors.push(line); continue }
    // numbers list: "1,2,5" | "128 246" | "70" (comma or space separated)
    const nums = numsPart.split(/[,\s]+/).map(s => s.trim()).filter(Boolean)
    const buffer: QuickParsed[] = []
    let lineBad = false
    for (const n of nums) {
      if (!/^\d{1,3}$/.test(n)) { lineBad = true; break }
      let type: QuickParsed['type']
      if (n.length === 1) type = 'single'
      else if (n.length === 2) type = 'jodi'
      else type = classifyPanna(n)
      buffer.push({ num: n, type, points: pts, ok: true })
    }
    if (lineBad || !buffer.length) { errors.push(line); continue }
    items.push(...buffer)
  }
  return { items, errors }
}

// Starline hour game accepts until the hour strikes (IST)
export function starHourAccepting(hour: number, now = new Date()): boolean {
  return istClock(now).h < hour
}

// Managed starline (AppStarline row) accepts until its declared result time
// minus the bet-closing minutes — minute-precision, honors custom minutes.
export function starlineAccepting(
  sl: { hour: number; minute?: number; betClosingMinutes?: number },
  now = new Date()
): boolean {
  const c = istClock(now)
  const nowMins = c.h * 60 + c.m
  const resultMins = sl.hour * 60 + (sl.minute || 0)
  return nowMins < resultMins - (sl.betClosingMinutes || 0)
}

export function isStarline(marketCode: string): boolean {
  return marketCode.startsWith('st')
}

export function starlineName(hour: number): string {
  return 'Starline ' + String(hour).padStart(2, '0') + ':00'
}

// ── Settlement ──
// Returns true when a pending bet wins, given the declared (partial) result.
export function betWins(bet: { type: string; slot: string; num: string }, r: {
  openPanna: string | null; closePanna: string | null
  openDigit: string | null; closeDigit: string | null; jodi: string | null
}): boolean {
  const { type, slot, num } = bet
  switch (type) {
    case 'single':
      if (slot === 'open') return !!r.openDigit && num === r.openDigit
      if (slot === 'close') return !!r.closeDigit && num === r.closeDigit
      return false // starline single handled below
    case 'jodi':
      return !!r.jodi && num === r.jodi
    case 'sp':
    case 'dp':
      // digit-set matching: "380" (operator chart) ≡ "038" (app grid)
      if (slot === 'open') return pannaMatches(num, r.openPanna)
      return pannaMatches(num, r.closePanna)
    case 'tp':
      // Classic TP books slot 'close' (close-only game); motor expansions
      // carry tp-class rows in the session the customer played — follow the
      // slot, exactly like sp/dp above.
      return pannaMatches(num, slot === 'open' ? r.openPanna : r.closePanna)
    case 'oddeven':
      if (!r.openDigit) return false
      const d = Number(r.openDigit)
      return num.toLowerCase() === 'odd' ? d % 2 === 1 : d % 2 === 0
    case 'hs': {
      // num = "X-PPP": open digit X + close panna PPP (Half Sangam A)
      if (!r.openDigit || !r.closePanna) return false
      const parts = num.split('-')
      return parts[0] === r.openDigit && pannaMatches(parts[1], r.closePanna)
    }
    case 'hsb': {
      // num = "PPP-X": open panna PPP + close digit X (Half Sangam B)
      if (!r.openPanna || !r.closeDigit) return false
      const parts = num.split('-')
      return pannaMatches(parts[0], r.openPanna) && parts[1] === r.closeDigit
    }
    case 'fs': {
      // num = "PPP-QQQ": open panna + close panna
      if (!r.openPanna || !r.closePanna) return false
      const parts = num.split('-')
      return pannaMatches(parts[0], r.openPanna) && pannaMatches(parts[1], r.closePanna)
    }
    default:
      return false
  }
}

// Starline settlement: one declared panna, single session
export function starBetWins(bet: { type: string; num: string }, panna: string): boolean {
  const digit = deriveDigit(panna)
  switch (bet.type) {
    case 'single': return bet.num === digit
    case 'sp':
    case 'dp':
    case 'tp': return pannaMatches(bet.num, panna)
    case 'oddeven': {
      const d = Number(digit)
      return bet.num.toLowerCase() === 'odd' ? d % 2 === 1 : d % 2 === 0
    }
    default: return false
  }
}

// Validate a panna against the universes (3 digits).
// Permutation-tolerant: any digit order of a valid panna is valid, so the
// operator chart spelling ("380") and the app grid spelling ("038") both pass.
export function isValidPanna(p: string): boolean {
  if (!/^\d{3}$/.test(p)) return false
  const all = new Set(
    [...Object.values(SP).join(',').split(','), ...Object.values(DP).join(',').split(','), ...TP].map(pannaKey)
  )
  return all.has(pannaKey(p))
}

// IST date string (bids/results are keyed by IST calendar day)
export function istDate(d = new Date()): string {
  const ist = new Date(d.getTime() + 5.5 * 3600 * 1000)
  return ist.toISOString().slice(0, 10)
}

// Client-side formatters (mirror prototype)
export function fmtINR(n: number | string | null | undefined): string {
  return '₹' + Number(n || 0).toLocaleString('en-IN')
}
