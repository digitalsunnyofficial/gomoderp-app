/**
 * entry-parser.ts — The ONE Unified Smart-Entry Parser.
 *
 * Goal: a single input box where the whole calculation happens. A player (or
 * the operator transcribing a WhatsApp chat) pastes free-form text; this
 * parser recognizes labeled sections, classifies every number, calculates
 * amounts and routes everything to the respective places:
 *
 *   SP - 1,2,5,6,7 = 100 rs        → Single store (5 ank entries @ 100)
 *   DP - 12,23,47,35,18 = 50 rs    → Double store (5 jodi entries @ 50)
 *   Motor -
 *   134678 = 200rs                 → Triple ▸ Group ▸ Motor Pana
 *   347890 = 100 rs                  (C(6,3) pannas each @ 200 / 100)
 *
 * ROUTING RULES (digit-length first, label-aware):
 *   1 digit   → Single (double-single-inventories, type=single)
 *               EXCEPTION: 1 digit under a BARE chart header ("Sp", "90 dp")
 *               → ank seed for that chart (SP column = 12 pannas, etc.)
 *   2 digits  → Double  (double-single-inventories, type=double)
 *   3 digits  → label=mix/none → Triple Mix   (triple-inventories, type=mix)
 *               label=common  → Triple Common (triple-inventories, type=common)
 *               label=group   → Triple Group  (triple-inventories, type=group)
 *   4-10 digits under a group label → seed, expanded by EXPANDER_REGISTRY
 *               (Motor → C(n,3) canonical pannas — admin parity; Family Set →
 *                family pannas; cut charts → chart lookup; DP Motor seed →
 *                n×(n-1) DP pannas; SP/DP/TP… → validated panna)
 *   anything else → skipped (kept for review)
 *
 * WHATSAPP BLOCK GRAMMAR (2026-09-30 operator samples):
 *   "[4:02 pm, 30/09/2026] San pag: Milan"        → metadata (skipped)
 *   "[…] San pag: Milan open motor"               → opens Motor chart context
 *   "Total 4500"                                   → operator arithmetic (skipped)
 *   "150rs" alone on a line                        → block rate for pending items
 *   "23457890,100"                                 → seed,rate comma style
 *   lines without an explicit amount inherit the block rate (standalone rate
 *   line → last explicit sibling rate → UI default rate)
 *
 * LABEL SYNTAX RECOGNIZED (see term-registry.ts for the dictionary):
 *   "SP - 1,2,5 = 100"   "DP: 12,23 = 50"   "Single Panna 12=50"
 *   "Motor -"  (bare header line — following lines belong to it)
 *   "SP - 134678 = 200rs"  (motor seed)
 *
 * EVOLUTION:
 *   - Unknown section labels are returned in `unknownLabels` so the UI can
 *     record Parser Exceptions (auto-evolution) and admins can teach the
 *     dictionary via Parser Terms (manual evolution).
 *
 * This module is PURE — same result on server and client, no React/DB.
 */

import type { GroupOption } from './group-types'
import { EXPANDER_REGISTRY } from './group-expanders'
import { resolveFamilyKey } from './panna-family'
import {
  lookupTerm,
  normalizeTerm,
  isGroupCategory,
  GROUP_OPTION_ORDER,
  type CanonicalCategory,
  type CustomTerm,
} from './term-registry'

// ────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────

export interface ParsedEntry {
  number: string
  amount: number
}

export interface GroupParseResult {
  option: GroupOption
  /** Expanded panna entries (merged, duplicates summed) */
  entries: ParsedEntry[]
  /** Raw seeds that produced these entries (for the details/audit string) */
  seeds: string[]
  /** Seeds that failed validation, with the expander's reason */
  invalid: Array<{ raw: string; reason: string }>
}

export interface UnifiedParseResult {
  singles: ParsedEntry[]
  doubles: ParsedEntry[]
  /** Triple ▸ Mix (unlabeled or explicitly "mix") */
  triples: ParsedEntry[]
  /** Triple ▸ Common */
  common: ParsedEntry[]
  /** Triple ▸ Group — one result per recognized group option, in fixed order */
  groups: GroupParseResult[]
  /** Tokens that could not be used, with reasons */
  skipped: string[]
  /** Section labels not yet in the dictionary (auto-evolution feed) */
  unknownLabels: string[]
  /** Labels recognized this parse (shown in the UI "recognized" strip) */
  recognizedLabels: Array<{ raw: string; category: CanonicalCategory }>
}

// ────────────────────────────────────────────────────────────
// Noise labels — chat words that must never be treated as labels
// (mirrors NOISE_LINE_RE / NOISE_PREFIX_RE in the Card View parser)
// ────────────────────────────────────────────────────────────

const NOISE_LABELS = new Set([
  'rs', 'rupees', 'rupaye', 'ru', 'total', 'totl', 'mob', 'mb', 'm b', 'mo',
  'nmb', 'dmo', 'dmb', 'mo ko', 'mb kb', 'mop', 'sr', 'ko', 'mohabat',
  'mohabat bazaar', 'gm', 'good morning', 'ok', 'thanks', 'thank you',
])

// ────────────────────────────────────────────────────────────
// Label detection
// ────────────────────────────────────────────────────────────

interface LineSplit {
  /** Raw label text (for display/learning), or null when the line has no label */
  labelRaw: string | null
  /** True when the label was recognized in the dictionary */
  known: boolean
  /** True when the label was a BARE header line ("Motor -", "Sp") — a bare
   * header opens a CHART context: following 1-digit lines become ank seeds
   * for that chart instead of single-store bets (operator sample "Sp / 7=75
   * / 8 / 3=75 / Total 2700"). Inline labels ("SP - 7 = 75") keep the
   * Task-2 semantics: single store. */
  bare: boolean
  /** Remaining content after the label (may be empty for bare header lines) */
  rest: string
}

/** A bare header line: words + ONE optional trailing separator, nothing else. */
const BARE_LABEL_RE = /^[A-Za-z][A-Za-z0-9\s]*\s*[-–—:.]?\s*$/

/** Explicit separator between label and content (dash / colon / dot / equals). */
const EXPLICIT_SEP_RE = /^\s*([-–—:.=])\s*(.*)$/

function normWords(s: string): string[] {
  const n = normalizeTerm(s)
  return n ? n.split(' ') : []
}

function isLabelShaped(words: string[]): boolean {
  if (words.length === 0 || words.length > 4) return false
  let hasLetter = false
  for (const w of words) {
    if (!/^[a-z0-9]+$/.test(w)) return false
    if (/[a-z]/.test(w)) hasLetter = true
  }
  return hasLetter
}

/**
 * A purely numeric label candidate ("50", "60") — only valid when followed
 * by an explicit dash/colon separator, never before "=" or another number.
 */
function isNumericLabel(words: string[]): boolean {
  return words.length === 1 && /^\d{1,3}$/.test(words[0])
}

/**
 * Split a raw line into (label, rest).
 *
 * Strategy (ordered):
 *   1. BARE header line — "Motor -", "SP", "50 chart", "Common:".
 *      Recognized ONLY when the whole line resolves in the dictionary
 *      (or is an explicitly punctuated unknown header like "Halffix -").
 *   2. LONGEST-PREFIX known label — tries up to the first 4 words as a
 *      label; the remainder must start with a separator or a digit.
 *      Purely numeric chart labels ("50") additionally reject a remainder
 *      that starts with a digit, so "50 60 70 = 100" stays a doubles line.
 *   3. EXPLICIT-separator unknown label — "Halffix - 12=50" → the label is
 *      reported as unknown (auto-evolution) and the content is still parsed
 *      (unlabeled) so no numbers are lost.
 *   4. Otherwise — plain content line.
 */
function splitLabel(line: string, customTerms?: CustomTerm[]): LineSplit {
  const trimmed = line.trim()
  if (!trimmed) return { labelRaw: null, known: true, bare: false, rest: '' }

  // ── 1. Bare header line ─────────────────────────────────
  if (BARE_LABEL_RE.test(trimmed)) {
    const words = normWords(trimmed)
    if (isLabelShaped(words)) {
      const hasTrailingSep = /[-–—:.]\s*$/.test(trimmed)
      const cat = lookupTerm(trimmed, customTerms)
      if (cat) {
        return { labelRaw: trimmed, known: true, bare: true, rest: '' }
      }
      // Unknown: flag only when it LOOKS like a deliberate header
      // (trailing dash/colon) or is noise-free multi-word. A lone word like
      // "gm" in chat text is not flagged to avoid spam.
      const isNoise = NOISE_LABELS.has(words.join(' '))
      if (!isNoise && hasTrailingSep) {
        return { labelRaw: trimmed, known: false, bare: true, rest: '' }
      }
      if (!isNoise && words.length >= 2 && words.length <= 3) {
        // e.g. "halffix chart" — probable unknown header
        return { labelRaw: trimmed, known: false, bare: true, rest: '' }
      }
      return { labelRaw: null, known: true, bare: false, rest: trimmed }
    }
  }

  const words = trimmed.split(/\s+/)

  // ── 2. Longest-prefix KNOWN label ────────────────────────
  const maxTake = Math.min(4, words.length - 1)
  for (let take = maxTake; take >= 1; take--) {
    const candidate = words.slice(0, take).join(' ')
    const cWords = normWords(candidate)
    const numeric = isNumericLabel(cWords)
    if (!isLabelShaped(cWords) && !numeric) continue
    const cat = lookupTerm(candidate, customTerms)
    if (!cat) continue
    const remainder = words.slice(take).join(' ')
    if (!remainder) continue // full line handled by bare check
    const sepM = remainder.match(EXPLICIT_SEP_RE)
    if (numeric) {
      // Numeric chart label ("50", "60", "70"): require an explicit dash or
      // colon — "50 - 128 = 75" is a chart label with a seed, while
      // "50 60 70 = 100" (no separator) and "50 = 100" (equals) stay
      // plain number lines.
      if (!sepM || !/[-–—:]/.test(sepM[1])) continue
      return { labelRaw: candidate, known: true, bare: false, rest: sepM[2] }
    }
    // Remainder must start with a separator or a digit to be a real label use
    if (sepM) {
      return { labelRaw: candidate, known: true, bare: false, rest: sepM[2] }
    }
    if (/^\d/.test(remainder)) {
      return { labelRaw: candidate, known: true, bare: false, rest: remainder }
    }
    // remainder starts with a letter → not a label usage; keep scanning
  }

  // ── 3. Explicit-separator UNKNOWN label ──────────────────
  const unk = trimmed.match(/^([A-Za-z][A-Za-z0-9\s]*?)\s*([-–—:])\s*(.*)$/)
  if (unk) {
    const candidate = unk[1].trim()
    const cWords = normWords(candidate)
    if (isLabelShaped(cWords) && !NOISE_LABELS.has(cWords.join(' '))) {
      return { labelRaw: candidate, known: false, bare: false, rest: unk[3].trim() }
    }
  }

  return { labelRaw: null, known: true, bare: false, rest: trimmed }
}

// ────────────────────────────────────────────────────────────
// Amount / number-line parsing
// ────────────────────────────────────────────────────────────

const RS_SUFFIX_RE = /(rs|₹|rupees|रुपये|रु)\.?$/i

export interface NumberLineResult {
  tokens: string[]
  amount: number
  /** True when the line carried an explicit amount (=/---/dot/rs-suffix/comma).
   * When false the amount is just the default rate, and the parser holds the
   * tokens as PENDING until the block's rate is known (operator style: the
   * rate line comes AFTER the numbers — "128 236 … 150rs"). */
  sawAmount: boolean
  ok: boolean
  reason?: string
}

/**
 * Parse one content line into (tokens, amount).
 * Supported: "1,2,5 = 100 rs" · "12 23 = 50" · "134678---200" · "07.2500rs"
 *            "5,3,4" (no amount → defaultRate) · "5 3 4 100rs"
 */
export function parseNumberLine(line: string, defaultRate: number): NumberLineResult {
  const trimmed = line.trim()
  if (!trimmed) return { tokens: [], amount: 0, sawAmount: false, ok: false, reason: 'empty' }

  let lhs = trimmed
  let amount = defaultRate
  let sawAmount = false

  const eqIdx = trimmed.indexOf('=')
  if (eqIdx > -1) {
    lhs = trimmed.slice(0, eqIdx).trim()
    let rhsRaw = trimmed.slice(eqIdx + 1).trim()
    rhsRaw = rhsRaw.replace(RS_SUFFIX_RE, '').trim()
    if (rhsRaw) {
      const parsed = parseFloat(rhsRaw)
      if (isNaN(parsed) || parsed <= 0) {
        return { tokens: [], amount: 0, sawAmount: false, ok: false, reason: `invalid amount "${rhsRaw}"` }
      }
      amount = parsed
      sawAmount = true
    }
  } else {
    // "---amount" (dash-run) then ".amount" styles
    const dashM = trimmed.match(/^(.+?)\s*[-–—]{2,}\s*(\d+)\s*(?:rs|₹)?\s*$/i)
    const dotM = dashM ? null : trimmed.match(/^(.+?)\s*\.{1,}\s*(\d+)\s*(?:rs|₹)?\s*$/i)
    const m = dashM || dotM
    if (m) {
      lhs = m[1].trim()
      const parsed = parseFloat(m[2])
      if (!isNaN(parsed) && parsed > 0) {
        amount = parsed
        sawAmount = true
      }
    }
    if (!sawAmount) {
      // trailing "NUM rs" glued at the end: "5 3 4 100rs" → nums "5 3 4" @100
      const tailRs = trimmed.match(/^(.+?)[\s]+(\d+)\s*(?:rs|₹)\s*$/i)
      if (tailRs && tailRs[1].trim()) {
        lhs = tailRs[1].trim()
        const parsed = parseFloat(tailRs[2])
        if (!isNaN(parsed) && parsed > 0) {
          amount = parsed
          sawAmount = true
        }
      }
    }
    if (!sawAmount) {
      // seed,rate comma style: "23457890,100" → seed 23457890 @100.
      // The first part must be 4-10 digits (a group seed — never a bet
      // number), so jodi lists like "12,23" are untouched.
      const commaM = trimmed.match(/^(\d{4,10})\s*,\s*(\d{1,5})$/)
      if (commaM) {
        const parsed = parseFloat(commaM[2])
        if (!isNaN(parsed) && parsed > 0) {
          lhs = commaM[1]
          amount = parsed
          sawAmount = true
        }
      }
    }
  }

  const tokens = lhs
    .split(/[\s,/]+/)
    .map(t => t.trim())
    .filter(t => t.length > 0)

  return { tokens, amount, sawAmount, ok: true }
}

// ────────────────────────────────────────────────────────────
// Triple helpers (mirror merp/page.tsx exactly)
// ────────────────────────────────────────────────────────────

/** Ank column (1-10) for a panna = digit-sum % 10, 0 → 10. */
export function calculateTriplePosition(numStr: string): number {
  let sum = 0
  for (const ch of numStr) sum += parseInt(ch, 10) || 0
  const ank = sum % 10
  return ank === 0 ? 10 : ank
}

/** Strip leading zeros (display normalization used by Smart Entry). */
function normalizeNumber(tok: string): string {
  return tok.replace(/^0+/, '') || '0'
}

// ────────────────────────────────────────────────────────────
// Main parser
// ────────────────────────────────────────────────────────────

const MAX_SEED_DIGITS = 10 // same cap as the group single-mode input
const MAX_EXPANDED_PER_GROUP = 5000 // safety valve for pathological motors

// ── WhatsApp block grammar (2026-09-30 operator samples) ────────────────

/** "Total 4500" / "totl 2000" — operator arithmetic, never a bet or label. */
const TOTAL_LINE_RE = /^\s*(?:total|totl)\b/i

/** "[4:02 pm, 30/09/2026] " — WhatsApp timestamp/sender prefix. */
const BRACKET_PREFIX_RE = /^\[[^\]]*\]\s*(.*)$/

/** "San pag: Milan" — sender:market metadata (letters/words both sides). */
const SENDER_LINE_RE = /^[A-Za-z][A-Za-z0-9\s]*\s*:\s*[A-Za-z][A-Za-z0-9\s]*$/

/** "50rs" / "150 rs" / "150₹" alone on a line — the block's rate.
 * Requires the currency suffix so a bare "150" stays a normal bet. */
const STANDALONE_RATE_RE = /^\s*(\d+(?:\.\d+)?)\s*(?:rs|₹|rupees|रुपये|रु)\s*\.?\s*$/i

/**
 * Find a KNOWN dictionary label of 2+ words anywhere inside a metadata-ish
 * line ("San pag: Milan open motor" → "open motor"). Single-word labels are
 * deliberately not scanned ("Sp" inside random text must not open a chart).
 */
function scanMultiWordLabel(
  text: string,
  customTerms?: CustomTerm[]
): { words: string[]; category: CanonicalCategory } | null {
  const words = normalizeTerm(text).split(' ').filter(Boolean)
  const maxTake = Math.min(4, words.length)
  for (let take = maxTake; take >= 2; take--) {
    for (let start = 0; start + take <= words.length; start++) {
      const cand = words.slice(start, start + take).join(' ')
      const cat = lookupTerm(cand, customTerms)
      if (cat) return { words: cand.split(' '), category: cat }
    }
  }
  return null
}

/** Remove a matched label phrase from the raw line, returning the remainder. */
function stripLabelFromRaw(raw: string, words: string[]): string {
  const escaped = words.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  const re = new RegExp(escaped.join('[^a-zA-Z0-9]+'), 'i')
  const m = raw.match(re)
  if (!m || m.index === undefined) return ''
  return raw.slice(m.index + m[0].length).trim()
}

export function parseUnifiedEntry(
  text: string,
  defaultRate: number,
  customTerms?: CustomTerm[]
): UnifiedParseResult {
  const out: UnifiedParseResult = {
    singles: [],
    doubles: [],
    triples: [],
    common: [],
    groups: [],
    skipped: [],
    unknownLabels: [],
    recognizedLabels: [],
  }

  if (!text || !text.trim()) return out

  let section: CanonicalCategory | null = null
  // True when the section was opened by a BARE header line ("Sp", "Motor -")
  // — bare headers open a CHART context where 1-digit lines become ank seeds.
  // Inline labels ("SP - 7 = 75") keep the classic single-store routing.
  let sectionBare = false
  // When an unknown header is seen, following content is HELD BACK (skipped
  // with a reason) instead of being silently mis-filed into the previous
  // section — this is money data; wrong routing is worse than visible hold.
  let heldBackBy: string | null = null

  // ── Pending (un-amounted) items ──
  // WhatsApp operators often write the rate AFTER the numbers ("128 236 …
  // 150rs") or rely on the sibling rate ("Sp / 7=75 / 8 / 3=75"). Lines with
  // no explicit amount are held as pending and routed once the block's rate
  // is known: a standalone "150rs" line, the next block boundary, or end of
  // input. Rate precedence: standalone rate → last explicit rate in the
  // block → the UI default rate → 0.
  interface PendingItem { tok: string; cat: CanonicalCategory | null; chartAnk: boolean }
  let pending: PendingItem[] = []
  let blockStandaloneRate: number | null = null
  let blockLastExplicitRate: number | null = null

  const bestBlockRate = () => blockStandaloneRate ?? blockLastExplicitRate ?? defaultRate
  const resolvePending = (rate: number) => {
    const items = pending
    pending = []
    for (const it of items) routeToken(it.tok, rate, it.cat, it.chartAnk)
  }
  const closeBlock = () => {
    if (pending.length) resolvePending(bestBlockRate())
    blockStandaloneRate = null
    blockLastExplicitRate = null
  }
  const openSection = (cat: CanonicalCategory, bare: boolean, rawLabel: string) => {
    closeBlock()
    section = cat
    sectionBare = bare
    heldBackBy = null
    out.recognizedLabels.push({ raw: rawLabel.trim(), category: cat })
    // "all <chart>" — play the chart for EVERY ank (operator sample:
    // "All dp9 / 50rs / Total 4500" = the full 90-DP universe @50).
    if (bare && isGroupCategory(cat) && /^all\b/.test(normalizeTerm(rawLabel))) {
      for (let d = 0; d <= 9; d++) {
        pending.push({ tok: String(d), cat, chartAnk: true })
      }
    }
  }

  // Working state per group option (merged by SUM across sections)
  const groupEntries = new Map<GroupOption, Map<string, number>>()
  const groupSeeds = new Map<GroupOption, string[]>()
  const groupInvalid = new Map<GroupOption, Array<{ raw: string; reason: string }>>()
  // Family-dedup per family-set option (prevent double-counting one family)
  const seenFamilyKeys = new Map<GroupOption, Set<string>>()

  const expandSeed = (option: GroupOption, rawSeed: string, rate: number) => {
    const cleaned = rawSeed.replace(/\D/g, '')
    if (!cleaned) {
      out.skipped.push(`${rawSeed} (no digits)`)
      return
    }
    if (cleaned.length > MAX_SEED_DIGITS) {
      out.skipped.push(`${rawSeed} (too long: ${cleaned.length} digits, max ${MAX_SEED_DIGITS})`)
      return
    }

    // Family-set dedup: two seeds resolving to the same family would
    // double-count every panna in that family after merge-by-sum.
    if (option === 'Family Set 4' || option === 'Family Set 6' || option === 'Family Set 8') {
      const resolved = resolveFamilyKey(cleaned.slice(0, 3))
      if (resolved && resolved.setType === option) {
        let seen = seenFamilyKeys.get(option)
        if (!seen) {
          seen = new Set()
          seenFamilyKeys.set(option, seen)
        }
        if (seen.has(resolved.key)) {
          out.skipped.push(`${rawSeed} (duplicate of family ${resolved.key} — not double-counted)`)
          return
        }
        seen.add(resolved.key)
      }
    }

    const expander = EXPANDER_REGISTRY[option]
    const result = expander(cleaned, { rate })
    if ('error' in result) {
      let inv = groupInvalid.get(option)
      if (!inv) {
        inv = []
        groupInvalid.set(option, inv)
      }
      inv.push({ raw: rawSeed, reason: result.error })
      out.skipped.push(`${rawSeed} (${result.error})`)
      return
    }
    const currentSize = groupEntries.get(option)?.size || 0
    if (currentSize + result.length > MAX_EXPANDED_PER_GROUP) {
      out.skipped.push(`${rawSeed} (expansion limit ${MAX_EXPANDED_PER_GROUP} pannas reached for ${option})`)
      return
    }
    let m = groupEntries.get(option)
    if (!m) {
      m = new Map()
      groupEntries.set(option, m)
    }
    for (const e of result) {
      m.set(e.panna, (m.get(e.panna) || 0) + e.rate)
    }
    let seeds = groupSeeds.get(option)
    if (!seeds) {
      seeds = []
      groupSeeds.set(option, seeds)
    }
    seeds.push(rawSeed)
  }

  const routeToken = (tok: string, amount: number, cat: CanonicalCategory | null, chartAnk: boolean) => {
    if (!/^\d+$/.test(tok)) {
      out.skipped.push(`${tok} (not a number)`)
      return
    }
    const len = tok.length
    const normalized = normalizeNumber(tok)

    if (len === 1) {
      // 1 digit under a BARE chart header → ank seed for that chart
      // ("Sp" header + "7=75" → the 12 SP chart pannas of ank 7 @75).
      if (chartAnk && cat && isGroupCategory(cat)) {
        expandSeed(cat as GroupOption, tok, amount)
        return
      }
      // 1 digit → Single store, whatever the label
      out.singles.push({ number: normalized, amount })
      return
    }
    if (len === 2) {
      // 2 digits → Double store, whatever the label
      out.doubles.push({ number: normalized, amount })
      return
    }

    if (len === 3) {
      if (cat && isGroupCategory(cat)) {
        expandSeed(cat as GroupOption, tok, amount)
      } else if (cat === 'common') {
        out.common.push({ number: normalized, amount })
      } else {
        // mix / no label → Triple Mix
        out.triples.push({ number: normalized, amount })
      }
      return
    }

    // 4+ digits: only meaningful as a group seed (motor / family / charts)
    if (cat && isGroupCategory(cat)) {
      expandSeed(cat as GroupOption, tok, amount)
    } else {
      out.skipped.push(`${tok} (invalid digit length: ${len})`)
    }
  }

  const lines = text.split(/[\n\r]+/)
  for (const rawLine of lines) {
    if (!rawLine.trim()) continue

    // ── 0. "Total 4500" arithmetic lines — never bets, never labels ──
    if (TOTAL_LINE_RE.test(rawLine)) continue

    // ── 1. WhatsApp metadata: "[4:02 pm, 30/09/2026] San pag: Milan open motor" ──
    let work = rawLine.trim()
    const bracketM = work.match(BRACKET_PREFIX_RE)
    const hadBracket = bracketM !== null
    if (bracketM) {
      work = (bracketM[1] || '').trim()
      if (!work) continue
    }
    if (hadBracket || SENDER_LINE_RE.test(work)) {
      const hit = scanMultiWordLabel(work, customTerms)
      if (hit) {
        // Header inside the metadata line ("… Milan open motor")
        openSection(hit.category, true, hit.words.join(' '))
        const restRaw = stripLabelFromRaw(work, hit.words)
        if (/\d/.test(restRaw)) {
          work = restRaw // seeds/rates share the header line — parse below
        } else {
          continue
        }
      } else if (!/\d/.test(work)) {
        // Pure metadata (sender:market) — a block boundary, nothing to parse
        closeBlock()
        continue
      }
      // Metadata-shaped but carries digits and no known label → parse below
    } else if (!/\d/.test(work)) {
      // Bare word-only line ("Milan open motor", "open dp motor") — an agent
      // or customer typing the header without any WhatsApp metadata. Find a
      // KNOWN multi-word label anywhere in it (dictionary-exact, 2+ words).
      // Lines with digits and non-label word lines fall through unchanged.
      const hit = scanMultiWordLabel(work, customTerms)
      if (hit) {
        openSection(hit.category, true, hit.words.join(' '))
        const restRaw = stripLabelFromRaw(work, hit.words)
        if (/\d/.test(restRaw)) {
          work = restRaw // seeds/rates shared the header line — parse below
        } else {
          continue
        }
      }
    }

    // ── 2. Standalone block rate — "50rs" / "150 rs" ──
    const rateM = work.match(STANDALONE_RATE_RE)
    if (rateM) {
      const v = parseFloat(rateM[1])
      if (!isNaN(v) && v > 0) {
        blockStandaloneRate = v
        resolvePending(v)
        continue
      }
    }

    const { labelRaw, known, bare, rest } = splitLabel(work, customTerms)

    if (labelRaw !== null) {
      if (known) {
        const cat = lookupTerm(labelRaw, customTerms)
        if (cat) {
          openSection(cat, bare, labelRaw)
        }
      } else {
        // Unknown header — stop the current section, hold the content and
        // record the label for auto-evolution.
        closeBlock()
        section = null
        sectionBare = false
        heldBackBy = normalizeTerm(labelRaw) || labelRaw.trim()
        if (heldBackBy && !out.unknownLabels.includes(heldBackBy)) {
          out.unknownLabels.push(heldBackBy)
        }
        out.skipped.push(`unrecognized label "${labelRaw.trim()}" — teach it in Parser Terms`)
      }
    }

    if (!rest) continue

    if (heldBackBy) {
      out.skipped.push(`${rest} (held back: unknown label "${heldBackBy}")`)
      continue
    }

    const { tokens, amount, sawAmount, ok, reason } = parseNumberLine(rest, defaultRate)
    if (!ok) {
      if (reason && reason !== 'empty') out.skipped.push(`${rest} (${reason})`)
      continue
    }
    if (tokens.length === 0) {
      out.skipped.push(`${rest} (no numbers)`)
      continue
    }
    const chartAnk = sectionBare && !!section && isGroupCategory(section)
    if (sawAmount) {
      blockLastExplicitRate = amount
      for (const tok of tokens) {
        routeToken(tok, amount, section, chartAnk)
      }
    } else {
      // No explicit amount — pending until the block's rate is known
      for (const tok of tokens) {
        pending.push({ tok, cat: section, chartAnk })
      }
    }
  }

  // End of input — resolve whatever is still pending with the block's rate
  closeBlock()

  // Materialize groups in fixed order
  for (const option of GROUP_OPTION_ORDER) {
    const m = groupEntries.get(option)
    if (!m || m.size === 0) continue
    out.groups.push({
      option,
      entries: Array.from(m.entries()).map(([number, amt]) => ({ number, amount: amt })),
      seeds: groupSeeds.get(option) || [],
      invalid: groupInvalid.get(option) || [],
    })
  }

  return out
}

// ────────────────────────────────────────────────────────────
// Grid builders (same shape the Card View expects in parsedData)
// ────────────────────────────────────────────────────────────

export type TripleGrid = Record<number, Array<{ number: string; price: number }>>

export function buildTripleGrid(entries: ParsedEntry[]): TripleGrid {
  const grid: TripleGrid = {}
  for (let i = 1; i <= 10; i++) grid[i] = []
  for (const e of entries) {
    const pos = calculateTriplePosition(e.number)
    if (pos >= 1 && pos <= 10) grid[pos].push({ number: e.number, price: e.amount })
  }
  return grid
}

export function gridTotals(grid: TripleGrid): Record<number, number> {
  const totals: Record<number, number> = {}
  for (let i = 1; i <= 10; i++) totals[i] = grid[i].reduce((s, n) => s + n.price, 0)
  return totals
}

export function grandTotalOf(entries: ParsedEntry[]): number {
  return entries.reduce((s, e) => s + e.amount, 0)
}
