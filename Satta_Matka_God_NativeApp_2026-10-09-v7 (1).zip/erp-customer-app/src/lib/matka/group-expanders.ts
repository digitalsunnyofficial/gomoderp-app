/**
 * Per-Option Group Seed Expanders.
 *
 * Each expander takes a single seed string + config (rate, optional series)
 * and returns either:
 *   - GeneratedEntry[] (one or more panna entries with rates)
 *   - { error: string } (if the seed is invalid for this option)
 *
 * Expanders NEVER throw — they return error objects so the batch pipeline
 * can continue processing the remaining seeds.
 *
 * The expanders for SP/DP/TP/SPDP/SPTP/DPTP/SPDPTP reuse the chart-definitions
 * helpers (isSP, isDP, isTP) and the universe sets.
 *
 * The Motor Pana expander mirrors the existing `generateGroupPannas` logic
 * for the 'Motor Pana' case in page.tsx: it takes a digit string, extracts
 * all unique digits, and generates all C(n,3) SP combinations.
 *
 * The cut-chart expanders (50/60/70/90 DP/90 ABR) look up the seed in the
 * corresponding chart map. The seed can be:
 *   - A panna string (e.g. "128") → returns that panna if it's in the chart
 *   - An ank reference (e.g. "Ank5" or "5") → returns all pannas for that ank
 */

import {
  SP_SET, DP_SET, TP_SET,
  CHART_50_PANNAS, CHART_60_PANNAS, CHART_70_PANNAS,
  CHART_90_DP, CHART_ABR9_PANNAS,
  CHART_20_PANNAS, CHART_30_PANNAS, CHART_40_PANNAS,
  DP_MOTOR_CHART, pannaKey, canonicalPanna, spellPannaZerosLast,
  SP_CHART_CANONICAL, DP_CHART_CANONICAL,
  isSP, isDP, isTP,
  pannaToAnk,
} from './chart-definitions'
import { FAMILY_SET_BUILDERS, buildFamilyCombined } from './panna-family'
import type { GeneratedEntry, GroupSeedExpander, ExpanderConfig } from './group-types'

// ────────────────────────────────────────────────────────────────────────────
// Helper: create entries from a list of pannas
// ────────────────────────────────────────────────────────────────────────────

function entriesFromPannas(
  pannas: string[],
  rate: number,
  sourceSeed: string
): GeneratedEntry[] {
  return pannas.map(panna => ({ panna, rate, sourceSeed }))
}

// ────────────────────────────────────────────────────────────────────────────
// 5a. expandSP — validate seed is a valid SP panna, return as-is
// ────────────────────────────────────────────────────────────────────────────
export const expandSP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  // Ank seed → whole SP chart column for that ank (12 pannas)
  if (/^\d$/.test(cleaned) || /^[Aa]nk\s*\d$/.test(cleaned.replace(/\s/g, ''))) {
    const ankRes = expandAnkPannaClass(true, false, seed, config)
    if (ankRes) return ankRes
  }
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number or a single ank` }
  }
  if (!isSP(cleaned)) {
    return { error: `"${cleaned}" is not a valid SP panna (digits must be all different)` }
  }
  if (!SP_SET.has(cleaned)) {
    return { error: `"${cleaned}" is not in the SP universe` }
  }
  return entriesFromPannas([cleaned], config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// 5b. expandDP — validate seed is a valid DP panna, return as-is
// ────────────────────────────────────────────────────────────────────────────
export const expandDP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  // Ank seed → whole DP chart column for that ank (9 pannas)
  if (/^\d$/.test(cleaned) || /^[Aa]nk\s*\d$/.test(cleaned.replace(/\s/g, ''))) {
    const ankRes = expandAnkPannaClass(false, true, seed, config)
    if (ankRes) return ankRes
  }
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number or a single ank` }
  }
  if (!isDP(cleaned)) {
    return { error: `"${cleaned}" is not a valid DP panna (exactly 2 digits must be the same)` }
  }
  if (!DP_SET.has(cleaned)) {
    return { error: `"${cleaned}" is not in the DP universe` }
  }
  return entriesFromPannas([cleaned], config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// 5c. expandTP — validate seed is one of the 10 fixed TP values.
//     Preserve "000" as string, never convert to "0".
// ────────────────────────────────────────────────────────────────────────────
export const expandTP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number` }
  }
  if (!isTP(cleaned)) {
    return { error: `"${cleaned}" is not a valid TP panna (all 3 digits must be the same)` }
  }
  if (!TP_SET.has(cleaned)) {
    return { error: `"${cleaned}" is not in the TP universe` }
  }
  // CRITICAL: return "000" as-is, never "0"
  return entriesFromPannas([cleaned], config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// 5d. expandSPDP — classify seed as SP or DP, reject TP
// ────────────────────────────────────────────────────────────────────────────
export const expandSPDP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  // Ank seed → SP + DP chart columns for that ank (12 + 9 = 21 pannas)
  if (/^\d$/.test(cleaned) || /^[Aa]nk\s*\d$/.test(cleaned.replace(/\s/g, ''))) {
    const ankRes = expandAnkPannaClass(true, true, seed, config)
    if (ankRes) return ankRes
  }
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number or a single ank` }
  }
  if (isTP(cleaned)) {
    return { error: `"${cleaned}" is a TP panna — not allowed in SPDP mode` }
  }
  if (isSP(cleaned) && SP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  if (isDP(cleaned) && DP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  return { error: `"${cleaned}" is neither a valid SP nor DP panna` }
}

// ────────────────────────────────────────────────────────────────────────────
// 5e. expandSPTP — classify seed as SP or TP, reject DP
// ────────────────────────────────────────────────────────────────────────────
export const expandSPTP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number` }
  }
  if (isDP(cleaned)) {
    return { error: `"${cleaned}" is a DP panna — not allowed in SPTP mode` }
  }
  if (isSP(cleaned) && SP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  if (isTP(cleaned) && TP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  return { error: `"${cleaned}" is neither a valid SP nor TP panna` }
}

// ────────────────────────────────────────────────────────────────────────────
// 5f. expandDPTP — classify seed as DP or TP, reject SP
// ────────────────────────────────────────────────────────────────────────────
export const expandDPTP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number` }
  }
  if (isSP(cleaned)) {
    return { error: `"${cleaned}" is an SP panna — not allowed in DPTP mode` }
  }
  if (isDP(cleaned) && DP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  if (isTP(cleaned) && TP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  return { error: `"${cleaned}" is neither a valid DP nor TP panna` }
}

// ────────────────────────────────────────────────────────────────────────────
// 5g. expandSPDPTP — classify seed as SP, DP, or TP; accept all three
// ────────────────────────────────────────────────────────────────────────────
export const expandSPDPTP: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (!/^\d{3}$/.test(cleaned)) {
    return { error: `Seed "${seed}" is not a 3-digit number` }
  }
  if (isSP(cleaned) && SP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  if (isDP(cleaned) && DP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  if (isTP(cleaned) && TP_SET.has(cleaned)) {
    return entriesFromPannas([cleaned], config.rate, seed)
  }
  return { error: `"${cleaned}" is not a valid SP, DP, or TP panna` }
}

// ────────────────────────────────────────────────────────────────────────────
// 5h. expandMotor — reuse existing single-motor generator logic.
//
// The existing page.tsx motor logic (generateGroupPannas, case 'Motor Pana',
// lines 2431-2434) takes a digits array and generates all C(n,3) SP
// combinations (all-different-digit pannas). We replicate that here as a
// pure function so we don't need to modify page.tsx's internal closure.
//
// Seed format: a string of digits, e.g. "4567890" (7 digits).
// The expander extracts unique digits, then generates all C(n,3) SP pannas.
// ────────────────────────────────────────────────────────────────────────────
export const expandMotor: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (cleaned.length < 3) {
    return { error: `Motor seed "${seed}" has fewer than 3 digits (got ${cleaned.length})` }
  }

  // Extract unique digits (preserve order of first occurrence)
  const seen = new Set<number>()
  const digits: number[] = []
  for (const ch of cleaned) {
    const d = Number(ch)
    if (!seen.has(d)) {
      seen.add(d)
      digits.push(d)
    }
  }

  if (digits.length < 3) {
    return { error: `Motor seed "${seed}" has fewer than 3 unique digits (got ${digits.length})` }
  }

  // Generate all C(n,3) combinations — ONE canonical spelling per panna
  // (admin Group Preview parity; confirmed by the operator's own arithmetic:
  // "23457890,100 / 12345678,100 → Total 11200" = C(8,3)=56 × 100 × 2 seeds).
  // The previous version emitted all 6 permutations, which multiplied every
  // panna's stake by 6 (money bug — same family as the customer-app
  // 120-vs-125 motor fix).
  digits.sort((a, b) => a - b)
  const pannas: string[] = []
  for (let i = 0; i < digits.length; i++) {
    for (let j = i + 1; j < digits.length; j++) {
      for (let k = j + 1; k < digits.length; k++) {
        pannas.push(canonicalPanna(`${digits[i]}${digits[j]}${digits[k]}`))
      }
    }
  }

  return entriesFromPannas(pannas, config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// Helper: resolve a seed to an ank number (1-10) for cut-chart lookup.
// Accepts "Ank5", "ank5", "5", or a panna string.
// ────────────────────────────────────────────────────────────────────────────
function resolveAnk(seed: string): number | null {
  // Try "AnkN" / "ankN" format
  const ankMatch = seed.match(/^[Aa]nk\s*(\d+)$/)
  if (ankMatch) {
    const n = parseInt(ankMatch[1], 10)
    if (n >= 0 && n <= 9) return n === 0 ? 10 : n
    return null
  }
  // Try pure digit → if 3 digits, treat as panna and compute ank
  const cleaned = seed.replace(/\D/g, '')
  if (/^\d{3}$/.test(cleaned)) {
    return pannaToAnk(cleaned)
  }
  // Try single digit (0-9) → ank
  if (/^\d$/.test(cleaned)) {
    const n = parseInt(cleaned, 10)
    return n === 0 ? 10 : n
  }
  return null
}

/**
 * Ank-seed expansion shared by the panna-class options.
 *
 * When the seed is a single digit (an ank), the operator means "the whole
 * chart column for that ank": SP → the 12 SP pannas of SP_CHART_CANONICAL,
 * DP → the 9 DP pannas of DP_CHART_CANONICAL, SPDP → both (21 rows).
 * Verified against the operator's WhatsApp sample "Sp / 7=75 / 8 / 3=75 /
 * Total 2700" (3 anks × 12 pannas × 75 = 2700).
 */
function expandAnkPannaClass(
  sp: boolean,
  dp: boolean,
  seed: string,
  config: ExpanderConfig
): GeneratedEntry[] | { error: string } | null {
  const cleaned = seed.replace(/\D/g, '')
  const ank = resolveAnkSafe(cleaned)
  if (ank === null) return null
  const pannas: string[] = [
    ...(sp ? SP_CHART_CANONICAL.get(ank) || [] : []),
    ...(dp ? DP_CHART_CANONICAL.get(ank) || [] : []),
  ]
  if (!pannas.length) {
    return { error: `No chart pannas found for ank ${cleaned}` }
  }
  return entriesFromPannas(pannas, config.rate, seed)
}

/** resolveAnk without the panna-string branch (single digit / AnkN only). */
function resolveAnkSafe(seed: string): number | null {
  const ankMatch = seed.match(/^[Aa]nk\s*(\d+)$/)
  if (ankMatch) {
    const n = parseInt(ankMatch[1], 10)
    return n >= 0 && n <= 9 ? (n === 0 ? 10 : n) : null
  }
  if (/^\d$/.test(seed)) {
    const n = parseInt(seed, 10)
    return n === 0 ? 10 : n
  }
  return null
}

/**
 * Generic cut-chart expander.
 * Looks up the seed in the given chart map and returns matching pannas.
 */
function expandCutChart(
  chart: Map<number, string[]>,
  chartName: string,
  seed: string,
  config: ExpanderConfig
): GeneratedEntry[] | { error: string } {
  // If seed is a 3-digit panna, check if it's in the chart
  const cleaned = seed.replace(/\D/g, '')
  if (/^\d{3}$/.test(cleaned)) {
    const ank = pannaToAnk(cleaned)
    const chartPannas = chart.get(ank) || []
    if (chartPannas.includes(cleaned)) {
      return entriesFromPannas([cleaned], config.rate, seed)
    }
    return { error: `Panna "${cleaned}" is not in the ${chartName}` }
  }

  // Otherwise, try to resolve as an ank reference
  const ank = resolveAnk(seed)
  if (ank === null) {
    return { error: `Seed "${seed}" is not a valid panna or ank reference for ${chartName}` }
  }
  const pannas = chart.get(ank) || []
  if (pannas.length === 0) {
    return { error: `No pannas found in ${chartName} for ank ${ank}` }
  }
  return entriesFromPannas(pannas, config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// 5i. expand50Chart
export const expand50Chart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_50_PANNAS, '50 Chart', seed, config)

// 5j. expand60Chart
export const expand60Chart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_60_PANNAS, '60 Chart', seed, config)

// 5k. expand70Chart
export const expand70Chart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_70_PANNAS, '70 Chart', seed, config)

// 5l. expand90DPChart
export const expand90DPChart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_90_DP, '90 DP Chart', seed, config)

// 5m. expand90AbrChart
export const expand90AbrChart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_ABR9_PANNAS, '90 ABR Chart', seed, config)

// SP Motor (2026-09 operator update)
// Data is IDENTICAL to SP (Chart 4) — the distinction is the group label
// (SP_MOTOR) carried in the entry details for parsing/settlement routing.
// Validation therefore mirrors expandSP.
export const expandSPMotor: GroupSeedExpander = (seed, config) => expandSP(seed, config)

// DP Motor (2026-09 operator update — verbatim operator chart)
// The operator's DP Motor chart groups the FULL DP universe by ank via the
// smallest-non-zero-digit rule (18/16/14/12/10/8/6/4/2 rows for anks 1-9,
// none for 0). A 3-digit seed must be a chart member (digit-set compare, so
// any spelling of a chart panna passes); an ank seed expands to that ank's
// whole family. Single source: DP_MOTOR_CHART in chart-definitions.ts —
// the same map the customer-app DP Motor game uses.
export const expandDPMotor: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (/^\d{3}$/.test(cleaned)) {
    for (const [, rows] of DP_MOTOR_CHART) {
      if (rows.some(p => pannaKey(p) === pannaKey(cleaned))) {
        return entriesFromPannas([cleaned], config.rate, seed)
      }
    }
    return { error: `Panna "${cleaned}" is not in the DP Motor chart` }
  }
  const ank = resolveAnk(seed)
  if (ank !== null) {
    const pannas = DP_MOTOR_CHART.get(ank) || []
    if (!pannas.length) {
      return { error: `No pannas found in the DP Motor chart for ank ${ank}` }
    }
    return entriesFromPannas(pannas, config.rate, seed)
  }
  // Multi-digit seed (≥2 unique digits) → seed-based DP motor: every panna
  // with one repeated digit drawn twice from the seed pool plus one different
  // seed digit → n×(n-1) rows. Confirmed by the operator's WhatsApp sample
  // "open dp motor / 23457890,40 / 12345678,40 / Total 4480"
  // (8 unique digits → 8×7 = 56 pannas × 40 × 2 seeds = 4480).
  const seen = new Set<number>()
  const digits: number[] = []
  for (const ch of cleaned) {
    const d = Number(ch)
    if (!seen.has(d)) {
      seen.add(d)
      digits.push(d)
    }
  }
  if (digits.length < 2) {
    return { error: `DP Motor seed "${seed}" needs at least 2 unique digits for seed expansion` }
  }
  const pannas: string[] = []
  for (const d of digits) {
    for (const e of digits) {
      if (d !== e) pannas.push(spellPannaZerosLast([d, d, e]))
    }
  }
  return entriesFromPannas(pannas, config.rate, seed)
}

// 20 / 30 / 40 Chart (2026-10 operator fix — verbatim chart data)
// Fixed panel sets across ALL 10 anks: 2 per ank (20), 3 per ank (30),
// 4 per ank (40). Data lives in chart-definitions.ts CHART_20/30/40_PANNAS.
export const expand20Chart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_20_PANNAS, '20 Chart', seed, config)

export const expand30Chart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_30_PANNAS, '30 Chart', seed, config)

export const expand40Chart: GroupSeedExpander = (seed, config) =>
  expandCutChart(CHART_40_PANNAS, '40 Chart', seed, config)

// ────────────────────────────────────────────────────────────────────────────
// 5o. expandFamilySet4 — Family Set 4: 4 pannas per family
// ────────────────────────────────────────────────────────────────────────────
export const expandFamilySet4: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (cleaned.length < 3) {
    return { error: `Family Set 4 seed "${seed}" has fewer than 3 digits` }
  }
  const familyPannas = FAMILY_SET_BUILDERS['Family Set 4'](cleaned)
  if (familyPannas.length === 0) {
    return { error: `No pannas found in Family Set 4 for seed "${seed}"` }
  }
  return entriesFromPannas(familyPannas, config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// 5o. expandFamilySet6 — Family Set 6: 6 pannas per family (SP permutations)
// ────────────────────────────────────────────────────────────────────────────
export const expandFamilySet6: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (cleaned.length < 3) {
    return { error: `Family Set 6 seed "${seed}" has fewer than 3 digits` }
  }
  const familyPannas = FAMILY_SET_BUILDERS['Family Set 6'](cleaned)
  if (familyPannas.length === 0) {
    return { error: `No pannas found in Family Set 6 for seed "${seed}"` }
  }
  return entriesFromPannas(familyPannas, config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// 5p. expandFamilySet8 — Family Set 8: 8 pannas per family (SP perms + DP neighbors)
// ────────────────────────────────────────────────────────────────────────────
export const expandFamilySet8: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (cleaned.length < 3) {
    return { error: `Family Set 8 seed "${seed}" has fewer than 3 digits` }
  }
  const familyPannas = FAMILY_SET_BUILDERS['Family Set 8'](cleaned)
  if (familyPannas.length === 0) {
    return { error: `No pannas found in Family Set 8 for seed "${seed}"` }
  }
  return entriesFromPannas(familyPannas, config.rate, seed)
}

// ────────────────────────────────────────────────────────────────────────────
// Expander registry — maps GroupOption → expander function
// ────────────────────────────────────────────────────────────────────────────
import type { GroupOption } from './group-types'

// expandFamilyChart — the COMBINED family chart (Sets 4+6+8 merged)
// The seed panna resolves to its family across all three sets; every panna
// still belongs to exactly one family so there is no double counting.
export const expandFamilyChart: GroupSeedExpander = (seed, config) => {
  const cleaned = seed.replace(/\D/g, '')
  if (cleaned.length < 3) {
    return { error: `Family Chart seed "${seed}" has fewer than 3 digits` }
  }
  const comb = buildFamilyCombined(cleaned)
  if (!comb.setType) {
    return { error: `No pannas found in any family set for seed "${seed}"` }
  }
  return entriesFromPannas(comb.pannas, config.rate, seed)
}

export const EXPANDER_REGISTRY: Record<GroupOption, GroupSeedExpander> = {
  SP: expandSP,
  DP: expandDP,
  TP: expandTP,
  SPDP: expandSPDP,
  SPTP: expandSPTP,
  DPTP: expandDPTP,
  SPDPTP: expandSPDPTP,
  'Motor Pana': expandMotor,
  'SP Motor': expandSPMotor,
  'DP Motor': expandDPMotor,
  '20 Chart': expand20Chart,
  '30 Chart': expand30Chart,
  '40 Chart': expand40Chart,
  '50 Chart': expand50Chart,
  '60 Chart': expand60Chart,
  '70 Chart': expand70Chart,
  '90 DP Chart': expand90DPChart,
  '90 ABR Chart': expand90AbrChart,
  'Family Set 4': expandFamilySet4,
  'Family Set 6': expandFamilySet6,
  'Family Set 8': expandFamilySet8,
  'Family Chart': expandFamilyChart,
}
