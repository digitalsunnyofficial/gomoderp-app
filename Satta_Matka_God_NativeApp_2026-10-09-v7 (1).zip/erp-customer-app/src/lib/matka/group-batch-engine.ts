/**
 * Batch Orchestrator — the main entry point for the Multi-Seed Batch feature.
 *
 * Takes a Group option, raw textarea text, and config (rate, optional series),
 * then:
 *   1. Parses the raw text into seeds (max 10)
 *   2. Expands each seed using the matching per-option expander
 *   3. Merges duplicate pannas by SUMMING their rates (never overwrite)
 *   4. Collects invalid seeds with reasons
 *   5. Returns a GroupBatchResult
 *
 * The merge-by-sum rule mirrors the existing parser-v5 Type-18 aggregation
 * logic (page.tsx line 612 — `aggregateEntries`).
 */

import { parseSeedBatch } from './seed-parser'
import { EXPANDER_REGISTRY } from './group-expanders'
import { resolveFamilyKey } from './panna-family'
import type {
  GroupOption,
  GroupBatchResult,
  GeneratedEntry,
  SeedValidationResult,
  ExpanderConfig,
} from './group-types'

/**
 * Check if a group option is a Family Set type (4/6/8).
 * Family Set seeds use a "family key" lookup model — multiple different
 * seed strings (e.g. "123" and "128") can resolve to the SAME family and
 * therefore the SAME panna list. Without deduplication, entering both
 * would double every panna's rate, which is almost never what the user
 * intends.
 */
function isFamilySetOption(option: GroupOption): boolean {
  return option === 'Family Set 4' || option === 'Family Set 6' || option === 'Family Set 8'
}

/**
 * Build a batch result from raw textarea input.
 *
 * @param option   The selected Group option (e.g. 'SP', 'Motor Pana', '50 Chart')
 * @param rawText  The raw textarea content (newline/comma/space separated seeds)
 * @param config   Expander config (rate, optional series)
 * @returns        GroupBatchResult with entries, mergedMap, invalidSeeds, rejectedOverflow
 */
export function buildGroupBatch(
  option: GroupOption,
  rawText: string,
  config: ExpanderConfig
): GroupBatchResult {
  // 1. Parse the raw text into seeds (max 10, report overflow)
  const { seeds: parsedSeeds, rejectedOverflow } = parseSeedBatch(rawText)

  // 1b. For Family Set options, dedupe seeds that resolve to the SAME family.
  //     Rationale: seeds "123" and "128" both belong to family key "123" in
  //     FAMILY_SET_8 — without dedup, both would expand to the same 8 pannas
  //     and merge-by-sum would double every panna's rate. That is almost
  //     never what the user intends. We keep the FIRST occurrence of each
  //     family and skip later duplicates (they are still reported as "valid"
  //     in invalidSeeds so the UI's green chip count matches user input).
  let seeds = parsedSeeds
  const dedupedAway: SeedValidationResult[] = []
  if (isFamilySetOption(option)) {
    const seenFamilyKeys = new Set<string>()
    const deduped: string[] = []
    for (const seed of parsedSeeds) {
      const cleaned = seed.replace(/\D/g, '').slice(0, 3)
      const resolved = resolveFamilyKey(cleaned)
      if (resolved && resolved.setType === option) {
        if (seenFamilyKeys.has(resolved.key)) {
          // Duplicate family reference — skip expansion, but record it
          dedupedAway.push({
            raw: seed,
            cleaned,
            valid: true,
            reason: `Duplicate of family ${resolved.key} — skipped to prevent double-counting`,
          })
          continue
        }
        seenFamilyKeys.add(resolved.key)
      }
      deduped.push(seed)
    }
    seeds = deduped
  }

  // 2. Get the expander for this option
  const expander = EXPANDER_REGISTRY[option]
  if (!expander) {
    // This should never happen if GroupOption is correctly typed, but guard anyway
    return {
      entries: [],
      mergedMap: new Map(),
      invalidSeeds: seeds.map(raw => ({
        raw,
        cleaned: raw,
        valid: false,
        reason: `Unknown group option: ${option}`,
      })),
      rejectedOverflow,
    }
  }

  // 3. Expand each seed
  const allEntries: GeneratedEntry[] = []
  const invalidSeeds: SeedValidationResult[] = []

  for (const seed of seeds) {
    const result = expander(seed, config)
    if ('error' in result) {
      invalidSeeds.push({
        raw: seed,
        cleaned: seed.replace(/\D/g, ''),
        valid: false,
        reason: result.error,
      })
    } else {
      allEntries.push(...result)
      // Mark as valid (even if it produced 0 entries, the seed itself was valid)
      // Actually, only mark valid if it produced at least 1 entry
      if (result.length > 0) {
        invalidSeeds.push({
          raw: seed,
          cleaned: seed.replace(/\D/g, ''),
          valid: true,
        })
      }
    }
  }

  // 4. Merge by summing duplicate pannas
  //    This mirrors parser-v5 Type-18 aggregation (sum, never overwrite)
  const mergedMap = new Map<string, number>()
  for (const entry of allEntries) {
    const current = mergedMap.get(entry.panna) || 0
    mergedMap.set(entry.panna, current + entry.rate)
  }

  // 5. Filter invalidSeeds to only keep the actually-invalid ones
  //    (we added valid ones above just for the UI's green chips)
  const trulyInvalid = invalidSeeds.filter(s => !s.valid)

  return {
    entries: allEntries,
    mergedMap,
    invalidSeeds: trulyInvalid,
    rejectedOverflow,
    dedupedAway,
  }
}

/**
 * Convenience: get just the merged entries as an array of { number, price }.
 * This shape matches what the existing page.tsx submit handler expects
 * for the `numbers` field in the parsedData JSON.
 */
export function getMergedEntries(
  result: GroupBatchResult
): Array<{ number: string; price: number }> {
  return Array.from(result.mergedMap.entries()).map(([panna, rate]) => ({
    number: panna,
    price: rate,
  }))
}

/**
 * Convenience: compute the grand total (sum of all merged rates).
 */
export function getGrandTotal(result: GroupBatchResult): number {
  let total = 0
  for (const rate of result.mergedMap.values()) {
    total += rate
  }
  return total
}
