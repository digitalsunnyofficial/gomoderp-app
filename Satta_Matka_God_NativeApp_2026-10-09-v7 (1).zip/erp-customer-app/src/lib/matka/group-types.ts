/**
 * Shared types for the Multi-Seed Batch Input feature (Group Chart Modes).
 *
 * These types are used by:
 *   - src/lib/matka/seed-parser.ts
 *   - src/lib/matka/group-expanders.ts
 *   - src/lib/matka/group-batch-engine.ts
 *   - src/components/matka/GroupBatchInput.tsx
 *   - src/components/matka/GroupBatchPreview.tsx
 *   - src/app/page.tsx (minimal imports)
 */

// ────────────────────────────────────────────────────────────────────────────
// Group Option — the 16 dropdown values.
// ────────────────────────────────────────────────────────────────────────────

/**
 * NOTE: The existing page.tsx dropdown uses `"Motor Pana"` (with a space) as
 * the option value for the motor entry. We keep that exact string here so the
 * batch engine is compatible with the existing dropdown without renaming.
 */
export type GroupOption =
  | 'SP'
  | 'DP'
  | 'TP'
  | 'SPDP'
  | 'SPTP'
  | 'DPTP'
  | 'SPDPTP'
  | 'Motor Pana'   // ← existing dropdown value (do NOT rename)
  | 'SP Motor'     // ← SP chart data under the SP_MOTOR group label (2026-09)
  | 'DP Motor'     // ← DP chart data under the DP_MOTOR group label (2026-09)
  | '20 Chart'
  | '30 Chart'
  | '40 Chart'
  | '50 Chart'
  | '60 Chart'
  | '70 Chart'
  | '90 DP Chart'
  | '90 ABR Chart'
  | 'Family Set 4'
  | 'Family Set 6'
  | 'Family Set 8'
  | 'Family Chart' // ← Sets 4+6+8 combined into one family chart (2026-09)

/**
 * Human-readable label for each Group option (used in UI + logs).
 * Keep labels SHORT — plain option names without parenthetical suffixes
 * (operator request: "keep the first part only, remove the () part").
 */
export const GROUP_OPTION_LABELS: Record<GroupOption, string> = {
  SP: 'SP',
  DP: 'DP',
  TP: 'TP',
  SPDP: 'SPDP',
  SPTP: 'SPTP',
  DPTP: 'DPTP',
  SPDPTP: 'SPDPTP',
  'Motor Pana': 'Motor Pana',
  'SP Motor': 'SP Motor',
  'DP Motor': 'DP Motor',
  '20 Chart': '20 Chart',
  '30 Chart': '30 Chart',
  '40 Chart': '40 Chart',
  '50 Chart': '50 Chart',
  '60 Chart': '60 Chart',
  '70 Chart': '70 Chart',
  '90 DP Chart': '90 DP Chart',
  '90 ABR Chart': '90 ABR Chart',
  'Family Set 4': 'Family Set 4',
  'Family Set 6': 'Family Set 6',
  'Family Set 8': 'Family Set 8',
  'Family Chart': 'Family Chart',
}

// ────────────────────────────────────────────────────────────────────────────
// Core data structures
// ────────────────────────────────────────────────────────────────────────────

/**
 * A single generated panna entry, tracking which seed it came from.
 * This allows the preview UI to show seed-to-panna lineage.
 */
export interface GeneratedEntry {
  /** 3-digit panna string, e.g. "128", "000", "999" */
  panna: string
  /** Rate (price) assigned to this panna for this seed */
  rate: number
  /** The original seed string that produced this entry */
  sourceSeed: string
}

/**
 * Result of validating a single raw seed string.
 */
export interface SeedValidationResult {
  /** The original raw token as entered by the user */
  raw: string
  /** Cleaned/normalized version (digits only, trimmed) */
  cleaned: string
  /** Whether this seed is valid for further expansion */
  valid: boolean
  /** If invalid, a human-readable reason */
  reason?: string
}

/**
 * The raw batch input collected from the textarea.
 */
export interface GroupBatchInput {
  /** The original textarea content (for audit/details field) */
  rawText: string
  /** Parsed seed tokens (max 10, after cleaning) */
  seeds: string[]
}

/**
 * The final result of the batch orchestrator.
 */
export interface GroupBatchResult {
  /** All generated entries (before merging) — one entry per panna per seed */
  entries: GeneratedEntry[]
  /**
   * Merged map: panna → total rate (sum of all rates for that panna).
   * Duplicate pannas across seeds are SUMMED, never overwritten.
   * This mirrors the existing parser-v5 Type-18 aggregation rule.
   */
  mergedMap: Map<string, number>
  /** Seeds that failed validation, with reasons */
  invalidSeeds: SeedValidationResult[]
  /** Seeds that were rejected because the batch exceeded the 10-seed cap */
  rejectedOverflow: string[]
  /**
   * Seeds that resolved to a family already covered by an earlier seed
   * (Family Set 4/6/8 only). These are SKIPPED during expansion to prevent
   * double-counting: e.g. entering "123 128" (both in family '123') would
   * otherwise double every panna's rate via the merge-by-sum rule.
   * Each entry includes a human-readable `reason` explaining which family
   * was duplicated.
   */
  dedupedAway?: SeedValidationResult[]
}

// ────────────────────────────────────────────────────────────────────────────
// Expander function signature
// ────────────────────────────────────────────────────────────────────────────

/**
 * Configuration passed to every per-option expander.
 */
export interface ExpanderConfig {
  /** Rate per panna (from the Rate input field) */
  rate: number
  /**
   * Optional series/ank selector (1-10).
   * Some expanders (50 Chart, 60 Chart, etc.) use this to select which ank's
   * cut chart to expand. If undefined, the expander uses the seed itself.
   */
  series?: number
}

/**
 * Every per-option expander matches this signature.
 * Returns either an array of generated entries, or an error object.
 * Never throws — errors are returned so the batch pipeline can continue.
 */
export type GroupSeedExpander = (
  seed: string,
  config: ExpanderConfig
) => GeneratedEntry[] | { error: string }
