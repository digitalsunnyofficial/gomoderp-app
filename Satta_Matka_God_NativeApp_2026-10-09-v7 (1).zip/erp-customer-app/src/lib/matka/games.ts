// ──────────────────────────────────────────────────────────
// GAME MANAGEMENT ENGINE — catalog, calculation + ERP mapping
// Shared by server (bets API, admin APIs) and client (app UI).
//
// Every game expands a customer selection into concrete bet
// entries (type + number + rate). The ERP mapping columns
// (erpType / erpSub / erpGroup) route the entries into the
// existing ERP chart system: single/double/triple → mix,
// common, group → SP/DP/TP/SPDPTP/Motor/Family sets.
// ──────────────────────────────────────────────────────────
import { SPB, DPB, TP, deriveDigit } from './app-engine'

export interface GameDef {
  code: string
  name: string
  category: string   // Digit | Pana | Jodi | Family | Motor | Common | Combined | Composite | Chart
  base: string       // calculation base (human readable)
  erpType: 'single' | 'double' | 'triple' | 'composite'
  erpSub: 'mix' | 'common' | 'group'
  erpGroup: string | null
  settleAs: 'single' | 'jodi' | 'sp' | 'dp' | 'tp' | 'hs' | 'hsb' | 'fs' | 'dj'
  rates: Record<string, number>  // per-entry payout multiplier
  minPoints: number
  scope: 'main' | 'star' | 'both'
  icon: string
  note: string
}

// Expanded entry produced by a selection
export interface ExpandedBet {
  type: string        // settlement type (settleAs of the game)
  num: string
  slot: string        // open | close | jodi | hs | fs
  rate: number
  erpSub: string
  erpGroup: string | null
}

// All 10 triples keyed by their derived digit
export const RED_JODIS = ['00', '11', '22', '33', '44', '55', '66', '77', '88', '99']

// Cycle jodi pairs: 01↔10, 12↔21, … 90↔09
export function cyclePairs(): Array<[string, string]> {
  const out: Array<[string, string]> = []
  for (let a = 0; a <= 9; a++) {
    const b = (a + 1) % 10
    out.push([String(a) + String(b), String(b) + String(a)])
  }
  return out
}

// All DP pannas that can be built from a seed of unique digits:
// every ordered pair (a,b), a≠b → aab, aba, baa (a doubled) — the
// complementary bba/bab/abb come from the reversed pair.
export function dpMotorPannas(seed: string): string[] {
  const digs = seed.split('')
  const out: string[] = []
  for (const a of digs) for (const b of digs) {
    if (a === b) continue
    out.push(a + a + b, a + b + a, b + a + a)
  }
  return [...new Set(out)]
}

// Two Digit Pana — pick exactly 2 digits → the 6 pannas of that family
export function twoDigitPannas(a: number, b: number): string[] {
  const s = (d: number) => String(d)
  return [
    s(a) + s(a) + s(b), s(a) + s(b) + s(a), s(b) + s(a) + s(a),
    s(b) + s(b) + s(a), s(b) + s(a) + s(b), s(a) + s(b) + s(b),
  ]
}

// Jodi family — pick 2 digits → aa, ab, ba, bb
export function jodiFamily(a: number, b: number): string[] {
  const s = (d: number) => String(d)
  return [s(a) + s(a), s(a) + s(b), s(b) + s(a), s(b) + s(b)]
}

// Digit based jodi — open digit d → d0 … d9
export function digitBasedJodis(d: number): string[] {
  return Array.from({ length: 10 }, (_, k) => String(d) + String(k))
}

// ── The catalog (23 games = the 22 requested + plain Jodi) ──
export const GAME_DEFS: GameDef[] = [
  {
    code: 'single', name: 'Single Digit', category: 'Digit', base: 'Single Digit (0-9)',
    erpType: 'single', erpSub: 'mix', erpGroup: null, settleAs: 'single',
    rates: { main: 9, star: 9.5 }, minPoints: 10, scope: 'both', icon: 'circle-dot',
    note: 'Bet on 0-9. Open session settles on the open digit, close session on the close digit.',
  },
  {
    code: 'jodi', name: 'Jodi', category: 'Jodi', base: 'Jodi (00-99)',
    erpType: 'double', erpSub: 'mix', erpGroup: null, settleAs: 'jodi',
    rates: { main: 90 }, minPoints: 10, scope: 'main', icon: 'grid-2x2',
    note: 'Jodi = open digit + close digit. Settles on the full result.',
  },
  {
    code: 'sp', name: 'Single Pana', category: 'Pana', base: 'SP (120 pannas)',
    erpType: 'triple', erpSub: 'mix', erpGroup: 'SP', settleAs: 'sp',
    rates: { main: 140, star: 140 }, minPoints: 10, scope: 'both', icon: 'triangle',
    note: 'All three digits different. Grouped by result digit (ank) — 12 pannas per ank.',
  },
  {
    code: 'sp_bulk', name: 'Single Pana Bulk', category: 'Pana', base: 'SP + Bulk',
    erpType: 'triple', erpSub: 'mix', erpGroup: 'SP', settleAs: 'sp',
    rates: { star: 140 }, minPoints: 10, scope: 'star', icon: 'layers',
    note: 'One SP panna placed across multiple Starline hour games in one go.',
  },
  {
    code: 'dp', name: 'Double Pana', category: 'Pana', base: 'DP (90 pannas)',
    erpType: 'triple', erpSub: 'mix', erpGroup: 'DP', settleAs: 'dp',
    rates: { main: 280, star: 280 }, minPoints: 10, scope: 'both', icon: 'square',
    note: 'Exactly two same digits. Grouped by result digit — 9 pannas per ank.',
  },
  {
    code: 'dp_bulk', name: 'Double Pana Bulk', category: 'Pana', base: 'DP + Bulk',
    erpType: 'triple', erpSub: 'mix', erpGroup: 'DP', settleAs: 'dp',
    rates: { star: 280 }, minPoints: 10, scope: 'star', icon: 'layers',
    note: 'One DP panna placed across multiple Starline hour games in one go.',
  },
  {
    code: 'single_bulk', name: 'Single Digit Bulk', category: 'Digit', base: 'Single + Bulk',
    erpType: 'single', erpSub: 'mix', erpGroup: null, settleAs: 'single',
    rates: { star: 9.5 }, minPoints: 10, scope: 'star', icon: 'layers',
    note: 'One ank digit placed across multiple Starline hour games in one go.',
  },
  {
    code: 'tp', name: 'Triple Pana', category: 'Pana', base: 'TP (10 pannas)',
    erpType: 'triple', erpSub: 'mix', erpGroup: 'TP', settleAs: 'tp',
    rates: { main: 700, star: 700 }, minPoints: 10, scope: 'both', icon: 'box',
    note: 'All three digits same (000-999).',
  },
  {
    code: 'tp_family', name: 'Triple Pana Family', category: 'Family', base: 'TP + Family',
    erpType: 'triple', erpSub: 'group', erpGroup: 'TP', settleAs: 'tp',
    rates: { main: 700 }, minPoints: 10, scope: 'main', icon: 'users',
    note: 'Pick a family digit — bets the triple of that family (erp group TP + Family).',
  },
  {
    code: 'spdptp', name: 'SPDPTP', category: 'Combined', base: 'SP + DP + TP',
    erpType: 'triple', erpSub: 'group', erpGroup: 'SPDPTP', settleAs: 'sp',
    rates: { main: 140 }, minPoints: 10, scope: 'main', icon: 'boxes',
    note: 'Pick an ank digit → 12 SP + 9 DP + 1 TP panna of that digit. DP/TP entries carry their own rates (280/700); ERP group SPDPTP.',
  },
  {
    code: 'sp_motor', name: 'SP Motor', category: 'Motor', base: 'SP + Motor',
    erpType: 'triple', erpSub: 'group', erpGroup: 'Motor Pana', settleAs: 'sp',
    rates: { main: 140 }, minPoints: 10, scope: 'main', icon: 'zap',
    note: 'Seed 4-10 unique digits → every 3-digit permutation (all-different pannas) at SP rate.',
  },
  {
    code: 'dp_motor', name: 'DP Motor', category: 'Motor', base: 'DP + Motor',
    erpType: 'triple', erpSub: 'group', erpGroup: 'Motor Pana', settleAs: 'dp',
    rates: { main: 280 }, minPoints: 10, scope: 'main', icon: 'zap',
    note: 'Seed 2-10 unique digits → every double panna buildable from the seed (6 per digit pair) at DP rate.',
  },
  {
    code: 'two_digit', name: 'Two Digit Pana', category: 'Pana', base: '2-digit family',
    erpType: 'triple', erpSub: 'mix', erpGroup: 'DP', settleAs: 'dp',
    rates: { main: 280 }, minPoints: 10, scope: 'main', icon: 'hash',
    note: 'Pick 2 digits → all 6 pannas of that two-digit family (aab, aba, baa, bba, bab, abb) at DP rate.',
  },
  {
    code: 'digit_jodi', name: 'Digit Jodi Pana', category: 'Composite', base: 'Digit + Pana',
    erpType: 'composite', erpSub: 'mix', erpGroup: null, settleAs: 'dj',
    rates: { main: 160 }, minPoints: 10, scope: 'main', icon: 'link',
    note: 'Pick a digit + a panna. Wins when the declared panna matches AND its derived digit equals your digit. Composite payout, admin-configurable.',
  },
  {
    code: 'jodi_family', name: 'Jodi Family', category: 'Jodi', base: 'Jodi family (aa/ab/ba/bb)',
    erpType: 'double', erpSub: 'mix', erpGroup: null, settleAs: 'jodi',
    rates: { main: 90 }, minPoints: 10, scope: 'main', icon: 'users',
    note: 'Pick 2 digits → 4 jodis (aa, ab, ba, bb) at Jodi rate.',
  },
  {
    code: 'red_jodi', name: 'Red Jodi', category: 'Jodi', base: 'Repeating jodis',
    erpType: 'double', erpSub: 'mix', erpGroup: null, settleAs: 'jodi',
    rates: { main: 90 }, minPoints: 10, scope: 'main', icon: 'circle',
    note: 'The 10 repeating-digit jodis (00, 11, 22 … 99) at Jodi rate.',
  },
  {
    code: 'cycle_jodi', name: 'Cycle Jodi', category: 'Jodi', base: 'Cycle pairs',
    erpType: 'double', erpSub: 'mix', erpGroup: null, settleAs: 'jodi',
    rates: { main: 90 }, minPoints: 10, scope: 'main', icon: 'repeat',
    note: 'Cycle pairs 01↔10, 12↔21 … 90↔09 — one tap bets both mirror jodis at Jodi rate.',
  },
  {
    code: 'digit_based_jodi', name: 'Digit Based Jodi', category: 'Jodi', base: 'Open digit → 10 jodis',
    erpType: 'double', erpSub: 'mix', erpGroup: null, settleAs: 'jodi',
    rates: { main: 90 }, minPoints: 10, scope: 'main', icon: 'grid-2x2',
    note: 'Pick an ank digit → all 10 jodis starting with that digit (d0 … d9).',
  },
  {
    code: 'sp_common', name: 'SP Common', category: 'Common', base: 'SP + Common',
    erpType: 'triple', erpSub: 'common', erpGroup: 'SP', settleAs: 'sp',
    rates: { main: 140 }, minPoints: 10, scope: 'main', icon: 'globe',
    note: 'SP pannas entered as Common — routed to the ERP common chart (applies across vendors).',
  },
  {
    code: 'dp_common', name: 'DP Common', category: 'Common', base: 'DP + Common',
    erpType: 'triple', erpSub: 'common', erpGroup: 'DP', settleAs: 'dp',
    rates: { main: 280 }, minPoints: 10, scope: 'main', icon: 'globe',
    note: 'DP pannas entered as Common — routed to the ERP common chart.',
  },
  {
    code: 'hs_a', name: 'Half Sangam A', category: 'Composite', base: 'Open digit + Close panna',
    erpType: 'composite', erpSub: 'mix', erpGroup: null, settleAs: 'hs',
    rates: { main: 1500 }, minPoints: 10, scope: 'main', icon: 'unlink',
    note: 'Pick the open digit + the close panna. Wins on open digit + close panna match.',
  },
  {
    code: 'hs_b', name: 'Half Sangam B', category: 'Composite', base: 'Open panna + Close digit',
    erpType: 'composite', erpSub: 'mix', erpGroup: null, settleAs: 'hsb',
    rates: { main: 1500 }, minPoints: 10, scope: 'main', icon: 'unlink',
    note: 'Pick the open panna + the close digit. Wins on open panna + close digit match.',
  },
  {
    code: 'fs', name: 'Full Sangam', category: 'Composite', base: 'Open panna + Close panna',
    erpType: 'composite', erpSub: 'mix', erpGroup: null, settleAs: 'fs',
    rates: { main: 8000 }, minPoints: 10, scope: 'main', icon: 'link-2',
    note: 'Pick both the open panna and the close panna.',
  },
]

export const GAME_BY_CODE: Record<string, GameDef> = Object.fromEntries(
  GAME_DEFS.map(g => [g.code, g])
)

export function gameRateOf(def: GameDef, marketCode: string | null | undefined): number {
  if (marketCode && marketCode.startsWith('st')) {
    return def.rates.star ?? def.rates.main ?? def.rates.rate ?? 0
  }
  return def.rates.main ?? def.rates.rate ?? 0
}

// ── Selection → entries expansion ────────────────────────────
// sel carries the game-specific pick; points = per-entry points.
export function expandGame(
  gameCode: string,
  sel: Record<string, unknown>,
  points: number,
  marketCode: string,
  slot: 'open' | 'close'
): ExpandedBet[] {
  const def = GAME_BY_CODE[gameCode]
  if (!def) throw new Error('Unknown game: ' + gameCode)
  const out: ExpandedBet[] = []
  const push = (type: string, num: string, slot2: string, rate: number, erpSub = def.erpSub, erpGroup = def.erpGroup) =>
    out.push({ type, num, slot: slot2, rate, erpSub, erpGroup })

  const mkJodiSlot = marketCode.startsWith('st') ? 'open' : 'jodi'
  const pannaSlot = marketCode.startsWith('st') ? 'open' : slot

  switch (gameCode) {
    case 'single':
      push('single', String(sel.digit), marketCode.startsWith('st') ? 'open' : slot, def.rates[marketCode.startsWith('st') ? 'star' : 'main'])
      break
    case 'jodi':
      push('jodi', String(sel.jodi), mkJodiSlot, def.rates.main)
      break
    case 'sp':
    case 'sp_common':
      if (sel.panna) {
        push('sp', String(sel.panna), pannaSlot, def.rates[marketCode.startsWith('st') ? 'star' : 'main'])
      } else {
        SPB[String(sel.ank)].forEach(p => push('sp', p, pannaSlot, def.rates[marketCode.startsWith('st') ? 'star' : 'main']))
      }
      break
    case 'dp':
    case 'dp_common':
      if (sel.panna) {
        push('dp', String(sel.panna), pannaSlot, def.rates[marketCode.startsWith('st') ? 'star' : 'main'])
      } else {
        DPB[String(sel.ank)].forEach(p => push('dp', p, pannaSlot, def.rates[marketCode.startsWith('st') ? 'star' : 'main']))
      }
      break
    case 'tp':
      push('tp', String(sel.panna), pannaSlot, def.rates[marketCode.startsWith('st') ? 'star' : 'main'])
      break
    case 'tp_family':
      push('tp', TP[String(sel.digit)], pannaSlot, def.rates.main)
      break
    case 'spdptp': {
      const d = String(sel.digit)
      SPB[d].forEach(p => push('sp', p, pannaSlot, 140, 'group', 'SPDPTP'))
      DPB[d].forEach(p => push('dp', p, pannaSlot, 280, 'group', 'SPDPTP'))
      push('tp', TP[d], pannaSlot, 700, 'group', 'SPDPTP')
      break
    }
    case 'sp_motor': {
      const seed = String(sel.seed)
      const digs = seed.split('')
      // permutations of 3 from unique seed digits
      for (const a of digs) for (const b of digs) for (const c of digs) {
        if (a === b || b === c || a === c) continue
        push('sp', a + b + c, pannaSlot, def.rates.main)
      }
      break
    }
    case 'dp_motor': {
      dpMotorPannas(String(sel.seed)).forEach(p => push('dp', p, pannaSlot, def.rates.main))
      break
    }
    case 'two_digit':
      twoDigitPannas(Number(sel.a), Number(sel.b)).forEach(p => push('dp', p, pannaSlot, def.rates.main))
      break
    case 'digit_jodi':
      push('dj', String(sel.digit) + '-' + String(sel.panna), pannaSlot, def.rates.main)
      break
    case 'jodi_family':
      jodiFamily(Number(sel.a), Number(sel.b)).forEach(j => push('jodi', j, mkJodiSlot, def.rates.main))
      break
    case 'red_jodi':
      push('jodi', String(sel.jodi), mkJodiSlot, def.rates.main)
      break
    case 'cycle_jodi':
      push('jodi', String(sel.j1), mkJodiSlot, def.rates.main)
      push('jodi', String(sel.j2), mkJodiSlot, def.rates.main)
      break
    case 'digit_based_jodi':
      digitBasedJodis(Number(sel.digit)).forEach(j => push('jodi', j, mkJodiSlot, def.rates.main))
      break
    case 'hs_a':
      push('hs', String(sel.digit) + '-' + String(sel.panna), 'hs', def.rates.main)
      break
    case 'hs_b':
      push('hsb', String(sel.panna) + '-' + String(sel.digit), 'hs', def.rates.main)
      break
    case 'fs':
      push('fs', String(sel.open) + '-' + String(sel.close), 'fs', def.rates.main)
      break
    default:
      throw new Error('Game ' + gameCode + ' needs a dedicated flow')
  }
  return out
}

// Bulk (Starline) games: one pick × many hours → one entry per hour
export function expandBulkGame(
  gameCode: 'single_bulk' | 'sp_bulk' | 'dp_bulk',
  sel: Record<string, unknown>,
  points: number,
  hours: number[]
): ExpandedBet[] {
  const def = GAME_BY_CODE[gameCode]
  const out: ExpandedBet[] = []
  const rate = def.rates.star ?? 0
  const erpSub = def.erpSub, erpGroup = def.erpGroup
  for (const h of hours) {
    if (gameCode === 'single_bulk') out.push({ type: 'single', num: String(sel.digit), slot: 'open', rate, erpSub, erpGroup })
    if (gameCode === 'sp_bulk') SPB[String(sel.ank)].forEach(p => out.push({ type: 'sp', num: p, slot: 'open', rate, erpSub, erpGroup }))
    if (gameCode === 'dp_bulk') DPB[String(sel.ank)].forEach(p => out.push({ type: 'dp', num: p, slot: 'open', rate, erpSub, erpGroup }))
  }
  return out
}

// Total entries a selection will produce (for live preview counts)
export function previewCount(gameCode: string, sel: Record<string, unknown>): number {
  try {
    return expandGame(gameCode, sel, 0, 'main', 'open').length
  } catch {
    return 0
  }
}

// ── Weekly schedule helpers ──────────────────────────────────
export interface DayRow { open: string; close: string; enabled: boolean }
export type WeeklySchedule = Record<string, DayRow>

export function parseSchedule(json: string | null | undefined): WeeklySchedule {
  try {
    const v = JSON.parse(json || '{}')
    return v && typeof v === 'object' ? v : {}
  } catch { return {} }
}

/** Effective open/close + enabled for a market on a given date (defaults to today). */
export function effectiveTimes(
  market: { openTime: string; closeTime: string; weeklySchedule?: string | null; isActive: boolean },
  date?: Date
): { open: string; close: string; enabled: boolean; active: boolean } {
  const d = date || new Date()
  const sched = parseSchedule(market.weeklySchedule)
  const row = sched[String(d.getDay())]
  return {
    open: row?.open || market.openTime,
    close: row?.close || market.closeTime,
    enabled: row ? row.enabled !== false : true,
    active: market.isActive !== false,
  }
}

/** Slot accepting check honoring the weekly schedule + master toggle.
 *  Also enforces the per-market "bet closing minutes": bets for a session stop
 *  N minutes BEFORE its result time (open result @ openTime, close @ closeTime).
 *  e.g. Shridevi result 11:30, betCloseMinutes 5 → last close bet 11:25. */
export function slotAcceptingWeekly(
  market: { openTime: string; closeTime: string; weeklySchedule?: string | null; isActive: boolean; betCloseMinutes?: number | null },
  slot: 'open' | 'close',
  now = new Date()
): boolean {
  const t = effectiveTimes(market, now)
  if (!t.active || !t.enabled) return false
  const cur = now.getHours() * 60 + now.getMinutes()
  const o = minsOfT(t.open), c = minsOfT(t.close)
  const cut = Math.max(0, Number(market.betCloseMinutes ?? 0) || 0)
  return slot === 'open' ? cur <= o - cut : cur >= o && cur <= c - cut
}

/** Live state of a market right now — used by the cron bot + admin panels. */
export function marketLiveState(
  market: { openTime: string; closeTime: string; weeklySchedule?: string | null; isActive: boolean; betCloseMinutes?: number | null },
  now = new Date()
): { state: 'off' | 'weekly-off' | 'open' | 'open-locked' | 'in-session' | 'session-locked' | 'closed'; openAccepting: boolean; closeAccepting: boolean } {
  const t = effectiveTimes(market, now)
  if (!t.active) return { state: 'off', openAccepting: false, closeAccepting: false }
  if (!t.enabled) return { state: 'weekly-off', openAccepting: false, closeAccepting: false }
  const openAccepting = slotAcceptingWeekly(market, 'open', now)
  const closeAccepting = slotAcceptingWeekly(market, 'close', now)
  let state: 'open' | 'open-locked' | 'in-session' | 'session-locked' | 'closed'
  if (openAccepting) state = 'open'
  else if (closeAccepting) state = 'in-session'
  else state = 'closed'
  return { state, openAccepting, closeAccepting }
}

// ── WhatsApp paste parser (customer app "paste data" provision) ──
// Accepts the formats operators commonly share on WhatsApp:
//   5=100 · 5 - 100 · 5:100 · 5 100      single number + points
//   5,6,7 = 100 · 5 6 7-100              number list, points each
//   128=50                               panna + points (panna games)
//   5-128=100                            digit-panna pairs (sangam / digit jodi)
//   05 12 71 = 20                        jodi list + points
// One entry per line, or several on one line separated by spaces/commas
// when a single amount follows the group.
export interface PastedEntry { num: string; points: number }
export function parsePastedData(
  text: string,
  gameCode: string
): { entries: PastedEntry[]; errors: string[] } {
  const entries: PastedEntry[] = []
  const errors: string[] = []
  const lines = String(text || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean)
  // Sangam / digit-jodi pair games: "5-128=100", "128-5=100", "128-246=100"
  const pad3 = (s: string) => s.padStart(3, '0')
  const pairGame = gameCode === 'hs_a' || gameCode === 'hs_b' || gameCode === 'fs' || gameCode === 'digit_jodi'
  for (const line of lines) {
    const clean = line.replace(/[₹]/g, ' ').replace(/total|pnts?|points/gi, ' ').trim()
    if (!clean) continue
    if (pairGame) {
      const mPair = clean.match(/^(\d{1,3})\s*[-–]\s*(\d{1,3})\s*[=:]\s*(\d+)$/)
      if (mPair) {
        const a = mPair[1], b = pad3(mPair[2]), pts = Number(mPair[3])
        if (gameCode === 'hs_b') entries.push({ num: pad3(a) + '-' + String(Number(b)), points: pts })
        else if (gameCode === 'fs') entries.push({ num: pad3(a) + '-' + pad3(mPair[2]), points: pts })
        else entries.push({ num: String(Number(a)) + '-' + b, points: pts })
        continue
      }
      const mNo = clean.match(/^(\d{1,3})\s*[-–]\s*(\d{1,3})\s*$/)
      if (mNo) { errors.push(`"${line}" — add points, e.g. ${mNo[1]}-${mNo[2]}=100`); continue }
    }
    // generic: numbers group [amount]
    const m = clean.match(/^((?:\d{1,3}\s*[, ]\s*)*\d{1,3})\s*(?:[=:]\s*(\d+)|-\s*(\d+))$/)
      || clean.match(/^((?:\d{1,3}\s*[, ]\s*)*\d{1,3})\s+(\d+)$/)
      || clean.match(/^((?:\d{1,3}\s*[, ]\s*)*\d{1,3})\s*[=:]\s*(\d+)$/)
    if (!m) { errors.push(`"${line}" is not in a known format (use 5=100 or 5,6=100)`); continue }
    const nums = m[1].split(/[, ]+/).map(s => s.trim()).filter(Boolean)
    const pts = Number(m[2] || m[3] || 0)
    if (!pts) { errors.push(`"${line}" — amount missing`); continue }
    for (const n of nums) entries.push({ num: n, points: pts })
  }
  return { entries, errors }
}

export function minsOfT(t: string): number {
  const parts = t.split(':').map(Number)
  return (parts[0] || 0) * 60 + (parts[1] || 0)
}

// Day labels for admin editors + app (en; the app maps via i18n)
export const DAY_KEYS = ['0', '1', '2', '3', '4', '5', '6']
export const DAY_LABELS: Record<string, string> = {
  '0': 'Sunday', '1': 'Monday', '2': 'Tuesday', '3': 'Wednesday',
  '4': 'Thursday', '5': 'Friday', '6': 'Saturday',
}
