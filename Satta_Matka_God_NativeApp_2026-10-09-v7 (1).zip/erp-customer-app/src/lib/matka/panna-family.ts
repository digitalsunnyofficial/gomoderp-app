/**
 * Family Set definitions for the Matka Group Mode.
 *
 * Three family set options with OPERATOR-VERIFIED data:
 *   - Family Set 4: 4 pannas per family (TP-based)
 *   - Family Set 6: 6 pannas per family (DP-based)
 *   - Family Set 8: 8 pannas per family (SP-based)
 *
 * Keys are stored in NORMALIZED (digit-sorted) form so that
 * normalizeDigitSet(seed) always produces a matching key.
 *
 * NOTE: '150', '200', '300' are intentionally EXCLUDED from FAMILY_SET_8 —
 * they belong to FAMILY_SET_6 per operator spec (each has 6 pannas, not 8).
 *
 * UPDATE 2026-09-07: Added 5 previously missing families to FAMILY_SET_6
 * (149, 150, 233, 200, 300) to complete the full 20-family chart.
 */

import { normalizeDigitSet } from './chart-definitions'

// Helper to strip a "()" suffix from a label (used for display normalization)
export function stripParenSuffix(label: string): string {
  const i = label.indexOf('(')
  return i > 0 ? label.slice(0, i).trim() : label.trim()
}

// ────────────────────────────────────────────────────────────────────────────
// FAMILY_SET_4 — 4 pannas per family (operator-verified)
// Keys in normalized form
// ────────────────────────────────────────────────────────────────────────────
export const FAMILY_SET_4: Map<string, string[]> = new Map(Object.entries({
  '111': ['111','116','166','666'],
  '222': ['222','227','277','777'],
  '333': ['333','338','388','888'],
  '444': ['444','449','499','999'],
  '000': ['000','500','550','555'],
}))

// ────────────────────────────────────────────────────────────────────────────
// FAMILY_SET_6 — 6 pannas per family (operator-verified)
// Keys in normalized form (digit-sorted)
// Full 20-family chart per operator spec (2026-09-07):
//   112,113,114,115,122,133,149,150,223,224,225,233,244,200,
//   334,330,344,300,440,400  ← previously 5 were missing (149,150,233,200,300)
// ────────────────────────────────────────────────────────────────────────────
export const FAMILY_SET_6: Map<string, string[]> = new Map(Object.entries({
  '112': ['112','117','126','167','266','667'],
  '113': ['113','118','136','168','366','668'],
  '114': ['114','119','146','169','466','669'],
  '115': ['115','110','156','160','566','660'],
  '122': ['122','127','177','226','267','677'],
  '133': ['133','138','188','336','368','688'],
  '149': ['149','144','199','446','469','699'],   // ← previously missing
  '015': ['150','100','155','556','560','600'],   // ← previously missing (user reported 150 not updating)
  '223': ['223','228','237','278','377','778'],
  '224': ['224','229','247','279','477','779'],
  '225': ['225','220','257','270','577','770'],
  '233': ['233','238','288','337','378','788'],   // ← previously missing
  '244': ['244','249','299','447','479','799'],
  '002': ['200','250','255','557','570','700'],   // ← previously missing
  '334': ['334','339','348','389','488','889'],
  '033': ['330','335','358','380','588','880'],
  '344': ['344','349','399','448','489','899'],
  '003': ['300','350','355','558','580','800'],   // ← previously missing
  '044': ['440','445','459','490','599','990'],
  '004': ['400','450','455','559','590','900'],
}))

// ────────────────────────────────────────────────────────────────────────────
// FAMILY_SET_8 — 8 pannas per family (operator-verified)
// Keys in normalized form
// NOTE: '150'→'015', '200'→'002', '300'→'003' intentionally EXCLUDED
// ────────────────────────────────────────────────────────────────────────────
export const FAMILY_SET_8: Map<string, string[]> = new Map(Object.entries({
  '012': ['120','125','157','170','256','260','567','670'],
  '123': ['123','128','137','178','236','268','367','678'],
  '124': ['124','129','147','179','246','269','467','679'],
  '013': ['130','135','158','180','356','360','568','680'],
  '134': ['134','139','148','189','346','369','468','689'],
  '014': ['140','145','159','190','456','460','569','690'],
  '234': ['234','239','248','289','347','379','478','789'],
  '023': ['230','235','258','280','357','370','578','780'],
  '024': ['240','245','259','290','457','470','579','790'],
  '034': ['340','345','359','390','458','480','589','890'],
}))

// ────────────────────────────────────────────────────────────────────────────
// Builder functions — lookup from verified tables via normalizeDigitSet
// ────────────────────────────────────────────────────────────────────────────

export function buildFamilySet4(seed: string): string[] {
  const cleaned = seed.replace(/\D/g, '').slice(0, 3)
  if (cleaned.length < 3) return []
  // Try resolveFamilyKey for reverse lookup (handles member pannas, not just canonical keys)
  const resolved = resolveFamilyKey(cleaned)
  if (resolved && resolved.setType === 'Family Set 4') return resolved.pannas
  return []
}

export function buildFamilySet6(seed: string): string[] {
  const cleaned = seed.replace(/\D/g, '').slice(0, 3)
  if (cleaned.length < 3) return []
  // Try resolveFamilyKey for reverse lookup (handles member pannas, not just canonical keys)
  const resolved = resolveFamilyKey(cleaned)
  if (resolved && resolved.setType === 'Family Set 6') return resolved.pannas
  return []
}

export function buildFamilySet8(seed: string): string[] {
  const cleaned = seed.replace(/\D/g, '').slice(0, 3)
  if (cleaned.length < 3) return []
  // Try resolveFamilyKey for reverse lookup (handles member pannas, not just canonical keys)
  const resolved = resolveFamilyKey(cleaned)
  if (resolved && resolved.setType === 'Family Set 8') return resolved.pannas
  return []
}

export const FAMILY_SET_BUILDERS: Record<string, (seed: string) => string[]> = {
  'Family Set 4': buildFamilySet4,
  'Family Set 6': buildFamilySet6,
  'Family Set 8': buildFamilySet8,
}

// ────────────────────────────────────────────────────────────────────────────
// resolveFamilyKey — reverse lookup: panna → family key across all 3 sets
// ────────────────────────────────────────────────────────────────────────────

export function resolveFamilyKey(
  panna: string
): { key: string; setType: 'Family Set 4' | 'Family Set 6' | 'Family Set 8'; pannas: string[] } | null {
  // First try direct key lookup (normalized form matches a family key)
  const key = normalizeDigitSet(panna)

  const f4 = FAMILY_SET_4.get(key)
  if (f4) return { key, setType: 'Family Set 4', pannas: f4 }

  const f6 = FAMILY_SET_6.get(key)
  if (f6) return { key, setType: 'Family Set 6', pannas: f6 }

  const f8 = FAMILY_SET_8.get(key)
  if (f8) return { key, setType: 'Family Set 8', pannas: f8 }

  // Reverse lookup: the panna might be a member of a family but not the key itself
  // e.g., '999' is in FAMILY_SET_4 key='444' → ['444','449','499','999']
  for (const [fKey, fPannas] of FAMILY_SET_4) {
    if (fPannas.includes(panna)) return { key: fKey, setType: 'Family Set 4', pannas: fPannas }
  }
  for (const [fKey, fPannas] of FAMILY_SET_6) {
    if (fPannas.includes(panna)) return { key: fKey, setType: 'Family Set 6', pannas: fPannas }
  }
  for (const [fKey, fPannas] of FAMILY_SET_8) {
    if (fPannas.includes(panna)) return { key: fKey, setType: 'Family Set 8', pannas: fPannas }
  }

  return null
}

// ────────────────────────────────────────────────────────────────────────────
// COMBINED FAMILY CHART (2026-09 operator update)
// Family Set 4 + Family Set 6 + Family Set 8 merge into ONE "Family" chart:
// a seed panna resolves to its family across ALL three sets. Every panna
// still belongs to exactly one family, so the combined chart is the union —
// the individual set games remain available and untouched.
// ────────────────────────────────────────────────────────────────────────────

export function buildFamilyCombined(seed: string): { pannas: string[]; setType: string | null } {
  const cleaned = seed.replace(/\D/g, '').slice(0, 3)
  if (cleaned.length < 3) return { pannas: [], setType: null }
  const resolved = resolveFamilyKey(cleaned)
  if (!resolved) return { pannas: [], setType: null }
  return { pannas: resolved.pannas, setType: resolved.setType }
}
