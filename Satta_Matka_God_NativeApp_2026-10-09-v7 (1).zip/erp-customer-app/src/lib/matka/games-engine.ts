// ──────────────────────────────────────────────────────────
// GAMES ENGINE — catalog + expansion/calculation for every
// game in the customer app. Client-safe (no server imports).
//
// Payout model: each expanded row is a standard bet type
// (single/jodi/sp/dp/tp) so settlement reuses betWins(); the
// row rate = game/allocation override when set, else the
// standard rate for the row type.
// Verified behaviour (2026-09 operator parity fix): Motor Pana and SP Motor
// now calculate EXACTLY like the admin panel's Motor Pana group preview —
// every C(n,3) combination of 3 DIFFERENT digits from the seed, one
// canonical spelling each. Seed 13467 → 10 pannas; the full digit set 0-9
// → the 120-panna SP universe (the admin preview count). No repeated-digit
// pannas, no extra orderings of the same digit set. DP Motor keeps the
// operator's verbatim chart (DP_MOTOR_CHART).
// ──────────────────────────────────────────────────────────
import { SPB, DPB, TP, classifyPanna, deriveDigit, type BetType } from './app-engine'
import {
  CHART_50_PANNAS, CHART_60_PANNAS, CHART_70_PANNAS,
  CHART_90_DP, CHART_ABR9_PANNAS,
  CHART_20_PANNAS, CHART_30_PANNAS, CHART_40_PANNAS,
  DP_MOTOR_CHART, pannaKey, canonicalPanna,
} from './chart-definitions'
import { resolveFamilyKey, buildFamilyCombined } from './panna-family'

export interface GameSeed {
  code: string
  name: string
  category: 'digit' | 'jodi' | 'panna' | 'sangam' | 'motor' | 'family' | 'chart' | 'special'
  base: 'ank' | 'jodi' | 'panna' | 'digits' | 'pair' | 'oddeven' | 'none'
  session: 'open' | 'close' | 'both'
  erpMapping: string
  defaultRate: number
  expansion: string
  icon: string
  sortOrder: number
}

// Rate card aligned with app-engine RATES
export const GAME_RATES: Record<string, number> = {
  single: 9, jodi: 90, sp: 140, dp: 280, tp: 700,
  hs: 1500, hsb: 1500, fs: 8000, oddeven: 1.95,
}

// ── The full catalog — 28 games (classic set + Jodi + Sangam A/B + motors +
// combos + families incl. the combined Family Chart + 20/30/40/50/60/70/90 charts) ──
export const GAME_CATALOG: GameSeed[] = [
  { code: 'single', name: 'Single Digit', category: 'digit', base: 'ank', session: 'both', erpMapping: 'Single', defaultRate: 9, expansion: 'none', icon: 'zap', sortOrder: 1 },
  { code: 'jodi', name: 'Jodi', category: 'jodi', base: 'jodi', session: 'both', erpMapping: 'Jodi', defaultRate: 90, expansion: 'none', icon: 'layers', sortOrder: 2 },
  { code: 'sp', name: 'Single Pana', category: 'panna', base: 'panna', session: 'both', erpMapping: 'SP', defaultRate: 140, expansion: 'none', icon: 'layers', sortOrder: 3 },
  { code: 'dp', name: 'Double Pana', category: 'panna', base: 'panna', session: 'both', erpMapping: 'DP', defaultRate: 280, expansion: 'none', icon: 'layers', sortOrder: 4 },
  { code: 'tp', name: 'Triple Pana', category: 'panna', base: 'panna', session: 'close', erpMapping: 'TP', defaultRate: 700, expansion: 'none', icon: 'layers', sortOrder: 5 },
  { code: 'hs', name: 'Half Sangam A', category: 'sangam', base: 'pair', session: 'both', erpMapping: 'Half Sangam A', defaultRate: 1500, expansion: 'none', icon: 'star', sortOrder: 6 },
  { code: 'hsb', name: 'Half Sangam B', category: 'sangam', base: 'pair', session: 'both', erpMapping: 'Half Sangam B', defaultRate: 1500, expansion: 'none', icon: 'star', sortOrder: 24 },
  { code: 'fs', name: 'Full Sangam', category: 'sangam', base: 'pair', session: 'both', erpMapping: 'Full Sangam', defaultRate: 8000, expansion: 'none', icon: 'star', sortOrder: 7 },
  { code: 'oddeven', name: 'Odd / Even', category: 'special', base: 'oddeven', session: 'open', erpMapping: 'Odd Even', defaultRate: 1.95, expansion: 'none', icon: 'circle', sortOrder: 8 },
  { code: 'sp-motor', name: 'SP Motor', category: 'motor', base: 'digits', session: 'both', erpMapping: 'Motor Pana', defaultRate: 140, expansion: 'sp-motor', icon: 'flask-conical', sortOrder: 9 },
  { code: 'dp-motor', name: 'DP Motor', category: 'motor', base: 'digits', session: 'both', erpMapping: 'Motor Pana', defaultRate: 280, expansion: 'dp-motor', icon: 'flask-conical', sortOrder: 10 },
  { code: 'motor', name: 'Motor Pana', category: 'motor', base: 'digits', session: 'both', erpMapping: 'Motor Pana', defaultRate: 140, expansion: 'motor', icon: 'flask-conical', sortOrder: 11 },
  { code: 'spdp', name: 'SP DP', category: 'panna', base: 'panna', session: 'both', erpMapping: 'SPDP', defaultRate: 140, expansion: 'spdp', icon: 'layers', sortOrder: 12 },
  { code: 'sptp', name: 'SP TP', category: 'panna', base: 'panna', session: 'both', erpMapping: 'SPTP', defaultRate: 140, expansion: 'sptp', icon: 'layers', sortOrder: 13 },
  { code: 'dptp', name: 'DP TP', category: 'panna', base: 'panna', session: 'both', erpMapping: 'DPTP', defaultRate: 280, expansion: 'dptp', icon: 'layers', sortOrder: 14 },
  { code: 'spdptp', name: 'SP DP TP', category: 'panna', base: 'panna', session: 'both', erpMapping: 'SPDPTP', defaultRate: 140, expansion: 'spdptp', icon: 'layers', sortOrder: 15 },
  { code: 'family-4', name: 'Family Set 4', category: 'family', base: 'panna', session: 'both', erpMapping: 'Family Set 4', defaultRate: 140, expansion: 'family4', icon: 'layers', sortOrder: 16 },
  { code: 'family-6', name: 'Family Set 6', category: 'family', base: 'panna', session: 'both', erpMapping: 'Family Set 6', defaultRate: 140, expansion: 'family6', icon: 'layers', sortOrder: 17 },
  { code: 'family-8', name: 'Family Set 8', category: 'family', base: 'panna', session: 'both', erpMapping: 'Family Set 8', defaultRate: 140, expansion: 'family8', icon: 'layers', sortOrder: 18 },
  { code: 'chart-50', name: '50 Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '50 Chart', defaultRate: 140, expansion: 'chart50', icon: 'download', sortOrder: 19 },
  { code: 'chart-60', name: '60 Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '60 Chart', defaultRate: 140, expansion: 'chart60', icon: 'download', sortOrder: 20 },
  { code: 'chart-70', name: '70 Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '70 Chart', defaultRate: 140, expansion: 'chart70', icon: 'download', sortOrder: 21 },
  { code: 'chart-90dp', name: '90 DP Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '90 DP Chart', defaultRate: 280, expansion: 'chart90dp', icon: 'download', sortOrder: 22 },
  { code: 'chart-abr', name: '90 ABR Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '90 ABR Chart', defaultRate: 140, expansion: 'chart90abr', icon: 'download', sortOrder: 23 },
  { code: 'chart-20', name: '20 Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '20 Chart', defaultRate: 140, expansion: 'chart20', icon: 'download', sortOrder: 25 },
  { code: 'chart-30', name: '30 Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '30 Chart', defaultRate: 140, expansion: 'chart30', icon: 'download', sortOrder: 26 },
  { code: 'chart-40', name: '40 Chart', category: 'chart', base: 'panna', session: 'both', erpMapping: '40 Chart', defaultRate: 140, expansion: 'chart40', icon: 'download', sortOrder: 27 },
  { code: 'family', name: 'Family Chart', category: 'family', base: 'panna', session: 'both', erpMapping: 'Family Chart', defaultRate: 140, expansion: 'family', icon: 'users', sortOrder: 28 },
]

export function gameLabel(code: string): string {
  return GAME_CATALOG.find(g => g.code === code)?.name || code
}

// ── Expansion result ──
export interface ExpandRow {
  num: string            // bet number ("5", "70", "128")
  type: BetType          // standard settlement type
  ok: boolean
  reason?: string        // when not ok
}

// ── Motor calculation — ADMIN PARITY (2026-09 operator fix) ──
// The operator showed the admin panel Motor Pana calculation listing 120
// pannas (full digit set) while the app produced 125 for a 5-digit seed.
// Root cause: the app generated n³ ARRANGEMENTS (repetition allowed) —
// counting 6 orderings of the same panna (134/143/314/341/413/431) and
// including repeated-digit (DP) and triple (TP) rows the admin motor never
// produces. The admin calculation (generateGroupPannas 'Motor Pana' →
// generateSP) plays every C(n,3) combination of 3 DIFFERENT digits, one
// panna each. This function now implements exactly that, with the app-wide
// canonical spelling (ascending digits, 0 last) applied to every row.
// Motor Pana and SP Motor share this one logic ("always same" per operator).
function motorRows(seed: string): ExpandRow[] {
  const seen = new Set<string>()
  const digits: string[] = []
  for (const ch of seed) {
    if (ch >= '0' && ch <= '9' && !seen.has(ch)) { seen.add(ch); digits.push(ch) }
  }
  if (digits.length < 3) {
    return [{ num: seed, type: 'sp', ok: false, reason: 'motor needs at least 3 DIFFERENT digits — it plays the 3-different-digit pannas of your digit set (admin parity)' }]
  }
  digits.sort()
  const out: ExpandRow[] = []
  const n = digits.length
  for (let i = 0; i < n - 2; i++) {
    for (let j = i + 1; j < n - 1; j++) {
      for (let k = j + 1; k < n; k++) {
        out.push({ num: canonicalPanna(digits[i] + digits[j] + digits[k]), type: 'sp', ok: true })
      }
    }
  }
  return out
}

function chartRows(map: Map<number, string[]>, seed: string, type: BetType): ExpandRow[] {
  const cleaned = seed.replace(/\D/g, '')
  if (!cleaned) return [{ num: seed, type, ok: false, reason: 'enter an ank or panna' }]
  if (cleaned.length === 1) {
    const rows = map.get(Number(cleaned)) || []
    if (!rows.length) return [{ num: seed, type, ok: false, reason: 'no entries for this ank in the chart' }]
    return rows.map(p => ({ num: p, type, ok: true }))
  }
  if (cleaned.length === 3) {
    // a specific panna — find which ank bucket holds it
    for (const [, rows] of map) {
      if (rows.includes(cleaned)) return [{ num: cleaned, type, ok: true }]
    }
    return [{ num: cleaned, type, ok: false, reason: 'not in this chart' }]
  }
  return [{ num: seed, type, ok: false, reason: 'enter an ank (0-9) or a 3-digit panna' }]
}

function pannaClassified(seed: string, allowed: Array<'sp' | 'dp' | 'tp'>): ExpandRow {
  const cleaned = seed.replace(/\D/g, '')
  if (!/^\d{3}$/.test(cleaned)) return { num: seed, type: 'sp', ok: false, reason: 'enter a 3-digit panna' }
  const cls = classifyPanna(cleaned) as 'sp' | 'dp' | 'tp'
  if (!allowed.includes(cls)) {
    return { num: cleaned, type: cls as BetType, ok: false, reason: `this is a ${cls.toUpperCase()} panna — not allowed in this game` }
  }
  return { num: cleaned, type: cls as BetType, ok: true }
}

// Family Set expansion: the seed panna must belong to the requested set type —
// every panna belongs to exactly one family set (4, 6 or 8 members).
function familyRows(seed: string, wanted: 'Family Set 4' | 'Family Set 6' | 'Family Set 8'): { rows: ExpandRow[]; error?: string } {
  const cleaned = seed.replace(/\D/g, '')
  if (!/^\d{3}$/.test(cleaned)) return { rows: [], error: 'Enter a 3-digit panna' }
  const resolved = resolveFamilyKey(cleaned)
  if (!resolved) {
    return { rows: [{ num: cleaned, type: 'sp', ok: false, reason: 'this panna is not in any family set' }] }
  }
  if (resolved.setType !== wanted) {
    return { rows: [{ num: cleaned, type: 'sp', ok: false, reason: `this panna belongs to ${resolved.setType} — switch the game` }] }
  }
  return { rows: resolved.pannas.map(p => ({ num: p, type: classifyPanna(p) as BetType, ok: true })) }
}

// ── Ank-family expansion (2026-09 operator update) ──
// The customer picks ONE ank digit and every panna of that ank is selected —
// the same digit-sum grouping as the master-admin SP/DP/TP charts (SP 12 per
// ank, DP 9, TP the one triple whose digit-sum ank matches). Combo games
// (SPDP/SPTP/DPTP/SPDPTP) expand to the union, each row typed by its own
// class so settlement stays standard sp/dp/tp via betWins().
export function ankFamilyRows(gameCode: string, ankDigit: string): ExpandRow[] {
  const d = String(Number(ankDigit))
  if (!/^[0-9]$/.test(d)) return []
  const sp = (SPB[d] || []).map(p => ({ num: p, type: 'sp' as BetType, ok: true }))
  const dp = (DPB[d] || []).map(p => ({ num: p, type: 'dp' as BetType, ok: true }))
  const tpPanna = TP.find(x => deriveDigit(x) === d)
  const tp: ExpandRow[] = tpPanna ? [{ num: tpPanna, type: 'tp', ok: true }] : []
  switch (gameCode) {
    case 'sp': return sp
    case 'dp': return dp
    case 'tp': return tp
    case 'spdp': return [...sp, ...dp]
    case 'sptp': return [...sp, ...tp]
    case 'dptp': return [...dp, ...tp]
    case 'spdptp': return [...sp, ...dp, ...tp]
    default: return []
  }
}

// Games that accept a single ank digit as a "bet the whole ank" seed
export const ANK_FAMILY_CODES = ['sp', 'dp', 'tp', 'spdp', 'sptp', 'dptp', 'spdptp']

// ── Expand a seed-based game into its bet rows ──
// For classic grid games (single/jodi/sp/dp/tp) the seed IS the number —
// validated by length/classification so the caller can post the bet directly.
export function expandGame(gameCode: string, seedInput: string): { rows: ExpandRow[]; error?: string } {
  const game = GAME_CATALOG.find(g => g.code === gameCode)
  if (!game) return { rows: [], error: 'Unknown game' }
  const seed = String(seedInput || '').trim()
  if (!seed) return { rows: [], error: 'Enter your numbers first' }

  // Ank-bulk: a single-digit seed on the panna family games selects the
  // WHOLE ank (same digit-sum grouping as the master-admin charts)
  const bare = seed.replace(/\D/g, '')
  if (/^\d$/.test(bare) && ANK_FAMILY_CODES.includes(game.code)) {
    return { rows: ankFamilyRows(game.code, bare) }
  }

  switch (game.expansion) {
    case 'none': {
      const n = seed.replace(/\D/g, '')
      if (game.base === 'ank') {
        if (!/^\d$/.test(n)) return { rows: [], error: 'Enter a single digit (0-9)' }
        return { rows: [{ num: n, type: 'single', ok: true }] }
      }
      if (game.base === 'jodi') {
        if (!/^\d{2}$/.test(n)) return { rows: [], error: 'Enter a 2-digit jodi (00-99)' }
        return { rows: [{ num: n, type: 'jodi', ok: true }] }
      }
      if (game.base === 'oddeven') {
        const v = seed.toLowerCase()
        if (v !== 'odd' && v !== 'even') return { rows: [], error: 'Pick ODD or EVEN' }
        return { rows: [{ num: v, type: 'oddeven', ok: true }] }
      }
      if (game.base === 'pair') {
        // hs-a "X-PPP" / hs-b "PPP-X" / fs "PPP-QQQ" pass through — built by the dedicated UI
        const pairType = game.code === 'hs' ? 'hs' : game.code === 'hsb' ? 'hsb' : 'fs'
        return { rows: [{ num: seed, type: pairType, ok: true }] }
      }
      // panna
      if (!/^\d{3}$/.test(n)) return { rows: [], error: 'Enter a 3-digit panna' }
      const cls = classifyPanna(n)
      if (game.code === 'sp' && cls !== 'sp') return { rows: [], error: 'Not a valid Single Panna' }
      if (game.code === 'dp' && cls !== 'dp') return { rows: [], error: 'Not a valid Double Panna' }
      if (game.code === 'tp' && cls !== 'tp') return { rows: [], error: 'Not a valid Triple Panna' }
      return { rows: [{ num: n, type: cls as BetType, ok: true }] }
    }
    case 'sp-motor': return { rows: motorRows(seed) }
    case 'dp-motor': {
      // Operator DP Motor chart (2026-09): ank digit → the ank's full DP
      // family (smallest-non-zero-digit ownership); a 3-digit seed must be a
      // chart member. Motor Pana and SP Motor use the admin-parity motor
      // calculation above.
      const n = seed.replace(/\D/g, '')
      if (/^\d$/.test(n)) {
        const rows = DP_MOTOR_CHART.get(n === '0' ? 10 : Number(n)) || []
        if (!rows.length) return { rows: [{ num: seed, type: 'dp', ok: false, reason: 'no entries for this ank in the DP Motor chart' }] }
        return { rows: rows.map(p => ({ num: p, type: 'dp' as BetType, ok: true })) }
      }
      if (/^\d{3}$/.test(n)) {
        for (const [, rows] of DP_MOTOR_CHART) {
          const hit = rows.find(p => pannaKey(p) === pannaKey(n))
          if (hit) return { rows: [{ num: hit, type: 'dp', ok: true }] }
        }
        return { rows: [{ num: n, type: 'dp', ok: false, reason: 'not in the DP Motor chart' }] }
      }
      return { rows: [{ num: seed, type: 'dp', ok: false, reason: 'enter an ank (0-9) or a 3-digit panna' }] }
    }
    case 'motor': return { rows: motorRows(seed) }
    case 'spdp': return { rows: [pannaClassified(seed, ['sp', 'dp'])] }
    case 'sptp': return { rows: [pannaClassified(seed, ['sp', 'tp'])] }
    case 'dptp': return { rows: [pannaClassified(seed, ['dp', 'tp'])] }
    case 'spdptp': return { rows: [pannaClassified(seed, ['sp', 'dp', 'tp'])] }
    case 'family4': return familyRows(seed, 'Family Set 4')
    case 'family6': return familyRows(seed, 'Family Set 6')
    case 'family8': return familyRows(seed, 'Family Set 8')
    case 'family': {
      // Combined Family chart — seed resolves across Sets 4, 6 and 8
      const cleaned = seed.replace(/\D/g, '')
      if (!/^\d{3}$/.test(cleaned)) return { rows: [], error: 'Enter a 3-digit panna' }
      const comb = buildFamilyCombined(cleaned)
      if (!comb.setType) {
        return { rows: [{ num: cleaned, type: 'sp', ok: false, reason: 'this panna is not in any family set' }] }
      }
      return { rows: comb.pannas.map(p => ({ num: p, type: classifyPanna(p) as BetType, ok: true })) }
    }
    case 'chart20': return { rows: chartRows(CHART_20_PANNAS, seed, 'sp') }
    case 'chart30': return { rows: chartRows(CHART_30_PANNAS, seed, 'sp') }
    case 'chart40': return { rows: chartRows(CHART_40_PANNAS, seed, 'sp') }
    case 'chart50': return { rows: chartRows(CHART_50_PANNAS, seed, 'sp') }
    case 'chart60': return { rows: chartRows(CHART_60_PANNAS, seed, 'sp') }
    case 'chart70': return { rows: chartRows(CHART_70_PANNAS, seed, 'sp') }
    case 'chart90dp': return { rows: chartRows(CHART_90_DP, seed, 'dp') }
    case 'chart90abr': return { rows: chartRows(CHART_ABR9_PANNAS, seed, 'sp') }
    default: return { rows: [], error: 'This game has no expansion defined' }
  }
}

// Total points preview: rows × per-row points
export function expansionTotals(rows: ExpandRow[], points: number): { count: number; total: number } {
  const ok = rows.filter(r => r.ok)
  return { count: ok.length, total: ok.length * points }
}

// Rate for an expanded row: game/allocation override wins, else standard type rate
export function rowRate(gameRate: number | null | undefined, type: string, marketCode: string): number {
  if (gameRate && gameRate > 0) return gameRate
  if (marketCode && marketCode.startsWith('st')) {
    const star: Record<string, number> = { single: 9.5, oddeven: 1.95, sp: 140, dp: 280, tp: 700 }
    return star[type] ?? 9.5
  }
  return GAME_RATES[type] ?? 0
}

// Universes re-exported for the play UI grids
export { SPB, DPB, TP }
