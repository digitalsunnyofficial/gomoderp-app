/**
 * Mapping from page dropdown values to GroupOption type values.
 *
 * The page.tsx <select> dropdown uses display labels like
 * "50 Chart (Motor+Cuts)" while the GroupOption type uses
 * "50 Chart". This module provides the conversion.
 */

import type { GroupOption } from './group-types'

/**
 * Map a page dropdown value (or a raw group type string) to a GroupOption.
 * Returns null if the value doesn't match any known option.
 */
export function mapPageValueToOption(value: string): GroupOption | null {
  // Direct match (already a GroupOption)
  const knownOptions: GroupOption[] = [
    'SP', 'DP', 'TP',
    'SPDP', 'SPTP', 'DPTP', 'SPDPTP',
    'Motor Pana', 'SP Motor', 'DP Motor',
    '20 Chart', '30 Chart', '40 Chart',
    '50 Chart', '60 Chart', '70 Chart',
    '90 DP Chart', '90 ABR Chart',
    'Family Set 4', 'Family Set 6', 'Family Set 8', 'Family Chart',
  ]
  if (knownOptions.includes(value as GroupOption)) {
    return value as GroupOption
  }

  // Try matching by prefix (e.g., "50 Chart (Motor+Cuts)" → "50 Chart")
  for (const opt of knownOptions) {
    if (value.startsWith(opt)) return opt
  }

  return null
}
