/**
 * Chart / type reference constants for the Matka Group Batch feature.
 *
 * ════════════════════════════════════════════════════════════════════════════
 * VERIFIED HARDCODED DATA — operator-confirmed chart constants
 * ════════════════════════════════════════════════════════════════════════════
 *
 * CHART_50_CUT, CHART_70_JODI7, CHART_90_DP, and CHART_ABR9 contain
 * operator-verified static data. Do NOT re-derive these from SP_UNIVERSE
 * ordering — the panna selections are irregular and specific.
 *
 * CHART_60 is COMPUTED from CHART_70_JODI7 (slice 0,6) so the two can
 * never drift out of sync.
 */

// ────────────────────────────────────────────────────────────────────────────
// Panna classification helpers (pure, no external deps)
// ────────────────────────────────────────────────────────────────────────────

/**
 * Returns true if a 3-digit panna has all 3 digits different (Single Panna).
 */
export function isSP(panna: string): boolean {
  if (!/^\d{3}$/.test(panna)) return false
  const [a, b, c] = panna.split('').map(Number)
  return a !== b && a !== c && b !== c
}

/**
 * Returns true if a 3-digit panna has exactly 2 digits the same (Double Panna).
 */
export function isDP(panna: string): boolean {
  if (!/^\d{3}$/.test(panna)) return false
  const [a, b, c] = panna.split('').map(Number)
  const same = (a === b ? 1 : 0) + (a === c ? 1 : 0) + (b === c ? 1 : 0)
  return same === 1
}

/**
 * Returns true if a 3-digit panna has all 3 digits the same (Triple Panna).
 */
export function isTP(panna: string): boolean {
  if (!/^\d{3}$/.test(panna)) return false
  const [a, b, c] = panna.split('').map(Number)
  return a === b && b === c
}

/**
 * The ank (column 1-10) of a panna = (digitSum % 10), with 0 mapped to 10.
 */
export function pannaToAnk(panna: string): number {
  if (!/^\d{3}$/.test(panna)) return 0
  const sum = panna.split('').reduce((s, d) => s + Number(d), 0)
  const ank = sum % 10
  return ank === 0 ? 10 : ank
}

// ────────────────────────────────────────────────────────────────────────────
// The 220-Panna Chart (canonical source — matches page.tsx PANNA_220_CHART)
// ────────────────────────────────────────────────────────────────────────────

export const PANNA_220: string[] = [
  // ─── SP (rows 0-11) — 120 pannas ───
  '128','129','120','130','140','123','124','125','126','127',
  '137','138','139','149','159','150','160','134','135','136',
  '146','147','148','158','168','169','179','170','180','145',
  '236','156','157','167','230','178','250','189','234','190',
  '245','237','238','239','249','240','269','260','270','235',
  '290','246','247','248','258','259','278','279','289','280',
  '380','345','256','257','267','268','340','350','360','370',
  '470','390','346','347','348','349','359','369','379','389',
  '489','480','490','356','357','358','368','378','450','460',
  '560','570','580','590','456','367','458','459','469','479',
  '579','589','670','680','690','457','467','468','478','569',
  '678','679','689','789','780','790','890','567','568','578',
  // ─── TP (row 12) — 10 pannas ───
  '777','444','111','888','555','222','999','666','333','000',
  // ─── DP (rows 13-21) — 90 pannas ───
  '119','110','166','112','113','114','115','116','117','118',
  '155','228','229','220','122','277','133','224','144','226',
  '227','255','337','266','177','330','188','233','199','244',
  '335','336','445','338','339','448','223','288','225','299',
  '344','499','355','446','366','466','377','440','388','334',
  '399','660','599','455','447','556','449','477','559','488',
  '588','688','779','699','799','880','557','558','577','668',
  '669','778','788','770','889','899','566','990','667','677',
  '100','200','300','400','500','600','700','800','900','550',
]

// ────────────────────────────────────────────────────────────────────────────
// SP / DP / TP Universes — derived by filtering PANNA_220
// ────────────────────────────────────────────────────────────────────────────

function buildSPUniverse(): string[] {
  return PANNA_220.filter(p => isSP(p))
}

function buildDPUniverse(): string[] {
  return PANNA_220.filter(p => isDP(p))
}

function buildTPUniverse(): string[] {
  return PANNA_220.filter(p => isTP(p))
}

export const SP_UNIVERSE: string[] = buildSPUniverse()
export const DP_UNIVERSE: string[] = buildDPUniverse()
export const TP_UNIVERSE: string[] = buildTPUniverse()

// Quick lookup sets
export const SP_SET: Set<string> = new Set(SP_UNIVERSE)
export const DP_SET: Set<string> = new Set(DP_UNIVERSE)
export const TP_SET: Set<string> = new Set(TP_UNIVERSE)

// ────────────────────────────────────────────────────────────────────────────
// CHART_50_CUT — motor + 4 cuts, 5 SP per Ank (operator-verified)
// ────────────────────────────────────────────────────────────────────────────
export const CHART_50_CUT: Map<number, string[]> = new Map(Object.entries({
  1: ['137','146','380','470','579'],
  2: ['138','147','246','480','570'],
  3: ['139','148','157','247','580'],
  4: ['149','158','248','257','680'],
  5: ['159','168','249','258','357'],
  6: ['169','240','259','268','358'],
  7: ['179','250','269','359','368'],
  8: ['260','279','350','369','468'],
  9: ['135','270','360','379','469'],
  10: ['136','280','370','460','479'],
}).map(([k, v]) => [Number(k), v]))

// Keep CHART_50_PANNAS as alias for backward compatibility
export const CHART_50_PANNAS: Map<number, string[]> = CHART_50_CUT

// ────────────────────────────────────────────────────────────────────────────
// CHART_70_JODI7 — motor + 6 companions, 7 SP per Ank (operator-verified)
// ────────────────────────────────────────────────────────────────────────────
export const CHART_70_JODI7: Map<number, string[]> = new Map(Object.entries({
  1: ['128','236','245','290','489','560','678'],
  2: ['129','156','237','390','589','679','345'],
  3: ['238','256','346','490','670','689','120'],
  4: ['130','167','239','347','356','590','789'],
  5: ['140','230','267','348','690','780','456'],
  6: ['150','178','349','457','367','790','123'],
  7: ['124','160','278','340','458','467','890'],
  8: ['125','134','170','189','378','459','567'],
  9: ['126','180','289','450','478','568','234'],
  10: ['127','145','235','389','569','578','190'],
}).map(([k, v]) => [Number(k), v]))

// Keep CHART_70_PANNAS as alias for backward compatibility
export const CHART_70_PANNAS: Map<number, string[]> = CHART_70_JODI7

// ────────────────────────────────────────────────────────────────────────────
// CHART_60 — DERIVED from CHART_70_JODI7 (slice 0,6) — single source of truth
// ────────────────────────────────────────────────────────────────────────────
export const CHART_60_PANNAS: Map<number, string[]> = (() => {
  const chart = new Map<number, string[]>()
  for (let ank = 1; ank <= 10; ank++) {
    const p70 = CHART_70_JODI7.get(ank) || []
    chart.set(ank, p70.slice(0, 6))
  }
  return chart
})()

// ────────────────────────────────────────────────────────────────────────────
// CHART_90_DP — 9 DP pannas per Ank (operator-verified)
// ────────────────────────────────────────────────────────────────────────────
export const CHART_90_DP: Map<number, string[]> = new Map(Object.entries({
  1: ['001','119','155','227','335','344','399','588','669'],
  2: ['002','011','066','228','255','336','499','688','778'],
  3: ['003','166','229','337','355','445','599','779','788'],
  4: ['004','022','077','112','266','338','446','455','699'],
  5: ['005','113','122','177','339','366','447','799','889'],
  6: ['006','033','088','114','277','448','466','556','899'],
  7: ['007','115','133','188','223','377','449','557','566'],
  8: ['008','044','099','116','224','233','288','477','558'],
  9: ['009','117','144','199','225','388','559','577','667'],
  10: ['055','118','226','244','299','334','488','668','677'],
}).map(([k, v]) => [Number(k), v]))

// ────────────────────────────────────────────────────────────────────────────
// CHART_ABR9 — 9 SP per Ank, irregular per-Ank selection (operator-verified)
// ────────────────────────────────────────────────────────────────────────────
export const CHART_ABR9_PANNAS: Map<number, string[]> = new Map(Object.entries({
  1: ['128','236','245','290','489','560','146','380','470'],
  2: ['129','156','237','390','589','679','138','147','570'],
  3: ['238','256','346','490','670','689','148','247','580'],
  4: ['130','167','239','347','356','590','149','158','257'],
  5: ['140','230','267','348','690','780','168','249','258'],
  6: ['150','178','349','457','367','790','169','259','358'],
  7: ['124','160','278','340','458','467','250','269','368'],
  8: ['125','134','170','189','378','459','279','350','369'],
  9: ['126','180','289','450','478','568','270','360','469'],
  10: ['127','145','235','389','569','578','136','370','479'],
}).map(([k, v]) => [Number(k), v]))

/**
 * Normalize a panna or digit string to its canonical digit set.
 * Used by panna-family.ts for family lookups.
 */
export function normalizeDigitSet(input: string): string {
  const digits = input.replace(/\D/g, '').split('').sort().join('')
  return digits
}

// ────────────────────────────────────────────────────────────────────────────
// OPERATOR-CANONICAL SP / DP CHARTS (2026-09 update)
// ────────────────────────────────────────────────────────────────────────────
// The operator's master chart layout, given as rows SP1-SP12 × ank columns
// 1-9,0 (SP = 12 pannas per ank, 120 total) and DP1-DP9 × ank columns
// (DP = 9 pannas per ank, 90 total). Data is IDENTICAL to the SP / DP
// charts — SP Motor / DP Motor differ only by their group label
// (SP_MOTOR / DP_MOTOR) used for parsing/settlement routing.
//
// Cross-checked: CHART_50_CUT = rows 1-5, CHART_60 = rows 6-11,
// CHART_70_JODI7 = rows 6-12, CHART_90_DP = the DP table — all consistent.
// NOTE: these use the operator's digit order (e.g. "380"), while the app
// grid universe (app-engine SPB) writes the same digit-set as "038".
// Settlement therefore compares pannas by digit-set via pannaKey().
// ────────────────────────────────────────────────────────────────────────────

export const SP_CHART_CANONICAL: Map<number, string[]> = new Map(Object.entries({
  1: ['137','146','380','470','579','128','236','245','290','489','560','678'],
  2: ['138','147','246','480','570','129','156','237','390','589','679','345'],
  3: ['139','148','157','247','580','238','256','346','490','670','689','120'],
  4: ['149','158','248','257','680','130','167','239','347','356','590','789'],
  5: ['159','168','249','258','357','140','230','267','348','690','780','456'],
  6: ['169','240','259','268','358','150','178','349','457','367','790','123'],
  7: ['179','250','269','359','368','124','160','278','340','458','467','890'],
  8: ['260','279','350','369','468','125','134','170','189','378','459','567'],
  9: ['135','270','360','379','469','126','180','289','450','478','568','234'],
  10: ['136','280','370','460','479','127','145','235','389','569','578','190'],
}).map(([k, v]) => [Number(k), v]))

export const DP_CHART_CANONICAL: Map<number, string[]> = new Map(Object.entries({
  1: ['001','119','155','227','335','344','399','588','669'],
  2: ['002','011','166','228','255','336','499','688','778'],
  3: ['003','066','229','337','355','445','599','779','788'],
  4: ['004','022','077','112','266','338','446','455','699'],
  5: ['005','113','122','177','339','366','447','799','889'],
  6: ['006','033','088','114','277','448','466','556','899'],
  7: ['007','115','133','188','223','377','449','557','566'],
  8: ['008','044','099','116','224','233','288','477','558'],
  9: ['009','117','144','199','225','388','559','577','667'],
  10: ['055','118','226','244','299','334','488','668','677'],
}).map(([k, v]) => [Number(k), v]))

// ────────────────────────────────────────────────────────────────────────────
// CHART_20 / CHART_30 / CHART_40 — operator-verbatim charts (2026-10 fix)
// ════════════════════════════════════════════════════════════════════════════
// The previous rule ("first 10 SP pannas of anks 1-2/1-3/1-4") was WRONG and
// produced charts the operator rejected. The correct structure, per the
// operator's verbatim lists, is a FIXED panel set spread across ALL 10 anks:
//   20 Chart = 2 pannas per ank × 10 anks (1-9, 0)  = 20 pannas
//   30 Chart = 3 pannas per ank × 10 anks (1-9, 0)  = 30 pannas
//   40 Chart = 4 pannas per ank × 10 anks (1-9, 0)  = 40 pannas
// Data below is transcribed EXACTLY as the operator provided it (spelling
// preserved, zeros-last convention). Do NOT re-derive or re-sort — the
// selections are irregular and specific, same class as CHART_50_CUT.
// Map key 10 = ank 0 (matches SP_CHART_CANONICAL / CHART_90_DP convention).
// Operator note: the 20-chart list contained "237" twice — treated as a
// transcription duplicate; the canonical chart holds 20 unique pannas.
// ────────────────────────────────────────────────────────────────────────────

export const CHART_20_PANNAS: Map<number, string[]> = new Map(Object.entries({
  1: ['489', '560'],
  2: ['237', '156'],
  3: ['238', '490'],
  4: ['167', '590'],
  5: ['267', '348'],
  6: ['349', '150'],
  7: ['278', '160'],
  8: ['378', '459'],
  9: ['126', '450'],
  10: ['127', '389'],
}).map(([k, v]) => [Number(k), v]))

export const CHART_30_PANNAS: Map<number, string[]> = new Map(Object.entries({
  1: ['380', '470', '146'],
  2: ['570', '147', '138'],
  3: ['148', '580', '247'],
  4: ['149', '158', '257'],
  5: ['168', '249', '258'],
  6: ['169', '358', '259'],
  7: ['269', '250', '368'],
  8: ['279', '350', '369'],
  9: ['270', '469', '360'],
  10: ['479', '370', '136'],
}).map(([k, v]) => [Number(k), v]))

export const CHART_40_PANNAS: Map<number, string[]> = new Map(Object.entries({
  1: ['245', '290', '236', '128'],
  2: ['129', '679', '390', '589'],
  3: ['256', '670', '689', '346'],
  4: ['347', '130', '239', '356'],
  5: ['780', '230', '140', '690'],
  6: ['790', '457', '178', '367'],
  7: ['467', '124', '458', '340'],
  8: ['170', '125', '189', '134'],
  9: ['289', '568', '478', '180'],
  10: ['235', '578', '569', '145'],
}).map(([k, v]) => [Number(k), v]))

// ────────────────────────────────────────────────────────────────────────────
// DP MOTOR CHART (2026-09 operator update — verbatim operator spec)
// ────────────────────────────────────────────────────────────────────────────
// Operator's DP Motor chart: ank d (1-9; ank 0 has no rows) owns every
// Double-class panna (exactly one repeated digit) whose SMALLEST NON-ZERO
// digit is d. Per-ank counts: 18,16,14,12,10,8,6,4,2 — exactly 90 rows, the
// full DP universe with every panna owned exactly once. Spelling follows the
// operator chart: non-zero digits ascending with zeros trailing (100, 110,
// 220, 990) — the same canonical rule as the global display (012→120).
//
// This is deliberately NOT the digit-sum grouping of DP_CHART_CANONICAL /
// DPB (the motor chart is the wider per-ank family). Motor Pana and SP Motor
// keep their existing digit-seed permutation logic — only DP Motor is
// chart-driven.
//
// Verified against the operator's verbatim 90-number list in
// scripts/test-games-engine.ts (dp-motor chart regression).

/** Non-zero digits ascending, zeros trailing: {0,0,1}→"100", {0,1,1}→"110", {1,2,2}→"122". */
export function spellPannaZerosLast(digits: number[]): string {
  const nz = digits.filter(x => x > 0).sort((a, b) => a - b)
  return nz.join('') + '0'.repeat(3 - nz.length)
}

function buildDPMotorChart(): Map<number, string[]> {
  const chart = new Map<number, string[]>()
  for (let d = 1; d <= 9; d++) chart.set(d, [])
  chart.set(10, []) // ank 0 → no rows (operator chart lists anks 1-9 only)
  for (let pair = 0; pair <= 9; pair++) {
    for (let single = 0; single <= 9; single++) {
      if (single === pair) continue
      const digits = [pair, pair, single]
      const owner = Math.min(...digits.filter(x => x > 0))
      chart.get(owner)!.push(spellPannaZerosLast(digits))
    }
  }
  for (const [, rows] of chart) rows.sort((a, b) => Number(a) - Number(b))
  return chart
}

export const DP_MOTOR_CHART: Map<number, string[]> = buildDPMotorChart()

// ────────────────────────────────────────────────────────────────────────────
// Digit-set panna matching (permutation-tolerant)
// ────────────────────────────────────────────────────────────────────────────
// The same panna family is written "038" in the app grid and "380" in the
// operator chart. Both conventions denote the digit-set {0,3,8}; results may
// be declared in either order, so matching compares sorted digit strings.

/** Digit-sorted key of a panna — "380" → "038", "128" → "128". */
export function pannaKey(panna: string): string {
  const cleaned = String(panna || '').replace(/\D/g, '')
  return cleaned.length === 3 ? cleaned.split('').sort().join('') : cleaned
}

/** Two pannas match when their digit-sets are equal ("380" ≡ "038"). */
export function pannaMatches(a: string | null | undefined, b: string | null | undefined): boolean {
  if (!a || !b) return false
  const ka = pannaKey(String(a)), kb = pannaKey(String(b))
  return ka.length === 3 && ka === kb
}

/** Operator-canonical spelling of a panna ("038" → "380"); unknown → input. */
export function canonicalPanna(panna: string): string {
  const key = pannaKey(panna)
  if (key.length !== 3) return String(panna || '')
  for (const [, rows] of SP_CHART_CANONICAL) {
    for (const p of rows) if (pannaKey(p) === key) return p
  }
  for (const [, rows] of DP_CHART_CANONICAL) {
    for (const p of rows) if (pannaKey(p) === key) return p
  }
  for (const p of TP_UNIVERSE) if (pannaKey(p) === key) return p
  return String(panna || '')
}
