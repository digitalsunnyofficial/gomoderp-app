/**
 * Seed batch parser — shared across all Group options.
 *
 * Splits raw textarea input into individual seed tokens.
 * Enforces the 10-seed maximum and reports overflow.
 */

export const MAX_SEEDS = 10

/**
 * Parse a raw textarea string into individual seed tokens.
 *
 * Splitting rules:
 *   - Newlines (\n, \r)
 *   - Commas (,)
 *   - Whitespace (spaces, tabs)
 *
 * Cleaning rules:
 *   - Trim each token
 *   - Remove empty tokens
 *   - Tokens are kept as-is (digits only) — validation happens in the expander
 *
 * Max seeds: 10. If more than 10 valid tokens are entered, the first 10 are
 * returned and the rest are reported via the `rejectedOverflow` field.
 *
 * @returns An object with `seeds` (the parsed tokens, max 10) and
 *          `rejectedOverflow` (any tokens beyond the 10-seed cap).
 */
export function parseSeedBatch(rawText: string): {
  seeds: string[]
  rejectedOverflow: string[]
} {
  if (!rawText || typeof rawText !== 'string') {
    return { seeds: [], rejectedOverflow: [] }
  }

  // Split on newline, comma, or whitespace
  const tokens = rawText
    .split(/[\n\r,\s]+/)
    .map(t => t.trim())
    .filter(t => t.length > 0)

  // Enforce max 10 seeds
  if (tokens.length <= MAX_SEEDS) {
    return { seeds: tokens, rejectedOverflow: [] }
  }

  return {
    seeds: tokens.slice(0, MAX_SEEDS),
    rejectedOverflow: tokens.slice(MAX_SEEDS),
  }
}

/**
 * Clean a single seed token: extract only the digit characters.
 * Example: "12-8" → "128", "  456  " → "456", "abc123" → "123"
 *
 * This is used by expanders that need pure-digit seeds.
 * Expanders that accept "AnkN" format (e.g., "Ank5") should NOT use this —
 * they handle their own parsing.
 */
export function cleanSeedDigits(seed: string): string {
  return seed.replace(/\D/g, '')
}
