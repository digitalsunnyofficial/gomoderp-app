/**
 * term-registry.ts — The Matka Terminology Dictionary (the "evolving library").
 *
 * This is the single source of truth that lets ONE unified input box recognize
 * whatever term a player uses for the same underlying concept:
 *
 *   "SP - 1,2,5,6,7 = 100 rs"          ← short form
 *   "Single Panna - 1,2,5,6,7 = 100"   ← long form
 *   "Ank Panna 1,2,5 100"              ← another spelling
 *
 * all resolve to the SAME canonical category (SP), so the Smart Entry parser
 * can classify, calculate and route the numbers to the correct store.
 *
 * Layers:
 *   1. BUILT-IN TERMS     — shipped dictionary (below). Covers the operator
 *                           spec: SP/DP/TP/SPDP/SPTP/DPTP/SPDPTP/Motor Pana/
 *                           50-60-70-90 charts/Family Sets/Mix/Common plus the
 *                           common spoken & misspelled variants.
 *   2. CUSTOM TERMS (DB)  — ParserTerm table. Admins add synonyms manually via
 *                           Parser Config (manual evolution). Loaded at parse
 *                           time and passed into the parser.
 *   3. AUTO-EVOLUTION     — unrecognized labels are returned by the parser as
 *                           `unknownLabels` and recorded as Parser Exceptions,
 *                           so admins see exactly what to teach the system.
 *
 * The registry is PURE (no imports from DB or React) so it can run on the
 * client (live preview) and the server (API-side parsing) identically.
 */

import type { GroupOption } from './group-types'

/** Mix/Common + the 16 group options are the canonical routing targets. */
export type CanonicalCategory = GroupOption | 'mix' | 'common'

export interface TermDef {
  /** The raw term as a person might write/spell it (normalized at lookup). */
  term: string
  /** Where entries under this term are routed. */
  category: CanonicalCategory
}

// ────────────────────────────────────────────────────────────
// Normalization — make lookup forgiving
// ────────────────────────────────────────────────────────────

/**
 * Normalize a label exactly the way terms are stored, so lookups are
 * case/spacing/punctuation-insensitive:
 *   "  Single   Panna! " → "single panna"
 *   "Motor-Pana:"        → "motor pana"
 *   "Motar"              → "motar" (misspellings are stored as their own terms)
 */
export function normalizeTerm(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ') // punctuation → space
    .replace(/\s+/g, ' ')
    .trim()
}

// ────────────────────────────────────────────────────────────
// BUILT-IN DICTIONARY
// ────────────────────────────────────────────────────────────

/**
 * The shipped dictionary. Misspellings that are common in real chats
 * (motar, jodi/joty, tripple, singal, coman…) are included deliberately —
 * the goal is "recognizes easily".
 */
export const BUILT_IN_TERMS: TermDef[] = [
  // ── SP — Single Panna / Ank Panna (1-digit ank bets; 3-digit SP pannas) ──
  { term: 'sp', category: 'SP' },
  { term: 's p', category: 'SP' },
  { term: 'single panna', category: 'SP' },
  { term: 'singal panna', category: 'SP' },
  { term: 'single patti', category: 'SP' },
  { term: 'sp panna', category: 'SP' },
  { term: 'sp patti', category: 'SP' },
  { term: 'ank panna', category: 'SP' },
  { term: 'ak panna', category: 'SP' },
  { term: 'ank patti', category: 'SP' },
  { term: 'ank', category: 'SP' },

  // ── DP — Double Panna / Jodi / Joti / Double Ank ──
  { term: 'dp', category: 'DP' },
  { term: 'd p', category: 'DP' },
  { term: 'double panna', category: 'DP' },
  { term: 'double pannta', category: 'DP' },
  { term: 'duble panna', category: 'DP' },
  { term: 'double patti', category: 'DP' },
  { term: 'dp panna', category: 'DP' },
  { term: 'dp patti', category: 'DP' },
  { term: 'jodi', category: 'DP' },
  { term: 'jody', category: 'DP' },
  { term: 'jodi panna', category: 'DP' },
  { term: 'jodi patti', category: 'DP' },
  { term: 'joti', category: 'DP' },
  { term: 'joty', category: 'DP' },
  { term: 'jote', category: 'DP' },
  { term: 'double ank', category: 'DP' },
  { term: 'double ak', category: 'DP' },

  // ── TP — Triple Panna ──
  { term: 'tp', category: 'TP' },
  { term: 't p', category: 'TP' },
  { term: 'triple panna', category: 'TP' },
  { term: 'tripple panna', category: 'TP' },
  { term: 'triple patti', category: 'TP' },
  { term: 'tp panna', category: 'TP' },
  { term: 'tp patti', category: 'TP' },
  { term: 'triple ank', category: 'TP' },

  // ── Combined panna groups ──
  { term: 'spdp', category: 'SPDP' },
  { term: 'sp dp', category: 'SPDP' },
  { term: 'sptp', category: 'SPTP' },
  { term: 'sp tp', category: 'SPTP' },
  { term: 'dptp', category: 'DPTP' },
  { term: 'dp tp', category: 'DPTP' },
  { term: 'spdptp', category: 'SPDPTP' },
  { term: 'sp dp tp', category: 'SPDPTP' },
  { term: 'spdpmo', category: 'SPDPTP' },

  // ── Motor — Motor Panna / Motor Patti / Cycle Patti / Motar ──
  { term: 'motor', category: 'Motor Pana' },
  { term: 'motar', category: 'Motor Pana' },
  { term: 'motor pana', category: 'Motor Pana' },
  { term: 'motor panna', category: 'Motor Pana' },
  { term: 'motor patti', category: 'Motor Pana' },
  { term: 'motar panna', category: 'Motor Pana' },
  { term: 'motar patti', category: 'Motor Pana' },
  { term: 'cycle', category: 'Motor Pana' },
  { term: 'cycle panna', category: 'Motor Pana' },
  { term: 'cycle patti', category: 'Motor Pana' },
  { term: 'motor cycle', category: 'Motor Pana' },

  // ── Session-qualified motor labels (WhatsApp "Milan open motor") ──
  // 2026-09-30 operator sample: "[4:02 pm] San pag: Milan open motor".
  // The open/close word is session metadata (the Smart Entry UI market/session
  // selector stays authoritative); the chart part routes the section.
  { term: 'open motor', category: 'Motor Pana' },
  { term: 'close motor', category: 'Motor Pana' },
  { term: 'open motar', category: 'Motor Pana' },
  { term: 'close motar', category: 'Motor Pana' },

  // ── SP Motor / DP Motor (2026-09-30 operator sample "open dp motor") ──
  { term: 'sp motor', category: 'SP Motor' },
  { term: 'sp motar', category: 'SP Motor' },
  { term: 'open sp motor', category: 'SP Motor' },
  { term: 'close sp motor', category: 'SP Motor' },
  { term: 'dp motor', category: 'DP Motor' },
  { term: 'dp motar', category: 'DP Motor' },
  { term: 'open dp motor', category: 'DP Motor' },
  { term: 'close dp motor', category: 'DP Motor' },

  // ── Full-chart ("all anks") headers ──
  // 2026-09-30 operator sample: "All dp9 / 50rs / Total 4500" = the whole
  // 90-DP universe (9 pannas × 10 anks = 90) at 50 each. "all <chart>" makes
  // the parser open the chart for every ank (0-9) at once.
  { term: 'all dp9', category: '90 DP Chart' },
  { term: 'all dp 9', category: '90 DP Chart' },
  { term: 'all 90 dp', category: '90 DP Chart' },
  { term: 'all 90dp', category: '90 DP Chart' },
  { term: 'all dp', category: '90 DP Chart' },
  { term: 'all dp chart', category: '90 DP Chart' },

  // ── Cut charts ──
  { term: '50 chart', category: '50 Chart' },
  { term: '50', category: '50 Chart' },
  { term: 'fifty chart', category: '50 Chart' },
  { term: '60 chart', category: '60 Chart' },
  { term: '60', category: '60 Chart' },
  { term: 'sixty chart', category: '60 Chart' },
  { term: '70 chart', category: '70 Chart' },
  { term: '70', category: '70 Chart' },
  { term: 'seventy chart', category: '70 Chart' },
  { term: '90 dp chart', category: '90 DP Chart' },
  { term: '90 dp', category: '90 DP Chart' },
  { term: 'ninety dp', category: '90 DP Chart' },
  { term: '90 abr chart', category: '90 ABR Chart' },
  { term: '90 abr', category: '90 ABR Chart' },
  { term: 'abr chart', category: '90 ABR Chart' },
  { term: 'abr', category: '90 ABR Chart' },

  // ── Family sets ──
  { term: 'family set 4', category: 'Family Set 4' },
  { term: 'family set4', category: 'Family Set 4' },
  { term: 'family 4', category: 'Family Set 4' },
  { term: 'fs4', category: 'Family Set 4' },
  { term: 'family set 6', category: 'Family Set 6' },
  { term: 'family set6', category: 'Family Set 6' },
  { term: 'family 6', category: 'Family Set 6' },
  { term: 'fs6', category: 'Family Set 6' },
  { term: 'family set 8', category: 'Family Set 8' },
  { term: 'family set8', category: 'Family Set 8' },
  { term: 'family 8', category: 'Family Set 8' },
  { term: 'fs8', category: 'Family Set 8' },
  { term: 'family set', category: 'Family Set 8' }, // bare "family set" → most common (8)

  // ── Triple sub-categories (non-group) ──
  { term: 'mix', category: 'mix' },
  { term: 'mix panna', category: 'mix' },
  { term: 'mixed', category: 'mix' },
  { term: 'normal', category: 'mix' },
  { term: 'direct', category: 'mix' },
  { term: 'common', category: 'common' },
  { term: 'coman', category: 'common' },
  { term: 'comon', category: 'common' },
  { term: 'common panna', category: 'common' },
  { term: 'common patti', category: 'common' },
]

// ────────────────────────────────────────────────────────────
// Lookup maps (built once, reused)
// ────────────────────────────────────────────────────────────

const BUILT_IN_MAP: Map<string, CanonicalCategory> = new Map(
  BUILT_IN_TERMS.map(t => [normalizeTerm(t.term), t.category])
)

/** Ordered list of the group options (UI + parser share this order). */
export const GROUP_OPTION_ORDER: GroupOption[] = [
  'SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP',
  'Motor Pana', 'SP Motor', 'DP Motor',
  '20 Chart', '30 Chart', '40 Chart', '50 Chart', '60 Chart', '70 Chart',
  '90 DP Chart', '90 ABR Chart',
  'Family Set 4', 'Family Set 6', 'Family Set 8', 'Family Chart',
]

/** Long, human-readable label for each canonical category (UI + docs). */
export const CATEGORY_LABELS: Record<CanonicalCategory, string> = {
  SP: 'SP (Single Panna)',
  DP: 'DP (Double Panna / Jodi)',
  TP: 'TP (Triple Panna)',
  SPDP: 'SPDP',
  SPTP: 'SPTP',
  DPTP: 'DPTP',
  SPDPTP: 'SPDPTP',
  'Motor Pana': 'Motor Pana',
  'SP Motor': 'SP Motor (SP data, SP_MOTOR label)',
  'DP Motor': 'DP Motor (DP data, DP_MOTOR label)',
  '20 Chart': '20 Chart',
  '30 Chart': '30 Chart',
  '40 Chart': '40 Chart',
  '50 Chart': '50 Chart',
  '60 Chart': '60 Chart',
  '70 Chart': '70 Chart',
  '90 DP Chart': '90 DP Chart',
  '90 ABR Chart': '90 ABR Chart',
  'Family Set 4': 'Family Set 4',
  'Family Set 6': 'Family Set 6',
  'Family Set 8': 'Family Set 8',
  'Family Chart': 'Family Chart (Sets 4+6+8 combined)',
  mix: 'Triple — Mix',
  common: 'Triple — Common',
}

/** Short label (no parenthetical) for chips/tables. */
export const CATEGORY_SHORT_LABELS: Record<CanonicalCategory, string> = {
  SP: 'SP',
  DP: 'DP',
  TP: 'TP',
  SPDP: 'SPDP',
  SPTP: 'SPTP',
  DPTP: 'DPTP',
  SPDPTP: 'SPDPTP',
  'Motor Pana': 'Motor',
  'SP Motor': 'SP Motor',
  'DP Motor': 'DP Motor',
  '20 Chart': '20 Chart',
  '30 Chart': '30 Chart',
  '40 Chart': '40 Chart',
  '50 Chart': '50 Chart',
  '60 Chart': '60 Chart',
  '70 Chart': '70 Chart',
  '90 DP Chart': '90 DP',
  '90 ABR Chart': '90 ABR',
  'Family Set 4': 'Family 4',
  'Family Set 6': 'Family 6',
  'Family Set 8': 'Family 8',
  'Family Chart': 'Family',
  mix: 'Mix',
  common: 'Common',
}

/** Shape of a DB-backed custom term (ParserTerm table) passed to the parser. */
export interface CustomTerm {
  term: string
  category: string
}

// ────────────────────────────────────────────────────────────
// Lookup API
// ────────────────────────────────────────────────────────────

/**
 * Is this canonical category a group-chart type (i.e. handled by the
 * EXPANDER_REGISTRY)? Mix/Common are stored directly, not expanded.
 */
export function isGroupCategory(cat: CanonicalCategory): boolean {
  return cat !== 'mix' && cat !== 'common'
}

/**
 * Resolve a raw label to its canonical category.
 *
 * Lookup is EXACT on the normalized form:
 *   1. Custom (DB) terms first — admin additions win (they may intentionally
 *      override a built-in).
 *   2. Exact built-in match.
 *
 * Deliberately NO prefix/fuzzy matching: "jodi 12 23" must NOT resolve to
 * "jodi" just because it starts with the word — the parser needs strict
 * matching to tell labels and number lines apart. Unknown labels are
 * reported for auto-evolution instead.
 *
 * Returns null when nothing matches.
 */
export function lookupTerm(
  rawLabel: string,
  customTerms?: CustomTerm[]
): CanonicalCategory | null {
  const norm = normalizeTerm(rawLabel)
  if (!norm) return null

  // 1. Custom (DB) terms first — admin overrides
  if (customTerms && customTerms.length > 0) {
    for (const t of customTerms) {
      if (normalizeTerm(t.term) === norm) {
        return t.category as CanonicalCategory
      }
    }
  }

  // 2. Exact built-in
  return BUILT_IN_MAP.get(norm) ?? null
}

/**
 * All known aliases for a canonical category (used by the Parser Config UI
 * and the project documentation).
 */
export function aliasesFor(category: CanonicalCategory): string[] {
  const out = BUILT_IN_TERMS.filter(t => t.category === category).map(t => t.term)
  return Array.from(new Set(out))
}
