/**
 * Hierarchy Authorization Helpers
 * 
 * Server-side utilities for the 4-tier role hierarchy:
 *   MASTER_ADMIN → ADMIN_MANAGER → AGENT → KHATRI (Vendor record)
 * 
 * ALL authorization is enforced server-side.
 * Never trust client-provided role, agentId, or createdByUserId.
 */

import { db } from './db'
import { NextResponse } from 'next/server'
import { parseAssignedMarkets } from './audit'

// ────────────────────────────────────────────────────────────
// Role Constants
// ────────────────────────────────────────────────────────────

export const ROLES = {
  MASTER_ADMIN: 'master_admin',
  ADMIN_MANAGER: 'admin_manager',
  AGENT: 'agent',
} as const

export type Role = typeof ROLES[keyof typeof ROLES]

// Legacy role mapping for backward compatibility
// 'super' is the current DB value for the Super Admin (formerly 'master')
export const LEGACY_ROLE_MAP: Record<string, Role> = {
  super: ROLES.MASTER_ADMIN,
  master: ROLES.MASTER_ADMIN, // pre-rename value — kept for old sessions/DBs
  manager: ROLES.ADMIN_MANAGER,
  user: ROLES.AGENT,
}

export function normalizeRole(raw: string): Role {
  return LEGACY_ROLE_MAP[raw] || (raw as Role)
}

export function isMasterAdmin(role: string): boolean {
  return normalizeRole(role) === ROLES.MASTER_ADMIN
}

export function isAdminManager(role: string): boolean {
  return normalizeRole(role) === ROLES.ADMIN_MANAGER
}

export function isAgent(role: string): boolean {
  return normalizeRole(role) === ROLES.AGENT
}

export function isMasterOrAdminManager(role: string): boolean {
  const normalized = normalizeRole(role)
  return normalized === ROLES.MASTER_ADMIN || normalized === ROLES.ADMIN_MANAGER
}

// ────────────────────────────────────────────────────────────
// Authenticated User (full DB-verified)
// ────────────────────────────────────────────────────────────

export interface AuthenticatedUser {
  id: string
  username: string
  role: Role
  name: string | null
  assignedMarkets: string[]
  isLocked: boolean
  status: string
  managerId: string | null
  createdByUserId: string | null
  createdByAdminManagerId: string | null
}

/**
 * Get the authenticated user from the session-verified headers.
 * Uses the x-session-userid header set by proxy.ts (server-set, not client-set).
 * Falls back to x-user-id for backward compatibility during transition.
 */
export async function getAuthenticatedUser(request: Request): Promise<AuthenticatedUser | null> {
  // Prefer server-set session headers (from proxy.ts)
  const sessionUserId = request.headers.get('x-session-userid')
  const clientUserId = request.headers.get('x-user-id')
  const userId = sessionUserId || clientUserId

  if (!userId) return null

  const raw = await db.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      username: true,
      role: true,
      name: true,
      assignedMarkets: true,
      isLocked: true,
      status: true,
      managerId: true,
      createdByUserId: true,
      createdByAdminManagerId: true,
    },
  })

  if (!raw) return null
  if (raw.isLocked) return null
  if (raw.status !== 'active' && raw.status !== 'migration_only') return null

  return {
    ...raw,
    role: normalizeRole(raw.role),
    assignedMarkets: parseAssignedMarkets(raw.assignedMarkets),
  }
}

// ────────────────────────────────────────────────────────────
// Authorization Result Types
// ────────────────────────────────────────────────────────────

export type AuthResult =
  | { ok: true; user: AuthenticatedUser }
  | { ok: false; response: NextResponse }

// ────────────────────────────────────────────────────────────
// Role Requirement Helpers
// ────────────────────────────────────────────────────────────

/** Require any authenticated, active, unlocked user */
export async function requireAuth(request: Request): Promise<AuthResult> {
  const user = await getAuthenticatedUser(request)
  if (!user) {
    return { ok: false, response: NextResponse.json({ error: 'Unauthorized — valid session required' }, { status: 401 }) }
  }
  return { ok: true, user }
}

/** Require MASTER_ADMIN role */
export async function requireMasterAdmin(request: Request): Promise<AuthResult> {
  const result = await requireAuth(request)
  if (!result.ok) return result
  if (result.user.role !== ROLES.MASTER_ADMIN) {
    return { ok: false, response: NextResponse.json({ error: 'Forbidden — super admin role required' }, { status: 403 }) }
  }
  return result
}

/** Require ADMIN_MANAGER or MASTER_ADMIN role */
export async function requireAdminManagerOrMaster(request: Request): Promise<AuthResult> {
  const result = await requireAuth(request)
  if (!result.ok) return result
  if (!isMasterOrAdminManager(result.user.role)) {
    return { ok: false, response: NextResponse.json({ error: 'Forbidden — admin or super admin role required' }, { status: 403 }) }
  }
  return result
}

/** Require AGENT role (for Agent-specific endpoints like access links) */
export async function requireAgent(request: Request): Promise<AuthResult> {
  const result = await requireAuth(request)
  if (!result.ok) return result
  if (result.user.role !== ROLES.AGENT) {
    return { ok: false, response: NextResponse.json({ error: 'Forbidden — agent role required' }, { status: 403 }) }
  }
  return result
}

// ────────────────────────────────────────────────────────────
// Visibility Helpers — Which Agents/Vendors can this user see?
// ────────────────────────────────────────────────────────────

/**
 * Get the list of Agent IDs visible to the current user.
 * 
 * MASTER_ADMIN: all agents
 * ADMIN_MANAGER: agents created by or assigned to this admin
 * AGENT: only themselves
 */
export async function getVisibleAgentIds(user: AuthenticatedUser): Promise<string[]> {
  if (user.role === ROLES.MASTER_ADMIN) {
    const allAgents = await db.user.findMany({
      where: { role: { in: [ROLES.AGENT, 'user'] } }, // include legacy 'user' role
      select: { id: true },
    })
    return allAgents.map(a => a.id)
  }

  if (user.role === ROLES.ADMIN_MANAGER) {
    // Agents where managerId = this admin OR createdByAdminManagerId = this admin
    const managedAgents = await db.user.findMany({
      where: {
        role: { in: [ROLES.AGENT, 'user'] },
        OR: [
          { managerId: user.id },
          { createdByAdminManagerId: user.id },
          { createdByUserId: user.id },
        ],
      },
      select: { id: true },
    })
    return managedAgents.map(a => a.id)
  }

  // AGENT can only see themselves
  return [user.id]
}

/**
 * Build a Prisma where clause for Vendor filtering based on ownership.
 * 
 * MASTER_ADMIN: no filter (all vendors)
 * ADMIN_MANAGER: vendors owned by visible agents
 * AGENT: vendors where agentId = currentUser.id
 */
export async function getVendorOwnershipFilter(user: AuthenticatedUser): Promise<Record<string, unknown>> {
  if (user.role === ROLES.MASTER_ADMIN) {
    return {} // no filter
  }

  const visibleAgentIds = await getVisibleAgentIds(user)
  if (visibleAgentIds.length === 0) {
    return { id: 'impossible' } // no visible agents = no vendors
  }

  return { agentId: { in: visibleAgentIds } }
}

/**
 * Check if the current user can access a specific vendor.
 */
export async function canAccessVendor(user: AuthenticatedUser, vendorId: string): Promise<boolean> {
  if (user.role === ROLES.MASTER_ADMIN) return true

  const vendor = await db.vendor.findUnique({
    where: { id: vendorId },
    select: { agentId: true },
  })
  if (!vendor) return false

  const visibleAgentIds = await getVisibleAgentIds(user)
  return visibleAgentIds.includes(vendor.agentId || '')
}

/**
 * Check if the current user can access a specific agent.
 */
export async function canAccessAgent(user: AuthenticatedUser, agentId: string): Promise<boolean> {
  if (user.role === ROLES.MASTER_ADMIN) return true
  const visibleAgentIds = await getVisibleAgentIds(user)
  return visibleAgentIds.includes(agentId)
}

// ────────────────────────────────────────────────────────────
// User Creation Rules
// ────────────────────────────────────────────────────────────

export interface CreateUserRule {
  allowed: boolean
  error?: string
}

/**
 * Check if a user can create another user with the specified role.
 */
export function canCreateUser(creatorRole: Role, targetRole: Role): CreateUserRule {
  // MASTER_ADMIN can create ADMIN_MANAGER or AGENT
  if (creatorRole === ROLES.MASTER_ADMIN) {
    if (targetRole === ROLES.MASTER_ADMIN) {
      return { allowed: false, error: 'Cannot create another Super Admin account' }
    }
    return { allowed: true }
  }

  // ADMIN_MANAGER can create AGENT only
  if (creatorRole === ROLES.ADMIN_MANAGER) {
    if (targetRole === ROLES.MASTER_ADMIN) {
      return { allowed: false, error: 'Admin/Manager cannot create Super Admin accounts' }
    }
    if (targetRole === ROLES.ADMIN_MANAGER) {
      return { allowed: false, error: 'Admin/Manager cannot create another Admin/Manager account' }
    }
    return { allowed: true }
  }

  // AGENT cannot create users
  return { allowed: false, error: 'Agents cannot create user accounts' }
}

// ────────────────────────────────────────────────────────────
// Vendor Assignment Rules
// ────────────────────────────────────────────────────────────

export interface AssignVendorRule {
  allowed: boolean
  error?: string
}

/**
 * Check if a user can assign a vendor to a specific agent.
 */
export async function canAssignVendorToAgent(
  user: AuthenticatedUser,
  targetAgentId: string
): Promise<AssignVendorRule> {
  if (user.role === ROLES.AGENT) {
    // Agents cannot choose which agent — they auto-assign to themselves
    return { allowed: false, error: 'Agents cannot assign vendors to other agents' }
  }

  // Verify the target is actually an Agent
  const targetUser = await db.user.findUnique({
    where: { id: targetAgentId },
    select: { id: true, role: true, status: true },
  })

  if (!targetUser) {
    return { allowed: false, error: 'Target agent not found' }
  }

  if (!isAgent(normalizeRole(targetUser.role)) && targetUser.role !== 'user') {
    return { allowed: false, error: 'Target user is not an Agent' }
  }

  if (targetUser.status !== 'active') {
    return { allowed: false, error: 'Target agent is not active' }
  }

  // ADMIN_MANAGER can only assign to agents in their hierarchy
  if (user.role === ROLES.ADMIN_MANAGER) {
    const visibleAgentIds = await getVisibleAgentIds(user)
    if (!visibleAgentIds.includes(targetAgentId)) {
      return { allowed: false, error: 'Cannot assign vendor to agent outside your hierarchy' }
    }
  }

  return { allowed: true }
}

// ────────────────────────────────────────────────────────────
// Reassignment Rules
// ────────────────────────────────────────────────────────────

export async function canReassignVendor(
  user: AuthenticatedUser,
  vendorId: string,
  newAgentId: string
): Promise<AssignVendorRule> {
  // AGENT cannot reassign
  if (user.role === ROLES.AGENT) {
    return { allowed: false, error: 'Agents cannot reassign vendor ownership' }
  }

  // Must be able to access the vendor
  const canAccess = await canAccessVendor(user, vendorId)
  if (!canAccess) {
    return { allowed: false, error: 'Cannot access this vendor' }
  }

  // Must be able to assign to the new agent
  return canAssignVendorToAgent(user, newAgentId)
}

// ────────────────────────────────────────────────────────────
// Agent Access Link Helpers
// ────────────────────────────────────────────────────────────

export async function canManageAccessLink(
  user: AuthenticatedUser,
  targetAgentId: string
): Promise<boolean> {
  if (user.role === ROLES.MASTER_ADMIN) return true
  if (user.role === ROLES.ADMIN_MANAGER) {
    const visibleAgentIds = await getVisibleAgentIds(user)
    return visibleAgentIds.includes(targetAgentId)
  }
  return false // Agents cannot manage access links
}

// ────────────────────────────────────────────────────────────
// Market Access (preserved from existing, now with normalized roles)
// ────────────────────────────────────────────────────────────

export function canAccessMarket(user: AuthenticatedUser, market: string | null | undefined): boolean {
  if (!market) return true
  if (isMasterOrAdminManager(user.role)) return true
  return user.assignedMarkets.includes(market)
}

export function getAccessibleMarkets(user: AuthenticatedUser): string[] | null {
  if (isMasterOrAdminManager(user.role)) return null // null = all markets
  return user.assignedMarkets
}

/**
 * Build Prisma where clause for market-based filtering.
 */
export function marketOwnershipFilter(
  user: AuthenticatedUser,
  marketFieldPath: string = 'inventoryCode.market'
): Record<string, unknown> {
  if (isMasterOrAdminManager(user.role)) return {}
  if (user.assignedMarkets.length === 0) {
    return { _none: {} }
  }
  const parts = marketFieldPath.split('.')
  if (parts.length === 1) {
    return { [parts[0]]: { in: user.assignedMarkets } }
  }
  let inner: Record<string, unknown> = { in: user.assignedMarkets }
  for (let i = parts.length - 1; i >= 0; i--) {
    inner = { [parts[i]]: inner }
  }
  return inner
}

// ────────────────────────────────────────────────────────────
// Combined Filter: Market + Agent Ownership
// ────────────────────────────────────────────────────────────

/**
 * Build a combined Prisma where clause that filters by both market access
 * and agent ownership. Used for inventory, settlement, and chart queries.
 */
export async function getCombinedFilter(
  user: AuthenticatedUser,
  marketFieldPath: string = 'inventoryCode.market'
): Promise<Record<string, unknown>> {
  const mktFilter = marketOwnershipFilter(user, marketFieldPath)
  const agentFilter = await getVendorOwnershipFilter(user)

  // If both are empty (master_admin), no filter needed
  if (Object.keys(mktFilter).length === 0 && Object.keys(agentFilter).length === 0) {
    return {}
  }

  // Combine with AND
  const conditions: Record<string, unknown>[] = []
  if (Object.keys(mktFilter).length > 0) conditions.push(mktFilter)
  if (Object.keys(agentFilter).length > 0) conditions.push(agentFilter)

  if (conditions.length === 1) return conditions[0]
  return { AND: conditions }
}
