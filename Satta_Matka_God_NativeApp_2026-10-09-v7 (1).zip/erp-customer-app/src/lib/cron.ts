// ──────────────────────────────────────────────────────────
// MARKET CRON BOT — opens & closes the markets in the app.
//
// Started once per server process from src/instrumentation.ts.
// Every tick (30s) it evaluates every market's weekly schedule
// (+ bet-closing minutes) and:
//   • computes the live state (open / in-session / closed / off)
//   • logs OPEN→CLOSED flips to the audit trail
//   • broadcasts an in-app notification to every customer when a
//     market opens for betting (AppConfig "cron_notify" = "open")
//
// The betting windows themselves are enforced statelessly in the
// bets API (slotAcceptingWeekly + betCloseMinutes + declared-result
// blocking) — the bot is the visible "cron" that flips markets and
// notifies, and its status is exposed to the admin panel.
// ──────────────────────────────────────────────────────────
import { db } from '@/lib/db'
import { logActivity } from '@/lib/audit'
import { effectiveTimes, marketLiveState } from '@/lib/matka/games'

export interface CronMarketState {
  code: string
  name: string
  state: string
  open: string
  close: string
  openAccepting: boolean
  closeAccepting: boolean
  changedAt: string | null
}

interface CronRuntime {
  startedAt: string
  lastTick: string | null
  ticks: number
  markets: Record<string, CronMarketState>
  running: boolean
}

function rt(): CronRuntime {
  const g = globalThis as Record<string, unknown>
  if (!g.__marketCron) {
    g.__marketCron = {
      startedAt: new Date().toISOString(),
      lastTick: null, ticks: 0, markets: {}, running: false,
    } as CronRuntime
  }
  return g.__marketCron as CronRuntime
}

export function cronStatus(): CronRuntime {
  return rt()
}

async function tick(): Promise<void> {
  const r = rt()
  try {
    const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
    const now = new Date()
    for (const m of markets) {
      const live = marketLiveState(m, now)
      const eff = effectiveTimes(m, now)
      const prev = r.markets[m.code]
      const flipped = !prev || prev.state !== live.state
      if (flipped) {
        // Audit-log market open/close flips (weekly-off/off transitions too)
        if (prev && (live.state === 'open' || prev.state === 'open')) {
          await logActivity({
            username: 'market-bot', action: live.state === 'open' ? 'market_opened' : 'market_closed',
            entity: 'app_market', entityId: m.id, market: m.code,
            metadata: { market: m.name, state: live.state, open: eff.open, close: eff.close },
          })
        }
        // Notify customers when betting opens for the session day
        if (prev && live.state === 'open' && prev.state !== 'open') {
          const notifyCfg = await db.appConfig.findUnique({ where: { key: 'cron_notify' } }).catch(() => null)
          const mode = notifyCfg?.value || 'open'
          if (mode === 'open') {
            await db.appNotification.create({
              data: { customerId: null, icon: 'zap', text: `${m.name} is OPEN — open session accepting bids till ${eff.open}` },
            }).catch(() => { /* non-fatal */ })
          }
        }
      }
      r.markets[m.code] = {
        code: m.code, name: m.name, state: live.state,
        open: eff.open, close: eff.close,
        openAccepting: live.openAccepting, closeAccepting: live.closeAccepting,
        changedAt: flipped ? now.toISOString() : (prev?.changedAt ?? null),
      }
    }
    r.lastTick = now.toISOString()
    r.ticks += 1
  } catch (err) {
    console.error('market cron tick error', err)
  }
}

export function startCron(): void {
  const r = rt()
  if (r.running) return
  r.running = true
  console.log('[cron] market bot started — tick every 30s')
  void tick()
  const timer = setInterval(() => { void tick() }, 30_000)
  // Don't keep the process alive just for the cron in dev hot-reload
  if (typeof timer.unref === 'function') timer.unref()
}
