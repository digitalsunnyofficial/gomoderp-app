import { db } from '@/lib/db'
import { istClock, marketWindowToday, minsOf, fmt12, istDate } from '@/lib/matka/app-engine'
import { sendPushToCustomers } from './push/expo-push'

// ──────────────────────────────────────────────────────────
// MARKET CRON LOGIC — shared by the scheduler
// (src/instrumentation.ts, every 60 s) and the manual hook
// (/api/cron/markets). Computes each live market's state
// from its WEEKLY schedule ("scheduled" → "open" → "closed",
// or "off" on disabled days / master OFF) while respecting
// bet-closing-minutes, persists it so ERP shows a live
// status, prunes expired customer-app sessions, and fires the
// native-app BET-WINDOW notifications (operator rule 2026-10):
//   · betting is now open (daily window began)
//   · close-session betting is now live
//   · betting closes in 10 min (open + close + starlines)
// Each notice is sent ONCE per market per slot per IST day —
// deduplicated through the AppConfig KV (keys "cron:remind:…").
// ──────────────────────────────────────────────────────────

const REMIND_MINUTES = 10 // "closes soon" window

async function remindOnce(
  key: string,
  text: string,
  title: string,
): Promise<boolean> {
  // Exactly-once guard: the KV key embeds the IST date + market + slot.
  const dup = await db.appConfig.findUnique({ where: { key } })
  if (dup) return false
  await db.appConfig.create({ data: { key, value: 'sent' } }).catch(() => false)
  const customers = await db.appCustomer.findMany({
    where: { status: 'active', approvalStatus: 'approved' },
    select: { id: true },
  })
  if (!customers.length) return false
  await db.appNotification.createMany({
    data: customers.map(c => ({ customerId: c.id, icon: 'bell', text })),
  })
  void sendPushToCustomers(customers.map(c => c.id), title, text, { screen: 'home' })
  return true
}

export async function marketCronTick(): Promise<{ changed: number; pruned: number; notified: number }> {
  const now = new Date()
  const cur = istClock(now).mins
  const today = istDate(now)
  const markets = await db.appMarket.findMany({ where: { isActive: true } })
  let changed = 0
  let notified = 0

  for (const m of markets) {
    const w = marketWindowToday(m, now)
    let next: string
    if (!w.on) {
      next = 'off'
    } else {
      const o = minsOf(w.openTime) - (m.betClosingMinutes || 0)
      const c = minsOf(w.closeTime) - (m.betClosingMinutes || 0)
      // open window = [openTime, closeTime); before it the market is
      // "scheduled", after the closing cutoff it is "closed".
      next = cur < o ? 'scheduled' : cur < c ? 'open' : 'closed'
    }
    if (next !== m.marketStatus) {
      await db.appMarket.update({
        where: { id: m.id },
        data: { marketStatus: next, statusChangedAt: now },
      })
      changed++
    }

    // ── Bet-window notifications (never break the cron) ──
    if (!w.on || m.isOn === false) continue
    try {
      const o = minsOf(w.openTime) - (m.betClosingMinutes || 0)
      const c = minsOf(w.closeTime) - (m.betClosingMinutes || 0)

      // 1) Daily window began → "betting is now open" (open session accepts
      //    bids until the open cutoff). Fires on the closed→scheduled flip.
      if (next === 'scheduled' && m.marketStatus && ['closed', 'off'].includes(m.marketStatus)) {
        if (await remindOnce(
          `cron:remind:${m.code}:dayopen:${today}`,
          `${m.name} betting is now open — Open session accepts bids until ${fmt12(w.openTime)}. Place your bets!`,
          `${m.name} — betting open`,
        )) notified++
      }

      // 2) Open cutoff reached → close-session betting goes live.
      if (next === 'open' && m.marketStatus === 'scheduled' && m.session !== 'open') {
        if (await remindOnce(
          `cron:remind:${m.code}:closelive:${today}`,
          `${m.name} Close session betting is now live — bids accepted until ${fmt12(w.closeTime)} (Jodi is closed with the Open session).`,
          `${m.name} — close session live`,
        )) notified++
      }

      // 3) "Last chance" — 10 minutes before each cutoff, once per slot/day.
      const toOpen = o - cur
      const toClose = c - cur
      if (toOpen > 0 && toOpen <= REMIND_MINUTES) {
        if (await remindOnce(
          `cron:remind:${m.code}:opensoon:${today}`,
          `Last chance — ${m.name} Open betting closes in ${toOpen} min (at ${fmt12(w.openTime)}).`,
          `${m.name} — open betting closes soon`,
        )) notified++
      }
      if (toClose > 0 && toClose <= REMIND_MINUTES) {
        if (await remindOnce(
          `cron:remind:${m.code}:closesoon:${today}`,
          `Last chance — ${m.name} Close betting closes in ${toClose} min (at ${fmt12(w.closeTime)}).`,
          `${m.name} — close betting closes soon`,
        )) notified++
      }
    } catch (err) {
      console.warn('[cron] bet-window notify failed (non-fatal):', err instanceof Error ? err.message : err)
    }
  }

  // ── Starline closing reminders (hourly games) ──
  try {
    const stars = await db.appStarline.findMany({ where: { isOn: true, isActive: true } })
    for (const sl of stars) {
      const resultMins = sl.hour * 60 + (sl.minute || 0)
      const left = resultMins - (sl.betClosingMinutes || 0) - cur
      if (left > 0 && left <= REMIND_MINUTES) {
        if (await remindOnce(
          `cron:remind:${sl.code}:${today}`,
          `Last chance — ${sl.name} betting closes in ${left} min (result at ${fmt12(String(sl.hour).padStart(2, '0') + ':' + String(sl.minute || 0).padStart(2, '0'))}).`,
          `${sl.name} — betting closes soon`,
        )) notified++
      }
    }
  } catch (err) {
    console.warn('[cron] starline notify failed (non-fatal):', err instanceof Error ? err.message : err)
  }

  // Prune expired app sessions
  const pruned = await db.appSession.deleteMany({
    where: { expiresAt: { lt: now } },
  })

  return { changed, pruned: pruned.count, notified }
}
