/**
 * access-control.ts — THE ONE SOURCE OF TRUTH for role-based access control.
 *
 * Every ERP page declares an AccessLevel here; navigation, page rendering and
 * API guards all derive from THIS matrix. Nothing else in the codebase may
 * hard-code role checks for page visibility.
 *
 * Roles (DB values, see roles.ts):
 *   super    → Super Admin  (top role — everything)
 *   manager  → Admin        (operations under the Super Admin)
 *   user     → Agent        (field role — brings customers, works own book)
 *
 * Access levels:
 *   'all'   → Super Admin + Admin + Agent
 *   'admin' → Super Admin + Admin only        (agents NEVER see these pages)
 *   'super' → Super Admin only
 *
 * ── AGENT ACCESS PROFILE (operator-approved, 2026-10) ──────────────────
 * Agents CAN:   Dashboard · New Entry · Entry List · Customer List
 *               (ONLY customers filed under their own agent code)
 *               · My Commission (own ledger only) · My Subscription (own)
 * Agents CANNOT: Smart Entry · Chitthi Generator · Subscription Plan
 *               management · ANY WhatsApp panel page · App Bids
 *               · Market management · System management · Admin/Agent
 *               directories · Payment management · ANY admin action on
 *               customers they did not onboard.
 * Unknown pages are DENIED by default (fail-closed).
 * ───────────────────────────────────────────────────────────────────────
 */

import type { PageName } from '@/lib/store'
import { NextResponse } from 'next/server'

export type AccessLevel = 'all' | 'admin' | 'super'

export type UiRole = 'super' | 'manager' | 'user'

/** Normalize any DB role value (incl. legacy 'master') to the UI trio. */
export function normalizeUiRole(role: string | null | undefined): UiRole {
  if (role === 'super' || role === 'master') return 'super'
  if (role === 'manager') return 'manager'
  return 'user'
}

/** The full page → access matrix. Every PageName MUST be listed here. */
export const PAGE_ACCESS: Record<PageName, AccessLevel> = {
  // Dashboard + core entry work (agents' day job)
  dashboard: 'all',
  'inv-new': 'all',
  'inv-list': 'all',
  'card-view': 'all',
  paywall: 'all',
  login: 'all',
  // Customer directory — agents get a SERVER-SCOPED view (own customers only)
  vendor: 'all',
  // Agent's own money pages
  'agent-commission': 'all', // API scopes agents to their own ledger
  'sub-users': 'all',        // "My Subscription" — own subscription only

  // ── Operator rule #1: agents must NOT have Smart Entry ──
  'unified-entry': 'admin',
  // ── Operator rule #2: agents must NOT have the Chitthi Generator ──
  chitthi: 'admin',
  // ── Operator rule #3: agents must NOT manage subscription Plans ──
  'sub-plans': 'admin',

  // Entry-adjacent admin tooling
  'app-bids': 'admin',

  // ── WhatsApp Management panel (major panel — master/manager) ──
  // Dashboard / Messages / Templates / Approvals / Learning / Mappings.
  // Agents have no WhatsApp access (operator rule).
  'wa-dashboard': 'admin',
  'wa-messages': 'admin',
  'wa-templates': 'admin',
  'wa-approvals': 'admin',
  'wa-learning': 'admin',
  'wa-mappings': 'admin',

  // Control (hierarchy)
  'hierarchy-managers': 'super',
  'hierarchy-agents': 'admin',

  // Market management
  configure: 'admin',
  starlines: 'admin',
  'market-results': 'admin',
  'chart-data': 'admin',
  'game-management': 'admin',
  'game-allocation': 'super',
  'sys-mgmt-markets': 'super',

  // App wallet ops
  'app-funds': 'admin',

  // Native-app notifications — master admin only (broadcast/push composer)
  'app-notify': 'super',

  // Native-app content (notice marquee, banner sliders, bank details) — super only
  'app-content': 'super',

  // Release APK upload — super only
  'app-build': 'super',

  // System management
  'sys-mgmt-users': 'super',
  'sys-mgmt-activity': 'super',
  'sys-mgmt-locked': 'super',
  'sys-mgmt-pending': 'super',
  'sys-mgmt-parser-ex': 'super',
  'sys-mgmt-parser-cfg': 'admin',
  'sys-mgmt-chart-revs': 'super',

  // Subscriptions & payments
  'sub-payments': 'admin',

  // Legacy / deep-link pages
  users: 'super',
  'app-customers': 'super',
  'hierarchy-customers': 'super',
}

/** Can this role open this page? Unknown pages are denied (fail-closed). */
export function canAccessPage(role: string | null | undefined, page: PageName): boolean {
  const level = PAGE_ACCESS[page]
  if (!level) return false // unknown page → deny
  const r = normalizeUiRole(role)
  if (level === 'all') return true
  if (level === 'admin') return r === 'super' || r === 'manager'
  return r === 'super'
}

/** All pages a role may open (useful for tests + audits). */
export function accessiblePages(role: string | null | undefined): PageName[] {
  return (Object.keys(PAGE_ACCESS) as PageName[]).filter(p => canAccessPage(role, p))
}

// ────────────────────────────────────────────────────────────
// API-side enforcement (route handlers)
// ────────────────────────────────────────────────────────────

/** Role header set by proxy.ts from the signed ERP session cookie. */
export function apiRoleOf(request: Request): string {
  return request.headers.get('x-session-role') || ''
}

export function apiUsernameOf(request: Request): string {
  return request.headers.get('x-session-username') || ''
}

/** 403 response with a consistent shape. */
export function forbidApi(message = 'Access denied'): NextResponse {
  return NextResponse.json({ error: message }, { status: 403 })
}

/**
 * Guard a route handler by AccessLevel. Returns a NextResponse to send when
 * denied, or null when the request may proceed.
 *
 * NOTE: authentication itself is already enforced by proxy.ts (signed ERP
 * session cookie) for every non-public /api/* route; this guard only adds
 * the ROLE layer. Passing level 'all' therefore still means "any logged-in
 * ERP session", never "anonymous".
 */
export function requireApiAccess(
  request: Request,
  level: AccessLevel,
  message = 'Access denied',
): NextResponse | null {
  const raw = apiRoleOf(request)
  if (!raw) return NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 })
  const role = normalizeUiRole(raw)
  if (level === 'all') return null
  if (level === 'admin') {
    if (role === 'super' || role === 'manager') return null
    return forbidApi(message)
  }
  if (role === 'super') return null
  return forbidApi(message)
}

/** True when the request's session role can manage customers/admin data. */
export function isApiAdmin(request: Request): boolean {
  const role = normalizeUiRole(apiRoleOf(request))
  return role === 'super' || role === 'manager'
}

/** Human-readable matrix used in docs, UI notices and tests. */
export const AGENT_ACCESS_PROFILE = {
  allowed: ['dashboard', 'inv-new', 'inv-list', 'vendor (own customers only)', 'agent-commission (own ledger)', 'sub-users (own subscription)'],
  forbidden: ['unified-entry', 'chitthi', 'sub-plans', 'wa-dashboard', 'wa-messages', 'wa-templates', 'wa-approvals', 'wa-learning', 'wa-mappings', 'app-bids', 'app-funds', 'app-notify', 'app-content', 'app-build', 'configure', 'starlines', 'market-results', 'chart-data', 'game-management', 'game-allocation', 'hierarchy-managers', 'hierarchy-agents', 'sys-mgmt-users', 'sys-mgmt-markets', 'sys-mgmt-activity', 'sys-mgmt-locked', 'sys-mgmt-pending', 'sys-mgmt-parser-ex', 'sys-mgmt-parser-cfg', 'sys-mgmt-chart-revs', 'sub-payments'],
} as const
