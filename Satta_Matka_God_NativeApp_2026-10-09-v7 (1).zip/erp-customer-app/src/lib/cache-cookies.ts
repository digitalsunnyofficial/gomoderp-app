/**
 * Cache + Cookie + URL-hash utilities for the ERP.
 *
 * - Cookie helpers (get/set/delete) for tracking demo trial start, session
 *   hints, etc. Cookies persist across browser sessions and work with the
 *   promotional landing site (which uses them to remember "demo started").
 *
 * - TTL cache for GET fetches. Cuts redundant API calls (e.g., inventory
 *   codes, vendors list, plans) when navigating between ERP pages.
 *
 * - URL hash breadcrumbs. Syncs the current ERP page (useAppStore)
 *   with window.location.hash so URLs are shareable + bookmarkable.
 */

// ────────────────────────────────────────
// COOKIES
// ────────────────────────────────────────

export function getCookie(name: string): string | null {
  if (typeof document === 'undefined') return null
  const match = document.cookie.match(new RegExp('(?:^|; )' + escapeRegExp(name) + '=([^;]*)'))
  return match ? decodeURIComponent(match[1]) : null
}

export function setCookie(name: string, value: string, days: number = 365): void {
  if (typeof document === 'undefined') return
  const expires = new Date(Date.now() + days * 864e5).toUTCString()
  // SameSite=Lax so cookies work on the root domain + /merp subpath
  document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax`
}

export function deleteCookie(name: string): void {
  if (typeof document === 'undefined') return
  document.cookie = `${encodeURIComponent(name)}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax`
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

// ────────────────────────────────────────
// DEMO TRIAL TRACKING
// ────────────────────────────────────────

const DEMO_COOKIE = 'erp_demo_start'

/**
 * Record when a user starts the 2-day demo trial. Called from the landing
 * page signup form (or from the ERP after admin approves a signup).
 * Returns the ISO timestamp of the demo start.
 */
export function startDemoTrial(): string {
  const now = new Date().toISOString()
  setCookie(DEMO_COOKIE, now, 2) // expires in 2 days
  return now
}

/**
 * Check if the demo trial is still active. Returns:
 *   - { active: true, daysLeft, startedAt } if within 2 days
 *   - { active: false, daysLeft: 0, startedAt } if expired
 *   - { active: false, daysLeft: null, startedAt: null } if never started
 */
export function checkDemoTrial(): { active: boolean; daysLeft: number | null; startedAt: string | null } {
  const startedAt = getCookie(DEMO_COOKIE)
  if (!startedAt) return { active: false, daysLeft: null, startedAt: null }
  const start = new Date(startedAt).getTime()
  const elapsed = Date.now() - start
  const daysElapsed = elapsed / 864e5
  const daysLeft = Math.max(0, 2 - daysElapsed)
  return { active: daysLeft > 0, daysLeft, startedAt }
}

export function clearDemoTrial(): void {
  deleteCookie(DEMO_COOKIE)
}

// ────────────────────────────────────────
// TTL CACHE for GET fetches
// ────────────────────────────────────────

interface CacheEntry {
  data: unknown
  expiresAt: number
}

const cacheStore = new Map<string, CacheEntry>()

/**
 * Fetch with a TTL cache. Only caches successful GET requests.
 *
 * Usage:
 *   const codes = await cachedFetch('/api/inventory-codes', 60_000)
 *   // cached for 60 seconds
 */
export async function cachedFetch<T = unknown>(url: string, ttlMs: number = 60_000): Promise<T> {
  const now = Date.now()
  const cached = cacheStore.get(url)
  if (cached && cached.expiresAt > now) {
    return cached.data as T
  }
  const res = await fetch(url)
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`)
  }
  const data = await res.json()
  cacheStore.set(url, { data, expiresAt: now + ttlMs })
  return data as T
}

/**
 * Invalidate cached entries matching a prefix (or all if no prefix).
 * Call after mutations to ensure stale data isn't served.
 */
export function invalidateCache(prefix?: string): void {
  if (!prefix) {
    cacheStore.clear()
    return
  }
  for (const key of cacheStore.keys()) {
    if (key.startsWith(prefix)) cacheStore.delete(key)
  }
}

// ────────────────────────────────────────
// URL HASH BREADCRUMBS
// ────────────────────────────────────────

/**
 * Map of ERP page names → URL hash. Used to make URLs shareable.
 * E.g., currentPage='dashboard' → URL becomes /merp#dashboard
 */
const PAGE_TO_HASH: Record<string, string> = {
  'dashboard': '#dashboard',
  'inv-new': '#new-entry',
  'inv-list': '#entries',
  'card-view': '#card',
  'vendor': '#khatri',
  'configure': '#settings',
  'users': '#users',
  'sub-plans': '#plans',
  'sub-users': '#subscriptions',
  'sub-payments': '#payments',
  'sys-mgmt-users': '#mgmt-users',
  'sys-mgmt-pending': '#pending',
  'sys-mgmt-activity': '#activity',
  'sys-mgmt-markets': '#markets',
  'sys-mgmt-locked': '#locked',
  'sys-mgmt-parser-ex': '#parser-ex',
  'sys-mgmt-parser-cfg': '#parser-cfg',
  'sys-mgmt-chart-revs': '#chart-revs',
  'hierarchy-managers': '#managers',
  'hierarchy-agents': '#agents',
  'hierarchy-customers': '#customers',
}

const HASH_TO_PAGE: Record<string, string> = Object.fromEntries(
  Object.entries(PAGE_TO_HASH).map(([page, hash]) => [hash.slice(1), page])
)

/**
 * Sync the URL hash with the current ERP page. Call this from a useEffect
 * that watches currentPage.
 */
export function syncHashForPage(page: string): void {
  if (typeof window === 'undefined') return
  const hash = PAGE_TO_HASH[page]
  if (hash && window.location.hash !== hash) {
    // Use replaceState to avoid filling browser history
    window.history.replaceState(null, '', `${window.location.pathname}${hash}`)
  }
}

/**
 * Read the current page from the URL hash. Used on initial load to restore
 * the user's last position.
 */
export function pageFromHash(): string | null {
  if (typeof window === 'undefined') return null
  const hash = window.location.hash.slice(1)
  return HASH_TO_PAGE[hash] || null
}
