/**
 * Phase 2 — Auth, audit, and market-access helpers.
 *
 * Frontend stores the logged-in user in localStorage (key `erp_user`).
 * For mutations, the frontend sends a custom header `x-user-id` so the
 * backend can identify the actor. The backend re-fetches the user from DB
 * to confirm identity and read `assignedMarkets` + `isLocked`.
 */

import { db } from './db'
import { NextResponse } from 'next/server'
import { isSuperRole } from './roles'

export interface AuthUser {
  id: string
  username: string
  role: string
  name: string | null
  assignedMarkets: string[]
  isLocked: boolean
}

// ────────────────────────────────────────────────────────────
// User identification
// ────────────────────────────────────────────────────────────

/**
 * Resolve the user making a request.
 * Accepts either a `x-user-id` header (preferred) or falls back to
 * `x-username` for backwards compatibility with old frontend code.
 * Returns null if the user cannot be identified, has been deleted, or is locked.
 */
export async function getRequestUser(request: Request): Promise<AuthUser | null> {
  const userId = request.headers.get('x-user-id')
  const username = request.headers.get('x-username')

  let raw: {
    id: string
    username: string
    role: string
    name: string | null
    assignedMarkets: string
    isLocked: boolean
    status: string
  } | null = null

  if (userId) {
    raw = await db.user.findUnique({ where: { id: userId } }) as typeof raw
  } else if (username) {
    raw = await db.user.findUnique({ where: { username } }) as typeof raw
  }

  if (!raw) return null
  if (raw.status !== 'active' || raw.isLocked) return null

  return {
    id: raw.id,
    username: raw.username,
    role: raw.role,
    name: raw.name,
    assignedMarkets: safeParseMarkets(raw.assignedMarkets),
    isLocked: raw.isLocked,
  }
}

/**
 * Super admins implicitly have access to all markets.
 * Regular users only have access to markets in their `assignedMarkets` array.
 */
export function canAccessMarket(user: AuthUser, market: string | null | undefined): boolean {
  if (!market) return true // system-level action, allow
  if (isSuperRole(user.role) || user.role === 'manager') return true
  return user.assignedMarkets.includes(market)
}

/**
 * Returns the list of markets the user is allowed to see.
 * Used to filter list endpoints.
 */
export function getAccessibleMarkets(user: AuthUser): string[] | null {
  if (user.role === 'super' || user.role === 'manager') return null // null means "all markets"
  return user.assignedMarkets
}

function safeParseMarkets(raw: string): string[] {
  try {
    const v = JSON.parse(raw)
    if (Array.isArray(v)) return v.map(String)
  } catch {
    // ignore
  }
  return []
}

// ────────────────────────────────────────────────────────────
// Audit logging
// ────────────────────────────────────────────────────────────

export type ActivityAction =
  | 'LOGIN'
  | 'LOGOUT'
  | 'LOGIN_DENIED_LOCKED'
  | 'INVENTORY_CREATE'
  | 'INVENTORY_UPDATE'
  | 'INVENTORY_DELETE'
  | 'TRIPLE_UPLOAD'
  | 'TRIPLE_UPDATE'
  | 'TRIPLE_DELETE'
  | 'DS_UPLOAD'
  | 'DS_UPDATE'
  | 'DS_DELETE'
  | 'SETTLEMENT_CREATE'
  | 'SETTLEMENT_UPDATE'
  | 'SETTLEMENT_DELETE'
  | 'VENDOR_CREATE'
  | 'VENDOR_UPDATE'
  | 'VENDOR_DELETE'
  | 'USER_CREATE'
  | 'USER_UPDATE'
  | 'USER_LOCK'
  | 'USER_UNLOCK'
  | 'PERMISSIONS_UPDATE'
  | 'PARSER_CORRECT'
  | 'PARSER_IGNORE'
  | 'CHART_EDIT'
  | 'CHART_REGENERATE'

export interface LogActivityInput {
  userId: string
  username: string
  action: ActivityAction | string
  market?: string | null
  recordsAffected?: number
  metadata?: Record<string, unknown> | null
}

/**
 * Append a row to the audit trail.
 * Never throws — if logging fails, the original operation should still succeed.
 */
export async function logActivity(input: LogActivityInput): Promise<void> {
  try {
    await db.userActivity.create({
      data: {
        userId: input.userId,
        username: input.username,
        action: input.action,
        market: input.market ?? null,
        recordsAffected: input.recordsAffected ?? 0,
        metadata: input.metadata ? JSON.stringify(input.metadata) : '{}',
      },
    })
  } catch (err) {
    // Audit log is best-effort; never block business logic on it.
    console.error('[logActivity] failed:', err)
  }
}

// ────────────────────────────────────────────────────────────
// Parser exception recording
// ────────────────────────────────────────────────────────────

export interface ParserExceptionInput {
  uploadedBy: string
  originalText: string
  market?: string | null
  inventoryCodeId?: string | null
  reason: string
}

export async function requireMaster(request?: Request): Promise<
  | { ok: true; user: AuthUser }
  | { ok: false; response: NextResponse }
> {
  if (!request) {
    return { ok: false, response: NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 }) }
  }
  const user = await getRequestUser(request)
  if (!user) {
    return { ok: false, response: NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 }) }
  }
  if (!isSuperRole(user.role)) {
    return { ok: false, response: NextResponse.json({ error: 'Forbidden — super admin role required' }, { status: 403 }) }
  }
  return { ok: true, user }
}

export async function recordParserException(input: ParserExceptionInput): Promise<void> {
  try {
    await db.parserException.create({
      data: {
        uploadedBy: input.uploadedBy,
        originalText: input.originalText,
        market: input.market ?? null,
        inventoryCodeId: input.inventoryCodeId ?? null,
        reason: input.reason,
        status: 'pending',
      },
    })
  } catch (err) {
    console.error('[recordParserException] failed:', err)
  }
}
