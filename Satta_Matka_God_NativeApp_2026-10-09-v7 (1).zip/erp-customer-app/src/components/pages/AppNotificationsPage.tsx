'use client'

// ──────────────────────────────────────────────────────────
// APP NOTIFICATIONS (ERP side) — master-admin composer for the
// native customer app. Sends in-app messages (AppNotification —
// customerId:null = broadcast seen by everyone) + Expo push
// (exp.host → FCM) to every registered device, via
// /api/app-admin/notifications.
//   • Audience: all / approved / pending / one agent's customers / one customer
//   • History of broadcasts with one-tap retract
// Icons use the SAME lucide names the web + native icon maps ship
// (megaphone, party, trophy, …) so they render identically in the app.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { SectionCard, GoldButton } from '@/components/shared-ui'
import {
  Bell, Check, AlertTriangle, RefreshCw, Send, Trash2, Users, Clock, BellRing, BellOff,
} from 'lucide-react'

const dt = (v: string | null | undefined) =>
  v ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('sent') || message.includes('Sent')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

const ICON_CHOICES = [
  { id: 'megaphone', label: '📣 Announce' },
  { id: 'party', label: '🎉 Promotion' },
  { id: 'trophy', label: '🏆 Results' },
  { id: 'sparkles', label: '✨ Special' },
  { id: 'alert-triangle', label: '⚠️ Important' },
  { id: 'bell', label: '🔔 General' },
]

const AUDIENCES = [
  { id: 'all', label: 'All customers', hint: 'One broadcast — every customer sees it in Notifications' },
  { id: 'approved', label: 'Approved only', hint: 'Personal copies to approved customers' },
  { id: 'pending', label: 'Pending approval', hint: 'Nudge signups waiting for your approval' },
  { id: 'agent', label: "One agent's customers", hint: 'Everyone filed under a chosen agent' },
  { id: 'customer', label: 'Single customer', hint: 'Search by name or mobile and send personally' },
]

type AgentRow = { username: string; name: string | null; customers: number }
type CustomerRow = { id: string; name: string; mobile: string }
type Broadcast = { id: string; icon: string; text: string; createdAt: string }

export function AppNotificationsPage() {
  const [broadcasts, setBroadcasts] = useState<Broadcast[]>([])
  const [counts, setCounts] = useState({ total: 0, approved: 0, pending: 0, pushRegistered: 0, pushEnabled: true })
  const [agents, setAgents] = useState<AgentRow[]>([])
  const [loading, setLoading] = useState(true)

  const [audience, setAudience] = useState('all')
  const [icon, setIcon] = useState('megaphone')
  const [text, setText] = useState('')
  const [agentUsername, setAgentUsername] = useState('')
  const [custQuery, setCustQuery] = useState('')
  const [custMatches, setCustMatches] = useState<CustomerRow[]>([])
  const [custPick, setCustPick] = useState<CustomerRow | null>(null)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')

  const load = useCallback(() => {
    setLoading(true)
    apiFetch('/api/app-admin/notifications')
      .then((d: { broadcasts: Broadcast[]; counts: typeof counts; agents: AgentRow[] }) => {
        setBroadcasts(d.broadcasts || []); setCounts(d.counts); setAgents(d.agents || [])
        setLoading(false)
      })
      .catch(e => { setMessage(e instanceof Error ? e.message : 'Failed to load'); setLoading(false) })
  }, [])
  useEffect(() => { load() }, [load])

  // customer search for the single-customer audience
  useEffect(() => {
    if (audience !== 'customer' || custQuery.trim().length < 2) { setCustMatches([]); return }
    const t = setTimeout(() => {
      apiFetch('/api/app-admin/customers?search=' + encodeURIComponent(custQuery.trim()))
        .then((d: { customers: CustomerRow[] }) => setCustMatches((d.customers || []).slice(0, 6)))
        .catch(() => setCustMatches([]))
    }, 300)
    return () => clearTimeout(t)
  }, [custQuery, audience])

  const send = async () => {
    if (!text.trim()) { setMessage('Write a message first'); return }
    if (audience === 'agent' && !agentUsername) { setMessage('Choose an agent'); return }
    if (audience === 'customer' && !custPick) { setMessage('Search and pick a customer'); return }
    setBusy(true)
    try {
      const res = await apiFetch('/api/app-admin/notifications', {
        method: 'POST',
        body: JSON.stringify({
          text: text.trim(), icon, audience,
          agentUsername: audience === 'agent' ? agentUsername : undefined,
          customerId: audience === 'customer' ? custPick?.id : undefined,
        }),
      }) as { notified: string | number; push: { delivered: number; failed: number; skipped: boolean } }
      const pushTxt = res.push.skipped
        ? 'push skipped (no registered devices or push disabled)'
        : `push delivered to ${res.push.delivered} device(s)${res.push.failed ? `, ${res.push.failed} failed` : ''}`
      setMessage(`Sent — ${typeof res.notified === 'number' ? res.notified + ' customer(s)' : res.notified}, ${pushTxt}. Sent — success`)
      setText(''); setCustPick(null); setCustQuery('')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed to send') }
    setBusy(false)
  }

  const retract = async (id: string) => {
    try {
      await apiFetch('/api/app-admin/notifications?id=' + id, { method: 'DELETE' })
      setMessage('Broadcast retracted — removed from every customer\'s list. Sent — success')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed to retract') }
  }

  const audienceHint = AUDIENCES.find(a => a.id === audience)?.hint

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <Bell size={22} className="text-indigo-600" /> App Notifications
          </h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Send messages to the Satta Matka God app — in-app Notifications + instant push on customers&apos; phones</p>
        </div>
        <button onClick={load} className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" aria-label="Refresh">
          <RefreshCw size={15} className="text-slate-500" />
        </button>
      </div>

      <Msg message={message} />

      {/* ── audience snapshot ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Total customers', v: counts.total, icon: Users },
          { label: 'Approved', v: counts.approved, icon: Check },
          { label: 'Pending approval', v: counts.pending, icon: Clock },
          { label: 'Push-registered devices', v: counts.pushRegistered, icon: counts.pushEnabled ? BellRing : BellOff },
        ].map(s => (
          <div key={s.label} className="rounded-xl border border-slate-200 bg-white p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0">
              <s.icon size={15} className="text-indigo-600" />
            </div>
            <div>
              <div className="text-[16px] font-bold text-[#111827] leading-none">{s.v}</div>
              <div className="text-[10.5px] text-slate-400 mt-1">{s.label}</div>
            </div>
          </div>
        ))}
      </div>
      {!counts.pushEnabled && (
        <div className="text-[11.5px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-5 flex items-center gap-2">
          <BellOff size={13} /> Push is disabled on the server (PUSH_ENABLED=false) — messages still appear in the app&apos;s Notifications screen.
        </div>
      )}

      {/* ── composer ── */}
      <SectionCard title="Compose">
        <div className="space-y-4">
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Audience</div>
            <div className="flex flex-wrap gap-2">
              {AUDIENCES.map(a => (
                <button key={a.id} onClick={() => { setAudience(a.id); setCustPick(null); setCustMatches([]) }}
                  className={`text-[12px] px-3 py-1.5 rounded-lg border transition-colors ${audience === a.id ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'}`}>
                  {a.label}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">{audienceHint}</p>
          </div>

          {audience === 'agent' && (
            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Agent</div>
              <select value={agentUsername} onChange={e => setAgentUsername(e.target.value)}
                className="text-[12.5px] border border-slate-200 rounded-lg px-3 py-2 w-full max-w-sm outline-none focus:border-indigo-400">
                <option value="">— choose agent —</option>
                {agents.map(a => (
                  <option key={a.username} value={a.username}>{a.name || a.username} ({a.customers} customers)</option>
                ))}
              </select>
              {agents.length === 0 && !loading && <p className="text-[11px] text-slate-400 mt-1">No agent filings yet.</p>}
            </div>
          )}

          {audience === 'customer' && (
            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Customer</div>
              {custPick ? (
                <div className="flex items-center gap-2 text-[12.5px] mb-2">
                  <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold">
                    {custPick.name} · {custPick.mobile}
                  </span>
                  <button onClick={() => setCustPick(null)} className="text-[11px] text-slate-400 hover:text-slate-600 underline">change</button>
                </div>
              ) : (
                <>
                  <input value={custQuery} onChange={e => setCustQuery(e.target.value)}
                    placeholder="Type name or mobile number…"
                    className="text-[12.5px] border border-slate-200 rounded-lg px-3 py-2 w-full max-w-sm outline-none focus:border-indigo-400" />
                  {custMatches.length > 0 && (
                    <div className="mt-2 max-w-sm border border-slate-200 rounded-lg divide-y divide-slate-100 bg-white overflow-hidden">
                      {custMatches.map(c => (
                        <button key={c.id} onClick={() => { setCustPick(c); setCustMatches([]); setCustQuery('') }}
                          className="w-full text-left px-3 py-2 text-[12.5px] hover:bg-indigo-50 flex justify-between">
                          <span className="font-semibold text-slate-700">{c.name}</span>
                          <span className="text-slate-400">{c.mobile}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Style</div>
            <div className="flex flex-wrap gap-2">
              {ICON_CHOICES.map(c => (
                <button key={c.id} onClick={() => setIcon(c.id)}
                  className={`text-[12px] px-3 py-1.5 rounded-lg border transition-colors ${icon === c.id ? 'bg-amber-100 text-amber-800 border-amber-300 font-semibold' : 'bg-white text-slate-600 border-slate-200 hover:border-amber-300'}`}>
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Message</div>
            <textarea value={text} onChange={e => setText(e.target.value.slice(0, 500))} rows={3}
              placeholder="e.g. Market timings updated from tomorrow — check the app for the new chart."
              className="text-[12.5px] border border-slate-200 rounded-lg px-3 py-2.5 w-full outline-none focus:border-indigo-400 resize-none" />
            <div className="text-[10.5px] text-slate-400 text-right">{text.length}/500</div>
          </div>

          <div className="flex items-center gap-3">
            <GoldButton onClick={send} disabled={busy}>
              <span className="flex items-center gap-2"><Send size={14} /> {busy ? 'Sending…' : 'Send notification'}</span>
            </GoldButton>
            <p className="text-[11px] text-slate-400">Appears in the app&apos;s Notifications screen; pushed instantly to registered phones.</p>
          </div>
        </div>
      </SectionCard>

      {/* ── broadcast history ── */}
      <div className="mt-5">
        <SectionCard title={`Broadcast history (${broadcasts.length})`}>
          {loading ? <p className="text-[12px] text-slate-400 py-4">Loading…</p> : broadcasts.length === 0 ? (
            <p className="text-[12px] text-slate-400 py-4">No broadcasts sent yet.</p>
          ) : (
            <div className="space-y-2">
              {broadcasts.map(b => {
                const ic = ICON_CHOICES.find(c => c.id === b.icon)
                return (
                  <div key={b.id} className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white px-3.5 py-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0 text-[15px]">
                      {ic ? ic.label.split(' ')[0] : '🔔'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[12.5px] text-slate-700 leading-relaxed break-words">{b.text}</p>
                      <p className="text-[10.5px] text-slate-400 mt-1">{dt(b.createdAt)} · visible to all customers</p>
                    </div>
                    <button onClick={() => retract(b.id)} title="Retract from all customers"
                      className="p-1.5 rounded-lg text-slate-300 hover:text-red-600 hover:bg-red-50 shrink-0">
                      <Trash2 size={14} />
                    </button>
                  </div>
                )
              })}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  )
}
