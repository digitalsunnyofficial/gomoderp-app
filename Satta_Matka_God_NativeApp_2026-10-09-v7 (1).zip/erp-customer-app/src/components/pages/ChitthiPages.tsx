'use client'

// ────────────────────────────────────────────────────────────
// Chitthi Generator — ERP page.
// An agent collects a customer's vyapar on the ground, enters it here
// (live-parsed by the SAME Smart Entry engine), and on submit the
// system renders the traditional handwritten chitthi slip as a JPG —
// ready to share with the customer on WhatsApp or print for a hard copy.
// ────────────────────────────────────────────────────────────

import React, { useState, useEffect, useMemo, useCallback } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { parseUnifiedEntry } from '@/lib/matka/entry-parser'
import type { CustomTerm } from '@/lib/matka/term-registry'
import { FormField, FormInput, GoldButton } from '@/components/shared-ui'
import { Printer, Share2, Download, RefreshCw, FileImage, Users } from 'lucide-react'

interface VendorLite { id: string; businessName: string; mobileNo: string }

interface ChitthiRow {
  id: string
  customerName: string
  market: string
  chitthiDate: string
  totalAmount: number
  createdBy: string
  createdAt: string
  imageUrl: string
}

interface GenerateResponse {
  id: string
  imageUrl: string
  total: number
  summary: {
    counts: {
      singles: { count: number; amount: number }
      doubles: { count: number; amount: number }
      triples: { count: number; amount: number }
      common: { count: number; amount: number }
      groups: Array<{ option: string; count: number; amount: number }>
    }
    total: number
    unknownLabels: string[]
    skipped: string[]
  }
}

function istToday(): string {
  const now = new Date(Date.now() + 5.5 * 3600 * 1000)
  return now.toISOString().slice(0, 10)
}

export function ChitthiPage() {
  const [vendors, setVendors] = useState<VendorLite[]>([])
  const [customTerms, setCustomTerms] = useState<CustomTerm[]>([])
  const [vendorId, setVendorId] = useState('')
  const [freeName, setFreeName] = useState('')
  const [market, setMarket] = useState('')
  const [date, setDate] = useState(istToday())
  const [defaultRate, setDefaultRate] = useState('100')
  const [rawText, setRawText] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState<GenerateResponse | null>(null)
  const [currentMeta, setCurrentMeta] = useState<{ market: string; customer: string }>({ market: '', customer: '' })
  const [recent, setRecent] = useState<ChitthiRow[]>([])
  const [imgBust, setImgBust] = useState(0)

  const loadRecent = useCallback(() => {
    apiFetch('/api/chitthi').then(setRecent).catch(console.error)
  }, [])

  useEffect(() => {
    apiFetch('/api/vendors').then((rows: VendorLite[]) => {
      setVendors(Array.isArray(rows) ? rows : [])
    }).catch(console.error)
    apiFetch('/api/parser-terms').then((rows: CustomTerm[]) => {
      setCustomTerms(Array.isArray(rows) ? rows : [])
    }).catch(console.error)
    loadRecent()
  }, [loadRecent])

  // Live parse preview — same engine as Smart Entry (client-safe)
  const preview = useMemo(() => {
    const text = rawText.trim()
    if (!text) return null
    const rate = parseFloat(defaultRate) || 0
    const parse = parseUnifiedEntry(text, rate, customTerms)
    const sum = (arr: Array<{ amount: number }>) => arr.reduce((s, e) => s + e.amount, 0)
    const groups = parse.groups.map(g => ({ option: g.option, count: g.entries.length, amount: sum(g.entries) }))
    const total = sum(parse.singles) + sum(parse.doubles) + sum(parse.triples) + sum(parse.common) +
      groups.reduce((s, g) => s + g.amount, 0)
    return { parse, total, groups }
  }, [rawText, defaultRate, customTerms])

  const submit = async () => {
    setError('')
    if (!market.trim()) { setError('Please enter the market name (e.g. Milan, KB).'); return }
    if (!rawText.trim()) { setError('Please enter the customer vyapar.'); return }
    setBusy(true)
    try {
      const vendor = vendors.find(v => v.id === vendorId)
      const res = await apiFetch('/api/chitthi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendorId: vendorId || undefined,
          customerName: vendor?.businessName || freeName || undefined,
          customerMobile: vendor?.mobileNo || undefined,
          market: market.trim(),
          date,
          rawText: rawText.trim(),
          defaultRate: parseFloat(defaultRate) || 100,
        }),
      })
      if (res?.error) { setError(res.error); return }
      setResult(res)
      setCurrentMeta({ market: market.trim(), customer: vendor?.businessName || freeName || '' })
      setImgBust(b => b + 1)
      loadRecent()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate chitthi')
    } finally {
      setBusy(false)
    }
  }

  const shareChitthi = async () => {
    if (!result) return
    const abs = `${window.location.origin}${result.imageUrl}`
    try {
      // Web Share Level 2 — share the actual JPG where supported (mobile)
      const imgRes = await fetch(`${result.imageUrl}?v=${imgBust}`)
      const blob = await imgRes.blob()
      const file = new File([blob], 'chitthi.jpg', { type: 'image/jpeg' })
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: 'Chitthi', text: `Chitthi — ${currentMeta.market} — total ₹${result.total}` })
        return
      }
    } catch { /* user cancelled or unsupported — fall through */ }
    // Fallback: open the image and prefill a WhatsApp text share
    window.open(abs, '_blank')
    const waText = encodeURIComponent(`Chitthi — ${currentMeta.market} — total ₹${result.total}`)
    window.open(`https://wa.me/?text=${waText}`, '_blank')
  }

  const printChitthi = () => {
    if (!result) return
    const w = window.open('', '_blank', 'width=480,height=780')
    if (!w) return
    w.document.write(`<html><head><title>Chitthi</title></head><body style="margin:0;display:flex;align-items:center;justify-content:center"><img src="${result.imageUrl}?v=${imgBust}" style="max-width:100%;max-height:100vh" onload="window.print()"></body></html>`)
    w.document.close()
  }

  const selectedVendor = vendors.find(v => v.id === vendorId)

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <div className="mb-5">
        <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <FileImage className="w-5 h-5 text-indigo-600" />
          Chitthi Generator
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Enter the customer vyapar you collected — the system writes it on the chitthi slip.
          Share the JPG with the customer on WhatsApp, or print it for a hard copy.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        {/* ── Left: form ── */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <FormField label="Customer (from your list)">
              <select
                value={vendorId}
                onChange={e => setVendorId(e.target.value)}
                className="w-full h-10 rounded-md border border-slate-300 bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">— Free text / no selection —</option>
                {vendors.map(v => (
                  <option key={v.id} value={v.id}>{v.businessName} ({v.mobileNo})</option>
                ))}
              </select>
            </FormField>
            {!vendorId && (
              <FormField label="Customer name (written on chitthi)">
                <FormInput value={freeName} onChange={e => setFreeName(e.target.value)} placeholder="e.g. Ramesh Bhai" />
              </FormField>
            )}
            <FormField label="Market">
              <FormInput value={market} onChange={e => setMarket(e.target.value)} placeholder="e.g. Milan, KB, Kalyan" />
            </FormField>
            <FormField label="Date">
              <FormInput type="date" value={date} onChange={e => setDate(e.target.value)} />
            </FormField>
          </div>

          {selectedVendor && (
            <div className="text-xs text-slate-500 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              Chitthi will show: {selectedVendor.businessName}
            </div>
          )}

          <FormField label="Vyapar (numbers with rates — same style as Smart Entry)">
            <textarea
              value={rawText}
              onChange={e => setRawText(e.target.value)}
              rows={10}
              spellCheck={false}
              className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder={'680=50\n360=50\n577=50\nMotor - 23457890,100'}
            />
          </FormField>

          <div className="flex items-end gap-3">
            <FormField label="Default rate (for numbers without an amount)">
              <FormInput
                type="number"
                min={1}
                value={defaultRate}
                onChange={e => setDefaultRate(e.target.value)}
                className="w-32"
              />
            </FormField>
          </div>

          {/* Live parse preview */}
          {preview && preview.total > 0 && (
            <div className="rounded-lg bg-indigo-50 border border-indigo-100 p-3 text-xs text-slate-700 space-y-1">
              <div className="font-semibold text-indigo-700 mb-1">Live check — what will be written on the chitthi</div>
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                {preview.parse.singles.length > 0 && <span>Single: {preview.parse.singles.length} = ₹{preview.parse.singles.reduce((s, e) => s + e.amount, 0)}</span>}
                {preview.parse.doubles.length > 0 && <span>Jodi: {preview.parse.doubles.length} = ₹{preview.parse.doubles.reduce((s, e) => s + e.amount, 0)}</span>}
                {preview.parse.triples.length > 0 && <span>Panna: {preview.parse.triples.length} = ₹{preview.parse.triples.reduce((s, e) => s + e.amount, 0)}</span>}
                {preview.parse.common.length > 0 && <span>Common: {preview.parse.common.length} = ₹{preview.parse.common.reduce((s, e) => s + e.amount, 0)}</span>}
                {preview.groups.map(g => (
                  <span key={g.option}>{g.option}: {g.count} = ₹{g.amount}</span>
                ))}
              </div>
              <div className="font-bold text-indigo-800 pt-1 border-t border-indigo-100">Total: ₹{preview.total}</div>
              {preview.parse.unknownLabels.length > 0 && (
                <div className="text-amber-700">Not in dictionary: {preview.parse.unknownLabels.join(', ')} — they will NOT be written on the chitthi.</div>
              )}
            </div>
          )}

          {error && <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-md px-3 py-2">{error}</div>}

          <div className="w-full [&>button]:w-full [&>button]:justify-center">
            <GoldButton onClick={submit} disabled={busy}>
              {busy ? (
                <span className="flex items-center justify-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" /> Writing the chitthi…</span>
              ) : 'Generate Chitthi (JPG)'}
            </GoldButton>
          </div>
        </div>

        {/* ── Right: rendered chitthi ── */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
          {result ? (
            <div className="space-y-3">
              <img
                src={`${result.imageUrl}?v=${imgBust}`}
                alt="Chitthi"
                className="w-full max-w-sm mx-auto rounded-lg shadow-md"
              />
              <div className="text-center text-sm text-slate-600">
                {currentMeta.customer || 'Customer'} · {currentMeta.market} · Total <span className="font-bold text-slate-800">₹{result.total}</span>
              </div>
              <div className="flex flex-wrap justify-center gap-2 pt-1">
                <a
                  href={`${result.imageUrl}?download=1`}
                  className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  <Download className="w-4 h-4" /> Download
                </a>
                <button
                  onClick={shareChitthi}
                  className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-700"
                >
                  <Share2 className="w-4 h-4" /> Share
                </button>
                <button
                  onClick={printChitthi}
                  className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  <Printer className="w-4 h-4" /> Print
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-64 flex flex-col items-center justify-center text-center text-slate-400 gap-2 py-10">
              <FileImage className="w-10 h-10" />
              <p className="text-sm">The chitthi photo will appear here after you generate it.</p>
              <p className="text-xs">It looks like the handwritten slip the customer is used to — with every number and the total circled.</p>
            </div>
          )}
        </div>
      </div>

      {/* ── Recent chitthis ── */}
      <div className="mt-6 bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-700">Recent chitthis</h2>
          <button onClick={loadRecent} className="text-xs text-indigo-600 hover:underline flex items-center gap-1">
            <RefreshCw className="w-3 h-3" /> Refresh
          </button>
        </div>
        {recent.length === 0 ? (
          <p className="text-sm text-slate-400">No chitthis yet.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {recent.map(r => (
              <button
                key={r.id}
                onClick={() => {
                  setResult({ id: r.id, imageUrl: r.imageUrl, total: r.totalAmount, summary: null as never })
                  setCurrentMeta({ market: r.market, customer: r.customerName || '' })
                  setImgBust(Date.now())
                }}
                className="group text-left rounded-lg border border-slate-200 overflow-hidden hover:border-indigo-400 hover:shadow-sm transition"
              >
                <img src={`${r.imageUrl}?w=200`} alt={r.market} className="w-full h-36 object-cover object-top" />
                <div className="p-2">
                  <div className="text-xs font-semibold text-slate-700 truncate">{r.market} · ₹{r.totalAmount}</div>
                  <div className="text-[11px] text-slate-400 truncate">{r.customerName || '—'} · {r.chitthiDate}</div>
                  <div className="text-[11px] text-slate-400 truncate">by {r.createdBy}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
