'use client'

// ────────────────────────────────────────────────────────────
// WhatsApp Management panel — PAGE 1: Dashboard.
// Channel health, 7-day activity, approval funnel, top customers,
// bot evolution (learning → parser versions), reply latency,
// computed optimization suggestions, and the sandbox simulator.
// ────────────────────────────────────────────────────────────

import React, { useState, useEffect, useCallback } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import {
  MessageCircle, Info, Send, CircleCheck, Clock, GraduationCap,
  Lightbulb, TrendingUp, Timer, Users,
} from 'lucide-react'
import { PanelHeader, RefreshButton, fmtTime, type WaStatus } from './WhatsAppPanelShared'

interface PanelStats {
  mode: 'live' | 'sandbox'
  approvalMode: 'on' | 'off'
  parserVersion: number
  totals: {
    inbound: number; outbound: number; pending: number; approved: number
    rejected: number; failedOutbound: number; transactions: number; txAmount: number
  }
  daily: Array<{ date: string; inbound: number; outbound: number; rejected: number }>
  topCustomers: Array<{ key: string; name: string; agentName: string | null; inbound: number; outbound: number }>
  unknownLabels: Array<{ label: string; count: number }>
  learning: {
    open: number; applied: number; dismissed: number
    recentActivations: Array<{ term: string; category: string | null; at: string | null }>
  }
  latency: { avgMs: number; sampled: number } | null
  suggestions: Array<{ severity: 'info' | 'warn'; text: string; page?: string }>
}

// nav helper without importing the whole store switch — PageName-safe jump
function usePanelNav() {
  const setCurrentPage = useAppStore(s => s.setCurrentPage)
  return (page: string) => setCurrentPage(page as never)
}

export function WhatsAppDashboardPage() {
  const nav = usePanelNav()
  const [stats, setStats] = useState<PanelStats | null>(null)
  const [status, setStatus] = useState<WaStatus | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    Promise.all([
      apiFetch('/api/whatsapp/panel-stats'),
      apiFetch('/api/whatsapp/status'),
    ]).then(([s, st]) => {
      setStats(s?.totals ? s : null)
      setStatus(st)
    }).catch(console.error).finally(() => setLoading(false))
  }, [])
  useEffect(() => { load() }, [load])

  const maxDaily = Math.max(1, ...(stats?.daily || []).map(d => Math.max(d.inbound, d.outbound)))

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PanelHeader
        icon={<MessageCircle className="w-5 h-5 text-emerald-600" />}
        title="WhatsApp Dashboard"
        subtitle={<>The whole WhatsApp channel at a glance — volume, approval funnel, bot evolution and where to optimize next.</>}
        actions={<RefreshButton loading={loading} onClick={load} />}
      />

      {stats?.suggestions?.some(s => s.severity === 'warn') && (
        <div className="mb-4 space-y-2">
          {stats.suggestions.filter(s => s.severity === 'warn').map((s, i) => (
            <button key={i} onClick={() => s.page && nav(s.page)}
              className="w-full text-left rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800 hover:bg-amber-100">
              ⚠ {s.text}{s.page && <span className="ml-1 underline">Take me there →</span>}
            </button>
          ))}
        </div>
      )}

      {/* ── KPI cards ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3 mb-5">
        <Kpi label="Inbound (30d)" value={stats?.totals.inbound ?? '—'} tone="indigo" />
        <Kpi label="Replies sent" value={stats?.totals.outbound ?? '—'} tone="emerald" />
        <Kpi label="Pending approval" value={stats?.totals.pending ?? '—'} tone="amber" onClick={() => nav('wa-approvals')} />
        <Kpi label="Approved txs" value={stats?.totals.approved ?? '—'} tone="emerald" onClick={() => nav('wa-approvals')} />
        <Kpi label="Rejected" value={stats?.totals.rejected ?? '—'} tone="red" onClick={() => nav('wa-approvals')} />
        <Kpi label="Business (tx ₹)" value={stats ? `₹${stats.totals.txAmount}` : '—'} tone="violet" />
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        {/* ── 7-day activity ── */}
        <Card title={<><TrendingUp className="w-4 h-4 text-indigo-500" /> Last 7 days</>}>
          <div className="flex items-end gap-2 h-40 px-1">
            {(stats?.daily || []).map(d => (
              <div key={d.date} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex items-end justify-center gap-0.5 h-32">
                  <div className="w-1/3 rounded-t bg-indigo-500/80" style={{ height: `${(d.inbound / maxDaily) * 100}%` }} title={`${d.inbound} inbound`} />
                  <div className="w-1/3 rounded-t bg-emerald-500/70" style={{ height: `${(d.outbound / maxDaily) * 100}%` }} title={`${d.outbound} outbound`} />
                </div>
                <span className="text-[10px] text-slate-400">{d.date.slice(5)}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-4 text-[11px] text-slate-500 mt-2">
            <span className="flex items-center gap-1"><i className="w-2.5 h-2.5 rounded-sm bg-indigo-500/80 inline-block" /> Inbound</span>
            <span className="flex items-center gap-1"><i className="w-2.5 h-2.5 rounded-sm bg-emerald-500/70 inline-block" /> Outbound</span>
          </div>
        </Card>

        {/* ── Approval funnel ── */}
        <Card title={<><Clock className="w-4 h-4 text-amber-500" /> Approval funnel</>}>
          {stats ? (
            <div className="space-y-2.5 text-sm">
              <FunnelRow label="Received" value={stats.totals.inbound} total={stats.totals.inbound} color="bg-slate-400" />
              <FunnelRow label="Waiting approval" value={stats.totals.pending} total={stats.totals.inbound} color="bg-amber-500" />
              <FunnelRow label="Approved → transactions" value={stats.totals.approved} total={stats.totals.inbound} color="bg-emerald-500" />
              <FunnelRow label="Rejected (kept in audit)" value={stats.totals.rejected} total={stats.totals.inbound} color="bg-red-500" />
              <div className="pt-1 text-xs text-slate-500 flex items-center gap-3">
                <span className="flex items-center gap-1"><Timer className="w-3.5 h-3.5" /> Avg reply {stats.latency ? `${stats.latency.avgMs < 1000 ? `${stats.latency.avgMs} ms` : `${(stats.latency.avgMs / 1000).toFixed(1)} s`}` : '—'}</span>
                {stats.totals.failedOutbound > 0 && (
                  <button onClick={() => nav('wa-messages')} className="text-red-600 underline">{stats.totals.failedOutbound} failed reply(ies) — retry</button>
                )}
              </div>
            </div>
          ) : <Empty />}
        </Card>

        {/* ── Top customers ── */}
        <Card title={<><Users className="w-4 h-4 text-indigo-500" /> Most active customers (30d)</>}>
          {(stats?.topCustomers?.length || 0) === 0 ? <Empty text="No customer messages yet." /> : (
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b border-slate-200 text-[10px] uppercase tracking-wider text-slate-400">
                  <th className="text-left px-2 py-1.5">Customer</th>
                  <th className="text-left px-2 py-1.5">Agent</th>
                  <th className="text-right px-2 py-1.5">In</th>
                  <th className="text-right px-2 py-1.5">Out</th>
                </tr>
              </thead>
              <tbody>
                {(stats?.topCustomers || []).map(c => (
                  <tr key={c.key} className="border-b border-slate-100">
                    <td className="px-2 py-1.5 font-medium text-slate-700">{c.name}</td>
                    <td className="px-2 py-1.5 text-slate-500">{c.agentName || '—'}</td>
                    <td className="px-2 py-1.5 text-right text-indigo-600">{c.inbound}</td>
                    <td className="px-2 py-1.5 text-right text-emerald-600">{c.outbound}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>

        {/* ── Bot evolution + unknown labels ── */}
        <Card title={<><GraduationCap className="w-4 h-4 text-violet-500" /> Bot evolution</>}>
          {stats ? (
            <div className="text-sm space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="rounded-full px-2 py-0.5 text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200">Parser v{stats.parserVersion}</span>
                <span className="text-xs text-slate-500">{stats.learning.applied} rule(s) activated · {stats.learning.open} open candidate(s) · {stats.learning.dismissed} dismissed</span>
              </div>
              {stats.learning.recentActivations.length > 0 && (
                <div className="text-xs text-slate-600 space-y-1">
                  {stats.learning.recentActivations.map((a, i) => (
                    <div key={i}>• <b className="font-mono">{a.term}</b>{a.category ? ` → ${a.category}` : ''} <span className="text-slate-400">· {fmtTime(a.at)}</span></div>
                  ))}
                </div>
              )}
              <div>
                <div className="text-xs font-medium text-slate-500 mb-1">What the bot could not read (teach it)</div>
                {(stats.unknownLabels?.length || 0) === 0 ? (
                  <div className="text-xs text-slate-400">No unread patterns — everything parses.</div>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {stats.unknownLabels.map(u => (
                      <button key={u.label} onClick={() => nav('wa-learning')}
                        className="rounded border border-amber-200 bg-amber-50 px-2 py-0.5 text-[11px] text-amber-800 hover:bg-amber-100">
                        {u.label} ×{u.count}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : <Empty />}
        </Card>
      </div>

      {/* ── Optimization suggestions ── */}
      <div className="mt-5 rounded-xl border border-slate-200 bg-white shadow-sm p-4">
        <div className="text-sm font-semibold text-slate-700 flex items-center gap-2 mb-2">
          <Lightbulb className="w-4 h-4 text-amber-500" /> Optimization suggestions
        </div>
        <div className="space-y-1.5">
          {(stats?.suggestions || []).map((s, i) => (
            <div key={i} className={`text-sm rounded-md px-3 py-2 ${s.severity === 'warn' ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-slate-50 text-slate-600 border border-slate-100'} flex items-center justify-between gap-2`}>
              <span>{s.text}</span>
              {s.page && <button onClick={() => nav(s.page!)} className="text-xs text-indigo-600 underline whitespace-nowrap">Open</button>}
            </div>
          ))}
        </div>
      </div>

      {status && <ChannelCard status={status} approvalMode={stats?.approvalMode || 'on'} parserVersion={stats?.parserVersion ?? 1} />}

      <SimulatorCard onDone={load} />
    </div>
  )
}

// ── Channel configuration (shared with the old inbox page) ──
export function ChannelCard({ status, approvalMode, parserVersion }: {
  status: WaStatus
  approvalMode: 'on' | 'off'
  parserVersion: number
}) {
  return (
    <div className="mt-5 rounded-xl border border-slate-200 bg-white shadow-sm p-4 text-sm">
      <div className="flex items-center gap-2 mb-2 font-semibold text-slate-700 flex-wrap">
        <Info className="w-4 h-4 text-indigo-500" /> WhatsApp Cloud API
        <span className={`ml-2 rounded-full px-2 py-0.5 text-xs font-medium ${status.mode === 'live'
          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
          : 'bg-sky-50 text-sky-700 border border-sky-200'}`}>
          {status.mode === 'live' ? 'LIVE — replies sent via Meta' : 'SANDBOX — replies generated, not sent'}
        </span>
        <span className={`ml-1 rounded-full px-2 py-0.5 text-xs font-medium ${approvalMode === 'on'
          ? 'bg-amber-50 text-amber-700 border border-amber-200'
          : 'bg-slate-100 text-slate-600 border border-slate-200'}`}>
          {approvalMode === 'on' ? 'Approval mode ON — vyapar needs Admin Manager approval' : 'Approval mode OFF — legacy auto-transactions'}
        </span>
        <span className="ml-1 rounded-full px-2 py-0.5 text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200">
          Parser v{parserVersion}
        </span>
      </div>
      <div className="text-slate-600 space-y-1">
        <div>Webhook callback URL for the Meta dashboard: <code className="rounded bg-slate-100 px-1.5 py-0.5">{typeof window !== 'undefined' ? `${window.location.origin}${status.webhookPath}` : status.webhookPath}</code></div>
        <div className="text-xs text-slate-500">
          .env keys: WHATSAPP_VERIFY_TOKEN {status.verifyTokenSet ? '✓' : '(default: matka-erp-verify)'} ·
          WHATSAPP_TOKEN {status.tokenSet ? '✓' : '— not set'} ·
          WHATSAPP_PHONE_NUMBER_ID {status.phoneNumberIdSet ? '✓' : '— not set'} ·
          WHATSAPP_APP_SECRET {status.signatureCheck ? '✓ (signature check on)' : '(optional)'}
        </div>
      </div>
    </div>
  )
}

// ── Sandbox simulator (moved here from the old inbox) ──
function SimulatorCard({ onDone }: { onDone: () => void }) {
  const [phone, setPhone] = useState('')
  const [name, setName] = useState('')
  const [text, setText] = useState('')
  const [groupId, setGroupId] = useState('')
  const [forwarded, setForwarded] = useState('')
  const [busy, setBusy] = useState(false)
  const [reply, setReply] = useState('')
  const [error, setError] = useState('')

  const simulate = async () => {
    setError(''); setReply('')
    if (!phone.trim() || !text.trim()) { setError('Phone and message text are required.'); return }
    setBusy(true)
    try {
      const res = await apiFetch('/api/whatsapp/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phone.trim(), name: name.trim(), text, groupId: groupId.trim(), forwardedFrom: forwarded.trim() }),
      })
      if (res?.error) setError(res.error)
      else { setReply(res.reply || ''); onDone() }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Simulation failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mt-5 bg-white rounded-xl border border-slate-200 shadow-sm p-4">
      <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2 mb-1">
        <CircleCheck className="w-4 h-4 text-emerald-500" /> Simulate an incoming message
      </h3>
      <p className="text-xs text-slate-500 mb-3">Runs the exact pipeline the webhook runs — raw store, group/forward resolution, parse, approval queue.</p>
      <div className="grid grid-cols-2 gap-2 mb-2">
        <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Sender WhatsApp no."
          className="h-9 rounded-md border border-slate-300 px-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Profile name (optional)"
          className="h-9 rounded-md border border-slate-300 px-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
        <input value={groupId} onChange={e => setGroupId(e.target.value)} placeholder="Group ID (optional — group flow)"
          className="h-9 rounded-md border border-slate-300 px-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
        <input value={forwarded} onChange={e => setForwarded(e.target.value)} placeholder="Forwarded: original sender no. (optional)"
          className="h-9 rounded-md border border-slate-300 px-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
      </div>
      <textarea value={text} onChange={e => setText(e.target.value)} rows={4} spellCheck={false}
        placeholder={'Milan open motor\n23457890,100\n12345678,100'}
        className="w-full rounded-md border border-slate-300 px-2.5 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500" />
      {error && <div className="text-xs text-red-600 mt-2">{error}</div>}
      {reply && (
        <div className="mt-2">
          <div className="text-xs font-medium text-emerald-700 mb-1">Reply the chat would receive:</div>
          <pre className="whitespace-pre-wrap text-xs text-slate-700 bg-emerald-50 rounded-md p-3">{reply}</pre>
        </div>
      )}
      <button onClick={simulate} disabled={busy}
        className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-md bg-emerald-600 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-60">
        <Send className={`w-4 h-4 ${busy ? 'animate-pulse' : ''}`} />
        {busy ? 'Processing…' : 'Run through pipeline'}
      </button>
    </div>
  )
}

// ── Small building blocks ──

function Card({ title, children }: { title: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
      <div className="text-sm font-semibold text-slate-700 flex items-center gap-2 mb-3">{title}</div>
      {children}
    </div>
  )
}

function Kpi({ label, value, tone, onClick }: {
  label: string
  value: React.ReactNode
  tone: 'indigo' | 'emerald' | 'amber' | 'red' | 'violet'
  onClick?: () => void
}) {
  const tones: Record<string, string> = {
    indigo: 'border-indigo-100 bg-indigo-50/50 text-indigo-700',
    emerald: 'border-emerald-100 bg-emerald-50/50 text-emerald-700',
    amber: 'border-amber-200 bg-amber-50/60 text-amber-700',
    red: 'border-red-100 bg-red-50/50 text-red-700',
    violet: 'border-violet-100 bg-violet-50/50 text-violet-700',
  }
  return (
    <button onClick={onClick} disabled={!onClick}
      className={`rounded-xl border p-3 text-left ${tones[tone]} ${onClick ? 'hover:shadow-sm cursor-pointer' : 'cursor-default'}`}>
      <div className="text-[11px] font-medium uppercase tracking-wide opacity-75">{label}</div>
      <div className="text-xl font-bold mt-0.5">{value}</div>
    </button>
  )
}

function FunnelRow({ label, value, total, color }: { label: string; value: number; total: number; color: string }) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0
  return (
    <div>
      <div className="flex justify-between text-xs text-slate-600 mb-0.5">
        <span>{label}</span><span className="font-semibold">{value} ({pct}%)</span>
      </div>
      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

function Empty({ text }: { text?: string }) {
  return <div className="p-6 text-center text-sm text-slate-400">{text || 'No data yet.'}</div>
}
