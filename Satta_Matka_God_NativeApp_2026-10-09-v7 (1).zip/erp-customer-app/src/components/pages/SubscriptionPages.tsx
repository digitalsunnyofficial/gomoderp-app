'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { formatDate, formatDateTime, formatCurrency } from '@/lib/format'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, BlueButton, Pagination, Modal } from '@/components/shared-ui'
import {
  CreditCard, Wallet, Crown, Check, X, Search, RefreshCw,
  CalendarDays, DollarSign, Zap, AlertTriangle, CheckCircle2,
  Clock, LogOut, Plus, Pencil, Lock, Unlock, Trash2,
  Eye, UserCircle, Settings, RotateCcw
} from 'lucide-react'

export function PaywallPage() {
  const { currentUser, logout } = useAppStore()
  const [plans, setPlans] = useState<any[]>([])
  const [subCheck, setSubCheck] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      apiFetch('/api/subscription-plans'),
      apiFetch('/api/user-subscriptions/check'),
    ]).then(([plansData, checkData]) => {
      setPlans(plansData.filter((p: any) => p.isActive))
      setSubCheck(checkData)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-[#3730A3] font-cinzel text-lg">Checking subscription...</div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#D97706] to-[#92400E] flex items-center justify-center mx-auto mb-4">
          <Crown className="text-white" size={32} />
        </div>
        <h1 className="text-2xl font-bold text-[#111827] mb-2">Subscription Required</h1>
        <p className="text-[#6B7280]">
          {subCheck?.status === 'expired'
            ? `Your ${subCheck?.planName || 'subscription'} has expired. Renew to continue using Hisab System.`
            : subCheck?.status === 'no_subscription'
            ? 'You need an active subscription to access Hisab System.'
            : `Your trial has ${subCheck?.daysRemaining || 0} days remaining. Upgrade now to continue after trial ends.`}
        </p>
        {subCheck?.daysRemaining > 0 && (
          <div className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[rgba(217,119,6,0.1)] text-[#D97706] text-sm font-semibold">
            <Clock size={16} /> {subCheck.daysRemaining} days remaining on {subCheck.planName}
          </div>
        )}
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {plans.map((plan: any) => {
          const isTrial = plan.name === 'trial'
          const features = plan.features ? JSON.parse(plan.features) : []
          return (
            <div
              key={plan.id}
              className={`rounded-xl border p-5 transition-all hover:shadow-lg ${
                isTrial
                  ? 'border-[#E5E7EB] bg-[#FFFFFF]'
                  : 'border-[rgba(55,48,163,0.2)] bg-gradient-to-br from-[#FFFFFF] to-[#EEF2FF]'
              }`}
            >
              <div className="text-center mb-4">
                <h3 className="text-lg font-bold text-[#111827]">{plan.label}</h3>
                <div className="mt-2">
                  <span className="text-3xl font-black text-[#3730A3]">
                    {plan.price === 0 ? 'FREE' : `₹${plan.price.toLocaleString('en-IN')}`}
                  </span>
                  {plan.price > 0 && (
                    <span className="text-sm text-[#6B7280]">
                      /{plan.durationDays === 30 ? 'month' : plan.durationDays === 90 ? '3 months' : plan.durationDays === 180 ? '6 months' : 'year'}
                    </span>
                  )}
                </div>
                <div className="text-xs text-[#9CA3AF] mt-1">{plan.durationDays} days access</div>
              </div>
              {features.length > 0 && (
                <ul className="space-y-2 mb-4">
                  {features.map((f: string, i: number) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-[#374151]">
                      <CheckCircle2 size={14} className="text-[#059669] shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
              )}
              <button
                className="w-full py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer bg-[#3730A3] text-[#FFFFFF] hover:bg-[#4F46E5]"
                onClick={() => alert('Please contact your administrator to activate this plan.')}
              >
                Contact Admin
              </button>
            </div>
          )
        })}
      </div>

      {/* Contact Section */}
      <div className="rounded-xl border border-[#E5E7EB] bg-[#FFFFFF] p-6 text-center">
        <h3 className="text-lg font-bold text-[#111827] mb-2">Need Help?</h3>
        <p className="text-[#6B7280] mb-4">Contact your administrator to activate or renew your subscription.</p>
        <div className="flex items-center justify-center gap-4">
          <button onClick={logout} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-[#6B7280] hover:text-[#111827] transition-colors cursor-pointer">
            <LogOut size={16} /> Log Out
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Mobile Paywall Page ──
export function MobilePaywallPage() {
  const { currentUser, logout } = useAppStore()
  const [plans, setPlans] = useState<any[]>([])
  const [subCheck, setSubCheck] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      apiFetch('/api/subscription-plans'),
      apiFetch('/api/user-subscriptions/check'),
    ]).then(([plansData, checkData]) => {
      setPlans(plansData.filter((p: any) => p.isActive))
      setSubCheck(checkData)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  if (loading) {
    return <div className="flex-1 flex items-center justify-center"><div className="text-[#3730A3] font-cinzel">Checking...</div></div>
  }

  return (
    <div className="flex-1 overflow-y-auto pb-20 px-4 pt-4">
      <div className="text-center mb-6">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#D97706] to-[#92400E] flex items-center justify-center mx-auto mb-3">
          <Crown className="text-white" size={28} />
        </div>
        <h1 className="text-xl font-bold text-[#111827] mb-1">Subscription Required</h1>
        {subCheck?.daysRemaining > 0 && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[rgba(217,119,6,0.1)] text-[#D97706] text-xs font-semibold">
            <Clock size={14} /> {subCheck.daysRemaining} days left
          </div>
        )}
      </div>
      <div className="space-y-3">
        {plans.map((plan: any) => (
          <div key={plan.id} className="rounded-xl border border-[rgba(55,48,163,0.15)] bg-[#FFFFFF] p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-[#111827]">{plan.label}</h3>
              <span className="text-lg font-black text-[#3730A3]">
                {plan.price === 0 ? 'FREE' : `₹${plan.price.toLocaleString('en-IN')}`}
              </span>
            </div>
            <div className="text-xs text-[#9CA3AF] mb-3">{plan.durationDays} days access</div>
            <button
              className="w-full py-2 rounded-lg text-sm font-semibold bg-[#3730A3] text-[#FFFFFF] cursor-pointer"
              onClick={() => alert('Contact your administrator to activate this plan.')}
            >
              Contact Admin
            </button>
          </div>
        ))}
      </div>
      <div className="mt-4 text-center">
        <button onClick={logout} className="text-sm text-[#6B7280] underline cursor-pointer">Log Out</button>
      </div>
    </div>
  )
}

// ── Subscription Plans Management Page (Admin) ──
export function SubscriptionPlansPage() {
  const [plans, setPlans] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingPlan, setEditingPlan] = useState<any>(null)
  const [form, setForm] = useState({ name: '', label: '', durationDays: 30, price: 0, features: '' })

  const loadPlans = useCallback(() => {
    apiFetch('/api/subscription-plans').then((data: any[]) => {
      setPlans(data)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  useEffect(() => { loadPlans() }, [loadPlans])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const payload = {
      ...form,
      durationDays: Number(form.durationDays),
      price: Number(form.price),
      features: form.features ? form.features.split('\n').filter(Boolean) : [],
    }
    try {
      if (editingPlan) {
        await apiFetch(`/api/subscription-plans/${editingPlan.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        })
      } else {
        await apiFetch('/api/subscription-plans', {
          method: 'POST',
          body: JSON.stringify(payload),
        })
      }
      setShowForm(false)
      setEditingPlan(null)
      setForm({ name: '', label: '', durationDays: 30, price: 0, features: '' })
      loadPlans()
    } catch (err: any) {
      alert(err.message || 'Failed to save plan')
    }
  }

  const handleEdit = (plan: any) => {
    setEditingPlan(plan)
    const features = plan.features ? JSON.parse(plan.features) : []
    setForm({
      name: plan.name,
      label: plan.label,
      durationDays: plan.durationDays,
      price: plan.price,
      features: features.join('\n'),
    })
    setShowForm(true)
  }

  const handleToggle = async (plan: any) => {
    try {
      await apiFetch(`/api/subscription-plans/${plan.id}`, {
        method: 'PUT',
        body: JSON.stringify({ isActive: !plan.isActive }),
      })
      loadPlans()
    } catch (err: any) {
      alert(err.message || 'Failed to update plan')
    }
  }

  const handleDelete = async (plan: any) => {
    if (!confirm(`Delete plan "${plan.label}"?`)) return
    try {
      await apiFetch(`/api/subscription-plans/${plan.id}`, { method: 'DELETE' })
      loadPlans()
    } catch (err: any) {
      alert(err.message || 'Failed to delete plan')
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="text-[#3730A3] font-cinzel text-lg">Loading plans...</div></div>
  }

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#111827]">Subscription Plans</h1>
          <p className="text-sm text-[#6B7280]">Manage pricing and plan options</p>
        </div>
        <button
          onClick={() => { setShowForm(true); setEditingPlan(null); setForm({ name: '', label: '', durationDays: 30, price: 0, features: '' }) }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] transition-colors cursor-pointer"
        >
          <Plus size={16} /> Add Plan
        </button>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-[#FFFFFF] rounded-xl shadow-xl w-full max-w-md mx-4 p-6">
            <h2 className="text-lg font-bold text-[#111827] mb-4">{editingPlan ? 'Edit Plan' : 'New Plan'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">Plan Name (unique key)</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" placeholder="e.g. monthly" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">Display Label</label>
                <input value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" placeholder="e.g. Monthly" required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#374151] mb-1">Duration (days)</label>
                  <input type="number" value={form.durationDays} onChange={e => setForm(f => ({ ...f, durationDays: Number(e.target.value) }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#374151] mb-1">Price (₹)</label>
                  <input type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: Number(e.target.value) }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" required />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">Features (one per line)</label>
                <textarea value={form.features} onChange={e => setForm(f => ({ ...f, features: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" rows={4} placeholder="Feature 1&#10;Feature 2&#10;Feature 3" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="flex-1 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] cursor-pointer">
                  {editingPlan ? 'Update Plan' : 'Create Plan'}
                </button>
                <button type="button" onClick={() => { setShowForm(false); setEditingPlan(null) }} className="flex-1 py-2.5 rounded-lg border border-[#E5E7EB] text-[#374151] text-sm font-semibold hover:bg-[#F9FAFB] cursor-pointer">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Plans Table */}
      <div className="bg-[#FFFFFF] rounded-xl border border-[#E5E7EB] overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
              <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Plan</th>
              <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Duration</th>
              <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Price</th>
              <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Status</th>
              <th className="text-right px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody>
            {plans.map((plan: any) => (
              <tr key={plan.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA]">
                <td className="px-4 py-3">
                  <div className="font-semibold text-[#111827] text-sm">{plan.label}</div>
                  <div className="text-xs text-[#9CA3AF]">{plan.name}</div>
                </td>
                <td className="px-4 py-3 text-sm text-[#374151]">{plan.durationDays} days</td>
                <td className="px-4 py-3 text-sm font-semibold text-[#3730A3]">
                  {plan.price === 0 ? 'FREE' : `₹${plan.price.toLocaleString('en-IN')}`}
                </td>
                <td className="px-4 py-3">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${plan.isActive ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current" />
                    {plan.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-2">
                    <button onClick={() => handleEdit(plan)} className="p-1.5 rounded-lg hover:bg-[#EEF2FF] text-[#3730A3] cursor-pointer" title="Edit"><Pencil size={14} /></button>
                    <button onClick={() => handleToggle(plan)} className="p-1.5 rounded-lg hover:bg-[#EEF2FF] text-[#3730A3] cursor-pointer" title={plan.isActive ? 'Disable' : 'Enable'}>
                      {plan.isActive ? <Lock size={14} /> : <Unlock size={14} />}
                    </button>
                    <button onClick={() => handleDelete(plan)} className="p-1.5 rounded-lg hover:bg-[rgba(220,38,38,0.1)] text-[#DC2626] cursor-pointer" title="Delete"><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {plans.length === 0 && (
          <div className="text-center py-8 text-[#9CA3AF] text-sm">No plans found. Create your first plan.</div>
        )}
      </div>
    </div>
  )
}

// ── User Subscriptions Management Page (Admin) ──
export function UserSubscriptionsPage() {
  const [subscriptions, setSubscriptions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showActivate, setShowActivate] = useState(false)
  const [plans, setPlans] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [actForm, setActForm] = useState({ userId: '', planId: '', paymentMethod: 'cash', amountPaid: 0 })
  const [extendSub, setExtendSub] = useState<any>(null)
  const [extendDays, setExtendDays] = useState(30)

  const loadData = useCallback(() => {
    Promise.all([
      apiFetch('/api/user-subscriptions'),
      apiFetch('/api/subscription-plans'),
      apiFetch('/api/users'),
    ]).then(([subsData, plansData, usersData]) => {
      setSubscriptions(subsData)
      setPlans(plansData.filter((p: any) => p.isActive && p.price > 0))
      setUsers(usersData.filter((u: any) => u.role !== 'super'))
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiFetch('/api/user-subscriptions', {
        method: 'POST',
        body: JSON.stringify(actForm),
      })
      setShowActivate(false)
      setActForm({ userId: '', planId: '', paymentMethod: 'cash', amountPaid: 0 })
      loadData()
    } catch (err: any) {
      alert(err.message || 'Failed to activate subscription')
    }
  }

  const handleExtend = async () => {
    if (!extendSub) return
    try {
      await apiFetch(`/api/user-subscriptions/${extendSub.id}`, {
        method: 'PUT',
        body: JSON.stringify({ extendDays, status: 'active' }),
      })
      setExtendSub(null)
      setExtendDays(30)
      loadData()
    } catch (err: any) {
      alert(err.message || 'Failed to extend subscription')
    }
  }

  const handleCancel = async (sub: any) => {
    if (!confirm(`Cancel subscription for ${sub.user?.name || sub.user?.username}?`)) return
    try {
      await apiFetch(`/api/user-subscriptions/${sub.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status: 'cancelled' }),
      })
      loadData()
    } catch (err: any) {
      alert(err.message || 'Failed to cancel subscription')
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="text-[#3730A3] font-cinzel text-lg">Loading subscriptions...</div></div>
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#111827]">User Subscriptions</h1>
          <p className="text-sm text-[#6B7280]">Manage user subscription access</p>
        </div>
        <button
          onClick={() => setShowActivate(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] transition-colors cursor-pointer"
        >
          <Plus size={16} /> Activate Subscription
        </button>
      </div>

      {/* Activate Modal */}
      {showActivate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-[#FFFFFF] rounded-xl shadow-xl w-full max-w-md mx-4 p-6">
            <h2 className="text-lg font-bold text-[#111827] mb-4">Activate Subscription</h2>
            <form onSubmit={handleActivate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">User</label>
                <select value={actForm.userId} onChange={e => setActForm(f => ({ ...f, userId: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" required>
                  <option value="">Select user...</option>
                  {users.map((u: any) => <option key={u.id} value={u.id}>{u.name || u.username}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">Plan</label>
                <select value={actForm.planId} onChange={e => {
                  const plan = plans.find((p: any) => p.id === e.target.value)
                  setActForm(f => ({ ...f, planId: e.target.value, amountPaid: plan?.price || 0 }))
                }} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" required>
                  <option value="">Select plan...</option>
                  {plans.map((p: any) => <option key={p.id} value={p.id}>{p.label} — ₹{p.price.toLocaleString('en-IN')}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#374151] mb-1">Payment Method</label>
                  <select value={actForm.paymentMethod} onChange={e => setActForm(f => ({ ...f, paymentMethod: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm">
                    <option value="cash">Cash</option>
                    <option value="upi">UPI</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="online">Online</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#374151] mb-1">Amount Paid (₹)</label>
                  <input type="number" value={actForm.amountPaid} onChange={e => setActForm(f => ({ ...f, amountPaid: Number(e.target.value) }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" />
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="flex-1 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] cursor-pointer">Activate</button>
                <button type="button" onClick={() => setShowActivate(false)} className="flex-1 py-2.5 rounded-lg border border-[#E5E7EB] text-[#374151] text-sm font-semibold hover:bg-[#F9FAFB] cursor-pointer">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Extend Modal */}
      {extendSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-[#FFFFFF] rounded-xl shadow-xl w-full max-w-sm mx-4 p-6">
            <h2 className="text-lg font-bold text-[#111827] mb-4">Extend Subscription</h2>
            <p className="text-sm text-[#6B7280] mb-4">
              Extend for <strong>{extendSub.user?.name || extendSub.user?.username}</strong> (currently: {extendSub.plan?.label})
            </p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-[#374151] mb-1">Days to extend</label>
              <input type="number" value={extendDays} onChange={e => setExtendDays(Number(e.target.value))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" min={1} />
            </div>
            <div className="flex gap-3">
              <button onClick={handleExtend} className="flex-1 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] cursor-pointer">Extend</button>
              <button onClick={() => setExtendSub(null)} className="flex-1 py-2.5 rounded-lg border border-[#E5E7EB] text-[#374151] text-sm font-semibold hover:bg-[#F9FAFB] cursor-pointer">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Subscriptions Table */}
      <div className="bg-[#FFFFFF] rounded-xl border border-[#E5E7EB] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">User</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Plan</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Start</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">End</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Status</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Payment</th>
                <th className="text-right px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {subscriptions.map((sub: any) => {
                const isActive = sub.status === 'active' && new Date(sub.endDate) > new Date()
                const daysLeft = Math.max(0, Math.ceil((new Date(sub.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
                return (
                  <tr key={sub.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA]">
                    <td className="px-4 py-3">
                      <div className="font-semibold text-[#111827] text-sm">{sub.user?.name || sub.user?.username}</div>
                      <div className="text-xs text-[#9CA3AF]">{sub.user?.username}</div>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#374151]">{sub.plan?.label}</td>
                    <td className="px-4 py-3 text-sm text-[#374151]">{formatDate(sub.startDate)}</td>
                    <td className="px-4 py-3">
                      <div className="text-sm text-[#374151]">{formatDate(sub.endDate)}</div>
                      {isActive && <div className="text-xs text-[#059669]">{daysLeft}d left</div>}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                        sub.status === 'active' ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' :
                        sub.status === 'expired' ? 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]' :
                        sub.status === 'cancelled' ? 'bg-[rgba(107,114,128,0.1)] text-[#6B7280]' :
                        'bg-[rgba(217,119,6,0.1)] text-[#D97706]'
                      }`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current" />
                        {sub.status.charAt(0).toUpperCase() + sub.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-semibold ${
                        sub.paymentStatus === 'completed' ? 'text-[#059669]' :
                        sub.paymentStatus === 'failed' ? 'text-[#DC2626]' :
                        sub.paymentStatus === 'refunded' ? 'text-[#D97706]' :
                        'text-[#9CA3AF]'
                      }`}>
                        {sub.paymentStatus.charAt(0).toUpperCase() + sub.paymentStatus.slice(1)}
                      </span>
                      {sub.amountPaid > 0 && <div className="text-xs text-[#9CA3AF]">₹{sub.amountPaid.toLocaleString('en-IN')}</div>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => setExtendSub(sub)} className="p-1.5 rounded-lg hover:bg-[#EEF2FF] text-[#3730A3] cursor-pointer" title="Extend"><CalendarDays size={14} /></button>
                        {sub.status === 'active' && (
                          <button onClick={() => handleCancel(sub)} className="p-1.5 rounded-lg hover:bg-[rgba(220,38,38,0.1)] text-[#DC2626] cursor-pointer" title="Cancel"><X size={14} /></button>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        {subscriptions.length === 0 && (
          <div className="text-center py-8 text-[#9CA3AF] text-sm">No subscriptions found.</div>
        )}
      </div>
    </div>
  )
}

// ── Payments Management Page (Admin) ──
export function PaymentsPage() {
  const [payments, setPayments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showRecord, setShowRecord] = useState(false)
  const [subscriptions, setSubscriptions] = useState<any[]>([])
  const [recForm, setRecForm] = useState({ subscriptionId: '', amount: 0, method: 'cash', notes: '' })

  const loadData = useCallback(() => {
    Promise.all([
      apiFetch('/api/payments'),
      apiFetch('/api/user-subscriptions'),
    ]).then(([payData, subsData]) => {
      setPayments(payData)
      setSubscriptions(subsData)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const handleRecord = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiFetch('/api/payments', {
        method: 'POST',
        body: JSON.stringify(recForm),
      })
      setShowRecord(false)
      setRecForm({ subscriptionId: '', amount: 0, method: 'cash', notes: '' })
      loadData()
    } catch (err: any) {
      alert(err.message || 'Failed to record payment')
    }
  }

  const handleStatusUpdate = async (payment: any, status: string) => {
    try {
      await apiFetch(`/api/payments/${payment.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
      })
      loadData()
    } catch (err: any) {
      alert(err.message || 'Failed to update payment')
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="text-[#3730A3] font-cinzel text-lg">Loading payments...</div></div>
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#111827]">Payments</h1>
          <p className="text-sm text-[#6B7280]">View and manage payment records</p>
        </div>
        <button
          onClick={() => setShowRecord(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] transition-colors cursor-pointer"
        >
          <Plus size={16} /> Record Payment
        </button>
      </div>

      {/* Record Payment Modal */}
      {showRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-[#FFFFFF] rounded-xl shadow-xl w-full max-w-md mx-4 p-6">
            <h2 className="text-lg font-bold text-[#111827] mb-4">Record Payment</h2>
            <form onSubmit={handleRecord} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">Subscription</label>
                <select value={recForm.subscriptionId} onChange={e => setRecForm(f => ({ ...f, subscriptionId: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" required>
                  <option value="">Select subscription...</option>
                  {subscriptions.map((s: any) => (
                    <option key={s.id} value={s.id}>{s.user?.name || s.user?.username} — {s.plan?.label}</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#374151] mb-1">Amount (₹)</label>
                  <input type="number" value={recForm.amount} onChange={e => setRecForm(f => ({ ...f, amount: Number(e.target.value) }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#374151] mb-1">Method</label>
                  <select value={recForm.method} onChange={e => setRecForm(f => ({ ...f, method: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm">
                    <option value="cash">Cash</option>
                    <option value="upi">UPI</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="online">Online</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#374151] mb-1">Notes</label>
                <textarea value={recForm.notes} onChange={e => setRecForm(f => ({ ...f, notes: e.target.value }))} className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg text-sm" rows={2} />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="flex-1 py-2.5 rounded-lg bg-[#3730A3] text-[#FFFFFF] text-sm font-semibold hover:bg-[#4F46E5] cursor-pointer">Record</button>
                <button type="button" onClick={() => setShowRecord(false)} className="flex-1 py-2.5 rounded-lg border border-[#E5E7EB] text-[#374151] text-sm font-semibold hover:bg-[#F9FAFB] cursor-pointer">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Payments Table */}
      <div className="bg-[#FFFFFF] rounded-xl border border-[#E5E7EB] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">User</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Plan</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Amount</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Method</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Status</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Receipt</th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Date</th>
                <th className="text-right px-4 py-3 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((pay: any) => (
                <tr key={pay.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA]">
                  <td className="px-4 py-3 text-sm text-[#111827] font-medium">{pay.subscription?.user?.name || pay.subscription?.user?.username}</td>
                  <td className="px-4 py-3 text-sm text-[#374151]">{pay.subscription?.plan?.label}</td>
                  <td className="px-4 py-3 text-sm font-semibold text-[#3730A3]">₹{pay.amount.toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 text-sm text-[#374151] capitalize">{pay.method?.replace('_', ' ')}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                      pay.status === 'completed' ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' :
                      pay.status === 'failed' ? 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]' :
                      pay.status === 'refunded' ? 'bg-[rgba(217,119,6,0.1)] text-[#D97706]' :
                      'bg-[rgba(107,114,128,0.1)] text-[#6B7280]'
                    }`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      {pay.status.charAt(0).toUpperCase() + pay.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-[#9CA3AF] font-mono">{pay.receiptNo || '—'}</td>
                  <td className="px-4 py-3 text-xs text-[#9CA3AF]">{formatDate(pay.createdAt)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      {pay.status === 'pending' && (
                        <button onClick={() => handleStatusUpdate(pay, 'completed')} className="p-1.5 rounded-lg hover:bg-[rgba(5,150,105,0.1)] text-[#059669] cursor-pointer" title="Mark Completed"><Check size={14} /></button>
                      )}
                      {pay.status === 'completed' && (
                        <button onClick={() => handleStatusUpdate(pay, 'refunded')} className="p-1.5 rounded-lg hover:bg-[rgba(217,119,6,0.1)] text-[#D97706] cursor-pointer" title="Refund"><RotateCcw size={14} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {payments.length === 0 && (
          <div className="text-center py-8 text-[#9CA3AF] text-sm">No payments found.</div>
        )}
      </div>
    </div>
  )
}

// ── Landing Page Configuration Page (Admin) ──
// ────────────────────────────────────────
// HIERARCHY PAGES
// ────────────────────────────────────────

