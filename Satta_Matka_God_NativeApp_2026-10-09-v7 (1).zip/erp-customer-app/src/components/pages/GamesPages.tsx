'use client'

// ──────────────────────────────────────────────────────────
// GAME MANAGEMENT (Market Management section)
//   GameManagementPage — the full catalog: category, input
//     basis, session, ERP mapping, default rate, on/off.
//   GameAllocationPage — per-market allocation matrix with
//     rate + min-point overrides. The customer app play
//     screen renders exactly the games allocated here.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import { marketDisplayName } from '@/lib/matka/app-engine'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, Modal } from '@/components/shared-ui'
import { Check, AlertTriangle, RefreshCw, Pencil, Layers, MapPin, ToggleLeft, ToggleRight, IndianRupee } from 'lucide-react'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('success') || message.includes('updated') || message.includes('Saved') || message.includes('saved')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

interface GameRow {
  id: string; code: string; name: string; category: string; base: string
  session: string; erpMapping: string; defaultRate: number
  expansion: string; icon: string; isActive: boolean; sortOrder: number
  marketsAllocated: number
}

const CAT_CHIP: Record<string, string> = {
  digit: 'bg-[#EFF6FF] text-[#1D4ED8]', jodi: 'bg-[#ECFEFF] text-[#0E7490]',
  panna: 'bg-[#F0FDF4] text-[#15803D]', sangam: 'bg-[#FDF2F8] text-[#BE185D]',
  motor: 'bg-[#FEF3C7] text-[#B45309]', family: 'bg-[#F5F3FF] text-[#6D28D9]',
  chart: 'bg-[#FFF7ED] text-[#C2410C]', special: 'bg-[#F8FAFC] text-[#475569]',
}

// ──────────────────────────────────────────────────────────
// GAME MANAGEMENT PAGE
// ──────────────────────────────────────────────────────────
export function GameManagementPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const canEdit = currentUser?.role === 'super'
  const [games, setGames] = useState<GameRow[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [filter, setFilter] = useState('all')
  const [edit, setEdit] = useState<GameRow | null>(null)
  const [rate, setRate] = useState('')

  const load = useCallback(() => {
    apiFetch('/api/app-admin/games')
      .then(d => setGames((d.games as GameRow[]) || []))
      .catch(e => setMessage(e instanceof Error ? e.message : 'Failed to load games'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => { load() }, [load])

  const saveRate = async () => {
    if (!edit) return
    try {
      await apiFetch('/api/app-admin/games', { method: 'PATCH', body: JSON.stringify({ id: edit.id, defaultRate: Number(rate) }) })
      setMessage('Rate updated successfully')
      setEdit(null)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const toggle = async (g: GameRow) => {
    try {
      await apiFetch('/api/app-admin/games', { method: 'PATCH', body: JSON.stringify({ id: g.id, isActive: !g.isActive }) })
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const cats = useMemo(() => Array.from(new Set(games.map(g => g.category))), [games])
  const shown = filter === 'all' ? games : games.filter(g => g.category === filter)

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Game Management</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">
            Every game with its calculation rule and the ERP entry category it feeds — rates are editable and the catalog drives the customer app.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <FormSelect value={filter} onChange={e => setFilter(e.target.value)} className="w-[160px]">
            <option value="all">All categories</option>
            {cats.map(c => <option key={c} value={c}>{c}</option>)}
          </FormSelect>
          <button onClick={load} className="p-1.5 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]"><RefreshCw size={14} /></button>
        </div>
      </div>
      <Msg message={message} />
      <SectionCard title={`Game Catalog (${games.length} games)`}>
        {loading ? <p className="text-[12px] text-[#9CA3AF]">Loading games…</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-left text-[#9CA3AF] border-b border-[#E5E7EB]">
                  <th className="py-2.5 pr-3 font-semibold">Game</th>
                  <th className="py-2.5 pr-3 font-semibold">Category</th>
                  <th className="py-2.5 pr-3 font-semibold">Input</th>
                  <th className="py-2.5 pr-3 font-semibold">Session</th>
                  <th className="py-2.5 pr-3 font-semibold">ERP Mapping</th>
                  <th className="py-2.5 pr-3 font-semibold">Default Rate</th>
                  <th className="py-2.5 pr-3 font-semibold">Allocated</th>
                  <th className="py-2.5 pr-3 font-semibold">Status</th>
                  <th className="py-2.5 font-semibold"></th>
                </tr>
              </thead>
              <tbody>
                {shown.map(g => (
                  <tr key={g.id} className={`border-b border-[#F3F4F6] hover:bg-[#F8FAFC] ${g.isActive ? '' : 'opacity-55'}`}>
                    <td className="py-2.5 pr-3">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-lg bg-[#EFF6FF] text-[#2563EB] grid place-items-center"><Layers size={13} /></span>
                        <b className="text-[#111827]">{g.name}</b>
                        <span className="text-[10px] font-mono text-[#9CA3AF]">{g.code}</span>
                      </div>
                    </td>
                    <td className="py-2.5 pr-3"><span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${CAT_CHIP[g.category] || CAT_CHIP.special}`}>{g.category}</span></td>
                    <td className="py-2.5 pr-3 text-[#374151]">{g.base}</td>
                    <td className="py-2.5 pr-3 text-[#374151] capitalize">{g.session}</td>
                    <td className="py-2.5 pr-3 text-[#374151]">{g.erpMapping || '—'}</td>
                    <td className="py-2.5 pr-3">
                      <span className="inline-flex items-center gap-1 font-mono font-bold text-[#B45309]"><IndianRupee size={11} />1 : {g.defaultRate}</span>
                    </td>
                    <td className="py-2.5 pr-3 text-[#374151]">{g.marketsAllocated} market{g.marketsAllocated === 1 ? '' : 's'}</td>
                    <td className="py-2.5 pr-3">
                      <button onClick={() => canEdit && toggle(g)} className={`inline-flex items-center gap-1 text-[11px] font-bold ${g.isActive ? 'text-[#059669]' : 'text-[#9CA3AF]'}`} disabled={!canEdit}>
                        {g.isActive ? <ToggleRight size={16} /> : <ToggleLeft size={16} />}{g.isActive ? 'Active' : 'Off'}
                      </button>
                    </td>
                    <td className="py-2.5">
                      {canEdit ? (
                        <button onClick={() => { setEdit(g); setRate(String(g.defaultRate)) }} className="text-[11px] font-semibold text-[#2563EB] px-2 py-1 rounded-md hover:bg-[#EFF6FF] inline-flex items-center gap-1"><Pencil size={11} />Rate</button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-[11px] text-[#6B7280] mt-3">
          Expansion rules: Motor generates every arrangement of the picked digit set (SP Motor keeps all-distinct pannas — seed 13467 → 60 pannas),
          Family Sets expand a panna to its family members, and the 50/60/70/90 charts resolve the ank to its chart pannas.
        </p>
      </SectionCard>

      {edit ? (
        <Modal open title={`Default Rate — ${edit.name}`} onClose={() => setEdit(null)}>
          <FormField label="PAYOUT RATE (1 : X)"><FormInput type="number" min={1} step="0.01" value={rate} onChange={e => setRate(e.target.value)} /></FormField>
          <p className="text-[11px] text-[#6B7280] mt-2">Per-market overrides live in Game Allocation and win over this default.</p>
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setEdit(null)}>Cancel</OutlineButton>
            <GoldButton onClick={saveRate}><Check size={14} /> Save Rate</GoldButton>
          </div>
        </Modal>
      ) : null}
    </div>
  )
}

// ──────────────────────────────────────────────────────────
// GAME ALLOCATION PAGE
// ──────────────────────────────────────────────────────────
interface AllocRow { id: string; gameId: string; marketCode: string; rate: number | null; minPoints: number; isActive: boolean }

export function GameAllocationPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const canEdit = currentUser?.role === 'super'
  const [games, setGames] = useState<GameRow[]>([])
  const [markets, setMarkets] = useState<Array<{ code: string; name: string; phase?: string; session?: string; isActive: boolean }>>([])
  const [allocs, setAllocs] = useState<AllocRow[]>([])
  const [market, setMarket] = useState('')
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [alloc, setAlloc] = useState<Record<string, boolean>>({})
  const [rateOv, setRateOv] = useState<Record<string, string>>({})
  const [minPts, setMinPts] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState('')

  const load = useCallback((mk: string) => {
    setLoading(true)
    apiFetch('/api/app-admin/allocation' + (mk ? `?market=${mk}` : ''))
      .then(d => {
        setGames((d.games as GameRow[]) || [])
        setMarkets((d.markets as Array<{ code: string; name: string; phase?: string; session?: string; isActive: boolean }>) || [])
        const rows = (d.allocations as AllocRow[]) || []
        setAllocs(mk ? rows : [])
        if (mk) {
          const a: Record<string, boolean> = {}
          const r: Record<string, string> = {}
          const m: Record<string, string> = {}
          for (const row of rows) {
            a[row.gameId] = row.isActive
            if (row.rate != null) r[row.gameId] = String(row.rate)
            m[row.gameId] = String(row.minPoints)
          }
          setAlloc(a); setRateOv(r); setMinPts(m)
        }
      })
      .catch(e => setMessage(e instanceof Error ? e.message : 'Failed to load allocation'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => { load(market) }, [market, load])

  const saveRow = async (gameId: string) => {
    if (!market) { setMessage('Pick a market first'); return }
    setSaving(gameId)
    try {
      await apiFetch('/api/app-admin/allocation', {
        method: 'POST',
        body: JSON.stringify({
          gameId, marketCode: market,
          isActive: alloc[gameId] ?? false,
          rate: rateOv[gameId] === undefined || rateOv[gameId] === '' ? null : Number(rateOv[gameId]),
          minPoints: minPts[gameId] === undefined || minPts[gameId] === '' ? 10 : Number(minPts[gameId]),
        }),
      })
      setMessage('Allocation saved successfully')
      load(market)
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') } finally { setSaving('') }
  }

  const allocCount = Object.values(alloc).filter(Boolean).length

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Game Allocation</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Choose which games each market offers, with rate &amp; minimum-point overrides — the app play screen follows this instantly.</p>
        </div>
        <div className="flex items-center gap-2">
          <FormSelect value={market} onChange={e => setMarket(e.target.value)} className="w-[240px]">
            <option value="">— Select market —</option>
            {markets.map(m => <option key={m.code} value={m.code}>{marketDisplayName(m)}{m.isActive ? '' : ' (disabled)'}</option>)}
          </FormSelect>
          <button onClick={() => load(market)} className="p-1.5 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]"><RefreshCw size={14} /></button>
        </div>
      </div>
      <Msg message={message} />

      {!market ? (
        <SectionCard title="Pick a market">
          <p className="text-[12px] text-[#9CA3AF]">Select a market above to edit its game allocation. Markets: {markets.length}</p>
        </SectionCard>
      ) : (
        <SectionCard
          title={`Allocation — ${(() => { const mk = markets.find(m => m.code === market); return mk ? marketDisplayName(mk) : market })()}`}
          headerRight={<span className="text-[11px] font-bold text-[#059669]">{allocCount} game{allocCount === 1 ? '' : 's'} enabled</span>}
        >
          {loading ? <p className="text-[12px] text-[#9CA3AF]">Loading…</p> : (
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="text-left text-[#9CA3AF] border-b border-[#E5E7EB]">
                    <th className="py-2.5 pr-3 font-semibold w-10"></th>
                    <th className="py-2.5 pr-3 font-semibold">Game</th>
                    <th className="py-2.5 pr-3 font-semibold">ERP Mapping</th>
                    <th className="py-2.5 pr-3 font-semibold">Rate override (1 : X)</th>
                    <th className="py-2.5 pr-3 font-semibold">Min points</th>
                    <th className="py-2.5 font-semibold"></th>
                  </tr>
                </thead>
                <tbody>
                  {games.filter(g => g.isActive).map(g => {
                    const on = alloc[g.id] ?? false
                    return (
                      <tr key={g.id} className={`border-b border-[#F3F4F6] ${on ? 'bg-[#F0FDF4]/50' : ''}`}>
                        <td className="py-2.5 pr-3">
                          <button
                            onClick={() => canEdit && setAlloc(a => ({ ...a, [g.id]: !on }))}
                            className={`${on ? 'text-[#059669]' : 'text-[#CBD5E1]'}`}
                            disabled={!canEdit} title={on ? 'Allocated — click to remove' : 'Click to allocate'}
                          >
                            {on ? <ToggleRight size={20} /> : <ToggleLeft size={20} />}
                          </button>
                        </td>
                        <td className="py-2.5 pr-3">
                          <div className="flex items-center gap-2">
                            <MapPin size={12} className="text-[#9CA3AF]" />
                            <b className="text-[#111827]">{g.name}</b>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${CAT_CHIP[g.category] || CAT_CHIP.special}`}>{g.category}</span>
                          </div>
                        </td>
                        <td className="py-2.5 pr-3 text-[#374151]">{g.erpMapping || '—'}</td>
                        <td className="py-2.5 pr-3 w-[170px]">
                          <FormInput type="number" min={1} step="0.01" placeholder={`default ${g.defaultRate}`} disabled={!canEdit || !on}
                            value={rateOv[g.id] ?? ''} onChange={e => setRateOv(r => ({ ...r, [g.id]: e.target.value }))} />
                        </td>
                        <td className="py-2.5 pr-3 w-[130px]">
                          <FormInput type="number" min={1} disabled={!canEdit || !on}
                            value={minPts[g.id] ?? '10'} onChange={e => setMinPts(r => ({ ...r, [g.id]: e.target.value }))} />
                        </td>
                        <td className="py-2.5">
                          {canEdit ? (
                            <GoldButton onClick={() => saveRow(g.id)} disabled={saving === g.id}>
                              <Check size={13} />{saving === g.id ? 'Saving…' : 'Save'}
                            </GoldButton>
                          ) : null}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
          <p className="text-[11px] text-[#6B7280] mt-3">Leave the rate override empty to use the game default. Min points defaults to 10. Changes reflect in the customer app within seconds — no refresh needed. Retired catalogue games (e.g. old Family Sets 4/6/8) are hidden from this matrix.</p>
        </SectionCard>
      )}
    </div>
  )
}
