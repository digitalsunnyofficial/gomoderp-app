'use client'

// ────────────────────────────────────────────────────────────
// WhatsApp Management panel — SHARED foundation.
//
// One data/actions hook (useWhatsAppCore) + shared types + shared
// presentational pieces consumed by the six panel pages:
//   WhatsAppDashboardPage · WhatsAppMessagesPage · WhatsAppTemplatesPage
//   WhatsAppApprovalsPage · WhatsAppLearningPage · WhatsAppMappingsPage
// Reuses the existing WhatsApp APIs verbatim — no behavior change, the
// former six tabs simply became first-class pages of a major panel.
// ────────────────────────────────────────────────────────────

import React, { useState, useEffect, useCallback } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'

// ── Types (mirror the API responses) ──

export interface WaMessage {
  id: string
  direction: 'in' | 'out'
  phone: string
  profileName: string
  body: string
  marketName: string | null
  status: string
  error: string | null
  parseSummary: string
  replyToId: string | null
  groupId?: string | null
  groupLabel?: string | null
  senderPhone?: string | null
  senderName?: string | null
  forwardedFrom?: string | null
  providerTimestamp?: string | null
  parserVersion?: number | null
  approvalId?: string | null
  createdAt: string
  customerName?: string | null
  agentName?: string | null
}

export interface WaApproval {
  id: string
  messageId: string
  groupId: string | null
  senderPhone: string | null
  senderName: string | null
  customerName: string
  agentUsername: string | null
  agentName: string | null
  marketName: string | null
  session: string | null
  rawMessage: string
  parseSummary: string
  total: number
  validationStatus: string
  validationNotes: string
  parserVersion: number
  status: string
  approvedBy: string | null
  approvedAt: string | null
  rejectedBy: string | null
  rejectedAt: string | null
  rejectionReason: string | null
  txId: string | null
  txNumber: number | null
  createdAt: string
  messagePhone: string | null
  messageProfileName: string | null
}

export interface WaTransaction {
  id: string
  txNumber: number
  customerName: string
  agentName: string | null
  agentUsername: string | null
  marketName: string | null
  session: string | null
  total: number
  status: string
  parseSummary: string
  createdAt: string
  _count?: { lines: number }
}

export interface LearningCandidate {
  id: string
  rawInput: string
  context: string | null
  status: string
  reviewedBy: string | null
  reviewedAt: string | null
  source: string
  sampleCount: number
  ruleDefinition: string | null
  testResults: string | null
  activatedTermId: string | null
  createdAt: string
}

export interface GroupMapping {
  id: string
  groupId: string
  groupLabel: string
  customerId: string | null
  vendorId: string | null
  context: string
  isActive: boolean
  note: string | null
  createdBy: string
  createdAt: string
  customerName?: string | null
  customerMobile?: string | null
  vendorName?: string | null
  vendorMobile?: string | null
}

export interface WaStatus {
  mode: 'live' | 'sandbox'
  verifyTokenSet: boolean
  tokenSet: boolean
  phoneNumberIdSet: boolean
  signatureCheck: boolean
  webhookPath: string
}

export interface CustomerOption { id: string; name: string; mobile: string }
export interface VendorOption { id: string; businessName: string; mobileNo: string }

// ── Small helpers ──

export function fmtTime(iso: string | null): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })
}

export function parseJson<T>(raw: string | null | undefined): T | null {
  if (!raw || raw === '{}' || raw === '[]') return null
  try { return JSON.parse(raw) as T } catch { return null }
}

export function StatusChip({ m }: { m: WaMessage }) {
  const map: Record<string, string> = {
    processed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    sent: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    read: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    sandbox: 'bg-sky-50 text-sky-700 border-sky-200',
    received: 'bg-slate-50 text-slate-600 border-slate-200',
    pending_approval: 'bg-amber-50 text-amber-700 border-amber-200',
    rejected: 'bg-red-50 text-red-700 border-red-200',
    failed: 'bg-red-50 text-red-700 border-red-200',
  }
  const label = m.status === 'pending_approval' ? 'PENDING APPROVAL' : m.status.toUpperCase()
  return (
    <span className={`inline-block rounded border px-1.5 py-0.5 text-[10px] font-medium ${map[m.status] || map.received}`}>
      {label}
    </span>
  )
}

export function TxStatusChip({ s }: { s: string }) {
  const map: Record<string, string> = {
    active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    deleted: 'bg-amber-50 text-amber-700 border-amber-200',
  }
  return (
    <span className={`inline-block rounded border px-1.5 py-0.5 text-[10px] font-medium ${map[s] || map.active}`}>
      {s === 'deleted' ? 'DELETED' : 'ACTIVE'}
    </span>
  )
}

export function ApprovalChip({ s }: { s: string }) {
  const map: Record<string, string> = {
    pending: 'bg-amber-50 text-amber-700 border-amber-200',
    approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    rejected: 'bg-red-50 text-red-700 border-red-200',
  }
  return (
    <span className={`inline-block rounded border px-1.5 py-0.5 text-[10px] font-medium ${map[s] || map.pending}`}>
      {s.toUpperCase()}
    </span>
  )
}

/** Compact bucket chips from a parseSummary JSON string. */
export function ParseBuckets({ raw }: { raw: string }) {
  const parsed = parseJson<{ counts?: Record<string, unknown>; unknownLabels?: string[] }>(raw)
  if (!parsed?.counts) return null
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {Object.entries(parsed.counts).map(([k, v]) => {
          if (k === 'groups') return null
          const b = v as { count: number; amount: number }
          return b.count > 0 ? (
            <span key={k} className="rounded bg-indigo-50 border border-indigo-100 px-1.5 py-0.5">{k}: {b.count} = ₹{b.amount}</span>
          ) : null
        })}
        {((parsed.counts.groups as Array<{ option: string; count: number; amount: number }>) || []).map(g => (
          <span key={g.option} className="rounded bg-indigo-50 border border-indigo-100 px-1.5 py-0.5">{g.option}: {g.count} = ₹{g.amount}</span>
        ))}
      </div>
      {(parsed.unknownLabels?.length || 0) > 0 && (
        <div className="mt-1 text-amber-700">Unknown: {parsed.unknownLabels?.join(', ')}</div>
      )}
    </div>
  )
}

/** Section header used by every panel page (title + subtitle + actions). */
export function PanelHeader({ icon, title, subtitle, actions }: {
  icon: React.ReactNode
  title: string
  subtitle: React.ReactNode
  actions?: React.ReactNode
}) {
  return (
    <div className="mb-5 flex items-start justify-between gap-3 flex-wrap">
      <div>
        <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">{icon} {title}</h1>
        <p className="text-sm text-slate-500 mt-1">{subtitle}</p>
      </div>
      {actions}
    </div>
  )
}

export function RefreshButton({ loading, onClick }: { loading: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-600 hover:bg-slate-50">
      <RefreshCwIcon className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
    </button>
  )
}

// Inline refresh icon (avoids a lucide import in every consumer of this helper).
function RefreshCwIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" /><path d="M21 3v5h-5" /><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" /><path d="M8 16H3v5" />
    </svg>
  )
}

// ── The ONE data/actions hook for the panel ──

export function useWhatsAppCore() {
  const [rows, setRows] = useState<WaMessage[]>([])
  const [txs, setTxs] = useState<WaTransaction[]>([])
  const [approvals, setApprovals] = useState<WaApproval[]>([])
  const [approvalMode, setApprovalMode] = useState<'on' | 'off'>('on')
  const [learning, setLearning] = useState<LearningCandidate[]>([])
  const [parserVersion, setParserVersion] = useState(1)
  const [groups, setGroups] = useState<GroupMapping[]>([])
  const [customers, setCustomers] = useState<CustomerOption[]>([])
  const [vendors, setVendors] = useState<VendorOption[]>([])
  const [status, setStatus] = useState<WaStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState('')
  const [banner, setBanner] = useState('')

  // learning review state
  const [termDraft, setTermDraft] = useState<Record<string, string>>({})
  const [categoryDraft, setCategoryDraft] = useState<Record<string, string>>({})
  const [testResult, setTestResult] = useState<Record<string, string>>({})

  // group mapping form state
  const [gmGroupId, setGmGroupId] = useState('')
  const [gmLabel, setGmLabel] = useState('')
  const [gmCustomer, setGmCustomer] = useState('')
  const [gmVendor, setGmVendor] = useState('')
  const [gmNote, setGmNote] = useState('')

  const isSuper = useAppStore(s => s.currentUser?.role === 'super')

  const load = useCallback(() => {
    setLoading(true)
    Promise.all([
      apiFetch('/api/whatsapp/inbox'),
      apiFetch('/api/whatsapp/transactions'),
      apiFetch('/api/whatsapp/status'),
      apiFetch('/api/whatsapp/approvals?status=all'),
      apiFetch('/api/whatsapp/learning'),
      apiFetch('/api/whatsapp/group-mappings'),
      apiFetch('/api/app-admin/customers').catch(() => null),
      apiFetch('/api/vendors').catch(() => []),
    ]).then(([inbox, transactions, st, appr, learn, gm, cust, vnd]) => {
      setRows(Array.isArray(inbox) ? inbox : [])
      setTxs(Array.isArray(transactions) ? transactions : [])
      setStatus(st)
      if (appr?.data) {
        setApprovals(appr.data)
        setApprovalMode(appr.approvalMode === 'off' ? 'off' : 'on')
      }
      if (learn?.data) {
        setLearning(learn.data)
        setParserVersion(learn.parserVersion || 1)
      }
      setGroups(Array.isArray(gm) ? gm : [])
      if (cust?.customers) setCustomers(cust.customers)
      setVendors(Array.isArray(vnd) ? vnd : [])
    }).catch(console.error).finally(() => setLoading(false))
  }, [])

  useEffect(() => { load() }, [load])

  const pending = approvals.filter(a => a.status === 'pending')
  const rejectedIn = rows.filter(r => r.direction === 'in' && r.status === 'rejected')

  const approvalForMessage = (m: WaMessage | null) =>
    m?.approvalId ? approvals.find(a => a.id === m.approvalId) || null : null
  const approvalForTx = (t: WaTransaction | null) =>
    t ? approvals.find(a => a.txNumber === t.txNumber) || null : null

  const decide = async (a: WaApproval, action: 'approve' | 'reject', reason = '') => {
    setBusyId(a.id)
    setBanner('')
    try {
      const res = await apiFetch(`/api/whatsapp/approvals/${a.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, reason }),
      })
      if (res?.error) {
        setBanner(res.error)
      } else {
        setBanner(action === 'approve'
          ? `Approved — Transaction #${res.txNumber} created${res.replyStatus === 'failed' ? ' (reply delivery failed — use Retry)' : ''}.`
          : 'Rejected — the original message and audit record stay intact.')
      }
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Action failed')
    }
    setBusyId('')
  }

  const retry = async (outboundId: string) => {
    setBusyId(outboundId)
    setBanner('')
    try {
      const res = await apiFetch('/api/whatsapp/retry-outbound', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ outboundId }),
      })
      setBanner(res?.error ? res.error : `Reply retry: ${res.status}`)
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Retry failed')
    }
    setBusyId('')
  }

  const learningAction = async (c: LearningCandidate, action: string, extra: Record<string, unknown> = {}) => {
    setBusyId(c.id)
    setBanner('')
    try {
      const res = await apiFetch(`/api/whatsapp/learning/${c.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...extra }),
      })
      if (res?.error) setBanner(res.error)
      else if (action === 'test' && res?.testSummary) {
        setTestResult(t => ({ ...t, [c.id]: `${res.testSummary.matched} of ${res.testSummary.scanned} historical messages would parse with this rule` }))
      } else if (action === 'activate') {
        setBanner(`Rule activated as dictionary term "${res.term?.term}" — parser version is now v${res.parserVersion}.`)
      }
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Action failed')
    }
    setBusyId('')
  }

  const createMapping = async () => {
    setBanner('')
    if (!gmGroupId.trim() || (!gmCustomer && !gmVendor)) {
      setBanner('Group ID and exactly one customer are required.')
      return
    }
    setBusyId('gm')
    try {
      const res = await apiFetch('/api/whatsapp/group-mappings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groupId: gmGroupId.trim(), groupLabel: gmLabel.trim(), customerId: gmCustomer, vendorId: gmVendor, note: gmNote.trim() }),
      })
      if (res?.error) setBanner(res.error)
      else {
        setBanner('Group mapped.')
        setGmGroupId(''); setGmLabel(''); setGmCustomer(''); setGmVendor(''); setGmNote('')
        load()
      }
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Failed to map group')
    }
    setBusyId('')
  }

  const deactivateMapping = async (id: string) => {
    setBusyId(id)
    try {
      await apiFetch(`/api/whatsapp/group-mappings/${id}`, { method: 'DELETE' })
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Failed to deactivate')
    }
    setBusyId('')
  }

  return {
    // data
    rows, txs, approvals, approvalMode, learning, parserVersion, groups, customers, vendors, status,
    loading, busyId, banner, setBanner, isSuper,
    // derived
    pending, rejectedIn, approvalForMessage, approvalForTx,
    // learning state
    termDraft, setTermDraft, categoryDraft, setCategoryDraft, testResult,
    // mapping form state
    gmGroupId, setGmGroupId, gmLabel, setGmLabel, gmCustomer, setGmCustomer, gmVendor, setGmVendor, gmNote, setGmNote,
    // actions
    load, decide, retry, learningAction, createMapping, deactivateMapping,
  }
}

export type WhatsAppCore = ReturnType<typeof useWhatsAppCore>
