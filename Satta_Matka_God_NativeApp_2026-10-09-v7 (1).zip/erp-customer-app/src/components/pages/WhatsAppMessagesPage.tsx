'use client'

// ────────────────────────────────────────────────────────────
// WhatsApp Management panel — PAGE 2: Messages (per customer).
// Left: every conversation (customer / group) with volume + last activity.
// Right: the selected thread in chat order with full message detail,
// parse digest, approval status and failed-reply retry.
// ────────────────────────────────────────────────────────────

import React, { useMemo, useState } from 'react'
import { useAppStore } from '@/lib/store'
import {
  MessageCircle, Send, Search, UserRound, Users, ShieldAlert, RotateCcw,
} from 'lucide-react'
import {
  useWhatsAppCore, PanelHeader, RefreshButton, StatusChip, ApprovalChip,
  ParseBuckets, fmtTime, parseJson, type WaMessage,
} from './WhatsAppPanelShared'

interface Thread {
  key: string
  name: string
  sub: string
  agentName: string | null
  isGroup: boolean
  messages: WaMessage[]
  lastAt: number
}

export function WhatsAppMessagesPage() {
  const core = useWhatsAppCore()
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [threadKey, setThreadKey] = useState<string>('')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<WaMessage | null>(null)

  const threads = useMemo<Thread[]>(() => {
    const map = new Map<string, Thread>()
    for (const m of core.rows) {
      const isGroup = !!m.groupId
      const key = isGroup ? `group:${m.groupId}` : `phone:${m.phone}`
      let t = map.get(key)
      if (!t) {
        t = {
          key,
          name: isGroup ? (m.groupLabel || `Group …${(m.groupId || '').slice(-8)}`) : (m.customerName || m.profileName || m.phone),
          sub: isGroup ? `sender ${m.senderName || m.senderPhone || ''}` : m.phone,
          agentName: m.agentName || null,
          isGroup,
          messages: [],
          lastAt: 0,
        }
        map.set(key, t)
      }
      t.messages.push(m)
      const at = new Date(m.createdAt).getTime()
      if (at > t.lastAt) {
        t.lastAt = at
        // prefer the richest name snapshot seen in the thread
        if (!isGroup && m.customerName) { t.name = m.customerName; t.agentName = m.agentName || t.agentName }
      }
    }
    return [...map.values()].sort((a, b) => b.lastAt - a.lastAt)
  }, [core.rows])

  const filtered = threads.filter(t =>
    !search.trim() ||
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.sub.includes(search))

  const active = filtered.find(t => t.key === threadKey) || filtered[0] || null
  const thread = threads.find(t => t.key === threadKey) || null
  const ordered = thread ? [...thread.messages].sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt)) : []
  const linked = selected
    ? core.rows.find(r => r.id === (selected.replyToId || core.rows.find(x => x.replyToId === selected.id)?.id)) || null
    : null

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PanelHeader
        icon={<MessageCircle className="w-5 h-5 text-emerald-600" />}
        title="Messages"
        subtitle="Every conversation per customer and group — immutable as received, with replies, parse digests and retry for failed deliveries."
        actions={<RefreshButton loading={core.loading} onClick={core.load} />}
      />

      {core.banner && (
        <div className="mb-4 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm text-indigo-700">{core.banner}</div>
      )}

      <div className="grid lg:grid-cols-5 gap-5">
        {/* ── Conversation list ── */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm">
          <div className="p-3 border-b border-slate-100">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search customer / number…"
                className="w-full h-9 rounded-md border border-slate-300 pl-8 pr-2 text-sm" />
            </div>
          </div>
          <div className="divide-y divide-slate-100 max-h-[560px] overflow-y-auto">
            {filtered.length === 0 && (
              <div className="p-8 text-center text-sm text-slate-400">No conversations yet.</div>
            )}
            {filtered.map(t => {
              const inN = t.messages.filter(m => m.direction === 'in').length
              const outN = t.messages.length - inN
              const failed = t.messages.some(m => m.direction === 'out' && m.status === 'failed')
              return (
                <button key={t.key} onClick={() => { setThreadKey(t.key); setSelected(null) }}
                  className={`w-full text-left px-4 py-3 hover:bg-slate-50 ${active?.key === t.key ? 'bg-indigo-50/60' : ''}`}>
                  <div className="flex items-center gap-2">
                    {t.isGroup ? <Users className="w-4 h-4 text-violet-500" /> : <UserRound className="w-4 h-4 text-indigo-500" />}
                    <span className="text-sm font-semibold text-slate-700 truncate">{t.name}</span>
                    {failed && <span className="ml-auto w-2 h-2 rounded-full bg-red-500" title="failed reply" />}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex gap-2">
                    <span>{t.sub}</span>
                    {t.agentName && <span>· Agent {t.agentName}</span>}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {inN} in · {outN} out · last {fmtTime(new Date(t.lastAt).toISOString())}
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        {/* ── Thread + detail ── */}
        <div className="lg:col-span-3 space-y-5">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
            {!thread ? (
              <div className="p-8 text-center text-sm text-slate-400">Pick a conversation to see the full history.</div>
            ) : (
              <>
                <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2 flex-wrap">
                  {thread.isGroup ? <Users className="w-4 h-4 text-violet-500" /> : <UserRound className="w-4 h-4 text-indigo-500" />}
                  <span className="text-sm font-semibold text-slate-700">{thread.name}</span>
                  {thread.agentName && <span className="text-xs text-slate-400">· Agent {thread.agentName}</span>}
                  <span className="text-[11px] text-slate-400 ml-auto">{thread.messages.length} messages</span>
                </div>
                <div className="divide-y divide-slate-100 max-h-[480px] overflow-y-auto">
                  {ordered.map(m => (
                    <button key={m.id} onClick={() => setSelected(m)}
                      className={`w-full text-left px-4 py-3 hover:bg-slate-50 ${selected?.id === m.id ? 'bg-indigo-50/60' : ''}`}>
                      <div className="flex items-center gap-2 flex-wrap">
                        {m.direction === 'in'
                          ? <MessageCircle className="w-4 h-4 text-indigo-500" />
                          : <Send className="w-4 h-4 text-emerald-500" />}
                        <span className="text-xs font-semibold text-slate-500">
                          {m.direction === 'in' ? (thread.isGroup ? (m.senderName || m.senderPhone || 'member') : 'Customer') : 'Bot reply'}
                        </span>
                        {m.direction === 'in' && m.groupId && (
                          <span className="text-[11px] rounded bg-violet-50 border border-violet-200 px-1.5 py-0.5 text-violet-700">
                            {m.groupLabel || 'group'}
                          </span>
                        )}
                        {m.forwardedFrom && (
                          <span className="text-[11px] rounded bg-orange-50 border border-orange-200 px-1.5 py-0.5 text-orange-700">
                            fwd from {m.forwardedFrom}
                          </span>
                        )}
                        <span className="ml-auto flex items-center gap-2">
                          {m.marketName && <span className="text-[11px] text-indigo-500">{m.marketName}</span>}
                          <StatusChip m={m} />
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 mt-1 whitespace-pre-wrap line-clamp-3">{m.body}</div>
                      <div className="text-[11px] text-slate-400 mt-1">{fmtTime(m.createdAt)}{m.providerTimestamp ? ` · provider ${fmtTime(m.providerTimestamp)}` : ''}{m.parserVersion != null && m.direction === 'in' ? ` · parser v${m.parserVersion}` : ''}</div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* ── Message detail (audit) ── */}
          {selected && (() => {
            const appr = core.approvalForMessage(selected)
            const linkedFailed = linked && linked.direction === 'out' && linked.status === 'failed'
            return (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    {selected.direction === 'in' ? 'Incoming message' : 'Reply'}
                    <StatusChip m={selected} />
                  </h3>
                  <button onClick={() => setSelected(null)} className="text-xs text-slate-400">Close</button>
                </div>
                {selected.customerName && (
                  <div className="mb-2 text-xs text-slate-600 flex items-center gap-1.5 flex-wrap">
                    <UserRound className="w-3.5 h-3.5 text-slate-400" />
                    Customer: <b>{selected.customerName}</b>
                    {selected.agentName ? <>— Agent: <b>{selected.agentName}</b></> : null}
                  </div>
                )}
                <div className="mb-2 text-[11px] text-slate-400 space-y-0.5">
                  {selected.groupId && <div>Group: <b className="font-mono text-slate-500">{selected.groupId}</b>{selected.groupLabel ? ` (${selected.groupLabel})` : ''}</div>}
                  {selected.senderPhone && <div>Sender: <b className="text-slate-500">{selected.senderName || selected.senderPhone}</b> {selected.senderPhone}</div>}
                  {selected.forwardedFrom && <div>Forwarded by the pickup team — original sender: <b className="text-slate-500">{selected.forwardedFrom}</b></div>}
                  {selected.direction === 'in' && selected.parserVersion != null && <div>Parser version: <b className="text-slate-500">v{selected.parserVersion}</b></div>}
                </div>
                <pre className="whitespace-pre-wrap text-xs text-slate-700 bg-slate-50 rounded-md p-3 max-h-60 overflow-y-auto">{selected.body}</pre>
                {parseJson<Record<string, unknown>>(selected.parseSummary) && (
                  <div className="mt-2 text-xs text-slate-600">
                    <div className="font-medium mb-1">Smart Entry parse</div>
                    <ParseBuckets raw={selected.parseSummary} />
                    {(parseJson<{ total: number }>(selected.parseSummary)?.total ?? 0) > 0 && (
                      <div className="mt-1 font-semibold text-slate-800">Total: ₹{parseJson<{ total: number }>(selected.parseSummary)?.total}</div>
                    )}
                  </div>
                )}
                {selected.error && (
                  <div className="mt-2 text-xs text-amber-700 flex items-center gap-1"><ShieldAlert className="w-3.5 h-3.5" /> {selected.error}</div>
                )}
                {appr && (
                  <div className="mt-2 text-xs text-slate-600">
                    Approval: <ApprovalChip s={appr.status} />
                    {appr.status === 'approved' && <span className="text-slate-400"> · Transaction #{appr.txNumber} · by {appr.approvedBy}</span>}
                    {appr.status === 'rejected' && <span className="text-slate-400"> · {appr.rejectionReason}</span>}
                  </div>
                )}
                {linked && (
                  <div className="mt-3 border-t border-slate-100 pt-2">
                    <div className="text-xs font-medium text-slate-500 mb-1 flex items-center gap-2">
                      {linked.direction === 'out' ? 'Reply sent back' : 'Customer message'}
                      {linked.direction === 'out' && <StatusChip m={linked} />}
                      {linkedFailed && (
                        <button onClick={() => core.retry(linked.id)} disabled={core.busyId === linked.id}
                          className="inline-flex items-center gap-1 rounded border border-indigo-300 px-2 py-0.5 text-[11px] text-indigo-600 hover:bg-indigo-50 disabled:opacity-50">
                          <RotateCcw className="w-3 h-3" /> Retry reply
                        </button>
                      )}
                    </div>
                    <pre className="whitespace-pre-wrap text-xs text-slate-600 bg-emerald-50/50 rounded-md p-2 max-h-40 overflow-y-auto">{linked.body}</pre>
                  </div>
                )}
              </div>
            )
          })()}
        </div>
      </div>
    </div>
  )
}
