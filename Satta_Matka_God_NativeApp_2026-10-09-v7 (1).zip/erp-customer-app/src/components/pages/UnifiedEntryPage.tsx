'use client'

// ────────────────────────────────────────────────────────────────────────────
// UnifiedEntryPage — "Smart Entry": ONE input → parse → calculate → route
// ────────────────────────────────────────────────────────────────────────────
// ONE raw textarea. The user may optionally prefix a TERM (SP, DP, Motor,
// "Single Panna", "Jodi", "Cycle Patti", "Family Set 8", "Common"… — the
// dictionary in src/lib/matka/term-registry.ts knows 100+ spellings). Every
// number is then classified and routed to its respective place:
//
//   Digit-length routing (unchanged core behaviour):
//     1 digit  → Single (Ank)          → double-single-inventories type=single
//     2 digits → Double (Jodi)         → double-single-inventories type=double
//     3 digits → Triple (Panna)        → triple-inventories type=mix|common
//   Label routing (NEW — Triple sub-categories Mix / Common / Group):
//     "common …"      → triple-inventories type=common
//     "<group term> …"→ triple-inventories type=group (16 group options:
//                      SP DP TP SPDP SPTP DPTP SPDPTP Motor Pana
//                      50/60/70/90DP/90ABR charts, Family Set 4/6/8)
//                      4-10 digit numbers under a group label are SEEDS and
//                      are expanded (Motor → C(n,3) pannas, Family → family
//                      pannas, charts → chart lookup) via EXPANDER_REGISTRY.
//     unknown label   → content HELD BACK (never mis-filed) + label reported
//                      as a Parser Exception (auto-evolution) so an admin
//                      can teach it in one click (manual evolution, stored
//                      in the ParserTerm table).
//
// Operator example (all in one message):
//   SP - 1,2,5,6,7 = 100 rs
//   DP - 12,23,47,35,18 = 50 rs
//   Motor -
//   134678 = 200rs
//   347890 = 100 rs
//
// Submit order matters (existing API contract):
//   1. POST /api/inventories           → parent inventory (409 → reuse)
//   2. POST /api/triple-inventories    type=mix     (FIRST of the triples)
//   3. POST /api/triple-inventories    type=common
//   4. POST /api/triple-inventories    type=group   (one per group option)
//   5. POST /api/double-single-inventories type=single
//   6. POST /api/double-single-inventories type=double (LAST — its handler
//      re-sums triple + double-single totals into the inventory)
// ────────────────────────────────────────────────────────────────────────────

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch, recordParserExceptions } from '@/lib/api-helpers'
import { formatDate, getCurrentTime } from '@/lib/format'
import { FormField, FormInput, FormSelect, GoldButton, OutlineButton } from '@/components/shared-ui'
import { DictationFormatButton } from '@/components/DictationFormatButton'
import { autoFormatDictation } from '@/lib/speech-dictation'
import {
  parseUnifiedEntry,
  buildTripleGrid,
  gridTotals,
  type ParsedEntry,
  type GroupParseResult,
} from '@/lib/matka/entry-parser'
import {
  GROUP_OPTION_ORDER,
  CATEGORY_LABELS,
  CATEGORY_SHORT_LABELS,
  type CanonicalCategory,
  type CustomTerm,
} from '@/lib/matka/term-registry'
import { Check, RotateCcw, Layers, Eye, AlertCircle, Loader2, Sparkles, GraduationCap } from 'lucide-react'

// ────────────────────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────────────────────

interface SubmitResult {
  inventoryId: string
  singlePosted: number
  doublePosted: number
  tripleMixPosted: number
  tripleCommonPosted: number
  groupPosted: number
  heldBack: number
}

// ────────────────────────────────────────────────────────────────────────────
// Small BarChart — matches the existing ERP style
// ────────────────────────────────────────────────────────────────────────────

function MiniBarChart({ data, emptyLabel = 'No data yet', color = '#4F46E5' }: { data: Array<{ num: string; amt: number }>; emptyLabel?: string; color?: string }) {
  const max = Math.max(...data.map(d => d.amt), 1)
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-end gap-1 h-[110px] pb-5 pt-1">
        {data.length === 0 ? (
          <div className="flex-1 text-center text-[11px] text-slate-400 self-center">{emptyLabel}</div>
        ) : data.map(d => {
          const h = d.amt > 0 ? Math.max((d.amt / max) * 90, 6) : 3
          const bg = d.amt > 0 ? `linear-gradient(180deg,${color},${color}BB)` : '#E2E8F0'
          return (
            <div
              key={d.num}
              className="flex-1 min-w-[18px] rounded-t-[3px] relative group transition-all"
              style={{ height: `${h}%`, background: bg }}
              title={`${d.num} = ₹${d.amt}`}
            >
              <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-semibold text-slate-500 whitespace-nowrap">
                {d.num}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// Aggregate single entries into 10 bars (digits 0-9)
function aggregateSingle(entries: ParsedEntry[]): Array<{ num: string; amt: number }> {
  const bars: Array<{ num: string; amt: number }> = []
  for (let i = 0; i <= 9; i++) bars.push({ num: String(i), amt: 0 })
  for (const e of entries) {
    const idx = parseInt(e.number, 10)
    if (idx >= 0 && idx <= 9) bars[idx].amt += e.amount
  }
  return bars
}

// Aggregate double entries — top 10 jodis by amount
function aggregateDouble(entries: ParsedEntry[]): Array<{ num: string; amt: number }> {
  const map = new Map<string, number>()
  for (const e of entries) {
    map.set(e.number, (map.get(e.number) || 0) + e.amount)
  }
  return Array.from(map.entries())
    .map(([num, amt]) => ({ num, amt }))
    .sort((a, b) => b.amt - a.amt)
    .slice(0, 10)
}

// Aggregate triple entries by ank position (digit sum % 10, 0 → column 10)
function aggregateTriple(entries: ParsedEntry[]): Array<{ num: string; amt: number }> {
  const bars: Array<{ num: string; amt: number }> = []
  for (let i = 1; i <= 9; i++) bars.push({ num: String(i), amt: 0 })
  bars.push({ num: '0', amt: 0 }) // column 10 = ank 0
  for (const e of entries) {
    let sum = 0
    for (const ch of e.number) sum += parseInt(ch, 10)
    const ank = sum % 10
    const idx = ank === 0 ? 9 : ank - 1
    bars[idx].amt += e.amount
  }
  return bars
}

// ────────────────────────────────────────────────────────────────────────────
// Result column — read-only display of parsed entries + chart
// ────────────────────────────────────────────────────────────────────────────

function ResultColumn({
  label,
  badge,
  entries,
  accent,
}: {
  label: string
  badge: string
  entries: ParsedEntry[]
  accent: { ring: string; chipBg: string; chipText: string; border: string; bar: string }
}) {
  const total = useMemo(() => entries.reduce((s, e) => s + e.amount, 0), [entries])
  const chartData = useMemo(() => {
    if (badge === 'S') return aggregateSingle(entries)
    if (badge === 'D') return aggregateDouble(entries)
    return aggregateTriple(entries)
  }, [entries, badge])

  return (
    <div className={`flex flex-col rounded-xl border ${accent.border} bg-white overflow-hidden`}>
      {/* Header */}
      <div className="px-3 py-2 flex items-center justify-between border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white">
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center justify-center w-6 h-6 rounded-md text-white text-[11px] font-bold ${accent.ring}`}>
            {badge}
          </span>
          <div className="text-[12px] font-bold text-slate-800 leading-tight">{label}</div>
        </div>
        <div className="text-right">
          <div className="text-[9px] text-slate-400 leading-tight">
            {entries.length} {entries.length === 1 ? 'entry' : 'entries'}
          </div>
          <div className="text-[12px] font-bold text-slate-800 leading-tight">₹{total.toLocaleString('en-IN')}</div>
        </div>
      </div>

      {/* Entries list (read-only) */}
      <div className="p-2.5 flex flex-col gap-1 max-h-[180px] overflow-y-auto">
        {entries.length === 0 ? (
          <div className="text-[11px] text-slate-300 italic text-center py-4">No entries</div>
        ) : (
          <div className="flex flex-wrap gap-1">
            {entries.map((e, i) => (
              <span
                key={`${e.number}-${i}`}
                className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-mono font-semibold ${accent.chipBg} ${accent.chipText}`}
              >
                {e.number}<span className="opacity-50 mx-0.5">=</span>₹{e.amount}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Chart preview */}
      <div className="border-t border-slate-100 p-2 bg-slate-50">
        <MiniBarChart data={chartData} emptyLabel="No preview" color={accent.bar} />
      </div>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
// Group result column — expanded pannas per group option
// ────────────────────────────────────────────────────────────────────────────

function GroupColumn({ group }: { group: GroupParseResult }) {
  const total = useMemo(() => group.entries.reduce((s, e) => s + e.amount, 0), [group])
  const chartData = useMemo(() => aggregateTriple(group.entries), [group])
  return (
    <ResultColumn
      label={`Group — ${CATEGORY_LABELS[group.option]}`}
      badge="G"
      entries={group.entries}
      accent={{
        ring: 'bg-amber-600',
        chipBg: 'bg-amber-50', chipText: 'text-amber-700',
        border: 'border-amber-100',
        bar: '#D97706',
      }}
    />
  )
}

// ────────────────────────────────────────────────────────────────────────────
// Main page
// ────────────────────────────────────────────────────────────────────────────

export function UnifiedEntryPage() {
  const { currentUser, setCurrentPage, setViewingInventoryId } = useAppStore()

  // Top form
  const [codes, setCodes] = useState<Array<{ id: string; name: string; code: string; market: string }>>([])
  const [vendors, setVendors] = useState<Array<{ id: string; businessName: string }>>([])
  const [form, setForm] = useState({
    date: formatDate(new Date()),
    inventoryCodeId: '',
    vendorId: '',
  })

  // ONE input textarea + ONE default rate
  const [rawText, setRawText] = useState('')
  const [defaultRate, setDefaultRate] = useState('')

  // Evolving dictionary: custom terms from DB (ParserTerm table)
  const [customTerms, setCustomTerms] = useState<CustomTerm[]>([])
  const [teachFor, setTeachFor] = useState<string | null>(null) // term being taught
  const [teachCategory, setTeachCategory] = useState<string>('SP')
  const [teaching, setTeaching] = useState(false)

  // Submit state
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState<SubmitResult | null>(null)
  const [error, setError] = useState('')
  const submitRef = useRef(false)

  const isAdmin = currentUser?.role === 'super' || currentUser?.role === 'manager' ||
    currentUser?.role === 'master' // legacy value pre-rename

  // Load inventory codes + vendors + custom dictionary terms
  useEffect(() => {
    apiFetch('/api/inventory-codes').then(setCodes).catch(console.error)
    apiFetch('/api/vendors').then(setVendors).catch(console.error)
    apiFetch('/api/parser-terms')
      .then((rows: Array<{ term: string; category: string }>) =>
        setCustomTerms(rows.map(r => ({ term: r.term, category: r.category })))
      )
      .catch(() => { /* dictionary is optional — built-ins still work */ })
  }, [])

  // Live parse (memoized) — the WHOLE calculation happens here
  const parsed = useMemo(
    () => parseUnifiedEntry(rawText, parseFloat(defaultRate) || 0, customTerms),
    [rawText, defaultRate, customTerms]
  )

  const totalSingles = useMemo(() => parsed.singles.reduce((s, e) => s + e.amount, 0), [parsed.singles])
  const totalDoubles = useMemo(() => parsed.doubles.reduce((s, e) => s + e.amount, 0), [parsed.doubles])
  const totalTriples = useMemo(() => parsed.triples.reduce((s, e) => s + e.amount, 0), [parsed.triples])
  const totalCommon = useMemo(() => parsed.common.reduce((s, e) => s + e.amount, 0), [parsed.common])
  const totalGroups = useMemo(() => parsed.groups.reduce((s, g) => s + g.entries.reduce((a, e) => a + e.amount, 0), 0), [parsed.groups])
  const grandTotal = totalSingles + totalDoubles + totalTriples + totalCommon + totalGroups

  const resetAll = useCallback(() => {
    setRawText('')
    setDefaultRate('')
    setResult(null)
    setError('')
    submitRef.current = false
  }, [])

  const handleFocusField = useCallback(() => {
    const el = document.activeElement as HTMLElement | null
    if (el && el.blur) el.blur()
  }, [])

  // ── Manual evolution: teach the dictionary a new term ────────────────────
  const teachTerm = async (term: string, category: string) => {
    if (!term) return
    setTeaching(true)
    try {
      await apiFetch('/api/parser-terms', {
        method: 'POST',
        body: JSON.stringify({
          term,
          category,
          note: `Taught from Smart Entry by ${currentUser?.username || 'admin'}`,
        }),
      })
      setCustomTerms(prev => [...prev, { term, category }])
      setTeachFor(null)
    } catch (e) {
      console.error(e)
      setError(e instanceof Error ? e.message : 'Could not save term')
    } finally {
      setTeaching(false)
    }
  }

  const handleSubmit = async () => {
    if (submitRef.current) return
    if (!form.inventoryCodeId) { setError('Please select a market'); return }
    if (!form.date) { setError('Please select a date'); return }

    const hasAny = parsed.singles.length > 0 || parsed.doubles.length > 0 ||
      parsed.triples.length > 0 || parsed.common.length > 0 || parsed.groups.length > 0
    if (!hasAny) { setError('Please enter at least one valid entry — e.g. "SP - 1,2,5 = 100" or "5,20,342=50"'); return }

    submitRef.current = true
    setSubmitting(true)
    setError('')
    setResult(null)

    handleFocusField()
    await new Promise(r => setTimeout(r, 50))

    try {
      // ── 1. Create or reuse the parent inventory ──────────────────────────
      const invBody = JSON.stringify({
        date: form.date,
        time: getCurrentTime(),
        inventoryCodeId: form.inventoryCodeId,
        remark: '',
        createdBy: currentUser?.username || 'admin1',
      })

      let inventoryId = ''
      const invResp = await fetch('/api/inventories', {
        method: 'POST',
        body: invBody,
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': String(currentUser?.id || ''),
          'x-user-name': String(currentUser?.username || ''),
          'x-user-role': String(currentUser?.role || ''),
          'x-user-markets': String(currentUser?.assignedMarkets || ''),
        },
      })
      if (invResp.ok) {
        const inv = await invResp.json() as { id: string }
        inventoryId = inv.id
      } else if (invResp.status === 409) {
        // Inventory already exists for this code+date+time → reuse it
        const body = await invResp.json().catch(() => ({})) as { existingId?: string; error?: string }
        if (body.existingId) {
          inventoryId = body.existingId
        } else {
          // Fallback: search the inventory list by code name
          const codeName = codes.find(c => c.id === form.inventoryCodeId)?.name || ''
          if (codeName) {
            const list = await apiFetch(`/api/inventories?limit=200&search=${encodeURIComponent(codeName)}`) as { data: Array<{ id: string; inventoryCodeId: string; date: string }> }
            const found = list.data.find(i =>
              i.inventoryCodeId === form.inventoryCodeId &&
              new Date(i.date).toDateString() === new Date(form.date).toDateString()
            )
            if (!found) throw new Error('Inventory already exists but could not be located. Open Entry Lists to find it.')
            inventoryId = found.id
          } else {
            throw new Error(body.error || 'Inventory already exists')
          }
        }
      } else {
        const err = await invResp.json().catch(() => ({ error: 'Failed to create inventory' })) as { error?: string }
        throw new Error(err.error || 'Failed to create inventory')
      }

      if (!inventoryId) throw new Error('Failed to obtain inventory ID')

      const out: SubmitResult = {
        inventoryId,
        singlePosted: 0,
        doublePosted: 0,
        tripleMixPosted: 0,
        tripleCommonPosted: 0,
        groupPosted: 0,
        heldBack: parsed.skipped.filter(s => s.includes('held back')).length,
      }
      const createdBy = currentUser?.username || 'admin1'
      const vendorId = form.vendorId || null
      const detailsRaw = rawText.length > 30_000 ? rawText.slice(0, 30_000) + '\n[truncated]' : rawText

      // ── 2. Triple MIX — POST FIRST so the DS handler can re-sum later ────
      if (parsed.triples.length > 0) {
        const entries = parsed.triples
        const totalAmount = entries.reduce((s, e) => s + e.amount, 0)
        const grid = buildTripleGrid(entries)
        const totals = gridTotals(grid)
        await apiFetch('/api/triple-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId,
            vendorId,
            type: 'mix',
            details: detailsRaw,
            parsedData: JSON.stringify({
              entries: entries.map(e => ({ number: e.number, price: e.amount, rate: 0, skipped: false })),
              totalEntriesCount: entries.length,
              grid,
              totals,
              skipped: [],
              skippedNumbers: [],
              droppedTokens: [],
            }),
            rate: 0,
            totalAmount,
            createdBy,
          }),
        })
        out.tripleMixPosted = entries.length
      }

      // ── 3. Triple COMMON ──────────────────────────────────────────────
      if (parsed.common.length > 0) {
        const entries = parsed.common
        const totalAmount = entries.reduce((s, e) => s + e.amount, 0)
        const grid = buildTripleGrid(entries)
        const totals = gridTotals(grid)
        await apiFetch('/api/triple-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId,
            vendorId,
            type: 'common',
            details: `Common (Smart Entry): ${entries.length} pannas | Total: ${totalAmount}`,
            parsedData: JSON.stringify({
              series: '',
              generatedPannas: entries.map(e => e.number),
              numbers: entries.map(e => ({ number: e.number, price: e.amount })),
              grid,
              totals,
              batchInput: detailsRaw,
            }),
            rate: 0,
            totalAmount,
            createdBy,
          }),
        })
        out.tripleCommonPosted = entries.length
      }

      // ── 4. Triple GROUP — one POST per group option ───────────────────
      for (const g of parsed.groups) {
        const totalAmount = g.entries.reduce((s, e) => s + e.amount, 0)
        const grid = buildTripleGrid(g.entries)
        const totals = gridTotals(grid)
        const seedStr = g.seeds.join(',') || '-'
        await apiFetch('/api/triple-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId,
            vendorId,
            type: 'group',
            details: `Group: ${g.option} | Seeds: ${seedStr} | Pannas: ${g.entries.length} | Total: ${totalAmount}`,
            parsedData: JSON.stringify({
              seriesCards: [],
              select: '',
              groupType: g.option,
              generatedPannas: g.entries.map(e => e.number),
              numbers: g.entries.map(e => ({ number: e.number, price: e.amount })),
              grid,
              totals,
              seeds: g.seeds,
              inputContent: detailsRaw,
            }),
            rate: 0,
            totalAmount,
            createdBy,
          }),
        })
        out.groupPosted += g.entries.length
      }

      // ── 5. Single ──────────────────────────────────────────────────────
      if (parsed.singles.length > 0) {
        const entries = parsed.singles
        const totalAmount = entries.reduce((s, e) => s + e.amount, 0)
        const numbers = entries.map(e => ({ number: e.number, price: e.amount }))
        await apiFetch('/api/double-single-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId,
            vendorId,
            type: 'single',
            details: `Card: ${numbers.map(n => n.number).join(',')} Single:`,
            parsedData: JSON.stringify({ numbers }),
            rate: 0,
            totalAmount,
            createdBy,
          }),
        })
        out.singlePosted = entries.length
      }

      // ── 6. Double — POST LAST so its handler re-sums everything ────────
      if (parsed.doubles.length > 0) {
        const entries = parsed.doubles
        const totalAmount = entries.reduce((s, e) => s + e.amount, 0)
        const numbers = entries.map(e => ({ number: e.number, price: e.amount }))
        await apiFetch('/api/double-single-inventories', {
          method: 'POST',
          body: JSON.stringify({
            inventoryId,
            vendorId,
            type: 'double',
            details: `Card: ${numbers.map(n => n.number).join(',')} Double:`,
            parsedData: JSON.stringify({ numbers }),
            rate: 0,
            totalAmount,
            createdBy,
          }),
        })
        out.doublePosted = entries.length
      }

      // ── 7. Auto-evolution: record unknown labels as Parser Exceptions ──
      if (parsed.unknownLabels.length > 0) {
        recordParserExceptions({
          uploadedBy: createdBy,
          uploadedByUserId: currentUser?.id,
          market: codes.find(c => c.id === form.inventoryCodeId)?.market || null,
          inventoryCodeId: form.inventoryCodeId,
          originalText: rawText.slice(0, 5000),
          droppedTokens: parsed.unknownLabels.map(l => `unknown label: ${l}`),
        }).catch(() => { /* non-fatal */ })
      }

      setResult(out)
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to submit'
      setError(msg)
    } finally {
      setSubmitting(false)
      submitRef.current = false
    }
  }

  const goToCardView = () => {
    if (!result?.inventoryId) return
    setViewingInventoryId(result.inventoryId)
    setCurrentPage('card-view')
  }

  const heldBackCount = parsed.skipped.filter(s => s.includes('held back')).length

  return (
    <div className="p-4 md:p-7 animate-in fade-in duration-300 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="mb-5">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Layers size={20} className="text-indigo-600" />
          Smart Entry
        </h1>
        <p className="text-[12px] text-slate-500 mt-1">
          One input box — the whole calculation happens here. Type, dictate (Gboard mic 🎤 → <b>Format</b>), or paste.
          Numbers are auto-classified: <b>1 digit → Single</b>, <b>2 → Double</b>, <b>3 → Triple</b> (Mix / Common / Group via terms like
          <b> SP, DP, Jodi, Motor, Cycle Patti, Family Set 8, Common…</b>).
        </p>
      </div>

      {/* Top form: Market + Date + Vendor */}
      <div className="mb-5 rounded-xl overflow-hidden border border-indigo-100 shadow-sm">
        <div className="bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-3 text-white flex items-center justify-between">
          <div>
            <div className="text-[14px] font-bold">Entry Details</div>
            <div className="text-[10px] text-indigo-100">Select market &amp; date — same as New Entry</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-indigo-100">Date</div>
            <div className="text-[12px] font-mono font-semibold">{form.date}</div>
          </div>
        </div>
        <div className="bg-white p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField label="Date">
            <FormInput type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
          </FormField>
          <FormField label="Market">
            <FormSelect value={form.inventoryCodeId} onChange={e => setForm(f => ({ ...f, inventoryCodeId: e.target.value }))}>
              <option value="">&mdash; Select &mdash;</option>
              {codes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="Customer (optional)">
            <FormSelect value={form.vendorId} onChange={e => setForm(f => ({ ...f, vendorId: e.target.value }))}>
              <option value="">&mdash; None &mdash;</option>
              {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName}</option>)}
            </FormSelect>
          </FormField>
        </div>
      </div>

      {/* ── ONE INPUT BOX ── */}
      <div className="mb-5 rounded-xl overflow-hidden border border-slate-200 bg-white shadow-sm">
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 px-4 py-3 text-white flex items-center justify-between gap-3 flex-wrap">
          <div>
            <div className="text-[14px] font-bold flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-5 h-5 rounded bg-white/15 text-[10px] font-bold">1</span>
              One Input — Terms Optional
            </div>
            <div className="text-[10px] text-slate-300 mt-0.5">
              Format: <span className="font-mono">Term - numbers = amount</span> · one entry per line ·
              <span className="font-mono"> SP/DP/TP/Jodi/Motor/Cycle/Family Set 4-6-8/50-60-70/90/ABR/Common/Mix</span> all recognized
            </div>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-[10px] text-slate-300">Default rate (when no =amount)</label>
            <input
              type="number"
              inputMode="decimal"
              value={defaultRate}
              onChange={e => setDefaultRate(e.target.value)}
              placeholder="0"
              className="w-20 px-2 py-1 text-[11px] border border-slate-300 rounded-md focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
            />
            <DictationFormatButton
              groupSize={null}
              getValue={() => rawText}
              onText={(t) => setRawText(t)}
            />
          </div>
        </div>
        <div className="p-3">
          <textarea
            value={rawText}
            onChange={e => setRawText(e.target.value)}
            onBlur={e => {
              const f = autoFormatDictation(e.target.value, null)
              if (f !== null) setRawText(f)
            }}
            placeholder={`Type or paste here. Example (one message, many sections):\nSP - 1,2,5,6,7 = 100 rs\nDP - 12,23,47,35,18 = 50 rs\nMotor -\n134678 = 200rs\n347890 = 100 rs\n\nAlso works:\nSingle Panna - 3,7 = 50        (SP synonyms recognized)\nJodi - 12,23 = 50              (DP synonyms recognized)\nCycle Patti - 134678 = 100     (Motor synonyms recognized)\nFamily Set 8 - 123 = 100\nCommon - 111,117 = 25\n5,20,342=50                    (no term → Triple Mix by digit length)`}
            rows={9}
            className="w-full px-4 py-3 text-[13px] font-mono border border-slate-200 rounded-lg focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-y min-h-[170px] bg-slate-50"
          />
          <div className="flex items-center justify-between mt-2 text-[10px] text-slate-500 flex-wrap gap-1">
            <span>
              Parsed: <b className="text-indigo-700">{parsed.singles.length}</b> single · <b className="text-violet-700">{parsed.doubles.length}</b> double · <b className="text-sky-700">{parsed.triples.length}</b> mix · <b className="text-emerald-700">{parsed.common.length}</b> common · <b className="text-amber-700">{parsed.groups.reduce((s, g) => s + g.entries.length, 0)}</b> group pannas
              {parsed.skipped.length > 0 && <span className="text-amber-600 ml-2">· {parsed.skipped.length} skipped{heldBackCount > 0 ? ` (${heldBackCount} held back)` : ''}</span>}
            </span>
            <span>Grand total: <b className="text-slate-800">₹{grandTotal.toLocaleString('en-IN')}</b></span>
          </div>
        </div>
      </div>

      {/* ── RECOGNIZED TERMS + UNKNOWN-LABEL TEACHING ── */}
      {(parsed.recognizedLabels.length > 0 || parsed.unknownLabels.length > 0) && (
        <div className="mb-5 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
          <div className="flex items-start gap-2 flex-wrap">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 inline-flex items-center gap-1 mt-0.5">
              <Sparkles size={11} /> Terms
            </span>
            {parsed.recognizedLabels.map((r, i) => (
              <span key={`k${i}`} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
                {r.raw} → {CATEGORY_SHORT_LABELS[r.category]}
              </span>
            ))}
            {parsed.unknownLabels.map(u => (
              <span key={u} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-50 text-red-700 border border-red-100">
                <AlertCircle size={10} /> unknown: {u}
                {isAdmin && (
                  <button
                    onClick={() => { setTeachFor(teachFor === u ? null : u); setTeachCategory('SP') }}
                    className="ml-1 inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-indigo-600 text-white hover:bg-indigo-700"
                    title="Teach the dictionary what this term means"
                  >
                    <GraduationCap size={10} /> Teach
                  </button>
                )}
              </span>
            ))}
          </div>
          {isAdmin && teachFor && (
            <div className="mt-2 p-2.5 rounded-lg bg-indigo-50 border border-indigo-100 flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-semibold text-indigo-900">
                &quot;{teachFor}&quot; means:
              </span>
              <select
                value={teachCategory}
                onChange={e => setTeachCategory(e.target.value)}
                className="text-[11px] border border-indigo-200 rounded-md px-2 py-1 bg-white outline-none text-slate-800"
              >
                {GROUP_OPTION_ORDER.map(o => (
                  <option key={o} value={o}>Group — {CATEGORY_LABELS[o]}</option>
                ))}
                <option value="mix">Triple — Mix</option>
                <option value="common">Triple — Common</option>
              </select>
              <button
                onClick={() => teachTerm(teachFor, teachCategory)}
                disabled={teaching}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-indigo-600 text-white text-[11px] font-semibold hover:bg-indigo-700 disabled:opacity-60"
              >
                {teaching ? <Loader2 size={11} className="animate-spin" /> : <Check size={11} />} Save to dictionary
              </button>
              <button onClick={() => setTeachFor(null)} className="text-[11px] text-slate-500 hover:text-slate-700">Cancel</button>
              <span className="text-[10px] text-indigo-500">Saved terms apply instantly and to every future entry.</span>
            </div>
          )}
          {!isAdmin && parsed.unknownLabels.length > 0 && (
            <div className="mt-1.5 text-[10px] text-slate-500">
              Unknown terms were held back — ask a Super Admin / Admin to add them via the <b>Teach</b> button or Parser Terms.
            </div>
          )}
        </div>
      )}

      {/* ── RESULT COLUMNS (read-only) ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-5">
        <ResultColumn
          label="Single (Ank)"
          badge="S"
          entries={parsed.singles}
          accent={{ ring: 'bg-indigo-600', chipBg: 'bg-indigo-50', chipText: 'text-indigo-700', border: 'border-indigo-100', bar: '#4F46E5' }}
        />
        <ResultColumn
          label="Double / Jodi"
          badge="D"
          entries={parsed.doubles}
          accent={{ ring: 'bg-violet-600', chipBg: 'bg-violet-50', chipText: 'text-violet-700', border: 'border-violet-100', bar: '#7C3AED' }}
        />
        <ResultColumn
          label="Triple — Mix"
          badge="T"
          entries={parsed.triples}
          accent={{ ring: 'bg-fuchsia-600', chipBg: 'bg-fuchsia-50', chipText: 'text-fuchsia-700', border: 'border-fuchsia-100', bar: '#C026D3' }}
        />
        <ResultColumn
          label="Triple — Common"
          badge="C"
          entries={parsed.common}
          accent={{ ring: 'bg-emerald-600', chipBg: 'bg-emerald-50', chipText: 'text-emerald-700', border: 'border-emerald-100', bar: '#059669' }}
        />
        {parsed.groups.map(g => <GroupColumn key={g.option} group={g} />)}
      </div>

      {/* Skipped list */}
      {parsed.skipped.length > 0 && (
        <details className="mb-4 text-[11px] text-amber-700 bg-amber-50 border border-amber-100 rounded-md p-2">
          <summary className="cursor-pointer font-semibold">Skipped / held back ({parsed.skipped.length}) — click to expand</summary>
          <ul className="mt-1 ml-4 list-disc space-y-0.5 max-h-32 overflow-y-auto">
            {parsed.skipped.slice(0, 50).map((s, i) => <li key={i}>{s}</li>)}
            {parsed.skipped.length > 50 && <li>… and {parsed.skipped.length - 50} more</li>}
          </ul>
        </details>
      )}

      {/* Submit / Reset / Status */}
      <div className="rounded-xl bg-white border border-slate-200 p-4 shadow-sm">
        {error && (
          <div className="mb-3 flex items-start gap-2 text-[12px] px-3 py-2 rounded-lg bg-red-50 text-red-700 border border-red-100">
            <AlertCircle size={14} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {result && (
          <div className="mb-3 flex items-start gap-2 text-[12px] px-3 py-2 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-100">
            <Check size={14} className="mt-0.5 shrink-0" />
            <div className="flex-1">
              <div className="font-semibold">
                Submitted: {result.singlePosted} single · {result.doublePosted} double · {result.tripleMixPosted} mix · {result.tripleCommonPosted} common · {result.groupPosted} group pannas
              </div>
              {result.heldBack > 0 && (
                <div className="text-[11px] text-amber-700 mt-0.5">
                  {result.heldBack} line(s) were held back (unknown terms) — they were NOT submitted.
                </div>
              )}
              <button
                onClick={goToCardView}
                className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-indigo-600 text-white text-[11px] font-semibold hover:bg-indigo-700 transition-colors"
              >
                <Eye size={12} /> View Saved Card
              </button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2.5">
          <GoldButton onClick={handleSubmit} disabled={submitting}>
            {submitting ? <><Loader2 size={14} className="animate-spin" /> Submitting...</> : <><Check size={14} /> Submit All</>}
          </GoldButton>
          <OutlineButton onClick={resetAll}>
            <RotateCcw size={14} /> Reset
          </OutlineButton>
          <span className="text-[11px] text-slate-400 ml-auto">
            One click creates the inventory and posts Singles, Doubles and Triples (Mix / Common / Group) to their respective places.
          </span>
        </div>
      </div>
    </div>
  )
}
