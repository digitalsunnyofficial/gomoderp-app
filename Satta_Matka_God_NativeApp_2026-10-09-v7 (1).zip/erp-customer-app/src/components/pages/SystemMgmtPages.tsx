'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { formatDate, formatDateTime, formatCurrency, getCurrentTime, MarketChip, StatusBadge, MARKET_COLORS, loadCustomMarkets, saveCustomMarkets, getMarketLabel, DEFAULT_CUSTOM_COLOR, type CustomMarket } from '@/lib/format'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, BlueButton, Pagination, Modal } from '@/components/shared-ui'
import { AppMarketsSection } from '@/components/pages/MarketsPages'
import {
  Plus, Check, RotateCcw, X, Search, Eye, EyeOff, KeyRound, Pencil, Trash2,
  Shield, Lock, Unlock, MapPin, Activity, RefreshCw, AlertTriangle,
  UserPlus, BarChart3, CheckCircle2, History, Clock, Settings, Filter
} from 'lucide-react'

export function ConfigurePage() {
  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Markets</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">
          THE single market source for the ERP and the Game. Every market is created from the
          formula Market name + Phase (Day/Night) + Session (Open/Close) — the Customer App,
          Game Allocation, Results and ERP entries all reference these exact session records.
          Starlines are managed separately on the Starlines page.
        </p>
      </div>

      {/* Live app markets — the ONE canonical market list (timings, bet closing minutes, cron-driven open/close) */}
      <AppMarketsSection />
    </div>
  )
}

// ────────────────────────────────────────
// USER MANAGEMENT PAGE
// ────────────────────────────────────────

export function UsersPage() {
  const { currentUser } = useAppStore()
  const [users, setUsers] = useState<Array<Record<string, unknown>>>([])
  const [codes, setCodes] = useState<Array<Record<string, unknown>>>([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [addForm, setAddForm] = useState({ username: '', password: '', name: '', email: '', phone: '', role: 'user' })
  const [selectedPerms, setSelectedPerms] = useState<Record<string, { canView: boolean; canEdit: boolean; canDelete: boolean }>>({})
  const [editingUser, setEditingUser] = useState<string | null>(null)
  const [message, setMessage] = useState('')
  const [lockModalUser, setLockModalUser] = useState<{ id: string; username: string } | null>(null)
  const [lockReason, setLockReason] = useState('')
  const [marketsModalUser, setMarketsModalUser] = useState<{ id: string; username: string; assignedMarkets: string } | null>(null)
  const [marketsSelection, setMarketsSelection] = useState<string[]>([])
  // ── Password view/edit (Super Admin only) ──
  const isMasterUser = currentUser?.role === 'super'
  const [passwordRevealId, setPasswordRevealId] = useState<string | null>(null)
  const [pwModalUser, setPwModalUser] = useState<{ id: string; username: string } | null>(null)
  const [pwNew, setPwNew] = useState('')

  const refreshUsers = () => apiFetch('/api/users').then(setUsers).catch(console.error)

  useEffect(() => {
    Promise.all([apiFetch('/api/users'), apiFetch('/api/inventory-codes')])
      .then(([u, c]) => { setUsers(u); setCodes(c); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const codeList = codes as Array<{ code: string; name: string; market: string }>
  // Unique markets from codes
  const allMarkets = Array.from(new Set(codeList.map(c => c.market).filter(Boolean))).sort()

  const handleAddUser = async () => {
    if (!addForm.username || !addForm.password) { setMessage('Username and password required'); return }
    try {
      const perms = Object.entries(selectedPerms).map(([code, perms]) => ({ inventoryCode: code, ...perms }))
      await apiFetch('/api/users', {
        method: 'POST',
        body: JSON.stringify({ ...addForm, permissions: perms, createdBy: currentUser?.username }),
      })
      setMessage('User created!')
      setAddForm({ username: '', password: '', name: '', email: '', phone: '', role: 'user' })
      setSelectedPerms({})
      setShowAdd(false)
      refreshUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const handleLockUser = async () => {
    if (!lockModalUser) return
    try {
      await apiFetch(`/api/users/${lockModalUser.id}/lock`, {
        method: 'POST',
        body: JSON.stringify({ lockedBy: currentUser?.username, lockReason }),
      })
      setMessage(`User "${lockModalUser.username}" locked`)
      setLockModalUser(null)
      setLockReason('')
      refreshUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed to lock')
    }
  }

  const handleUnlockUser = async (id: string, username: string) => {
    if (!confirm(`Unlock user "${username}"?`)) return
    try {
      await apiFetch(`/api/users/${id}/lock?unlockedBy=${encodeURIComponent(currentUser?.username || 'admin')}`, { method: 'DELETE' })
      setMessage(`User "${username}" unlocked`)
      refreshUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed to unlock')
    }
  }

  const openMarketsModal = (user: { id: string; username: string; assignedMarkets?: string }) => {
    setMarketsModalUser({ id: user.id, username: user.username, assignedMarkets: user.assignedMarkets || '' })
    setMarketsSelection((user.assignedMarkets || '').split(',').map(s => s.trim()).filter(Boolean))
  }

  const handleSaveMarkets = async () => {
    if (!marketsModalUser) return
    try {
      await apiFetch(`/api/users/${marketsModalUser.id}/markets`, {
        method: 'PUT',
        body: JSON.stringify({ markets: marketsSelection, updatedBy: currentUser?.username }),
      })
      setMessage(`Markets updated for "${marketsModalUser.username}"`)
      setMarketsModalUser(null)
      refreshUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const handleSavePermissions = async (userId: string) => {
    try {
      const perms = Object.entries(selectedPerms).map(([code, perms]) => ({ inventoryCode: code, ...perms }))
      await apiFetch(`/api/users/${userId}/permissions`, { method: 'PUT', body: JSON.stringify({ permissions: perms }) })
      setMessage('Permissions updated!')
      setEditingUser(null)
      refreshUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const handleSavePassword = async () => {
    if (!pwModalUser) return
    if (!pwNew || pwNew.length < 4) { setMessage('Password must be at least 4 characters'); return }
    try {
      await apiFetch(`/api/users/${pwModalUser.id}`, {
        method: 'PUT',
        body: JSON.stringify({ password: pwNew, updatedBy: currentUser?.username }),
      })
      setMessage(`Password updated for "${pwModalUser.username}"`)
      setPwModalUser(null)
      setPwNew('')
      refreshUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed to update password')
    }
  }

  const userList = users as Array<{ id: string; username: string; name: string | null; role: string; status: string; isLocked?: boolean; lockedAt?: string | null; lockedBy?: string | null; lockReason?: string | null; assignedMarkets?: string; permissions: Array<{ inventoryCode: string; canView: boolean; canEdit: boolean; canDelete: boolean }> }>

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">User Management</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Manage users, permissions, market access, and account locking</p>
        </div>
        <GoldButton onClick={() => setShowAdd(!showAdd)}><Plus size={14} /> Add User</GoldButton>
      </div>

      {message && (
        <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('success') || message.includes('created') || message.includes('updated') || message.includes('locked') || message.includes('unlocked') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{message}</div>
      )}

      {showAdd && (
        <SectionCard title="Add New User">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
            <FormField label="Username"><FormInput value={addForm.username} onChange={e => setAddForm(f => ({ ...f, username: e.target.value }))} /></FormField>
            <FormField label="Password"><FormInput type="password" value={addForm.password} onChange={e => setAddForm(f => ({ ...f, password: e.target.value }))} /></FormField>
            <FormField label="Name"><FormInput value={addForm.name} onChange={e => setAddForm(f => ({ ...f, name: e.target.value }))} /></FormField>
            <FormField label="Email"><FormInput type="email" placeholder="user@example.com" value={addForm.email} onChange={e => setAddForm(f => ({ ...f, email: e.target.value }))} /></FormField>
            <FormField label="Phone"><FormInput type="tel" placeholder="9999999999" value={addForm.phone} onChange={e => setAddForm(f => ({ ...f, phone: e.target.value }))} /></FormField>
            <FormField label="Role">
              <FormSelect value={addForm.role} onChange={e => setAddForm(f => ({ ...f, role: e.target.value }))}>
                <option value="user">Agent</option><option value="manager">Admin</option><option value="super">Super Admin</option>
              </FormSelect>
            </FormField>
          </div>
          <div className="mb-5">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] mb-3">Inventory Code Permissions</div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {codeList.map(c => (
                <div key={c.code} className="flex items-center gap-2 bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2">
                  <label className="flex items-center gap-1.5 text-[12px] cursor-pointer flex-1">
                    <input
                      type="checkbox"
                      checked={selectedPerms[c.code]?.canView ?? false}
                      onChange={e => setSelectedPerms(p => ({ ...p, [c.code]: { ...p[c.code] || { canView: true, canEdit: false, canDelete: false }, canView: e.target.checked } }))}
                      className="accent-[#3730A3]"
                    />
                    {c.name}
                  </label>
                </div>
              ))}
            </div>
          </div>
          <div className="flex gap-2.5">
            <GoldButton onClick={handleAddUser}><Check size={14} /> Create User</GoldButton>
            <OutlineButton onClick={() => setShowAdd(false)}>Cancel</OutlineButton>
          </div>
        </SectionCard>
      )}

      <SectionCard title={`Users (${userList.length})`}>
        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                {['Username', 'Name', 'Role', 'Email', 'Phone', 'Status', 'Markets', ...(isMasterUser ? ['Password'] : []), 'Actions'].map(h => (
                  <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={isMasterUser ? 9 : 8} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
              ) : userList.map(u => {
                const userMarkets = (u.assignedMarkets || '').split(',').map(s => s.trim()).filter(Boolean)
                const roleLabel = u.role === 'super' ? 'Super Admin' : u.role === 'manager' ? 'Admin' : 'Agent'
                const roleBg = u.role === 'super' ? 'bg-[rgba(55,48,163,0.1)] text-[#3730A3]' : u.role === 'manager' ? 'bg-[rgba(124,58,237,0.1)] text-[#7C3AED]' : 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]'
                return (
                  <tr key={u.id} className={`border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)] ${u.isLocked ? 'opacity-60' : ''}`}>
                    <td className="px-3.5 py-3 font-mono text-[12px]">
                      {u.username}
                      {u.isLocked && <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded-full bg-[rgba(220,38,38,0.15)] text-[#DC2626] uppercase tracking-wider">Locked</span>}
                    </td>
                    <td className="px-3.5 py-3">{u.name || '\u2014'}</td>
                    <td className="px-3.5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full ${roleBg}`}>
                        {roleLabel}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 text-[12px] text-slate-600">{(u as any).email || '\u2014'}</td>
                    <td className="px-3.5 py-3 text-[12px] text-slate-600">{(u as any).phone || '\u2014'}</td>
                    <td className="px-3.5 py-3"><StatusBadge status={u.isLocked ? 'locked' : u.status} /></td>
                    <td className="px-3.5 py-3">
                      {u.role === 'super' ? (
                        <span className="text-[10px] text-[#3730A3] font-semibold uppercase tracking-wider">All Markets</span>
                      ) : userMarkets.length === 0 ? (
                        <span className="text-[10px] text-[#9CA3AF]">None</span>
                      ) : (
                        <div className="flex gap-1 flex-wrap">
                          {userMarkets.slice(0, 3).map(m => (
                            <span key={m} className="bg-[#FFFFFF] border border-[#E5E7EB] rounded px-1.5 py-0.5 text-[10px] font-mono text-[#6B7280]">{m}</span>
                          ))}
                          {userMarkets.length > 3 && <span className="text-[10px] text-[#9CA3AF]">+{userMarkets.length - 3}</span>}
                        </div>
                      )}
                    </td>
                    {isMasterUser && (
                      <td className="px-3.5 py-3">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-[12px] text-slate-700 min-w-[64px]">
                            {passwordRevealId === u.id ? ((u as any).passwordPlain || '(not stored)') : '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022'}
                          </span>
                          <button
                            title={passwordRevealId === u.id ? 'Hide password' : 'Reveal password'}
                            onClick={() => setPasswordRevealId(passwordRevealId === u.id ? null : u.id)}
                            className="w-7 h-7 rounded-md flex items-center justify-center text-[#6B7280] hover:bg-[rgba(107,114,128,0.1)] border border-transparent hover:border-[rgba(107,114,128,0.3)] transition-all"
                          >
                            {passwordRevealId === u.id ? <EyeOff size={14} /> : <Eye size={14} />}
                          </button>
                          <button
                            title="Edit password"
                            onClick={() => { setPwModalUser({ id: u.id, username: u.username }); setPwNew('') }}
                            className="w-7 h-7 rounded-md flex items-center justify-center text-[#3730A3] hover:bg-[rgba(55,48,163,0.1)] border border-transparent hover:border-[rgba(55,48,163,0.3)] transition-all"
                          >
                            <KeyRound size={14} />
                          </button>
                        </div>
                      </td>
                    )}
                    <td className="px-3.5 py-3">
                      <div className="flex gap-1">
                        <button title="Edit permissions" onClick={() => { setEditingUser(u.id); setSelectedPerms(Object.fromEntries(u.permissions.map((p: { inventoryCode: string; canView: boolean; canEdit: boolean; canDelete: boolean }) => [p.inventoryCode, { canView: p.canView, canEdit: p.canEdit, canDelete: p.canDelete }]))) }} className="w-7 h-7 rounded-md flex items-center justify-center text-[#D97706] hover:bg-[rgba(217,119,6,0.1)] border border-transparent hover:border-[rgba(217,119,6,0.3)] transition-all"><Pencil size={14} /></button>
                        {u.role !== 'super' && (
                          <>
                            <button title="Assign markets" onClick={() => openMarketsModal({ id: u.id, username: u.username, assignedMarkets: u.assignedMarkets })} className="w-7 h-7 rounded-md flex items-center justify-center text-[#0284C7] hover:bg-[rgba(2,132,199,0.1)] border border-transparent hover:border-[rgba(2,132,199,0.3)] transition-all"><MapPin size={14} /></button>
                            {u.isLocked ? (
                              <button title="Unlock user" onClick={() => handleUnlockUser(u.id, u.username)} className="w-7 h-7 rounded-md flex items-center justify-center text-[#059669] hover:bg-[rgba(5,150,105,0.1)] border border-transparent hover:border-[rgba(5,150,105,0.3)] transition-all"><Unlock size={14} /></button>
                            ) : (
                              <button title="Lock user" onClick={() => { setLockModalUser({ id: u.id, username: u.username }); setLockReason('') }} className="w-7 h-7 rounded-md flex items-center justify-center text-[#DC2626] hover:bg-[rgba(220,38,38,0.1)] border border-transparent hover:border-[rgba(220,38,38,0.3)] transition-all"><Lock size={14} /></button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </SectionCard>

      {/* Edit Permissions Modal */}
      <Modal open={!!editingUser} onClose={() => setEditingUser(null)} title="Edit User Permissions" wide>
        <div className="space-y-2">
          {codeList.map(c => {
            const perms = selectedPerms[c.code] || { canView: false, canEdit: false, canDelete: false }
            return (
              <div key={c.code} className="flex items-center gap-4 bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-4 py-2.5">
                <span className="text-[13px] flex-1">{c.name}</span>
                <label className="flex items-center gap-1.5 text-[12px] cursor-pointer">
                  <input type="checkbox" checked={perms.canView} onChange={e => setSelectedPerms(p => ({ ...p, [c.code]: { ...perms, canView: e.target.checked } }))} className="accent-[#3730A3]" /> View
                </label>
                <label className="flex items-center gap-1.5 text-[12px] cursor-pointer">
                  <input type="checkbox" checked={perms.canEdit} onChange={e => setSelectedPerms(p => ({ ...p, [c.code]: { ...perms, canEdit: e.target.checked } }))} className="accent-[#3730A3]" /> Edit
                </label>
                <label className="flex items-center gap-1.5 text-[12px] cursor-pointer">
                  <input type="checkbox" checked={perms.canDelete} onChange={e => setSelectedPerms(p => ({ ...p, [c.code]: { ...perms, canDelete: e.target.checked } }))} className="accent-[#3730A3]" /> Delete
                </label>
              </div>
            )
          })}
        </div>
        <div className="flex gap-2.5 justify-end mt-5">
          <OutlineButton onClick={() => setEditingUser(null)}>Cancel</OutlineButton>
          <GoldButton onClick={() => editingUser && handleSavePermissions(editingUser)}><Check size={14} /> Save Permissions</GoldButton>
        </div>
      </Modal>

      {/* Lock User Modal */}
      <Modal open={!!lockModalUser} onClose={() => setLockModalUser(null)} title={`Lock User: ${lockModalUser?.username || ''}`}>
        <div className="space-y-4">
          <div className="bg-[rgba(220,38,38,0.08)] border border-[rgba(220,38,38,0.3)] rounded-lg p-3 text-[12px] text-[#DC2626]">
            Locking this user will prevent them from logging in or performing any actions.
            Their historical data (inventories, settlements, audit trail) will remain intact.
          </div>
          <FormField label="Lock Reason (optional)">
            <FormInput value={lockReason} onChange={e => setLockReason(e.target.value)} placeholder="e.g. Suspicious activity, end of contract, etc." autoFocus />
          </FormField>
          <div className="flex gap-2.5 justify-end">
            <OutlineButton onClick={() => setLockModalUser(null)}>Cancel</OutlineButton>
            <button onClick={handleLockUser} className="px-4 py-2 rounded-lg text-[12px] font-semibold bg-[#DC2626] text-white hover:bg-[#c23838] transition-colors flex items-center gap-1.5"><Lock size={14} /> Lock User</button>
          </div>
        </div>
      </Modal>

      {/* Assign Markets Modal */}
      <Modal open={!!marketsModalUser} onClose={() => setMarketsModalUser(null)} title={`Assign Markets: ${marketsModalUser?.username || ''}`} wide>
        <div className="space-y-3">
          <p className="text-[12px] text-[#6B7280]">Select which markets this user can access. Super admins automatically have access to all markets.</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {allMarkets.length === 0 ? (
              <div className="col-span-full text-[12px] text-[#9CA3AF] py-4">No markets configured. Add markets via Inventory Codes first.</div>
            ) : allMarkets.map(m => (
              <label key={m} className="flex items-center gap-2 bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 cursor-pointer hover:border-[#3730A3] transition-colors">
                <input
                  type="checkbox"
                  checked={marketsSelection.includes(m)}
                  onChange={e => setMarketsSelection(prev => e.target.checked ? [...prev, m] : prev.filter(x => x !== m))}
                  className="accent-[#3730A3]"
                />
                <span className="text-[12px] font-mono">{m}</span>
              </label>
            ))}
          </div>
          <div className="flex gap-2.5 justify-end mt-3">
            <OutlineButton onClick={() => setMarketsModalUser(null)}>Cancel</OutlineButton>
            <GoldButton onClick={handleSaveMarkets}><Check size={14} /> Save Markets</GoldButton>
          </div>
        </div>
      </Modal>

      {/* Edit Password Modal (Super Admin only) */}
      <Modal open={!!pwModalUser} onClose={() => setPwModalUser(null)} title={`Change Password: ${pwModalUser?.username || ''}`}>
        <div className="space-y-4">
          <div className="bg-[rgba(217,119,6,0.08)] border border-[rgba(217,119,6,0.3)] rounded-lg p-3 text-[12px] text-[#92400E]">
            The new password takes effect immediately. The user will need it on their next login.
          </div>
          <FormField label="New Password">
            <FormInput type="text" value={pwNew} onChange={e => setPwNew(e.target.value)} placeholder="Enter new password (min 4 chars)" autoFocus />
          </FormField>
          <div className="flex gap-2.5 justify-end">
            <OutlineButton onClick={() => setPwModalUser(null)}>Cancel</OutlineButton>
            <GoldButton onClick={handleSavePassword}><KeyRound size={14} /> Update Password</GoldButton>
          </div>
        </div>
      </Modal>
    </div>
  )
}

// ────────────────────────────────────────
// PHASE 2: SYSTEM MANAGEMENT PAGES
// ────────────────────────────────────────

export function MarketPermissionsPage() {
  const { currentUser } = useAppStore()
  const [users, setUsers] = useState<Array<Record<string, unknown>>>([])
  const [codes, setCodes] = useState<Array<Record<string, unknown>>>([])
  const [loading, setLoading] = useState(true)
  const [editingUser, setEditingUser] = useState<{ id: string; username: string; assignedMarkets: string } | null>(null)
  const [marketsSelection, setMarketsSelection] = useState<string[]>([])
  const [message, setMessage] = useState('')

  const refresh = () => {
    Promise.all([apiFetch('/api/users'), apiFetch('/api/inventory-codes')])
      .then(([u, c]) => { setUsers(u); setCodes(c); setLoading(false) })
      .catch(() => setLoading(false))
  }

  useEffect(() => { refresh() }, [])

  const codeList = codes as Array<{ code: string; name: string; market: string }>
  const allMarkets = Array.from(new Set(codeList.map(c => c.market).filter(Boolean))).sort()
  const userList = users as Array<{ id: string; username: string; name: string | null; role: string; assignedMarkets?: string; isLocked?: boolean }>

  const openEdit = (u: { id: string; username: string; assignedMarkets?: string }) => {
    setEditingUser({ id: u.id, username: u.username, assignedMarkets: u.assignedMarkets || '' })
    setMarketsSelection((u.assignedMarkets || '').split(',').map(s => s.trim()).filter(Boolean))
  }

  const handleSave = async () => {
    if (!editingUser) return
    try {
      await apiFetch(`/api/users/${editingUser.id}/markets`, {
        method: 'PUT',
        body: JSON.stringify({ markets: marketsSelection, updatedBy: currentUser?.username }),
      })
      setMessage(`Markets updated for "${editingUser.username}"`)
      setEditingUser(null)
      refresh()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Market Permissions</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Assign which markets each user can access. Super admins automatically have access to all markets.</p>
      </div>

      {message && (
        <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('updated') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{message}</div>
      )}

      <SectionCard title={`Available Markets (${allMarkets.length})`}>
        <div className="flex gap-2 flex-wrap">
          {allMarkets.length === 0 ? (
            <p className="text-[12px] text-[#9CA3AF]">No markets configured.</p>
          ) : allMarkets.map(m => (
            <span key={m} className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-[12px] font-mono text-[#6B7280]">{m}</span>
          ))}
        </div>
      </SectionCard>

      <SectionCard title={`User Market Assignments (${userList.length})`}>
        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                {['Username', 'Name', 'Role', 'Status', 'Assigned Markets', 'Actions'].map(h => (
                  <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
              ) : userList.map(u => {
                const userMarkets = (u.assignedMarkets || '').split(',').map(s => s.trim()).filter(Boolean)
                return (
                  <tr key={u.id} className={`border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)] ${u.isLocked ? 'opacity-60' : ''}`}>
                    <td className="px-3.5 py-3 font-mono text-[12px]">{u.username}</td>
                    <td className="px-3.5 py-3">{u.name || '\u2014'}</td>
                    <td className="px-3.5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full ${u.role === 'super' ? 'bg-[rgba(55,48,163,0.1)] text-[#3730A3]' : 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]'}`}>
                        {u.role === 'super' ? 'Super' : 'User'}
                      </span>
                    </td>
                    <td className="px-3.5 py-3"><StatusBadge status={u.isLocked ? 'locked' : 'active'} /></td>
                    <td className="px-3.5 py-3">
                      {u.role === 'super' ? (
                        <span className="text-[10px] text-[#3730A3] font-semibold uppercase tracking-wider">All Markets (implicit)</span>
                      ) : userMarkets.length === 0 ? (
                        <span className="text-[10px] text-[#DC2626]">No access</span>
                      ) : (
                        <div className="flex gap-1 flex-wrap">
                          {userMarkets.map(m => (
                            <span key={m} className="bg-[#FFFFFF] border border-[#E5E7EB] rounded px-1.5 py-0.5 text-[10px] font-mono text-[#6B7280]">{m}</span>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="px-3.5 py-3">
                      {u.role !== 'super' && (
                        <button onClick={() => openEdit(u)} className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-[rgba(2,132,199,0.1)] text-[#0284C7] hover:bg-[rgba(2,132,199,0.2)] border border-[rgba(2,132,199,0.3)] transition-all flex items-center gap-1"><Pencil size={12} /> Edit Markets</button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </SectionCard>

      <Modal open={!!editingUser} onClose={() => setEditingUser(null)} title={`Assign Markets: ${editingUser?.username || ''}`} wide>
        <div className="space-y-3">
          <p className="text-[12px] text-[#6B7280]">Select which markets this user can access.</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {allMarkets.map(m => (
              <label key={m} className="flex items-center gap-2 bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 cursor-pointer hover:border-[#3730A3] transition-colors">
                <input
                  type="checkbox"
                  checked={marketsSelection.includes(m)}
                  onChange={e => setMarketsSelection(prev => e.target.checked ? [...prev, m] : prev.filter(x => x !== m))}
                  className="accent-[#3730A3]"
                />
                <span className="text-[12px] font-mono">{m}</span>
              </label>
            ))}
          </div>
          <div className="flex gap-2.5 justify-end mt-3">
            <OutlineButton onClick={() => setEditingUser(null)}>Cancel</OutlineButton>
            <GoldButton onClick={handleSave}><Check size={14} /> Save Markets</GoldButton>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export function UserActivityPage() {
  const [data, setData] = useState<{
    activities: Array<{ id: string; userId: string | null; username: string; action: string; entity: string; entityId: string | null; market: string | null; recordsAffected: number; metadata: string; createdAt: string }>
    total: number
    summary: { byAction: Array<{ action: string; count: number }>; byUser: Array<{ username: string; count: number }>; byEntity: Array<{ entity: string; count: number }> }
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [filterAction, setFilterAction] = useState('')
  const [filterUser, setFilterUser] = useState('')
  const [limit, setLimit] = useState(100)

  useEffect(() => {
    setLoading(true)
    const params = new URLSearchParams()
    if (filterAction) params.set('action', filterAction)
    if (filterUser) params.set('username', filterUser)
    params.set('limit', String(limit))
    apiFetch(`/api/user-activity?${params.toString()}`)
      .then(d => { setData(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [filterAction, filterUser, limit])

  const formatMeta = (m: string) => {
    try { const o = JSON.parse(m); return Object.keys(o).length ? JSON.stringify(o, null, 2) : '' } catch { return '' }
  }
  const actionColor = (action: string) => {
    if (action.startsWith('login')) return 'text-[#059669]'
    if (action.startsWith('logout')) return 'text-[#9CA3AF]'
    if (action === 'create' || action === 'upload') return 'text-[#0284C7]'
    if (action === 'update' || action === 'update_markets') return 'text-[#D97706]'
    if (action === 'delete' || action === 'delete_hard' || action === 'lock' || action === 'login_blocked_locked') return 'text-[#DC2626]'
    if (action === 'unlock') return 'text-[#059669]'
    if (action.startsWith('chart_') || action.startsWith('parser_')) return 'text-[#3730A3]'
    return 'text-[#6B7280]'
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">User Activity</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Audit trail of all user actions across the system</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Total Events</div>
          <div className="text-[24px] font-bold text-[#3730A3] mt-1">{data?.total?.toLocaleString() || 0}</div>
        </div>
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Active Users</div>
          <div className="text-[24px] font-bold text-[#0284C7] mt-1">{data?.summary?.byUser?.length || 0}</div>
        </div>
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Action Types</div>
          <div className="text-[24px] font-bold text-[#059669] mt-1">{data?.summary?.byAction?.length || 0}</div>
        </div>
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Entities Touched</div>
          <div className="text-[24px] font-bold text-[#DC2626] mt-1">{data?.summary?.byEntity?.length || 0}</div>
        </div>
      </div>

      {/* Filters */}
      <SectionCard title="Filters">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <FormField label="Filter by Action">
            <FormSelect value={filterAction} onChange={e => setFilterAction(e.target.value)}>
              <option value="">All actions</option>
              {data?.summary?.byAction?.map(a => <option key={a.action} value={a.action}>{a.action}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="Filter by Username">
            <FormSelect value={filterUser} onChange={e => setFilterUser(e.target.value)}>
              <option value="">All users</option>
              {data?.summary?.byUser?.map(u => <option key={u.username} value={u.username}>{u.username}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="Limit">
            <FormSelect value={String(limit)} onChange={e => setLimit(parseInt(e.target.value))}>
              <option value="50">Last 50</option>
              <option value="100">Last 100</option>
              <option value="200">Last 200</option>
              <option value="500">Last 500</option>
            </FormSelect>
          </FormField>
        </div>
      </SectionCard>

      {/* Activity feed */}
      <SectionCard title={`Recent Activity (${data?.activities?.length || 0})`}>
        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                {['Timestamp', 'User', 'Action', 'Entity', 'Market', 'Records', 'Details'].map(h => (
                  <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
              ) : (data?.activities?.length || 0) === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-[#9CA3AF]">No activity recorded yet.</td></tr>
              ) : data?.activities.map(a => (
                <tr key={a.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)]">
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#6B7280]">{formatDateTime(a.createdAt)}</td>
                  <td className="px-3.5 py-3 font-mono text-[12px]">{a.username}</td>
                  <td className={`px-3.5 py-3 font-mono text-[11px] font-semibold ${actionColor(a.action)}`}>{a.action}</td>
                  <td className="px-3.5 py-3 text-[12px]">{a.entity || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[12px] font-mono">{a.market || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[12px] text-[#6B7280]">{a.recordsAffected}</td>
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#9CA3AF] max-w-md truncate">{formatMeta(a.metadata) || '\u2014'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

export function LockedUsersPage() {
  const { currentUser } = useAppStore()
  const [users, setUsers] = useState<Array<Record<string, unknown>>>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')

  const refresh = () => apiFetch('/api/users').then(setUsers).catch(console.error).finally(() => setLoading(false))
  useEffect(() => { refresh() }, [])

  const lockedUsers = (users as Array<{ id: string; username: string; name: string | null; role: string; isLocked: boolean; lockedAt: string | null; lockedBy: string | null; lockReason: string | null }>).filter(u => u.isLocked)

  const handleUnlock = async (id: string, username: string) => {
    if (!confirm(`Unlock user "${username}"? They will be able to login and perform actions again.`)) return
    try {
      await apiFetch(`/api/users/${id}/lock?unlockedBy=${encodeURIComponent(currentUser?.username || 'admin')}`, { method: 'DELETE' })
      setMessage(`User "${username}" unlocked`)
      refresh()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Locked Users</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">View and unlock user accounts that have been soft-deleted</p>
      </div>

      {message && (
        <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('unlocked') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{message}</div>
      )}

      <SectionCard title={`Locked Users (${lockedUsers.length})`}>
        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                {['Username', 'Name', 'Locked At', 'Locked By', 'Reason', 'Actions'].map(h => (
                  <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
              ) : lockedUsers.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-8 text-[#9CA3AF]">No locked users. All accounts are active.</td></tr>
              ) : lockedUsers.map(u => (
                <tr key={u.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(220,38,38,0.04)]">
                  <td className="px-3.5 py-3 font-mono text-[12px]">{u.username}</td>
                  <td className="px-3.5 py-3">{u.name || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#6B7280]">{u.lockedAt ? formatDateTime(u.lockedAt) : '\u2014'}</td>
                  <td className="px-3.5 py-3 font-mono text-[12px]">{u.lockedBy || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[12px] text-[#DC2626]">{u.lockReason || '\u2014'}</td>
                  <td className="px-3.5 py-3">
                    <button onClick={() => handleUnlock(u.id, u.username)} className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-[rgba(5,150,105,0.1)] text-[#059669] hover:bg-[rgba(5,150,105,0.2)] border border-[rgba(5,150,105,0.3)] transition-all flex items-center gap-1"><Unlock size={12} /> Unlock</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

export function ParserExceptionsPage() {
  const { currentUser } = useAppStore()
  const [data, setData] = useState<{
    exceptions: Array<{
      id: string; uploadedBy: string; originalText: string; market: string | null;
      reason: string; kind: string; rawNumber: string | null; parsedData: string | null;
      status: string; resolvedBy: string | null; resolvedAt: string | null; resolution: string | null;
      createdAt: string
    }>
    total: number
    summary: { open: number; resolved: number; ignored: number }
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('open')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [editing, setEditing] = useState<{ id: string; originalText: string; rawNumber: string | null } | null>(null)
  const [editNumber, setEditNumber] = useState('')
  const [editRate, setEditRate] = useState('')
  const [message, setMessage] = useState('')
  // Manual-add modal state (admin can create a new exception record by hand)
  const [showAddModal, setShowAddModal] = useState(false)
  const [addForm, setAddForm] = useState({ number: '', rate: '', market: '', kind: 'skipped', reason: 'manual_entry', originalText: '' })

  const refresh = () => {
    setLoading(true)
    apiFetch(`/api/parser-exceptions?status=${statusFilter}&limit=500`)
      .then(d => { setData(d); setLoading(false); setSelected(new Set()) })
      .catch(() => setLoading(false))
  }
  useEffect(() => { refresh() }, [statusFilter])

  const toggle = (id: string) => setSelected(prev => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n })
  const toggleAll = () => setSelected(prev => prev.size === (data?.exceptions?.length || 0) ? new Set() : new Set(data?.exceptions?.map(e => e.id) || []))

  const resolveOne = async (id: string, resolution: 'saved_manually' | 're_parsed' | 'ignored', resolutionData?: Record<string, unknown>) => {
    try {
      await apiFetch(`/api/parser-exceptions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: resolution === 'ignored' ? 'ignored' : 'resolved',
          resolution,
          resolutionData: resolutionData || null,
          resolvedBy: currentUser?.username,
          resolvedByUserId: currentUser?.id,
        }),
      })
      setMessage(`Exception ${id.substring(0, 8)} marked as "${resolution.replace('_', ' ')}"`)
      refresh()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const bulkAction = async (action: 'resolve' | 'ignore') => {
    if (selected.size === 0) return
    if (!confirm(`${action === 'resolve' ? 'Resolve' : 'Ignore'} ${selected.size} exception(s)?`)) return
    const ids = Array.from(selected)
    try {
      await Promise.all(ids.map(id =>
        apiFetch(`/api/parser-exceptions/${id}`, {
          method: 'PATCH',
          body: JSON.stringify({
            status: action === 'ignore' ? 'ignored' : 'resolved',
            resolution: action === 'ignore' ? 'ignored' : 'saved_manually',
            resolvedBy: currentUser?.username,
            resolvedByUserId: currentUser?.id,
          }),
        })
      ))
      setMessage(`${ids.length} exception(s) ${action === 'ignore' ? 'ignored' : 'resolved'}`)
      refresh()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Bulk action failed')
    }
  }

  const handleEditSave = async () => {
    if (!editing) return
    try {
      await apiFetch(`/api/parser-exceptions/${editing.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: 'resolved',
          resolution: 'edited',
          resolutionData: { number: editNumber, rate: editRate ? parseFloat(editRate) : null },
          resolvedBy: currentUser?.username,
          resolvedByUserId: currentUser?.id,
        }),
      })
      setMessage(`Exception resolved with edited data`)
      setEditing(null)
      setEditNumber('')
      setEditRate('')
      refresh()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  // Manual-add: POST a new exception record to the API
  const handleManualAdd = async () => {
    if (!addForm.number) { setMessage('Panna number is required'); return }
    try {
      await apiFetch('/api/parser-exceptions', {
        method: 'POST',
        body: JSON.stringify({
          uploadedBy: currentUser?.username || 'admin',
          uploadedByUserId: currentUser?.id,
          market: addForm.market || null,
          inventoryCodeId: null,
          originalText: addForm.originalText || `Manual entry: ${addForm.number}=${addForm.rate || 0}₹`,
          reason: addForm.reason,
          kind: addForm.kind,
          rawNumber: addForm.number,
          parsedData: JSON.stringify({ number: addForm.number, rate: addForm.rate ? parseFloat(addForm.rate) : 0 }),
          status: 'open',
        }),
      })
      setMessage(`Exception added manually for panna ${addForm.number}`)
      setShowAddModal(false)
      setAddForm({ number: '', rate: '', market: '', kind: 'skipped', reason: 'manual_entry', originalText: '' })
      refresh()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed to add exception')
    }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Parser Exceptions</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Review, edit, re-parse, save manually, or ignore records skipped or dropped by the WhatsApp parser</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowAddModal(true)} className="px-3 py-1.5 rounded-md text-[11px] font-medium bg-[rgba(55,48,163,0.1)] text-[#3730A3] hover:bg-[rgba(55,48,163,0.2)] border border-[rgba(55,48,163,0.3)] transition-all flex items-center gap-1"><Plus size={12} /> Add Manually</button>
          <button onClick={() => bulkAction('resolve')} disabled={selected.size === 0} className="px-3 py-1.5 rounded-md text-[11px] font-medium bg-[rgba(5,150,105,0.1)] text-[#059669] hover:bg-[rgba(5,150,105,0.2)] border border-[rgba(5,150,105,0.3)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"><Check size={12} /> Resolve Selected ({selected.size})</button>
          <button onClick={() => bulkAction('ignore')} disabled={selected.size === 0} className="px-3 py-1.5 rounded-md text-[11px] font-medium bg-[rgba(217,119,6,0.1)] text-[#D97706] hover:bg-[rgba(217,119,6,0.2)] border border-[rgba(217,119,6,0.3)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"><X size={12} /> Ignore Selected</button>
        </div>
      </div>

      {message && (
        <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('resolved') || message.includes('ignored') || message.includes('marked') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{message}</div>
      )}

      {/* Summary */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Open</div>
          <div className="text-[24px] font-bold text-[#D97706] mt-1">{data?.summary?.open || 0}</div>
        </div>
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Resolved</div>
          <div className="text-[24px] font-bold text-[#059669] mt-1">{data?.summary?.resolved || 0}</div>
        </div>
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Ignored</div>
          <div className="text-[24px] font-bold text-[#9CA3AF] mt-1">{data?.summary?.ignored || 0}</div>
        </div>
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">Total</div>
          <div className="text-[24px] font-bold text-[#3730A3] mt-1">{data?.total || 0}</div>
        </div>
      </div>

      {/* Filter */}
      <SectionCard title="Filter">
        <FormField label="Status">
          <FormSelect value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="open">Open</option>
            <option value="resolved">Resolved</option>
            <option value="ignored">Ignored</option>
            <option value="all">All</option>
          </FormSelect>
        </FormField>
      </SectionCard>

      {/* Exceptions table */}
      <SectionCard title={`Exceptions (${data?.exceptions?.length || 0})`}>
        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                <th className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] w-8">
                  <input type="checkbox" checked={selected.size > 0 && selected.size === (data?.exceptions?.length || 0)} onChange={toggleAll} className="accent-[#3730A3]" />
                </th>
                {['Created', 'Uploaded By', 'Kind', 'Reason', 'Number', 'Market', 'Original Text', 'Status', 'Actions'].map(h => (
                  <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={9} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
              ) : (data?.exceptions?.length || 0) === 0 ? (
                <tr><td colSpan={9} className="text-center py-8 text-[#9CA3AF]">No exceptions in this view.</td></tr>
              ) : data?.exceptions.map(ex => (
                <tr key={ex.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)]">
                  <td className="px-3.5 py-3">
                    <input type="checkbox" checked={selected.has(ex.id)} onChange={() => toggle(ex.id)} className="accent-[#3730A3]" />
                  </td>
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#6B7280]">{formatDateTime(ex.createdAt)}</td>
                  <td className="px-3.5 py-3 font-mono text-[12px]">{ex.uploadedBy}</td>
                  <td className="px-3.5 py-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${ex.kind === 'skipped' ? 'bg-[rgba(217,119,6,0.1)] text-[#D97706]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{ex.kind}</span>
                  </td>
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#6B7280]">{ex.reason}</td>
                  <td className="px-3.5 py-3 font-mono text-[12px]">{ex.rawNumber || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[12px]">{ex.market || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#9CA3AF] max-w-xs truncate" title={ex.originalText}>{ex.originalText}</td>
                  <td className="px-3.5 py-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${ex.status === 'open' ? 'bg-[rgba(217,119,6,0.1)] text-[#D97706]' : ex.status === 'resolved' ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(156,163,175,0.1)] text-[#9CA3AF]'}`}>{ex.status}</span>
                  </td>
                  <td className="px-3.5 py-3">
                    {ex.status === 'open' && (
                      <div className="flex gap-1">
                        <button title="Edit & save manually" onClick={() => { setEditing({ id: ex.id, originalText: ex.originalText, rawNumber: ex.rawNumber }); setEditNumber(ex.rawNumber || ''); setEditRate('') }} className="w-7 h-7 rounded-md flex items-center justify-center text-[#D97706] hover:bg-[rgba(217,119,6,0.1)] border border-transparent hover:border-[rgba(217,119,6,0.3)] transition-all"><Pencil size={12} /></button>
                        <button title="Mark as re-parsed" onClick={() => resolveOne(ex.id, 're_parsed')} className="w-7 h-7 rounded-md flex items-center justify-center text-[#0284C7] hover:bg-[rgba(2,132,199,0.1)] border border-transparent hover:border-[rgba(2,132,199,0.3)] transition-all"><RotateCcw size={12} /></button>
                        <button title="Save manually" onClick={() => resolveOne(ex.id, 'saved_manually')} className="w-7 h-7 rounded-md flex items-center justify-center text-[#059669] hover:bg-[rgba(5,150,105,0.1)] border border-transparent hover:border-[rgba(5,150,105,0.3)] transition-all"><Check size={12} /></button>
                        <button title="Ignore" onClick={() => resolveOne(ex.id, 'ignored')} className="w-7 h-7 rounded-md flex items-center justify-center text-[#9CA3AF] hover:bg-[rgba(156,163,175,0.1)] border border-transparent hover:border-[rgba(156,163,175,0.3)] transition-all"><X size={12} /></button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>

      {/* Edit modal */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title="Edit & Save Exception Manually" wide>
        <div className="space-y-3">
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF] mb-1">Original Text</div>
            <pre className="text-[12px] font-mono text-[#6B7280] whitespace-pre-wrap">{editing?.originalText}</pre>
          </div>
          <FormField label="Panna Number">
            <FormInput value={editNumber} onChange={e => setEditNumber(e.target.value)} placeholder="e.g. 128" />
          </FormField>
          <FormField label="Rate (₹)">
            <FormInput value={editRate} onChange={e => setEditRate(e.target.value)} placeholder="e.g. 500" type="number" />
          </FormField>
          <div className="flex gap-2.5 justify-end">
            <OutlineButton onClick={() => setEditing(null)}>Cancel</OutlineButton>
            <GoldButton onClick={handleEditSave}><Check size={14} /> Save & Resolve</GoldButton>
          </div>
        </div>
      </Modal>

      {/* Manual-add modal — admin can create a new exception record by hand */}
      <Modal open={showAddModal} onClose={() => setShowAddModal(false)} title="Add Exception Manually" wide>
        <div className="space-y-3">
          <p className="text-[12px] text-[#6B7280]">Use this form to manually create a parser exception record — for example, when an operator reports a bet that the WhatsApp parser missed entirely (no upload context).</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <FormField label="Panna Number (required)">
              <FormInput value={addForm.number} onChange={e => setAddForm(f => ({ ...f, number: e.target.value }))} placeholder="e.g. 128" />
            </FormField>
            <FormField label="Rate (₹)">
              <FormInput value={addForm.rate} onChange={e => setAddForm(f => ({ ...f, rate: e.target.value }))} placeholder="e.g. 500" type="number" />
            </FormField>
            <FormField label="Market (optional)">
              <FormInput value={addForm.market} onChange={e => setAddForm(f => ({ ...f, market: e.target.value }))} placeholder="e.g. kalyan" />
            </FormField>
            <FormField label="Kind">
              <FormSelect value={addForm.kind} onChange={e => setAddForm(f => ({ ...f, kind: e.target.value }))}>
                <option value="skipped">skipped</option>
                <option value="dropped">dropped</option>
              </FormSelect>
            </FormField>
            <FormField label="Reason">
              <FormInput value={addForm.reason} onChange={e => setAddForm(f => ({ ...f, reason: e.target.value }))} placeholder="e.g. manual_entry, missing_rate" />
            </FormField>
            <FormField label="Original Text (optional)">
              <FormInput value={addForm.originalText} onChange={e => setAddForm(f => ({ ...f, originalText: e.target.value }))} placeholder="context for this manual entry" />
            </FormField>
          </div>
          <div className="flex gap-2.5 justify-end">
            <OutlineButton onClick={() => setShowAddModal(false)}>Cancel</OutlineButton>
            <GoldButton onClick={handleManualAdd}><Plus size={14} /> Add Exception</GoldButton>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export function ParserConfigPage() {
  // Custom patterns textarea — admin can paste examples of new patterns the
  // parser should evolve to handle. These are stored in localStorage as a
  // living catalog (not yet auto-applied to the parser — used for review
  // and to drive future parser updates).
  const [customPatterns, setCustomPatterns] = useState('')
  const [customNotes, setCustomNotes] = useState('')
  const [saveMsg, setSaveMsg] = useState('')

  // Simple Parser Generator state
  const [addPatternMode, setAddPatternMode] = useState<'simple' | 'advanced'>('simple')
  const [simplePattern, setSimplePattern] = useState({
    ankFormat: 'double',
    ankSeparator: 'none',
    ankRateSep: '---',
    rateSuffix: 'none',
    appliesTo: 'double',
  })
  const [generatedRegex, setGeneratedRegex] = useState('')
  const [testInput, setTestInput] = useState('')
  const [testResult, setTestResult] = useState<{ matched: boolean; numbers: string[]; rate: number } | null>(null)

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem('erp_custom_parser_patterns_v1')
      if (raw) {
        const parsed = JSON.parse(raw)
        setCustomPatterns(parsed.patterns || '')
        setCustomNotes(parsed.notes || '')
      }
    } catch { /* ignore */ }
  }, [])

  const generatePatternFromSimple = useCallback(() => {
    const { ankFormat, ankSeparator, ankRateSep, rateSuffix } = simplePattern
    let ankRe = ''
    let sepRe = ''
    let rateSuffixRe = ''

    switch (ankFormat) {
      case 'single': ankRe = '(\\d{1})'; break
      case 'double': ankRe = '(\\d{2})'; break
      case 'triple': ankRe = '(\\d{3})'; break
      case 'any': ankRe = '(\\d{1,3})'; break
    }

    if (ankSeparator !== 'none' && (ankFormat === 'double' || ankFormat === 'triple' || ankFormat === 'any')) {
      switch (ankSeparator) {
        case 'comma': sepRe = '(?:,' + ankRe + ')+'; break
        case 'space': sepRe = '(?:\\s+' + ankRe + ')+'; break
        case 'dot': sepRe = '(?:\\.' + ankRe + ')+'; break
      }
    }

    let arSepRe = ''
    switch (ankRateSep) {
      case '---': arSepRe = '-{2,}'; break
      case '.': arSepRe = '\\.'; break
      case '=': arSepRe = '='; break
      case '\u00d7': arSepRe = '\\u00d7'; break
      case '-': arSepRe = '-'; break
      case '/': arSepRe = '/'; break
      case '..': arSepRe = '\\.{2,}'; break
      case '*': arSepRe = '\\*'; break
    }

    if (rateSuffix !== 'none') {
      rateSuffixRe = '\\s*(?:rs)?\\s*$'
    } else {
      rateSuffixRe = '\\s*$'
    }

    let fullRe = ''
    if (ankSeparator === 'none') {
      fullRe = '^' + ankRe + arSepRe + '\\s*(\\d+)' + rateSuffixRe
    } else {
      fullRe = '^' + ankRe + sepRe + arSepRe + '\\s*(\\d+)' + rateSuffixRe
    }

    return fullRe
  }, [simplePattern])

  useEffect(() => {
    if (addPatternMode === 'simple') {
      setGeneratedRegex(generatePatternFromSimple())
    }
  }, [addPatternMode, generatePatternFromSimple])

  const handleTestPattern = () => {
    if (!generatedRegex || !testInput.trim()) { setTestResult(null); return }
    try {
      const re = new RegExp(generatedRegex, 'i')
      const match = testInput.trim().match(re)
      if (match) {
        const rate = parseInt(match[match.length - 1]) || 0
        const numbers: string[] = []
        for (let i = 1; i < match.length - 1; i++) {
          if (match[i]) numbers.push(match[i])
        }
        setTestResult({ matched: true, numbers, rate })
      } else {
        setTestResult({ matched: false, numbers: [], rate: 0 })
      }
    } catch {
      setTestResult({ matched: false, numbers: [], rate: 0 })
    }
  }

  const handleSavePatterns = () => {
    try {
      window.localStorage.setItem('erp_custom_parser_patterns_v1', JSON.stringify({
        patterns: customPatterns,
        notes: customNotes,
        savedAt: new Date().toISOString(),
      }))
      setSaveMsg('Custom patterns saved! These will be reviewed for inclusion in the next parser update.')
      setTimeout(() => setSaveMsg(''), 5000)
    } catch {
      setSaveMsg('Failed to save patterns to browser storage')
    }
  }

  const currentUser = useAppStore(s => s.currentUser)
  const isMaster = currentUser?.role === 'super'

  const simplePreview = (() => {
    const { ankFormat, ankSeparator, ankRateSep, rateSuffix } = simplePattern
    const ankExample = ankFormat === 'single' ? '7' : ankFormat === 'double' ? '07' : ankFormat === 'triple' ? '257' : '07'
    const sepStr = ankSeparator === 'comma' ? ',' : ankSeparator === 'space' ? ' ' : ankSeparator === 'dot' ? '.' : ''
    const multiAnk = ankSeparator !== 'none' ? sepStr + '53' + sepStr + '82' : ''
    return ankExample + multiAnk + ankRateSep + '1500' + (rateSuffix !== 'none' ? 'rs' : '')
  })()

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Parser Configuration</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Reference documentation of the 24 WhatsApp parser grammar patterns + custom pattern catalog</p>
      </div>

      {/* Simple Parser Generator */}
      <SectionCard title="Add Pattern" headerRight={
        <div className="flex gap-1">
          <button onClick={() => setAddPatternMode('simple')} className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-colors ${addPatternMode === 'simple' ? 'bg-[#3730A3] text-white' : 'bg-[#F5F6FA] text-[#6B7280] hover:bg-[#E5E7EB]'}`}>Simple Builder</button>
          <button onClick={() => setAddPatternMode('advanced')} className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-colors ${addPatternMode === 'advanced' ? 'bg-[#3730A3] text-white' : 'bg-[#F5F6FA] text-[#6B7280] hover:bg-[#E5E7EB]'}`}>Advanced</button>
        </div>
      }>
        {addPatternMode === 'simple' ? (
          <div className="space-y-4">
            <div className="bg-[#F5F6FA] rounded-lg p-3 text-center">
              <div className="text-[10px] text-[#9CA3AF] uppercase tracking-wider mb-1">Pattern Preview</div>
              <div className="font-mono text-[16px] font-bold">
                <span className="text-[#3730A3]">{simplePreview}</span>
              </div>
              <div className="text-[11px] text-[#6B7280] mt-1">Select options below to build a pattern. No regex knowledge needed.</div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <FormField label="Ank Format">
                <select value={simplePattern.ankFormat} onChange={e => setSimplePattern(p => ({ ...p, ankFormat: e.target.value }))} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] focus:outline-none focus:border-[#3730A3]">
                  <option value="single">Single</option>
                  <option value="double">Double</option>
                  <option value="triple">Triple</option>
                  <option value="any">Any</option>
                </select>
              </FormField>
              <FormField label="Ank Separator">
                <select value={simplePattern.ankSeparator} onChange={e => setSimplePattern(p => ({ ...p, ankSeparator: e.target.value }))} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] focus:outline-none focus:border-[#3730A3]">
                  <option value="none">None</option>
                  <option value="comma">Comma</option>
                  <option value="space">Space</option>
                  <option value="dot">Dot</option>
                </select>
              </FormField>
              <FormField label="Ank-Rate Separator">
                <select value={simplePattern.ankRateSep} onChange={e => setSimplePattern(p => ({ ...p, ankRateSep: e.target.value }))} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] focus:outline-none focus:border-[#3730A3]">
                  <option value="---">---</option>
                  <option value=".">.</option>
                  <option value="=">=</option>
                  <option value="×">×</option>
                  <option value="-">-</option>
                  <option value="/">/</option>
                  <option value="..">..</option>
                  <option value="*">*</option>
                </select>
              </FormField>
              <FormField label="Rate Suffix">
                <select value={simplePattern.rateSuffix} onChange={e => setSimplePattern(p => ({ ...p, rateSuffix: e.target.value }))} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] focus:outline-none focus:border-[#3730A3]">
                  <option value="none">No suffix</option>
                  <option value="optional">Optional "rs"</option>
                </select>
              </FormField>
              <FormField label="Applies To">
                <select value={simplePattern.appliesTo} onChange={e => setSimplePattern(p => ({ ...p, appliesTo: e.target.value }))} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] focus:outline-none focus:border-[#3730A3]">
                  <option value="double">Double</option>
                  <option value="single">Single</option>
                  <option value="triple">Triple</option>
                  <option value="all">All Modes</option>
                </select>
              </FormField>
            </div>
            <div className="bg-[#111827] rounded-lg p-3">
              <div className="text-[10px] text-[#9CA3AF] uppercase tracking-wider mb-1">Generated Regex</div>
              <code className="text-[12px] font-mono text-[#10B981] break-all">{generatedRegex || 'Select options above...'}</code>
            </div>
            <div className="flex gap-2 items-end">
              <FormField label="Test Input" className="flex-1">
                <input value={testInput} onChange={e => setTestInput(e.target.value)} placeholder={simplePreview} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] font-mono focus:outline-none focus:border-[#3730A3]" />
              </FormField>
              <button onClick={handleTestPattern} className="px-4 py-2 rounded-lg text-[12px] font-semibold bg-[#3730A3] text-white hover:bg-[#4338CA] transition-colors mb-0.5">Test</button>
            </div>
            {testResult && (
              <div className={`rounded-lg p-3 text-[12px] ${testResult.matched ? 'bg-[rgba(5,150,105,0.1)] border border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] border border-[rgba(220,38,38,0.3)]'}`}>
                {testResult.matched ? (
                  <div><span className="text-[#059669] font-semibold">Match!</span>{' '}
                  Numbers: <span className="font-mono text-[#3730A3]">[{testResult.numbers.join(', ')}]</span>{' '}
                  Rate: <span className="font-mono text-[#059669] font-bold">₹{testResult.rate}</span></div>
                ) : (
                  <span className="text-[#DC2626] font-semibold">No match — pattern does not match this input</span>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-[12px] text-[#6B7280] mb-3">When you encounter a new WhatsApp input pattern that the parser doesn't handle correctly, paste example lines below.</p>
            <FormField label="New pattern examples (one per line)">
              <textarea value={customPatterns} onChange={e => setCustomPatterns(e.target.value)} placeholder={`Example:
489,478,128==200\u20b9
580-690-700*150\u20b9
389=100\u20b9 extra note`} rows={6} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] font-mono text-[#3730A3] focus:outline-none focus:border-[#3730A3] focus:ring-1 focus:ring-[#3730A3]/30 resize-y" />
            </FormField>
            <FormField label="Notes / expected behavior">
              <textarea value={customNotes} onChange={e => setCustomNotes(e.target.value)} placeholder="Describe what the parser SHOULD produce for each example" rows={3} className="w-full bg-[#F5F6FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[12px] text-[#6B7280] focus:outline-none focus:border-[#3730A3] focus:ring-1 focus:ring-[#3730A3]/30 resize-y" />
            </FormField>
            {saveMsg && (
              <div className={`text-[12px] px-3 py-2 rounded-lg mt-2 ${saveMsg.includes('saved') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{saveMsg}</div>
            )}
            <div className="mt-3">
              <GoldButton onClick={handleSavePatterns}><Check size={14} /> Save Patterns</GoldButton>
            </div>
          </div>
        )}
      </SectionCard>

      <SectionCard title="Supported Input Patterns (24 Grammar Types)">
        <div className="space-y-3 text-[13px] text-[#6B7280]">
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 1 — Single Number + Amount</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">489.50₹
156.15₹
349.100₹</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Rule: NUMBER + sep + AMOUNT. Separators: . .. ... .... ..... = == === + - * : _</div>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 2 — Multiple Numbers Share Same Amount</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">366/690/456/489/128/579...50₹
129/246/147=100₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 3 — Comma Separated Group</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">347,356,590,267.....200₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 4 — Dot Separated Group</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">123.135.158.125.136.159.126.138.168.150rs</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 5 — Hyphen Separated Group</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">145-127-230-129..25₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 6 — Colon Separated Group</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">128:560:129:679:148...700₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 7 — Space Separated Group</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">119 110 112 113 114 115 116 117 118 ...350₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 8 — Matrix Format (multi-line carry-forward)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">155,669,588,227
499,110,228,336
229,300,445,337
299,488,677,334+150₹</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Every number in matrix gets 150. Pending buffer flushes when the rate suffix appears.</div>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 9 — Assignment Format</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">680=200₹
770=100₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 10 — Star Format</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">178*200₹
778*100₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 11 — Plus Format (separator, NOT addition)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">470+200₹
345+100₹</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Plus is just a separator here — not arithmetic addition.</div>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 12 — Pending Numbers (buffer pattern)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">488
448
247
389
377..50₹</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Each pending panna inherits the rate from the next rate-suffixed line.</div>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 13 — Mixed Pending Block</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">577
469
356..25₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 14 — Multi-Line Carry Forward (underscore separator)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">159
357___370₹
---
580
355
690
680
890___120₹</pre>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 15 — Multiple Groups One Line</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">280.357=200₹
367.467=50₹</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Dot-separated pannas + = + amount. Both pannas share the rate.</div>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 16 — Garbage Noise (ignored)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">Mob, MB, Mb, M.B, Mo, NMB, DMO, DMB, Mo.ko, Mb.kb, ========, Total, Rs</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Parser strips these as prefixes or drops the entire line if it's only noise.</div>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 17 — Amount At End</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">566 166 660 150₹</pre>
            <div className="text-[11px] text-[#9CA3AF] mt-1">Last numeric token is the amount. Previous tokens are pannas.</div>
          </div>
          <div className="bg-[rgba(55,48,163,0.08)] border border-[rgba(55,48,163,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#3730A3] mb-1">Type 18 — Special Duplicate Aggregation (CRITICAL)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">389=260₹
389=30₹
→ becomes 389=290₹ (NOT 30, NOT 260)</pre>
            <div className="text-[11px] text-[#3730A3] mt-1">Always aggregate duplicate pannas by summing their rates. Stage 5 of the parser enforces this.</div>
          </div>
          <div className="bg-[rgba(220,38,38,0.08)] border border-[rgba(220,38,38,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#DC2626] mb-1">Type 19 — Triple Zero (CRITICAL)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">000=25₹ → 000=25 (keep as "000", NEVER convert to "0")</pre>
            <div className="text-[11px] text-[#DC2626] mt-1">The "000" panna is a valid betting number. The formatPanna() function has an explicit guard to preserve it.</div>
          </div>
          <div className="bg-[rgba(5,150,105,0.08)] border border-[rgba(5,150,105,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#059669] mb-1">Type 20 — Comma + Dash + Amount (NEW)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">00,02,60,67,66---1500
07---2500</pre>
            <div className="text-[11px] text-[#059669] mt-1">Comma-separated 2-digit numbers + triple-dash + amount. Each number gets the rate.</div>
          </div>
          <div className="bg-[rgba(5,150,105,0.08)] border border-[rgba(5,150,105,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#059669] mb-1">Type 21 — Comma + Dot + Amount with "rs" (NEW)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">00,02,60,67,66.1500rs
00,02,60,67,66.1500</pre>
            <div className="text-[11px] text-[#059669] mt-1">Comma-separated 2-digit numbers + dot + amount (3+ digits) + optional "rs". Each number gets the rate.</div>
          </div>
          <div className="bg-[rgba(5,150,105,0.08)] border border-[rgba(5,150,105,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#059669] mb-1">Type 22 — Dot-Group + Equals + Amount (NEW)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">53.57.13.07=75rs
53.57.13.07.32.98.97.04=75rs</pre>
            <div className="text-[11px] text-[#059669] mt-1">Dot-separated 2-digit numbers + = + amount + "rs". Each number gets the rate. Used in Milan/Jodi format.</div>
          </div>
          <div className="bg-[rgba(5,150,105,0.08)] border border-[rgba(5,150,105,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#059669] mb-1">Type 23 — Single Number + Dot + Amount (NEW)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">07.2500rs
07.2500</pre>
            <div className="text-[11px] text-[#059669] mt-1">Single 2-digit number + dot + 3+ digit amount + optional "rs". Auto-detected: 3+ digits after dot = amount, not another number.</div>
          </div>
          <div className="bg-[rgba(5,150,105,0.08)] border border-[rgba(5,150,105,0.3)] rounded-lg p-3">
            <div className="text-[12px] font-semibold text-[#059669] mb-1">Type 24 — Space + Dash + Amount (NEW)</div>
            <pre className="text-[11px] font-mono text-[#9CA3AF] whitespace-pre-wrap">00 02 60 67 66---1500
07---2500</pre>
            <div className="text-[11px] text-[#059669] mt-1">Space-separated 2-digit numbers + triple-dash + amount. Each number gets the rate.</div>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="5-Stage Parser Pipeline">
        <ol className="text-[12px] text-[#6B7280] space-y-2 list-decimal pl-5">
          <li><strong>Stage 1 — Remove WhatsApp metadata:</strong> Strip <code className="bg-[#FFFFFF] px-1.5 py-0.5 rounded text-[#3730A3]">[date, time] Author:</code> prefixes, phone numbers, timestamps.</li>
          <li><strong>Stage 2 — Remove noise words:</strong> Drop Type-16 garbage (Mob, MB, DMO, etc.) as prefixes or entire lines.</li>
          <li><strong>Stage 3 — Normalize separators:</strong> Treat <code className="bg-[#FFFFFF] px-1.5 py-0.5 rounded text-[#3730A3]">. , .. , ... , = , + , * , - , : , / , _</code> as interchangeable. Collapse runs of separators.</li>
          <li><strong>Stage 4 — Extract pannas[] and amount:</strong> The last numeric token before ₹/rs is the amount; everything before is a panna list. Lines with no rate go to a pending buffer.</li>
          <li><strong>Stage 5 — Aggregate:</strong> Sum rates for duplicate panna numbers (Type 18). Never replace — always add.</li>
        </ol>
      </SectionCard>

      <SectionCard title="Skipped vs Dropped Records">
        <div className="space-y-3 text-[12px] text-[#6B7280]">
          <div className="bg-[rgba(217,119,6,0.08)] border border-[rgba(217,119,6,0.3)] rounded-lg p-3">
            <div className="font-semibold text-[#D97706] mb-1">SKIPPED (kind = "skipped")</div>
            Valid panna number (3 digits, recognized format) but missing rate/amount. The parser leaves it as a stub entry with price=0 and pushes it to the SKIPPED list for manual review.
          </div>
          <div className="bg-[rgba(220,38,38,0.08)] border border-[rgba(220,38,38,0.3)] rounded-lg p-3">
            <div className="font-semibold text-[#DC2626] mb-1">DROPPED (kind = "dropped")</div>
            Invalid token or syntax — not a recognizable 3-digit panna. Pushed to the DROPPED list. Usually means a typo, a chat message that isn't a bet, or a non-numeric token.
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Recovery Workflow">
        <ol className="text-[12px] text-[#6B7280] space-y-2 list-decimal pl-5">
          <li>When you upload WhatsApp text, the parser produces entries, skipped numbers, and dropped tokens.</li>
          <li>Skipped and dropped records are sent to <code className="bg-[#FFFFFF] px-1.5 py-0.5 rounded text-[#3730A3]">/api/parser-exceptions</code> and shown on the Parser Exceptions page.</li>
          <li>From the Parser Exceptions page you can: <strong>Edit &amp; Save Manually</strong> (provides number + rate), <strong>Re-parse</strong> (mark for re-parsing), <strong>Save Manually</strong> (accept as-is), <strong>Ignore</strong> (dismiss as not a real entry), or <strong>Add Manually</strong> (create a new exception record by hand when no upload context exists).</li>
          <li>Bulk actions: Resolve Selected or Ignore Selected for batch processing.</li>
          <li>Resolved/ignored records are kept for audit trail; they don't appear in the default Open view.</li>
        </ol>
      </SectionCard>
    </div>
  )
}

// ── Pending Signups Page (Gap 2) ──
export function PendingSignupsPage() {
  const [pendingUsers, setPendingUsers] = useState<Array<{ id: string; username: string; name: string; email?: string; phone?: string; requestedRole?: string; createdAt: string }>>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [message, setMessage] = useState('')

  const fetchPending = useCallback(() => {
    setLoading(true)
    apiFetch('/api/users/pending')
      .then((data: { users: Array<{ id: string; username: string; name: string; email?: string; phone?: string; requestedRole?: string; createdAt: string }> }) => {
        setPendingUsers(data.users || [])
        setLoading(false)
      })
      .catch(() => { setPendingUsers([]); setLoading(false) })
  }, [])

  useEffect(() => { fetchPending() }, [fetchPending])

  const handleApprove = async (id: string) => {
    setActionLoading(id)
    setMessage('')
    try {
      await apiFetch(`/api/users/${id}/approve`, { method: 'POST' })
      setMessage('User approved successfully')
      fetchPending()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Approval failed')
    }
    setActionLoading(null)
  }

  const handleReject = async (id: string) => {
    setActionLoading(id)
    setMessage('')
    try {
      await apiFetch(`/api/users/${id}/approve`, { method: 'DELETE' })
      setMessage('Signup rejected')
      fetchPending()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Rejection failed')
    }
    setActionLoading(null)
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Pending Signups</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Review and approve or reject new account requests</p>
      </div>

      {message && (
        <div className={`${message.includes('success') || message.includes('rejected') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
          {message.includes('success') || message.includes('rejected') ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />} {message}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12 text-[#9CA3AF]">
          <RefreshCw size={20} className="animate-spin mr-2" /> Loading pending signups...
        </div>
      ) : pendingUsers.length === 0 ? (
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-8 text-center">
          <UserPlus size={32} className="mx-auto text-[#9CA3AF] mb-3" />
          <p className="text-[13px] text-[#6B7280]">No pending signup requests</p>
        </div>
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl overflow-hidden">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                <th className="text-left px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Username</th>
                <th className="text-left px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Name</th>
                <th className="text-left px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Email</th>
                <th className="text-left px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Phone</th>
                <th className="text-left px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Requested As</th>
                <th className="text-left px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Requested</th>
                <th className="text-right px-4 py-3 font-semibold text-[#9CA3AF] uppercase tracking-wider text-[10px]">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pendingUsers.map((user, i) => (
                <tr key={user.id} className={`border-b border-[#E5E7EB] ${i % 2 === 1 ? 'bg-[#F9FAFB]' : ''}`}>
                  <td className="px-4 py-3 text-[#111827] font-medium">{user.username}</td>
                  <td className="px-4 py-3 text-[#6B7280]">{user.name || '—'}</td>
                  <td className="px-4 py-3 text-[#6B7280]">{user.email || '—'}</td>
                  <td className="px-4 py-3 text-[#6B7280]">{user.phone || '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[11px] px-2 py-0.5 rounded-full ${user.requestedRole === 'manager' ? 'bg-[rgba(124,58,237,0.1)] text-[#7C3AED]' : 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]'}`}>
                      {user.requestedRole === 'manager' ? 'Admin' : 'Agent'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-[#6B7280]">{new Date(user.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleApprove(user.id)}
                        disabled={actionLoading === user.id}
                        className="px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-[rgba(5,150,105,0.1)] text-[#059669] border border-[rgba(5,150,105,0.3)] hover:bg-[rgba(5,150,105,0.2)] disabled:opacity-50 transition-colors"
                      >
                        {actionLoading === user.id ? '...' : 'Approve'}
                      </button>
                      <button
                        onClick={() => handleReject(user.id)}
                        disabled={actionLoading === user.id}
                        className="px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-[rgba(220,38,38,0.1)] text-[#DC2626] border border-[rgba(220,38,38,0.3)] hover:bg-[rgba(220,38,38,0.2)] disabled:opacity-50 transition-colors"
                      >
                        {actionLoading === user.id ? '...' : 'Reject'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export function ChartRevisionsPage() {
  const [revisions, setRevisions] = useState<Array<{
    id: string; chartId: string; editedBy: string; action: string;
    summary: string | null; previousData: string; newData: string;
    createdAt: string
  }>>([])
  const [loading, setLoading] = useState(true)
  const [chartIdFilter, setChartIdFilter] = useState('')

  useEffect(() => {
    setLoading(true)
    const url = chartIdFilter ? `/api/chart-revisions?chartId=${encodeURIComponent(chartIdFilter)}` : '/api/chart-revisions?limit=200'
    apiFetch(url).then(d => { setRevisions(d); setLoading(false) }).catch(() => setLoading(false))
  }, [chartIdFilter])

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Chart Revisions</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Audit history of every chart save, regenerate, edit, and manual override</p>
      </div>

      <SectionCard title="Filters">
        <FormField label="Filter by Chart ID (inventory ID)">
          <FormInput value={chartIdFilter} onChange={e => setChartIdFilter(e.target.value)} placeholder="Paste chart ID (inventory ID) to filter" />
        </FormField>
      </SectionCard>

      <SectionCard title={`Revisions (${revisions.length})`}>
        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                {['Timestamp', 'Chart ID', 'Edited By', 'Action', 'Summary', 'Changes'].map(h => (
                  <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
              ) : revisions.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-8 text-[#9CA3AF]">No chart revisions recorded yet. Save or regenerate a chart to see entries here.</td></tr>
              ) : revisions.map(r => (
                <tr key={r.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)]">
                  <td className="px-3.5 py-3 text-[11px] font-mono text-[#6B7280]">{formatDateTime(r.createdAt)}</td>
                  <td className="px-3.5 py-3 font-mono text-[11px] text-[#9CA3AF]">{r.chartId.substring(0, 12)}...</td>
                  <td className="px-3.5 py-3 font-mono text-[12px]">{r.editedBy}</td>
                  <td className="px-3.5 py-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${r.action === 'save' ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : r.action === 'regenerate' ? 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]' : r.action === 'manual_override' ? 'bg-[rgba(217,119,6,0.1)] text-[#D97706]' : 'bg-[rgba(55,48,163,0.1)] text-[#3730A3]'}`}>{r.action}</span>
                  </td>
                  <td className="px-3.5 py-3 text-[12px] text-[#6B7280]">{r.summary || '\u2014'}</td>
                  <td className="px-3.5 py-3 text-[10px] font-mono text-[#9CA3AF]">
                    <details>
                      <summary className="cursor-pointer hover:text-[#3730A3]">View diff</summary>
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        <div>
                          <div className="text-[#DC2626] mb-1">Previous</div>
                          <pre className="bg-[#FFFFFF] p-2 rounded text-[10px] overflow-x-auto max-w-xs">{(() => { try { return JSON.stringify(JSON.parse(r.previousData), null, 2) } catch { return r.previousData } })()}</pre>
                        </div>
                        <div>
                          <div className="text-[#059669] mb-1">New</div>
                          <pre className="bg-[#FFFFFF] p-2 rounded text-[10px] overflow-x-auto max-w-xs">{(() => { try { return JSON.stringify(JSON.parse(r.newData), null, 2) } catch { return r.newData } })()}</pre>
                        </div>
                      </div>
                    </details>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}
