'use client'

// ────────────────────────────────────────────────────────────
// WhatsApp Management panel — PAGES 4-6 (operations):
//   WhatsAppApprovalsPage — pending queue / approved transactions /
//                           rejected messages + full audit detail
//   WhatsAppLearningPage  — learning candidates + bot evolution
//   WhatsAppMappingsPage  — provider Group ID → ONE customer mapping
// Markup and behavior carried over from the former inbox tabs verbatim.
// ────────────────────────────────────────────────────────────

import React, { useState } from 'react'
import {
  ShieldAlert, ReceiptText, Clock, UserRound, Users, Check, X,
  FlaskConical, GraduationCap, History, MapPin,
} from 'lucide-react'
import {
  useWhatsAppCore, PanelHeader, RefreshButton, StatusChip, TxStatusChip, ApprovalChip,
  ParseBuckets, fmtTime, parseJson,
  type WaApproval, type WaMessage, type WaTransaction,
} from './WhatsAppPanelShared'

// ─────────────────────────── PAGE 4: Approvals ───────────────────────────

type ApprovalTab = 'pending' | 'approved' | 'rejected'

export function WhatsAppApprovalsPage() {
  const core = useWhatsAppCore()
  const [tab, setTab] = useState<ApprovalTab>('pending')
  const [selected, setSelected] = useState<WaMessage | null>(null)
  const [selectedTx, setSelectedTx] = useState<WaTransaction | null>(null)
  const [selectedApproval, setSelectedApproval] = useState<WaApproval | null>(null)
  const [rejecting, setRejecting] = useState<WaApproval | null>(null)
  const [rejectReason, setRejectReason] = useState('')

  const decide = async (a: WaApproval, action: 'approve' | 'reject', reason = '') => {
    await core.decide(a, action, reason)
    setRejecting(null)
    setRejectReason('')
  }

  const tabs: Array<{ id: ApprovalTab; label: string; icon: React.ReactNode; count: number }> = [
    { id: 'pending', label: 'Pending', icon: <Clock className="w-4 h-4" />, count: core.pending.length },
    { id: 'approved', label: 'Approved Transactions', icon: <ReceiptText className="w-4 h-4" />, count: core.txs.length },
    { id: 'rejected', label: 'Rejected', icon: <ShieldAlert className="w-4 h-4" />, count: core.rejectedIn.length },
  ]

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PanelHeader
        icon={<Clock className="w-5 h-5 text-amber-500" />}
        title="Approvals"
        subtitle={<>Every valid vyapar waits here first — <b>only an approval creates the ERP transaction</b>, and the confirmation reply goes out after that commit. Rejections keep the original message and audit intact.</>}
        actions={<RefreshButton loading={core.loading} onClick={core.load} />}
      />

      {core.banner && (
        <div className="mb-4 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm text-indigo-700">{core.banner}</div>
      )}
      {core.approvalMode === 'off' && (
        <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">
          Approval mode is OFF (legacy auto-transactions). Turn it on in System configuration to route vyapar through this queue.
        </div>
      )}

      <div className="grid lg:grid-cols-5 gap-5">
        <div className={`lg:col-span-3 bg-white rounded-xl border border-slate-200 shadow-sm ${selected || selectedTx || selectedApproval ? 'hidden lg:block' : ''}`}>
          <div className="flex items-center gap-1 border-b border-slate-100 px-3 pt-2 flex-wrap">
            {tabs.map(t => (
              <button key={t.id}
                onClick={() => { setTab(t.id); setSelected(null); setSelectedTx(null); setSelectedApproval(null) }}
                className={`px-3 py-2 text-sm font-medium border-b-2 -mb-px flex items-center gap-1.5 ${tab === t.id ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
                {t.icon} {t.label} ({t.count})
              </button>
            ))}
          </div>

          {tab === 'pending' && (
            core.pending.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-400">
                Nothing waiting for approval. Valid vyapar lands here first — only approval creates the ERP transaction.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-[560px] overflow-y-auto">
                {core.pending.map(a => (
                  <button key={a.id} onClick={() => { setSelectedApproval(a); setSelected(null); setSelectedTx(null) }}
                    className={`w-full text-left px-4 py-3 hover:bg-slate-50 ${selectedApproval?.id === a.id ? 'bg-amber-50/60' : ''}`}>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Clock className="w-4 h-4 text-amber-500" />
                      <span className="text-sm font-semibold text-slate-700">{a.customerName}</span>
                      {a.agentName && <span className="text-xs text-slate-400">· Agent {a.agentName}</span>}
                      {a.groupId && <span className="text-[11px] rounded bg-violet-50 border border-violet-200 px-1.5 py-0.5 text-violet-700">GROUP</span>}
                      {a.senderPhone && a.groupId && <span className="text-[11px] text-slate-400">sender {a.senderName || a.senderPhone}</span>}
                      <span className="ml-auto text-sm font-semibold text-slate-800">₹{a.total}</span>
                      {a.validationStatus === 'warnings' && (
                        <span className="text-[11px] rounded bg-orange-50 border border-orange-200 px-1.5 py-0.5 text-orange-700">WARNINGS</span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 mt-1 line-clamp-2">{a.rawMessage}</div>
                    <div className="text-[11px] text-slate-400 mt-1 flex gap-2">
                      {a.marketName && <span className="text-indigo-500">{a.marketName}{a.session ? ` (${a.session})` : ''}</span>}
                      <span>{fmtTime(a.createdAt)}</span>
                    </div>
                  </button>
                ))}
              </div>
            )
          )}

          {tab === 'approved' && (
            core.txs.length === 0 && !core.loading ? (
              <div className="p-8 text-center text-sm text-slate-400">
                No approved transactions yet. Each approval creates one with its own Transaction ID.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-[560px] overflow-y-auto">
                {core.txs.map(t => (
                  <button key={t.id} onClick={() => { setSelectedTx(t); setSelected(null); setSelectedApproval(null) }}
                    className={`w-full text-left px-4 py-3 hover:bg-slate-50 ${selectedTx?.id === t.id ? 'bg-indigo-50/60' : ''}`}>
                    <div className="flex items-center gap-2">
                      <ReceiptText className="w-4 h-4 text-indigo-500" />
                      <span className="text-sm font-semibold text-slate-700">#{t.txNumber}</span>
                      <span className="text-sm text-slate-600 truncate">
                        {t.customerName}{t.agentName ? <span className="text-slate-400"> · Agent {t.agentName}</span> : null}
                      </span>
                      <span className="ml-auto text-sm font-semibold text-slate-800">₹{t.total}</span>
                      <TxStatusChip s={t.status} />
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1 flex gap-2">
                      {t.marketName && <span className="text-indigo-500">{t.marketName}{t.session ? ` (${t.session})` : ''}</span>}
                      {t._count?.lines != null && <span>{t._count.lines} entries</span>}
                      <span>{fmtTime(t.createdAt)}</span>
                    </div>
                  </button>
                ))}
              </div>
            )
          )}

          {tab === 'rejected' && (
            core.rejectedIn.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-400">
                Nothing rejected. Invalid syntax/numbers/amounts never create a transaction — they are stored here with the precise reason.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-[560px] overflow-y-auto">
                {core.rejectedIn.map(m => (
                  <button key={m.id} onClick={() => { setSelected(m); setSelectedTx(null); setSelectedApproval(null) }}
                    className={`w-full text-left px-4 py-3 hover:bg-slate-50 ${selected?.id === m.id ? 'bg-red-50/60' : ''}`}>
                    <div className="flex items-center gap-2 flex-wrap">
                      <ShieldAlert className="w-4 h-4 text-red-500" />
                      <span className="text-sm font-semibold text-slate-700">{m.profileName || m.phone}</span>
                      <span className="text-xs text-slate-400">{m.phone}</span>
                      {m.groupId && <span className="text-[11px] rounded bg-violet-50 border border-violet-200 px-1.5 py-0.5 text-violet-700">GROUP</span>}
                      {m.customerName && (
                        <span className="text-[11px] rounded bg-slate-100 border border-slate-200 px-1.5 py-0.5 text-slate-600">{m.customerName}</span>
                      )}
                      <span className="ml-auto"><StatusChip m={m} /></span>
                    </div>
                    <div className="text-xs text-slate-500 mt-1 line-clamp-2">{m.body}</div>
                    {m.error && <div className="text-[11px] text-red-500 mt-0.5">Reason: {m.error}</div>}
                    <div className="text-[11px] text-slate-400 mt-1">{fmtTime(m.createdAt)}</div>
                  </button>
                ))}
              </div>
            )
          )}
        </div>

        {/* ── Detail column ── */}
        <div className="lg:col-span-2 space-y-5">
          {selectedApproval && (() => {
            const a = selectedApproval
            const notes = parseJson<string[]>(a.validationNotes) || []
            return (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-center justify-between mb-2 gap-2 flex-wrap">
                  <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-500" />
                    Approval — {a.customerName}
                    <ApprovalChip s={a.status} />
                  </h3>
                  <button onClick={() => setSelectedApproval(null)} className="lg:hidden text-xs text-slate-400">Close</button>
                </div>
                <div className="text-xs text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <UserRound className="w-3.5 h-3.5 text-slate-400" />
                    <span>Customer: <b>{a.customerName}</b></span>
                    {a.agentName && <span>— Agent: <b>{a.agentName}</b>{a.agentUsername ? ` (${a.agentUsername})` : ''}</span>}
                  </div>
                  {a.groupId && (
                    <div className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-violet-400" />
                      <span>Group: <b className="font-mono">{a.groupId}</b></span>
                      {a.senderPhone && <span>· Sender: <b>{a.senderName || a.senderPhone}</b></span>}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>Context: <b>{a.marketName || '—'}{a.session ? ` (${a.session === 'open' ? 'Open' : 'Close'})` : ''}</b></span>
                    <span>· Total <b>₹{a.total}</b> · Parser <b>v{a.parserVersion}</b></span>
                  </div>
                  <div className="text-slate-400">Received {fmtTime(a.createdAt)}</div>
                </div>

                <div className="mt-2">
                  <div className="text-xs font-medium text-slate-500 mb-1">Original message (immutable)</div>
                  <pre className="whitespace-pre-wrap text-xs text-slate-700 bg-slate-50 rounded-md p-3 max-h-40 overflow-y-auto">{a.rawMessage}</pre>
                </div>

                {parseJson<Record<string, unknown>>(a.parseSummary) && (
                  <div className="mt-2 text-xs text-slate-600">
                    <div className="font-medium mb-1">Parsed entries (Smart Entry engine)</div>
                    <ParseBuckets raw={a.parseSummary} />
                  </div>
                )}

                {notes.length > 0 && (
                  <div className="mt-2 text-xs text-orange-700 bg-orange-50 border border-orange-200 rounded-md p-2">
                    <div className="font-medium mb-1">Validation warnings</div>
                    <ul className="list-disc list-inside space-y-0.5">
                      {notes.map((n, i) => <li key={i}>{n}</li>)}
                    </ul>
                  </div>
                )}

                <div className="mt-3 border-t border-slate-100 pt-2 text-[11px] text-slate-500 space-y-1">
                  <div className="flex items-center gap-1.5 font-medium text-slate-600"><History className="w-3.5 h-3.5" /> Audit history</div>
                  <div>• {fmtTime(a.createdAt)} — message received{a.senderPhone && a.groupId ? ` by ${a.senderName || a.senderPhone} in group` : ''}, parsed with parser v{a.parserVersion}</div>
                  {a.status === 'approved' && <div>• {fmtTime(a.approvedAt)} — approved by <b>{a.approvedBy}</b> → Transaction #{a.txNumber} created; confirmation reply sent after commit</div>}
                  {a.status === 'rejected' && <div>• {fmtTime(a.rejectedAt)} — rejected by <b>{a.rejectedBy}</b> — “{a.rejectionReason}” (original message + audit intact)</div>}
                  {a.status === 'pending' && <div>• Waiting for an Admin Manager decision — no ERP record exists yet</div>}
                </div>

                {a.status === 'pending' && (
                  <div className="mt-3 flex gap-2">
                    <button onClick={() => decide(a, 'approve')} disabled={core.busyId === a.id}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-emerald-600 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-60">
                      <Check className="w-4 h-4" /> Approve &amp; create transaction
                    </button>
                    <button onClick={() => { setRejecting(a); setRejectReason('') }} disabled={core.busyId === a.id}
                      className="inline-flex items-center justify-center gap-1.5 rounded-md border border-red-300 px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 disabled:opacity-60">
                      <X className="w-4 h-4" /> Reject
                    </button>
                  </div>
                )}
              </div>
            )
          })()}

          {rejecting && (
            <div className="bg-white rounded-xl border border-red-200 shadow-sm p-4">
              <h3 className="text-sm font-semibold text-slate-700 mb-1">Reject vyapar — {rejecting.customerName}</h3>
              <p className="text-xs text-slate-500 mb-2">The precise reason is stored on the audit record and sent to the chat. The original message stays intact.</p>
              <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} rows={3}
                placeholder="e.g. '45=abc — amount is not a number; resend like 45=100'"
                className="w-full rounded-md border border-slate-300 px-2.5 py-2 text-sm" />
              <div className="mt-2 flex gap-2">
                <button onClick={() => decide(rejecting, 'reject', rejectReason)} disabled={core.busyId === rejecting.id || !rejectReason.trim()}
                  className="flex-1 rounded-md bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-60">Reject with reason</button>
                <button onClick={() => setRejecting(null)} className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
              </div>
            </div>
          )}

          {selectedTx && (() => {
            const appr = core.approvalForTx(selectedTx)
            return (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    <ReceiptText className="w-4 h-4 text-indigo-500" />
                    Transaction #{selectedTx.txNumber}
                    <TxStatusChip s={selectedTx.status} />
                  </h3>
                  <button onClick={() => setSelectedTx(null)} className="lg:hidden text-xs text-slate-400">Close</button>
                </div>
                <div className="text-xs text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <UserRound className="w-3.5 h-3.5 text-slate-400" />
                    <span>Customer: <b>{selectedTx.customerName}</b></span>
                    {selectedTx.agentName ? (
                      <span>— Agent: <b>{selectedTx.agentName}</b>{selectedTx.agentUsername ? ` (${selectedTx.agentUsername})` : ''}</span>
                    ) : (
                      <span className="text-slate-400">— no agent on file</span>
                    )}
                  </div>
                  <div>
                    Market: <b>{selectedTx.marketName || '—'}{selectedTx.session ? ` (${selectedTx.session})` : ''}</b>
                    {' '}· Total <b>₹{selectedTx.total}</b>
                    {selectedTx._count?.lines != null ? ` · ${selectedTx._count.lines} entries` : ''}
                  </div>
                  <div className="text-slate-400">{fmtTime(selectedTx.createdAt)}</div>
                </div>
                {(() => { const p = parseJson<{ total: number }>(selectedTx.parseSummary); return p && p.total > 0 && (
                  <div className="mt-2 text-xs text-slate-600">
                    <div className="font-medium mb-1">Smart Entry parse (single / double / triple)</div>
                    <ParseBuckets raw={selectedTx.parseSummary} />
                  </div>
                ) })()}
                {appr && (
                  <div className="mt-3 border-t border-slate-100 pt-2 text-[11px] text-slate-500">
                    <div className="flex items-center gap-1.5 font-medium text-slate-600 mb-1"><History className="w-3.5 h-3.5" /> Approval audit</div>
                    {appr.approvedBy
                      ? <div>Approved by <b>{appr.approvedBy}</b> at {fmtTime(appr.approvedAt)} · parser v{appr.parserVersion} · immutable parsed snapshot stored</div>
                      : <div>Created in legacy auto mode (approval was off at the time)</div>}
                  </div>
                )}
              </div>
            )
          })()}

          {selected && (() => {
            const appr = core.approvalForMessage(selected)
            const linked = core.rows.find(r => r.id === (selected.replyToId || core.rows.find(x => x.replyToId === selected.id)?.id)) || null
            const linkedFailed = linked && linked.direction === 'out' && linked.status === 'failed'
            return (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    {selected.direction === 'in' ? 'Incoming message' : 'Reply'}
                    <StatusChip m={selected} />
                  </h3>
                  <button onClick={() => setSelected(null)} className="lg:hidden text-xs text-slate-400">Close</button>
                </div>
                <pre className="whitespace-pre-wrap text-xs text-slate-700 bg-slate-50 rounded-md p-3 max-h-60 overflow-y-auto">{selected.body}</pre>
                {selected.error && (
                  <div className="mt-2 text-xs text-amber-700 flex items-center gap-1"><ShieldAlert className="w-3.5 h-3.5" /> {selected.error}</div>
                )}
                {appr && (
                  <div className="mt-2 text-xs text-slate-600">
                    Approval: <ApprovalChip s={appr.status} />
                    {appr.status === 'approved' && <span className="text-slate-400"> · Transaction #{appr.txNumber} · by {appr.approvedBy}</span>}
                    {appr.status === 'rejected' && <span className="text-slate-400"> · {appr.rejectionReason}</span>}
                  </div>
                )}
                {linked && (
                  <div className="mt-3 border-t border-slate-100 pt-2">
                    <div className="text-xs font-medium text-slate-500 mb-1 flex items-center gap-2">
                      {linked.direction === 'out' ? 'Reply sent back' : 'Customer message'}
                      {linked.direction === 'out' && <StatusChip m={linked} />}
                      {linkedFailed && (
                        <button onClick={() => core.retry(linked.id)} disabled={core.busyId === linked.id}
                          className="inline-flex items-center gap-1 rounded border border-indigo-300 px-2 py-0.5 text-[11px] text-indigo-600 hover:bg-indigo-50 disabled:opacity-50">
                          <FlaskConical className="w-3 h-3" /> Retry reply
                        </button>
                      )}
                    </div>
                    <pre className="whitespace-pre-wrap text-xs text-slate-600 bg-emerald-50/50 rounded-md p-2 max-h-40 overflow-y-auto">{linked.body}</pre>
                  </div>
                )}
              </div>
            )
          })()}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────── PAGE 5: Bot Learning ───────────────────────

export function WhatsAppLearningPage() {
  const core = useWhatsAppCore()
  const openCount = core.learning.filter(l => l.status !== 'dismissed' && l.status !== 'applied').length
  const applied = core.learning.filter(l => l.status === 'applied')

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PanelHeader
        icon={<GraduationCap className="w-5 h-5 text-violet-600" />}
        title="Bot Learning"
        subtitle={<>What the WhatsApp data teaches us: unknown patterns become candidates — review, define a rule, test it against history, then activate it explicitly. Nothing changes the parser automatically.</>}
        actions={<RefreshButton loading={core.loading} onClick={core.load} />}
      />

      {core.banner && (
        <div className="mb-4 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm text-indigo-700">{core.banner}</div>
      )}

      {/* Bot evolution header */}
      <div className="mb-5 grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-xl border border-violet-100 bg-violet-50/50 p-3">
          <div className="text-[11px] font-medium uppercase tracking-wide text-violet-600">Parser version</div>
          <div className="text-xl font-bold text-violet-700">v{core.parserVersion}</div>
        </div>
        <div className="rounded-xl border border-amber-100 bg-amber-50/50 p-3">
          <div className="text-[11px] font-medium uppercase tracking-wide text-amber-600">Open candidates</div>
          <div className="text-xl font-bold text-amber-700">{openCount}</div>
        </div>
        <div className="rounded-xl border border-emerald-100 bg-emerald-50/50 p-3">
          <div className="text-[11px] font-medium uppercase tracking-wide text-emerald-600">Rules activated</div>
          <div className="text-xl font-bold text-emerald-700">{applied.length}</div>
        </div>
        <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
          <div className="text-[11px] font-medium uppercase tracking-wide text-slate-500">Dismissed</div>
          <div className="text-xl font-bold text-slate-600">{core.learning.filter(l => l.status === 'dismissed').length}</div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
        {core.learning.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-400">
            No learning candidates. Unknown input patterns are captured automatically — never applied to production rules without review.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 max-h-[560px] overflow-y-auto">
            {core.learning.map(c => (
              <div key={c.id} className="px-4 py-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <GraduationCap className="w-4 h-4 text-violet-500" />
                  <span className="text-sm font-semibold text-slate-700 font-mono">{c.rawInput}</span>
                  <span className={`text-[11px] rounded border px-1.5 py-0.5 ${c.status === 'applied' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : c.status === 'dismissed' ? 'bg-slate-100 text-slate-500 border-slate-200' : 'bg-violet-50 text-violet-700 border-violet-200'}`}>
                    {c.status.toUpperCase()}
                  </span>
                  <span className="text-[11px] text-slate-400">×{c.sampleCount} · {c.context || 'whatsapp'} · {fmtTime(c.createdAt)}</span>
                </div>
                {c.status !== 'applied' && c.status !== 'dismissed' && (
                  <div className="mt-2 flex items-center gap-2 flex-wrap text-xs">
                    <input
                      value={core.termDraft[c.id] ?? c.rawInput}
                      onChange={e => core.setTermDraft(d => ({ ...d, [c.id]: e.target.value }))}
                      placeholder="term (e.g. lagani)"
                      className="h-8 rounded-md border border-slate-300 px-2 text-xs w-40"
                    />
                    <select
                      value={core.categoryDraft[c.id] || ''}
                      onChange={e => core.setCategoryDraft(d => ({ ...d, [c.id]: e.target.value }))}
                      className="h-8 rounded-md border border-slate-300 px-2 text-xs bg-white"
                    >
                      <option value="">category…</option>
                      <option value="SP">SP (single)</option>
                      <option value="DP">DP (jodi)</option>
                      <option value="TP">TP (panna)</option>
                      <option value="SPDP">SPDP</option>
                      <option value="SPTP">SPTP</option>
                      <option value="DPTP">DPTP</option>
                      <option value="SPDPTP">SPDPTP</option>
                      <option value="Motor Pana">Motor Pana</option>
                      <option value="mix">mix</option>
                      <option value="common">common</option>
                    </select>
                    <button onClick={() => core.learningAction(c, 'define', { term: core.termDraft[c.id] ?? c.rawInput, category: core.categoryDraft[c.id] })}
                      disabled={!core.categoryDraft[c.id] || core.busyId === c.id}
                      className="rounded-md border border-slate-300 px-2 py-1 text-slate-600 hover:bg-slate-50 disabled:opacity-50">
                      Define rule
                    </button>
                    <button onClick={() => core.learningAction(c, 'test')} disabled={core.busyId === c.id || !c.ruleDefinition}
                      className="rounded-md border border-indigo-300 px-2 py-1 text-indigo-600 hover:bg-indigo-50 disabled:opacity-50">
                      <FlaskConical className="w-3 h-3 inline mr-0.5" /> Test on history
                    </button>
                    <button onClick={() => core.learningAction(c, 'activate')} disabled={core.busyId === c.id || !c.ruleDefinition}
                      className="rounded-md bg-emerald-600 px-2 py-1 text-white hover:bg-emerald-700 disabled:opacity-50">
                      <Check className="w-3 h-3 inline mr-0.5" /> Activate
                    </button>
                    <button onClick={() => core.learningAction(c, 'dismiss')} disabled={core.busyId === c.id}
                      className="rounded-md border border-red-200 px-2 py-1 text-red-600 hover:bg-red-50 disabled:opacity-50">
                      <X className="w-3 h-3 inline mr-0.5" /> Dismiss
                    </button>
                  </div>
                )}
                {core.testResult[c.id] && <div className="mt-1 text-[11px] text-indigo-600"><FlaskConical className="w-3 h-3 inline mr-1" />{core.testResult[c.id]}</div>}
                {c.testResults && !core.testResult[c.id] && (
                  <div className="mt-1 text-[11px] text-slate-400">Last test: {parseJson<{ matched: number; scanned: number }>(c.testResults)?.matched ?? '?'} messages matched historically.</div>
                )}
                {c.status === 'applied' && (
                  <div className="mt-1 text-[11px] text-emerald-600">Activated as dictionary term — parser rules updated by an administrator (audit-logged).</div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─────────────────── PAGE 6: Customer/Group Mapping ───────────────────

export function WhatsAppMappingsPage() {
  const core = useWhatsAppCore()

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PanelHeader
        icon={<Users className="w-5 h-5 text-violet-600" />}
        title="Customer / Group Mapping"
        subtitle={<>A registered WhatsApp <b>Group ID</b> represents ONE customer. Identity comes from the provider&apos;s immutable Group ID — never the group name. Members&apos; sender identity is stored separately on every message.</>}
        actions={<RefreshButton loading={core.loading} onClick={core.load} />}
      />

      {core.banner && (
        <div className="mb-4 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm text-indigo-700">{core.banner}</div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-4">
        {core.isSuper && (
          <div className="rounded-lg border border-slate-200 p-3 space-y-2">
            <div className="text-xs font-semibold text-slate-600">Map a group to a customer</div>
            <div className="grid md:grid-cols-2 gap-2">
              <input value={core.gmGroupId} onChange={e => core.setGmGroupId(e.target.value)} placeholder="Provider Group ID (required)"
                className="h-9 rounded-md border border-slate-300 px-2.5 text-sm" />
              <input value={core.gmLabel} onChange={e => core.setGmLabel(e.target.value)} placeholder="Group name (display hint only)"
                className="h-9 rounded-md border border-slate-300 px-2.5 text-sm" />
              <select value={core.gmCustomer} onChange={e => { core.setGmCustomer(e.target.value); core.setGmVendor('') }}
                className="h-9 rounded-md border border-slate-300 px-2.5 text-sm bg-white">
                <option value="">— App customer —</option>
                {core.customers.map(c => <option key={c.id} value={c.id}>{c.name} ({c.mobile})</option>)}
              </select>
              <select value={core.gmVendor} onChange={e => { core.setGmVendor(e.target.value); core.setGmCustomer('') }}
                className="h-9 rounded-md border border-slate-300 px-2.5 text-sm bg-white">
                <option value="">— ERP customer —</option>
                {core.vendors.map(v => <option key={v.id} value={v.id}>{v.businessName} ({v.mobileNo})</option>)}
              </select>
              <input value={core.gmNote} onChange={e => core.setGmNote(e.target.value)} placeholder="Note (optional)"
                className="h-9 rounded-md border border-slate-300 px-2.5 text-sm md:col-span-2" />
            </div>
            <button onClick={core.createMapping} disabled={core.busyId === 'gm'}
              className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-60">
              Map group
            </button>
          </div>
        )}
        {core.groups.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-400">No groups mapped yet.</div>
        ) : (
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-slate-200">
                {['Group ID', 'Label', 'Customer', 'Context', 'Status', core.isSuper ? 'Options' : ''].map(h => (
                  <th key={h} className="px-2 py-2 text-left text-[10px] font-bold uppercase tracking-wider text-slate-400">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {core.groups.map(g => (
                <tr key={g.id} className="border-b border-slate-100">
                  <td className="px-2 py-2 font-mono text-[12px]">{g.groupId}</td>
                  <td className="px-2 py-2">{g.groupLabel || '—'}</td>
                  <td className="px-2 py-2">{g.customerName || g.vendorName || '—'}</td>
                  <td className="px-2 py-2">{g.context}</td>
                  <td className="px-2 py-2">
                    <span className={`rounded border px-1.5 py-0.5 text-[10px] ${g.isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-200'}`}>
                      {g.isActive ? 'ACTIVE' : 'INACTIVE'}
                    </span>
                  </td>
                  <td className="px-2 py-2">
                    {core.isSuper && g.isActive && (
                      <button onClick={() => core.deactivateMapping(g.id)} disabled={core.busyId === g.id}
                        className="rounded border border-red-200 px-2 py-1 text-[11px] text-red-600 hover:bg-red-50 disabled:opacity-50">Deactivate</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
