'use client'

// ────────────────────────────────────────────────────────────
// WhatsApp Management panel — PAGE 3: Templates.
// Full message-template management per the Meta Cloud API categories:
//   utility · marketing · authentication
// • Pipeline slots (vyapar_ack / tx_success / rejection_notice /
//   invalid_notice): edit the wording and ACTIVATE to override the
//   built-in bot replies — deactivating restores the canonical text.
// • Custom templates: compose with {{variables}} and send to any
//   customer; usageCount / lastUsedAt track every send.
// ────────────────────────────────────────────────────────────

import React, { useState, useEffect, useCallback } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import {
  MessageCircle, Plus, Pencil, Send, Power, Tag, FileText, X, Check,
} from 'lucide-react'
import { PanelHeader, RefreshButton, fmtTime } from './WhatsAppPanelShared'

interface TemplateVar { name: string; sample: string }
interface WaTemplate {
  id: string
  name: string
  key: string | null
  category: string
  language: string
  bodyText: string
  variables: string
  isActive: boolean
  usageCount: number
  lastUsedAt: string | null
  createdBy: string
  createdAt: string
  variableList: TemplateVar[]
}

const PIPELINE_SLOT_LABELS: Record<string, string> = {
  vyapar_ack: 'Bot: vyapar received (pending approval)',
  tx_success: 'Bot: transaction successful',
  rejection_notice: 'Bot: vyapar rejected',
  invalid_notice: 'Bot: unreadable vyapar',
}
const CATEGORY_STYLES: Record<string, string> = {
  utility: 'bg-sky-50 text-sky-700 border-sky-200',
  marketing: 'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200',
  authentication: 'bg-amber-50 text-amber-700 border-amber-200',
}

export function WhatsAppTemplatesPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [rows, setRows] = useState<WaTemplate[]>([])
  const [counts, setCounts] = useState<Record<string, number>>({})
  const [customers, setCustomers] = useState<Array<{ id: string; name: string; mobile: string }>>([])
  const [vendors, setVendors] = useState<Array<{ id: string; businessName: string; mobileNo: string }>>([])
  const [loading, setLoading] = useState(true)
  const [banner, setBanner] = useState('')
  const [busyId, setBusyId] = useState('')
  const [filter, setFilter] = useState<string>('all')

  // editor state
  const [editing, setEditing] = useState<WaTemplate | null>(null)
  const [creating, setCreating] = useState(false)
  const [fName, setFName] = useState('')
  const [fCategory, setFCategory] = useState('utility')
  const [fKey, setFKey] = useState('')
  const [fBody, setFBody] = useState('')
  // send modal state
  const [sending, setSending] = useState<WaTemplate | null>(null)
  const [sendTarget, setSendTarget] = useState('') // customerId or "phone:"
  const [sendPhone, setSendPhone] = useState('')
  const [sendParams, setSendParams] = useState<Record<string, string>>({})
  const [sendPreview, setSendPreview] = useState('')

  const load = useCallback(() => {
    setLoading(true)
    Promise.all([
      apiFetch('/api/whatsapp/templates'),
      apiFetch('/api/app-admin/customers').catch(() => null),
      apiFetch('/api/vendors').catch(() => null),
    ]).then(([tpl, cust, vnd]) => {
      setRows(Array.isArray(tpl?.data) ? tpl.data : [])
      setCounts(tpl?.counts || {})
      if (cust?.customers) setCustomers(cust.customers)
      if (Array.isArray(vnd)) setVendors(vnd)
    }).catch(console.error).finally(() => setLoading(false))
  }, [])
  useEffect(() => { load() }, [load])

  const filtered = filter === 'all' ? rows : rows.filter(r => r.category === filter)

  const openCreate = () => {
    setEditing(null); setCreating(true)
    setFName(''); setFCategory('utility'); setFKey(''); setFBody('')
    setBanner('')
  }
  const openEdit = (t: WaTemplate) => {
    setCreating(false); setEditing(t)
    setFName(t.name); setFCategory(t.category); setFKey(t.key || ''); setFBody(t.bodyText)
    setBanner('')
  }
  const closeEditor = () => { setEditing(null); setCreating(false) }

  const saveTemplate = async () => {
    setBanner('')
    if (!fName.trim() || !fBody.trim()) { setBanner('Name and body text are required.'); return }
    setBusyId('editor')
    try {
      if (editing) {
        const res = await apiFetch(`/api/whatsapp/templates/${editing.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: fName, category: fCategory, bodyText: fBody }),
        })
        setBanner(res?.error ? res.error : 'Template saved.')
        if (!res?.error) closeEditor()
      } else {
        const res = await apiFetch('/api/whatsapp/templates', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: fName, category: fCategory, bodyText: fBody, key: fKey || null }),
        })
        setBanner(res?.error ? res.error : 'Template created (inactive — activate when ready).')
        if (!res?.error) closeEditor()
      }
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Save failed')
    }
    setBusyId('')
  }

  const toggleActive = async (t: WaTemplate) => {
    setBusyId(t.id); setBanner('')
    try {
      const res = await apiFetch(`/api/whatsapp/templates/${t.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !t.isActive }),
      })
      if (res?.error) setBanner(res.error)
      else setBanner(t.isActive
        ? `"${t.name}" deactivated — the bot falls back to its built-in wording.`
        : `"${t.name}" activated — the bot now uses this wording.`)
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Toggle failed')
    }
    setBusyId('')
  }

  const openSend = (t: WaTemplate) => {
    setSending(t); setSendTarget(''); setSendPhone(''); setSendParams({})
    setSendPreview('')
    setBanner('')
  }

  // live preview while composing the send
  useEffect(() => {
    if (!sending) return
    const vars = sending.variableList || []
    let body = sending.bodyText
    for (const v of vars) body = body.replace(new RegExp(`\\{\\{\\s*${v.name}\\s*\\}\\}`, 'g'), sendParams[v.name] ?? v.sample ?? '')
    setSendPreview(body)
  }, [sending, sendParams])

  const sendIt = async () => {
    if (!sending) return
    setBusyId('send'); setBanner('')
    try {
      const payload: Record<string, unknown> = { params: sendParams }
      if (sendTarget.startsWith('phone:')) payload.phone = sendPhone
      else if (sendTarget) payload.customerId = sendTarget
      else if (sendPhone.trim()) payload.phone = sendPhone
      if (!payload.customerId && !payload.phone) {
        setBanner('Pick a customer or type a WhatsApp number.')
        setBusyId('')
        return
      }
      const res = await apiFetch(`/api/whatsapp/templates/${sending.id}/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (res?.error) setBanner(res.error)
      else {
        setBanner(res.data.status === 'failed'
          ? 'Send failed — check the Messages page and retry.'
          : `Sent to ${res.data.customerName || res.data.phone} (${res.data.status}).`)
        setSending(null)
      }
      load()
    } catch (err) {
      setBanner(err instanceof Error ? err.message : 'Send failed')
    }
    setBusyId('')
  }

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PanelHeader
        icon={<MessageCircle className="w-5 h-5 text-emerald-600" />}
        title="Templates"
        subtitle={<>Message templates in Meta&apos;s categories — utility, marketing, authentication. The four <b>Bot reply</b> slots override what the pipeline answers; custom templates can be sent to any customer.</>}
        actions={<div className="flex gap-2">
          <RefreshButton loading={loading} onClick={load} />
          {isSuper && (
            <button onClick={openCreate} className="inline-flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700">
              <Plus className="w-4 h-4" /> New template
            </button>
          )}
        </div>}
      />

      {banner && (
        <div className="mb-4 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm text-indigo-700">{banner}</div>
      )}

      {/* Category filter chips */}
      <div className="flex items-center gap-2 mb-4 flex-wrap text-sm">
        {['all', 'utility', 'marketing', 'authentication'].map(c => (
          <button key={c} onClick={() => setFilter(c)}
            className={`rounded-full border px-3 py-1 ${filter === c ? 'border-indigo-500 bg-indigo-50 text-indigo-700 font-medium' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'}`}>
            {c === 'all' ? `All (${counts.total ?? rows.length})` : `${c[0].toUpperCase()}${c.slice(1)} (${counts[c] ?? 0})`}
          </button>
        ))}
      </div>

      {/* Templates table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-x-auto">
        <table className="w-full text-[13px]">
          <thead>
            <tr className="border-b border-slate-200 text-[10px] uppercase tracking-wider text-slate-400">
              <th className="text-left px-3 py-2.5">Template</th>
              <th className="text-left px-3 py-2.5">Category</th>
              <th className="text-left px-3 py-2.5">Purpose</th>
              <th className="text-right px-3 py-2.5">Used</th>
              <th className="text-left px-3 py-2.5">Last used</th>
              <th className="text-left px-3 py-2.5">State</th>
              <th className="text-right px-3 py-2.5">Options</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="px-3 py-8 text-center text-slate-400">
                {loading ? 'Loading…' : 'No templates in this category yet.'}
              </td></tr>
            )}
            {filtered.map(t => (
              <tr key={t.id} className="border-b border-slate-100 align-top">
                <td className="px-3 py-2.5">
                  <div className="font-medium text-slate-700 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-slate-400" /> {t.name}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-2 max-w-md whitespace-pre-wrap">{t.bodyText}</div>
                  {(t.variableList?.length || 0) > 0 && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {t.variableList.map(v => (
                        <span key={v.name} className="rounded bg-slate-100 border border-slate-200 px-1.5 py-0.5 text-[10px] text-slate-500">{`{{${v.name}}}`}</span>
                      ))}
                    </div>
                  )}
                </td>
                <td className="px-3 py-2.5">
                  <span className={`rounded border px-1.5 py-0.5 text-[10px] font-medium ${CATEGORY_STYLES[t.category] || CATEGORY_STYLES.utility}`}>
                    {t.category.toUpperCase()}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1">{t.language}</div>
                </td>
                <td className="px-3 py-2.5 text-[12px] text-slate-500">
                  {t.key ? (
                    <span className="rounded bg-violet-50 border border-violet-200 px-1.5 py-0.5 text-[10px] text-violet-700 font-medium">BOT REPLY</span>
                  ) : (
                    <span className="text-slate-400">custom — manual send</span>
                  )}
                  {t.key && <div className="mt-1">{PIPELINE_SLOT_LABELS[t.key] || t.key}</div>}
                </td>
                <td className="px-3 py-2.5 text-right font-medium text-slate-700">{t.usageCount}</td>
                <td className="px-3 py-2.5 text-[12px] text-slate-500">{t.lastUsedAt ? fmtTime(t.lastUsedAt) : '—'}</td>
                <td className="px-3 py-2.5">
                  <span className={`rounded border px-1.5 py-0.5 text-[10px] font-medium ${t.isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-200'}`}>
                    {t.isActive ? 'ACTIVE' : 'INACTIVE'}
                  </span>
                </td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-1.5 justify-end flex-wrap">
                    <button onClick={() => openSend(t)} disabled={!t.isActive}
                      className="inline-flex items-center gap-1 rounded border border-emerald-300 px-2 py-1 text-[11px] text-emerald-700 hover:bg-emerald-50 disabled:opacity-40">
                      <Send className="w-3 h-3" /> Send
                    </button>
                    {isSuper && (
                      <>
                        <button onClick={() => openEdit(t)}
                          className="inline-flex items-center gap-1 rounded border border-slate-300 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-50">
                          <Pencil className="w-3 h-3" /> Edit
                        </button>
                        <button onClick={() => toggleActive(t)} disabled={busyId === t.id}
                          className={`inline-flex items-center gap-1 rounded border px-2 py-1 text-[11px] disabled:opacity-40 ${t.isActive ? 'border-amber-300 text-amber-700 hover:bg-amber-50' : 'border-emerald-300 text-emerald-700 hover:bg-emerald-50'}`}>
                          <Power className="w-3 h-3" /> {t.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!isSuper && (
        <p className="mt-2 text-[11px] text-slate-400">Template editing is a Super Admin function — you can send active templates.</p>
      )}

      {/* ── Editor modal ── */}
      {(creating || editing) && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4" onClick={closeEditor}>
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-slate-800 flex items-center gap-2">
                <Tag className="w-4 h-4 text-indigo-500" />
                {editing ? `Edit — ${editing.name}` : 'New template'}
              </h3>
              <button onClick={closeEditor} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid md:grid-cols-2 gap-3 mb-3">
              <div>
                <label className="text-xs font-medium text-slate-500">Template name</label>
                <input value={fName} onChange={e => setFName(e.target.value)} placeholder="e.g. Diwali offer broadcast"
                  className="mt-1 w-full h-9 rounded-md border border-slate-300 px-2.5 text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500">Category</label>
                <select value={fCategory} onChange={e => setFCategory(e.target.value)}
                  className="mt-1 w-full h-9 rounded-md border border-slate-300 px-2.5 text-sm bg-white">
                  <option value="utility">Utility (transactional — order updates, confirmations)</option>
                  <option value="marketing">Marketing (offers, promotions, broadcasts)</option>
                  <option value="authentication">Authentication (OTPs, verification)</option>
                </select>
              </div>
              {creating && (
                <div className="md:col-span-2">
                  <label className="text-xs font-medium text-slate-500">Bot reply slot (optional — leave empty for a custom template)</label>
                  <select value={fKey} onChange={e => setFKey(e.target.value)}
                    className="mt-1 w-full h-9 rounded-md border border-slate-300 px-2.5 text-sm bg-white">
                    <option value="">— custom template (send manually) —</option>
                    {Object.entries(PIPELINE_SLOT_LABELS).map(([k, label]) => (
                      <option key={k} value={k} disabled={rows.some(r => r.key === k)}>{label}{rows.some(r => r.key === k) ? ' (occupied)' : ''}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            <div className="mb-1">
              <label className="text-xs font-medium text-slate-500">
                Body — use <code className="rounded bg-slate-100 px-1">{'{{variable}}'}</code> tokens; they become input fields when sending
              </label>
              <textarea value={fBody} onChange={e => setFBody(e.target.value)} rows={7} spellCheck={false}
                placeholder={'Hello {{customer_name}},\nWe received your vyapar for {{market_name}} — Total ₹{{total}}.'}
                className="mt-1 w-full rounded-md border border-slate-300 px-2.5 py-2 text-sm font-mono" />
              <div className="text-[11px] text-slate-400 mt-1">
                Detected variables: {(fBody.match(/\{\{\s*[\w.-]+\s*\}\}/g) || []).join(' ') || 'none'}
              </div>
            </div>
            <div className="mt-4 flex gap-2 justify-end">
              <button onClick={closeEditor} className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
              <button onClick={saveTemplate} disabled={busyId === 'editor'}
                className="inline-flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-60">
                <Check className="w-4 h-4" /> {editing ? 'Save changes' : 'Create template'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Send modal ── */}
      {sending && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4" onClick={() => setSending(null)}>
          <div className="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-slate-800 flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-500" /> Send — {sending.name}
              </h3>
              <button onClick={() => setSending(null)} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid md:grid-cols-2 gap-3 mb-3">
              <div>
                <label className="text-xs font-medium text-slate-500">App customer</label>
                <select value={sendTarget.startsWith('phone:') ? '' : sendTarget}
                  onChange={e => { setSendTarget(e.target.value); setSendPhone('') }}
                  className="mt-1 w-full h-9 rounded-md border border-slate-300 px-2.5 text-sm bg-white">
                  <option value="">— pick a customer —</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.name} ({c.mobile})</option>)}
                  {vendors.length > 0 && <optgroup label="ERP customers">
                    {vendors.map(v => <option key={v.id} value={v.id}>{v.businessName} ({v.mobileNo})</option>)}
                  </optgroup>}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500">…or raw WhatsApp number</label>
                <input value={sendPhone} onChange={e => { setSendPhone(e.target.value); setSendTarget(e.target.value ? 'phone:' : '') }}
                  placeholder="e.g. 9876543210" className="mt-1 w-full h-9 rounded-md border border-slate-300 px-2.5 text-sm" />
              </div>
            </div>
            {(sending.variableList?.length || 0) > 0 && (
              <div className="mb-3">
                <label className="text-xs font-medium text-slate-500">Variables (blanks use the saved sample)</label>
                <div className="grid md:grid-cols-2 gap-2 mt-1">
                  {sending.variableList.map(v => (
                    <div key={v.name}>
                      <div className="text-[10px] text-slate-400 mb-0.5">{`{{${v.name}}}`}</div>
                      <input value={sendParams[v.name] ?? ''}
                        onChange={e => setSendParams(p => ({ ...p, [v.name]: e.target.value }))}
                        placeholder={v.sample || 'value'}
                        className="w-full h-8 rounded-md border border-slate-300 px-2 text-xs" />
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="mb-3">
              <label className="text-xs font-medium text-slate-500">Preview (what the customer receives)</label>
              <pre className="mt-1 whitespace-pre-wrap text-xs text-slate-700 bg-emerald-50 rounded-md p-3 max-h-48 overflow-y-auto">{sendPreview || sending.bodyText}</pre>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setSending(null)} className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
              <button onClick={sendIt} disabled={busyId === 'send'}
                className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-60">
                <Send className={`w-4 h-4 ${busyId === 'send' ? 'animate-pulse' : ''}`} /> Send now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
