'use client'

// ──────────────────────────────────────────────────────────
// MARKET MANAGEMENT v2 PAGES
//   StarlinesPage — create / update / manage the short hourly
//     starline games (one or many, each with its own result
//     time, bet-closing window and ON/OFF switch). Unlike
//     markets they are NOT bound to the Name+Phase+Session
//     formula — the operator runs as many as needed.
//   ChartDataPage — backend input for every market's Jodi &
//     Panel chart: paste historical results (date + open panna
//     + close panna) and they silently fill the app's Results,
//     Jodi Chart and Panel Chart for that market.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, Modal } from '@/components/shared-ui'
import { Plus, Check, AlertTriangle, RefreshCw, Trash2, Pencil, Power, Clock, BarChart3, Upload, Zap } from 'lucide-react'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('success') || message.includes('updated') || message.includes('added') || message.includes('Saved') || message.includes('deleted') || message.includes('filled')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

interface StarlineRow {
  id: string; code: string; name: string
  hour: number; minute: number; betClosingMinutes: number
  isOn: boolean; isActive: boolean; sortOrder: number
}

const hhmm = (h: number, m: number) => `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`

// ──────────────────────────────────────────────────────────
// STARLINES MANAGEMENT
// ──────────────────────────────────────────────────────────
export function StarlinesPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const canEdit = currentUser?.role === 'super'
  const [rows, setRows] = useState<StarlineRow[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [showGen, setShowGen] = useState(false)
  const [editRow, setEditRow] = useState<StarlineRow | null>(null)
  const [form, setForm] = useState({ name: '', hour: '10', minute: '0', betClosingMinutes: 5 })
  const [genForm, setGenForm] = useState({ name: '', fromHour: '9', toHour: '20', minute: '5', betClosingMinutes: 5 })

  const load = useCallback(() => {
    apiFetch('/api/app-admin/starlines')
      .then((d: { starlines: StarlineRow[] }) => { setRows(d.starlines || []); setLoading(false) })
      .catch(e => { setMessage(e instanceof Error ? e.message : 'Failed to load'); setLoading(false) })
  }, [])

  useEffect(() => { load() }, [load])

  const add = async () => {
    try {
      await apiFetch('/api/app-admin/starlines', { method: 'POST', body: JSON.stringify(form) })
      setMessage('Starline added successfully')
      setShowAdd(false)
      setForm({ name: '', hour: '10', minute: '0', betClosingMinutes: 5 })
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const generate = async () => {
    try {
      const d = await apiFetch('/api/app-admin/starlines', {
        method: 'POST',
        body: JSON.stringify({
          action: 'generate', name: genForm.name,
          fromHour: Number(genForm.fromHour), toHour: Number(genForm.toHour),
          minute: Number(genForm.minute), betClosingMinutes: genForm.betClosingMinutes,
        }),
      }) as { message?: string }
      setMessage(d.message || 'Hourly starlines generated successfully')
      setShowGen(false)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const saveEdit = async () => {
    if (!editRow) return
    try {
      await apiFetch('/api/app-admin/starlines', {
        method: 'PATCH',
        body: JSON.stringify({ id: editRow.id, name: editRow.name, hour: editRow.hour, minute: editRow.minute, betClosingMinutes: editRow.betClosingMinutes }),
      })
      setMessage('Starline updated successfully')
      setEditRow(null)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const toggleOn = async (r: StarlineRow) => {
    try {
      await apiFetch('/api/app-admin/starlines', { method: 'PATCH', body: JSON.stringify({ id: r.id, isOn: !r.isOn }) })
      setMessage(r.isOn ? `${r.name} switched OFF — hidden from the app` : `${r.name} switched ON`)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const remove = async (r: StarlineRow) => {
    if (!window.confirm(`Delete ${r.name}? Customers can no longer bet on it.`)) return
    try {
      await apiFetch('/api/app-admin/starlines?id=' + r.id, { method: 'DELETE' })
      setMessage(`${r.name} deleted successfully`)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Starlines</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Short-duration hourly games — create one or many, each with its own result time and bet-closing window. Starlines are separate from markets and are declared in the Starline Results section.</p>
        </div>
        {canEdit ? (
          <div className="flex gap-2">
            <OutlineButton onClick={() => setShowGen(true)}><Zap size={14} /> Generate Hourly Slots</OutlineButton>
            <GoldButton onClick={() => setShowAdd(true)}><Plus size={14} /> Add Starline</GoldButton>
          </div>
        ) : null}
      </div>
      <Msg message={message} />
      {loading ? <p className="text-[12px] text-[#9CA3AF]">Loading starlines…</p> : null}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {rows.map(r => (
          <div key={r.id} className={`border rounded-xl p-3.5 bg-white ${r.isActive ? 'border-[#E5E7EB]' : 'border-dashed border-[#D1D5DB] opacity-70'}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <b className="text-[14px] text-[#111827]">{r.name}</b>
                  <span className="text-[10px] font-mono text-[#6B7280] bg-[#F3F4F6] rounded px-1.5 py-0.5">{r.code}</span>
                  <button
                    onClick={() => canEdit && toggleOn(r)} disabled={!canEdit}
                    title={r.isOn ? 'Master switch — click to turn the starline OFF' : 'Master switch — click to turn the starline ON'}
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded inline-flex items-center gap-1 ${r.isOn ? 'bg-[#ECFDF5] text-[#059669]' : 'bg-[#FEE2E2] text-[#B91C1C]'}`}
                  ><Power size={10} />{r.isOn ? 'ON' : 'OFF'}</button>
                </div>
                <div className="flex items-center gap-1.5 mt-1.5 text-[11.5px] text-[#374151]">
                  <Clock size={12} className="text-[#2563EB]" />
                  Result at <b className="font-semibold">{hhmm(r.hour, r.minute)}</b>
                </div>
                <div className="text-[11px] text-[#6B7280] mt-1">Bets stop <b className="text-[#B45309]">{r.betClosingMinutes} min</b> before the result time</div>
              </div>
            </div>
            {canEdit ? (
              <div className="flex items-center justify-end gap-1.5 mt-3 pt-2.5 border-t border-[#F3F4F6]">
                <button onClick={() => setEditRow({ ...r })} className="text-[11px] font-semibold text-[#2563EB] px-2 py-1 rounded-md hover:bg-[#EFF6FF] flex items-center gap-1"><Pencil size={11} />Edit</button>
                <button onClick={() => remove(r)} className="text-[11px] font-semibold text-[#DC2626] px-2 py-1 rounded-md hover:bg-[#FEF2F2] flex items-center gap-1"><Trash2 size={11} />Delete</button>
              </div>
            ) : null}
          </div>
        ))}
      </div>
      {!loading && !rows.length ? <p className="text-[12px] text-[#9CA3AF]">No starlines yet — add the first one.</p> : null}

      {showAdd ? (
        <Modal open title="Add Starline" onClose={() => setShowAdd(false)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Name (optional — auto from time)"><FormInput placeholder="e.g. Morning Starline" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></FormField>
            <FormField label="Result Time">
              <div className="flex gap-2">
                <FormSelect value={form.hour} onChange={e => setForm(f => ({ ...f, hour: e.target.value }))} className="flex-1">
                  {Array.from({ length: 24 }, (_, h) => <option key={h} value={h}>{String(h).padStart(2, '0')} h</option>)}
                </FormSelect>
                <FormSelect value={form.minute} onChange={e => setForm(f => ({ ...f, minute: e.target.value }))} className="flex-1">
                  {['0', '15', '30', '45'].map(m => <option key={m} value={m}>{String(m).padStart(2, '0')} m</option>)}
                </FormSelect>
              </div>
            </FormField>
            <FormField label="Bet Closing Minutes"><FormInput type="number" min={0} max={120} value={form.betClosingMinutes} onChange={e => setForm(f => ({ ...f, betClosingMinutes: Number(e.target.value) }))} /></FormField>
          </div>
          <p className="text-[11px] text-[#6B7280] mt-3">One starline per result hour. Customers see it in the app Starline screen immediately; betting stops {form.betClosingMinutes} min before the result time.</p>
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setShowAdd(false)}>Cancel</OutlineButton>
            <GoldButton onClick={add}><Plus size={14} /> Create Starline</GoldButton>
          </div>
        </Modal>
      ) : null}

      {showGen ? (
        <Modal open title="Generate Hourly Starline Slots" onClose={() => setShowGen(false)}>
          <p className="text-[12px] text-[#6B7280] mb-4">Create a full day of hourly games from ONE config — e.g. name <b>Main Star Line</b> from <b>09</b> to <b>20</b> at minute <b>05</b> generates Main Star Line 09:05 AM, 10:05 AM … 08:05 PM (one starline per hour, exactly like the reference charts). Hours that already exist are kept as-is.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Starline Name"><FormInput placeholder="e.g. Main Star Line" value={genForm.name} onChange={e => setGenForm(f => ({ ...f, name: e.target.value }))} /></FormField>
            <FormField label="Result Minute">
              <FormSelect value={genForm.minute} onChange={e => setGenForm(f => ({ ...f, minute: e.target.value }))}>
                {['0', '5', '10', '15', '30', '45'].map(m => <option key={m} value={m}>{String(m).padStart(2, '0')} m past each hour</option>)}
              </FormSelect>
            </FormField>
            <FormField label="From Hour (first result)">
              <FormSelect value={genForm.fromHour} onChange={e => setGenForm(f => ({ ...f, fromHour: e.target.value }))}>
                {Array.from({ length: 24 }, (_, h) => <option key={h} value={h}>{String(h).padStart(2, '0')} h</option>)}
              </FormSelect>
            </FormField>
            <FormField label="To Hour (last result)">
              <FormSelect value={genForm.toHour} onChange={e => setGenForm(f => ({ ...f, toHour: e.target.value }))}>
                {Array.from({ length: 24 }, (_, h) => <option key={h} value={h}>{String(h).padStart(2, '0')} h</option>)}
              </FormSelect>
            </FormField>
            <FormField label="Bet Closing Minutes"><FormInput type="number" min={0} max={120} value={genForm.betClosingMinutes} onChange={e => setGenForm(f => ({ ...f, betClosingMinutes: Number(e.target.value) }))} /></FormField>
          </div>
          <p className="text-[11px] text-[#6B7280] mt-3">Declare each hourly result from Market Results → the starline&apos;s hour. Betting per hour stops {genForm.betClosingMinutes} min before its result time automatically.</p>
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setShowGen(false)}>Cancel</OutlineButton>
            <GoldButton onClick={generate}><Zap size={14} /> Generate Slots</GoldButton>
          </div>
        </Modal>
      ) : null}

      {editRow ? (
        <Modal open title={`Edit Starline — ${editRow.name}`} onClose={() => setEditRow(null)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Name"><FormInput value={editRow.name} onChange={e => setEditRow(r => r ? { ...r, name: e.target.value } : r)} /></FormField>
            <FormField label="Result Time">
              <div className="flex gap-2">
                <FormSelect value={String(editRow.hour)} onChange={e => setEditRow(r => r ? { ...r, hour: Number(e.target.value) } : r)} className="flex-1">
                  {Array.from({ length: 24 }, (_, h) => <option key={h} value={h}>{String(h).padStart(2, '0')} h</option>)}
                </FormSelect>
                <FormSelect value={String(editRow.minute)} onChange={e => setEditRow(r => r ? { ...r, minute: Number(e.target.value) } : r)} className="flex-1">
                  {['0', '15', '30', '45'].map(m => <option key={m} value={m}>{String(m).padStart(2, '0')} m</option>)}
                </FormSelect>
              </div>
            </FormField>
            <FormField label="Bet Closing Minutes"><FormInput type="number" min={0} max={120} value={editRow.betClosingMinutes} onChange={e => setEditRow(r => r ? { ...r, betClosingMinutes: Number(e.target.value) } : r)} /></FormField>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setEditRow(null)}>Cancel</OutlineButton>
            <GoldButton onClick={saveEdit}><Check size={14} /> Save Starline</GoldButton>
          </div>
        </Modal>
      ) : null}
    </div>
  )
}

// ──────────────────────────────────────────────────────────
// JODI & PANEL CHART DATA — backend input for all markets
// ──────────────────────────────────────────────────────────
interface ChartMarket { code: string; name: string; session?: string; phase?: string }
interface ChartRow { resultDate: string; openPanna: string | null; closePanna: string | null; openDigit: string | null; closeDigit: string | null; jodi: string | null }
interface ParsedEntry { resultDate: string; openPanna: string; closePanna: string; jodi: string; error?: string }

// Accepts one entry per line: <date> <open panna> <close panna>
// e.g. "01-09-2026 137 347" · "2026/09/01,137,347" · "2026-09-01 137-347"
function parseChartPaste(text: string): { entries: ParsedEntry[]; errors: string[] } {
  const entries: ParsedEntry[] = []
  const errors: string[] = []
  const digitOf = (p: string) => String(p.split('').reduce((a, c) => a + Number(c), 0) % 10)
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim()
    if (!line) continue
    const tokens = line.split(/[\s,;|]+/).filter(Boolean)
    if (tokens.length < 2) { errors.push(`Too few fields: "${line}"`); continue }
    // date = first token that looks like a date (dashes or slashes, 6-10 chars)
    const dateTok = tokens.find(t => /^\d{1,4}[-/]\d{1,2}([-/]\d{1,4})?$/.test(t))
    if (!dateTok) { errors.push(`No date found: "${line}"`); continue }
    // normalize dd-mm-yyyy / dd/mm/yyyy → yyyy-mm-dd
    let iso = ''
    const dmy = dateTok.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/)
    if (dmy) iso = `${dmy[3]}-${dmy[2].padStart(2, '0')}-${dmy[1].padStart(2, '0')}`
    else {
      const ymd = dateTok.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/)
      if (ymd) iso = `${ymd[1]}-${ymd[2].padStart(2, '0')}-${ymd[3].padStart(2, '0')}`
      else iso = dateTok // last resort (yyyy-mm-dd already clean)
    }
    const pannas = tokens.filter(t => t !== dateTok && /^\d{3}$/.test(t.replace(/\D/g, '') ? t.replace(/\D/g, '') : t))
      .map(t => t.replace(/\D/g, ''))
      .filter(t => t.length === 3)
    if (!pannas.length) { errors.push(`No 3-digit panna: "${line}"`); continue }
    const open = pannas[0]
    const close = pannas[1] || ''
    const jodi = close ? digitOf(open) + digitOf(close) : digitOf(open)
    entries.push({ resultDate: iso, openPanna: open, closePanna: close, jodi })
  }
  return { entries, errors }
}

export function ChartDataPage() {
  const [markets, setMarkets] = useState<ChartMarket[]>([])
  const [market, setMarket] = useState('')
  const [paste, setPaste] = useState('')
  const [rows, setRows] = useState<ChartRow[]>([])
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    apiFetch('/api/app-admin/markets')
      .then((d: { markets: ChartMarket[] }) => {
        setMarkets(d.markets || [])
        if (d.markets?.length) setMarket(d.markets[0].code)
      })
      .catch(e => setMessage(e instanceof Error ? e.message : 'Failed to load markets'))
  }, [])

  const loadRows = useCallback(() => {
    if (!market) return
    apiFetch('/api/app-admin/chart-data?market=' + market)
      .then((d: { results: ChartRow[] }) => setRows(d.results || []))
      .catch(() => setRows([]))
  }, [market])

  useEffect(() => { loadRows() }, [loadRows])

  const preview = paste.trim() ? parseChartPaste(paste) : { entries: [], errors: [] }

  const save = async () => {
    if (!market || !preview.entries.length) { setMessage('Paste at least one valid line first'); return }
    setBusy(true)
    try {
      const d = await apiFetch('/api/app-admin/chart-data', {
        method: 'POST',
        body: JSON.stringify({ marketCode: market, entries: preview.entries.map(e => ({ resultDate: e.resultDate, openPanna: e.openPanna, closePanna: e.closePanna || null })) }),
      }) as { updated: number; skipped: number }
      setMessage(`Chart data saved successfully — ${d.updated} day${d.updated === 1 ? '' : 's'} filled for ${markets.find(m => m.code === market)?.name}. The app's Results, Jodi Chart and Panel Chart update instantly.`)
      setPaste('')
      loadRows()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') } finally { setBusy(false) }
  }

  const mkLabel = (m: ChartMarket) => {
    const phase = m.phase === 'night' ? ' Night' : m.phase === 'day' ? ' Day' : ''
    const sess = m.session === 'both' ? '' : m.session === 'open' ? ' Open' : m.session === 'close' ? ' Close' : ''
    return m.name + phase + sess
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2"><BarChart3 size={20} className="text-indigo-600" /> Jodi &amp; Panel Chart Data</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Backend input for every market&apos;s Jodi Chart and Panel Chart — paste historical results and they fill the customer app instantly. One entry per line: <span className="font-mono text-[#374151]">date, open panna, close panna</span> (e.g. <span className="font-mono">01-09-2026 137 347</span>).</p>
      </div>
      <Msg message={message} />

      <SectionCard title="Paste Chart Data">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <FormField label="Market">
            <FormSelect value={market} onChange={e => setMarket(e.target.value)}>
              {markets.map(m => <option key={m.code} value={m.code}>{mkLabel(m)}</option>)}
            </FormSelect>
          </FormField>
          <div className="md:col-span-2 flex items-end text-[11.5px] text-[#6B7280]">
            The digits and jodi are derived automatically (124 → 7, 470 → 1, jodi 71). Past dates only — today&apos;s result is declared in Market Results.
          </div>
        </div>
        <textarea
          value={paste}
          onChange={e => setPaste(e.target.value)}
          placeholder={'01-09-2026 137 347\n02-09-2026 128 246\n2026-09-03 380 470'}
          rows={7}
          className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] placeholder:text-[#9CA3AF] w-full resize-y font-mono"
        />
        {preview.entries.length || preview.errors.length ? (
          <div className="mt-3 border border-[#E5E7EB] rounded-lg overflow-hidden">
            <div className="bg-[#F8FAFC] px-3 py-2 text-[11px] font-bold text-[#6B7280] uppercase tracking-wide">Preview — {preview.entries.length} valid · {preview.errors.length} problem line{preview.errors.length === 1 ? '' : 's'}</div>
            <div className="max-h-44 overflow-y-auto">
              <table className="w-full text-[12px]">
                <thead><tr className="text-left text-[10px] uppercase text-[#9CA3AF] border-b border-[#F3F4F6]">
                  <th className="px-3 py-1.5">Date</th><th className="px-3 py-1.5">Open</th><th className="px-3 py-1.5">Close</th><th className="px-3 py-1.5">Jodi</th>
                </tr></thead>
                <tbody>
                  {preview.entries.map(e => (
                    <tr key={e.resultDate} className="border-b border-[#F8FAFC]">
                      <td className="px-3 py-1.5 font-mono">{e.resultDate}</td>
                      <td className="px-3 py-1.5 font-mono font-bold text-[#2563EB]">{e.openPanna}</td>
                      <td className="px-3 py-1.5 font-mono font-bold text-[#2563EB]">{e.closePanna || '—'}</td>
                      <td className="px-3 py-1.5"><span className="font-mono font-bold bg-[#EFF6FF] text-[#1D4ED8] rounded px-1.5 py-0.5">{e.jodi}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {preview.errors.length ? (
                <div className="px-3 py-2 text-[11px] text-[#DC2626] bg-[rgba(220,38,38,0.04)]">{preview.errors.slice(0, 5).join(' · ')}{preview.errors.length > 5 ? ' …' : ''}</div>
              ) : null}
            </div>
          </div>
        ) : null}
        <div className="flex justify-end gap-2 mt-4">
          <OutlineButton onClick={() => { setPaste(''); setMessage('') }}>Clear</OutlineButton>
          <GoldButton onClick={save} disabled={busy || !preview.entries.length}><Upload size={14} /> {busy ? 'Saving…' : `Fill Chart (${preview.entries.length} days)`}</GoldButton>
        </div>
      </SectionCard>

      <SectionCard
        title={`Stored Chart Data — ${mkLabel(markets.find(m => m.code === market) || { code: '', name: '' })} (${rows.length})`}
        headerRight={<button onClick={loadRows} className="p-1.5 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]" title="Refresh"><RefreshCw size={14} /></button>}
      >
        {rows.length ? (
          <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
            <table className="w-full text-[12px]">
              <thead><tr className="text-left text-[10px] uppercase tracking-wide text-[#9CA3AF] border-b border-[#E5E7EB] sticky top-0 bg-white">
                <th className="py-2 pr-3">Date</th><th className="py-2 pr-3">Open Panna</th><th className="py-2 pr-3">Open Digit</th><th className="py-2 pr-3">Close Panna</th><th className="py-2 pr-3">Close Digit</th><th className="py-2 pr-3">Jodi</th>
              </tr></thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.resultDate} className="border-b border-[#F3F4F6] hover:bg-[#F8FAFC]">
                    <td className="py-2 pr-3 font-mono">{r.resultDate}</td>
                    <td className="py-2 pr-3 font-mono font-bold text-[#2563EB]">{r.openPanna || '—'}</td>
                    <td className="py-2 pr-3 font-mono">{r.openDigit || '·'}</td>
                    <td className="py-2 pr-3 font-mono font-bold text-[#2563EB]">{r.closePanna || '—'}</td>
                    <td className="py-2 pr-3 font-mono">{r.closeDigit || '·'}</td>
                    <td className="py-2 pr-3"><span className="font-mono font-bold bg-[#EFF6FF] text-[#1D4ED8] rounded px-2 py-0.5">{r.jodi || '—'}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-[12px] text-[#9CA3AF] py-4">No chart data stored for this market yet — declared results appear here automatically, or paste historical data above.</p>
        )}
      </SectionCard>
    </div>
  )
}
