'use client'

// ──────────────────────────────────────────────────────────
// MARKET EXPANSION PANELS (ERP side) — reference dashboard UI
//   MarketResultsPage — quick declare every game, auto-settles
//   UniversesPage     — SP/DP/TP/Jodi/Single/Sangam reference
//   AppChartsPage     — market charts built from app entries
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import { SPB, DPB, TP, deriveDigit, istDate, isStarline, starlineName } from '@/lib/matka/app-engine'
import { Trophy, Grid3x3, BarChart3, Zap, RefreshCw, AlertTriangle, Check, Users, Smartphone, Clock, Share2 } from 'lucide-react'

const inr = (n: number | null | undefined) => '₹' + Number(n || 0).toLocaleString('en-IN')
const istShift = (days: number) => {
  const d = new Date(Date.now() + 5.5 * 3600 * 1000 - days * 86400000)
  return d.toISOString().slice(0, 10)
}

interface MarketRow {
  code: string; name: string; category: string
  openTime: string; closeTime: string; isActive: boolean
}
interface ResultRow {
  marketCode: string; marketName: string; resultDate: string
  openPanna: string | null; closePanna: string | null
  openDigit: string | null; closeDigit: string | null
  jodi: string | null; declaredBy: string
  declaredAt?: string; updatedAt?: string
}
interface ChartData {
  market: { code: string; name: string; openTime: string; closeTime: string; isActive: boolean }
  date: string; isStarline: boolean
  counts: { bets: number; customers: number; staked: number; potential: number }
  openAnk: number[]; closeAnk: number[]; starAnk: number[]
  oddEven: { odd: number; even: number }
  jodi: number[]
  pannas: Array<{ num: string; type: string; slot: string; amount: number; bets: number }>
  customers: Array<{ id: string; name: string; mobile: string; bets: number; staked: number }>
  whatsapp?: string
}

function H1({ icon, title, sub, right }: { icon: React.ReactNode; title: string; sub: string; right?: React.ReactNode }) {
  return (
    <div className="mb-5 flex items-start justify-between flex-wrap gap-3">
      <div>
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          {icon} {title}
        </h1>
        <p className="text-[12px] text-[#6B7280] mt-1">{sub}</p>
      </div>
      {right}
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// MARKET RESULTS — quick declare grid (main markets + starline)
// ══════════════════════════════════════════════════════════
export function MarketResultsPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [date, setDate] = useState(istDate())
  const [tab, setTab] = useState<'main' | 'star'>('main')
  const [markets, setMarkets] = useState<MarketRow[]>([])
  const [results, setResults] = useState<ResultRow[]>([])
  const [open, setOpen] = useState<Record<string, string>>({})
  const [close, setClose] = useState<Record<string, string>>({})
  const [star, setStar] = useState<Record<number, string>>({})
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)
  const [winnerNote, setWinnerNote] = useState('')

  const load = useCallback(() => {
    apiFetch('/api/app-admin/results').then((d: { results: ResultRow[]; markets: MarketRow[] }) => {
      setResults(d.results); setMarkets(d.markets)
    }).catch(() => setMsg('Failed to load results'))
  }, [])
  useEffect(() => { load() }, [load])

  const resultMap = useMemo(() => Object.fromEntries(results.map(r => [r.marketCode + '|' + r.resultDate, r])), [results])

  const declareOne = async (marketCode: string, openPanna?: string, closePanna?: string) => {
    const d = await apiFetch('/api/app-admin/results', {
      method: 'POST',
      body: JSON.stringify({ marketCode, resultDate: date, openPanna: openPanna || undefined, closePanna: closePanna || undefined }),
    }) as { settlement: { won: number; totalWin: number } }
    return d.settlement
  }

  // Save ONE market's result (single-market save — other markets untouched)
  const saveOne = async (marketCode: string, name: string) => {
    const o = (open[marketCode] || '').trim(), c = (close[marketCode] || '').trim()
    if (!/^\d{3}$/.test(o) && !/^\d{3}$/.test(c)) {
      setMsg(`Enter the open or close panna for ${name} first`)
      return
    }
    setBusy(true); setMsg(''); setWinnerNote('')
    try {
      const s = await declareOne(marketCode, o || undefined, c || undefined)
      setWinnerNote(`${name} result saved · ${s.won} winning bid${s.won === 1 ? '' : 's'} paid ${inr(s.totalWin)} automatically`)
      setOpen(prev => ({ ...prev, [marketCode]: '' })); setClose(prev => ({ ...prev, [marketCode]: '' }))
      load()
    } catch (e) { setMsg(e instanceof Error ? e.message : 'Declare failed') }
    setBusy(false)
  }

  const declareAll = async () => {
    setBusy(true); setMsg(''); setWinnerNote('')
    try {
      let n = 0, won = 0, paid = 0
      if (tab === 'main') {
        for (const m of markets.filter(x => x.isActive)) {
          const o = (open[m.code] || '').trim(), c = (close[m.code] || '').trim()
          if (/^\d{3}$/.test(o) || /^\d{3}$/.test(c)) {
            const s = await declareOne(m.code, o || undefined, c || undefined)
            n++; won += s.won; paid += s.totalWin
          }
        }
      } else {
        for (let h = 0; h < 24; h++) {
          const v = (star[h] || '').trim()
          if (/^\d{3}$/.test(v)) {
            const s = await declareOne('st' + h, v)
            n++; won += s.won; paid += s.totalWin
          }
        }
      }
      if (!n) { setMsg('Enter at least one 3-digit panna to declare'); setBusy(false); return }
      setWinnerNote(`${n} declaration${n > 1 ? 's' : ''} saved · ${won} winning bid${won === 1 ? '' : 's'} paid ${inr(paid)} automatically`)
      setOpen({}); setClose({}); setStar({}); load()
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Declare failed')
    }
    setBusy(false)
  }

  const digitBox = (v: string) => (
    <span className="min-w-[27px] h-[28px] px-1 grid place-items-center rounded-lg bg-[rgba(37,99,235,.15)] text-[#60A5FA] font-extrabold font-mono text-[14px]">
      {/^\d{3}$/.test(v) ? deriveDigit(v) : '—'}
    </span>
  )

  const activeMarkets = markets.filter(m => m.isActive)
  return (
    <div className="p-7 animate-in fade-in duration-300">
      <H1 icon={<Trophy size={22} className="text-[#60A5FA]" />} title="Market Results"
        sub="Declare per market or all at once · jodi = last digit of open panna's digit-sum + close panna's digit-sum (e.g. 124-71-470: 1+2+4=7, 4+7+0=1 → jodi 71)" />
      {msg ? (
        <div className="bg-[rgba(248,113,113,.12)] text-[#F87171] border border-[rgba(248,113,113,.35)] text-[12px] px-3 py-2 rounded-lg mb-4 flex items-center gap-2"><AlertTriangle size={14} /> {msg}</div>
      ) : null}
      {winnerNote ? (
        <div className="bg-[rgba(74,222,128,.12)] text-[#4ADE80] border border-[rgba(74,222,128,.35)] text-[12px] px-3 py-2 rounded-lg mb-4 flex items-center gap-2"><Check size={14} /> {winnerNote}</div>
      ) : null}

      <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl px-4 py-3 mb-4 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-[12px] font-semibold text-[#6B7280]">Result date</span>
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="text-[12.5px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-1.5 text-[#374151] outline-none focus:border-[#60A5FA]" />
        </div>
        <div className="inline-flex bg-[rgba(148,163,184,.08)] rounded-[11px] p-0.5">
          <button onClick={() => setTab('main')} className={`text-[12px] font-bold px-3.5 py-1.5 rounded-[9px] ${tab === 'main' ? 'bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF]' : 'text-[#6B7280]'}`}>Main Markets</button>
          <button onClick={() => setTab('star')} className={`text-[12px] font-bold px-3.5 py-1.5 rounded-[9px] ${tab === 'star' ? 'bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF]' : 'text-[#6B7280]'}`}>Starline 24</button>
        </div>
        {isSuper ? (
          <button onClick={declareAll} disabled={busy}
            className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold px-3.5 py-2 rounded-[10px] bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF] hover:brightness-110 disabled:opacity-50">
            <Zap size={14} /> {busy ? 'Declaring…' : 'Declare All Filled'}
          </button>
        ) : <span className="text-[11px] text-[#6B7280]">Declare is Super Admin only</span>}
      </div>

      {tab === 'main' ? (
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))' }}>
          {activeMarkets.map(m => {
            const r = resultMap[m.code + '|' + date]
            const ov = open[m.code] || '', cv = close[m.code] || ''
            const ro = r && r.openPanna ? `${r.openPanna}-${r.openDigit}` : null
            const rc = r && r.closePanna ? `${r.closePanna}-${r.closeDigit}` : null
            return (
              <div key={m.code} className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <b className="text-[13.5px] text-[#111827]">{m.name}</b>
                  {r ? (
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${ro && rc ? 'bg-[rgba(74,222,128,.15)] text-[#4ADE80]' : 'bg-[rgba(251,146,60,.15)] text-[#FB923C]'}`}>
                      {ro && rc ? 'declared' : 'partial'}
                    </span>
                  ) : <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(148,163,184,.15)] text-[#6B7280]">pending</span>}
                </div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[10.5px] font-bold text-[#6B7280] w-10">OPEN</span>
                  <input value={ov} disabled={!isSuper || !!ro} maxLength={3} placeholder="---"
                    onChange={e => setOpen(s => ({ ...s, [m.code]: e.target.value.replace(/\D/g, '').slice(0, 3) }))}
                    className="w-[74px] text-center font-mono font-bold text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-[10px] px-2 py-[6px] text-[#374151] outline-none focus:border-[#60A5FA]" />
                  {digitBox(ov)}
                  {ro ? <span className="text-[10.5px] font-mono text-[#6B7280]">{ro}</span> : null}
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10.5px] font-bold text-[#6B7280] w-10">CLOSE</span>
                  <input value={cv} disabled={!isSuper || !!rc} maxLength={3} placeholder="---"
                    onChange={e => setClose(s => ({ ...s, [m.code]: e.target.value.replace(/\D/g, '').slice(0, 3) }))}
                    className="w-[74px] text-center font-mono font-bold text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-[10px] px-2 py-[6px] text-[#374151] outline-none focus:border-[#60A5FA]" />
                  {digitBox(cv)}
                  {rc ? <span className="text-[10.5px] font-mono text-[#6B7280]">{rc}</span> : null}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10.5px] font-bold text-[#6B7280]">JODI</span>
                  <span className="min-w-[27px] h-[28px] px-1.5 grid place-items-center rounded-lg bg-[rgba(139,92,246,.18)] text-[#7C3AED] font-extrabold font-mono text-[14px]">
                    {/^\d{3}$/.test(ov) && /^\d{3}$/.test(cv) ? deriveDigit(ov) + deriveDigit(cv) : r?.jodi || '—'}
                  </span>
                </div>
                {r?.declaredAt ? (
                  <div className="text-[10px] text-slate-400 mt-2 flex items-center gap-1"><Clock size={10} /> declared {new Date(r.declaredAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true })} by {r.declaredBy}</div>
                ) : null}
                {isSuper ? (
                  <button onClick={() => saveOne(m.code, m.name)} disabled={busy}
                    className="mt-2 w-full inline-flex items-center justify-center gap-1.5 text-[12px] font-bold px-3 py-2 rounded-[10px] bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-white hover:brightness-110 disabled:opacity-50">
                    <Zap size={13} /> Save &amp; Settle This Market
                  </button>
                ) : null}
              </div>
            )
          })}
        </div>
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">Starline — 24 Hour Games ({date})</h3>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(37,99,235,.15)] text-[#60A5FA]">one panna per hour</span>
          </div>
          <div>
            {Array.from({ length: 24 }, (_, h) => {
              const r = resultMap['st' + h + '|' + date]
              const v = star[h] || ''
              return (
                <div key={h} className="flex items-center gap-3 px-4 py-2 border-t border-[#F3F4F6] first:border-t-0">
                  <span className="w-[64px] text-center font-mono text-[12px] font-bold px-1.5 py-1 rounded-lg bg-[rgba(148,163,184,.1)] text-[#9CA3AF]">{String(h).padStart(2, '0')}:00</span>
                  {r ? (
                    <>
                      <span className="font-mono font-extrabold text-[#374151]">{r.openPanna}-{r.openDigit}</span>
                      <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(74,222,128,.15)] text-[#4ADE80]">declared</span>
                    </>
                  ) : (
                    <>
                      <input value={v} disabled={!isSuper} maxLength={3} placeholder="---"
                        onChange={e => setStar(s => ({ ...s, [h]: e.target.value.replace(/\D/g, '').slice(0, 3) }))}
                        className="w-[74px] text-center font-mono font-bold text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-[10px] px-2 py-[6px] text-[#374151] outline-none focus:border-[#60A5FA]" />
                      {digitBox(v)}
                      <span className="text-[11px] text-[#9CA3AF]">enter panna</span>
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* History */}
      <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden mt-4">
        <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
          <h3 className="text-[14px] font-bold text-[#111827]">Game Result History</h3>
          <button onClick={load} className="p-1.5 rounded-lg border border-[#E5E7EB] hover:border-[#3B82F6] text-[#6B7280]" aria-label="Refresh"><RefreshCw size={14} /></button>
        </div>
        <div className="max-h-[320px] overflow-auto">
          <table className="w-full text-[12.5px]">
            <thead>
              <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#6B7280] bg-[rgba(148,163,184,.07)]">
                <th className="py-2 px-3.5 font-semibold">Date</th><th className="py-2 px-3.5 font-semibold">Market</th>
                <th className="py-2 px-3.5 font-semibold">Open</th><th className="py-2 px-3.5 font-semibold">Close</th>
                <th className="py-2 px-3.5 font-semibold">Jodi</th><th className="py-2 px-3.5 font-semibold">Status</th>
                <th className="py-2 px-3.5 font-semibold">Declared At</th><th className="py-2 px-3.5 font-semibold">By</th>
              </tr>
            </thead>
            <tbody>
              {results.slice(0, 100).map(r => (
                <tr key={r.marketCode + r.resultDate} className="border-t border-[#F3F4F6] hover:bg-[rgba(148,163,184,.05)]">
                  <td className="py-2 px-3.5 text-[#6B7280] text-[11px]">{r.resultDate}</td>
                  <td className="py-2 px-3.5"><b className="text-[#374151]">{r.marketName}</b></td>
                  <td className="py-2 px-3.5 font-mono text-[#374151]">{r.openPanna ? `${r.openPanna}-${r.openDigit}` : '—'}</td>
                  <td className="py-2 px-3.5 font-mono text-[#374151]">{r.closePanna ? `${r.closePanna}-${r.closeDigit}` : '—'}</td>
                  <td className="py-2 px-3.5 font-mono font-bold text-[#60A5FA]">{r.jodi || '—'}</td>
                  <td className="py-2 px-3.5">
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${r.openPanna && r.closePanna ? 'bg-[rgba(74,222,128,.15)] text-[#4ADE80]' : 'bg-[rgba(251,146,60,.15)] text-[#FB923C]'}`}>
                      {r.openPanna && r.closePanna ? 'complete' : 'partial'}
                    </span>
                  </td>
                  <td className="py-2 px-3.5 text-[#6B7280] text-[11px]">{r.declaredAt ? new Date(r.declaredAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'}</td>
                  <td className="py-2 px-3.5 text-[#6B7280] text-[11px]">{r.declaredBy}</td>
                </tr>
              ))}
              {!results.length && <tr><td colSpan={8} className="py-6 text-center text-[#6B7280]">No results declared yet</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// NUMBER UNIVERSES — validation reference (SP/DP/TP/Jodi/etc.)
// ══════════════════════════════════════════════════════════
const JODIS = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'))
export function UniversesPage() {
  const [tab, setTab] = useState<'sp' | 'dp' | 'tp' | 'jodi' | 'single' | 'sangam'>('sp')
  const tabs: Array<[typeof tab, string]> = [
    ['sp', 'SP Pana'], ['dp', 'DP Pana'], ['tp', 'TP Pana'],
    ['jodi', 'Jodi'], ['single', 'Single Ank'], ['sangam', 'Sangam'],
  ]
  const U = tab === 'sp' ? SPB : DPB
  return (
    <div className="p-7 animate-in fade-in duration-300">
      <H1 icon={<Grid3x3 size={22} className="text-[#60A5FA]" />} title="Number Universes"
        sub="The validation universe for every mode — what the app accepts and what results pay on" />
      <div className="flex gap-2 flex-wrap mb-3.5">
        {tabs.map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`text-[12px] font-semibold px-3.5 py-[7px] rounded-full ${tab === id ? 'bg-[rgba(37,99,235,.15)] text-[#60A5FA]' : 'bg-[rgba(148,163,184,.15)] text-[#6B7280]'}`}>
            {label}
          </button>
        ))}
      </div>

      {(tab === 'sp' || tab === 'dp') && (
        <>
          <p className="text-[12.5px] text-[#6B7280] mb-3">{tab === 'sp' ? 'Single Pana — 120 numbers' : 'Double Pana — 90 numbers'} · grouped by result ank · this IS the validation universe</p>
          {Object.keys(U).map(ank => (
            <div key={ank} className="bg-[rgba(148,163,184,.06)] rounded-xl px-3 py-2.5 mb-2.5">
              <span className="inline-block text-[12.5px] font-extrabold font-mono px-3 py-1 rounded-lg bg-[rgba(251,146,60,.15)] text-[#FB923C] mb-2">ANK {ank}</span>
              <div className="flex flex-wrap gap-1.5">
                {U[ank].map(p => <span key={p} className="font-mono font-bold text-[12px] rounded-md px-2 py-1 bg-[rgba(74,222,128,.13)] text-[#6EE7B7]">{p}</span>)}
              </div>
            </div>
          ))}
        </>
      )}

      {tab === 'tp' && (
        <>
          <p className="text-[12.5px] text-[#6B7280] mb-3">Triple Pana — 10 numbers, one per ank · starline only</p>
          <div className="flex flex-wrap gap-2">
            {TP.map(p => <span key={p} className="font-mono font-bold text-[15px] px-3.5 py-2 rounded-lg bg-[rgba(74,222,128,.13)] text-[#6EE7B7]">{p}</span>)}
          </div>
        </>
      )}

      {tab === 'jodi' && (
        <>
          <p className="text-[12.5px] text-[#6B7280] mb-3">Jodi — 100 numbers (open digit + close digit)</p>
          <div className="flex flex-wrap gap-1.5">
            {JODIS.map(j => <span key={j} className="font-mono font-bold text-[12.5px] px-2.5 py-1.5 rounded-md bg-[rgba(139,92,246,.14)] text-[#C4B5FD]">{j}</span>)}
          </div>
        </>
      )}

      {tab === 'single' && (
        <>
          <p className="text-[12.5px] text-[#6B7280] mb-3">Single Ank — 10 digits</p>
          <div className="flex flex-wrap gap-2">
            {Array.from({ length: 10 }, (_, i) => (
              <span key={i} className="font-mono font-bold text-[17px] px-4.5 py-3 rounded-lg bg-[rgba(74,222,128,.13)] text-[#6EE7B7]" style={{ padding: '12px 18px' }}>{i}</span>
            ))}
          </div>
        </>
      )}

      {tab === 'sangam' && (
        <div className="grid md:grid-cols-2 gap-3">
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-4">
            <b className="text-[#111827]">Half Sangam — 2,200 combinations</b>
            <p className="text-[12.5px] text-[#6B7280] mt-2">Open digit + Close SP panna · format <span className="font-mono text-[#60A5FA]">7-370</span></p>
          </div>
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-4">
            <b className="text-[#111827]">Full Sangam — 48,400 combinations</b>
            <p className="text-[12.5px] text-[#6B7280] mt-2">Open SP panna + Close SP panna · format <span className="font-mono text-[#60A5FA]">123-456</span></p>
          </div>
        </div>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// MARKET CHARTS — every customer's app entries merged into ONE
// chart per market + date (digit-wise, jodi-wise, panna-wise).
// ══════════════════════════════════════════════════════════
export function AppChartsPage() {
  const [markets, setMarkets] = useState<MarketRow[]>([])
  const [market, setMarket] = useState('')
  const [date, setDate] = useState(istDate())
  const [chart, setChart] = useState<ChartData | null>(null)
  const [loading, setLoading] = useState(true)
  const [custOpen, setCustOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    apiFetch('/api/app-admin/bets?take=1').then((d: { markets: MarketRow[] }) => {
      setMarkets(d.markets)
      if (d.markets.length) setMarket(m => m || d.markets[0].code)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  const load = useCallback(() => {
    if (!market || !date) return
    setLoading(true)
    apiFetch(`/api/app-admin/charts?market=${market}&date=${date}`)
      .then((c: ChartData) => { setChart(c); setLoading(false) })
      .catch(() => setLoading(false))
  }, [market, date])
  useEffect(() => { load() }, [load])

  const ankRow = (arr: number[], label: string, hot: number) => (
    <div className="flex items-center gap-1.5 flex-wrap">
      <span className="text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280] w-[64px] flex-shrink-0">{label}</span>
      {arr.map((v, d) => (
        <div key={d} className={`flex-1 min-w-[52px] rounded-xl border px-1 py-1.5 text-center ${v > 0 ? (d === hot ? 'border-[rgba(248,113,113,.5)] bg-[rgba(248,113,113,.1)]' : 'border-[rgba(37,99,235,.4)] bg-[rgba(37,99,235,.09)]') : 'border-[#F3F4F6] bg-[rgba(148,163,184,.04)]'}`}>
          <div className={`text-[15px] font-extrabold font-mono ${v > 0 ? (d === hot ? 'text-[#F87171]' : 'text-[#60A5FA]') : 'text-[#6B7280]'}`}>{d}</div>
          <div className={`text-[11px] font-bold font-mono ${v > 0 ? (d === hot ? 'text-[#F87171]' : 'text-[#374151]') : 'text-[#6B7280]'}`}>{v ? inr(v) : '—'}</div>
        </div>
      ))}
    </div>
  )

  const isStar = chart?.isStarline
  const ankArr = isStar ? (chart?.starAnk || []) : (chart?.openAnk || [])
  const ankClose = chart?.closeAnk || []
  const combined = ankArr.map((v, i) => v + (ankClose[i] || 0))
  const hotDigit = combined.reduce((mi, v, i) => (v > combined[mi] ? i : mi), 0)
  const maxJodi = Math.max(...(chart?.jodi || [1]), 1)

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <H1 icon={<BarChart3 size={22} className="text-[#60A5FA]" />} title="Market Charts"
        sub="App vyapar flows straight into market charts — all customers' entries for a market merge into its chart, prepared digit-wise / jodi-wise / panna-wise with amount totals" />

      <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl px-4 py-3 mb-4 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <select value={market} onChange={e => setMarket(e.target.value)}
            className="text-[12.5px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-1.5 text-[#374151] outline-none focus:border-[#60A5FA]">
            {markets.map(m => <option key={m.code} value={m.code}>{m.name}</option>)}
            {Array.from({ length: 24 }, (_, h) => <option key={'st' + h} value={'st' + h}>{starlineName(h)}</option>)}
          </select>
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="text-[12.5px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-1.5 text-[#374151] outline-none focus:border-[#60A5FA]" />
          <button onClick={() => { setDate(istDate()) }} className="text-[11.5px] font-semibold px-2.5 py-1.5 rounded-lg bg-[rgba(37,99,235,.15)] text-[#60A5FA]">Today</button>
          <button onClick={() => setDate(istShift(1))} className="text-[11.5px] font-semibold px-2.5 py-1.5 rounded-lg bg-[rgba(148,163,184,.15)] text-[#6B7280]">Yesterday</button>
        </div>
        {chart ? (
          <div className="flex items-center gap-2 flex-wrap text-[11.5px] font-semibold">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[rgba(37,99,235,.13)] text-[#60A5FA]"><Users size={12} /> {chart.counts.customers} customers</span>
            <span className="px-2.5 py-1 rounded-full bg-[rgba(148,163,184,.13)] text-[#9CA3AF]">{chart.counts.bets} bets</span>
            <span className="px-2.5 py-1 rounded-full bg-[rgba(250,204,21,.13)] text-[#FACC15]">staked {inr(chart.counts.staked)}</span>
            <button
              onClick={async () => {
                if (!chart.whatsapp) return
                try { await navigator.clipboard.writeText(chart.whatsapp) } catch {
                  const ta = document.createElement('textarea'); ta.value = chart.whatsapp; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta)
                }
                setCopied(true); setTimeout(() => setCopied(false), 2000)
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-br from-[#16A34A] to-[#22C55E] text-white text-[11.5px] font-bold hover:brightness-110"
              title="Copy the full vyapar chart as WhatsApp-ready text for the upper authority">
              <Share2 size={12} /> {copied ? 'Copied ✓' : 'Copy for WhatsApp'}
            </button>
          </div>
        ) : null}
      </div>

      {loading && !chart ? (
        <div className="flex items-center justify-center h-40"><div className="w-8 h-8 border-2 border-[#3B82F6] border-t-transparent rounded-full animate-spin" /></div>
      ) : chart ? (
        chart.counts.bets === 0 ? (
          <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-10 text-center">
            <Smartphone size={30} className="mx-auto text-[#6B7280] mb-3" />
            <p className="text-[13.5px] text-[#374151] font-semibold">No app entries for {chart.market.name} on {date}</p>
            <p className="text-[12px] text-[#6B7280] mt-1">As soon as customers place their vyapar in this market from the app, its chart is prepared here automatically.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {/* Ank rows */}
            <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-4 flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-[14px] font-bold text-[#111827]">Ank Chart — digit-wise totals</h3>
                <span className="text-[11px] text-[#9CA3AF]">single + panna amounts rolled into their ank</span>
              </div>
              {isStar
                ? ankRow(chart.starAnk, 'Starline', hotDigit)
                : ankRow(chart.openAnk, 'Open', hotDigit)}
              {!isStar && ankRow(chart.closeAnk, 'Close', hotDigit)}
            </div>

            {/* Jodi grid */}
            {!isStar && (
              <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-4">
                <h3 className="text-[14px] font-bold text-[#111827] mb-3">Jodi Chart — 00 → 99</h3>
                <div className="grid gap-1" style={{ gridTemplateColumns: 'repeat(10, minmax(0, 1fr))' }}>
                  {chart.jodi.map((v, n) => (
                    <div key={n} className={`rounded-lg border text-center py-1.5 ${v > 0 ? 'border-[rgba(139,92,246,.45)] bg-[rgba(139,92,246,.12)]' : 'border-[#F3F4F6] bg-[rgba(148,163,184,.03)]'}`}>
                      <div className={`text-[12px] font-extrabold font-mono ${v > 0 ? 'text-[#C4B5FD]' : 'text-[#6B7280]'}`}>{String(n).padStart(2, '0')}</div>
                      <div className={`text-[10.5px] font-bold font-mono ${v > 0 ? 'text-[#374151]' : 'text-[#6B7280]'}`}>{v ? inr(v) : '—'}</div>
                      {v > 0 && <div className="mx-1 mt-1 h-[3px] rounded-full bg-gradient-to-r from-[#2563EB] to-[#60A5FA]" style={{ opacity: 0.35 + 0.65 * (v / maxJodi) }} />}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Pannas + odd/even */}
            {(chart.pannas.length > 0 || isStar) && (
              <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
                <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
                  <h3 className="text-[14px] font-bold text-[#111827]">Panna Entries ({chart.pannas.length})</h3>
                  {isStar ? (
                    <span className="text-[11.5px] font-semibold text-[#9CA3AF]">
                      Odd <b className="text-[#FACC15]">{inr(chart.oddEven.odd)}</b> · Even <b className="text-[#FACC15]">{inr(chart.oddEven.even)}</b>
                    </span>
                  ) : null}
                </div>
                <table className="w-full text-[12.5px]">
                  <thead>
                    <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#6B7280] bg-[rgba(148,163,184,.07)]">
                      <th className="py-2 px-3.5 font-semibold">Panna</th>
                      <th className="py-2 px-3.5 font-semibold">Type</th>
                      <th className="py-2 px-3.5 font-semibold">Session</th>
                      <th className="py-2 px-3.5 font-semibold">Bids</th>
                      <th className="py-2 px-3.5 font-semibold">Total Amount</th>
                      <th className="py-2 px-3.5 font-semibold">Ank</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chart.pannas.map(p => (
                      <tr key={p.type + p.num + p.slot} className="border-t border-[#F3F4F6] hover:bg-[rgba(148,163,184,.05)]">
                        <td className="py-2 px-3.5 font-mono font-bold text-[#374151]">{p.num}</td>
                        <td className="py-2 px-3.5 uppercase font-bold text-[10.5px] text-[#FB923C]">{p.type}</td>
                        <td className="py-2 px-3.5 text-[#6B7280] capitalize">{p.slot}</td>
                        <td className="py-2 px-3.5 text-[#374151]">{p.bets}</td>
                        <td className="py-2 px-3.5 font-bold text-[#4ADE80]">{inr(p.amount)}</td>
                        <td className="py-2 px-3.5 font-mono text-[#60A5FA] font-bold">{deriveDigit(p.num)}</td>
                      </tr>
                    ))}
                    {!chart.pannas.length && <tr><td colSpan={6} className="py-5 text-center text-[#6B7280]">No panna entries — only single/jodi bets in this chart</td></tr>}
                  </tbody>
                </table>
              </div>
            )}

            {/* Customers merged into this chart */}
            <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
                <h3 className="text-[14px] font-bold text-[#111827]">Customers in this chart ({chart.counts.customers})</h3>
                <button onClick={() => setCustOpen(o => !o)} className="text-[11.5px] font-semibold px-2.5 py-1.5 rounded-lg bg-[#FFFFFF] border border-[#E5E7EB] text-[#374151] hover:border-[#3B82F6] hover:text-[#60A5FA] transition">
                  {custOpen ? 'Hide' : 'Show'} list
                </button>
              </div>
              {custOpen ? (
                <table className="w-full text-[12.5px]">
                  <thead>
                    <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#6B7280] bg-[rgba(148,163,184,.07)]">
                      <th className="py-2 px-3.5 font-semibold">#</th>
                      <th className="py-2 px-3.5 font-semibold">Member</th>
                      <th className="py-2 px-3.5 font-semibold">Mobile</th>
                      <th className="py-2 px-3.5 font-semibold">Bids</th>
                      <th className="py-2 px-3.5 font-semibold">Stake</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chart.customers.map((c, i) => (
                      <tr key={c.id} className="border-t border-[#F3F4F6]">
                        <td className="py-2 px-3.5 text-[#9CA3AF]">{i + 1}</td>
                        <td className="py-2 px-3.5 font-semibold text-[#374151]">{c.name}</td>
                        <td className="py-2 px-3.5 font-mono text-[11px] text-[#6B7280]">{c.mobile}</td>
                        <td className="py-2 px-3.5 text-[#374151]">{c.bets}</td>
                        <td className="py-2 px-3.5 font-bold text-[#FACC15]">{inr(c.staked)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="px-4 py-3 text-[11.5px] text-[#6B7280]">
                  Every customer&apos;s entries for {chart.market.name} on {date} are merged into this single market chart — total stake {inr(chart.counts.staked)} · potential payout {inr(chart.counts.potential)}.
                </p>
              )}
            </div>
          </div>
        )
      ) : (
        <p className="text-[12px] text-[#6B7280]">Select a market and date to build its chart.</p>
      )}
    </div>
  )
}
