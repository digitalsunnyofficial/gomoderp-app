'use client'

// ──────────────────────────────────────────────────────────
// MARKET MANAGEMENT PAGES
//   AppMarketsSection — live app markets: built-in markets,
//     timings entered at creation, AM/PM display, bet closing
//     minutes, live open/close status driven by the cron.
//   MarketResultsPage — declare / update a single market's
//     result; stores + shows the declaration time; auto-derives
//     digits and jodi (e.g. 124-71-470: 1+2+4=7 open digit,
//     4+7+0=11→1 close digit, jodi 71).
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, Modal } from '@/components/shared-ui'
import { fmt12, WEEKDAY_KEYS, WEEKDAY_SHORT, marketDisplayName, type DaySchedule } from '@/lib/matka/app-engine'
import {
  Plus, Check, AlertTriangle, Clock, RefreshCw, Trophy, Pencil, Zap, History, Timer, CalendarDays, Power, Trash2,
} from 'lucide-react'

const dtIST = (v: string | null | undefined) => v
  ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true })
  : '—'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('success') || message.includes('updated') || message.includes('added') || message.includes('declared') || message.includes('Saved')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

interface AppMarketRow {
  id: string; code: string; name: string; category: string
  phase?: string; session?: string
  openTime: string; closeTime: string; betClosingMinutes: number
  isOn: boolean; weeklySchedule: string
  marketStatus: string; statusChangedAt: string | null
  isActive: boolean; sortOrder: number
  liveStatus: string
  todayOpen: string; todayClose: string
  weekly: Record<string, DaySchedule>
}

// Week editor state: 7 rows of {on, open, close}
type WeekDraft = Record<string, { on: boolean; open: string; close: string }>

function weeklyToDraft(weekly: Record<string, DaySchedule>, defOpen: string, defClose: string): WeekDraft {
  const d: WeekDraft = {}
  for (const k of WEEKDAY_KEYS) {
    const row = weekly[k]
    d[k] = row && typeof row.on === 'boolean'
      ? { on: row.on, open: row.open || defOpen, close: row.close || defClose }
      : { on: true, open: defOpen, close: defClose }
  }
  return d
}

// ── Weekly editor modal (per-day enable + times) ──
function WeeklyModal({ row, onClose, onSaved }: { row: AppMarketRow; onClose: () => void; onSaved: () => void }) {
  const [draft, setDraft] = useState<WeekDraft>(() => weeklyToDraft(row.weekly, row.openTime, row.closeTime))
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')

  const save = async () => {
    setSaving(true); setErr('')
    try {
      await apiFetch('/api/app-admin/markets', {
        method: 'PATCH',
        body: JSON.stringify({ id: row.id, weeklySchedule: draft }),
      })
      onSaved()
    } catch (e) { setErr(e instanceof Error ? e.message : 'Failed to save schedule') } finally { setSaving(false) }
  }

  const onDays = WEEKDAY_KEYS.filter(k => draft[k].on).length
  return (
    <Modal open title={`Weekly Timings — ${row.name}`} onClose={onClose}>
      <p className="text-[11.5px] text-[#6B7280] mb-3">
        Set the open → close declaration window per day. A day switched off keeps the market closed for that weekday —
        the cron and the customer app both follow this schedule instantly.
      </p>
      <div className="grid gap-2">
        {WEEKDAY_KEYS.map(k => (
          <div key={k} className={`flex items-center gap-2.5 border rounded-xl px-3 py-2 ${draft[k].on ? 'border-[#BFDBFE] bg-[#F8FAFF]' : 'border-[#E5E7EB] bg-[#FAFAFA]'}`}>
            <button
              onClick={() => setDraft(d => ({ ...d, [k]: { ...d[k], on: !d[k].on } }))}
              className={`w-12 text-[11px] font-bold rounded-lg py-1.5 ${draft[k].on ? 'bg-[#2563EB] text-white' : 'bg-[#E5E7EB] text-[#6B7280]'}`}
            >{WEEKDAY_SHORT[k]}</button>
            <input type="time" className="flex-1 min-w-0 border border-[#E5E7EB] rounded-lg px-2 py-1.5 text-[12px]" disabled={!draft[k].on}
              value={draft[k].open} onChange={e => setDraft(d => ({ ...d, [k]: { ...d[k], open: e.target.value } }))} />
            <span className="text-[#9CA3AF]">→</span>
            <input type="time" className="flex-1 min-w-0 border border-[#E5E7EB] rounded-lg px-2 py-1.5 text-[12px]" disabled={!draft[k].on}
              value={draft[k].close} onChange={e => setDraft(d => ({ ...d, [k]: { ...d[k], close: e.target.value } }))} />
          </div>
        ))}
      </div>
      {err ? <p className="text-[11.5px] text-[#DC2626] mt-2">{err}</p> : null}
      <div className="flex justify-end gap-2 mt-4">
        <OutlineButton onClick={onClose}>Cancel</OutlineButton>
        <GoldButton onClick={save} disabled={saving}><Check size={14} />{saving ? 'Saving…' : `Save Schedule (${onDays} day${onDays === 1 ? '' : 's'} on)`}</GoldButton>
      </div>
    </Modal>
  )
}

// ──────────────────────────────────────────────────────────
// LIVE MARKETS SECTION (embedded in Markets page)
// ──────────────────────────────────────────────────────────
export function AppMarketsSection() {
  const currentUser = useAppStore(s => s.currentUser)
  const canEdit = currentUser?.role === 'super'
  const [markets, setMarkets] = useState<AppMarketRow[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [editRow, setEditRow] = useState<AppMarketRow | null>(null)
  const [weekRow, setWeekRow] = useState<AppMarketRow | null>(null)
  const [form, setForm] = useState({ name: '', phase: 'day', session: 'open', openTime: '10:00', closeTime: '18:00', betClosingMinutes: 5, category: 'regular' })

  // Market structure preview: Name + Phase + Session → "Main Bazaar Day Open"
  const phaseLbl = form.phase === 'night' ? 'Night' : form.phase === 'none' ? '' : 'Day'
  const sessLbl = form.session === 'both' ? 'Open + Close' : form.session === 'close' ? 'Close' : 'Open'
  const identity = [form.name.trim() || 'Market Name', phaseLbl, form.session === 'both' ? '' : sessLbl].filter(Boolean).join(' ')

  const load = useCallback(() => {
    apiFetch('/api/app-admin/markets')
      .then(d => setMarkets((d.markets as AppMarketRow[]) || []))
      .catch(e => setMessage(e instanceof Error ? e.message : 'Failed to load markets'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    load()
    // live status refresh — mirrors the cron tick
    const t = setInterval(load, 30000)
    return () => clearInterval(t)
  }, [load])

  const addMarket = async () => {
    if (!form.name.trim()) { setMessage('Market name is required'); return }
    try {
      await apiFetch('/api/app-admin/markets', { method: 'POST', body: JSON.stringify(form) })
      setMessage('Market added successfully — timings saved')
      setShowAdd(false)
      setForm({ name: '', phase: 'day', session: 'open', openTime: '10:00', closeTime: '18:00', betClosingMinutes: 5, category: 'regular' })
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const saveEdit = async () => {
    if (!editRow) return
    try {
      await apiFetch('/api/app-admin/markets', {
        method: 'PATCH',
        body: JSON.stringify({
          id: editRow.id, openTime: editRow.openTime, closeTime: editRow.closeTime,
          betClosingMinutes: editRow.betClosingMinutes, name: editRow.name,
          phase: editRow.phase || 'day', session: editRow.session || 'both',
        }),
      })
      setMessage('Market updated successfully')
      setEditRow(null)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const toggleActive = async (m: AppMarketRow) => {
    try {
      await apiFetch('/api/app-admin/markets', { method: 'PATCH', body: JSON.stringify({ id: m.id, isActive: !m.isActive }) })
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  // Master ON/OFF — stops/starts the market instantly across app + cron
  const toggleOn = async (m: AppMarketRow) => {
    try {
      await apiFetch('/api/app-admin/markets', { method: 'PATCH', body: JSON.stringify({ id: m.id, isOn: !m.isOn }) })
      setMessage(m.isOn ? `${m.name} switched OFF — betting stopped in the app` : `${m.name} switched ON — schedule active again`)
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const deleteMarket = async (m: AppMarketRow) => {
    if (!window.confirm(`Delete market "${marketDisplayName(m)}" (${m.code})? Its game allocations are removed; historical bids and results are kept.`)) return
    try {
      await apiFetch('/api/app-admin/markets?id=' + m.id, { method: 'DELETE' })
      setMessage('Market deleted successfully')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const statusChip = (s: string) => {
    if (s === 'open') return 'bg-[rgba(5,150,105,0.12)] text-[#059669] border-[rgba(5,150,105,0.35)]'
    if (s === 'scheduled') return 'bg-[rgba(2,132,199,0.1)] text-[#0369A1] border-[rgba(2,132,199,0.3)]'
    if (s === 'off') return 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'
    return 'bg-[rgba(100,116,139,0.1)] text-[#64748B] border-[rgba(100,116,139,0.3)]'
  }

  return (
    <SectionCard
      title="Live Markets — Customer App"
      headerRight={
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-[#9CA3AF] hidden md:inline">auto open/close via cron · bet closing minutes per market</span>
          <button onClick={load} className="p-1.5 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]" title="Refresh"><RefreshCw size={14} /></button>
          {canEdit ? <GoldButton onClick={() => setShowAdd(true)}><Plus size={14} /> Add Market</GoldButton> : null}
        </div>
      }
    >
      <p className="text-[12px] text-[#6B7280] mb-4">
        Markets are the single source for the ERP and the Game app — every market is built by the formula
        <b> Market Name + Market Phase + Market Session</b> (e.g. <b>Sridevi Day Open</b>). No built-in markets: create exactly
        what you run. The cron opens and closes each market automatically, every live market stops accepting orders
        <b> bet closing minutes</b> before its declared time, and the <b> weekly schedule</b> controls each weekday's window —
        including weekly-offs. Starlines are managed separately in the <b>Starlines</b> section.
      </p>
      <Msg message={message} />
      {loading ? <p className="text-[12px] text-[#9CA3AF]">Loading markets…</p> : null}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {markets.map(m => {
          const mPhase = m.phase === 'night' ? 'Night' : m.phase === 'none' ? '' : 'Day'
          const mSess = m.session === 'both' ? 'Open + Close' : m.session === 'close' ? 'Close' : 'Open'
          const identity = marketDisplayName(m)
          return (
          <div key={m.id} className={`border rounded-xl p-3.5 bg-white ${m.isActive ? 'border-[#E5E7EB]' : 'border-dashed border-[#D1D5DB] opacity-70'}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <b className="text-[14px] text-[#111827]">{identity}</b>
                  <span className="text-[10px] font-mono text-[#6B7280] bg-[#F3F4F6] rounded px-1.5 py-0.5">{m.code}</span>
                  <button
                    onClick={() => canEdit && toggleOn(m)} disabled={!canEdit}
                    title={m.isOn ? 'Master switch — click to turn the market OFF' : 'Master switch — click to turn the market ON'}
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded inline-flex items-center gap-1 ${m.isOn ? 'bg-[#ECFDF5] text-[#059669]' : 'bg-[#FEE2E2] text-[#B91C1C]'}`}
                  ><Power size={10} />{m.isOn ? 'ON' : 'OFF'}</button>
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                  {mPhase ? <span className="text-[9.5px] font-bold uppercase tracking-wide bg-[#EFF6FF] text-[#1D4ED8] rounded px-1.5 py-0.5">{mPhase}</span> : null}
                  <span className="text-[9.5px] font-bold uppercase tracking-wide bg-[#F5F3FF] text-[#6D28D9] rounded px-1.5 py-0.5">{mSess}</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1.5 text-[11.5px] text-[#374151]">
                  <Clock size={12} className="text-[#2563EB]" />
                  <span className="font-semibold">{fmt12(m.todayOpen)}</span>
                  <span className="text-[#9CA3AF]">→</span>
                  <span className="font-semibold">{fmt12(m.todayClose)}</span>
                  <span className="text-[10px] text-[#6B7280]">(today)</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1 text-[11px] text-[#6B7280]">
                  <Timer size={12} className="text-[#D97706]" />
                  Bet closes <b className="text-[#B45309]">{m.betClosingMinutes} min</b> before each time
                </div>
              </div>
              <span className={`text-[10px] font-bold px-2 py-1 rounded-full border uppercase tracking-wide ${statusChip(m.liveStatus)}`}>
                {m.liveStatus === 'open' ? '● Open' : m.liveStatus === 'scheduled' ? 'Scheduled' : m.liveStatus === 'off' ? 'Off' : 'Closed'}
              </span>
            </div>
            <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-[#F3F4F6]">
              <span className="text-[10.5px] text-[#9CA3AF]">
                {m.statusChangedAt ? `state changed ${dtIST(m.statusChangedAt)}` : 'state by schedule'}
                {!m.isActive ? ' · disabled' : !m.isOn ? ' · master OFF' : ''}
              </span>
              {canEdit ? (
                <div className="flex items-center gap-1.5">
                  <button onClick={() => setEditRow({ ...m })} className="text-[11px] font-semibold text-[#2563EB] px-2 py-1 rounded-md hover:bg-[#EFF6FF] flex items-center gap-1"><Pencil size={11} />Edit</button>
                  <button onClick={() => setWeekRow({ ...m })} className="text-[11px] font-semibold text-[#7C3AED] px-2 py-1 rounded-md hover:bg-[#F5F3FF] flex items-center gap-1"><CalendarDays size={11} />Weekly</button>
                  <button onClick={() => toggleActive(m)} className={`text-[11px] font-semibold px-2 py-1 rounded-md ${m.isActive ? 'text-[#DC2626] hover:bg-[#FEF2F2]' : 'text-[#059669] hover:bg-[#ECFDF5]'}`}>
                    {m.isActive ? 'Disable' : 'Enable'}
                  </button>
                  <button onClick={() => deleteMarket(m)} className="text-[11px] font-semibold text-[#DC2626] px-2 py-1 rounded-md hover:bg-[#FEF2F2] flex items-center gap-1"><Trash2 size={11} />Delete</button>
                </div>
              ) : null}
            </div>
          </div>
          )
        })}
      </div>
      {!loading && !markets.length ? <p className="text-[12px] text-[#9CA3AF]">No markets yet — add the first one.</p> : null}

      {/* Weekly schedule editor */}
      {weekRow ? (
        <WeeklyModal
          row={weekRow}
          onClose={() => setWeekRow(null)}
          onSaved={() => { setWeekRow(null); setMessage('Weekly schedule saved successfully'); load() }}
        />
      ) : null}

      {/* Add market modal — Name + Phase + Session + timings captured at creation */}
      {showAdd ? (
        <Modal open title="Add Market" onClose={() => setShowAdd(false)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Market Name"><FormInput placeholder="e.g. Main Bazaar" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></FormField>
            <FormField label="Market Phase">
              <FormSelect value={form.phase} onChange={e => setForm(f => ({ ...f, phase: e.target.value }))}>
                <option value="day">Day</option>
                <option value="night">Night</option>
                <option value="none">None (classic — e.g. Kalyan)</option>
              </FormSelect>
            </FormField>
            <FormField label="Market Session">
              <FormSelect value={form.session} onChange={e => setForm(f => ({ ...f, session: e.target.value }))}>
                <option value="open">Open</option>
                <option value="close">Close</option>
                <option value="both">Both (Open + Close)</option>
              </FormSelect>
            </FormField>
            <FormField label="Bet Closing Minutes"><FormInput type="number" min={0} max={120} value={form.betClosingMinutes} onChange={e => setForm(f => ({ ...f, betClosingMinutes: Number(e.target.value) }))} /></FormField>
            <FormField label="Open Time (declaration)"><FormInput type="time" value={form.openTime} onChange={e => setForm(f => ({ ...f, openTime: e.target.value }))} /></FormField>
            <FormField label="Close Time (declaration)"><FormInput type="time" value={form.closeTime} onChange={e => setForm(f => ({ ...f, closeTime: e.target.value }))} /></FormField>
          </div>
          <div className="mt-4 bg-[#F8FAFC] border border-[#E5E7EB] rounded-lg px-3 py-2.5 flex items-center gap-2">
            <span className="text-[11px] text-[#6B7280] font-semibold">Market identity:</span>
            <span className="text-[13px] font-bold text-[#111827]">{identity}</span>
          </div>
          <p className="text-[11px] text-[#6B7280] mt-2">Name + Phase + Session build the market (e.g. <b>Main Bazaar Day Open</b>). Orders stop {form.betClosingMinutes} min before Open and Close times. The cron flips the market Scheduled → Open → Closed automatically.</p>
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setShowAdd(false)}>Cancel</OutlineButton>
            <GoldButton onClick={addMarket}><Plus size={14} /> Create Market</GoldButton>
          </div>
        </Modal>
      ) : null}

      {/* Edit market modal — identity + timings */}
      {editRow ? (
        <Modal open title={`Edit Market — ${editRow.name}`} onClose={() => setEditRow(null)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Market Name"><FormInput value={editRow.name} onChange={e => setEditRow(r => r ? { ...r, name: e.target.value } : r)} /></FormField>
            <FormField label="Market Phase">
              <FormSelect value={editRow.phase || 'day'} onChange={e => setEditRow(r => r ? { ...r, phase: e.target.value } : r)}>
                <option value="day">Day</option>
                <option value="night">Night</option>
                <option value="none">None (classic — e.g. Kalyan)</option>
              </FormSelect>
            </FormField>
            <FormField label="Market Session">
              <FormSelect value={editRow.session || 'both'} onChange={e => setEditRow(r => r ? { ...r, session: e.target.value } : r)}>
                <option value="open">Open</option>
                <option value="close">Close</option>
                <option value="both">Both (Open + Close)</option>
              </FormSelect>
            </FormField>
            <FormField label="Bet Closing Minutes"><FormInput type="number" min={0} max={120} value={editRow.betClosingMinutes} onChange={e => setEditRow(r => r ? { ...r, betClosingMinutes: Number(e.target.value) } : r)} /></FormField>
            <FormField label="Open Time"><FormInput type="time" value={editRow.openTime} onChange={e => setEditRow(r => r ? { ...r, openTime: e.target.value } : r)} /></FormField>
            <FormField label="Close Time"><FormInput type="time" value={editRow.closeTime} onChange={e => setEditRow(r => r ? { ...r, closeTime: e.target.value } : r)} /></FormField>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setEditRow(null)}>Cancel</OutlineButton>
            <GoldButton onClick={saveEdit}><Check size={14} /> Save Market</GoldButton>
          </div>
        </Modal>
      ) : null}
    </SectionCard>
  )
}

// ──────────────────────────────────────────────────────────
// MARKET RESULTS PAGE — declare / update, declaration time
// ──────────────────────────────────────────────────────────
interface AppResultRow {
  id: string; marketCode: string; marketName: string; resultDate: string
  openPanna: string | null; closePanna: string | null
  openDigit: string | null; closeDigit: string | null; jodi: string | null
  declaredBy: string; declaredAt: string; updatedAt: string
  version?: number
}

export function MarketResultsPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const canEdit = currentUser?.role === 'super'
  // Separate worlds: MARKETS (Name+Phase+Session) and STARLINES (hourly games)
  // never share one section — each has its own declare UI and its own table.
  const [world, setWorld] = useState<'markets' | 'starlines'>('markets')
  const [markets, setMarkets] = useState<Array<{ code: string; name: string; session?: string; phase?: string }>>([])
  const [starlines, setStarlines] = useState<Array<{ id: string; code: string; name: string; hour: number; minute: number; isOn: boolean; isActive: boolean }>>([])
  const [results, setResults] = useState<AppResultRow[]>([])
  const [market, setMarket] = useState('')
  const [starMk, setStarMk] = useState('')
  const [message, setMessage] = useState('')
  const [declareMk, setDeclareMk] = useState<string | null>(null)
  const [form, setForm] = useState({ resultDate: new Date().toISOString().slice(0, 10), openPanna: '', closePanna: '' })
  const [starForm, setStarForm] = useState({ resultDate: new Date().toISOString().slice(0, 10), openPanna: '' })
  const [busy, setBusy] = useState(false)

  const load = useCallback((mk: string) => {
    apiFetch('/api/app-admin/results' + (mk ? `?market=${mk}` : ''))
      .then(d => {
        setResults((d.results as AppResultRow[]) || [])
        setMarkets(((d.markets as Array<{ code: string; name: string; session?: string; phase?: string }>) || [])
          .filter(m => !String(m.code).startsWith('st')))
      })
      .catch(e => setMessage(e instanceof Error ? e.message : 'Failed to load results'))
  }, [])

  const loadStarlines = useCallback(() => {
    apiFetch('/api/app-admin/starlines')
      .then((d: { starlines: Array<{ id: string; code: string; name: string; hour: number; minute: number; isOn: boolean; isActive: boolean }> }) => {
        setStarlines(d.starlines || [])
        setStarMk(prev => prev || (d.starlines || [])[0]?.code || '')
      })
      .catch(() => {})
  }, [])

  useEffect(() => { load(market); loadStarlines() }, [market, load, loadStarlines])

  const mkLabel = (m: { code: string; name: string; session?: string; phase?: string }) => {
    const phase = m.phase === 'night' ? ' Night' : m.phase === 'day' ? ' Day' : ''
    const sess = m.session === 'both' || !m.session ? '' : m.session === 'open' ? ' Open' : ' Close'
    return m.name + phase + sess
  }

  const declare = async () => {
    if (!declareMk) return
    if (!form.openPanna && !form.closePanna) { setMessage('Enter at least the Open panna (or Close panna)'); return }
    setBusy(true)
    try {
      const d = await apiFetch('/api/app-admin/results', {
        method: 'POST',
        body: JSON.stringify({ marketCode: declareMk, ...form, openPanna: form.openPanna || null, closePanna: form.closePanna || null }),
      })
      const s = (d as { settlement?: { won: number; lost: number; considered: number } }).settlement
      setMessage(`Result declared successfully — ${s ? `${s.won} won · ${s.lost} lost of ${s.considered} pending bids · ` : ''}customers notified`)
      setDeclareMk(null)
      setForm({ resultDate: new Date().toISOString().slice(0, 10), openPanna: '', closePanna: '' })
      load(market)
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') } finally { setBusy(false) }
  }

  const declareStar = async () => {
    if (!starMk) return
    if (!starForm.openPanna) { setMessage('Enter the declared panna'); return }
    setBusy(true)
    try {
      await apiFetch('/api/app-admin/results', {
        method: 'POST',
        body: JSON.stringify({ marketCode: starMk, resultDate: starForm.resultDate, openPanna: starForm.openPanna }),
      })
      setMessage('Starline result declared successfully — customers notified')
      setStarForm({ resultDate: new Date().toISOString().slice(0, 10), openPanna: '' })
      load('')
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') } finally { setBusy(false) }
  }

  // jodi preview per the operator's rule: open sum digit → jodi → close sum digit
  const digitOf = (p: string) => String(p.split('').reduce((a, c) => a + Number(c), 0) % 10)
  const previewJodi = form.openPanna && form.closePanna ? digitOf(form.openPanna) + digitOf(form.closePanna) : ''
  const starResults = results.filter(r => String(r.marketCode).startsWith('st'))
  const marketResults = results.filter(r => !String(r.marketCode).startsWith('st'))
  const starName = (code: string) => starlines.find(s => s.code === code)?.name || code
  const today = new Date().toISOString().slice(0, 10)

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Results</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Markets and Starlines are declared in their own sections — declaration time is stored, digits and jodi auto-derive, declaring locks betting.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setWorld('markets')} className={`text-[12px] font-bold px-4 py-2 rounded-lg border flex items-center gap-1.5 ${world === 'markets' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}><Trophy size={14} /> Market Results</button>
          <button onClick={() => setWorld('starlines')} className={`text-[12px] font-bold px-4 py-2 rounded-lg border flex items-center gap-1.5 ${world === 'starlines' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}><Timer size={14} /> Starline Results</button>
        </div>
      </div>
      <Msg message={message} />

      {world === 'markets' ? (
        <>
          {canEdit && markets.length ? (
            <div className="mb-4 flex items-center gap-2">
              <FormSelect value={declareMk || ''} onChange={e => setDeclareMk(e.target.value || null)} className="w-[240px]">
                <option value="">— Declare market result —</option>
                {markets.map(m => <option key={m.code} value={m.code}>{mkLabel(m)}</option>)}
              </FormSelect>
            </div>
          ) : null}

          {declareMk ? (
            <SectionCard title={`Declare / Update — ${mkLabel(markets.find(m => m.code === declareMk) || { code: declareMk, name: declareMk })}`}>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <FormField label="Result Date"><FormInput type="date" value={form.resultDate} onChange={e => setForm(f => ({ ...f, resultDate: e.target.value }))} /></FormField>
                <FormField label="Open Panna (3 digits)"><FormInput maxLength={3} placeholder="e.g. 124" value={form.openPanna} onChange={e => setForm(f => ({ ...f, openPanna: e.target.value.replace(/\D/g, '') }))} /></FormField>
                <FormField label="Close Panna (3 digits)"><FormInput maxLength={3} placeholder="e.g. 470" value={form.closePanna} onChange={e => setForm(f => ({ ...f, closePanna: e.target.value.replace(/\D/g, '') }))} /></FormField>
                <div className="flex gap-2">
                  <GoldButton onClick={declare} disabled={busy}><Trophy size={14} /> {busy ? 'Declaring…' : 'Declare & Settle'}</GoldButton>
                  <OutlineButton onClick={() => setDeclareMk(null)}>Cancel</OutlineButton>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-3 text-[12px] text-[#374151] bg-[#F8FAFC] border border-[#E5E7EB] rounded-lg px-3 py-2.5">
                <span className="font-semibold">Auto-derivation:</span>
                {form.openPanna ? <span className="font-mono">{form.openPanna} → open digit <b className="text-[#2563EB]">{digitOf(form.openPanna)}</b></span> : <span className="text-[#9CA3AF]">open panna pending</span>}
                <span className="text-[#D1D5DB]">|</span>
                {form.closePanna ? <span className="font-mono">{form.closePanna} → close digit <b className="text-[#2563EB]">{digitOf(form.closePanna)}</b></span> : <span className="text-[#9CA3AF]">close panna pending</span>}
                <span className="text-[#D1D5DB]">|</span>
                {previewJodi
                  ? <span className="font-mono bg-[#EFF6FF] text-[#1D4ED8] rounded px-2 py-0.5 font-bold">Jodi {previewJodi} <span className="font-normal text-[10px]">({form.openPanna}-{previewJodi}-{form.closePanna})</span></span>
                  : <span className="text-[#9CA3AF]">jodi appears when both pannas are in</span>}
              </div>
              <p className="text-[11px] text-[#6B7280] mt-2">Partial declares are allowed (open now, close later). Declaring a session locks THAT session's betting only — the other session keeps accepting. Winners are settled instantly; every approved customer is notified. Re-declaring with different pannas CORRECTS the result: version increments, previous payouts are reversed and recalculated atomically.</p>
            </SectionCard>
          ) : null}

          <SectionCard
            title="Declared Market Results"
            headerRight={
              <div className="flex items-center gap-2">
                <FormSelect value={market} onChange={e => setMarket(e.target.value)} className="w-[200px]">
                  <option value="">All markets</option>
                  {markets.map(m => <option key={m.code} value={m.code}>{mkLabel(m)}</option>)}
                </FormSelect>
                <button onClick={() => load(market)} className="p-1.5 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]"><RefreshCw size={14} /></button>
              </div>
            }
          >
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="text-left text-[#9CA3AF] border-b border-[#E5E7EB]">
                    <th className="py-2.5 pr-3 font-semibold">Market</th>
                    <th className="py-2.5 pr-3 font-semibold">Date</th>
                    <th className="py-2.5 pr-3 font-semibold">Open</th>
                    <th className="py-2.5 pr-3 font-semibold">Close</th>
                    <th className="py-2.5 pr-3 font-semibold">Jodi</th>
                    <th className="py-2.5 pr-3 font-semibold">Declared At</th>
                    <th className="py-2.5 pr-3 font-semibold">By</th>
                    <th className="py-2.5 font-semibold"></th>
                  </tr>
                </thead>
                <tbody>
                  {marketResults.map(r => {
                    // Session-qualified identity from the canonical market row;
                    // r.marketName (displayName since the fix) is the fallback.
                    const mrow = markets.find(m => m.code === r.marketCode)
                    const label = mrow ? mkLabel(mrow) : r.marketName
                    return (
                    <tr key={r.id} className="border-b border-[#F3F4F6] hover:bg-[#F8FAFC]">
                      <td className="py-2.5 pr-3 font-semibold text-[#111827]">{label}{(r.version || 1) > 1 ? <span className="ml-1.5 text-[10px] font-bold text-[#B45309] bg-[#FFF7ED] rounded px-1.5 py-0.5" title="Corrected result">v{r.version}</span> : null}</td>
                      <td className="py-2.5 pr-3 text-[#374151]">{r.resultDate}</td>
                      <td className="py-2.5 pr-3 font-mono font-bold text-[#2563EB]">{r.openPanna ? `${r.openPanna}-${r.openDigit}` : '—'}</td>
                      <td className="py-2.5 pr-3 font-mono font-bold text-[#2563EB]">{r.closePanna ? `${r.closePanna}-${r.closeDigit}` : '—'}</td>
                      <td className="py-2.5 pr-3"><span className="font-mono font-bold bg-[#EFF6FF] text-[#1D4ED8] rounded px-2 py-0.5">{r.jodi || '—'}</span></td>
                      <td className="py-2.5 pr-3 text-[#374151]" title="Declaration time (stored)"><span className="inline-flex items-center gap-1"><History size={11} className="text-[#9CA3AF]" />{dtIST(r.declaredAt)}</span></td>
                      <td className="py-2.5 pr-3 text-[#6B7280]">{r.declaredBy}</td>
                      <td className="py-2.5">
                        {canEdit ? (
                          <button
                            onClick={() => { setDeclareMk(r.marketCode); setForm({ resultDate: r.resultDate, openPanna: r.openPanna || '', closePanna: r.closePanna || '' }); setMessage('') }}
                            className="text-[11px] font-semibold text-[#2563EB] px-2 py-1 rounded-md hover:bg-[#EFF6FF] inline-flex items-center gap-1"
                          ><Pencil size={11} /> Update</button>
                        ) : null}
                      </td>
                    </tr>
                    )
                  })}
                </tbody>
              </table>
              {!marketResults.length ? <p className="text-[12px] text-[#9CA3AF] py-4">No market results declared yet — use “Declare market result” above.</p> : null}
            </div>
          </SectionCard>
        </>
      ) : (
        <>
          <SectionCard title="Declare Starline Result">
            {starlines.length ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                  <FormField label="Starline">
                    <FormSelect value={starMk} onChange={e => setStarMk(e.target.value)}>
                      <option value="">— Select starline —</option>
                      {starlines.map(s => <option key={s.code} value={s.code}>{s.name}</option>)}
                    </FormSelect>
                  </FormField>
                  <FormField label="Result Date"><FormInput type="date" value={starForm.resultDate} onChange={e => setStarForm(f => ({ ...f, resultDate: e.target.value }))} /></FormField>
                  <FormField label="Declared Panna (3 digits)"><FormInput maxLength={3} placeholder="e.g. 149" value={starForm.openPanna} onChange={e => setStarForm(f => ({ ...f, openPanna: e.target.value.replace(/\D/g, '') }))} /></FormField>
                  <div className="flex gap-2">
                    <GoldButton onClick={declareStar} disabled={busy || !starMk}><Trophy size={14} /> {busy ? 'Declaring…' : 'Declare & Settle'}</GoldButton>
                  </div>
                </div>
                <p className="text-[11px] text-[#6B7280] mt-3">A starline has a single panna per day — the digit derives automatically (149 → 5). Winners settle instantly. {starMk && !starlines.find(s => s.code === starMk)?.isOn ? '⚠ This starline is currently switched OFF in Starlines management.' : ''}</p>
              </>
            ) : (
              <p className="text-[12px] text-[#9CA3AF] py-2">No starlines configured yet — create them in the <b>Starlines</b> section of Market Management first.</p>
            )}
          </SectionCard>

          <SectionCard
            title="Declared Starline Results (Today)"
            headerRight={<button onClick={() => load('')} className="p-1.5 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]"><RefreshCw size={14} /></button>}
          >
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-2.5">
              {starlines.map(s => {
                const r = starResults.find(x => x.marketCode === s.code && x.resultDate === today)
                return (
                  <div key={s.code} className={`border rounded-xl p-3 ${r ? 'border-[#BFDBFE] bg-[#F8FAFF]' : 'border-[#E5E7EB] bg-white'} ${s.isOn && s.isActive ? '' : 'opacity-60'}`}>
                    <div className="text-[11px] font-bold text-[#374151] truncate">{s.name}</div>
                    <div className="text-[9.5px] text-[#9CA3AF] uppercase tracking-wide">{String(s.hour).padStart(2, '0')}:{String(s.minute).padStart(2, '0')} result</div>
                    <div className="mt-1.5 font-mono font-bold text-[15px] text-[#1D4ED8]">{r && r.openPanna ? `${r.openPanna}-${r.openDigit}` : '—'}</div>
                    <div className="text-[9.5px] text-[#9CA3AF]">{r ? (r.declaredBy === 'chart-backfill' ? 'chart data' : `by ${r.declaredBy}`) : 'not declared'}</div>
                  </div>
                )
              })}
            </div>
            {!starlines.length ? <p className="text-[12px] text-[#9CA3AF] py-4">No starlines configured.</p> : null}
          </SectionCard>

          <SectionCard title="Starline Result History">
            <div className="overflow-x-auto max-h-[360px] overflow-y-auto">
              <table className="w-full text-[12px]">
                <thead><tr className="text-left text-[#9CA3AF] border-b border-[#E5E7EB] sticky top-0 bg-white">
                  <th className="py-2.5 pr-3 font-semibold">Starline</th>
                  <th className="py-2.5 pr-3 font-semibold">Date</th>
                  <th className="py-2.5 pr-3 font-semibold">Panna</th>
                  <th className="py-2.5 pr-3 font-semibold">Digit</th>
                  <th className="py-2.5 pr-3 font-semibold">Declared At</th>
                  <th className="py-2.5 pr-3 font-semibold">By</th>
                </tr></thead>
                <tbody>
                  {starResults.map(r => (
                    <tr key={r.id} className="border-b border-[#F3F4F6] hover:bg-[#F8FAFC]">
                      <td className="py-2.5 pr-3 font-semibold text-[#111827]">{starName(r.marketCode)}</td>
                      <td className="py-2.5 pr-3 text-[#374151]">{r.resultDate}</td>
                      <td className="py-2.5 pr-3 font-mono font-bold text-[#2563EB]">{r.openPanna || '—'}</td>
                      <td className="py-2.5 pr-3 font-mono">{r.openDigit || '·'}</td>
                      <td className="py-2.5 pr-3 text-[#374151]">{dtIST(r.declaredAt)}</td>
                      <td className="py-2.5 pr-3 text-[#6B7280]">{r.declaredBy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!starResults.length ? <p className="text-[12px] text-[#9CA3AF] py-4">No starline results yet.</p> : null}
            </div>
          </SectionCard>
        </>
      )}
    </div>
  )
}
