'use client'

import React, { useState, useEffect } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { formatDate, formatCurrency, MarketChip, StatusBadge } from '@/lib/format'
import { Pagination } from '@/components/shared-ui'
import { Search, Plus, ChevronLeft } from 'lucide-react'

export function InventoryListPage() {
  const { setCurrentPage, setViewingInventoryId, currentUser } = useAppStore()
  const [data, setData] = useState<Array<Record<string, unknown>>>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [limit, setLimit] = useState(10)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    apiFetch(`/api/inventories?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`)
      .then(res => { if (!cancelled) { setData(res.data || []); setTotal(res.total || 0); setLoading(false) } })
      .catch(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [page, limit, search])

  const totalPages = Math.ceil(total / limit)
  const inv = data as Array<{
    id: string; date: string; time: string | null; status: string; totalTxn: number; remark: string | null;
    inventoryCode: { name: string; market: string; type: string };
    createdBy: string; createdAt: string;
    creatorInfo: { username: string; name: string; role: string } | null
  }>

  const roleBadge = (role: string) => {
    if (role === 'super') return <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 font-semibold">Super</span>
    if (role === 'manager') return <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-50 text-violet-700 font-semibold">Admin</span>
    return <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-sky-50 text-sky-700 font-semibold">Agent</span>
  }

  const handleView = (id: string) => {
    useAppStore.getState().setViewingInventoryId(id)
    useAppStore.getState().setCurrentPage('card-view')
  }

  return (
    <div className="p-4 md:p-7 animate-in fade-in duration-300 max-w-[1280px] mx-auto">
      {/* ── Entry Header Card (gradient indigo, matches HTML mockup design) ── */}
      <div
        className="mb-4 rounded-xl overflow-hidden relative"
        style={{ background: 'linear-gradient(135deg,#4F46E5 0%,#4338CA 100%)' }}
      >
        {/* Decorative circles */}
        <div
          className="absolute pointer-events-none rounded-full"
          style={{ top: '-30%', right: '-10%', width: 200, height: 200, background: 'rgba(255,255,255,0.06)' }}
        />
        <div
          className="absolute pointer-events-none rounded-full"
          style={{ bottom: '-40%', left: '30%', width: 160, height: 160, background: 'rgba(255,255,255,0.04)' }}
        />
        <div className="relative z-10 p-5 md:p-6 text-white">
          {/* Breadcrumb + New Entry button */}
          <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
            <nav className="flex items-center gap-2 text-[12px]">
              <button
                onClick={() => setCurrentPage('dashboard')}
                className="flex items-center gap-1 text-indigo-200 hover:text-white transition-colors font-semibold"
              >
                <ChevronLeft size={14} /> Dashboard
              </button>
              <span className="text-indigo-300">&raquo;</span>
              <span className="text-white font-semibold">Entry Lists</span>
            </nav>
            <button
              onClick={() => setCurrentPage('inv-new')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-white text-indigo-700 hover:bg-indigo-50 transition-all shadow-sm"
            >
              <Plus size={13} /> New Entry
            </button>
          </div>

          {/* Title */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
            <div>
              <h1 className="text-lg md:text-xl font-extrabold leading-tight">Entry Lists</h1>
              <p className="text-[12px] text-indigo-200 font-medium mt-0.5">
                All inventory entries across all markets
              </p>
            </div>
          </div>

          {/* Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <div className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">Total Entries</div>
              <div className="text-sm font-bold mt-0.5">{total}</div>
            </div>
            <div>
              <div className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">Current Page</div>
              <div className="text-sm font-bold mt-0.5">{page} / {totalPages || 1}</div>
            </div>
            <div>
              <div className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">Per Page</div>
              <div className="text-sm font-bold mt-0.5">{limit}</div>
            </div>
            <div>
              <div className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">Search</div>
              <div className="text-sm font-bold mt-0.5 truncate">{search || '—'}</div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Section Card ── */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden mb-4">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
          <h3 className="text-[13px] font-bold text-slate-900 tracking-wide">Entry Records</h3>
          <span className="text-[10px] text-slate-500 font-medium">{total} records</span>
        </div>
        {/* Body */}
        <div className="p-4">
          {/* Filters */}
          <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
            <div className="flex items-center gap-2 text-[12px] text-slate-500">
              Show
              <select
                value={limit}
                onChange={e => { setLimit(Number(e.target.value)); setPage(1) }}
                className="bg-white border border-slate-200 rounded-md text-slate-900 text-[12px] px-2 py-1 outline-none cursor-pointer focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
              </select>
              entries
            </div>
            <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg px-3 focus-within:border-indigo-400 focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
              <Search size={14} className="text-slate-400" />
              <input
                type="text"
                placeholder="Search entries..."
                value={search}
                onChange={e => { setSearch(e.target.value); setPage(1) }}
                className="bg-transparent border-none outline-none text-slate-900 text-[13px] py-2 w-48 placeholder:text-slate-400"
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto -mx-4 -mb-4">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  {['#', 'Date', 'Code', 'Submitted By', 'Status', 'Total TXN', 'Options'].map(h => (
                    <th
                      key={h}
                      className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-slate-500 whitespace-nowrap"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400">
                      <div className="inline-flex items-center gap-2">
                        <div className="w-3 h-3 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                        Loading...
                      </div>
                    </td>
                  </tr>
                ) : inv.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-12 text-slate-400">
                      No entries found. Try adjusting your search or create a new entry.
                    </td>
                  </tr>
                ) : (inv.map((item, i) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 hover:bg-indigo-50/40 transition-colors"
                  >
                    <td className="px-3.5 py-3">
                      <span className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 font-mono text-[11px] text-slate-500">
                        {(page - 1) * limit + i + 1}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 font-mono text-[12px] text-slate-700">{formatDate(item.date)}</td>
                    <td className="px-3.5 py-3"><MarketChip market={item.inventoryCode.market} label={item.inventoryCode.name} /></td>
                    <td className="px-3.5 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[12px] text-slate-700 font-medium">{item.creatorInfo?.name || item.createdBy || '—'}</span>
                        {item.creatorInfo
                          ? roleBadge(item.creatorInfo.role)
                          : item.createdBy === 'app' && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-sky-50 text-sky-700 font-semibold border border-sky-200">Customer App</span>
                          )}
                      </div>
                    </td>
                    <td className="px-3.5 py-3"><StatusBadge status={item.status} /></td>
                    <td className="px-3.5 py-3 font-mono text-[12px] font-semibold text-slate-900">{formatCurrency(item.totalTxn)}</td>
                    <td className="px-3.5 py-3">
                      <button
                        onClick={() => handleView(item.id)}
                        className="text-indigo-600 hover:text-indigo-800 text-[12px] font-semibold transition-colors"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                )))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between mt-4 text-[12px] text-slate-500">
            <span>
              Showing {Math.min((page - 1) * limit + 1, total)} to {Math.min(page * limit, total)} of {total} entries
            </span>
            <Pagination page={page} totalPages={totalPages} onPageChange={setPage} />
          </div>
        </div>
      </div>
    </div>
  )
}
