'use client'

// ──────────────────────────────────────────────────────────
// AGENT COMMISSION — X% of what the agent's customers PLAY,
// filed for the agent each customer belongs to (AppCustomer.
// agentUsername, set at signup via the agent code / default tree).
// Operator rule 2026-10: deposits never earn commission — every
// placed bet is a play event; a win refills the wallet and the
// next play earns again.
//
// Master/Manager: global default rate + per-agent overrides +
// full ledger + customer-wise report with mark-paid / cancel.
// Agent (role "user"): sees ONLY their own ledger + customers.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import {
  Percent, Check, X, AlertTriangle, RefreshCw, IndianRupee, Users, Save, Receipt, Clock, BadgeCheck, Ban, Wallet,
} from 'lucide-react'

const inr = (n: number | null | undefined) => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })
const dt = (v: string | null | undefined) => v ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'

interface CommissionRow {
  id: string; agentUsername: string; agentName: string | null
  customerId: string; customerName: string | null; customerMobile: string | null
  source: string; betId: string | null; fundRequestId: string | null
  baseAmount: number; marketName: string | null; detail: string | null
  rate: number; amount: number
  status: string; paidAt: string | null; paidBy: string | null; note: string | null
  createdAt: string
}
interface AgentRow { id: string; username: string; name: string | null; commissionRate: number | null; status: string }
interface CustomerRollupRow {
  customerId: string; agentUsername: string; customerName: string; customerMobile: string
  wallet: number; played: number; commission: number; count: number
}
interface CommissionsData {
  commissions: CommissionRow[]
  summary: { pendingCount: number; pendingAmount: number; paidCount: number; paidAmount: number }
  agentRollup: Array<{ agentUsername: string; totalCommission: number; totalPlayed: number; count: number }>
  customerRollup: CustomerRollupRow[]
  agents: AgentRow[]
  globalRate: number
  globalRateIsDefault?: boolean
  scope: 'all' | 'self'
}
interface CommissionWithdrawal {
  id: string; agentUsername: string; agentName: string | null
  amount: number; method: string; payoutTo: string | null
  status: string; adminNote: string | null; processedBy: string | null
  processedAt: string | null; createdAt: string
}

const statusChip: Record<string, string> = {
  pending: 'bg-[rgba(217,119,6,0.12)] text-[#B45309] border-[rgba(217,119,6,0.35)]',
  paid: 'bg-[rgba(5,150,105,0.12)] text-[#059669] border-[rgba(5,150,105,0.35)]',
  cancelled: 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]',
}

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('saved') || message.includes('marked') || message.includes('cleared') || message.includes('cancelled')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

export function AgentCommissionPage() {
  const { currentUser } = useAppStore()
  const isMaster = currentUser?.role === 'super'
  const isManager = currentUser?.role === 'manager'
  const manages = isMaster || isManager

  const [data, setData] = useState<CommissionsData | null>(null)
  const [wds, setWds] = useState<CommissionWithdrawal[]>([])
  const [wdAvailable, setWdAvailable] = useState<number | Record<string, number>>(0)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState<string | null>(null)

  // settings (master)
  const [globalRate, setGlobalRate] = useState('0')
  const [agentRateDraft, setAgentRateDraft] = useState<Record<string, string>>({})

  // filters
  const [fStatus, setFStatus] = useState('all')
  const [fAgent, setFAgent] = useState('all')

  // withdraw modal (agent)
  const [showWd, setShowWd] = useState(false)
  const [wdForm, setWdForm] = useState({ amount: '', method: 'UPI', payoutTo: '' })

  const load = useCallback(() => {
    setLoading(true)
    Promise.all([
      apiFetch('/api/app-admin/commissions'),
      apiFetch('/api/app-admin/commission-withdrawals'),
    ])
      .then(([c, w]: unknown[]) => {
        const dd = c as CommissionsData
        const ww = w as { withdrawals: CommissionWithdrawal[]; available: number | Record<string, number> }
        setData(dd)
        setGlobalRate(String(dd.globalRate))
        setWds(ww.withdrawals || [])
        setWdAvailable(ww.available ?? 0)
        setLoading(false)
      })
      .catch(() => { setLoading(false) })
  }, [])
  useEffect(() => { load() }, [load])

  const put = async (body: Record<string, unknown>, okMsg: string) => {
    setBusy(body.action as string)
    try {
      await apiFetch('/api/app-admin/commissions', { method: 'PUT', body: JSON.stringify(body) })
      setMessage(okMsg)
      load()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Action failed')
    }
    setBusy(null)
  }

  // ── Agent commission withdrawal (operator rule 2026-10) ──
  const myAvailable = typeof wdAvailable === 'number' ? wdAvailable : (wdAvailable[currentUser?.username || ''] ?? 0)
  const wdProcess = async (id: string, action: 'paid' | 'reject') => {
    if (action === 'reject' && !confirm('Reject this commission withdrawal request?')) return
    setBusy('wd-' + id)
    try {
      await apiFetch('/api/app-admin/commission-withdrawals', { method: 'PUT', body: JSON.stringify({ id, action }) })
      setMessage(action === 'paid' ? 'Commission withdrawal marked PAID — commission rows settled' : 'Withdrawal request rejected')
      load()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Action failed')
    }
    setBusy(null)
  }
  const wdSubmit = async () => {
    setBusy('wd-new')
    try {
      await apiFetch('/api/app-admin/commission-withdrawals', {
        method: 'POST',
        body: JSON.stringify({ amount: Number(wdForm.amount), method: wdForm.method, payoutTo: wdForm.payoutTo }),
      })
      setMessage('Withdrawal request filed — the master admin will process the payout')
      setShowWd(false)
      setWdForm({ amount: '', method: 'UPI', payoutTo: '' })
      load()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Request failed')
    }
    setBusy(null)
  }

  const rows = useMemo(() => {
    if (!data) return []
    return data.commissions.filter(r =>
      (fStatus === 'all' || r.status === fStatus) &&
      (fAgent === 'all' || r.agentUsername === fAgent))
  }, [data, fStatus, fAgent])

  if (loading) {
    return (
      <div className="p-7 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-violet-600 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  const s = data?.summary

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Percent size={22} className="text-violet-600" /> Agent Commission
        </h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">
          {manages
            ? 'X% of every bid your customers play is filed for the agent the customer belongs to — deposits never earn commission'
            : 'Your commission on the play of your customers — filed on every bid they place'}
        </p>
      </div>

      <Msg message={message} />

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-[11px] text-amber-600 font-semibold"><Clock size={13} /> PENDING PAYOUT</div>
          <div className="text-xl font-bold text-slate-900 mt-1">{inr(s?.pendingAmount)}</div>
          <div className="text-[11px] text-slate-400">{s?.pendingCount || 0} row{(s?.pendingCount || 0) === 1 ? '' : 's'}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-[11px] text-emerald-600 font-semibold"><BadgeCheck size={13} /> PAID</div>
          <div className="text-xl font-bold text-slate-900 mt-1">{inr(s?.paidAmount)}</div>
          <div className="text-[11px] text-slate-400">{s?.paidCount || 0} row{(s?.paidCount || 0) === 1 ? '' : 's'}</div>
        </div>
        {(data?.agentRollup || []).slice(0, manages ? 2 : 0).map(r => (
          <div key={r.agentUsername} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex items-center gap-2 text-[11px] text-violet-600 font-semibold truncate"><Users size={13} /> @{r.agentUsername}</div>
            <div className="text-xl font-bold text-slate-900 mt-1">{inr(r.totalCommission)}</div>
            <div className="text-[11px] text-slate-400">on {inr(r.totalPlayed)} played · {r.count}</div>
          </div>
        ))}
      </div>

      {/* ── Commission withdrawal flow (agent requests · master pays) ── */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden mb-5">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Wallet size={14} className="text-violet-600" />
            <b className="text-[13px] text-slate-800">Commission Withdrawals</b>
            <span className="text-[11px] text-slate-400">— {manages ? 'agent cash-out requests queue' : 'cash out your earned commission'}</span>
          </div>
          {!manages ? (
            <button
              onClick={() => setShowWd(true)}
              className="bg-violet-600 text-white text-[12px] font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 hover:bg-violet-700"
            >
              <IndianRupee size={13} /> Withdraw Commission
            </button>
          ) : null}
        </div>
        {!manages ? (
          <div className="px-4 py-3 flex items-center justify-between border-b border-slate-100 bg-violet-50/40">
            <span className="text-[12px] text-slate-600">Available to withdraw (earned − already requested)</span>
            <b className="text-[15px] text-violet-700">{inr(myAvailable)}</b>
          </div>
        ) : null}
        {wds.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-[12px]">
            {manages ? 'No withdrawal requests yet — agents file them from this page' : 'No withdrawal requests yet — file one to receive your commission payout'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-left">
                  <th className="px-4 py-2.5 font-semibold">Date</th>
                  {manages && <th className="px-4 py-2.5 font-semibold">Agent</th>}
                  <th className="px-4 py-2.5 font-semibold text-right">Amount</th>
                  <th className="px-4 py-2.5 font-semibold">Payout</th>
                  <th className="px-4 py-2.5 font-semibold">Status</th>
                  {isMaster && <th className="px-4 py-2.5 font-semibold text-right">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {wds.map(w => (
                  <tr key={w.id} className="border-t border-slate-100 hover:bg-slate-50/60">
                    <td className="px-4 py-2.5 text-slate-600 whitespace-nowrap">{dt(w.createdAt)}</td>
                    {manages && <td className="px-4 py-2.5"><div className="font-semibold text-slate-900">{w.agentName || w.agentUsername}</div><div className="text-[11px] text-slate-400">@{w.agentUsername}</div></td>}
                    <td className="px-4 py-2.5 text-right font-bold text-violet-700 whitespace-nowrap">{inr(w.amount)}</td>
                    <td className="px-4 py-2.5 text-slate-600"><div>{w.method}</div>{w.payoutTo && <div className="text-[11px] text-slate-400 mono">{w.payoutTo}</div>}</td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full border text-[10px] font-semibold uppercase tracking-wide ${statusChip[w.status] || ''}`}>{w.status}</span>
                      {w.processedBy && <div className="text-[10px] text-slate-400 mt-0.5">by {w.processedBy}</div>}
                      {w.adminNote && <div className="text-[10px] text-slate-400 mt-0.5 max-w-[180px] truncate" title={w.adminNote}>{w.adminNote}</div>}
                    </td>
                    {isMaster && (
                      <td className="px-4 py-2.5 text-right whitespace-nowrap">
                        {w.status === 'pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button disabled={busy === 'wd-' + w.id} onClick={() => wdProcess(w.id, 'paid')} className="bg-emerald-600 text-white text-[11px] font-semibold px-2.5 py-1.5 rounded-lg flex items-center gap-1 hover:bg-emerald-700 disabled:opacity-50"><IndianRupee size={11} /> Paid</button>
                            <button disabled={busy === 'wd-' + w.id} onClick={() => wdProcess(w.id, 'reject')} className="text-[11px] text-red-600 border border-red-200 px-2.5 py-1.5 rounded-lg flex items-center gap-1 hover:bg-red-50 disabled:opacity-50"><Ban size={11} /> Reject</button>
                          </div>
                        ) : <span className="text-slate-300 text-[11px]">—</span>}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Master settings */}
      {isMaster && data && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 mb-5">
          <div className="flex items-center gap-2 mb-1">
            <Percent size={16} className="text-violet-600" />
            <b className="text-[14px] text-slate-900">Commission Settings</b>
          </div>
          <p className="text-[11px] text-slate-400 mb-4">
            Rate precedence: agent override → rate set here → built-in default 2% when nothing is set (0 = commission off). Applied every time a customer PLACES a bid (on the points played — never on deposits).
          </p>
          <div className="flex flex-wrap items-end gap-3 mb-5">
            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                GLOBAL RATE (%) {data.globalRateIsDefault && <span className="text-slate-400 font-normal">— default 2% in effect, set your own to override</span>}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number" min={0} max={100} step="0.5" value={globalRate}
                  onChange={e => setGlobalRate(e.target.value)}
                  className="border border-slate-200 rounded-lg px-3 py-2 text-[13px] w-32 focus:outline-none focus:border-violet-400"
                />
                <button
                  disabled={busy === 'set_global_rate'}
                  onClick={() => put({ action: 'set_global_rate', rate: Number(globalRate) }, 'Global rate saved')}
                  className="bg-violet-600 text-white text-[12px] font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 hover:bg-violet-700 disabled:opacity-50"
                >
                  <Save size={13} /> Save
                </button>
              </div>
            </div>
          </div>

          {data.agents.length > 0 && (
            <div>
              <b className="text-[13px] text-slate-700">Per-agent overrides</b>
              <p className="text-[11px] text-slate-400 mb-3">Leave empty to use the global default rate.</p>
              <div className="space-y-2">
                {data.agents.map(a => {
                  const draft = agentRateDraft[a.username]
                  const val = draft !== undefined ? draft : (a.commissionRate === null || a.commissionRate === undefined ? '' : String(a.commissionRate))
                  return (
                    <div key={a.id} className="flex flex-wrap items-center gap-3 border border-slate-100 rounded-lg px-3 py-2">
                      <div className="flex-1 min-w-[180px]">
                        <div className="text-[13px] font-semibold text-slate-900">{a.name || a.username}</div>
                        <div className="text-[11px] text-slate-400">@{a.username}{a.commissionRate == null ? ' · global default' : ` · override ${a.commissionRate}%`}</div>
                      </div>
                      <input
                        type="number" min={0} max={100} step="0.5" placeholder="global"
                        value={val}
                        onChange={e => setAgentRateDraft(prev => ({ ...prev, [a.username]: e.target.value }))}
                        className="border border-slate-200 rounded-lg px-3 py-1.5 text-[13px] w-28 focus:outline-none focus:border-violet-400"
                      />
                      <button
                        disabled={busy === 'set_agent_rate'}
                        onClick={() => put({ action: 'set_agent_rate', agentUsername: a.username, rate: val === '' ? null : Number(val) }, `Rate for @${a.username} saved`)}
                        className="bg-violet-600 text-white text-[11px] font-semibold px-3 py-1.5 rounded-lg hover:bg-violet-700 disabled:opacity-50"
                      >
                        Save
                      </button>
                      {a.commissionRate != null && (
                        <button
                          disabled={busy === 'set_agent_rate'}
                          onClick={() => put({ action: 'set_agent_rate', agentUsername: a.username, rate: null }, `Override for @${a.username} cleared`)}
                          className="text-[11px] text-slate-500 border border-slate-200 px-3 py-1.5 rounded-lg hover:bg-slate-50 disabled:opacity-50"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filters */}
      {manages && data && data.agents.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <select
            value={fStatus} onChange={e => setFStatus(e.target.value)}
            className="border border-slate-200 rounded-lg px-3 py-2 text-[12px] bg-white focus:outline-none"
          >
            <option value="all">All statuses</option>
            <option value="pending">Pending</option>
            <option value="paid">Paid</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select
            value={fAgent} onChange={e => setFAgent(e.target.value)}
            className="border border-slate-200 rounded-lg px-3 py-2 text-[12px] bg-white focus:outline-none max-w-[220px]"
          >
            <option value="all">All agents</option>
            {data.agents.map(a => <option key={a.id} value={a.username}>{a.name || a.username} (@{a.username})</option>)}
          </select>
          <button onClick={load} className="text-[12px] text-slate-500 border border-slate-200 px-3 py-2 rounded-lg flex items-center gap-1.5 hover:bg-slate-50">
            <RefreshCw size={13} /> Refresh
          </button>
        </div>
      )}

      {/* Customer-wise commission report (detailed report for master AND agent) */}
      {data && (() => {
        const rollup = (data.customerRollup || []).filter(r => fAgent === 'all' || r.agentUsername === fAgent)
        if (rollup.length === 0) return null
        return (
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden mb-5">
            <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
              <Users size={14} className="text-violet-600" />
              <b className="text-[13px] text-slate-800">Customer-wise commission</b>
              <span className="text-[11px] text-slate-400">— played volume and commission earned per customer</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 text-left">
                    <th className="px-4 py-2.5 font-semibold">Customer</th>
                    {manages && <th className="px-4 py-2.5 font-semibold">Agent</th>}
                    <th className="px-4 py-2.5 font-semibold text-right">Wallet</th>
                    <th className="px-4 py-2.5 font-semibold text-right">Bids</th>
                    <th className="px-4 py-2.5 font-semibold text-right">Played</th>
                    <th className="px-4 py-2.5 font-semibold text-right">Commission</th>
                  </tr>
                </thead>
                <tbody>
                  {rollup.map(r => (
                    <tr key={r.customerId} className="border-t border-slate-100 hover:bg-slate-50/60">
                      <td className="px-4 py-2.5">
                        <div className="font-semibold text-slate-900">{r.customerName}</div>
                        <div className="text-[11px] text-slate-400">{r.customerMobile}</div>
                      </td>
                      {manages && <td className="px-4 py-2.5 text-slate-600">@{r.agentUsername}</td>}
                      <td className="px-4 py-2.5 text-right text-slate-600 whitespace-nowrap">{inr(r.wallet)}</td>
                      <td className="px-4 py-2.5 text-right text-slate-600">{r.count}</td>
                      <td className="px-4 py-2.5 text-right text-slate-700 font-medium whitespace-nowrap">{inr(r.played)}</td>
                      <td className="px-4 py-2.5 text-right font-bold text-violet-700 whitespace-nowrap">{inr(r.commission)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      })()}

      {/* Ledger */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {rows.length === 0 ? (
          <div className="text-center py-14 text-slate-400 text-[13px]">
            <Receipt size={26} className="mx-auto mb-2 opacity-50" />
            No commission rows yet — they appear here when your customers play bids
            {(data?.globalRate || 0) === 0 && manages ? ' and a rate above 0% is configured' : ''}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-left">
                  <th className="px-4 py-3 font-semibold">Date</th>
                  <th className="px-4 py-3 font-semibold">Customer</th>
                  {manages && <th className="px-4 py-3 font-semibold">Agent</th>}
                  <th className="px-4 py-3 font-semibold">Play</th>
                  <th className="px-4 py-3 font-semibold text-right">Played</th>
                  <th className="px-4 py-3 font-semibold text-right">Rate</th>
                  <th className="px-4 py-3 font-semibold text-right">Commission</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  {isMaster && <th className="px-4 py-3 font-semibold text-right">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.id} className="border-t border-slate-100 hover:bg-slate-50/60">
                    <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{dt(r.createdAt)}</td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-900">{r.customerName || '—'}</div>
                      <div className="text-[11px] text-slate-400">{r.customerMobile}</div>
                    </td>
                    {manages && (
                      <td className="px-4 py-3">
                        <div className="text-slate-800">{r.agentName || r.agentUsername}</div>
                        <div className="text-[11px] text-slate-400">@{r.agentUsername}</div>
                      </td>
                    )}
                    <td className="px-4 py-3 text-slate-600">
                      <div className="max-w-[200px] truncate" title={r.detail || ''}>{r.detail || '—'}</div>
                    </td>
                    <td className="px-4 py-3 text-right text-slate-700 font-medium whitespace-nowrap">{inr(r.baseAmount)}</td>
                    <td className="px-4 py-3 text-right text-slate-500">{r.rate}%</td>
                    <td className="px-4 py-3 text-right font-bold text-violet-700 whitespace-nowrap">{inr(r.amount)}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full border text-[10px] font-semibold uppercase tracking-wide ${statusChip[r.status] || ''}`}>
                        {r.status}
                      </span>
                      {r.status === 'paid' && r.paidBy && <div className="text-[10px] text-slate-400 mt-0.5">by {r.paidBy}</div>}
                      {r.note && <div className="text-[10px] text-slate-400 mt-0.5 max-w-[180px] truncate" title={r.note}>{r.note}</div>}
                    </td>
                    {isMaster && (
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        {r.status === 'pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              disabled={busy === 'mark_paid'}
                              onClick={() => put({ action: 'mark_paid', id: r.id }, 'Commission marked as paid')}
                              className="bg-emerald-600 text-white text-[11px] font-semibold px-2.5 py-1.5 rounded-lg flex items-center gap-1 hover:bg-emerald-700 disabled:opacity-50"
                            >
                              <IndianRupee size={11} /> Paid
                            </button>
                            <button
                              disabled={busy === 'cancel'}
                              onClick={() => { if (confirm('Cancel this commission row? Use only for wrong filings.')) put({ action: 'cancel', id: r.id }, 'Commission row cancelled') }}
                              className="text-[11px] text-red-600 border border-red-200 px-2.5 py-1.5 rounded-lg flex items-center gap-1 hover:bg-red-50 disabled:opacity-50"
                            >
                              <Ban size={11} /> Cancel
                            </button>
                          </div>
                        ) : <span className="text-slate-300 text-[11px]">—</span>}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {manages && (
        <p className="text-[11px] text-slate-400 mt-3 flex items-center gap-1.5">
          <X size={11} /> Rows are created automatically the moment a customer plays a bid — never manually, never twice for the same bid. Deposits never earn commission. Paying a withdrawal settles the underlying commission rows oldest-first.
        </p>
      )}

      {/* Withdraw modal (agent) */}
      {showWd && (
        <div className="fixed inset-0 z-50 bg-black/40 grid place-items-center p-4" onClick={() => setShowWd(false)}>
          <div className="bg-white rounded-2xl w-full max-w-md p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-1">
              <b className="text-[15px] text-slate-900 flex items-center gap-2"><Wallet size={16} className="text-violet-600" /> Withdraw Commission</b>
              <button onClick={() => setShowWd(false)} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>
            <p className="text-[11px] text-slate-400 mb-4">Available: <b className="text-violet-700">{inr(myAvailable)}</b> — the master admin pays this out and settles your commission rows.</p>
            <label className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block mb-1">Amount (₹)</label>
            <input type="number" min={1} value={wdForm.amount} onChange={e => setWdForm(f => ({ ...f, amount: e.target.value }))} placeholder="e.g. 500" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] mb-3 outline-none focus:border-violet-400" />
            <label className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block mb-1">Payout Method</label>
            <div className="flex gap-2 mb-3">
              {['UPI', 'Bank Transfer'].map(m => (
                <button key={m} onClick={() => setWdForm(f => ({ ...f, method: m }))} className={`flex-1 py-2 rounded-lg text-[12px] font-semibold border ${wdForm.method === m ? 'bg-violet-600 text-white border-violet-600' : 'bg-white text-slate-700 border-slate-200'}`}>{m}</button>
              ))}
            </div>
            <label className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block mb-1">{wdForm.method === 'UPI' ? 'UPI ID' : 'Account reference'}</label>
            <input value={wdForm.payoutTo} onChange={e => setWdForm(f => ({ ...f, payoutTo: e.target.value }))} placeholder={wdForm.method === 'UPI' ? 'yourname@upi' : 'A/C no + IFSC'} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] mb-4 outline-none focus:border-violet-400 mono" />
            <div className="flex justify-end gap-2">
              <button onClick={() => setShowWd(false)} className="text-[12px] font-semibold text-slate-600 border border-slate-200 px-4 py-2 rounded-lg hover:bg-slate-50">Cancel</button>
              <button
                disabled={busy === 'wd-new' || !Number(wdForm.amount) || Number(wdForm.amount) > myAvailable}
                onClick={wdSubmit}
                className="bg-violet-600 text-white text-[12px] font-semibold px-4 py-2 rounded-lg hover:bg-violet-700 disabled:opacity-50 flex items-center gap-1.5"
              >
                <Check size={13} /> File Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
