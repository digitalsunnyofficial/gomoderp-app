'use client'

import React, { useState } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { AlertTriangle, EyeOff, Eye, CheckCircle2 } from 'lucide-react'

export function LoginPage() {
  const { login } = useAppStore()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showSignup, setShowSignup] = useState(false)
  const [signupUsername, setSignupUsername] = useState('')
  const [signupPassword, setSignupPassword] = useState('')
  const [signupName, setSignupName] = useState('')
  const [signupEmail, setSignupEmail] = useState('')
  const [signupPhone, setSignupPhone] = useState('')
  const [signupRole, setSignupRole] = useState('user')
  const [signupMessage, setSignupMessage] = useState('')
  const [signupLoading, setSignupLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username || !password) { setError('Please enter username and password'); return }
    setLoading(true)
    setError('')
    try {
      const user = await apiFetch('/api/auth', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      })
      login(user)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Login failed')
    }
    setLoading(false)
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!signupUsername || !signupPassword || !signupName || !signupEmail || !signupPhone) { setSignupMessage('All fields are required: name, email, phone, username, password'); return }
    setSignupLoading(true)
    setSignupMessage('')
    try {
      await apiFetch('/api/auth/signup', {
        method: 'POST',
        body: JSON.stringify({ username: signupUsername, password: signupPassword, name: signupName, email: signupEmail, phone: signupPhone }),
      })
      setSignupMessage('Signup request submitted! Awaiting admin approval.')
      setSignupUsername('')
      setSignupPassword('')
      setSignupName('')
      setSignupEmail('')
      setSignupPhone('')
    } catch (err: unknown) {
      setSignupMessage(err instanceof Error ? err.message : 'Signup failed')
    }
    setSignupLoading(false)
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left Panel - Brand */}
      <div className="relative bg-[#0F172A] lg:w-[45%] min-h-[280px] lg:min-h-screen flex flex-col items-center justify-center p-8 overflow-hidden">
        {/* Animated Gradient Orbs */}
        <div className="absolute top-[-20%] left-[-10%] w-[400px] h-[400px] rounded-full bg-gradient-to-br from-[#4F46E5]/30 to-[#7C3AED]/20 blur-3xl animate-pulse" />
        <div className="absolute bottom-[-15%] right-[-10%] w-[350px] h-[350px] rounded-full bg-gradient-to-tl from-[#06B6D4]/25 to-[#8B5CF6]/15 blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-[40%] left-[30%] w-[200px] h-[200px] rounded-full bg-gradient-to-r from-[#EC4899]/20 to-[#F59E0B]/10 blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />

        {/* Content */}
        <div className="relative z-10 text-center">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] flex items-center justify-center text-white font-extrabold text-3xl mx-auto mb-6 shadow-2xl shadow-indigo-500/30">H</div>
          <h1 className="text-4xl font-extrabold text-white tracking-tight mb-2">Hisab System</h1>
          <p className="text-slate-400 text-sm font-medium max-w-xs mx-auto">Entry &amp; Hisab Management Platform for seamless operations</p>
        </div>

        {/* Bottom Decoration */}
        <div className="absolute bottom-6 left-0 right-0 text-center">
          <p className="text-slate-600 text-xs">Authorized personnel only</p>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
        <div className="w-full max-w-md">
          {!showSignup ? (
            /* Sign In Form */
            <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-200 overflow-hidden">
              {/* Glowing top border */}
              <div className="h-1 bg-gradient-to-r from-[#4F46E5] via-[#7C3AED] to-[#06B6D4]" />
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-slate-900">Welcome back</h2>
                  <p className="text-slate-500 text-sm mt-1">Sign in to your account</p>
                </div>

                {error && (
                  <div className="bg-red-50 text-red-600 text-sm px-4 py-3 rounded-lg flex items-center gap-2 mb-4">
                    <AlertTriangle size={16} /> {error}
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Username</label>
                    <input
                      type="text"
                      placeholder="Enter username"
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                      autoFocus
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Password</label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition"
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#4F46E5] to-[#7C3AED] text-white font-semibold text-sm hover:from-[#4338CA] hover:to-[#6D28D9] transition-all disabled:opacity-60 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/25"
                  >
                    {loading ? 'Signing in...' : 'Sign In'}
                  </button>
                </form>

                <div className="mt-6 text-center">
                  <span className="text-sm text-slate-500">Don&apos;t have an account? </span>
                  <button onClick={() => { setShowSignup(true); setError('') }} className="text-sm text-indigo-600 font-semibold hover:text-indigo-700 transition">Sign up</button>
                </div>
              </div>
            </div>
          ) : (
            /* Sign Up Form */
            <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-200 overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-[#4F46E5] via-[#7C3AED] to-[#06B6D4]" />
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-slate-900">Create account</h2>
                  <p className="text-slate-500 text-sm mt-1">Request access to the platform</p>
                </div>

                {signupMessage && (
                  <div className={`${signupMessage.includes('submitted') ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'} text-sm px-4 py-3 rounded-lg flex items-center gap-2 mb-4`}>
                    {signupMessage.includes('submitted') ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />} {signupMessage}
                  </div>
                )}

                <form onSubmit={handleSignup} className="space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Username</label>
                    <input
                      type="text"
                      placeholder="Choose a username"
                      value={signupUsername}
                      onChange={e => setSignupUsername(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Password</label>
                    <input
                      type="password"
                      placeholder="Choose a password"
                      value={signupPassword}
                      onChange={e => setSignupPassword(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Full Name <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      placeholder="Your full name"
                      value={signupName}
                      onChange={e => setSignupName(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Email <span className="text-red-500">*</span></label>
                    <input
                      type="email"
                      placeholder="you@example.com"
                      value={signupEmail}
                      onChange={e => setSignupEmail(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Phone Number <span className="text-red-500">*</span></label>
                    <input
                      type="tel"
                      placeholder="9999999999"
                      value={signupPhone}
                      onChange={e => setSignupPhone(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-3 text-[12px] text-indigo-700 leading-relaxed">
                    <strong>Note:</strong> All signups create an <strong>agent</strong> account under the Default Admin. After approval, you'll get 2-day demo access to all features. Master/Default admin will review and approve your request.
                  </div>
                  <button
                    type="submit"
                    disabled={signupLoading}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#4F46E5] to-[#7C3AED] text-white font-semibold text-sm hover:from-[#4338CA] hover:to-[#6D28D9] transition-all disabled:opacity-60 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/25"
                  >
                    {signupLoading ? 'Submitting...' : 'Request Access'}
                  </button>
                </form>

                <div className="mt-6 text-center">
                  <button onClick={() => { setShowSignup(false); setSignupMessage('') }} className="text-sm text-indigo-600 font-semibold hover:text-indigo-700 transition">Back to Sign In</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
