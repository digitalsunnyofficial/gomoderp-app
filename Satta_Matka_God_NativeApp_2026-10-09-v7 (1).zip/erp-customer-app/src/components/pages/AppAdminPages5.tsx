'use client'

// ──────────────────────────────────────────────────────────
// PAYMENT MANAGEMENT + UNIFIED CUSTOMER LIST (ERP side)
//   PaymentsPage        — business QR gateway, points, deposits
//   UnifiedCustomersPage— ONE customer list: system + app tabs,
//                         360° dossier per app customer
//   Customer360         — profile/history/withdraw/winning/loss
//                         on ONE page
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { SectionCard, FormInput, BlueButton, OutlineButton, Modal } from '@/components/shared-ui'
import { useAppStore } from '@/lib/store'
import { VendorPage } from '@/components/pages/VendorPage'
import { AppCustomersPage } from '@/components/pages/AppAdminPages'
import {
  Wallet, Check, X, AlertTriangle, RefreshCw, IndianRupee, Ban, QrCode,
  Users, Smartphone, Eye, ChevronLeft, Upload, Clock, Trophy, ArrowDownCircle,
  ArrowUpCircle, TrendingUp, TrendingDown, UserCircle,
} from 'lucide-react'

const inr = (n: number | null | undefined) => '₹' + Number(n || 0).toLocaleString('en-IN')
const dt = (v: string | null | undefined) => v ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('success') || message.includes('approved') || message.includes('saved') || message.includes('Saved') || message.includes('rejected') || message.includes('Added')
  return (
    <div className={`${ok ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-600 border-red-200'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// PAYMENT MANAGEMENT — QR gateway (1 Point = ₹1)
// ══════════════════════════════════════════════════════════
interface QrCfg { image?: string; upi?: string; payee?: string; note?: string; updatedAt?: string; updatedBy?: string }
interface DepositRow {
  id: string; customerId: string; customerName: string; customerMobile: string
  amount: number; method: string; utr: string; status: string
  processedBy?: string | null; processedAt?: string | null; note?: string | null; createdAt: string
}
interface PaySummary {
  pointsAdded24h: number; deposits24h: number
  pointsTotal: number; depositsTotal: number
  pending: number; pointRate: string
}

async function fileToCompressedDataUrl(file: File, max = 560): Promise<string> {
  const raw = await new Promise<string>((res, rej) => {
    const fr = new FileReader()
    fr.onload = () => res(String(fr.result))
    fr.onerror = () => rej(new Error('read failed'))
    fr.readAsDataURL(file)
  })
  return new Promise<string>((resolve) => {
    const img = new Image()
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height))
      const w = Math.round(img.width * scale), h = Math.round(img.height * scale)
      const cv = document.createElement('canvas')
      cv.width = w; cv.height = h
      const ctx = cv.getContext('2d')
      if (!ctx) return resolve(raw)
      ctx.drawImage(img, 0, 0, w, h)
      resolve(cv.toDataURL('image/png'))
    }
    img.onerror = () => resolve(raw)
    img.src = raw
  })
}

export function PaymentManagementPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [qr, setQr] = useState<QrCfg>({})
  const [summary, setSummary] = useState<PaySummary | null>(null)
  const [deposits, setDeposits] = useState<DepositRow[]>([])
  const [msg, setMsg] = useState('')
  const [upi, setUpi] = useState('')
  const [payee, setPayee] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const [newImage, setNewImage] = useState('')

  const load = useCallback(() => {
    apiFetch('/api/app-admin/payments').then((d: { qr: QrCfg; summary: PaySummary; deposits: DepositRow[] }) => {
      setQr(d.qr || {}); setSummary(d.summary); setDeposits(d.deposits || [])
      setUpi(d.qr?.upi || ''); setPayee(d.qr?.payee || ''); setNote(d.qr?.note || '')
    }).catch(e => setMsg((e as Error).message))
  }, [])
  useEffect(() => { load() }, [load])

  const saveQr = async () => {
    setSaving(true)
    try {
      await apiFetch('/api/app-admin/payments', {
        method: 'PUT', body: JSON.stringify({ upi, payee, note, image: newImage || undefined }),
      })
      setMsg('Payment QR saved — customers will see it instantly')
      setNewImage('')
      load()
    } catch (e) { setMsg((e as Error).message) }
    setSaving(false)
  }

  const act = async (id: string, action: 'approve' | 'reject') => {
    try {
      await apiFetch('/api/app-admin/payments', { method: 'POST', body: JSON.stringify({ id, action }) })
      setMsg(action === 'approve' ? 'Payment approved — points added to wallet' : 'Payment request rejected')
      load()
    } catch (e) { setMsg((e as Error).message) }
  }

  const stat = (label: string, value: string, tone = 'text-[#111827]') => (
    <div className="bg-white border border-slate-200 rounded-2xl px-4 py-3">
      <div className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{label}</div>
      <div className={`text-[17px] font-extrabold mt-0.5 ${tone}`}>{value}</div>
    </div>
  )

  const pendingFirst = [...deposits].sort((a, b) =>
    (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) ||
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

  return (
    <div className="p-7 animate-in fade-in duration-300 max-w-[1400px]">
      <div className="mb-5 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <Wallet size={22} className="text-blue-600" /> Payment Management
          </h1>
          <p className="text-[12px] text-slate-500 mt-1">Business QR gateway — customers pay from any payment app, points are added 1 : 1 (1 Point = ₹1). Update the QR periodically from here.</p>
        </div>
        <button onClick={load} className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" aria-label="Refresh"><RefreshCw size={15} className="text-slate-500" /></button>
      </div>

      <Msg message={msg} />

      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 mb-5">
          {stat('Points added (24h)', inr(summary.pointsAdded24h), 'text-emerald-600')}
          {stat('Deposits (24h)', String(summary.deposits24h))}
          {stat('Total points added', inr(summary.pointsTotal), 'text-blue-600')}
          {stat('Pending requests', String(summary.pending), summary.pending ? 'text-orange-500' : 'text-[#111827]')}
          {stat('Conversion', summary.pointRate, 'text-purple-600')}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-[380px_1fr] gap-4 items-start">
        <SectionCard title="Business QR">
          <div className="flex flex-col items-center gap-3">
            <div className="w-[240px] h-[240px] rounded-2xl border-2 border-dashed border-slate-200 grid place-items-center overflow-hidden bg-slate-50">
              {(newImage || qr.image)
                ? <img src={newImage || qr.image} alt="Payment QR" className="w-full h-full object-contain" />
                : <div className="text-center text-slate-400"><QrCode size={44} className="mx-auto mb-1" /><span className="text-[11px] font-semibold">No QR uploaded yet</span></div>}
            </div>
            {newImage ? <span className="text-[11px] font-bold text-blue-600">New QR ready — press Save</span> : null}
            {qr.updatedAt ? <div className="text-[10.5px] text-slate-400 flex items-center gap-1"><Clock size={11} /> Last updated {dt(qr.updatedAt)} · {qr.updatedBy || '—'}</div> : null}
            {isSuper ? (
              <>
                <input ref={fileRef} type="file" accept="image/*" className="hidden"
                  onChange={async e => {
                    const f = e.target.files?.[0]
                    if (!f) return
                    try { setNewImage(await fileToCompressedDataUrl(f)) } catch { setMsg('Could not read the image') }
                  }} />
                <div className="flex gap-2">
                  <OutlineButton onClick={() => fileRef.current?.click()}><span className="inline-flex items-center gap-1.5"><Upload size={13} /> Upload New QR</span></OutlineButton>
                  <BlueButton onClick={saveQr} disabled={saving}>{saving ? 'Saving…' : 'Save QR'}</BlueButton>
                </div>
                <div className="w-full grid grid-cols-1 gap-2 mt-1">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">UPI ID / VPA</label>
                    <FormInput value={upi} onChange={e => setUpi(e.target.value)} placeholder="business@upi" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Payee name</label>
                    <FormInput value={payee} onChange={e => setPayee(e.target.value)} placeholder="Satta Matka God" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Note in app</label>
                    <FormInput value={note} onChange={e => setNote(e.target.value)} placeholder="Scan & pay, then submit the UTR" />
                  </div>
                </div>
              </>
            ) : <p className="text-[11px] text-slate-400">Only Super Admin can update the QR</p>}
          </div>
        </SectionCard>

        <SectionCard title={`Deposit Requests — points ledger (${deposits.length})`} headerRight={<span className="text-[11px] font-bold text-slate-400">approve → points added 1 : 1</span>}>
          <div className="overflow-x-auto max-h-[520px]">
            <table className="w-full text-[12px]">
              <thead className="sticky top-0 bg-white">
                <tr className="text-left text-[10px] uppercase tracking-wide text-slate-400 border-b border-slate-100">
                  <th className="py-2 pr-3">Customer</th>
                  <th className="py-2 pr-3">Amount</th>
                  <th className="py-2 pr-3">Method</th>
                  <th className="py-2 pr-3">Reference (UTR)</th>
                  <th className="py-2 pr-3">Requested</th>
                  <th className="py-2 pr-3">Status</th>
                  {isSuper ? <th className="py-2">Action</th> : null}
                </tr>
              </thead>
              <tbody>
                {pendingFirst.map(f => (
                  <tr key={f.id} className={'border-b border-slate-50 ' + (f.status === 'pending' ? 'bg-amber-50/50' : 'hover:bg-slate-50/60')}>
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold text-slate-800">{f.customerName}</div>
                      <div className="text-[10.5px] text-slate-400 font-mono">{f.customerMobile}</div>
                    </td>
                    <td className="py-2.5 pr-3 font-bold text-slate-800">{inr(f.amount)} <span className="text-[9.5px] text-slate-400">pts</span></td>
                    <td className="py-2.5 pr-3 text-slate-600">{f.method}</td>
                    <td className="py-2.5 pr-3 font-mono text-[11px] text-slate-600">{f.utr || '—'}</td>
                    <td className="py-2.5 pr-3 text-slate-500 text-[11px]">{dt(f.createdAt)}</td>
                    <td className="py-2.5 pr-3">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${f.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : f.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-700'}`}>{f.status}</span>
                      {f.processedAt ? <div className="text-[9.5px] text-slate-400 mt-0.5">{dt(f.processedAt)}</div> : null}
                    </td>
                    {isSuper ? (
                      <td className="py-2.5">
                        {f.status === 'pending' ? (
                          <div className="flex gap-1.5">
                            <button onClick={() => act(f.id, 'approve')} className="text-[10.5px] font-bold px-2.5 py-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-1"><Check size={12} /> Approve</button>
                            <button onClick={() => act(f.id, 'reject')} className="text-[10.5px] font-bold px-2.5 py-1 rounded-md border border-red-200 text-red-600 hover:bg-red-50 inline-flex items-center gap-1"><X size={12} /> Reject</button>
                          </div>
                        ) : <span className="text-[10px] text-slate-400">{f.processedBy || ''}</span>}
                      </td>
                    ) : null}
                  </tr>
                ))}
                {!deposits.length ? <tr><td colSpan={7} className="py-6 text-center text-slate-400">No deposit requests yet</td></tr> : null}
              </tbody>
            </table>
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// UNIFIED CUSTOMER LIST — system + app customers in ONE place
// ══════════════════════════════════════════════════════════
export function UnifiedCustomersPage() {
  const [tab, setTab] = useState<'system' | 'app'>('app')
  const [view360, setView360] = useState<string | null>(null)

  if (view360) return <Customer360 id={view360} onBack={() => setView360(null)} />

  return (
    <div className="animate-in fade-in duration-300">
      <div className="px-7 pt-7 pb-1 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <Users size={22} className="text-blue-600" /> Customer List
          </h1>
          <p className="text-[12px] text-slate-500 mt-1">ALL customers of the system — web (ERP) and mobile app — managed from one place. Click an app customer for the full 360° dossier.</p>
        </div>
        <div className="inline-flex bg-slate-100 rounded-xl p-1">
          <button onClick={() => { setTab('app'); setView360(null) }}
            className={`text-[12px] font-bold px-4 py-1.5 rounded-lg inline-flex items-center gap-1.5 ${tab === 'app' ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}>
            <Smartphone size={13} /> App Customers
          </button>
          <button onClick={() => { setTab('system'); setView360(null) }}
            className={`text-[12px] font-bold px-4 py-1.5 rounded-lg inline-flex items-center gap-1.5 ${tab === 'system' ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}>
            <UserCircle size={13} /> System Customers
          </button>
        </div>
      </div>
      {tab === 'app'
        ? <AppCustomersPage onView360={setView360} />
        : <VendorPage />}
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// CUSTOMER 360 — everything on ONE page
// ══════════════════════════════════════════════════════════
interface C360 {
  customer: {
    id: string; name: string; mobile: string; wallet: number
    status: string; approval: string; approvedBy?: string | null; approvedAt?: string | null
    canBet: boolean; canWithdraw: boolean; lang?: string
    referral?: string | null; agentUsername?: string | null; agentName?: string | null
    adminUsername?: string | null; adminName?: string | null
    deviceInfo?: string | null; lastLoginAt?: string | null; createdAt: string
  }
  totals: {
    bets: number; staked: number; won: number; net: number
    pending: number; pendingStake: number; lost: number; lostStake: number; wonBets: number
    depositsApproved: number; withdrawalsPaid: number
    pendingDeposits: number; pendingWithdrawals: number
  }
  deposits: Array<{ id: string; amount: number; method: string; utr: string; status: string; createdAt: string }>
  withdrawals: Array<{ id: string; amount: number; status: string; createdAt: string }>
  ledger: Array<{ id: string; type: string; amount: number; balanceAfter: number; remark: string; createdAt: string }>
  recentBets: Array<{ id: string; marketName: string; type: string; num: string; points: number; win: number; status: string; createdAt: string; gameCode?: string | null }>
  markets: Array<{ marketCode: string; marketName: string; bets: number; staked: number; won: number }>
  notifications: Array<{ id: string; icon: string; text: string; createdAt: string }>
}

const TXN_ICON: Record<string, string> = {
  deposit: '↓', bet: '↓', win: '↑', withdraw_hold: '↓', withdraw_refund: '↑',
  withdraw_paid: '↓', admin_credit: '↑', admin_debit: '↓',
}

function Customer360({ id, onBack }: { id: string; onBack: () => void }) {
  const [data, setData] = useState<C360 | null>(null)
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')

  const load = useCallback(() => {
    apiFetch('/api/app-admin/customers/' + id).then((d: C360) => { setData(d); setErr('') }).catch(e => setErr((e as Error).message))
  }, [id])
  useEffect(() => { load() }, [load])

  if (err) return <div className="p-7"><Msg message={err} /><OutlineButton onClick={onBack}>Back to Customer List</OutlineButton></div>
  if (!data) return <div className="p-7 text-[12px] text-slate-400">Loading customer dossier…</div>

  const c = data.customer, t = data.totals
  const chip = (label: string, tone: string) => <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${tone}`}>{label}</span>

  const act = async (payload: Record<string, unknown>, okMsg: string) => {
    try {
      await apiFetch('/api/app-admin/customers', { method: 'PATCH', body: JSON.stringify({ id, ...payload }) })
      setMsg(okMsg); load()
    } catch (e) { setMsg((e as Error).message) }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300 max-w-[1400px]">
      <button onClick={onBack} className="text-[12px] font-bold text-slate-500 hover:text-blue-600 inline-flex items-center gap-1 mb-4"><ChevronLeft size={15} /> Customer List</button>

      <Msg message={msg} />

      {/* Profile header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 mb-4">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-400 text-white grid place-items-center text-[20px] font-extrabold">{c.name.slice(0, 1).toUpperCase()}</div>
            <div>
              <div className="text-[17px] font-extrabold text-slate-800 flex items-center gap-2">{c.name}
                {chip(c.approval === 'approved' ? 'APPROVED' : c.approval.toUpperCase(), c.approval === 'approved' ? 'bg-emerald-100 text-emerald-700' : c.approval === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-600')}
                {chip(c.status === 'active' ? 'ACTIVE' : 'BLOCKED', c.status === 'active' ? 'bg-slate-100 text-slate-600' : 'bg-red-100 text-red-600')}
              </div>
              <div className="text-[12px] text-slate-500 font-mono">{c.mobile} · joined {dt(c.createdAt)}</div>
              <div className="text-[11.5px] text-slate-500 mt-1">
                Tree: <b>{c.agentName || c.agentUsername || '—'}</b> (agent) → <b>{c.adminName || c.adminUsername || '—'}</b> (admin)
                {c.referral ? <span className="text-slate-400"> · ref: {c.referral}</span> : null}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-bold uppercase text-slate-400">Wallet points</div>
            <div className="text-[26px] font-extrabold text-blue-600 leading-tight">{inr(c.wallet)}</div>
            <div className="text-[10px] text-slate-400">1 Point = ₹1 · last login {c.lastLoginAt ? dt(c.lastLoginAt) : 'never'}</div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          {c.approval === 'pending' && <>
            <button onClick={() => act({ approval: 'approved' }, 'Customer approved — they can log in now')} className="text-[11px] font-bold px-3 py-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-1"><Check size={13} /> Approve Signup</button>
            <button onClick={() => act({ approval: 'rejected' }, 'Signup rejected')} className="text-[11px] font-bold px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 inline-flex items-center gap-1"><X size={13} /> Reject</button>
          </>}
          <button onClick={() => act({ status: c.status === 'active' ? 'blocked' : 'active' }, c.status === 'active' ? 'Customer blocked' : 'Customer unblocked')} className="text-[11px] font-bold px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 inline-flex items-center gap-1"><Ban size={13} /> {c.status === 'active' ? 'Block' : 'Unblock'}</button>
          <button onClick={() => act({ canBet: !c.canBet }, 'Betting flag updated')} className="text-[11px] font-bold px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50">Betting {c.canBet ? 'Off' : 'On'}</button>
          <button onClick={() => act({ canWithdraw: !c.canWithdraw }, 'Withdrawal flag updated')} className="text-[11px] font-bold px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50">Withdrawals {c.canWithdraw ? 'Off' : 'On'}</button>
        </div>
      </div>

      {/* Overall numbers */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3 mb-4">
        {[
          ['Total bids', String(t.bets), 'text-[#111827]'],
          ['Total staked', inr(t.staked), 'text-slate-800'],
          ['Total winning', inr(t.won), 'text-emerald-600'],
          ['Net (win − stake)', (t.net >= 0 ? '+' : '') + inr(t.net), t.net >= 0 ? 'text-orange-500' : 'text-emerald-600'],
          ['Deposits approved', inr(t.depositsApproved), 'text-blue-600'],
          ['Withdrawals paid', inr(t.withdrawalsPaid), 'text-purple-600'],
        ].map(([l, v, tone]) => (
          <div key={l} className="bg-white border border-slate-200 rounded-2xl px-4 py-3">
            <div className="text-[9.5px] font-bold uppercase tracking-wide text-slate-400">{l}</div>
            <div className={`text-[16px] font-extrabold mt-0.5 ${tone}`}>{v}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* History — recent bids */}
        <SectionCard title={`Bid History (${t.bets} total · ${t.pending} pending ${inr(t.pendingStake)})`}>
          <div className="overflow-x-auto max-h-[300px]">
            <table className="w-full text-[12px]">
              <thead className="sticky top-0 bg-white">
                <tr className="text-left text-[10px] uppercase text-slate-400 border-b border-slate-100">
                  <th className="py-2 pr-3">Market</th><th className="py-2 pr-3">Bid</th>
                  <th className="py-2 pr-3">Points</th><th className="py-2 pr-3">Win</th>
                  <th className="py-2 pr-3">Status</th><th className="py-2">When</th>
                </tr>
              </thead>
              <tbody>
                {data.recentBets.map(b => (
                  <tr key={b.id} className="border-b border-slate-50">
                    <td className="py-2 pr-3 font-semibold text-slate-700">{b.marketName}</td>
                    <td className="py-2 pr-3 font-mono text-slate-700">{b.type.toUpperCase()} {b.num}</td>
                    <td className="py-2 pr-3">{inr(b.points)}</td>
                    <td className="py-2 pr-3 font-bold text-emerald-600">{b.win ? inr(b.win) : '—'}</td>
                    <td className="py-2 pr-3">{chip(b.status, b.status === 'won' ? 'bg-emerald-100 text-emerald-700' : b.status === 'lost' ? 'bg-slate-100 text-slate-500' : 'bg-amber-100 text-amber-700')}</td>
                    <td className="py-2 text-[10.5px] text-slate-400">{dt(b.createdAt)}</td>
                  </tr>
                ))}
                {!data.recentBets.length ? <tr><td colSpan={6} className="py-5 text-center text-slate-400">No bids yet</td></tr> : null}
              </tbody>
            </table>
          </div>
        </SectionCard>

        {/* Market-wise */}
        <SectionCard title="Market-wise Play">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="text-left text-[10px] uppercase text-slate-400 border-b border-slate-100">
                <th className="py-2 pr-3">Market</th><th className="py-2 pr-3">Bids</th>
                <th className="py-2 pr-3">Staked</th><th className="py-2 pr-3">Won</th><th className="py-2">Net</th>
              </tr>
            </thead>
            <tbody>
              {data.markets.map(m => (
                <tr key={m.marketCode} className="border-b border-slate-50">
                  <td className="py-2 pr-3 font-semibold text-slate-700">{m.marketName}</td>
                  <td className="py-2 pr-3">{m.bets}</td>
                  <td className="py-2 pr-3">{inr(m.staked)}</td>
                  <td className="py-2 pr-3 text-emerald-600">{m.won ? inr(m.won) : '—'}</td>
                  <td className={`py-2 font-bold ${(m.won - m.staked) >= 0 ? 'text-orange-500' : 'text-emerald-600'}`}>{inr(m.won - m.staked)}</td>
                </tr>
              ))}
              {!data.markets.length ? <tr><td colSpan={5} className="py-5 text-center text-slate-400">No market activity</td></tr> : null}
            </tbody>
          </table>

          <div className="grid grid-cols-2 gap-3 mt-4">
            <div>
              <div className="text-[10px] font-bold uppercase text-slate-400 mb-1.5 flex items-center gap-1"><ArrowDownCircle size={12} /> Deposits ({data.deposits.length})</div>
              <div className="max-h-[130px] overflow-y-auto text-[11.5px]">
                {data.deposits.map(d => (
                  <div key={d.id} className="flex justify-between border-b border-slate-50 py-1.5">
                    <span className="text-slate-600">{inr(d.amount)} · {d.utr || d.method}</span>
                    {chip(d.status, d.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : d.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-700')}
                  </div>
                ))}
                {!data.deposits.length ? <p className="text-slate-400">None</p> : null}
              </div>
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-slate-400 mb-1.5 flex items-center gap-1"><ArrowUpCircle size={12} /> Withdrawals ({data.withdrawals.length})</div>
              <div className="max-h-[130px] overflow-y-auto text-[11.5px]">
                {data.withdrawals.map(w => (
                  <div key={w.id} className="flex justify-between border-b border-slate-50 py-1.5">
                    <span className="text-slate-600">{inr(w.amount)}</span>
                    {chip(w.status, w.status === 'paid' ? 'bg-emerald-100 text-emerald-700' : w.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-700')}
                  </div>
                ))}
                {!data.withdrawals.length ? <p className="text-slate-400">None</p> : null}
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Wallet ledger */}
        <SectionCard title="Wallet Ledger (points)">
          <div className="max-h-[300px] overflow-y-auto">
            {data.ledger.map(l => (
              <div key={l.id} className="flex items-center gap-3 py-2 border-b border-slate-50 text-[12px]">
                <span className={`w-7 h-7 rounded-lg grid place-items-center font-bold ${l.amount >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'}`}>{TXN_ICON[l.type] || (l.amount >= 0 ? '↑' : '↓')}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-slate-700 truncate">{l.remark}</div>
                  <div className="text-[10px] text-slate-400">{l.type} · {dt(l.createdAt)}</div>
                </div>
                <div className={`font-bold ${l.amount >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>{l.amount >= 0 ? '+' : ''}{inr(l.amount)}</div>
                <div className="w-[80px] text-right text-slate-500 text-[11px]">bal {inr(l.balanceAfter)}</div>
              </div>
            ))}
            {!data.ledger.length ? <p className="py-5 text-center text-slate-400 text-[12px]">No transactions</p> : null}
          </div>
        </SectionCard>

        {/* Notifications */}
        <SectionCard title="Recent Notifications sent">
          <div className="max-h-[300px] overflow-y-auto text-[12px]">
            {data.notifications.map(n => (
              <div key={n.id} className="py-2 border-b border-slate-50">
                <div className="text-slate-700">{n.text}</div>
                <div className="text-[10px] text-slate-400">{dt(n.createdAt)}</div>
              </div>
            ))}
            {!data.notifications.length ? <p className="py-5 text-center text-slate-400">No notifications</p> : null}
          </div>
        </SectionCard>
      </div>
    </div>
  )
}
