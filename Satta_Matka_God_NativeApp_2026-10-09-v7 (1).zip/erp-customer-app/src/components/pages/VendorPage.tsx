'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { formatCurrency } from '@/lib/format'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, Modal } from '@/components/shared-ui'
import { Search, Eye, Pencil, Trash2, Check, RotateCcw, X } from 'lucide-react'

export function VendorPage({ embedded = false }: { embedded?: boolean }) {
  const { currentUser } = useAppStore()
  const [vendors, setVendors] = useState<Array<Record<string, unknown>>>([])
  const [tab, setTab] = useState<'list' | 'add'>('list')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [viewVendor, setViewVendor] = useState<Record<string, unknown> | null>(null)
  const [editVendor, setEditVendor] = useState<Record<string, unknown> | null>(null)
  const [message, setMessage] = useState('')

  const [addForm, setAddForm] = useState({
    code: '', vendorType: 'business', businessName: '', mobileNo: '', email: '',
    businessArea: '', address: '', city: '', pincode: '', state: '',
    gstNo: '', aadharNo: '', panNo: '', businessTurnover: '', businessCategory: '',
    ownerFullName: '', ownerMobileNo: '', ownerEmail: '', ownerBirthDate: '',
    ownerAnniversaryDate: '', moreDetails: '', advance: '0', forYear: '', openingBalance: '0',
    sameAddress: true,
  })

  const fetchVendors = useCallback(() => {
    apiFetch(`/api/vendors?search=${encodeURIComponent(search)}`)
      .then(data => { setVendors(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [search])

  useEffect(() => { fetchVendors() }, [fetchVendors])

  const vendorList = vendors as Array<{
    id: string; code: string; businessName: string; mobileNo: string; email: string | null;
    aadharNo: string | null; address: string | null; moreDetails: string | null; vendorType: string;
  }>

  const handleAddVendor = async () => {
    if (!addForm.code || !addForm.businessName || !addForm.mobileNo) {
      setMessage('Code, Business Name, and Mobile are required')
      return
    }
    try {
      await apiFetch('/api/vendors', {
        method: 'POST',
        body: JSON.stringify({ ...addForm, createdBy: currentUser?.username || 'admin1' }),
      })
      setMessage('Customer added successfully!')
      setAddForm({ code: '', vendorType: 'business', businessName: '', mobileNo: '', email: '', businessArea: '', address: '', city: '', pincode: '', state: '', gstNo: '', aadharNo: '', panNo: '', businessTurnover: '', businessCategory: '', ownerFullName: '', ownerMobileNo: '', ownerEmail: '', ownerBirthDate: '', ownerAnniversaryDate: '', moreDetails: '', advance: '0', forYear: '', openingBalance: '0', sameAddress: true })
      fetchVendors()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const handleViewVendor = async (id: string) => {
    try { const data = await apiFetch(`/api/vendors/${id}`); setViewVendor(data) } catch (err) { console.error(err) }
  }

  const handleEditVendor = async (id: string) => {
    try { const data = await apiFetch(`/api/vendors/${id}`); setEditVendor(data) } catch (err) { console.error(err) }
  }

  const handleSaveEdit = async () => {
    if (!editVendor) return
    try {
      await apiFetch(`/api/vendors/${editVendor.id}`, { method: 'PUT', body: JSON.stringify(editVendor) })
      setEditVendor(null)
      fetchVendors()
      setMessage('Customer updated successfully!')
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const handleDeleteVendor = async (id: string) => {
    if (!confirm('Delete this vendor?')) return
    try { await apiFetch(`/api/vendors/${id}`, { method: 'DELETE' }); fetchVendors() } catch (err) { console.error(err) }
  }

  const vendorDetailFields = [
    { key: 'code', label: 'Customer Code' },
    { key: 'businessName', label: 'Business Name' },
    { key: 'mobileNo', label: 'Mobile No' },
    { key: 'email', label: 'Email' },
    { key: 'businessArea', label: 'Business Area' },
    { key: 'address', label: 'Address' },
    { key: 'city', label: 'City' },
    { key: 'pincode', label: 'Pincode' },
    { key: 'state', label: 'State' },
    { key: 'gstNo', label: 'GST No' },
    { key: 'aadharNo', label: 'Aadhar No' },
    { key: 'panNo', label: 'Pan No' },
    { key: 'businessTurnover', label: 'Business Turnover' },
    { key: 'businessCategory', label: 'Business Category' },
    { key: 'ownerFullName', label: 'Owner Full Name' },
    { key: 'ownerMobileNo', label: 'Owner Mobile' },
    { key: 'ownerEmail', label: 'Owner Email' },
    { key: 'moreDetails', label: 'More Details' },
    { key: 'openingBalance', label: 'Opening Balance' },
    { key: 'advance', label: 'Advance' },
  ]

  return (
    <div className={embedded ? 'animate-in fade-in duration-300' : 'p-7 animate-in fade-in duration-300'}>
      {!embedded ? (
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Customer Management</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Manage your customers</p>
      </div>
      ) : null}

      {message && (
        <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('success') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>{message}</div>
      )}

      <div className="flex gap-0 bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-0.5 w-fit mb-6">
        <button onClick={() => setTab('list')} className={`px-4 py-1.5 rounded-md text-[12px] font-medium transition-all ${tab === 'list' ? 'bg-[#3730A3] text-[#FFFFFF] font-bold' : 'text-[#6B7280]'}`}>Customer List</button>
        <button onClick={() => setTab('add')} className={`px-4 py-1.5 rounded-md text-[12px] font-medium transition-all ${tab === 'add' ? 'bg-[#3730A3] text-[#FFFFFF] font-bold' : 'text-[#6B7280]'}`}>Add Customer</button>
      </div>

      {tab === 'list' && (
        <SectionCard title="Customer List">
          <div className="flex items-center justify-end gap-3 mb-3">
            <div className="flex items-center gap-2 bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3">
              <Search size={14} className="text-[#9CA3AF]" />
              <input type="text" placeholder="Search customers..." value={search} onChange={e => setSearch(e.target.value)} className="bg-transparent border-none outline-none text-[#111827] text-[13px] py-2 w-48 placeholder:text-[#9CA3AF]" />
            </div>
          </div>
          <div className="overflow-x-auto -mx-5 -mb-5">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="bg-[#FFFFFF] border-b border-[#E5E7EB]">
                  {['VCode', 'FullName', 'MobileNo', 'Email', 'AadharNo', 'Address', 'Type', 'Options'].map(h => (
                    <th key={h} className="px-3.5 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="text-center py-8 text-[#9CA3AF]">Loading...</td></tr>
                ) : vendorList.length === 0 ? (
                  <tr><td colSpan={8} className="text-center py-8 text-[#9CA3AF]">No vendors found</td></tr>
                ) : vendorList.map(v => (
                  <tr key={v.id} className="border-b border-[rgba(229,231,235,0.5)] hover:bg-[rgba(55,48,163,0.04)] transition-colors">
                    <td className="px-3.5 py-3 font-mono text-[12px]">{v.code}</td>
                    <td className="px-3.5 py-3">{v.businessName}</td>
                    <td className="px-3.5 py-3 font-mono text-[12px]">{v.mobileNo}</td>
                    <td className="px-3.5 py-3 text-[#6B7280]">{v.email || '\u2014'}</td>
                    <td className="px-3.5 py-3 font-mono text-[12px]">{v.aadharNo || '\u2014'}</td>
                    <td className="px-3.5 py-3 text-[#6B7280] max-w-[150px] truncate">{v.address || '\u2014'}</td>
                    <td className="px-3.5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full ${v.vendorType === 'business' ? 'bg-[rgba(2,132,199,0.1)] text-[#0284C7]' : 'bg-[rgba(5,150,105,0.1)] text-[#059669]'}`}>
                        {v.vendorType === 'business' ? 'Business' : 'Individual'}
                      </span>
                    </td>
                    <td className="px-3.5 py-3">
                      <div className="flex gap-1">
                        <button onClick={() => handleViewVendor(v.id)} className="w-7 h-7 rounded-md flex items-center justify-center text-[#0284C7] hover:bg-[rgba(2,132,199,0.1)] border border-transparent hover:border-[rgba(2,132,199,0.3)] transition-all"><Eye size={14} /></button>
                        <button onClick={() => handleEditVendor(v.id)} className="w-7 h-7 rounded-md flex items-center justify-center text-[#D97706] hover:bg-[rgba(217,119,6,0.1)] border border-transparent hover:border-[rgba(217,119,6,0.3)] transition-all"><Pencil size={14} /></button>
                        <button onClick={() => handleDeleteVendor(v.id)} className="w-7 h-7 rounded-md flex items-center justify-center text-[#DC2626] hover:bg-[rgba(220,38,38,0.1)] border border-transparent hover:border-[rgba(220,38,38,0.3)] transition-all"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}

      {tab === 'add' && (
        <SectionCard title="Add New Customer">
          <div className="flex gap-4 mb-5">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="vendorType" value="business" checked={addForm.vendorType === 'business'} onChange={() => setAddForm(f => ({ ...f, vendorType: 'business' }))} className="accent-[#3730A3]" />
              <span className="text-[13px]">Business</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="vendorType" value="individual" checked={addForm.vendorType === 'individual'} onChange={() => setAddForm(f => ({ ...f, vendorType: 'individual' }))} className="accent-[#3730A3]" />
              <span className="text-[13px]">Individual</span>
            </label>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-5">
            {[
              { key: 'code', label: 'Customer Code' }, { key: 'businessName', label: 'Business Name' },
              { key: 'mobileNo', label: 'Mobile No' }, { key: 'email', label: 'Email' },
              { key: 'businessArea', label: 'Business Area' }, { key: 'address', label: 'Address' },
              { key: 'city', label: 'City' }, { key: 'pincode', label: 'Pincode' },
              { key: 'state', label: 'State' }, { key: 'gstNo', label: 'GST No' },
              { key: 'aadharNo', label: 'Aadhar No' }, { key: 'panNo', label: 'Pan No' },
              { key: 'businessTurnover', label: 'Business Turnover' }, { key: 'businessCategory', label: 'Business Category' },
              { key: 'ownerFullName', label: 'Owner Full Name' }, { key: 'ownerMobileNo', label: 'Owner Mobile' },
              { key: 'ownerEmail', label: 'Owner Email' }, { key: 'ownerBirthDate', label: 'Owner Birth Date' },
              { key: 'ownerAnniversaryDate', label: 'Owner Anniversary' }, { key: 'moreDetails', label: 'More Details' },
              { key: 'openingBalance', label: 'Opening Balance' }, { key: 'advance', label: 'Advance' },
              { key: 'forYear', label: 'For Year' },
            ].map(f => (
              <FormField key={f.key} label={f.label}>
                <FormInput
                  placeholder={f.label}
                  value={(addForm as Record<string, string>)[f.key] || ''}
                  onChange={e => setAddForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                />
              </FormField>
            ))}
          </div>
          <label className="flex items-center gap-2 mb-4 cursor-pointer">
            <input type="checkbox" checked={addForm.sameAddress} onChange={e => setAddForm(f => ({ ...f, sameAddress: e.target.checked }))} className="accent-[#3730A3]" />
            <span className="text-[13px]">Same as business address</span>
          </label>
          <div className="flex gap-2.5">
            <GoldButton onClick={handleAddVendor}><Check size={14} /> Add Customer</GoldButton>
            <OutlineButton onClick={() => setAddForm({ code: '', vendorType: 'business', businessName: '', mobileNo: '', email: '', businessArea: '', address: '', city: '', pincode: '', state: '', gstNo: '', aadharNo: '', panNo: '', businessTurnover: '', businessCategory: '', ownerFullName: '', ownerMobileNo: '', ownerEmail: '', ownerBirthDate: '', ownerAnniversaryDate: '', moreDetails: '', advance: '0', forYear: '', openingBalance: '0', sameAddress: true })}><RotateCcw size={14} /> Reset</OutlineButton>
          </div>
        </SectionCard>
      )}

      <Modal open={!!viewVendor} onClose={() => setViewVendor(null)} title="Customer Details" wide>
        {viewVendor && (
          <div className="grid grid-cols-2">
            {vendorDetailFields.map(f => (
              <React.Fragment key={f.key}>
                <div className="px-3.5 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] bg-[#FFFFFF] border-r border-b border-[#E5E7EB]">{f.label}</div>
                <div className="px-3.5 py-2.5 text-[13px] text-[#111827] bg-[#FFFFFF] border-b border-[#E5E7EB]">{String(viewVendor[f.key] ?? '\u2014')}</div>
              </React.Fragment>
            ))}
          </div>
        )}
      </Modal>

      <Modal open={!!editVendor} onClose={() => setEditVendor(null)} title="Edit Customer" wide>
        {editVendor && (
          <>
            <div className="flex gap-4 mb-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="editVendorType" value="business" checked={editVendor.vendorType === 'business'} onChange={() => setEditVendor(v => v ? { ...v, vendorType: 'business' } : v)} className="accent-[#3730A3]" />
                <span className="text-[13px]">Business</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="editVendorType" value="individual" checked={editVendor.vendorType === 'individual'} onChange={() => setEditVendor(v => v ? { ...v, vendorType: 'individual' } : v)} className="accent-[#3730A3]" />
                <span className="text-[13px]">Individual</span>
              </label>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              {vendorDetailFields.map(f => (
                <FormField key={f.key} label={f.label}>
                  <FormInput
                    value={String(editVendor[f.key] ?? '')}
                    onChange={e => setEditVendor(v => v ? { ...v, [f.key]: e.target.value } : v)}
                  />
                </FormField>
              ))}
            </div>
            <div className="flex gap-2.5 justify-end">
              <OutlineButton onClick={() => setEditVendor(null)}>Cancel</OutlineButton>
              <GoldButton onClick={handleSaveEdit}><Check size={14} /> Save Changes</GoldButton>
            </div>
          </>
        )}
      </Modal>
    </div>
  )
}
