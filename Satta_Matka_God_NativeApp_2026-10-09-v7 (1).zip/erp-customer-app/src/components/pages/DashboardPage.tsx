'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useAppStore, type PageName } from '@/lib/store'
import { canAccessPage } from '@/lib/access-control'
import { apiFetch } from '@/lib/api-helpers'
import { formatCurrency } from '@/lib/format'
import { Plus, Users, List, MessageSquare } from 'lucide-react'

export function DashboardPage() {
  const { setCurrentPage, currentUser } = useAppStore()
  const [data, setData] = useState<{
    totalInventories: number; activeVendors: number
    recentInventories: Array<{ id: string; date: string; status: string; totalTxn: number; remaining: number; inventoryCode: { name: string; market: string; type: string } }>
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const donutRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    apiFetch('/api/dashboard').then(d => { setData(d); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  // Donut chart drawing
  useEffect(() => {
    if (!donutRef.current || loading) return
    const canvas = donutRef.current
    const dpr = window.devicePixelRatio || 1
    const size = 150
    canvas.width = size * dpr
    canvas.height = size * dpr
    canvas.style.width = size + 'px'
    canvas.style.height = size + 'px'
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.scale(dpr, dpr)

    const chartData = [
      { label: 'Main Bazar', value: 38, color: '#4F46E5' },
      { label: 'Kalyan', value: 25, color: '#7C3AED' },
      { label: 'Milan Day', value: 18, color: '#10B981' },
      { label: 'Rajdhani', value: 12, color: '#F59E0B' },
      { label: 'Others', value: 7, color: '#94A3B8' },
    ]

    const cx = size / 2, cy = size / 2
    const outerR = Math.max(1, cx - 8)
    const innerR = Math.max(1, outerR * 0.62)
    const total = chartData.reduce((s, d) => s + d.value, 0)
    let progress = 0

    function animate() {
      progress = Math.min(progress + 0.025, 1)
      ctx.clearRect(0, 0, size, size)
      let angle = -Math.PI / 2
      chartData.forEach(item => {
        const slice = (item.value / total) * Math.PI * 2 * progress
        ctx.beginPath()
        ctx.arc(cx, cy, outerR, angle, angle + slice)
        ctx.arc(cx, cy, innerR, angle + slice, angle, true)
        ctx.closePath()
        ctx.fillStyle = item.color
        ctx.fill()
        angle += slice
      })
      if (progress > 0.5) {
        const alpha = Math.min((progress - 0.5) * 2, 1)
        ctx.globalAlpha = alpha
        ctx.fillStyle = '#0F172A'
        ctx.font = 'bold 18px sans-serif'
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.fillText(String(data?.totalInventories || 0), cx, cy - 6)
        ctx.font = '500 10px sans-serif'
        ctx.fillStyle = '#64748B'
        ctx.fillText('Total', cx, cy + 10)
        ctx.globalAlpha = 1
      }
      if (progress < 1) requestAnimationFrame(animate)
    }
    const timer = setTimeout(animate, 400)
    return () => clearTimeout(timer)
  }, [data, loading])

  const nav = (page: PageName) => setCurrentPage(page)
  const now = new Date()
  const greeting = now.getHours() < 12 ? 'Good Morning' : now.getHours() < 17 ? 'Good Afternoon' : 'Good Evening'
  const isMasterDashboard = currentUser?.role === 'super' || currentUser?.role === 'manager'

  const kpiCards = [
    { label: 'Total Entries', value: data?.totalInventories?.toLocaleString() || '0', sub: 'vs last month', icon: '📄', trend: '+12%', trendColor: 'text-emerald-600 bg-emerald-50' },
    { label: 'Active Customers', value: data?.activeVendors?.toString() || '0', sub: 'this week', icon: '👥', trend: '2 new', trendColor: 'text-emerald-600 bg-emerald-50' },
  ]

  const marketBars = [
    { name: 'Main Bazar', value: 68500, entries: 72, color: '#4F46E5' },
    { name: 'Kalyan', value: 42300, entries: 45, color: '#7C3AED' },
    { name: 'Milan Day', value: 31200, entries: 34, color: '#10B981' },
    { name: 'Rajdhani', value: 18900, entries: 22, color: '#F59E0B' },
    { name: 'Milan Night', value: 12400, entries: 11, color: '#94A3B8' },
  ]
  const maxBarVal = marketBars[0]?.value || 1

  const donutLegend = [
    { label: 'Main Bazar', value: 38, color: '#4F46E5' },
    { label: 'Kalyan', value: 25, color: '#7C3AED' },
    { label: 'Milan Day', value: 18, color: '#10B981' },
    { label: 'Rajdhani', value: 12, color: '#F59E0B' },
    { label: 'Others', value: 7, color: '#94A3B8' },
  ]

  const statusColor: Record<string, string> = {
    completed: 'bg-emerald-50 text-emerald-600',
    active: 'bg-indigo-50 text-indigo-600',
    pending: 'bg-amber-50 text-amber-600',
    overdue: 'bg-red-50 text-red-600',
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* Center Content */}
      <div className="flex-1 p-5 overflow-y-auto min-w-0">
        {/* Welcome */}
        <div className="mb-4">
          <h1 className="text-xl md:text-2xl font-extrabold text-slate-900">{greeting}, {currentUser?.name || 'Admin'}</h1>
          <p className="text-xs text-slate-500 mt-0.5 font-medium">{now.toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-5">
          {kpiCards.map(card => (
            <div key={card.label} className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06)] hover:-translate-y-0.5 transition-all">
              <div className="flex items-center justify-between mb-2">
                <div className="w-[38px] h-[38px] rounded-[10px] bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg">{card.icon}</div>
                <span className={`text-[0.58rem] font-bold px-1.5 py-0.5 rounded-full ${card.trendColor}`}>{card.trend}</span>
              </div>
              <div className="text-[0.65rem] font-bold uppercase tracking-[0.08em] text-slate-500 mb-0.5">{card.label}</div>
              <div className="text-2xl font-extrabold text-slate-900 leading-none">{card.value}</div>
              <div className="text-[0.6rem] text-slate-400 font-medium mt-0.5">{card.sub}</div>
            </div>
          ))}
        </div>

        {/* Entries Table */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden mb-5">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-slate-800">List of Entries</div>
              <div className="text-[0.6rem] text-slate-400 font-medium mt-0.5">Recent entry records in the system</div>
            </div>
            <button onClick={() => nav('inv-list')} className="text-[0.65rem] font-semibold text-indigo-600 hover:text-indigo-700 transition">View All</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50/80 text-left">
                  <th className="px-4 py-2 font-semibold text-slate-500 text-[0.58rem] uppercase tracking-wider">Entry ID</th>
                  <th className="px-4 py-2 font-semibold text-slate-500 text-[0.58rem] uppercase tracking-wider">Market</th>
                  <th className="px-4 py-2 font-semibold text-slate-500 text-[0.58rem] uppercase tracking-wider">Type</th>
                  <th className="px-4 py-2 font-semibold text-slate-500 text-[0.58rem] uppercase tracking-wider">Date</th>
                  <th className="px-4 py-2 font-semibold text-slate-500 text-[0.58rem] uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody>
                {(data?.recentInventories || []).slice(0, 8).map((inv, i) => (
                  <tr key={inv.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition cursor-pointer" onClick={() => { useAppStore.getState().setViewingInventoryId(inv.id); nav('card-view') }}>
                    <td className="px-4 py-2.5 font-semibold text-slate-700">{inv.inventoryCode?.name || inv.id.slice(0, 8)}</td>
                    <td className="px-4 py-2.5 text-slate-500">{inv.inventoryCode?.market || '—'}</td>
                    <td className="px-4 py-2.5 text-slate-500">{inv.inventoryCode?.type || '—'}</td>
                    <td className="px-4 py-2.5 text-slate-400 font-medium">{inv.date ? new Date(inv.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[0.6rem] font-bold capitalize ${statusColor[inv.status] || statusColor.active}`}>{inv.status}</span>
                    </td>
                  </tr>
                ))}
                {(!data?.recentInventories || data.recentInventories.length === 0) && (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400 text-sm">No entries yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Donut Chart */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <div className="text-sm font-bold text-slate-800">Entry Breakdown</div>
              <div className="text-[0.6rem] text-slate-400 font-medium mt-0.5">By market type</div>
            </div>
            <div className="p-4 flex items-center gap-4">
              <canvas ref={donutRef} style={{ width: 150, height: 150, flexShrink: 0 }} />
              <div className="flex-1 space-y-2">
                {donutLegend.map(d => (
                  <div key={d.label} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.color }} />
                      <span className="text-[0.65rem] text-slate-600 font-medium">{d.label}</span>
                    </div>
                    <span className="text-[0.65rem] text-slate-800 font-bold">{d.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Market Performance */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <div className="text-sm font-bold text-slate-800">Market Performance</div>
              <div className="text-[0.6rem] text-slate-400 font-medium mt-0.5">Value distribution by market</div>
            </div>
            <div className="p-4 space-y-3">
              {marketBars.map(m => {
                const pct = (m.value / maxBarVal) * 100
                const formatted = '₹' + (m.value >= 1000 ? (m.value / 1000).toFixed(1) + 'K' : m.value)
                return (
                  <div key={m.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[0.68rem] font-semibold text-slate-700">{m.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[0.6rem] text-slate-500 font-medium">{m.entries} entries</span>
                        <span className="text-[0.65rem] text-slate-800 font-bold">{formatted}</span>
                      </div>
                    </div>
                    <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${pct}%`, background: m.color }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <aside className="w-[320px] border-l border-slate-200 bg-white overflow-y-auto flex-shrink-0 p-5 hidden xl:block">
        {/* Quick Actions */}
        <div className="mb-6">
          <div className="text-[0.7rem] font-bold text-slate-900 mb-3">Quick Actions</div>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => nav('inv-new')} className="flex items-center gap-2.5 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition text-left">
              <div className="w-[30px] h-[30px] rounded-md bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0"><Plus size={14} /></div>
              <span className="text-[0.68rem] font-semibold text-slate-700">New Entry</span>
            </button>
            {canAccessPage(currentUser?.role, 'wa-dashboard') ? (
            <button onClick={() => nav('wa-dashboard')} className="flex items-center gap-2.5 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition text-left">
              <div className="w-[30px] h-[30px] rounded-md bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0"><MessageSquare size={14} /></div>
              <span className="text-[0.68rem] font-semibold text-slate-700">WhatsApp</span>
            </button>
            ) : null}
            <button onClick={() => nav('vendor')} className="flex items-center gap-2.5 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition text-left">
              <div className="w-[30px] h-[30px] rounded-md bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0"><Users size={14} /></div>
              <span className="text-[0.68rem] font-semibold text-slate-700">Customers</span>
            </button>
            <button onClick={() => nav('inv-list')} className="flex items-center gap-2.5 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition text-left">
              <div className="w-[30px] h-[30px] rounded-md bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0"><List size={14} /></div>
              <span className="text-[0.68rem] font-semibold text-slate-700">Records</span>
            </button>
          </div>
        </div>

        {/* Agent Overview */}
        {isMasterDashboard && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <div className="text-[0.7rem] font-bold text-slate-900">Agent Overview</div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 transition">
                <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[0.6rem] font-bold flex-shrink-0">AG</div>
                <div className="flex-1 min-w-0">
                  <div className="text-[0.7rem] font-semibold text-slate-800">Agents</div>
                  <div className="text-[0.55rem] text-slate-400 font-medium">Manage agents &amp; customers</div>
                </div>
                <div className="w-[7px] h-[7px] rounded-full bg-emerald-500 flex-shrink-0" />
              </div>
            </div>
          </div>
        )}

        {/* Recent Activity */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className="text-[0.7rem] font-bold text-slate-900">Recent Activity</div>
          </div>
          <div>
            {[
              { dot: 'bg-indigo-500', text: 'New entry created', sub: `${currentUser?.name || 'Admin'} · just now` },
              { dot: 'bg-indigo-400', text: 'Hisab record updated', sub: `${currentUser?.name || 'Admin'} · earlier` },
              { dot: 'bg-emerald-500', text: 'Customer info updated', sub: 'System · today' },
              { dot: 'bg-amber-500', text: 'Permissions modified', sub: 'System · today' },
            ].map((a, i) => (
              <div key={i} className="flex gap-2.5 py-2 border-b border-slate-50 last:border-b-0">
                <div className={`w-[7px] h-[7px] rounded-full ${a.dot} mt-1.5 flex-shrink-0`} />
                <div className="flex-1 min-w-0">
                  <div className="text-[0.65rem] font-semibold text-slate-700">{a.text}</div>
                  <div className="text-[0.55rem] text-slate-400 font-medium">{a.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Status */}
        <div>
          <div className="text-[0.7rem] font-bold text-slate-900 mb-3">System Status</div>
          <div className="bg-slate-50 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[0.6rem] text-slate-500 font-medium">Uptime</span>
              <span className="text-[0.6rem] text-slate-700 font-bold">99.8%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[0.6rem] text-slate-500 font-medium">Status</span>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-[0.6rem] text-emerald-600 font-bold">Operational</span>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </div>
  )
}
