'use client'

// ──────────────────────────────────────────────────────────
// CUSTOMER APP PANELS (ERP side) — reference dashboard UI
//   WinningReportPage  — payouts on declared results
//   PayoutRatesPage    — per family rate editor (snapshotted at bet time)
//   AppContentPage     — notice / bank details / sliders / default agent
//   WithdrawRequestsPage — payout approvals with hold + refund
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import { istDate } from '@/lib/matka/app-engine'
import { Medal, SlidersHorizontal, Wrench, ArrowUpCircle, Check, X, RefreshCw, AlertTriangle, Megaphone, Bot, Package, Upload, Trash2, Copy, Smartphone } from 'lucide-react'

const inr = (n: number | null | undefined) => '₹' + Number(n || 0).toLocaleString('en-IN')
const dt = (v: string | null | undefined) => v ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('success') || message.includes('updated') || message.includes('paid') || message.includes('Saved')
  return (
    <div className={`${ok ? 'bg-[rgba(74,222,128,.12)] text-[#4ADE80] border-[rgba(74,222,128,.35)]' : 'bg-[rgba(248,113,113,.12)] text-[#F87171] border-[rgba(248,113,113,.35)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

const chipCls = (s: string) =>
  s === 'won' || s === 'paid' || s === 'approved' || s === 'complete' ? 'bg-[rgba(74,222,128,.15)] text-[#4ADE80]'
  : s === 'pending' || s === 'partial' ? 'bg-[rgba(251,146,60,.15)] text-[#FB923C]'
  : s === 'rejected' ? 'bg-[rgba(248,113,113,.15)] text-[#F87171]'
  : 'bg-[rgba(148,163,184,.15)] text-[#6B7280]'

// ══════════════════════════════════════════════════════════
// WINNING REPORT
// ══════════════════════════════════════════════════════════
interface BetRow {
  id: string; customerId: string; customerName: string; customerMobile: string
  marketName: string; betDate: string; slot: string; type: string; num: string
  points: number; rate: number; win: number; status: string; createdAt: string
}
export function WinningReportPage() {
  const [rows, setRows] = useState<BetRow[]>([])
  const [markets, setMarkets] = useState<Array<{ code: string; name: string }>>([])
  const [market, setMarket] = useState('')
  const [date, setDate] = useState('')
  const [summary, setSummary] = useState<{ count: number; staked: number; won: number } | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    apiFetch(`/api/app-admin/bets?status=won&market=${market}&date=${date}`)
      .then((d: { bets: BetRow[]; markets: Array<{ code: string; name: string }>; summary: { count: number; staked: number; won: number } }) => {
        setRows(d.bets); setMarkets(d.markets); setSummary(d.summary); setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [market, date])
  useEffect(() => { load() }, [load])

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <Medal size={22} className="text-[#60A5FA]" /> Winning Report
          </h1>
          <p className="text-[12px] text-[#6B7280] mt-1">Payouts credited to app wallets on declared results</p>
        </div>
        <div className="flex gap-2">
          <select value={market} onChange={e => setMarket(e.target.value)}
            className="text-[12px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-2 text-[#374151] outline-none focus:border-[#60A5FA]">
            <option value="">All markets</option>
            {markets.map(m => <option key={m.code} value={m.code}>{m.name}</option>)}
          </select>
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="text-[12px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-2 text-[#374151] outline-none focus:border-[#60A5FA]" />
        </div>
      </div>
      <Msg message={''} />
      <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between flex-wrap gap-2">
          <h3 className="text-[14px] font-bold text-[#111827]">Winning History List</h3>
          <div className="flex items-center gap-2 text-[11.5px] font-semibold">
            <span className="px-2.5 py-1 rounded-full bg-[rgba(37,99,235,.13)] text-[#60A5FA]">{summary?.count ?? 0} payouts</span>
            <span className="px-2.5 py-1 rounded-full bg-[rgba(250,204,21,.13)] text-[#FACC15]">total paid {inr(summary?.won || 0)}</span>
            <button onClick={load} className="p-1.5 rounded-lg border border-[#E5E7EB] hover:border-[#3B82F6] text-[#6B7280]" aria-label="Refresh"><RefreshCw size={14} /></button>
          </div>
        </div>
        <div className="max-h-[460px] overflow-auto">
          <table className="w-full text-[12.5px]">
            <thead>
              <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#6B7280] bg-[rgba(148,163,184,.07)] sticky top-0">
                <th className="py-2.5 px-3.5 font-semibold">Member</th>
                <th className="py-2.5 px-3.5 font-semibold">Market</th>
                <th className="py-2.5 px-3.5 font-semibold">Bet</th>
                <th className="py-2.5 px-3.5 font-semibold">Stake</th>
                <th className="py-2.5 px-3.5 font-semibold">Rate</th>
                <th className="py-2.5 px-3.5 font-semibold">Win Amount</th>
                <th className="py-2.5 px-3.5 font-semibold">Date</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(b => (
                <tr key={b.id} className="border-t border-[#F3F4F6] hover:bg-[rgba(148,163,184,.05)]">
                  <td className="py-2.5 px-3.5"><b className="text-[#374151]">{b.customerName}</b><div className="text-[10.5px] font-mono text-[#9CA3AF]">{b.customerMobile}</div></td>
                  <td className="py-2.5 px-3.5 text-[#9CA3AF]">{b.marketName}<div className="text-[10px] text-[#9CA3AF]">{b.betDate}</div></td>
                  <td className="py-2.5 px-3.5">
                    <span className="uppercase font-bold text-[10.5px] text-[#FB923C]">{b.type}</span> <b className="font-mono text-[#374151]">{b.num}</b>
                    <span className="text-[10px] text-[#9CA3AF]"> · {b.slot}</span>
                  </td>
                  <td className="py-2.5 px-3.5 text-[#374151]">{inr(b.points)}</td>
                  <td className="py-2.5 px-3.5 text-[#6B7280]">1:{b.rate}</td>
                  <td className="py-2.5 px-3.5"><b className="text-[#4ADE80]">{inr(b.win)}</b></td>
                  <td className="py-2.5 px-3.5 text-[11px] text-[#6B7280]">{dt(b.createdAt)}</td>
                </tr>
              ))}
              {!rows.length && !loading && <tr><td colSpan={7} className="py-8 text-center text-[#6B7280]">No winnings for this filter</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// PAYOUT RATES — rate = win on ₹10 stake · snapshotted on bet
// ══════════════════════════════════════════════════════════
interface RateCard {
  main: { single: number; jodi: number; sp: number; dp: number; hs: number; fs: number }
  star: { single: number; oddeven: number; sp: number; dp: number; tp: number }
}
const RATE_LBL: Record<string, string> = {
  single: 'Single Digit', jodi: 'Jodi', sp: 'Single Pana', dp: 'Double Pana',
  hs: 'Half Sangam', fs: 'Full Sangam', oddeven: 'Odd/Even', tp: 'Triple Pana',
}
export function PayoutRatesPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [fam, setFam] = useState<'main' | 'star'>('main')
  const [rates, setRates] = useState<RateCard | null>(null)
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    apiFetch('/api/app-admin/config').then((d: { rates: RateCard }) => setRates(d.rates)).catch(() => setMsg('Failed to load rates'))
  }, [])

  if (!rates) return <div className="p-7"><Msg message={msg} /><p className="text-[12px] text-[#6B7280]">Loading rates…</p></div>

  const types: string[] = fam === 'main'
    ? ['single', 'jodi', 'sp', 'dp', 'hs', 'fs']
    : ['single', 'oddeven', 'sp', 'dp', 'tp']

  const save = async () => {
    setBusy(true); setMsg('')
    try {
      await apiFetch('/api/app-admin/config', { method: 'PUT', body: JSON.stringify({ rates }) })
      setMsg('Rates updated successfully — new bids snapshot the new rates')
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Update failed')
    }
    setBusy(false)
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <SlidersHorizontal size={22} className="text-[#60A5FA]" /> Payout Rates
          </h1>
          <p className="text-[12px] text-[#6B7280] mt-1">rate = win on ₹10 stake · snapshotted on every bet at placement time</p>
        </div>
        <div className="inline-flex bg-[rgba(148,163,184,.08)] rounded-[11px] p-0.5">
          <button onClick={() => setFam('main')} className={`text-[12px] font-bold px-3.5 py-1.5 rounded-[9px] ${fam === 'main' ? 'bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF]' : 'text-[#6B7280]'}`}>Main Family</button>
          <button onClick={() => setFam('star')} className={`text-[12px] font-bold px-3.5 py-1.5 rounded-[9px] ${fam === 'star' ? 'bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF]' : 'text-[#6B7280]'}`}>Starline Family</button>
        </div>
      </div>
      <Msg message={msg} />
      <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden max-w-[600px]">
        <div className="px-4 py-3 border-b border-[#E5E7EB]">
          <h3 className="text-[14px] font-bold text-[#111827]">Add Games Rate — {fam === 'main' ? 'Main' : 'Starline'}</h3>
        </div>
        <table className="w-full text-[12.5px]">
          <thead>
            <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#6B7280] bg-[rgba(148,163,184,.07)]">
              <th className="py-2 px-4 font-semibold">Game</th>
              <th className="py-2 px-4 font-semibold">Rate</th>
              <th className="py-2 px-4 font-semibold">Preview</th>
            </tr>
          </thead>
          <tbody>
            {types.map(t => {
              const key = t as string
              const val = (rates[fam] as Record<string, number>)[key] ?? 0
              return (
                <tr key={key} className="border-t border-[#F3F4F6]">
                  <td className="py-2.5 px-4 font-semibold text-[#374151]">{RATE_LBL[key]}</td>
                  <td className="py-2.5 px-4">
                    <input type="number" step="0.05" min="0.1" disabled={!isSuper} value={val}
                      onChange={e => setRates(r => r ? { ...r, [fam]: { ...(r[fam] as Record<string, number>), [key]: Number(e.target.value) } } : r)}
                      className="w-[100px] text-center font-mono font-bold text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2 py-1.5 text-[#374151] outline-none focus:border-[#60A5FA]" />
                  </td>
                  <td className="py-2.5 px-4 text-[11.5px] text-[#6B7280]">₹10 → {inr(10 * val)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <div className="px-4 py-3.5 border-t border-[#E5E7EB]">
          {isSuper ? (
            <button onClick={save} disabled={busy}
              className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold px-4 py-2 rounded-[10px] bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF] hover:brightness-110 disabled:opacity-50">
              <Check size={14} /> {busy ? 'Updating…' : 'Update Rates'}
            </button>
          ) : <span className="text-[11px] text-[#6B7280]">Only Super Admin can edit rates</span>}
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// APP CONTENT — notice marquee, bank details, sliders,
// and the DEFAULT AGENT for the Admin→Agent→Customer tree.
// ══════════════════════════════════════════════════════════
export function AppContentPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [noticeTitle, setNoticeTitle] = useState('')
  const [notice, setNotice] = useState('')
  const [deposit, setDeposit] = useState({ name: '', accountNo: '', ifsc: '', upi: '' })
  const [banners, setBanners] = useState<Array<{ t: string; s: string; bg: string }>>([])
  const [defaultAgent, setDefaultAgent] = useState('')
  const [agents, setAgents] = useState<Array<{ username: string; name: string | null; phone: string | null }>>([])
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)

  const load = useCallback(() => {
    apiFetch('/api/app-admin/config').then((d: {
      notice: string; noticeTitle: string
      deposit: Record<string, string>
      banners: Array<{ t: string; s: string; bg: string }>
      defaultAgent: string
      agents: Array<{ username: string; name: string | null; phone: string | null }>
    }) => {
      setNotice(d.notice || ''); setNoticeTitle(d.noticeTitle || '')
      setDeposit({ name: d.deposit.name || '', accountNo: d.deposit.accountNo || '', ifsc: d.deposit.ifsc || '', upi: d.deposit.upi || '' })
      setBanners(d.banners || [])
      setDefaultAgent(d.defaultAgent || '')
      setAgents(d.agents || [])
    }).catch(() => setMsg('Failed to load app content'))
  }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    setBusy(true); setMsg('')
    try {
      await apiFetch('/api/app-admin/config', {
        method: 'PUT',
        body: JSON.stringify({ notice, noticeTitle, deposit, banners, defaultAgent }),
      })
      setMsg('App content updated successfully — the Android app picks it up on next refresh')
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Update failed')
    }
    setBusy(false)
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Wrench size={22} className="text-[#60A5FA]" /> App Content
        </h1>
        <p className="text-[12px] text-[#6B7280] mt-1">Notice marquee · deposit account · sliders · default agent tree for direct signups</p>
      </div>
      <Msg message={msg} />

      <div className="grid md:grid-cols-2 gap-4 mb-4">
        {/* Notification */}
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">Notification</h3>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(37,99,235,.15)] text-[#60A5FA]">app home marquee</span>
          </div>
          <div className="p-4">
            <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280]">Title</label>
            <input value={noticeTitle} onChange={e => setNoticeTitle(e.target.value)} disabled={!isSuper}
              className="mt-1 w-full text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-3 py-2 text-[#374151] outline-none focus:border-[#60A5FA]" />
            <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280] mt-3">Description</label>
            <textarea rows={3} value={notice} onChange={e => setNotice(e.target.value)} disabled={!isSuper}
              className="mt-1 w-full text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-3 py-2 text-[#374151] outline-none focus:border-[#60A5FA]" />
            <p className="text-[11px] text-[#9CA3AF] mt-2"><Megaphone size={11} className="inline mb-px" /> Scrolls on the customer app home screen.</p>
          </div>
        </div>

        {/* Bank & app settings */}
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">Bank &amp; App Settings</h3>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(34,211,238,.15)] text-[#3B82F6]">deposit screen</span>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-2 gap-2.5">
              {([['A/C NAME', 'name'], ['A/C NO.', 'accountNo'], ['IFSC', 'ifsc'], ['UPI ID', 'upi']] as const).map(([label, key]) => (
                <div key={key}>
                  <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280]">{label}</label>
                  <input value={deposit[key]} disabled={!isSuper}
                    onChange={e => setDeposit(d => ({ ...d, [key]: e.target.value }))}
                    className="mt-1 w-full font-mono text-[12.5px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-3 py-2 text-[#374151] outline-none focus:border-[#60A5FA]" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Default agent tree */}
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">Default Agent (Hierarchy)</h3>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(37,99,235,.15)] text-[#60A5FA]">signup tree</span>
          </div>
          <div className="p-4">
            <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280]">
              Customers joining without a referral go under
            </label>
            <select value={defaultAgent} onChange={e => setDefaultAgent(e.target.value)} disabled={!isSuper}
              className="mt-1 w-full text-[13px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-3 py-2 text-[#374151] outline-none focus:border-[#60A5FA]">
              <option value="">— direct under Super Admin (no agent) —</option>
              {agents.map(a => <option key={a.username} value={a.username}>{a.username} · {a.name || 'agent'}{a.phone ? ` · ${a.phone}` : ''}</option>)}
            </select>
            <p className="text-[11px] text-[#9CA3AF] mt-2.5">
              <Bot size={11} className="inline mb-px" /> Tree per customer: <b className="text-[#9CA3AF]">Admin → Agent → Customer</b>. A referral typed in the app always wins over this default; the agent&apos;s admin completes the tree automatically.
            </p>
          </div>
        </div>

        {/* Sliders */}
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">Slider Management</h3>
            {isSuper ? (
              <button onClick={() => setBanners(b => [...b, { t: 'NEW SLIDER', s: 'subtitle text', bg: 'linear-gradient(120deg,#2563EB,#3B82F6)' }])}
                className="text-[11.5px] font-semibold px-2.5 py-1.5 rounded-lg bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF]">+ Add Slider</button>
            ) : null}
          </div>
          <div>
            {banners.map((b, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-2.5 border-t border-[#F3F4F6] first:border-t-0">
                <div className="h-[46px] w-[160px] rounded-lg grid place-items-center text-white font-bold text-[10.5px] text-center px-2 flex-shrink-0" style={{ background: b.bg }}>{b.t}</div>
                <div className="flex-1 min-w-0">
                  <input value={b.t} disabled={!isSuper} onChange={e => setBanners(bs => bs.map((x, j) => j === i ? { ...x, t: e.target.value } : x))}
                    className="w-full text-[12px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-1.5 text-[#374151] outline-none focus:border-[#60A5FA]" />
                  <input value={b.s} disabled={!isSuper} onChange={e => setBanners(bs => bs.map((x, j) => j === i ? { ...x, s: e.target.value } : x))}
                    className="w-full text-[11px] mt-1 bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-1 text-[#6B7280] outline-none focus:border-[#60A5FA]" />
                </div>
                {isSuper ? (
                  <button onClick={() => setBanners(bs => bs.filter((_, j) => j !== i))} aria-label="Delete slider"
                    className="p-1.5 rounded-lg text-[#F87171] hover:bg-[rgba(248,113,113,.15)]"><X size={15} /></button>
                ) : null}
              </div>
            ))}
            {!banners.length && <p className="px-4 py-4 text-[12px] text-[#6B7280]">No sliders — the app home shows no banners</p>}
          </div>
        </div>
      </div>

      {isSuper ? (
        <button onClick={save} disabled={busy}
          className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold px-4 py-2 rounded-[10px] bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-[#FFFFFF] hover:brightness-110 disabled:opacity-50">
          <Check size={14} /> {busy ? 'Saving…' : 'Save App Content'}
        </button>
      ) : <span className="text-[11px] text-[#6B7280]">Only Super Admin can edit app content</span>}
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// WITHDRAW REQUESTS — hold at request · paid / reject + refund
// ══════════════════════════════════════════════════════════
interface WithdrawRow {
  id: string; customerName: string; customerMobile: string; customerWallet: number
  amount: number; status: string; processedBy?: string | null; processedAt?: string | null; createdAt: string
}
export function WithdrawRequestsPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [rows, setRows] = useState<WithdrawRow[]>([])
  const [filter, setFilter] = useState('all')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    apiFetch(`/api/app-admin/withdrawals?status=${filter}`)
      .then((d: { withdrawals: WithdrawRow[] }) => { setRows(d.withdrawals); setLoading(false) })
      .catch(() => { setMessage('Failed to load withdrawal requests'); setLoading(false) })
  }, [filter])
  useEffect(() => { load() }, [load])

  const act = async (id: string, action: 'paid' | 'reject') => {
    setMessage('')
    try {
      await apiFetch('/api/app-admin/withdrawals', { method: 'POST', body: JSON.stringify({ id, action }) })
      setMessage(action === 'paid' ? 'Withdrawal marked paid successfully' : 'Withdrawal rejected — held amount refunded to wallet')
      load()
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Action failed')
    }
  }

  const pending = rows.filter(w => w.status === 'pending').length
  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <ArrowUpCircle size={22} className="text-[#60A5FA]" /> Withdraw Requests
          </h1>
          <p className="text-[12px] text-[#6B7280] mt-1">Amount is held from the wallet at request time · reject refunds automatically</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {['all', 'pending', 'paid', 'rejected'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`text-[11.5px] font-semibold px-3 py-1.5 rounded-full ${filter === f ? 'bg-[rgba(37,99,235,.15)] text-[#60A5FA]' : 'bg-[rgba(148,163,184,.15)] text-[#6B7280]'}`}>{f}</button>
          ))}
          <span className="text-[11.5px] font-semibold px-2.5 py-1 rounded-full bg-[rgba(251,146,60,.15)] text-[#FB923C]">{pending} pending</span>
        </div>
      </div>
      <Msg message={message} />
      <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
        <table className="w-full text-[12.5px]">
          <thead>
            <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#6B7280] bg-[rgba(148,163,184,.07)]">
              <th className="py-2.5 px-3.5 font-semibold">Member</th>
              <th className="py-2.5 px-3.5 font-semibold">Wallet</th>
              <th className="py-2.5 px-3.5 font-semibold">Amount</th>
              <th className="py-2.5 px-3.5 font-semibold">Requested</th>
              <th className="py-2.5 px-3.5 font-semibold">Status</th>
              <th className="py-2.5 px-3.5 text-right font-semibold">Option</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(w => (
              <tr key={w.id} className="border-t border-[#F3F4F6] hover:bg-[rgba(148,163,184,.05)]">
                <td className="py-2.5 px-3.5"><b className="text-[#374151]">{w.customerName}</b><div className="text-[10.5px] font-mono text-[#9CA3AF]">{w.customerMobile}</div></td>
                <td className="py-2.5 px-3.5 text-[#6B7280]">{inr(w.customerWallet)}</td>
                <td className="py-2.5 px-3.5"><b className="text-[#374151]">{inr(w.amount)}</b></td>
                <td className="py-2.5 px-3.5 text-[11px] text-[#6B7280]">{dt(w.createdAt)}</td>
                <td className="py-2.5 px-3.5">
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${chipCls(w.status)}`}>{w.status}</span>
                  {w.processedBy ? <div className="text-[10px] text-[#9CA3AF] mt-0.5">by {w.processedBy}</div> : null}
                </td>
                <td className="py-2.5 px-3.5 text-right whitespace-nowrap">
                  {w.status === 'pending' && isSuper ? (
                    <>
                      <button onClick={() => act(w.id, 'paid')} className="inline-flex items-center gap-1 text-[11.5px] font-semibold px-2.5 py-1.5 rounded-lg bg-[rgba(74,222,128,.15)] text-[#4ADE80] hover:bg-[rgba(74,222,128,.25)] mr-1.5"><Check size={13} /> Paid</button>
                      <button onClick={() => act(w.id, 'reject')} className="inline-flex items-center gap-1 text-[11.5px] font-semibold px-2.5 py-1.5 rounded-lg bg-[rgba(248,113,113,.15)] text-[#F87171] hover:bg-[rgba(248,113,113,.25)]"><X size={13} /> Reject</button>
                    </>
                  ) : <span className="text-[11px] text-[#9CA3AF]">—</span>}
                </td>
              </tr>
            ))}
            {!rows.length && !loading && <tr><td colSpan={6} className="py-8 text-center text-[#6B7280]">No withdrawal requests</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// APP BUILD (APK) — upload the release APK; served at /apk/sm-gomod.apk
// ══════════════════════════════════════════════════════════
interface ApkMeta {
  fileName: string; size: number; versionLabel: string
  uploadedBy?: string; uploadedAt?: string; updatedAt?: string
}

export function AppBuildPage() {
  const [apk, setApk] = useState<ApkMeta | null>(null)
  const [hasApk, setHasApk] = useState(false)
  const [loading, setLoading] = useState(true)
  const [versionLabel, setVersionLabel] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [progress, setProgress] = useState(-1) // -1 = idle, 0-100 = uploading, 200 = done flash
  const [msg, setMsg] = useState('')
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [copied, setCopied] = useState(false)

  const load = useCallback(() => {
    apiFetch('/api/app-admin/apk').then((d: { hasApk: boolean; apk?: ApkMeta }) => {
      setHasApk(!!d.hasApk); setApk(d.apk || null)
    }).catch(() => setMsg('Failed to load the current APK info')).finally(() => setLoading(false))
  }, [])
  useEffect(() => { load() }, [load])

  const publicUrl = typeof window !== 'undefined' ? `${window.location.origin}/apk/sm-gomod.apk` : '/apk/sm-gomod.apk'
  const mb = (n: number) => (n / 1024 / 1024).toFixed(1) + ' MB'

  // XHR (not fetch) — the only way to get upload progress for a 20-60 MB file
  const upload = () => {
    if (!file) { setMsg('Choose the .apk file first'); return }
    setMsg(''); setProgress(0)
    const fd = new FormData()
    fd.append('file', file)
    if (versionLabel.trim()) fd.append('versionLabel', versionLabel.trim())
    const xhr = new XMLHttpRequest()
    xhr.open('POST', '/api/app-admin/apk')
    // same-origin XHR sends the session cookie automatically — no credentials line needed
    try {
      const raw = localStorage.getItem('erp_user')
      if (raw) {
        const u = JSON.parse(raw)
        if (u?.id) xhr.setRequestHeader('x-user-id', String(u.id))
        if (u?.username) xhr.setRequestHeader('x-user-name', String(u.username))
        if (u?.role) xhr.setRequestHeader('x-user-role', String(u.role))
      }
    } catch { /* headers are best-effort; the session cookie is what authorises */ }
    xhr.upload.onprogress = e => { if (e.lengthComputable) setProgress(Math.round((e.loaded / e.total) * 100)) }
    xhr.onload = () => {
      setProgress(-1)
      let payload: { ok?: boolean; error?: string } = {}
      try { payload = JSON.parse(xhr.responseText) } catch { /* non-JSON body */ }
      if (xhr.status >= 200 && xhr.status < 300 && payload.ok) {
        setMsg('Upload success — the new build is LIVE on the landing page right now')
        setFile(null); setVersionLabel(''); setConfirmDelete(false)
        const el = document.getElementById('apk-file-input') as HTMLInputElement | null
        if (el) el.value = ''
        load()
      } else {
        setMsg(payload.error || `Upload failed (HTTP ${xhr.status})`)
      }
    }
    xhr.onerror = () => { setProgress(-1); setMsg('Upload failed — network error, try again') }
    xhr.send(fd)
  }

  const remove = async () => {
    if (!confirmDelete) { setConfirmDelete(true); return }
    setConfirmDelete(false); setMsg('')
    try {
      await apiFetch('/api/app-admin/apk', { method: 'DELETE' })
      setMsg('Upload removed success — landing page falls back to the file placed on the server, if any')
      load()
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Remove failed')
    }
  }

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(publicUrl); setCopied(true); setTimeout(() => setCopied(false), 1600) } catch { /* clipboard unavailable */ }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Package size={22} className="text-[#60A5FA]" /> App Build (APK)
        </h1>
        <p className="text-[12px] text-[#6B7280] mt-1">Upload the Android release APK here — the landing page download button serves it instantly. No more file-manager trips to the server.</p>
      </div>
      <Msg message={msg} />

      <div className="grid md:grid-cols-2 gap-4">
        {/* Current release */}
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">Current Release</h3>
            <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${hasApk ? 'bg-[rgba(74,222,128,.15)] text-[#4ADE80]' : 'bg-[rgba(148,163,184,.15)] text-[#6B7280]'}`}>
              {hasApk ? 'live' : 'not uploaded'}
            </span>
          </div>
          <div className="p-4">
            {loading ? (
              <p className="text-[12px] text-[#6B7280]">Loading…</p>
            ) : hasApk && apk ? (
              <div className="space-y-2.5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#3B82F6] grid place-items-center shrink-0"><Smartphone size={18} className="text-white" /></div>
                  <div className="min-w-0">
                    <div className="text-[13.5px] font-bold text-[#111827] truncate">{apk.fileName}</div>
                    <div className="text-[11.5px] text-[#6B7280]">{mb(apk.size)} · uploaded {dt(apk.updatedAt)}{apk.uploadedBy ? ` by ${apk.uploadedBy}` : ''}</div>
                  </div>
                </div>
                {apk.versionLabel ? (
                  <span className="inline-block text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(37,99,235,.12)] text-[#60A5FA]">{apk.versionLabel}</span>
                ) : null}
                <div>
                  <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280]">Customer download link (never changes)</label>
                  <div className="mt-1 flex items-center gap-1.5">
                    <input readOnly value={publicUrl} onFocus={e => e.currentTarget.select()}
                      className="flex-1 min-w-0 font-mono text-[11.5px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-2.5 py-2 text-[#374151] outline-none" />
                    <button onClick={copyLink} title="Copy link"
                      className="shrink-0 px-2.5 py-2 rounded-lg border border-[#D1D5DB] text-[#374151] hover:bg-[#F5F6FA] transition-colors">
                      {copied ? <Check size={14} className="text-[#4ADE80]" /> : <Copy size={14} />}
                    </button>
                    <a href={publicUrl} target="_blank" rel="noreferrer" title="Open / test download"
                      className="shrink-0 px-2.5 py-2 rounded-lg border border-[#D1D5DB] text-[#374151] hover:bg-[#F5F6FA] transition-colors inline-flex items-center">
                      <ArrowUpCircle size={14} />
                    </a>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-[12.5px] text-[#6B7280]">No APK uploaded yet. Upload one below — until then the landing page serves any APK file placed manually on the server (if the host serves /apk/ statically).</p>
            )}
          </div>
        </div>

        {/* Upload / replace */}
        <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
            <h3 className="text-[14px] font-bold text-[#111827]">{hasApk ? 'Replace Build' : 'Upload Build'}</h3>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[rgba(37,99,235,.15)] text-[#60A5FA]">.apk only · max 150 MB</span>
          </div>
          <div className="p-4">
            <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280]">APK file</label>
            <input id="apk-file-input" type="file" accept=".apk" onChange={e => setFile(e.target.files?.[0] || null)}
              className="mt-1 w-full text-[12.5px] text-[#374151] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-3 py-2 file:mr-3 file:px-3 file:py-1 file:rounded-md file:border-0 file:bg-[#2563EB] file:text-white file:text-[11.5px] file:font-semibold cursor-pointer" />
            <label className="block text-[10.5px] font-bold uppercase tracking-wide text-[#6B7280] mt-3">Version label (optional)</label>
            <input value={versionLabel} onChange={e => setVersionLabel(e.target.value)} placeholder='e.g. "v1.2 — back button + starline fixes"'
              className="mt-1 w-full text-[12.5px] bg-[#F5F6FA] border border-[#D1D5DB] rounded-lg px-3 py-2 text-[#374151] outline-none focus:border-[#60A5FA] placeholder:text-[#9CA3AF]" />
            {progress >= 0 ? (
              <div className="mt-3">
                <div className="h-2 rounded-full bg-[#E5E7EB] overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#2563EB] to-[#3B82F6] transition-all" style={{ width: `${progress}%` }} />
                </div>
                <p className="text-[11px] text-[#6B7280] mt-1 flex items-center gap-1.5"><Upload size={11} /> Uploading… {progress}%</p>
              </div>
            ) : (
              <button onClick={upload} disabled={!file}
                className={`mt-4 w-full py-2.5 rounded-xl text-[13px] font-bold text-white transition-all ${file ? 'bg-gradient-to-br from-[#2563EB] to-[#3B82F6] hover:shadow-lg hover:shadow-[rgba(37,99,235,.3)]' : 'bg-[#9CA3AF] cursor-not-allowed'}`}>
                {hasApk ? 'Replace — go live now' : 'Upload — go live now'}
              </button>
            )}
            <p className="text-[11px] text-[#9CA3AF] mt-2.5">
              The build is stored inside the database, so it survives every server redeploy. Customers always download the exact file above from the same link.
            </p>
          </div>
        </div>
      </div>

      {hasApk ? (
        <div className="mt-4 bg-[#FFFFFF] border border-[rgba(248,113,113,.35)] rounded-2xl px-4 py-3 flex items-center justify-between">
          <div>
            <div className="text-[13px] font-bold text-[#111827]">Remove the uploaded build</div>
            <p className="text-[11.5px] text-[#6B7280]">The landing page then serves a manually placed server file, if the host has one. Rarely needed.</p>
          </div>
          <button onClick={remove}
            className={`shrink-0 inline-flex items-center gap-1.5 text-[12px] font-bold px-3 py-2 rounded-lg border transition-colors ${confirmDelete ? 'bg-[rgba(248,113,113,.15)] text-[#F87171] border-[rgba(248,113,113,.5)]' : 'text-[#6B7280] border-[#D1D5DB] hover:bg-[#F5F6FA]'}`}>
            <Trash2 size={13} /> {confirmDelete ? 'Click again to confirm' : 'Remove'}
          </button>
        </div>
      ) : null}
    </div>
  )
}
