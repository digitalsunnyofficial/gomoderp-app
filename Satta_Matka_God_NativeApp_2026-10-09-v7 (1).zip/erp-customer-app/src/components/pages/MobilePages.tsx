'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useAppStore, type PageName, type MobileTab } from '@/lib/store'
import { canAccessPage } from '@/lib/access-control'
import { apiFetch } from '@/lib/api-helpers'
import { formatDate, formatDateTime, formatCurrency, getCurrentTime, MarketChip, StatusBadge } from '@/lib/format'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton, BlueButton, Pagination, Modal } from '@/components/shared-ui'
import {
  Plus, Check, X, Search, Eye, Pencil, Trash2, RefreshCw,
  ChevronLeft, ChevronRight, Home, List, Receipt, Users, UserCircle,
  ArrowLeft, HandCoins, CreditCard, Wallet, Settings, MessageCircle,
  AlertTriangle, CheckCircle2
} from 'lucide-react'

export function getMobileTabForPage(page: PageName): MobileTab {
  if (page === 'dashboard') return 'home'
  if (page === 'unified-entry') return 'smart-entry'
  if (['inv-new', 'inv-list', 'card-view'].includes(page)) return 'inventory'
  if (page === 'vendor') return 'vendors'
  if (['wa-dashboard', 'wa-messages', 'wa-templates', 'wa-approvals', 'wa-learning', 'wa-mappings', 'chitthi', 'users', 'configure', 'sys-mgmt-users', 'sys-mgmt-markets', 'sys-mgmt-activity', 'sys-mgmt-locked', 'sys-mgmt-parser-ex', 'sys-mgmt-parser-cfg', 'sys-mgmt-chart-revs', 'sub-plans', 'sub-users', 'sub-payments', 'app-customers', 'app-bids', 'app-funds', 'market-results', 'starlines', 'chart-data', 'game-management', 'game-allocation'].includes(page)) return 'profile'
  return 'home'
}

// Helper: map mobile tab to default page
export function getPageForMobileTab(tab: MobileTab): PageName {
  switch (tab) {
    case 'home': return 'dashboard'
    case 'smart-entry': return 'unified-entry'
    case 'inventory': return 'inv-list'
    case 'vendors': return 'vendor'
    case 'profile': return 'users'
  }
}

// Mobile Login Page — Material Design style
export function MobileLoginPage() {
  const { login } = useAppStore()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showSignup, setShowSignup] = useState(false)
  const [signupUsername, setSignupUsername] = useState('')
  const [signupPassword, setSignupPassword] = useState('')
  const [signupName, setSignupName] = useState('')
  const [signupEmail, setSignupEmail] = useState('')
  const [signupPhone, setSignupPhone] = useState('')
  const [signupRole, setSignupRole] = useState('user') // 'user' = Agent, 'manager' = Admin
  const [signupMessage, setSignupMessage] = useState('')
  const [signupLoading, setSignupLoading] = useState(false)
  const [signupSuccess, setSignupSuccess] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username || !password) { setError('Please enter username and password'); return }
    setLoading(true)
    setError('')
    try {
      const user = await apiFetch('/api/auth', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      })
      login(user)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Login failed')
    }
    setLoading(false)
  }

  // Full-page signup — after success, redirects to the Sign In page with a confirmation banner
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!signupUsername || !signupPassword || !signupName || !signupEmail || !signupPhone) {
      setSignupMessage('All fields are required: username, password, full name, email, phone')
      return
    }
    setSignupLoading(true)
    setSignupMessage('')
    try {
      await apiFetch('/api/auth/signup', {
        method: 'POST',
        body: JSON.stringify({ username: signupUsername, password: signupPassword, name: signupName, email: signupEmail, phone: signupPhone, requestedRole: signupRole }),
      })
      const successMsg = signupRole === 'manager'
        ? 'Account created! Your Admin access request is pending approval by the Super Admin. Please sign in after approval.'
        : 'Account created! Your Agent access request is pending approval by an Admin or the Super Admin. Please sign in after approval.'
      setSignupUsername(''); setSignupPassword(''); setSignupName(''); setSignupEmail(''); setSignupPhone('')
      setSignupRole('user')
      setShowSignup(false)
      setSignupSuccess(successMsg)
    } catch (err: unknown) {
      setSignupMessage(err instanceof Error ? err.message : 'Signup failed')
    }
    setSignupLoading(false)
  }

  // ── Dedicated Sign Up page (replaces the sign-in view entirely) ──
  if (showSignup) {
    return (
      <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(180deg, #EEF2FF 0%, #F5F6FA 260px)' }}>
        <div className="px-7 pt-12 pb-5 flex flex-col items-start gap-4">
          <div className="w-14 h-14 rounded-[16px] bg-[#3730A3] flex items-center justify-center shadow-[0_4px_12px_rgba(17,24,39,.10),0_2px_4px_rgba(17,24,39,.04)]">
            <span className="msr fill" style={{ color: '#fff', fontSize: 28 }}>person_add</span>
          </div>
          <h1 className="font-display text-[23px] font-extrabold text-[#111827]">Create account</h1>
          <p className="text-[13.5px] text-[#6B7280] font-medium -mt-2">Request access — your account will be active after approval</p>
        </div>
        <form onSubmit={handleSignup} className="flex-1 px-6 pt-2 pb-6 flex flex-col gap-3.5">
          {signupMessage && (
            <div className="flex gap-2.5 bg-[#FEE2E2] border border-[#FCA5A5] rounded-[12px] px-3.5 py-3 items-start">
              <span className="msr" style={{ color: '#DC2626', fontSize: 20 }}>error</span>
              <span className="text-[12.5px] text-[#7F1D1D] font-semibold leading-snug">{signupMessage}</span>
            </div>
          )}
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Username</label>
            <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>person</span>
              <input type="text" value={signupUsername} onChange={e => setSignupUsername(e.target.value)} placeholder="Choose a username" className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Password</label>
            <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>lock</span>
              <input type="password" value={signupPassword} onChange={e => setSignupPassword(e.target.value)} placeholder="Choose a password" className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Full Name</label>
            <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>badge</span>
              <input type="text" value={signupName} onChange={e => setSignupName(e.target.value)} placeholder="Your full name" className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Email</label>
            <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>mail</span>
              <input type="email" value={signupEmail} onChange={e => setSignupEmail(e.target.value)} placeholder="you@example.com" className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Phone Number</label>
            <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>call</span>
              <input type="tel" value={signupPhone} onChange={e => setSignupPhone(e.target.value)} placeholder="9999999999" className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Requesting Access As</label>
            <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>work</span>
              <select value={signupRole} onChange={e => setSignupRole(e.target.value)} className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium appearance-none">
                <option value="user">Agent</option>
                <option value="manager">Admin</option>
              </select>
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>expand_more</span>
            </div>
            <span className="text-[11px] text-[#6B7280] font-medium px-1">
              {signupRole === 'manager'
                ? 'Admin requests are approved by the Super Admin only'
                : 'Agent requests are approved by an Admin or the Super Admin'}
            </span>
          </div>
          <button
            type="submit"
            disabled={signupLoading}
            className="h-[52px] rounded-[12px] border-none bg-[#3730A3] text-white font-display font-bold text-[14.5px] flex items-center justify-center gap-2 cursor-pointer shadow-[0_6px_16px_rgba(55,48,163,.28)] disabled:opacity-55 disabled:shadow-none active:scale-[0.98] transition-transform"
          >
            {signupLoading ? 'Submitting...' : 'Create Account'}
          </button>
          <button type="button" onClick={() => { setShowSignup(false); setSignupMessage('') }} className="text-[12px] text-[#3730A3] font-semibold underline text-center">Back to Sign In</button>
        </form>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(180deg, #EEF2FF 0%, #F5F6FA 260px)' }}>
      <div className="px-7 pt-12 pb-5 flex flex-col items-start gap-4">
        <div className="w-14 h-14 rounded-[16px] bg-[#3730A3] flex items-center justify-center shadow-[0_4px_12px_rgba(17,24,39,.10),0_2px_4px_rgba(17,24,39,.04)]">
          <span className="msr fill" style={{ color: '#fff', fontSize: 28 }}>shield_person</span>
        </div>
        <h1 className="font-display text-[23px] font-extrabold text-[#111827]">Welcome back</h1>
        <p className="text-[13.5px] text-[#6B7280] font-medium -mt-2">Sign in to continue to your card console</p>
      </div>
      <form onSubmit={handleLogin} className="flex-1 px-6 pt-2 pb-6 flex flex-col gap-3.5">
        {signupSuccess && (
          <div className="flex gap-2.5 bg-[rgba(5,150,105,0.1)] border border-[rgba(5,150,105,0.3)] rounded-[12px] px-3.5 py-3 items-start">
            <span className="msr" style={{ color: '#059669', fontSize: 20 }}>check_circle</span>
            <span className="text-[12.5px] text-[#065F46] font-semibold leading-snug">{signupSuccess}</span>
          </div>
        )}
        {error && (
          <div className="flex gap-2.5 bg-[#FEE2E2] border border-[#FCA5A5] rounded-[12px] px-3.5 py-3 items-start">
            <span className="msr" style={{ color: '#DC2626', fontSize: 20 }}>error</span>
            <span className="text-[12.5px] text-[#7F1D1D] font-semibold leading-snug">{error}</span>
          </div>
        )}
        <div className="flex flex-col gap-1.5">
          <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Username</label>
          <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
            <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>person</span>
            <input
              type="text"
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium"
              autoFocus
            />
          </div>
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Password</label>
          <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
            <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>lock</span>
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium"
            />
            <button type="button" onClick={() => setShowPassword(!showPassword)} className="border-none bg-transparent cursor-pointer p-0">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 19 }}>{showPassword ? 'visibility' : 'visibility_off'}</span>
            </button>
          </div>
        </div>
        <div className="flex items-center justify-between mt-0.5">
          <div className="flex items-center gap-2 text-[13px] text-[#374151] font-medium">
            <div className="w-[19px] h-[19px] rounded-[6px] border-[1.8px] border-[#D1D5DB] flex items-center justify-center bg-[#3730A3] border-[#3730A3]">
              <span className="msr fill" style={{ fontSize: 14, color: '#fff' }}>check</span>
            </div>
            Remember me
          </div>
          <span className="text-[13px] text-[#3730A3] font-bold font-display">Forgot password?</span>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="h-[52px] rounded-[12px] border-none bg-[#3730A3] text-white font-display font-bold text-[14.5px] flex items-center justify-center gap-2 cursor-pointer shadow-[0_6px_16px_rgba(55,48,163,.28)] disabled:opacity-55 disabled:shadow-none active:scale-[0.98] transition-transform"
        >
          {loading ? <span className="w-[18px] h-[18px] rounded-full border-[2.5px] border-[#ffffff55] border-t-white animate-spin" /> : <span className="msr" style={{ fontSize: 18 }}>login</span>}
          {loading ? 'Signing in...' : 'Sign In'}
        </button>
        <div className="mt-2 text-center">
          <span className="text-[12px] text-[#6B7280]">Don't have an account? </span>
          <button type="button" onClick={() => { setShowSignup(true); setError('') }} className="text-[12px] text-[#3730A3] font-semibold underline">Sign up</button>
        </div>
        <div className="flex items-center gap-2.5 text-[#9CA3AF] text-[11.5px] font-semibold my-0.5">
          <div className="flex-1 h-px bg-[#E5E7EB]" />
          ACCESS TIERS
          <div className="flex-1 h-px bg-[#E5E7EB]" />
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2.5 px-3.5 py-3 bg-white border-[1.5px] border-[#E5E7EB] rounded-[12px]">
            <span className="msr fill" style={{ color: '#3730A3' }}>admin_panel_settings</span>
            <span className="text-[12.5px] text-[#374151] font-semibold leading-snug"><b>Master / Admin</b> — full access to all modules including admin &amp; hisab.</span>
          </div>
          <div className="flex items-center gap-2.5 px-3.5 py-3 bg-white border-[1.5px] border-[#E5E7EB] rounded-[12px]">
            <span className="msr fill" style={{ color: '#D97706' }}>badge</span>
            <span className="text-[12.5px] text-[#374151] font-semibold leading-snug"><b>Field Operator</b> — limited to card &amp; hisab modules for your assigned markets.</span>
          </div>
        </div>
      </form>
    </div>
  )
}

// Mobile Bottom Navigation
export function MobileBottomNav({ mobileTab, setMobileTab }: { mobileTab: MobileTab; setMobileTab: (tab: MobileTab) => void }) {
  const { setCurrentPage } = useAppStore()
  const tabs: Array<{ id: MobileTab; icon: string; label: string }> = [
    { id: 'home', icon: 'home', label: 'Home' },
    { id: 'smart-entry', icon: 'auto_awesome', label: 'Smart' },
    { id: 'inventory', icon: 'inventory_2', label: 'Entries' },
    { id: 'vendors', icon: 'groups', label: 'Customers' },
    { id: 'profile', icon: 'person', label: 'Profile' },
  ]
  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-[#E5E7EB] flex items-stretch z-50 shadow-[0_-2px_10px_rgba(17,24,39,.05)]">
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => {
            if (mobileTab !== tab.id) {
              setMobileTab(tab.id)
              setCurrentPage(getPageForMobileTab(tab.id))
            }
          }}
          className={`flex-1 flex flex-col items-center justify-center gap-0.5 border-none bg-transparent cursor-pointer relative ${mobileTab === tab.id ? 'text-[#3730A3]' : 'text-[#9CA3AF]'}`}
        >
          {mobileTab === tab.id && <div className="absolute top-1 left-1/2 -translate-x-1/2 w-9 h-[26px] rounded-[13px] bg-[#EEF2FF] -z-10" />}
          <span className={`msr ${mobileTab === tab.id ? 'fill' : ''}`} style={{ fontSize: 23 }}>{tab.icon}</span>
          <span className="text-[10.5px] font-semibold font-display tracking-tight">{tab.label}</span>
        </button>
      ))}
    </div>
  )
}

// Mobile Top App Bar
export function MobileTopBar({ pageTitle, pageSubtitle, showBack, onBack }: { pageTitle: string; pageSubtitle?: string; showBack: boolean; onBack: () => void }) {
  const { currentUser, logout } = useAppStore()
  return (
    <div className="h-14 flex items-center gap-1 px-1.5 bg-white border-b border-[#E5E7EB] z-10 shrink-0">
      {showBack && (
        <button onClick={onBack} className="w-12 h-12 border-none bg-transparent rounded-full flex items-center justify-center text-[#374151] cursor-pointer">
          <span className="msr">arrow_back</span>
        </button>
      )}
      <div className="flex-1 min-w-0 pl-0.5">
        <div className="font-display text-[16.5px] font-bold text-[#111827] truncate">{pageTitle}</div>
        {pageSubtitle && <div className="text-[11.5px] text-[#6B7280] font-medium mt-px">{pageSubtitle}</div>}
      </div>
      <div className="flex items-center gap-0.5">
        <button className="w-12 h-12 border-none bg-transparent rounded-full flex items-center justify-center text-[#374151] cursor-pointer">
          <span className="msr">notifications</span>
        </button>
        <div className="w-8 h-8 rounded-full bg-[#FEF3C7] text-[#92400E] flex items-center justify-center font-display font-bold text-[13px]">{currentUser?.name?.[0] || 'U'}</div>
      </div>
    </div>
  )
}

// Mobile FAB
export function MobileFAB({ onClick }: { onClick: () => void }) {
  return (
    <button
      className="fixed right-4 z-30 w-14 h-14 rounded-[16px] bg-[#3730A3] text-white border-none shadow-[0_4px_12px_rgba(17,24,39,.10),0_2px_4px_rgba(17,24,39,.04)] flex items-center justify-center cursor-pointer active:scale-94 transition-transform"
      style={{ bottom: 'calc(64px + 16px)' }}
      onClick={onClick}
    >
      <span className="msr">add</span>
    </button>
  )
}

// Mobile Dashboard — Material Design card-based layout
export function MobileDashboardPage() {
  const { setCurrentPage, currentUser } = useAppStore()
  const isMasterMobile = currentUser?.role === 'super' || currentUser?.role === 'manager' // WhatsApp panel quick action (master/manager)
  const [data, setData] = useState<{
    totalInventories: number; activeVendors: number
    recentInventories: Array<{ id: string; date: string; status: string; totalTxn: number; remaining: number; inventoryCode: { name: string; market: string; type: string } }>
  } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    apiFetch('/api/dashboard').then(d => { setData(d); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const nav = (page: PageName) => setCurrentPage(page)
  const now = new Date()
  const greeting = now.getHours() < 12 ? 'Good morning' : now.getHours() < 17 ? 'Good afternoon' : 'Good evening'

  const statCards = [
    { label: "Today's Collection", value: data?.totalInventories?.toLocaleString() || '0', icon: 'payments', variant: 'a' as const },
    { label: "Today's Entries", value: data?.totalInventories?.toString() || '0', icon: 'inventory_2', variant: 'b' as const },
    ...(isMasterMobile ? [{ label: 'Active Customers', value: data?.activeVendors?.toString() || '0', icon: 'groups', variant: 'b' as const }] : []),
  ]

  // Quick actions are filtered through the RBAC matrix — agents must NOT see
  // Smart Entry (operator rule, access-control.ts).
  const quickActions = ([
    { label: 'Smart Entry', icon: 'auto_awesome', page: 'unified-entry' as PageName },
    { label: 'New Entry', icon: 'add_box', page: 'inv-new' as PageName },
    { label: 'Paste Entry', icon: 'content_paste', page: 'inv-new' as PageName },
    // WhatsApp Management panel — master/manager quick action
    ...(isMasterMobile ? [{ label: 'WhatsApp', icon: 'forum', page: 'wa-dashboard' as PageName }] : []),
    { label: 'Customers', icon: 'groups', page: 'vendor' as PageName },
  ] as Array<{ label: string; icon: string; page: PageName }>).filter(q => canAccessPage(currentUser?.role, q.page))

  const getMarketColor = (market: string) => {
    const colors: Record<string, string> = {
      shridevi: '#7C3AED', milan: '#0891B2', time: '#059669', kalyan: '#D97706', rajdhani: '#DC2626',
    }
    try {
      const raw = localStorage.getItem('customMarkets')
      if (raw) { const parsed = JSON.parse(raw); if (parsed[market]?.color) return parsed[market].color }
    } catch {}
    return colors[market] || '#9333EA'
  }

  const getStatusChip = (status: string) => {
    const s = status.toLowerCase()
    if (s === 'open') return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#D1FAE5] text-[#059669]"><span className="msr fill" style={{ fontSize: 12 }}>radio_button_checked</span>Open</span>
    if (s === 'closed') return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#E8EAF6] text-[#6B7280]"><span className="msr fill" style={{ fontSize: 12 }}>lock</span>Closed</span>
    if (s === 'pending') return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#FDE68A] text-[#92400E]"><span className="msr fill" style={{ fontSize: 12 }}>pending</span>Pending</span>
    return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#D1FAE5] text-[#059669]"><span className="msr fill" style={{ fontSize: 12 }}>radio_button_checked</span>{status}</span>
  }

  if (loading) {
    return (
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 pt-4 pb-2">
          <div className="h-3 w-20 bg-[#EDEEF5] rounded animate-pulse" />
          <div className="h-5 w-36 bg-[#EDEEF5] rounded animate-pulse mt-1" />
        </div>
        <div className="flex gap-2.5 px-4 py-3.5 overflow-x-auto">
          {[1,2,3,4].map(i => <div key={i} className="w-[148px] h-[110px] bg-white border border-[#E5E7EB] rounded-[16px] animate-pulse" />)}
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Greeting */}
      <div className="px-4 pt-4 pb-1">
        <div className="text-[12.5px] text-[#6B7280] font-semibold">{greeting},</div>
        <div className="font-display text-[19px] font-extrabold text-[#111827]">{currentUser?.name || 'Admin'}</div>
      </div>

      {/* Stat cards — horizontal scroll */}
      <div className="flex gap-2.5 px-4 py-3.5 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
        {statCards.map((card, i) => (
          <div key={i} className={`shrink-0 w-[148px] rounded-[16px] px-3.5 py-3.5 flex flex-col gap-2 ${card.variant === 'a' ? 'bg-gradient-to-br from-[#3730A3] to-[#6366F1]' : 'bg-white border border-[#E5E7EB]'}`} style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
            <div className={`w-8 h-8 rounded-[9px] flex items-center justify-center ${card.variant === 'a' ? 'bg-[#ffffff26]' : 'bg-[#E8EAF6]'}`}>
              <span className="msr" style={{ color: card.variant === 'a' ? '#fff' : '#3730A3' }}>{card.icon}</span>
            </div>
            <div className={`text-[11.5px] font-semibold ${card.variant === 'a' ? 'text-[#DCDDFB]' : 'text-[#6B7280]'}`}>{card.label}</div>
            <div className={`font-display text-[20px] font-extrabold ${card.variant === 'a' ? 'text-white' : 'text-[#111827]'}`}>{card.value}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <div className="font-display text-[14.5px] font-extrabold text-[#111827]">Quick Actions</div>
      </div>
      <div className="grid grid-cols-4 gap-2 px-4 pb-1">
        {quickActions.map(qa => (
          <button key={qa.label} onClick={() => nav(qa.page)} className="flex flex-col items-center gap-1.5 border-none bg-transparent cursor-pointer">
            <div className="w-[52px] h-[52px] rounded-[16px] bg-white border border-[#E5E7EB] flex items-center justify-center" style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
              <span className="msr" style={{ color: '#3730A3', fontSize: 24 }}>{qa.icon}</span>
            </div>
            <span className="text-[10.5px] font-semibold text-[#374151] text-center leading-tight">{qa.label}</span>
          </button>
        ))}
      </div>

      {/* Recent Inventories */}
      <div className="flex items-center justify-between px-4 pt-5 pb-2">
        <div className="font-display text-[14.5px] font-extrabold text-[#111827]">Recent Cards</div>
        <button onClick={() => nav('inv-list')} className="text-[12px] font-bold text-[#3730A3] font-display">See all</button>
      </div>
      <div className="flex flex-col gap-2.5 px-4 pb-2">
        {data?.recentInventories?.map(inv => (
          <div key={inv.id} className="bg-white border border-[#E5E7EB] rounded-[16px] overflow-hidden relative" style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
            <div className="absolute left-0 top-0 bottom-0 w-1" style={{ background: getMarketColor(inv.inventoryCode.market) }} />
            <div className="px-3.5 py-3 pl-[17px]">
              <div className="flex items-start justify-between gap-2.5">
                <div>
                  <div className="font-mono text-[11px] text-[#6B7280] font-semibold">{inv.id.substring(0, 12).toUpperCase()}</div>
                  <div className="font-display text-[15px] font-bold text-[#111827] mt-0.5">{inv.inventoryCode.name}</div>
                  <div className="flex items-center gap-1.5 text-[11.5px] text-[#6B7280] font-medium mt-0.5">
                    <span className="msr" style={{ fontSize: 13 }}>schedule</span>
                    {formatDate(inv.date)}
                  </div>
                </div>
                {getStatusChip(inv.status)}
              </div>
            </div>
          </div>
        ))}
        {(!data?.recentInventories || data.recentInventories.length === 0) && (
          <div className="text-center py-8 text-[#9CA3AF] text-[12.5px] font-semibold">No recent cards</div>
        )}
      </div>
    </div>
  )
}


// ────────────────────────────────────────
// MOBILE MATERIAL DESIGN PAGE COMPONENTS
// ────────────────────────────────────────

// Mobile New Entry Page — Material Design
export function MobileNewCardPage() {
  const { currentUser, setCurrentPage, setViewingInventoryId } = useAppStore()
  const [codes, setCodes] = useState<Array<{ id: string; name: string; code: string }>>([])
  const [form, setForm] = useState({
    date: formatDate(new Date()),
    inventoryCodeId: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')
  const submitRef = useRef(false)

  useEffect(() => {
    apiFetch('/api/inventory-codes').then(setCodes).catch(console.error)
  }, [])

  const handleSubmit = async () => {
    if (!form.inventoryCodeId) { setMessage('Please select a market'); return }
    if (submitRef.current) return
    submitRef.current = true
    setSubmitting(true)
    setMessage('')
    try {
      const inventory = await apiFetch('/api/inventories', {
        method: 'POST',
        body: JSON.stringify({
          date: form.date,
          time: getCurrentTime(),
          inventoryCodeId: form.inventoryCodeId,
          remark: '',
          createdBy: currentUser?.username || 'admin1',
        }),
      }) as { id: string }
      setViewingInventoryId(inventory.id)
      setCurrentPage('card-view')
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : 'Failed to create entry'
      setMessage(errMsg)
      submitRef.current = false
    }
    setSubmitting(false)
  }

  return (
    <div className="flex-1 overflow-y-auto pb-20 px-4 pt-3">
      {/* Message */}
      {message && (
        <div className={`flex gap-2.5 rounded-[12px] px-3.5 py-3 items-start mb-3 ${message.includes('success') ? 'bg-[#D1FAE5] border border-[#6EE7B7]' : 'bg-[#FEE2E2] border border-[#FCA5A5]'}`}>
          <span className="msr" style={{ color: message.includes('success') ? '#059669' : '#DC2626', fontSize: 20 }}>{message.includes('success') ? 'check_circle' : 'error'}</span>
          <span className={`text-[12.5px] font-semibold leading-snug ${message.includes('success') ? 'text-[#065F46]' : 'text-[#7F1D1D]'}`}>{message}</span>
        </div>
      )}

      {/* Card Date */}
      <div className="flex flex-col gap-1.5 mb-3.5">
        <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Card Date</label>
        <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
          <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>calendar_today</span>
          <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
            className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
        </div>
      </div>

      {/* Markets */}
      <div className="flex flex-col gap-1.5 mb-3.5">
        <label className="text-[12px] font-bold text-[#374151] font-display tracking-tight">Markets</label>
        <div className="h-[52px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] focus-within:shadow-[0_0_0_4px_#EEF2FF] transition-all">
          <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>qr_code</span>
          <select value={form.inventoryCodeId} onChange={e => setForm(f => ({ ...f, inventoryCodeId: e.target.value }))}
            className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium appearance-none cursor-pointer">
            <option value="">Select market</option>
            {codes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <span className="msr" style={{ color: '#9CA3AF', fontSize: 18 }}>expand_more</span>
        </div>
      </div>

      {/* Submit Button */}
      <button
        onClick={handleSubmit}
        disabled={submitting}
        className="w-full h-[52px] rounded-[12px] border-none bg-[#3730A3] text-white font-display font-bold text-[14.5px] flex items-center justify-center gap-2 cursor-pointer shadow-[0_6px_16px_rgba(55,48,163,.28)] disabled:opacity-55 disabled:shadow-none active:scale-[0.98] transition-transform mt-2"
      >
        {submitting ? <span className="w-[18px] h-[18px] rounded-full border-[2.5px] border-[#ffffff55] border-t-white animate-spin" /> : <span className="msr" style={{ fontSize: 18 }}>add_circle</span>}
        {submitting ? 'Creating...' : 'Create Entry'}
      </button>
    </div>
  )
}

// Mobile Card List Page — Material Design
export function MobileCardListPage() {
  const { setCurrentPage, setViewingInventoryId } = useAppStore()
  const [data, setData] = useState<Array<Record<string, unknown>>>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    apiFetch(`/api/inventories?page=${page}&limit=10&search=${encodeURIComponent(search)}`)
      .then(res => { if (!cancelled) { setData(res.data || []); setTotal(res.total || 0); setLoading(false) } })
      .catch(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [page, search])

  const inv = data as Array<{ id: string; date: string; time: string | null; status: string; totalTxn: number; remark: string | null; inventoryCode: { name: string; market: string; type: string }; createdAt: string }>

  const getMarketColor = (market: string) => {
    const colors: Record<string, string> = {
      shridevi: '#7C3AED', milan: '#0891B2', time: '#059669', kalyan: '#D97706', rajdhani: '#DC2626',
    }
    try {
      const raw = localStorage.getItem('customMarkets')
      if (raw) { const parsed = JSON.parse(raw); if (parsed[market]?.color) return parsed[market].color }
    } catch {}
    return colors[market] || '#9333EA'
  }

  const getStatusChip = (status: string) => {
    const s = status.toLowerCase()
    if (s === 'open') return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#D1FAE5] text-[#059669]"><span className="msr fill" style={{ fontSize: 12 }}>radio_button_checked</span>Open</span>
    if (s === 'closed') return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#E8EAF6] text-[#6B7280]"><span className="msr fill" style={{ fontSize: 12 }}>lock</span>Closed</span>
    return <span className="inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-1 rounded-full bg-[#D1FAE5] text-[#059669]">{status}</span>
  }

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Search Bar */}
      <div className="px-4 pt-3 pb-2">
        <div className="h-[48px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] transition-all">
          <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>search</span>
          <input type="text" placeholder="Search cards..." value={search} onChange={e => { setSearch(e.target.value); setPage(1) }}
            className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
        </div>
      </div>

      {/* Card List */}
      <div className="flex flex-col gap-2.5 px-4 pb-2">
        {loading ? (
          [1,2,3,4,5].map(i => <div key={i} className="h-[88px] bg-white border border-[#E5E7EB] rounded-[16px] animate-pulse" />)
        ) : inv.length === 0 ? (
          <div className="text-center py-12">
            <span className="msr" style={{ fontSize: 48, color: '#D1D5DB' }}>inventory_2</span>
            <div className="text-[13px] text-[#9CA3AF] font-semibold mt-2">No cards found</div>
          </div>
        ) : inv.map(item => (
          <button key={item.id} onClick={() => { setViewingInventoryId(item.id); setCurrentPage('card-view') }}
            className="bg-white border border-[#E5E7EB] rounded-[16px] overflow-hidden relative text-left w-full cursor-pointer active:scale-[0.99] transition-transform"
            style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
            <div className="absolute left-0 top-0 bottom-0 w-1" style={{ background: getMarketColor(item.inventoryCode.market) }} />
            <div className="px-3.5 py-3 pl-[17px]">
              <div className="flex items-start justify-between gap-2.5">
                <div>
                  <div className="font-display text-[15px] font-bold text-[#111827]">{item.inventoryCode.name}</div>
                  <div className="flex items-center gap-1.5 text-[11.5px] text-[#6B7280] font-medium mt-0.5">
                    <span className="msr" style={{ fontSize: 13 }}>schedule</span>
                    {formatDate(item.date)} {item.time || formatDateTime(item.createdAt)}
                  </div>
                  <div className="text-[12px] text-[#3730A3] font-semibold font-mono mt-1">TXN: {formatCurrency(item.totalTxn)}</div>
                </div>
                {getStatusChip(item.status)}
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Pagination */}
      {total > 10 && (
        <div className="flex items-center justify-center gap-2 py-3 px-4">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
            className="w-10 h-10 rounded-[12px] border border-[#E5E7EB] bg-white flex items-center justify-center disabled:opacity-40 cursor-pointer">
            <span className="msr" style={{ fontSize: 18 }}>chevron_left</span>
          </button>
          <span className="text-[12px] font-semibold text-[#6B7280]">{page} / {Math.ceil(total / 10)}</span>
          <button onClick={() => setPage(p => Math.min(Math.ceil(total / 10), p + 1))} disabled={page >= Math.ceil(total / 10)}
            className="w-10 h-10 rounded-[12px] border border-[#E5E7EB] bg-white flex items-center justify-center disabled:opacity-40 cursor-pointer">
            <span className="msr" style={{ fontSize: 18 }}>chevron_right</span>
          </button>
        </div>
      )}
    </div>
  )
}

// Mobile Customers (Khatri) Page — Material Design
export function MobileKhatriPage() {
  const { currentUser } = useAppStore()
  const [vendors, setVendors] = useState<Array<Record<string, unknown>>>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [addForm, setAddForm] = useState({
    code: '', vendorType: 'business', businessName: '', mobileNo: '', email: '',
    businessArea: '', address: '', city: '', pincode: '', state: '',
    gstNo: '', aadharNo: '', panNo: '', businessTurnover: '', businessCategory: '',
    ownerFullName: '', ownerMobileNo: '', ownerEmail: '', ownerBirthDate: '',
    ownerAnniversaryDate: '', moreDetails: '', advance: '0', forYear: '', openingBalance: '0',
    sameAddress: true,
  })
  const [message, setMessage] = useState('')

  const fetchVendors = useCallback(() => {
    apiFetch(`/api/vendors?search=${encodeURIComponent(search)}`)
      .then(data => { setVendors(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [search])

  useEffect(() => { fetchVendors() }, [fetchVendors])

  const vendorList = vendors as Array<{
    id: string; code: string; businessName: string; mobileNo: string; email: string | null;
    aadharNo: string | null; address: string | null; moreDetails: string | null; vendorType: string;
  }>

  const handleAddVendor = async () => {
    if (!addForm.code || !addForm.businessName || !addForm.mobileNo) {
      setMessage('Code, Business Name, and Mobile are required')
      return
    }
    try {
      await apiFetch('/api/vendors', {
        method: 'POST',
        body: JSON.stringify({ ...addForm, createdBy: currentUser?.username || 'admin1' }),
      })
      setMessage('Customer added successfully!')
      setAddForm({ code: '', vendorType: 'business', businessName: '', mobileNo: '', email: '', businessArea: '', address: '', city: '', pincode: '', state: '', gstNo: '', aadharNo: '', panNo: '', businessTurnover: '', businessCategory: '', ownerFullName: '', ownerMobileNo: '', ownerEmail: '', ownerBirthDate: '', ownerAnniversaryDate: '', moreDetails: '', advance: '0', forYear: '', openingBalance: '0', sameAddress: true })
      setShowAdd(false)
      fetchVendors()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Failed')
    }
  }

  const handleDeleteVendor = async (id: string) => {
    if (!confirm('Delete this customer?')) return
    try { await apiFetch(`/api/vendors/${id}`, { method: 'DELETE' }); fetchVendors() } catch (err) { console.error(err) }
  }

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Search Bar */}
      <div className="px-4 pt-3 pb-2">
        <div className="h-[48px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] transition-all">
          <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>search</span>
          <input type="text" placeholder="Search customers..." value={search} onChange={e => setSearch(e.target.value)}
            className="border-none outline-none bg-transparent flex-1 text-[15px] text-[#111827] font-medium" />
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`mx-4 mb-2 flex gap-2.5 rounded-[12px] px-3.5 py-3 items-start ${message.includes('success') ? 'bg-[#D1FAE5] border border-[#6EE7B7]' : 'bg-[#FEE2E2] border border-[#FCA5A5]'}`}>
          <span className="msr" style={{ color: message.includes('success') ? '#059669' : '#DC2626', fontSize: 20 }}>{message.includes('success') ? 'check_circle' : 'error'}</span>
          <span className={`text-[12.5px] font-semibold leading-snug ${message.includes('success') ? 'text-[#065F46]' : 'text-[#7F1D1D]'}`}>{message}</span>
        </div>
      )}

      {/* Add Customer Form (collapsible) */}
      {showAdd && (
        <div className="mx-4 mb-3 bg-white border border-[#E5E7EB] rounded-[16px] p-4" style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display text-[16px] font-bold text-[#111827]">Add Customer</h3>
            <button onClick={() => setShowAdd(false)} className="w-8 h-8 rounded-full bg-[#F5F6FA] flex items-center justify-center border-none cursor-pointer">
              <span className="msr" style={{ fontSize: 18 }}>close</span>
            </button>
          </div>
          <div className="flex flex-col gap-3">
            <div className="h-[48px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 18 }}>badge</span>
              <input type="text" placeholder="Customer Code" value={addForm.code} onChange={e => setAddForm(f => ({ ...f, code: e.target.value }))}
                className="border-none outline-none bg-transparent flex-1 text-[14px] text-[#111827] font-medium" />
            </div>
            <div className="h-[48px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 18 }}>store</span>
              <input type="text" placeholder="Business Name" value={addForm.businessName} onChange={e => setAddForm(f => ({ ...f, businessName: e.target.value }))}
                className="border-none outline-none bg-transparent flex-1 text-[14px] text-[#111827] font-medium" />
            </div>
            <div className="h-[48px] rounded-[12px] border-[1.5px] border-[#D1D5DB] bg-white flex items-center px-3.5 gap-2.5 focus-within:border-[#3730A3] transition-all">
              <span className="msr" style={{ color: '#9CA3AF', fontSize: 18 }}>phone</span>
              <input type="text" placeholder="Mobile No" value={addForm.mobileNo} onChange={e => setAddForm(f => ({ ...f, mobileNo: e.target.value }))}
                className="border-none outline-none bg-transparent flex-1 text-[14px] text-[#111827] font-medium" />
            </div>
            <button onClick={handleAddVendor}
              className="w-full h-[48px] rounded-[12px] border-none bg-[#3730A3] text-white font-display font-bold text-[14px] flex items-center justify-center gap-2 cursor-pointer shadow-[0_6px_16px_rgba(55,48,163,.28)] active:scale-[0.98] transition-transform">
              <span className="msr" style={{ fontSize: 18 }}>person_add</span>
              Add Customer
            </button>
          </div>
        </div>
      )}

      {/* Customer List */}
      <div className="flex flex-col gap-2.5 px-4 pb-2">
        {loading ? (
          [1,2,3,4,5].map(i => <div key={i} className="h-[88px] bg-white border border-[#E5E7EB] rounded-[16px] animate-pulse" />)
        ) : vendorList.length === 0 ? (
          <div className="text-center py-12">
            <span className="msr" style={{ fontSize: 48, color: '#D1D5DB' }}>groups</span>
            <div className="text-[13px] text-[#9CA3AF] font-semibold mt-2">No customers found</div>
          </div>
        ) : vendorList.map(v => (
          <div key={v.id} className="bg-white border border-[#E5E7EB] rounded-[16px] overflow-hidden relative"
            style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#D97706]" />
            <div className="px-3.5 py-3 pl-[17px]">
              <div className="flex items-start justify-between gap-2.5">
                <div>
                  <div className="font-display text-[15px] font-bold text-[#111827]">{v.businessName}</div>
                  <div className="flex items-center gap-1.5 text-[11.5px] text-[#6B7280] font-medium mt-0.5">
                    <span className="msr" style={{ fontSize: 13 }}>badge</span>
                    {v.code}
                  </div>
                  <div className="flex items-center gap-1.5 text-[11.5px] text-[#6B7280] font-medium mt-0.5">
                    <span className="msr" style={{ fontSize: 13 }}>phone</span>
                    {v.mobileNo}
                  </div>
                </div>
                <button onClick={() => handleDeleteVendor(v.id)} className="w-9 h-9 rounded-full bg-[#FEE2E2] flex items-center justify-center border-none cursor-pointer">
                  <span className="msr" style={{ color: '#DC2626', fontSize: 18 }}>delete</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add FAB override — show add form instead of navigate */}
      {!showAdd && (
        <button onClick={() => setShowAdd(true)}
          className="fixed right-4 z-30 w-14 h-14 rounded-[16px] bg-[#3730A3] text-white border-none shadow-[0_4px_12px_rgba(17,24,39,.10),0_2px_4px_rgba(17,24,39,.04)] flex items-center justify-center cursor-pointer active:scale-94 transition-transform"
          style={{ bottom: 'calc(64px + 16px)' }}>
          <span className="msr">person_add</span>
        </button>
      )}
    </div>
  )
}

// Mobile Profile Page — Material Design
export function MobileProfilePage() {
  const { currentUser, logout } = useAppStore()
  const role = currentUser?.role || 'user'
  const isMaster = role === 'super'
  const isManager = role === 'manager'
  const isMasterOrManager = isMaster || isManager
  const { setCurrentPage } = useAppStore()

  // Master-only system management items
  const masterMenuItems = [
    { icon: 'shield_person', label: 'Users', page: 'sys-mgmt-users' as PageName, desc: 'Manage users & permissions' },
    { icon: 'map', label: 'Market Permissions', page: 'sys-mgmt-markets' as PageName, desc: 'Assign market access' },
    { icon: 'history', label: 'User Activity', page: 'sys-mgmt-activity' as PageName, desc: 'Track user actions' },
    { icon: 'lock', label: 'Locked Users', page: 'sys-mgmt-locked' as PageName, desc: 'View locked accounts' },
    { icon: 'warning', label: 'Parser Exceptions', page: 'sys-mgmt-parser-ex' as PageName, desc: 'Review parse errors' },
    { icon: 'bar_chart', label: 'Chart Revisions', page: 'sys-mgmt-chart-revs' as PageName, desc: 'View chart history' },
    { icon: 'person_add', label: 'Pending Signups', page: 'sys-mgmt-pending' as PageName, desc: 'Approve or reject signups' },
  ]

  // Shared items for Master + Manager
  const sharedMenuItems = [
    { icon: 'tune', label: 'Parser Configuration', page: 'sys-mgmt-parser-cfg' as PageName, desc: 'Configure parser rules' },
    { icon: 'percent', label: 'Agent Commission', page: 'agent-commission' as PageName, desc: 'Deposit commissions & payouts' },
    { icon: isMaster ? 'settings' : 'store', label: isMaster ? 'Markets' : 'Settings', page: 'configure' as PageName, desc: isMaster ? 'System configuration' : 'Application settings' },
  ]

  // Manager-specific items
  const managerMenuItems = [
    { icon: 'group', label: 'My Agents', page: 'hierarchy-agents' as PageName, desc: 'View & manage agents' },
    { icon: 'groups', label: 'My Customers', page: 'hierarchy-customers' as PageName, desc: 'View customer list' },
  ]

  // Agent-specific items
  const agentMenuItems = [
    { icon: 'groups', label: 'My Customers', page: 'hierarchy-customers' as PageName, desc: 'View customer list' },
    { icon: 'percent', label: 'My Commission', page: 'agent-commission' as PageName, desc: 'Commission on customer deposits' },
    { icon: 'credit_card', label: 'My Subscription', page: 'sub-users' as PageName, desc: 'View subscription details' },
  ]

  // Subscription items (shared) — Plan management filtered by RBAC matrix;
  // agents keep only "My Subscription" (operator rule #3, access-control.ts).
  const subscriptionMenuItems = [
    ...(canAccessPage(role, 'sub-plans' as PageName) ? [{ icon: 'loyalty', label: 'Subscription Plans', page: 'sub-plans' as PageName, desc: 'View available plans' }] : []),
    ...(isMaster ? [{ icon: 'payments', label: 'Payments', page: 'sub-payments' as PageName, desc: 'View payment records' }] : []),
    ...(isManager ? [{ icon: 'payments', label: 'Payments', page: 'sub-payments' as PageName, desc: 'View payment records' }] : []),
  ]

  // WhatsApp Management panel (master + manager; agents have no WhatsApp
  // access per the operator's RBAC rules).
  const whatsAppMenuItems = [
    { icon: 'forum', label: 'WhatsApp Dashboard', page: 'wa-dashboard' as PageName, desc: 'Channel overview & bot insights' },
    { icon: 'chat', label: 'Messages', page: 'wa-messages' as PageName, desc: 'Per-customer conversations' },
    { icon: 'description', label: 'Templates', page: 'wa-templates' as PageName, desc: 'Utility / marketing / authentication' },
    { icon: 'fact_check', label: 'Approvals', page: 'wa-approvals' as PageName, desc: 'Approve or reject vyapar' },
    { icon: 'school', label: 'Bot Learning', page: 'wa-learning' as PageName, desc: 'Teach the parser new patterns' },
    { icon: 'group_add', label: 'Group Mapping', page: 'wa-mappings' as PageName, desc: 'Group ID → customer' },
  ].filter(item => canAccessPage(role, item.page))

  const renderMenuSection = (title: string, items: Array<{ icon: string; label: string; page: PageName; desc: string }>) => (
    <div className="px-4 pt-2 pb-1">
      <div className="font-display text-[12px] font-bold text-[#9CA3AF] uppercase tracking-wider px-1 mb-2">{title}</div>
      <div className="flex flex-col gap-2">
        {items.map(item => (
          <button key={item.page + item.label} onClick={() => setCurrentPage(item.page)}
            className="bg-white border border-[#E5E7EB] rounded-[16px] px-4 py-3 flex items-center gap-3 text-left w-full cursor-pointer active:scale-[0.99] transition-transform"
            style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
            <div className="w-10 h-10 rounded-[12px] bg-[#E8EAF6] flex items-center justify-center">
              <span className="msr" style={{ color: '#3730A3', fontSize: 20 }}>{item.icon}</span>
            </div>
            <div className="flex-1">
              <div className="font-display text-[14px] font-bold text-[#111827]">{item.label}</div>
              <div className="text-[11.5px] text-[#6B7280] font-medium">{item.desc}</div>
            </div>
            <span className="msr" style={{ color: '#9CA3AF', fontSize: 20 }}>chevron_right</span>
          </button>
        ))}
      </div>
    </div>
  )

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Profile Header */}
      <div className="px-4 pt-4 pb-3">
        <div className="bg-white border border-[#E5E7EB] rounded-[16px] p-4" style={{ boxShadow: '0 1px 3px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04)' }}>
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center font-display font-bold text-[18px] text-white ${isMaster ? 'bg-gradient-to-br from-[#D97706] to-[#92400E]' : isManager ? 'bg-gradient-to-br from-[#7C3AED] to-[#5B21B6]' : 'bg-gradient-to-br from-[#0284C7] to-[#2563eb]'}`}>
              {currentUser?.name?.[0] || 'U'}
            </div>
            <div>
              <div className="font-display text-[16px] font-bold text-[#111827]">{currentUser?.name || 'Admin'}</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`inline-flex items-center gap-1 text-[10.5px] font-bold font-display px-2 py-0.5 rounded-full ${isMaster ? 'bg-[#FEF3C7] text-[#92400E]' : isManager ? 'bg-[#EDE9FE] text-[#7C3AED]' : 'bg-[#E0F2FE] text-[#0284C7]'}`}>
                  <span className="msr" style={{ fontSize: 12 }}>{isMaster ? 'admin_panel_settings' : isManager ? 'supervisor_account' : 'person'}</span>
                  {isMaster ? 'Super Admin' : isManager ? 'Admin' : 'Agent'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Role-specific menus */}
      {isMaster && renderMenuSection('System Management', masterMenuItems)}
      {isManager && renderMenuSection('My Team', managerMenuItems)}
      {role === 'user' && renderMenuSection('My Account', agentMenuItems)}
      {isMasterOrManager && renderMenuSection('Configuration', sharedMenuItems)}
      {(isMaster || isManager) && renderMenuSection('Subscription', subscriptionMenuItems)}
      {whatsAppMenuItems.length > 0 && renderMenuSection('WhatsApp', whatsAppMenuItems)}

      {/* Logout */}
      <div className="px-4 pt-4 pb-2">
        <button onClick={logout}
          className="w-full h-[52px] rounded-[12px] border border-[#FCA5A5] bg-[#FEF2F2] text-[#DC2626] font-display font-bold text-[14.5px] flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98] transition-transform">
          <span className="msr" style={{ fontSize: 20 }}>logout</span>
          Sign Out
        </button>
      </div>
    </div>
  )
}

// ────────────────────────────────────────
// SUBSCRIPTION & PAYMENT PAGES
// ────────────────────────────────────────

// ── Paywall Page (shown to non-subscribed users) ──
