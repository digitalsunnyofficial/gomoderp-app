'use client'

// ──────────────────────────────────────────────────────────
// APP MANAGEMENT PANELS (ERP side)
//   AppCustomersPage  — customer app users, wallet ops, flags
//   AppBidsPage       — all app bids + Declare Result & settle
//   FundRequestsPage  — deposit approvals + withdrawal payouts
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { SectionCard, GoldButton, OutlineButton } from '@/components/shared-ui'
import { Modal } from '@/components/shared-ui'
import {
  Smartphone, Users, Receipt, Wallet, Trophy, AlertTriangle, Check, X, Eye,
  TrendingUp, TrendingDown, RefreshCw, IndianRupee, Ban, PlusCircle, BarChart3,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { istDate } from '@/lib/matka/app-engine'

const inr = (n: number | null | undefined) => '₹' + Number(n || 0).toLocaleString('en-IN')
const dt = (v: string | null | undefined) => v ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('success') || message.includes('approved') || message.includes('declared') || message.includes('Adjusted') || message.includes('paid') || message.includes('rejected') || message.includes('Updated')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

const chip = (label: string, tone: 'grn' | 'red' | 'gray' | 'gold' | 'orange' | 'teal') => {
  const tones: Record<string, string> = {
    grn: 'bg-emerald-100 text-emerald-700', red: 'bg-red-100 text-red-700',
    gray: 'bg-slate-100 text-slate-600', gold: 'bg-amber-100 text-amber-700',
    orange: 'bg-orange-100 text-orange-700', teal: 'bg-teal-100 text-teal-700',
  }
  return <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${tones[tone]}`}>{label}</span>
}

// ══════════════════════════════════════════════════════════
// APP CUSTOMERS
// ══════════════════════════════════════════════════════════
interface AppCustomerRow {
  id: string; name: string; mobile: string; wallet: number
  status: string; canBet: boolean; canWithdraw: boolean
  createdAt: string; lastLoginAt: string | null
  betsCount: number; totalStaked: number; totalWon: number
  pendingFunds: number; pendingWithdraws: number
}

export function AppCustomersPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [rows, setRows] = useState<AppCustomerRow[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [message, setMessage] = useState('')
  const [adjust, setAdjust] = useState<AppCustomerRow | null>(null)
  const [adjAmount, setAdjAmount] = useState('')
  const [adjRemark, setAdjRemark] = useState('')

  const load = useCallback(() => {
    setLoading(true)
    apiFetch('/api/app-admin/customers?search=' + encodeURIComponent(search))
      .then((d: { customers: AppCustomerRow[] }) => { setRows(d.customers); setLoading(false) })
      .catch(e => { setMessage(e instanceof Error ? e.message : 'Failed to load'); setLoading(false) })
  }, [search])
  useEffect(() => { load() }, [load])

  const patch = async (id: string, data: Record<string, unknown>) => {
    try {
      await apiFetch('/api/app-admin/customers', { method: 'PATCH', body: JSON.stringify({ id, ...data }) })
      setMessage('Customer updated successfully')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const submitAdjust = async () => {
    if (!adjust) return
    const amt = Number(adjAmount)
    if (!Number.isFinite(amt) || amt === 0) { setMessage('Enter a non-zero amount (+ credit / − debit)'); return }
    try {
      await apiFetch('/api/app-admin/customers', {
        method: 'POST', body: JSON.stringify({ id: adjust.id, amount: amt, remark: adjRemark || 'manual adjustment' }),
      })
      setMessage('Adjusted ' + inr(amt) + ' for ' + adjust.name + ' — success')
      setAdjust(null); setAdjAmount(''); setAdjRemark('')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <Smartphone size={22} className="text-indigo-600" /> App Customers
          </h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Customers registered from the Satta Matka God app — wallets, flags and status</p>
        </div>
        <div className="flex gap-2">
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search name / mobile"
            className="text-[12px] border border-slate-200 rounded-lg px-3 py-2 w-[220px] outline-none focus:border-indigo-400"
          />
          <button onClick={load} className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" aria-label="Refresh">
            <RefreshCw size={15} className="text-slate-500" />
          </button>
        </div>
      </div>

      <Msg message={message} />

      <SectionCard title={`Customers (${rows.length})`}>
        {loading ? <p className="text-[12px] text-slate-400 py-4">Loading…</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wide text-slate-400 border-b border-slate-100">
                  <th className="py-2 pr-3">Customer</th>
                  <th className="py-2 pr-3">Wallet</th>
                  <th className="py-2 pr-3">Bids</th>
                  <th className="py-2 pr-3">Staked</th>
                  <th className="py-2 pr-3">Won</th>
                  <th className="py-2 pr-3">Flags</th>
                  <th className="py-2 pr-3">Last Login</th>
                  {isSuper ? <th className="py-2">Actions</th> : null}
                </tr>
              </thead>
              <tbody>
                {rows.map(c => (
                  <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold text-slate-800">{c.name}</div>
                      <div className="text-[10.5px] text-slate-400 mono">{c.mobile}</div>
                    </td>
                    <td className="py-2.5 pr-3 font-bold text-slate-700">{inr(c.wallet)}</td>
                    <td className="py-2.5 pr-3 text-slate-600">{c.betsCount}</td>
                    <td className="py-2.5 pr-3 text-slate-600">{inr(c.totalStaked)}</td>
                    <td className="py-2.5 pr-3 text-emerald-700 font-semibold">{c.totalWon ? inr(c.totalWon) : '—'}</td>
                    <td className="py-2.5 pr-3">
                      <div className="flex gap-1 flex-wrap">
                        {chip(c.status, c.status === 'active' ? 'grn' : 'red')}
                        {chip(c.canBet ? 'Betting On' : 'Betting Off', c.canBet ? 'teal' : 'red')}
                        {chip(c.canWithdraw ? 'W/D On' : 'W/D Off', c.canWithdraw ? 'teal' : 'red')}
                        {c.pendingFunds > 0 ? chip(c.pendingFunds + ' deposit req', 'gold') : null}
                        {c.pendingWithdraws > 0 ? chip(c.pendingWithdraws + ' w/d req', 'orange') : null}
                      </div>
                    </td>
                    <td className="py-2.5 pr-3 text-slate-500 text-[11px]">{c.lastLoginAt ? dt(c.lastLoginAt) : 'never'}</td>
                    {isSuper ? (
                      <td className="py-2.5">
                        <div className="flex gap-1.5 flex-wrap">
                          <button
                            onClick={() => patch(c.id, { status: c.status === 'active' ? 'blocked' : 'active' })}
                            className={`text-[10.5px] font-bold px-2 py-1 rounded-md border ${c.status === 'active' ? 'border-red-200 text-red-600 hover:bg-red-50' : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'}`}
                          >
                            {c.status === 'active' ? <Ban size={12} className="inline mr-1" /> : <Check size={12} className="inline mr-1" />}
                            {c.status === 'active' ? 'Block' : 'Unblock'}
                          </button>
                          <button
                            onClick={() => patch(c.id, { canBet: !c.canBet })}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
                          >
                            Betting {c.canBet ? 'Off' : 'On'}
                          </button>
                          <button
                            onClick={() => patch(c.id, { canWithdraw: !c.canWithdraw })}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
                          >
                            W/D {c.canWithdraw ? 'Off' : 'On'}
                          </button>
                          <button
                            onClick={() => setAdjust(c)}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md bg-indigo-600 text-white hover:bg-indigo-700 inline-flex items-center gap-1"
                          >
                            <IndianRupee size={12} /> Adjust
                          </button>
                        </div>
                      </td>
                    ) : null}
                  </tr>
                ))}
                {!rows.length ? <tr><td colSpan={8} className="py-6 text-center text-slate-400">No app customers yet — signups will appear here.</td></tr> : null}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>

      <Modal open={!!adjust} onClose={() => setAdjust(null)} title={'Adjust Wallet — ' + (adjust?.name || '')}>
        <p className="text-[12px] text-slate-500 mb-3">
          Current wallet: <b className="text-slate-800">{inr(adjust?.wallet)}</b> · Use a negative amount to debit.
        </p>
        <div className="grid grid-cols-1 gap-3">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Amount (+ credit / − debit)</label>
            <input value={adjAmount} onChange={e => setAdjAmount(e.target.value)} type="number" placeholder="e.g. 500 or -200"
              className="mt-1 w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400" />
          </div>
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Remark</label>
            <input value={adjRemark} onChange={e => setAdjRemark(e.target.value)} placeholder="reason (shown in customer ledger)"
              className="mt-1 w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400" />
          </div>
          <GoldButton onClick={submitAdjust}>Apply Adjustment</GoldButton>
        </div>
      </Modal>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// APP BIDS + RESULT DECLARATION
// ══════════════════════════════════════════════════════════
interface AppBetRow {
  id: string; customerId: string; customerName: string; customerMobile: string
  marketCode: string; marketName: string; betDate: string; slot: string
  type: string; num: string; points: number; rate: number; win: number
  status: string; createdAt: string
}

export function AppBidsPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [view, setView] = useState<'bids' | 'charts'>('bids')
  const [rows, setRows] = useState<AppBetRow[]>([])
  const [total, setTotal] = useState(0)
  const [markets, setMarkets] = useState<Array<{ code: string; name: string }>>([])
  const [status, setStatus] = useState('all')
  const [market, setMarket] = useState('')
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [declareOpen, setDeclareOpen] = useState(false)
  const [dMarket, setDMarket] = useState('')
  const [dDate, setDDate] = useState(istDate())
  const [dOpen, setDOpen] = useState('')
  const [dClose, setDClose] = useState('')
  const [summary, setSummary] = useState<string>('')

  const load = useCallback(() => {
    setLoading(true)
    apiFetch(`/api/app-admin/bets?status=${status}&market=${market}`)
      .then((d: { bets: AppBetRow[]; total: number; markets: Array<{ code: string; name: string }> }) => {
        setRows(d.bets); setTotal(d.total); setMarkets(d.markets); setLoading(false)
      })
      .catch(e => { setMessage(e instanceof Error ? e.message : 'Failed to load'); setLoading(false) })
  }, [status, market])
  useEffect(() => { load() }, [load])

  const declare = async () => {
    try {
      const d = await apiFetch('/api/app-admin/results', {
        method: 'POST',
        body: JSON.stringify({ marketCode: dMarket, resultDate: dDate, openPanna: dOpen || undefined, closePanna: dClose || undefined }),
      }) as { settlement: { considered: number; won: number; lost: number; skipped: number; totalWin: number } }
      const s = d.settlement
      setSummary(`Result declared — success. Bids considered: ${s.considered} · won: ${s.won} · lost: ${s.lost} · still pending (close not declared): ${s.skipped} · winnings paid: ${inr(s.totalWin)}`)
      setDeclareOpen(false); setDOpen(''); setDClose('')
      load()
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Failed to declare')
    }
  }

  const stChip = (s: string) => s === 'won' ? chip('WON', 'grn') : s === 'lost' ? chip('LOST', 'gray') : chip('PENDING', 'orange')

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
            <Receipt size={22} className="text-indigo-600" /> App Bids
          </h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Vyapar placed by customers from the Satta Matka God app ({total} total)</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setView('bids')} className={`text-[12px] font-bold px-4 py-2 rounded-lg border ${view === 'bids' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>Bid List</button>
          <button onClick={() => setView('charts')} className={`text-[12px] font-bold px-4 py-2 rounded-lg border ${view === 'charts' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>Market Charts</button>
          {isSuper && view === 'bids' ? (
            <GoldButton onClick={() => { setSummary(''); setDeclareOpen(true) }}>Declare Result &amp; Settle</GoldButton>
          ) : null}
        </div>
      </div>

      {view === 'charts' ? <MarketChartsPanel /> : (
      <>
      <Msg message={message} />
      {summary ? (
        <div className="bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)] text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2">
          <Trophy size={14} /> {summary}
        </div>
      ) : null}

      <div className="flex gap-2 mb-4 flex-wrap">
        <select value={status} onChange={e => setStatus(e.target.value)}
          className="text-[12px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400">
          <option value="all">All statuses</option>
          <option value="pending">Pending</option>
          <option value="won">Won</option>
          <option value="lost">Lost</option>
        </select>
        <select value={market} onChange={e => setMarket(e.target.value)}
          className="text-[12px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400">
          <option value="">All markets</option>
          {markets.map(m => <option key={m.code} value={m.code}>{m.name}</option>)}
        </select>
        <button onClick={load} className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" aria-label="Refresh">
          <RefreshCw size={15} className="text-slate-500" />
        </button>
      </div>

      <SectionCard title={`Bids (${rows.length} shown)`}>
        {loading ? <p className="text-[12px] text-slate-400 py-4">Loading…</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wide text-slate-400 border-b border-slate-100">
                  <th className="py-2 pr-3">Customer</th>
                  <th className="py-2 pr-3">Market</th>
                  <th className="py-2 pr-3">Type</th>
                  <th className="py-2 pr-3">Num</th>
                  <th className="py-2 pr-3">Slot</th>
                  <th className="py-2 pr-3">Points</th>
                  <th className="py-2 pr-3">Rate</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2 pr-3">Win</th>
                  <th className="py-2">Placed</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(b => (
                  <tr key={b.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold text-slate-800">{b.customerName}</div>
                      <div className="text-[10.5px] text-slate-400 mono">{b.customerMobile}</div>
                    </td>
                    <td className="py-2.5 pr-3 text-slate-600">{b.marketName}<div className="text-[10px] text-slate-400">{b.betDate}</div></td>
                    <td className="py-2.5 pr-3 uppercase font-bold text-[10.5px] text-indigo-700">{b.type}</td>
                    <td className="py-2.5 pr-3 mono font-bold text-slate-800">{b.num}</td>
                    <td className="py-2.5 pr-3 text-slate-500">{b.slot}</td>
                    <td className="py-2.5 pr-3 font-semibold">{inr(b.points)}</td>
                    <td className="py-2.5 pr-3 text-slate-500">1:{b.rate}</td>
                    <td className="py-2.5 pr-3">{stChip(b.status)}</td>
                    <td className="py-2.5 pr-3 text-emerald-700 font-semibold">{b.win ? inr(b.win) : '—'}</td>
                    <td className="py-2.5 text-slate-400 text-[11px]">{dt(b.createdAt)}</td>
                  </tr>
                ))}
                {!rows.length ? <tr><td colSpan={10} className="py-6 text-center text-slate-400">No bids found for this filter.</td></tr> : null}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>

      <Modal open={declareOpen} onClose={() => setDeclareOpen(false)} title="Declare Result & Settle Bids" wide>
        <p className="text-[12px] text-slate-500 mb-3">
          Enter the declared panna(s). Winning digits and jodi are derived automatically, all decidable pending bids for the
          market + date are settled and wallets are credited instantly. Declare Open now and Close later if needed.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Market</label>
            <select value={dMarket} onChange={e => setDMarket(e.target.value)}
              className="mt-1 w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400">
              <option value="">Select market…</option>
              {markets.map(m => <option key={m.code} value={m.code}>{m.name}</option>)}
              {Array.from({ length: 24 }, (_, h) => (
                <option key={'st' + h} value={'st' + h}>Starline {String(h).padStart(2, '0')}:00</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Date</label>
            <input type="date" value={dDate} onChange={e => setDDate(e.target.value)}
              className="mt-1 w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400" />
          </div>
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Open Panna (3 digits)</label>
            <input value={dOpen} onChange={e => setDOpen(e.target.value.replace(/\D/g, '').slice(0, 3))} placeholder="e.g. 127"
              className="mt-1 w-full text-[13px] mono border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400" />
          </div>
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Close Panna (optional now)</label>
            <input value={dClose} onChange={e => setDClose(e.target.value.replace(/\D/g, '').slice(0, 3))} placeholder="e.g. 550"
              className="mt-1 w-full text-[13px] mono border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <GoldButton onClick={declare}>Declare &amp; Settle</GoldButton>
          <span className="text-[11px] text-slate-400">Starline: declare the single panna in either field.</span>
        </div>
      </Modal>
      </>
      )}
    </div>
  )
}

// ──────────────────────────────────────────────────────────
// MARKET CHARTS — every app order of a market aggregated into
// an inventory chart; one click copies the WhatsApp-ready text
// so the operator can send the market vyapar to superiors.
// ──────────────────────────────────────────────────────────
interface ChartSection { slot: string; slotLabel: string; types: Array<{ type: string; typeLabel: string; total: number; rows: Array<{ num: string; points: number; count: number }> }> }
interface BoardCell { pos: number; num: string; points: number; count: number }
interface BoardSub { cells: BoardCell[]; total: number }
interface TypeSummaryRow { type: string; typeLabel: string; bids: number; staked: number; won: number; pendingCount: number; pendingPoints: number; net: number }

// One master board: 10 ank columns (1-9, 0) of number + points cells —
// mirrors the WhatsApp-paste grid the operator already knows.
function BoardGrid({ label, sub }: { label: string; sub?: BoardSub }) {
  if (!sub || !sub.cells.length) return null
  const cols: BoardCell[][] = Array.from({ length: 10 }, () => [])
  for (const c of sub.cells) {
    if (c.pos >= 1 && c.pos <= 10) cols[c.pos - 1].push(c)
    else cols[9].push(c)
  }
  return (
    <div className="border border-slate-200 rounded-xl p-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{label}</span>
        <span className="text-[11px] font-bold text-slate-700">{inr(sub.total)} pts</span>
      </div>
      <div className="grid grid-cols-5 md:grid-cols-10 gap-1.5">
        {cols.map((cells, ci) => (
          <div key={ci} className="rounded-lg bg-slate-50 border border-slate-100 p-1.5 min-h-[64px]">
            <div className="text-[10px] font-extrabold text-slate-400 text-center mb-1">{ci === 9 ? '0' : String(ci + 1)}</div>
            {cells.length ? cells.map((c, i) => (
              <div key={i} className="flex items-center justify-between gap-1 px-0.5 py-[1px]">
                <span className="font-mono text-[11px] font-bold text-slate-700">{c.num}</span>
                <span className="text-[10px] font-bold text-indigo-600">{c.points}</span>
              </div>
            )) : <div className="text-center text-[9px] text-slate-300">-</div>}
          </div>
        ))}
      </div>
    </div>
  )
}

export function MarketChartsPanel() {
  const [market, setMarket] = useState('kalyan')
  const [date, setDate] = useState(istDate())
  const [data, setData] = useState<{ market: string; date: string; grandTotal: number; bettorCount: number; bidCount: number; sections: ChartSection[]; whatsappText: string; markets: Array<{ code: string; name: string }>; boards?: { single: { open: BoardSub; close: BoardSub }; double: { jodi: BoardSub }; triple: { open: BoardSub; close: BoardSub } }; typeSummary?: TypeSummaryRow[] } | null>(null)
  const [markets, setMarkets] = useState<Array<{ code: string; name: string }>>([])
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  const load = useCallback(() => {
    setLoading(true)
    apiFetch(`/api/app-admin/market-charts?market=${market}&date=${date}`)
      .then(d => { setData(d as never); setMarkets((d.markets as Array<{ code: string; name: string }>) || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [market, date])
  useEffect(() => { load() }, [load])

  const copyWA = async () => {
    if (!data?.whatsappText) return
    try {
      await navigator.clipboard.writeText(data.whatsappText)
      setCopied(true)
      setTimeout(() => setCopied(false), 2500)
    } catch {
      // clipboard blocked — show the text so the operator can copy manually
      const w = window.open('', '_blank')
      if (w) { w.document.write('<pre style="font:13px monospace;white-space:pre-wrap;padding:16px">' + data.whatsappText.replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c] || c)) + '</pre>'); w.document.close() }
    }
  }

  return (
    <>
      <div className="flex gap-2 mb-4 flex-wrap items-center">
        <select value={market} onChange={e => setMarket(e.target.value)} className="text-[12px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400">
          {markets.map(m => <option key={m.code} value={m.code}>{m.name}</option>)}
        </select>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} className="text-[12px] border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-400" />
        <button onClick={load} className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" aria-label="Refresh"><RefreshCw size={15} className="text-slate-500" /></button>
        {data ? (
          <button onClick={copyWA} className="text-[12px] font-bold px-4 py-2 rounded-lg bg-[#059669] text-white hover:bg-[#047857] inline-flex items-center gap-1.5">
            <BarChart3 size={14} /> {copied ? 'Copied — paste in WhatsApp' : 'Copy WhatsApp Chart'}
          </button>
        ) : null}
      </div>
      {loading ? <p className="text-[12px] text-slate-400 py-4">Loading chart…</p> : data ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            {[
              ['Market', data.market],
              ['Date', data.date],
              ['Bettors / Bids', `${data.bettorCount} / ${data.bidCount}`],
              ['Grand Total', inr(data.grandTotal) + ' pts'],
            ].map(([l, v]) => (
              <div key={l} className="border border-slate-200 rounded-xl p-3 bg-slate-50/60">
                <div className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{l}</div>
                <div className="text-[14px] font-bold text-slate-800 mt-0.5">{v}</div>
              </div>
            ))}
          </div>
          {data.boards ? (
            <SectionCard title={`Master Charts — ${data.market} · ${data.date}`}>
              <p className="text-[11px] text-slate-400 mb-3">Single / Double / Triple master boards — every app order lands here automatically. Pannas aggregate by digit-set (chart spellings 038 / 380 merge) and display in the operator chart spelling.</p>
              <div className="space-y-3">
                {(['open', 'close'] as const).map(sl => (
                  <div key={sl} className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                    <BoardGrid label={`SINGLE · ${sl.toUpperCase()}`} sub={data.boards?.single[sl]} />
                    <BoardGrid label={`TRIPLE · ${sl.toUpperCase()}`} sub={data.boards?.triple[sl]} />
                  </div>
                ))}
                <BoardGrid label="DOUBLE (JODI)" sub={data.boards?.double.jodi} />
              </div>
            </SectionCard>
          ) : null}
          {data.typeSummary && data.typeSummary.length ? (
            <SectionCard title={`Game-Type Win/Loss — ${data.market} · ${data.date}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="text-left text-[10px] uppercase tracking-wide text-slate-400 border-b border-slate-200">
                      <th className="py-2 pr-3">Game Type</th>
                      <th className="py-2 pr-3">Bids</th>
                      <th className="py-2 pr-3">Staked</th>
                      <th className="py-2 pr-3">Won</th>
                      <th className="py-2 pr-3">Pending</th>
                      <th className="py-2 pr-3">Net (Staked - Won)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.typeSummary.map(r => (
                      <tr key={r.type} className="border-b border-slate-100">
                        <td className="py-1.5 pr-3 font-bold text-slate-700">{r.typeLabel}</td>
                        <td className="py-1.5 pr-3">{r.bids}</td>
                        <td className="py-1.5 pr-3">{inr(r.staked)} pts</td>
                        <td className="py-1.5 pr-3 text-emerald-600 font-semibold">{r.won ? inr(r.won) : '-'}</td>
                        <td className="py-1.5 pr-3 text-amber-600">{r.pendingCount ? `${r.pendingCount} bids / ${r.pendingPoints} pts` : '-'}</td>
                        <td className={'py-1.5 pr-3 font-bold ' + (r.net >= 0 ? 'text-emerald-700' : 'text-red-600')}>{inr(r.net)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">Net = points staked minus points paid out on settled bids. Pending bids settle when the result is declared.</p>
            </SectionCard>
          ) : null}
          {data.sections.length ? data.sections.map(s => (
            <SectionCard key={s.slot} title={`${s.slotLabel} — ${data.market} · ${data.date}`}>
              {s.types.map(t => (
                <div key={t.type} className="mb-4 last:mb-0">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[12px] font-bold text-slate-700">{t.typeLabel}</span>
                    <span className="text-[11px] font-bold text-indigo-700">{t.total} pts</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {t.rows.map(r => (
                      <span key={r.num} className="inline-flex items-center gap-1 border border-slate-200 bg-white rounded-lg px-2 py-1">
                        <b className="mono text-[12px] text-slate-800">{r.num}</b>
                        <span className="text-[11px] text-slate-500">{r.points}</span>
                        {r.count > 1 ? <span className="text-[9px] bg-amber-100 text-amber-800 rounded px-1 font-bold">×{r.count}</span> : null}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
              {!s.types.length ? <p className="text-[12px] text-slate-400">No bids in this slot.</p> : null}
            </SectionCard>
          )) : (
            <SectionCard title="No orders">
              <p className="text-[12px] text-slate-400">No app bids for this market on {data.date} yet.</p>
            </SectionCard>
          )}
        </>
      ) : null}
    </>
  )
}
interface FundRow {
  id: string; customerId: string; customerName: string; customerMobile: string; customerWallet: number
  amount: number; method?: string; utr?: string; status: string
  processedBy?: string | null; processedAt?: string | null; note?: string | null; createdAt: string
}
interface WithdrawRow {
  id: string; customerId: string; customerName: string; customerMobile: string; customerWallet: number
  amount: number; status: string; processedBy?: string | null; processedAt?: string | null
  note?: string | null; createdAt: string
}

export function FundRequestsPage() {
  const [tab, setTab] = useState<'deposits' | 'withdrawals' | 'qr'>('deposits')
  const [funds, setFunds] = useState<FundRow[]>([])
  const [withdrawals, setWithdrawals] = useState<WithdrawRow[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')

  const load = useCallback(() => {
    setLoading(true)
    apiFetch('/api/app-admin/funds?status=all')
      .then((d: { funds: FundRow[]; withdrawals: WithdrawRow[] }) => {
        setFunds(d.funds); setWithdrawals(d.withdrawals); setLoading(false)
      })
      .catch(e => { setMessage(e instanceof Error ? e.message : 'Failed to load'); setLoading(false) })
  }, [])
  useEffect(() => { load() }, [load])

  const act = async (api: string, id: string, action: string) => {
    try {
      await apiFetch(api, { method: 'POST', body: JSON.stringify({ id, action }) })
      setMessage('Request ' + action + 'ed — success')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed') }
  }

  const pendingDeposits = funds.filter(f => f.status === 'pending').length
  const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending').length

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Wallet size={22} className="text-indigo-600" /> Payment Management
        </h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Business QR for the customer app (1 point = ₹1) · approve deposits · pay out or refund withdrawals</p>
      </div>

      <Msg message={message} />

      <div className="flex gap-2 mb-4 flex-wrap">
        <button onClick={() => setTab('deposits')}
          className={`text-[12px] font-bold px-4 py-2 rounded-lg border ${tab === 'deposits' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
          Deposits {pendingDeposits ? <span className="ml-1 bg-amber-400 text-amber-900 rounded-full px-1.5 text-[10px]">{pendingDeposits}</span> : null}
        </button>
        <button onClick={() => setTab('withdrawals')}
          className={`text-[12px] font-bold px-4 py-2 rounded-lg border ${tab === 'withdrawals' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
          Withdrawals {pendingWithdrawals ? <span className="ml-1 bg-amber-400 text-amber-900 rounded-full px-1.5 text-[10px]">{pendingWithdrawals}</span> : null}
        </button>
        <button onClick={() => setTab('qr')}
          className={`text-[12px] font-bold px-4 py-2 rounded-lg border ${tab === 'qr' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
          Business QR
        </button>
        <button onClick={load} className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" aria-label="Refresh">
          <RefreshCw size={15} className="text-slate-500" />
        </button>
      </div>

      {tab === 'qr' ? <QrSettingsSection onMessage={setMessage} /> : (
      <SectionCard title={tab === 'deposits' ? `Deposit Requests (${funds.length})` : `Withdrawal Requests (${withdrawals.length})`}>
        {loading ? <p className="text-[12px] text-slate-400 py-4">Loading…</p> : tab === 'deposits' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wide text-slate-400 border-b border-slate-100">
                  <th className="py-2 pr-3">Customer</th>
                  <th className="py-2 pr-3">Amount</th>
                  <th className="py-2 pr-3">Method</th>
                  <th className="py-2 pr-3">UTR</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2 pr-3">Requested</th>
                  <th className="py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {funds.map(f => (
                  <tr key={f.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold text-slate-800">{f.customerName}</div>
                      <div className="text-[10.5px] text-slate-400 mono">{f.customerMobile} · bal {inr(f.customerWallet)}</div>
                    </td>
                    <td className="py-2.5 pr-3 font-bold">{inr(f.amount)}</td>
                    <td className="py-2.5 pr-3 text-slate-500">{f.method}</td>
                    <td className="py-2.5 pr-3 mono text-slate-600">{f.utr}</td>
                    <td className="py-2.5 pr-3">
                      {f.status === 'pending' ? chip('PENDING', 'orange') : f.status === 'approved' ? chip('APPROVED', 'grn') : chip('REJECTED', 'red')}
                    </td>
                    <td className="py-2.5 pr-3 text-slate-400 text-[11px]">{dt(f.createdAt)}</td>
                    <td className="py-2.5">
                      {f.status === 'pending' ? (
                        <div className="flex gap-1.5">
                          <button onClick={() => act('/api/app-admin/funds', f.id, 'approve')}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-1">
                            <TrendingUp size={12} /> Approve
                          </button>
                          <button onClick={() => act('/api/app-admin/funds', f.id, 'reject')}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md border border-red-200 text-red-600 hover:bg-red-50">
                            Reject
                          </button>
                        </div>
                      ) : <span className="text-[10.5px] text-slate-400">by {f.processedBy || '—'}</span>}
                    </td>
                  </tr>
                ))}
                {!funds.length ? <tr><td colSpan={7} className="py-6 text-center text-slate-400">No deposit requests yet.</td></tr> : null}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wide text-slate-400 border-b border-slate-100">
                  <th className="py-2 pr-3">Customer</th>
                  <th className="py-2 pr-3">Amount</th>
                  <th className="py-2 pr-3">Wallet (after hold)</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2 pr-3">Requested</th>
                  <th className="py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {withdrawals.map(w => (
                  <tr key={w.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold text-slate-800">{w.customerName}</div>
                      <div className="text-[10.5px] text-slate-400 mono">{w.customerMobile}</div>
                    </td>
                    <td className="py-2.5 pr-3 font-bold">{inr(w.amount)}</td>
                    <td className="py-2.5 pr-3 text-slate-600">{inr(w.customerWallet)}</td>
                    <td className="py-2.5 pr-3">
                      {w.status === 'pending' ? chip('ON HOLD', 'orange') : w.status === 'paid' ? chip('PAID', 'grn') : chip('REJECTED', 'red')}
                    </td>
                    <td className="py-2.5 pr-3 text-slate-400 text-[11px]">{dt(w.createdAt)}</td>
                    <td className="py-2.5">
                      {w.status === 'pending' ? (
                        <div className="flex gap-1.5">
                          <button onClick={() => act('/api/app-admin/withdrawals', w.id, 'paid')}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-1">
                            <Check size={12} /> Mark Paid
                          </button>
                          <button onClick={() => act('/api/app-admin/withdrawals', w.id, 'reject')}
                            className="text-[10.5px] font-bold px-2 py-1 rounded-md border border-red-200 text-red-600 hover:bg-red-50">
                            Reject &amp; Refund
                          </button>
                        </div>
                      ) : <span className="text-[10.5px] text-slate-400">by {w.processedBy || '—'}</span>}
                    </td>
                  </tr>
                ))}
                {!withdrawals.length ? <tr><td colSpan={6} className="py-6 text-center text-slate-400">No withdrawal requests yet.</td></tr> : null}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>
      )}
    </div>
  )
}

// ──────────────────────────────────────────────────────────
// BUSINESS QR SETTINGS — upload/update the UPI QR shown in
// the customer app deposit screen. 1 point = ₹1.
// ──────────────────────────────────────────────────────────
interface PaySettings { upiId: string; payeeName: string; qrImage: string; note: string; minDeposit: number; autoCredit?: boolean; autoVerifySecret?: string; autoCreditWindowMin?: number; updatedAt?: string; updatedBy?: string | null }

export function QrSettingsSection({ onMessage }: { onMessage: (m: string) => void }) {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const [s, setS] = useState<PaySettings | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(() => {
    apiFetch('/api/app-admin/payment-settings')
      .then(d => setS(d.settings as PaySettings))
      .catch(e => onMessage(e instanceof Error ? e.message : 'Failed to load QR settings'))
  }, [onMessage])
  useEffect(() => { load() }, [load])

  const onFile = (file: File) => {
    if (file.size > 1_500_000) { onMessage('QR image too large — keep it under 1.5 MB'); return }
    const reader = new FileReader()
    reader.onload = () => setS(prev => prev ? { ...prev, qrImage: String(reader.result) } : prev)
    reader.readAsDataURL(file)
  }

  const save = async () => {
    if (!s) return
    setBusy(true)
    try {
      await apiFetch('/api/app-admin/payment-settings', {
        method: 'POST',
        body: JSON.stringify({ upiId: s.upiId, payeeName: s.payeeName, qrImage: s.qrImage, note: s.note, minDeposit: s.minDeposit, autoCredit: s.autoCredit, autoVerifySecret: s.autoVerifySecret, autoCreditWindowMin: s.autoCreditWindowMin }),
      })
      onMessage('Payment settings saved — the app picks them up without any refresh')
      load()
    } catch (e) { onMessage(e instanceof Error ? e.message : 'Failed to save') } finally { setBusy(false) }
  }

  if (!s) return <p className="text-[12px] text-slate-400 py-4">Loading QR settings…</p>
  return (
    <SectionCard title="Business UPI QR — Customer App Deposit">
      <p className="text-[12px] text-slate-500 mb-4">Customers open any UPI app (GPay / PhonePe / Paytm / BHIM), scan this QR, pay, then submit the UTR in the app. You approve under Deposits and the points are credited automatically — <b>1 point = ₹1</b>. Update the QR anytime; the app picks it up without any refresh.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div>
          <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 flex flex-col items-center gap-3 bg-slate-50/60">
            {s.qrImage ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={s.qrImage} alt="Business QR" className="w-44 h-44 object-contain rounded-lg border border-slate-200 bg-white" />
            ) : (
              <div className="w-44 h-44 rounded-lg border border-slate-200 bg-white grid place-items-center text-[11px] text-slate-400">No QR uploaded yet</div>
            )}
            {isSuper ? (
              <label className="text-[11.5px] font-bold px-3 py-2 rounded-lg bg-indigo-600 text-white cursor-pointer hover:bg-indigo-700 inline-flex items-center gap-1.5">
                <PlusCircle size={13} /> {s.qrImage ? 'Replace QR Image' : 'Upload QR Image'}
                <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f) }} />
              </label>
            ) : null}
          </div>
        </div>
        <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] block mb-1.5">UPI ID</label>
            <input value={s.upiId} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, upiId: e.target.value } : p)} placeholder="business@upi" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-indigo-500 mono" />
          </div>
          <div>
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] block mb-1.5">Payee Name</label>
            <input value={s.payeeName} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, payeeName: e.target.value } : p)} placeholder="e.g. MAIN BAZAAR" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-indigo-500" />
          </div>
          <div>
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] block mb-1.5">Minimum Deposit (₹)</label>
            <input type="number" min={1} value={s.minDeposit} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, minDeposit: Number(e.target.value) } : p)} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-indigo-500" />
          </div>
          <div className="md:col-span-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] block mb-1.5">Note Shown In App</label>
            <input value={s.note} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, note: e.target.value } : p)} placeholder="e.g. Pay & submit UTR — credited after check" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-indigo-500" />
          </div>
          <div className="md:col-span-2 border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <div className="flex items-center justify-between gap-3 mb-2">
              <b className="text-[13px] text-slate-800">UPI Auto-Credit (auto capture)</b>
              <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                <input type="checkbox" checked={!!s.autoCredit} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, autoCredit: e.target.checked } : p)} className="w-4 h-4 accent-indigo-600" />
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${s.autoCredit ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-500'}`}>{s.autoCredit ? 'ON' : 'OFF'}</span>
              </label>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">When ON, every business-UPI credit reported to <b className="mono">POST /api/upi/auto-verify</b> (payment-watch automation on your phone, or a gateway webhook) is matched against pending deposits and the wallet is credited automatically — no manual UTR checking. Strongest match: UTR / the app&apos;s <span className="mono">SMG…</span> payment note; fallback: exact amount within the window.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] block mb-1.5">Webhook Secret</label>
                <input value={s.autoVerifySecret || ''} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, autoVerifySecret: e.target.value } : p)} placeholder="e.g. smg_webhook_2026" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-indigo-500 mono" />
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF] block mb-1.5">Match Window (minutes)</label>
                <input type="number" min={1} max={720} value={s.autoCreditWindowMin ?? 30} disabled={!isSuper} onChange={e => setS(p => p ? { ...p, autoCreditWindowMin: Number(e.target.value) } : p)} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-indigo-500" />
              </div>
              <div className="text-[11px] text-slate-500 self-end pb-1">Feed JSON: <span className="mono">{'{ secret, amount, utr?, note?, source? }'}</span> — unmatched credits are simply ignored (manual approval still works).</div>
            </div>
          </div>
          <div className="md:col-span-2 flex items-center justify-between gap-3">
            <span className="text-[11px] text-slate-400">{s.updatedAt ? `Last updated ${dt(s.updatedAt)}${s.updatedBy ? ' by ' + s.updatedBy : ''}` : 'Never updated'}</span>
            {isSuper ? <GoldButton onClick={save} disabled={busy}><Check size={14} /> {busy ? 'Saving…' : 'Save QR Settings'}</GoldButton> : null}
          </div>
        </div>
      </div>
    </SectionCard>
  )
}
