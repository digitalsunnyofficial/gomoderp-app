'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { formatDateTime } from '@/lib/format'
import { ChevronRight, ChevronDown, Users, UserCircle, Shield, Crown, Phone, Mail, Lock, Unlock, Trash2, Edit3, X, Check, AlertTriangle } from 'lucide-react'

// ────────────────────────────────────────
// MANAGER LIST — shows managers + their agents, with lock/delete
// ────────────────────────────────────────
export function HierarchyManagersPage() {
  const { currentUser } = useAppStore()
  const [allUsers, setAllUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedManager, setExpandedManager] = useState<string | null>(null)
  const [lockModal, setLockModal] = useState<{ show: boolean; user: any }>({ show: false, user: null })
  const [lockReason, setLockReason] = useState('')
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [message, setMessage] = useState('')

  const fetchUsers = useCallback(() => {
    setLoading(true)
    apiFetch('/api/users')
      .then((users: any[]) => { setAllUsers(users); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  useEffect(() => { fetchUsers() }, [fetchUsers])

  const managers = allUsers.filter((u: any) => u.role === 'manager')
  const agents = allUsers.filter((u: any) => u.role === 'user')

  const getAgentsForManager = (managerId: string) =>
    agents.filter((a: any) => a.managerId === managerId)

  const toggleExpand = (id: string) =>
    setExpandedManager(prev => prev === id ? null : id)

  const handleLock = async (user: any) => {
    setLockModal({ show: true, user })
    setLockReason('')
  }

  const confirmLock = async () => {
    if (!lockModal.user) return
    setActionLoading(lockModal.user.id)
    try {
      await apiFetch(`/api/users/${lockModal.user.id}/lock`, {
        method: 'POST',
        body: JSON.stringify({ reason: lockReason || 'Locked by admin' })
      })
      setMessage(`${lockModal.user.name || lockModal.user.username} has been locked`)
      setLockModal({ show: false, user: null })
      fetchUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Lock failed')
    }
    setActionLoading(null)
  }

  const handleUnlock = async (userId: string) => {
    setActionLoading(userId)
    try {
      await apiFetch(`/api/users/${userId}/lock`, { method: 'DELETE' })
      setMessage('User unlocked successfully')
      fetchUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Unlock failed')
    }
    setActionLoading(null)
  }

  const handleDelete = async (user: any) => {
    if (!confirm(`Are you sure you want to delete ${user.name || user.username}? This action cannot be undone.`)) return
    setActionLoading(user.id)
    try {
      await apiFetch(`/api/users/${user.id}`, { method: 'DELETE' })
      setMessage(`${user.name || user.username} has been deleted`)
      fetchUsers()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Delete failed')
    }
    setActionLoading(null)
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Crown size={22} className="text-indigo-600" /> Admin List
        </h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">All admins and their associated agents</p>
      </div>

      {message && (
        <div className={`${message.includes('success') || message.includes('unlocked') || message.includes('deleted') || message.includes('locked') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
          {message.includes('success') || message.includes('unlocked') || message.includes('deleted') || message.includes('locked') ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : managers.length === 0 ? (
        <div className="text-center py-16 text-slate-400">No managers found</div>
      ) : (
        <div className="space-y-3">
          {managers.map((m: any) => {
            const mAgents = getAgentsForManager(m.id)
            const isExpanded = expandedManager === m.id
            return (
              <div key={m.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                {/* Manager Header */}
                <div
                  className="flex items-center gap-4 p-4 cursor-pointer hover:bg-slate-50 transition"
                  onClick={() => toggleExpand(m.id)}
                >
                  <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm flex-shrink-0">
                    {(m.name || m.username || 'M').substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900">{m.name || m.username}</div>
                    <div className="text-xs text-slate-500 flex items-center gap-3 mt-0.5">
                      <span>@{m.username}</span>
                      {m.email && <span className="flex items-center gap-1"><Mail size={11} />{m.email}</span>}
                      {m.phone && <span className="flex items-center gap-1"><Phone size={11} />{m.phone}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full font-semibold">
                      {mAgents.length} agent{mAgents.length !== 1 ? 's' : ''}
                    </span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${m.isLocked ? 'bg-red-50 text-red-700' : m.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                      {m.isLocked ? 'Locked' : m.status}
                    </span>
                    {isExpanded ? <ChevronDown size={18} className="text-slate-400" /> : <ChevronRight size={18} className="text-slate-400" />}
                  </div>
                </div>

                {/* Expanded: Associated Agents */}
                {isExpanded && (
                  <div className="border-t border-slate-100 bg-slate-50/50">
                    {/* Manager Full Profile */}
                    <div className="px-4 py-3 border-b border-slate-100">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Manager Profile</div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div><span className="text-slate-400">Name:</span> <span className="text-slate-700 font-medium">{m.name || '—'}</span></div>
                        <div><span className="text-slate-400">Email:</span> <span className="text-slate-700 font-medium">{m.email || '—'}</span></div>
                        <div><span className="text-slate-400">Phone:</span> <span className="text-slate-700 font-medium">{m.phone || '—'}</span></div>
                        <div><span className="text-slate-400">Created:</span> <span className="text-slate-700 font-medium">{formatDateTime(m.createdAt)}</span></div>
                        {m.assignedMarkets && <div className="col-span-2 md:col-span-4"><span className="text-slate-400">Markets:</span> <span className="text-slate-700 font-medium">{m.assignedMarkets || 'All'}</span></div>}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="px-4 py-2 border-b border-slate-100 flex items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-2">Actions:</span>
                      {!m.isLocked ? (
                        <button onClick={(e) => { e.stopPropagation(); handleLock(m) }} disabled={actionLoading === m.id}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 font-semibold flex items-center gap-1 disabled:opacity-50">
                          <Lock size={11} /> Lock
                        </button>
                      ) : (
                        <button onClick={(e) => { e.stopPropagation(); handleUnlock(m.id) }} disabled={actionLoading === m.id}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 font-semibold flex items-center gap-1 disabled:opacity-50">
                          <Unlock size={11} /> Unlock
                        </button>
                      )}
                      <button onClick={(e) => { e.stopPropagation(); handleDelete(m) }} disabled={actionLoading === m.id}
                        className="text-[11px] px-2.5 py-1 rounded-lg bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 font-semibold flex items-center gap-1 disabled:opacity-50">
                        <Trash2 size={11} /> Delete
                      </button>
                    </div>

                    {/* Agents List */}
                    <div className="px-4 py-2">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Associated Agents ({mAgents.length})</div>
                    </div>
                    {mAgents.length === 0 ? (
                      <div className="px-4 py-3 text-sm text-slate-400">No agents assigned</div>
                    ) : (
                      <div className="divide-y divide-slate-100">
                        {mAgents.map((a: any) => (
                          <div key={a.id} className="flex items-center gap-3 px-4 py-3">
                            <div className="w-8 h-8 rounded-full bg-violet-100 text-violet-700 flex items-center justify-center font-bold text-[0.65rem] flex-shrink-0">
                              {(a.name || a.username || 'A').substring(0, 2).toUpperCase()}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium text-slate-800">{a.name || a.username}</div>
                              <div className="text-xs text-slate-500">@{a.username}{a.phone ? ` · ${a.phone}` : ''}</div>
                            </div>
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${a.isLocked ? 'bg-red-50 text-red-700' : a.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                              {a.isLocked ? 'Locked' : a.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Lock Modal */}
      {lockModal.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/40" onClick={() => setLockModal({ show: false, user: null })} />
          <div className="relative bg-white rounded-xl p-6 w-96 max-w-[90vw] shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-900">Lock User</h3>
              <button onClick={() => setLockModal({ show: false, user: null })} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>
            <p className="text-sm text-slate-600 mb-3">
              Lock <strong>{lockModal.user?.name || lockModal.user?.username}</strong>? They will not be able to log in.
            </p>
            <textarea
              value={lockReason}
              onChange={e => setLockReason(e.target.value)}
              placeholder="Reason for locking (optional)"
              className="w-full border border-slate-200 rounded-lg p-2.5 text-sm resize-none h-20 outline-none focus:border-indigo-400"
            />
            <div className="flex justify-end gap-2 mt-4">
              <button onClick={() => setLockModal({ show: false, user: null })} className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button onClick={confirmLock} disabled={actionLoading}
                className="px-4 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 font-semibold disabled:opacity-50 flex items-center gap-1">
                <Lock size={14} /> {actionLoading ? '...' : 'Lock'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ────────────────────────────────────────
// AGENT LIST — shows agents under managers + their customers, with lock/delete
// ────────────────────────────────────────
export function HierarchyAgentsPage() {
  const { currentUser } = useAppStore()
  const isMaster = currentUser?.role === 'super'
  const [allUsers, setAllUsers] = useState<any[]>([])
  const [vendors, setVendors] = useState<any[]>([])
  const [appCustomers, setAppCustomers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null)
  const [lockModal, setLockModal] = useState<{ show: boolean; user: any }>({ show: false, user: null })
  const [lockReason, setLockReason] = useState('')
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [message, setMessage] = useState('')

  const fetchData = useCallback(() => {
    setLoading(true)
    Promise.all([
      apiFetch('/api/users'),
      apiFetch('/api/vendors'),
      // App customers carry agentUsername — the app-side half of the
      // agent → customer mapping (ERP vendors use createdBy).
      apiFetch('/api/app-admin/customers').catch(() => ({ customers: [] })),
    ]).then(([users, vends, cust]: any[]) => {
      setAllUsers(users)
      setVendors(vends)
      setAppCustomers(cust?.customers || [])
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  const agents = allUsers.filter((u: any) => u.role === 'user' && u.status !== 'pending_approval' && u.status !== 'rejected')
  const managers = allUsers.filter((u: any) => u.role === 'manager')

  const getManagerForAgent = (agent: any) => {
    if (!agent.managerId) return null
    return managers.find((m: any) => m.id === agent.managerId)
  }

  const getCustomersForAgent = (agentUsername: string) =>
    vendors.filter((v: any) => v.createdBy === agentUsername)

  const getAppCustomersForAgent = (agentUsername: string) =>
    appCustomers.filter((c: any) => c.agentUsername === agentUsername)

  const toggleExpand = (id: string) =>
    setExpandedAgent(prev => prev === id ? null : id)

  const handleLock = async (user: any) => {
    setLockModal({ show: true, user })
    setLockReason('')
  }

  const confirmLock = async () => {
    if (!lockModal.user) return
    setActionLoading(lockModal.user.id)
    try {
      await apiFetch(`/api/users/${lockModal.user.id}/lock`, {
        method: 'POST',
        body: JSON.stringify({ reason: lockReason || 'Locked by admin' })
      })
      setMessage(`${lockModal.user.name || lockModal.user.username} has been locked`)
      setLockModal({ show: false, user: null })
      fetchData()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Lock failed')
    }
    setActionLoading(null)
  }

  const handleUnlock = async (userId: string) => {
    setActionLoading(userId)
    try {
      await apiFetch(`/api/users/${userId}/lock`, { method: 'DELETE' })
      setMessage('User unlocked successfully')
      fetchData()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Unlock failed')
    }
    setActionLoading(null)
  }

  const handleDelete = async (user: any) => {
    if (!confirm(`Are you sure you want to delete ${user.name || user.username}? This action cannot be undone.`)) return
    setActionLoading(user.id)
    try {
      await apiFetch(`/api/users/${user.id}`, { method: 'DELETE' })
      setMessage(`${user.name || user.username} has been deleted`)
      fetchData()
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Delete failed')
    }
    setActionLoading(null)
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Shield size={22} className="text-violet-600" /> Agent List
        </h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">All agents and their associated customers</p>
      </div>

      {message && (
        <div className={`${message.includes('success') || message.includes('unlocked') || message.includes('deleted') || message.includes('locked') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
          {message.includes('success') || message.includes('unlocked') || message.includes('deleted') || message.includes('locked') ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-2 border-violet-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : agents.length === 0 ? (
        <div className="text-center py-16 text-slate-400">No agents found</div>
      ) : (
        <div className="space-y-3">
          {agents.map((a: any) => {
            const manager = getManagerForAgent(a)
            const aCustomers = getCustomersForAgent(a.username)
            const aAppCustomers = getAppCustomersForAgent(a.username)
            const isExpanded = expandedAgent === a.id
            return (
              <div key={a.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                {/* Agent Header */}
                <div
                  className="flex items-center gap-4 p-4 cursor-pointer hover:bg-slate-50 transition"
                  onClick={() => toggleExpand(a.id)}
                >
                  <div className="w-10 h-10 rounded-full bg-violet-100 text-violet-700 flex items-center justify-center font-bold text-sm flex-shrink-0">
                    {(a.name || a.username || 'A').substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900">{a.name || a.username}</div>
                    <div className="text-xs text-slate-500 flex items-center gap-3 mt-0.5">
                      <span>@{a.username}</span>
                      {manager && <span className="flex items-center gap-1"><Crown size={11} className="text-indigo-500" />{manager.name || manager.username}</span>}
                      {a.email && <span className="flex items-center gap-1"><Mail size={11} />{a.email}</span>}
                      {a.phone && <span className="flex items-center gap-1"><Phone size={11} />{a.phone}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full font-semibold">
                      Commission: {typeof a.commissionRate === 'number' ? (a.commissionRate > 0 ? `${a.commissionRate}% (own)` : 'off (own 0%)') : 'global default'}
                    </span>
                    <span className="text-xs bg-sky-50 text-sky-700 px-2.5 py-1 rounded-full font-semibold" title="Customers who joined the app under this agent">
                      {aAppCustomers.length} app · {aCustomers.length} ERP customer{(aAppCustomers.length + aCustomers.length) !== 1 ? 's' : ''}
                    </span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${a.isLocked ? 'bg-red-50 text-red-700' : a.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                      {a.isLocked ? 'Locked' : a.status}
                    </span>
                    {isExpanded ? <ChevronDown size={18} className="text-slate-400" /> : <ChevronRight size={18} className="text-slate-400" />}
                  </div>
                </div>

                {/* Expanded: Agent Profile + Customers + Actions */}
                {isExpanded && (
                  <div className="border-t border-slate-100 bg-slate-50/50">
                    {/* Agent Profile */}
                    <div className="px-4 py-3 border-b border-slate-100">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Agent Profile</div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div><span className="text-slate-400">Name:</span> <span className="text-slate-700 font-medium">{a.name || '—'}</span></div>
                        <div><span className="text-slate-400">Manager:</span> <span className="text-slate-700 font-medium">{manager?.name || manager?.username || 'Unassigned'}</span></div>
                        <div><span className="text-slate-400">Phone:</span> <span className="text-slate-700 font-medium">{a.phone || '—'}</span></div>
                        <div><span className="text-slate-400">Created:</span> <span className="text-slate-700 font-medium">{formatDateTime(a.createdAt)}</span></div>
                        <div><span className="text-slate-400">Commission:</span> <span className="text-slate-700 font-medium">{typeof a.commissionRate === 'number' ? (a.commissionRate > 0 ? `${a.commissionRate}% on customer play (own rate)` : 'off (own 0%)') : 'global default rate'}</span></div>
                        <div><span className="text-slate-400">App customers:</span> <span className="text-slate-700 font-medium">{aAppCustomers.length} joined via app{aAppCustomers.length ? ` (${aAppCustomers.slice(0, 3).map((c: any) => c.name).join(', ')}${aAppCustomers.length > 3 ? '…' : ''})` : ''}</span></div>
                      </div>
                    </div>

                    {/* Actions (Master only) */}
                    {isMaster && (
                      <div className="px-4 py-2 border-b border-slate-100 flex items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-2">Actions:</span>
                        {!a.isLocked ? (
                          <button onClick={(e) => { e.stopPropagation(); handleLock(a) }} disabled={actionLoading === a.id}
                            className="text-[11px] px-2.5 py-1 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 font-semibold flex items-center gap-1 disabled:opacity-50">
                            <Lock size={11} /> Lock
                          </button>
                        ) : (
                          <button onClick={(e) => { e.stopPropagation(); handleUnlock(a.id) }} disabled={actionLoading === a.id}
                            className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 font-semibold flex items-center gap-1 disabled:opacity-50">
                            <Unlock size={11} /> Unlock
                          </button>
                        )}
                        <button onClick={(e) => { e.stopPropagation(); handleDelete(a) }} disabled={actionLoading === a.id}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 font-semibold flex items-center gap-1 disabled:opacity-50">
                          <Trash2 size={11} /> Delete
                        </button>
                      </div>
                    )}

                    {/* Customer List */}
                    <div className="px-4 py-2">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Customers ({aCustomers.length})</div>
                    </div>
                    {aCustomers.length === 0 ? (
                      <div className="px-4 py-3 text-sm text-slate-400">No customers associated</div>
                    ) : (
                      <table className="w-full text-xs">
                        <thead className="bg-slate-100/80">
                          <tr>
                            <th className="text-left px-4 py-2 font-semibold text-slate-500">Code</th>
                            <th className="text-left px-4 py-2 font-semibold text-slate-500">Name</th>
                            <th className="text-left px-4 py-2 font-semibold text-slate-500">Mobile</th>
                            <th className="text-left px-4 py-2 font-semibold text-slate-500">Advance</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {aCustomers.map((c: any) => (
                            <tr key={c.id}>
                              <td className="px-4 py-2 text-slate-700 font-medium">{c.code}</td>
                              <td className="px-4 py-2 text-slate-600">{c.businessName}</td>
                              <td className="px-4 py-2 text-slate-500">{c.mobileNo || '—'}</td>
                              <td className="px-4 py-2 text-slate-600">{(c.advance || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Lock Modal */}
      {lockModal.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/40" onClick={() => setLockModal({ show: false, user: null })} />
          <div className="relative bg-white rounded-xl p-6 w-96 max-w-[90vw] shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-900">Lock User</h3>
              <button onClick={() => setLockModal({ show: false, user: null })} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
            </div>
            <p className="text-sm text-slate-600 mb-3">
              Lock <strong>{lockModal.user?.name || lockModal.user?.username}</strong>? They will not be able to log in.
            </p>
            <textarea
              value={lockReason}
              onChange={e => setLockReason(e.target.value)}
              placeholder="Reason for locking (optional)"
              className="w-full border border-slate-200 rounded-lg p-2.5 text-sm resize-none h-20 outline-none focus:border-indigo-400"
            />
            <div className="flex justify-end gap-2 mt-4">
              <button onClick={() => setLockModal({ show: false, user: null })} className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button onClick={confirmLock} disabled={actionLoading}
                className="px-4 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 font-semibold disabled:opacity-50 flex items-center gap-1">
                <Lock size={14} /> {actionLoading ? '...' : 'Lock'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ────────────────────────────────────────
// CUSTOMER LIST — shows all customers/vendors with creator associations
// ────────────────────────────────────────
export function HierarchyCustomersPage() {
  const { currentUser } = useAppStore()
  const isMaster = currentUser?.role === 'super'
  const [customers, setCustomers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')

  useEffect(() => {
    apiFetch('/api/vendors')
      .then((data: any[]) => { setCustomers(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const handleDelete = async (customer: any) => {
    if (!confirm(`Delete customer ${customer.businessName}?`)) return
    try {
      await apiFetch(`/api/vendors/${customer.id}`, { method: 'DELETE' })
      setMessage(`${customer.businessName} deleted`)
      setCustomers(prev => prev.filter(c => c.id !== customer.id))
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : 'Delete failed')
    }
  }

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide flex items-center gap-2">
          <Users size={22} className="text-emerald-600" /> Customer List
        </h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">All customers with their manager/agent associations</p>
      </div>

      {message && (
        <div className={`${message.includes('deleted') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
          {message.includes('deleted') ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : customers.length === 0 ? (
        <div className="text-center py-16 text-slate-400">No customers found</div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Code</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Business Name</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Mobile</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Created By</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Role</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Admin</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">City</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Advance</th>
                {isMaster && <th className="text-right px-4 py-3 font-semibold text-slate-600">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {customers.map((c: any) => {
                const creator = c.creatorInfo
                return (
                  <tr key={c.id} className="border-b border-slate-100 hover:bg-slate-50 transition">
                    <td className="px-4 py-3 text-slate-900 font-medium">{c.code}</td>
                    <td className="px-4 py-3 text-slate-700">{c.businessName}</td>
                    <td className="px-4 py-3 text-slate-500">{c.mobileNo || '—'}</td>
                    <td className="px-4 py-3 text-slate-700 font-medium">{creator?.name || c.createdBy || '—'}</td>
                    <td className="px-4 py-3">
                      {creator?.role && (
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${creator.role === 'super' ? 'bg-amber-50 text-amber-700' : creator.role === 'manager' ? 'bg-violet-50 text-violet-700' : 'bg-sky-50 text-sky-700'}`}>
                          {creator.role === 'super' ? 'Super' : creator.role === 'manager' ? 'Admin' : 'Agent'}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-500">{creator?.managerId ? 'Under Admin' : creator?.role === 'super' ? '—' : 'Unassigned'}</td>
                    <td className="px-4 py-3 text-slate-500">{c.city || '—'}</td>
                    <td className="px-4 py-3 text-slate-600">{(c.advance || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}</td>
                    {isMaster && (
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => handleDelete(c)}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 font-semibold inline-flex items-center gap-1">
                          <Trash2 size={11} /> Delete
                        </button>
                      </td>
                    )}
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
