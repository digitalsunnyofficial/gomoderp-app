'use client'

// ──────────────────────────────────────────────────────────
// UNIFIED CUSTOMER LIST — the ONE customer directory of the
// system. ERP (vendor) customers and customer-app users live
// here together; app signups are approved/rejected from here
// and every app customer has a single detail page with
// profile, history, withdrawal, winning, loss & overall data.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-helpers'
import { useAppStore } from '@/lib/store'
import { VendorPage } from '@/components/pages/VendorPage'
import { SectionCard, FormInput, GoldButton, OutlineButton, Modal } from '@/components/shared-ui'
import {
  Smartphone, Store, Check, X, AlertTriangle, Eye, KeyRound, RefreshCw, Ban,
  TrendingUp, TrendingDown, IndianRupee, Clock, Trophy, Receipt, Wallet,
} from 'lucide-react'

const inr = (n: number | null | undefined) => '₹' + Number(n || 0).toLocaleString('en-IN')
const dt = (v: string | null | undefined) => v ? new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—'

function Msg({ message }: { message: string }) {
  if (!message) return null
  const ok = message.includes('approved') || message.includes('success') || message.includes('reset') || message.includes('Adjusted') || message.includes('rejected')
  return (
    <div className={`${ok ? 'bg-[rgba(5,150,105,0.1)] text-[#059669] border-[rgba(5,150,105,0.3)]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]'} text-[12px] px-3 py-2 rounded-lg mb-4 border flex items-center gap-2`}>
      {ok ? <Check size={14} /> : <AlertTriangle size={14} />} {message}
    </div>
  )
}

interface AppCustomerRow {
  id: string; name: string; mobile: string; wallet: number
  status: string; canBet: boolean; canWithdraw: boolean
  approvalStatus: string; approvedBy: string | null; approvedAt: string | null
  createdAt: string; lastLoginAt: string | null
  referral?: string | null; agentUsername?: string | null; agentName?: string | null
  betsCount: number; totalStaked: number; totalWon: number
  pendingFunds: number; pendingWithdraws: number
}

interface CustomerDetail {
  profile: Record<string, unknown>
  overall: {
    wallet: number; bids: number; staked: number; won: number
    wonBids: number; lostBids: number; stakedLost: number; net: number
    deposited: number; withdrawn: number; withdrawPending: number; pendingFunds: number
  }
  byType: Array<{ type: string; bids: number; staked: number; won: number }>
  bets: Array<{ id: string; marketName: string; betDate: string; slot: string; type: string; num: string; points: number; win: number; status: string; createdAt: string }>
  transactions: Array<{ id: string; type: string; amount: number; balanceAfter: number; remark: string; createdAt: string }>
  funds: Array<{ id: string; amount: number; method: string; utr: string; status: string; createdAt: string }>
  withdrawals: Array<{ id: string; amount: number; status: string; createdAt: string; processedAt: string | null }>
}

const approvalChip: Record<string, string> = {
  approved: 'bg-[rgba(5,150,105,0.12)] text-[#059669] border-[rgba(5,150,105,0.35)]',
  pending: 'bg-[rgba(217,119,6,0.12)] text-[#B45309] border-[rgba(217,119,6,0.35)]',
  rejected: 'bg-[rgba(220,38,38,0.1)] text-[#DC2626] border-[rgba(220,38,38,0.3)]',
}

export function UnifiedCustomerListPage() {
  const currentUser = useAppStore(s => s.currentUser)
  const isSuper = currentUser?.role === 'super'
  const isManager = currentUser?.role === 'manager'
  const canManage = isSuper || isManager

  const [tab, setTab] = useState<'app' | 'erp'>('app')
  const [rows, setRows] = useState<AppCustomerRow[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [detail, setDetail] = useState<CustomerDetail | null>(null)
  const [detailId, setDetailId] = useState<string | null>(null)
  const [resetFor, setResetFor] = useState<AppCustomerRow | null>(null)
  const [newPassword, setNewPassword] = useState('')
  // Master Admin signup-approval toggle (AppConfig "signup_approval_required"):
  // ON  → new app signups wait for approval here (default)
  // OFF → new signups are approved instantly and log in straight away
  const [signupApproval, setSignupApproval] = useState<boolean | null>(null)
  const [savingToggle, setSavingToggle] = useState(false)

  const load = useCallback(() => {
    setLoading(true)
    apiFetch(`/api/app-admin/customers?search=${encodeURIComponent(search)}`)
      .then(d => setRows((d.customers as AppCustomerRow[]) || []))
      .catch(e => setMessage(e instanceof Error ? e.message : 'Failed to load'))
      .finally(() => setLoading(false))
  }, [search])

  useEffect(() => { load() }, [load])

  // Load the signup-approval toggle state (Super Admin provision only —
  // the API rejects agents and the UI hides the toggle from them)
  useEffect(() => {
    if (!isSuper) return
    apiFetch('/api/app-admin/signup-config')
      .then(d => setSignupApproval(!!(d as { signupApprovalRequired?: boolean }).signupApprovalRequired))
      .catch(() => setSignupApproval(null))
  }, [isSuper])

  const toggleApproval = async () => {
    if (signupApproval === null) return
    const next = !signupApproval
    if (!next && !window.confirm('Turn OFF signup approval?\n\nNew customers will be able to log in immediately after registering — no review. Existing pending accounts still need manual approval.')) return
    setSavingToggle(true)
    try {
      await apiFetch('/api/app-admin/signup-config', { method: 'PUT', body: JSON.stringify({ signupApprovalRequired: next }) })
      setSignupApproval(next)
      setMessage(next ? 'Signup approval turned ON — new signups will wait for review here.' : 'Signup approval turned OFF — new signups can log in instantly.')
      load()
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed to update the toggle') } finally { setSavingToggle(false) }
  }

  const openDetail = async (id: string) => {
    setDetailId(id)
    try {
      const d = await apiFetch(`/api/app-admin/customers/detail?id=${id}`)
      setDetail(d as CustomerDetail)
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Failed to load detail') }
  }

  const act = async (body: Record<string, unknown>, okMsg: string) => {
    try {
      await apiFetch('/api/app-admin/customers', { method: 'PATCH', body: JSON.stringify(body) })
      setMessage(okMsg)
      load()
      if (detailId) openDetail(detailId)
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Action failed') }
  }

  const pendingCount = rows.filter(r => r.approvalStatus === 'pending').length

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-6">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Customer List</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">{canManage ? `The single customer directory — system (ERP) customers and app customers together. ${signupApproval === false ? 'Signup approval is OFF — new app signups get instant access.' : 'App signups await approval here before they can use the app.'}` : 'Your own customer book — only customers who signed up with YOUR agent code (or ERP customers you added) appear here.'}</p>
      </div>

      <div className="flex items-center gap-2 mb-5 flex-wrap">
        <button onClick={() => setTab('app')} className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-[12.5px] font-semibold border transition-colors ${tab === 'app' ? 'bg-[#EFF6FF] border-[#BFDBFE] text-[#1D4ED8]' : 'bg-white border-[#E5E7EB] text-[#6B7280] hover:bg-[#F9FAFB]'}`}>
          <Smartphone size={14} /> App Customers {pendingCount ? <span className="bg-[#F59E0B] text-white text-[10px] font-bold rounded-full px-1.5 py-0.5">{pendingCount} pending</span> : null}
        </button>
        <button onClick={() => setTab('erp')} className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-[12.5px] font-semibold border transition-colors ${tab === 'erp' ? 'bg-[#EFF6FF] border-[#BFDBFE] text-[#1D4ED8]' : 'bg-white border-[#E5E7EB] text-[#6B7280] hover:bg-[#F9FAFB]'}`}>
          <Store size={14} /> ERP Customers (Vendors)
        </button>
      </div>

      {tab === 'erp' ? <VendorPage embedded /> : (
        <>
          <Msg message={message} />
          <SectionCard
            title="App Customers"
            headerRight={
              <div className="flex items-center gap-2">
                {/* ── Signup-approval toggle (Super Admin provision — hidden from agents/admins) ── */}
                {isSuper ? (
                <div className="flex items-center gap-2 mr-1 pl-3 border-l border-[#E5E7EB]" title="Toggle: ON = new signups need approval, OFF = instant access">
                  <div className="text-right leading-tight">
                    <div className="text-[10px] font-bold uppercase tracking-wide text-[#9CA3AF]">Signup approval</div>
                    <div className={`text-[10.5px] font-bold ${signupApproval === null ? 'text-[#9CA3AF]' : signupApproval ? 'text-[#B45309]' : 'text-[#059669]'}`}>
                      {signupApproval === null ? 'loading…' : signupApproval ? 'Required' : 'Not required'}
                    </div>
                  </div>
                  <button
                    onClick={toggleApproval}
                    disabled={!isSuper || signupApproval === null || savingToggle}
                    role="switch"
                    aria-checked={!!signupApproval}
                    aria-label="Signup approval toggle"
                    className={`relative w-11 h-6 rounded-full transition-colors shrink-0 disabled:opacity-50 disabled:cursor-not-allowed ${signupApproval ? 'bg-[#F59E0B]' : 'bg-[#059669]'}`}
                  >
                    <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${signupApproval ? 'translate-x-5' : ''}`} />
                  </button>
                </div>
                ) : null}
                <div className="w-[220px]"><FormInput placeholder="Search name / mobile…" value={search} onChange={e => setSearch(e.target.value)} /></div>
                <button onClick={load} className="p-2 rounded-md hover:bg-[#F3F4F6] text-[#6B7280]"><RefreshCw size={14} /></button>
              </div>
            }
          >
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="text-left text-[#9CA3AF] border-b border-[#E5E7EB]">
                    <th className="py-2.5 pr-3 font-semibold">Customer</th>
                    <th className="py-2.5 pr-3 font-semibold">Approval</th>
                    <th className="py-2.5 pr-3 font-semibold">Agent</th>
                    <th className="py-2.5 pr-3 font-semibold">Wallet</th>
                    <th className="py-2.5 pr-3 font-semibold">Bids</th>
                    <th className="py-2.5 pr-3 font-semibold">Staked</th>
                    <th className="py-2.5 pr-3 font-semibold">Won</th>
                    <th className="py-2.5 pr-3 font-semibold">Last Login</th>
                    <th className="py-2.5 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map(c => (
                    <tr key={c.id} className="border-b border-[#F3F4F6] hover:bg-[#F8FAFC]">
                      <td className="py-2.5 pr-3">
                        <div className="font-semibold text-[#111827]">{c.name} {c.status === 'blocked' ? <span className="text-[10px] text-[#DC2626] font-bold">· BLOCKED</span> : null}</div>
                        <div className="text-[11px] text-[#6B7280] font-mono">{c.mobile}</div>
                      </td>
                      <td className="py-2.5 pr-3">
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-full border uppercase ${approvalChip[c.approvalStatus] || approvalChip.pending}`}>{c.approvalStatus}</span>
                      </td>
                      <td className="py-2.5 pr-3">
                        {c.agentUsername ? (
                          <div>
                            <div className="font-semibold text-[#374151]">{c.agentName || c.agentUsername}</div>
                            <div className="text-[10.5px] text-[#9CA3AF]">@{c.agentUsername}{c.referral ? ` · code “${c.referral}”` : ''}</div>
                          </div>
                        ) : <span className="text-[11px] text-[#9CA3AF]">—</span>}
                      </td>
                      <td className="py-2.5 pr-3 font-bold text-[#111827]">{inr(c.wallet)}</td>
                      <td className="py-2.5 pr-3 text-[#374151]">{c.betsCount}</td>
                      <td className="py-2.5 pr-3 text-[#374151]">{inr(c.totalStaked)}</td>
                      <td className="py-2.5 pr-3 text-[#059669] font-semibold">{inr(c.totalWon)}</td>
                      <td className="py-2.5 pr-3 text-[#6B7280]">{c.lastLoginAt ? dt(c.lastLoginAt) : '—'}</td>
                      <td className="py-2.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {c.approvalStatus === 'pending' && canManage ? (
                            <>
                              <button onClick={() => act({ id: c.id, action: 'approve' }, `${c.name} approved — app access granted`)} className="text-[11px] font-bold text-white bg-[#059669] px-2 py-1 rounded-md hover:bg-[#047857]">Approve</button>
                              <button onClick={() => act({ id: c.id, action: 'reject' }, `${c.name} registration rejected`)} className="text-[11px] font-bold text-white bg-[#DC2626] px-2 py-1 rounded-md hover:bg-[#B91C1C]">Reject</button>
                            </>
                          ) : null}
                          {canManage ? (
                            <button onClick={() => openDetail(c.id)} className="text-[11px] font-semibold text-[#2563EB] px-2 py-1 rounded-md hover:bg-[#EFF6FF] inline-flex items-center gap-1"><Eye size={11} /> Detail</button>
                          ) : null}
                          {isSuper ? (
                            <>
                              <button onClick={() => { setResetFor(c); setNewPassword('') }} className="text-[11px] font-semibold text-[#6B7280] px-2 py-1 rounded-md hover:bg-[#F3F4F6] inline-flex items-center gap-1"><KeyRound size={11} /> Password</button>
                              <button onClick={() => act({ id: c.id, status: c.status === 'blocked' ? 'active' : 'blocked' }, c.status === 'blocked' ? `${c.name} unblocked` : `${c.name} blocked`)} className={`text-[11px] font-semibold px-2 py-1 rounded-md inline-flex items-center gap-1 ${c.status === 'blocked' ? 'text-[#059669] hover:bg-[#ECFDF5]' : 'text-[#DC2626] hover:bg-[#FEF2F2]'}`}><Ban size={11} />{c.status === 'blocked' ? 'Unblock' : 'Block'}</button>
                            </>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {loading ? <p className="text-[12px] text-[#9CA3AF] py-4">Loading customers…</p> : null}
              {!loading && !rows.length ? <p className="text-[12px] text-[#9CA3AF] py-4">{canManage ? 'No app customers yet — signups from the customer app appear here for approval.' : 'No customers yet — when a customer signs up with YOUR agent code, they appear here automatically.'}</p> : null}
            </div>
          </SectionCard>
        </>
      )}

      {/* ── Customer single detail page (modal overlay) ── */}
      {detailId && detail ? (
        <Modal open wide title={`${detail.profile.name as string} — Full Details`} onClose={() => { setDetailId(null); setDetail(null) }}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
            {[
              { l: 'Wallet Points', v: inr(detail.overall.wallet), i: <Wallet size={14} /> },
              { l: 'Total Deposited', v: inr(detail.overall.deposited), i: <IndianRupee size={14} /> },
              { l: 'Total Withdrawn', v: inr(detail.overall.withdrawn), i: <IndianRupee size={14} /> },
              { l: 'Withdraw Pending', v: inr(detail.overall.withdrawPending), i: <Clock size={14} /> },
              { l: 'Total Bids', v: String(detail.overall.bids), i: <Receipt size={14} /> },
              { l: 'Total Staked', v: inr(detail.overall.staked), i: <Receipt size={14} /> },
              { l: 'Total Winning', v: inr(detail.overall.won), i: <Trophy size={14} /> },
              { l: 'Total Loss (staked-lost)', v: inr(detail.overall.stakedLost), i: <TrendingDown size={14} /> },
            ].map(k => (
              <div key={k.l} className="border border-[#E5E7EB] rounded-xl p-3 bg-[#F8FAFC]">
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-[#9CA3AF]">{k.i}{k.l}</div>
                <div className="text-[15px] font-bold text-[#111827] mt-1">{k.v}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Profile + overall */}
            <div>
              <h4 className="text-[13px] font-bold text-[#111827] mb-2">Profile</h4>
              <div className="border border-[#E5E7EB] rounded-xl divide-y divide-[#F3F4F6] text-[12px]">
                {[
                  ['Name', String(detail.profile.name)],
                  ['Mobile', String(detail.profile.mobile)],
                  ['Account Status', String(detail.profile.status)],
                  ['Approval', `${String(detail.profile.approvalStatus)}${detail.profile.approvedBy ? ` · by ${detail.profile.approvedBy} · ${dt(detail.profile.approvedAt as string)}` : ''}`],
                  ['Betting', detail.profile.canBet ? 'Enabled' : 'Disabled'],
                  ['Withdrawals', detail.profile.canWithdraw ? 'Enabled' : 'Disabled'],
                  ['Joined', dt(detail.profile.createdAt as string)],
                  ['Last Login', detail.profile.lastLoginAt ? dt(detail.profile.lastLoginAt as string) : '—'],
                  ['Net Position (win − stake)', inr(detail.overall.net)],
                  ['Won / Lost Bids', `${detail.overall.wonBids} / ${detail.overall.lostBids}`],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-3 px-3 py-2">
                    <span className="text-[#9CA3AF]">{k}</span><span className="font-semibold text-[#111827] text-right">{v}</span>
                  </div>
                ))}
              </div>
              <h4 className="text-[13px] font-bold text-[#111827] mt-4 mb-2">By Game Type</h4>
              <div className="border border-[#E5E7EB] rounded-xl divide-y divide-[#F3F4F6] text-[12px]">
                {detail.byType.map(t => (
                  <div key={t.type} className="flex justify-between gap-3 px-3 py-2">
                    <span className="text-[#6B7280] uppercase font-semibold text-[11px]">{t.type}</span>
                    <span className="text-[#374151]">{t.bids} bids · staked {inr(t.staked)} · won {inr(t.won)}</span>
                  </div>
                ))}
                {!detail.byType.length ? <div className="px-3 py-2 text-[#9CA3AF]">No bids yet</div> : null}
              </div>
            </div>

            {/* History */}
            <div>
              <h4 className="text-[13px] font-bold text-[#111827] mb-2">Bid History (recent)</h4>
              <div className="border border-[#E5E7EB] rounded-xl max-h-[240px] overflow-y-auto divide-y divide-[#F3F4F6] text-[11.5px]">
                {detail.bets.map(b => (
                  <div key={b.id} className="flex items-center justify-between gap-2 px-3 py-2">
                    <div>
                      <span className="font-semibold text-[#111827]">{b.marketName}</span>
                      <span className="text-[#9CA3AF]"> · {b.slot} {b.type.toUpperCase()} <b className="font-mono text-[#1D4ED8]">{b.num}</b></span>
                      <div className="text-[10px] text-[#9CA3AF]">{b.betDate} · {dt(b.createdAt)}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-[#111827]">{inr(b.points)}</div>
                      <span className={`text-[10px] font-bold uppercase ${b.status === 'won' ? 'text-[#059669]' : b.status === 'lost' ? 'text-[#DC2626]' : 'text-[#B45309]'}`}>{b.status}{b.status === 'won' ? ` ${inr(b.win)}` : ''}</span>
                    </div>
                  </div>
                ))}
                {!detail.bets.length ? <div className="px-3 py-2 text-[#9CA3AF]">No bids yet</div> : null}
              </div>

              <h4 className="text-[13px] font-bold text-[#111827] mt-4 mb-2">Withdrawal Data</h4>
              <div className="border border-[#E5E7EB] rounded-xl max-h-[150px] overflow-y-auto divide-y divide-[#F3F4F6] text-[11.5px]">
                {detail.withdrawals.map(w => (
                  <div key={w.id} className="flex items-center justify-between px-3 py-2">
                    <span className="text-[#374151]">{inr(w.amount)} · {dt(w.createdAt)}</span>
                    <span className={`text-[10px] font-bold uppercase ${w.status === 'paid' ? 'text-[#059669]' : w.status === 'rejected' ? 'text-[#DC2626]' : 'text-[#B45309]'}`}>{w.status}</span>
                  </div>
                ))}
                {!detail.withdrawals.length ? <div className="px-3 py-2 text-[#9CA3AF]">No withdrawals yet</div> : null}
              </div>

              <h4 className="text-[13px] font-bold text-[#111827] mt-4 mb-2">Wallet Ledger (recent)</h4>
              <div className="border border-[#E5E7EB] rounded-xl max-h-[170px] overflow-y-auto divide-y divide-[#F3F4F6] text-[11.5px]">
                {detail.transactions.map(t => (
                  <div key={t.id} className="flex items-center justify-between px-3 py-2">
                    <div>
                      <div className="text-[#374151]">{t.remark}</div>
                      <div className="text-[10px] text-[#9CA3AF]">{dt(t.createdAt)} · bal {inr(t.balanceAfter)}</div>
                    </div>
                    <span className={`font-bold ${t.amount > 0 ? 'text-[#059669]' : 'text-[#DC2626]'}`}>{t.amount > 0 ? '+' : ''}{inr(t.amount)}</span>
                  </div>
                ))}
                {!detail.transactions.length ? <div className="px-3 py-2 text-[#9CA3AF]">No transactions yet</div> : null}
              </div>
            </div>
          </div>
        </Modal>
      ) : null}

      {/* Password reset modal */}
      {resetFor ? (
        <Modal open title={`Reset Password — ${resetFor.name}`} onClose={() => setResetFor(null)}>
          <p className="text-[12px] text-[#6B7280] mb-3">Set a new password for <b>{resetFor.mobile}</b>. All their app sessions will be logged out. The customer can still change it later from the app (Profile → Change Password).</p>
          <FormInput placeholder="New password (min 6 characters)" value={newPassword} onChange={e => setNewPassword(e.target.value)} />
          <div className="flex justify-end gap-2 mt-4">
            <OutlineButton onClick={() => setResetFor(null)}>Cancel</OutlineButton>
            <GoldButton onClick={async () => {
              if (newPassword.length < 6) { setMessage('Password must be at least 6 characters'); return }
              await act({ id: resetFor.id, action: 'reset_password', newPassword }, 'Password reset — customer sessions logged out')
              setResetFor(null)
            }}><KeyRound size={14} /> Reset Password</GoldButton>
          </div>
        </Modal>
      ) : null}
    </div>
  )
}
