'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-helpers'
import { formatDate, getCurrentTime } from '@/lib/format'
import { SectionCard, FormField, FormInput, FormSelect, GoldButton, OutlineButton } from '@/components/shared-ui'
import { Check, RotateCcw, ChevronLeft, X } from 'lucide-react'
// Inline-render the CardInventoryPage from the ERP entry so users stay on the
// same page after creating an inventory (no navigation friction).
import { CardInventoryPage } from '@/app/merp/page'

export function NewInventoryPage() {
  const { currentUser, setViewingInventoryId } = useAppStore()
  const [codes, setCodes] = useState<Array<{ id: string; name: string; code: string }>>([])
  const [form, setForm] = useState({
    date: formatDate(new Date()),
    inventoryCodeId: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')
  const [inlineInventoryId, setInlineInventoryId] = useState<string | null>(null)
  const submitRef = useRef(false)

  useEffect(() => {
    apiFetch('/api/inventory-codes').then(setCodes).catch(console.error)
  }, [])

  const handleSubmit = async () => {
    if (!form.inventoryCodeId) { setMessage('Please select an inventory code'); return }
    if (submitRef.current) return // Prevent double submission
    submitRef.current = true
    setSubmitting(true)
    setMessage('')
    try {
      const inventory = await apiFetch('/api/inventories', {
        method: 'POST',
        body: JSON.stringify({
          date: form.date,
          time: getCurrentTime(),
          inventoryCodeId: form.inventoryCodeId,
          remark: '',
          createdBy: currentUser?.username || 'admin1',
        }),
      }) as { id: string }
      // ── INLINE FLOW: Don't navigate to card-view. Instead, set
      // viewingInventoryId (so CardInventoryPage loads its data) and render
      // the CardInventoryPage component inline below the date+market form.
      // The user can keep working in the same scroll context.
      setViewingInventoryId(inventory.id)
      setInlineInventoryId(inventory.id)
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : 'Failed to create inventory'
      if (errMsg.includes('already exists')) {
        // Duplicate detected — the error message from the backend includes guidance
        setMessage(errMsg + ' — Go to Entry Lists to view it.')
      } else {
        setMessage(errMsg)
      }
      submitRef.current = false
    }
    setSubmitting(false)
  }

  const handleReset = () => {
    setForm({ date: formatDate(new Date()), inventoryCodeId: '' })
    setMessage('')
    submitRef.current = false
  }

  const handleCloseInline = () => {
    // User closed the inline inventory view — reset everything so they can
    // create another entry.
    setInlineInventoryId(null)
    setViewingInventoryId(null)
    submitRef.current = false
    setMessage('')
  }

  const selectedCode = codes.find(c => c.id === form.inventoryCodeId)

  return (
    <div className="p-4 md:p-7 animate-in fade-in duration-300">
      <div className="mb-4">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">New Entry</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Create a new entry — the input form opens below after you pick a market.</p>
      </div>

      {/* ── Date + Market selector (always visible at top) ── */}
      <SectionCard
        title="Entry Details"
        headerRight={<span className="font-mono text-[12px] text-[#9CA3AF]">{form.date}</span>}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
          <FormField label="Date">
            <FormInput
              type="date"
              value={form.date}
              onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
              disabled={!!inlineInventoryId}
            />
          </FormField>
          <FormField label="Markets">
            <FormSelect
              value={form.inventoryCodeId}
              onChange={e => setForm(f => ({ ...f, inventoryCodeId: e.target.value }))}
              disabled={!!inlineInventoryId}
            >
              <option value="">&mdash; Select &mdash;</option>
              {codes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </FormSelect>
          </FormField>
        </div>

        {message && (
          <div className={`text-[12px] px-3 py-2 rounded-lg mb-4 ${message.includes('success') ? 'bg-[rgba(5,150,105,0.1)] text-[#059669]' : 'bg-[rgba(220,38,38,0.1)] text-[#DC2626]'}`}>
            {message}
          </div>
        )}

        {!inlineInventoryId && (
          <div className="flex gap-2.5 flex-wrap">
            <GoldButton onClick={handleSubmit} disabled={submitting || !form.inventoryCodeId}>
              <Check size={14} /> {submitting ? 'Creating...' : 'Continue'}
            </GoldButton>
            <OutlineButton onClick={handleReset}>
              <RotateCcw size={14} /> Reset
            </OutlineButton>
          </div>
        )}

        {inlineInventoryId && (
          <div className="flex items-center justify-between gap-3 flex-wrap bg-[rgba(5,150,105,0.06)] border border-[rgba(5,150,105,0.2)] rounded-lg px-3 py-2">
            <div className="flex items-center gap-2 text-[12px] text-[#059669] font-semibold">
              <Check size={14} /> Inventory created for <strong>{selectedCode?.name}</strong> on {form.date}
            </div>
            <button
              onClick={handleCloseInline}
              className="inline-flex items-center gap-1 text-[12px] font-semibold text-[#475569] hover:text-[#DC2626] transition-colors px-2 py-1 rounded hover:bg-[rgba(220,38,38,0.06)]"
            >
              <X size={12} /> Close &amp; Create New
            </button>
          </div>
        )}
      </SectionCard>

      {/* ── Inline Card Inventory Page (renders below when inventory is created) ── */}
      {inlineInventoryId && (
        <div className="mt-4 border-t-2 border-[#4F46E5]/20 pt-4">
          <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
            <div className="bg-gradient-to-r from-[#4F46E5] to-[#7C3AED] text-white px-4 py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[13px] font-bold">
                <ChevronLeft size={14} className="opacity-60" />
                Entry Workspace
              </div>
              <span className="text-[10px] opacity-80 font-mono">{selectedCode?.code}</span>
            </div>
            <div>
              <CardInventoryPage key={inlineInventoryId} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
