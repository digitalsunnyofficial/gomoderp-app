'use client'

// ──────────────────────────────────────────────────────────
// GAME MANAGEMENT PANELS
//   • GamesPage        — catalog + ERP mapping editor
//   • GameAllocPage    — allocate games to markets (+overrides)
//   • MarketTimingsPage— weekly open/close schedule + on/off
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react'
import { SectionCard, FormField, FormInput, FormSelect, BlueButton, OutlineButton, Modal } from '@/components/shared-ui'
import { apiFetch } from '@/lib/api-helpers'
import { DAY_LABELS, GAME_DEFS } from '@/lib/matka/games'

// ── small helpers ──
function Chip({ children, cls = '' }: { children: React.ReactNode; cls?: string }) {
  return <span className={'inline-flex items-center gap-1 text-[10.5px] font-bold px-2 py-[3px] rounded-full ' + cls}>{children}</span>
}

function Toggle({ on, onChange, disabled }: { on: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      onClick={() => onChange(!on)}
      disabled={disabled}
      className={'relative w-10 h-[22px] rounded-full transition-colors flex-shrink-0 ' + (on ? 'bg-[#2563EB]' : 'bg-[#D1D5DB]') + (disabled ? ' opacity-50' : '')}
    >
      <span className={'absolute top-[3px] w-4 h-4 rounded-full bg-white shadow transition-all ' + (on ? 'left-[21px]' : 'left-[3px]')} />
    </button>
  )
}

// ══════════════════════════════════════════════════════════
// GAME MANAGEMENT
// ══════════════════════════════════════════════════════════
interface GameRow {
  id: string; code: string; name: string; category: string; base: string
  erpType: string; erpSub: string; erpGroup: string | null; settleAs: string
  rates: Record<string, number>; minPoints: number; scope: string; icon: string
  active: boolean; isBuiltin: boolean; sortOrder: number; note: string | null
  allocations: string[]
}

const EMPTY_FORM = {
  id: '', code: '', name: '', category: 'Custom', base: '', erpType: 'triple',
  erpSub: 'mix', erpGroup: '', settleAs: 'sp', rateMain: 140, rateStar: 0,
  minPoints: 10, active: true, note: '',
}

export function GamesPage() {
  const [games, setGames] = useState<GameRow[]>([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState({ ...EMPTY_FORM })
  const [msg, setMsg] = useState('')
  const [search, setSearch] = useState('')

  const load = useCallback(async () => {
    try {
      const d = await apiFetch('/api/app-admin/games')
      setGames((d as { games: GameRow[] }).games)
    } catch (e) { setMsg((e as Error).message) }
    setLoading(false)
  }, [])
  useEffect(() => { load() }, [load])

  const openEdit = (g: GameRow) => {
    setForm({
      id: g.id, code: g.code, name: g.name, category: g.category, base: g.base,
      erpType: g.erpType, erpSub: g.erpSub, erpGroup: g.erpGroup || '',
      settleAs: g.settleAs, rateMain: g.rates.main ?? g.rates.rate ?? 0,
      rateStar: g.rates.star ?? 0, minPoints: g.minPoints, active: g.active,
      note: g.note || '',
    })
    setModal(true)
  }
  const openCreate = () => {
    setForm({ ...EMPTY_FORM })
    setModal(true)
  }

  const save = async () => {
    try {
      const rates: Record<string, number> = {}
      if (form.rateMain) rates.main = Number(form.rateMain)
      if (form.rateStar) rates.star = Number(form.rateStar)
      if (form.id) {
        await apiFetch('/api/app-admin/games', {
          method: 'PUT',
          body: JSON.stringify({
            id: form.id, name: form.name, category: form.category, base: form.base,
            erpType: form.erpType, erpSub: form.erpSub,
            erpGroup: form.erpGroup || null, settleAs: form.settleAs,
            rates, minPoints: Number(form.minPoints), active: form.active, note: form.note || null,
          }),
        })
      } else {
        await apiFetch('/api/app-admin/games', {
          method: 'POST',
          body: JSON.stringify({
            code: form.code, name: form.name, category: form.category, base: form.base,
            erpType: form.erpType, erpSub: form.erpSub,
            erpGroup: form.erpGroup || null, settleAs: form.settleAs,
            rates, minPoints: Number(form.minPoints), active: form.active, note: form.note || null,
          }),
        })
      }
      setModal(false)
      setMsg('Saved')
      load()
    } catch (e) { setMsg((e as Error).message) }
  }

  const filtered = games.filter(g =>
    !search || (g.name + g.code + g.category).toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5 flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Game Management</h1>
          <p className="text-[12px] text-[#9CA3AF] mt-1">Every game, its calculation base and its mapping into the ERP entry system</p>
        </div>
        <div className="flex items-center gap-2">
          <FormInput placeholder="Search games…" value={search} onChange={e => setSearch(e.target.value)} className="!w-56" />
          <BlueButton onClick={openCreate}>+ Custom Game</BlueButton>
        </div>
      </div>

      {msg && <div className="mb-3 text-[12px] font-semibold text-[#2563EB]">{msg}</div>}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {[
          { l: 'Total Games', v: games.length },
          { l: 'Active', v: games.filter(g => g.active).length },
          { l: 'Custom (added)', v: games.filter(g => !g.isBuiltin).length },
          { l: 'Categories', v: new Set(games.map(g => g.category)).size },
        ].map(s => (
          <div key={s.l} className="bg-white border border-[#E5E7EB] rounded-xl px-4 py-3">
            <div className="text-[10.5px] font-bold uppercase tracking-wide text-[#9CA3AF]">{s.l}</div>
            <div className="text-[20px] font-extrabold text-[#2563EB] mt-0.5">{s.v}</div>
          </div>
        ))}
      </div>

      <SectionCard title="Games Catalog">
        {loading ? <p className="text-[12px] text-[#6B7280]">Loading…</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#9CA3AF] border-b border-[#E5E7EB]">
                  <th className="py-2 pr-3">Game</th>
                  <th className="py-2 pr-3">Category</th>
                  <th className="py-2 pr-3">Base</th>
                  <th className="py-2 pr-3">ERP Mapping</th>
                  <th className="py-2 pr-3">Rates</th>
                  <th className="py-2 pr-3">Min</th>
                  <th className="py-2 pr-3">Allocated</th>
                  <th className="py-2 pr-3">On</th>
                  <th className="py-2"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(g => (
                  <tr key={g.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="py-2.5 pr-3">
                      <div className="font-bold text-[#111827]">{g.name}</div>
                      <div className="text-[10.5px] text-[#9CA3AF] font-mono">{g.code}{g.isBuiltin ? '' : ' · custom'}</div>
                    </td>
                    <td className="py-2.5 pr-3"><Chip cls="bg-[#EFF6FF] text-[#2563EB]">{g.category}</Chip></td>
                    <td className="py-2.5 pr-3 text-[#6B7280] max-w-[170px]">{g.base}</td>
                    <td className="py-2.5 pr-3">
                      <div className="font-mono text-[10.5px] text-[#111827]">
                        {g.erpType} → {g.erpSub}{g.erpGroup ? ' → ' + g.erpGroup : ''}
                      </div>
                      <div className="text-[10px] text-[#9CA3AF]">settles as {g.settleAs}</div>
                    </td>
                    <td className="py-2.5 pr-3 font-mono text-[11px] text-[#111827]">
                      {Object.entries(g.rates).map(([k, v]) => <div key={k}>{k}: 1:{v}</div>)}
                    </td>
                    <td className="py-2.5 pr-3 text-[#6B7280]">{g.minPoints}</td>
                    <td className="py-2.5 pr-3">
                      {g.allocations.length
                        ? <Chip cls="bg-[#DCFCE7] text-[#15803D]">{g.allocations.length} market{g.allocations.length > 1 ? 's' : ''}</Chip>
                        : <Chip cls="bg-[#F3F4F6] text-[#9CA3AF]">none</Chip>}
                    </td>
                    <td className="py-2.5 pr-3"><Toggle on={g.active} onChange={() => { }} disabled /></td>
                    <td className="py-2.5">
                      <OutlineButton onClick={() => openEdit(g)}>Edit</OutlineButton>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-[11px] text-[#9CA3AF] mt-3">
          ERP mapping follows the existing chart system: entry type (single/double/triple/composite) → sub (mix/common/group) → group (SP, DP, TP, SPDPTP, Motor Pana, Family sets…).
          Game selections are expanded into ERP-ready entries automatically when a customer bids.
        </p>
      </SectionCard>

      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? 'Edit Game — ' + form.name : 'New Custom Game'} wide>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {!form.id && (
            <FormField label="Game Code (unique)">
              <FormInput value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} placeholder="e.g. lucky_digit" />
            </FormField>
          )}
          <FormField label="Name">
            <FormInput value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </FormField>
          <FormField label="Category">
            <FormSelect value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {['Digit', 'Pana', 'Jodi', 'Family', 'Motor', 'Common', 'Combined', 'Composite', 'Custom'].map(c => <option key={c}>{c}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="Calculation Base">
            <FormInput value={form.base} onChange={e => setForm(f => ({ ...f, base: e.target.value }))} placeholder="e.g. SP + Motor" />
          </FormField>
          <FormField label="ERP Type">
            <FormSelect value={form.erpType} onChange={e => setForm(f => ({ ...f, erpType: e.target.value }))}>
              {['single', 'double', 'triple', 'composite'].map(c => <option key={c}>{c}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="ERP Sub">
            <FormSelect value={form.erpSub} onChange={e => setForm(f => ({ ...f, erpSub: e.target.value }))}>
              {['mix', 'common', 'group'].map(c => <option key={c}>{c}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="ERP Group">
            <FormSelect value={form.erpGroup} onChange={e => setForm(f => ({ ...f, erpGroup: e.target.value }))}>
              <option value="">— none —</option>
              {['SP', 'DP', 'TP', 'SPDP', 'SPTP', 'DPTP', 'SPDPTP', 'Motor Pana', '50 Chart', '60 Chart', '70 Chart', '90 DP Chart', '90 ABR Chart', 'Family Set 4', 'Family Set 6', 'Family Set 8'].map(c => <option key={c}>{c}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="Settles As">
            <FormSelect value={form.settleAs} onChange={e => setForm(f => ({ ...f, settleAs: e.target.value }))}>
              {['single', 'jodi', 'sp', 'dp', 'tp', 'hs', 'hsb', 'fs', 'dj'].map(c => <option key={c}>{c}</option>)}
            </FormSelect>
          </FormField>
          <FormField label="Min Points">
            <FormInput type="number" value={form.minPoints} onChange={e => setForm(f => ({ ...f, minPoints: Number(e.target.value) }))} />
          </FormField>
          <FormField label="Rate — Main (1:x)">
            <FormInput type="number" value={form.rateMain} onChange={e => setForm(f => ({ ...f, rateMain: Number(e.target.value) }))} />
          </FormField>
          <FormField label="Rate — Starline (1:x, 0 = off)">
            <FormInput type="number" value={form.rateStar} onChange={e => setForm(f => ({ ...f, rateStar: Number(e.target.value) }))} />
          </FormField>
          <FormField label="Active">
            <div className="pt-1.5"><Toggle on={form.active} onChange={v => setForm(f => ({ ...f, active: v }))} /></div>
          </FormField>
        </div>
        <FormField label="Calculation Note (shown to operators)">
          <FormInput value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} placeholder="How this game is calculated" />
        </FormField>
        <div className="flex justify-end gap-2 mt-2">
          <OutlineButton onClick={() => setModal(false)}>Cancel</OutlineButton>
          <BlueButton onClick={save}>Save Game</BlueButton>
        </div>
      </Modal>
    </div>
  )
}

// ══════════════════════════════════════════════════════════
// GAME ALLOCATION TO MARKETS
// ══════════════════════════════════════════════════════════
interface AllocRow { gameId: string; enabled: boolean; rate: number | null; minPoints: number | null }
export function GameAllocPage() {
  const [markets, setMarkets] = useState<Array<{ id: string; code: string; name: string; isActive: boolean }>>([])
  const [games, setGames] = useState<GameRow[]>([])
  const [mk, setMk] = useState('')
  const [alloc, setAlloc] = useState<Record<string, AllocRow>>({})
  const [msg, setMsg] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    apiFetch('/api/app-admin/games/allocate').then(d => {
      const data = d as { markets: typeof markets; games: GameRow[] }
      setMarkets(data.markets)
      setGames(data.games)
      if (data.markets[0]) setMk(data.markets[0].code)
    }).catch(e => setMsg((e as Error).message))
  }, [])

  const loadAlloc = useCallback(async (code: string) => {
    if (!code) return
    try {
      const d = await apiFetch('/api/app-admin/games/allocate?marketCode=' + code)
      const map: Record<string, AllocRow> = {}
      for (const a of (d as { allocations: AllocRow[] }).allocations) map[a.gameId] = a
      setAlloc(map)
    } catch (e) { setMsg((e as Error).message) }
  }, [])
  useEffect(() => { loadAlloc(mk) }, [mk, loadAlloc])

  const setRow = (gameId: string, patch: Partial<AllocRow>) => {
    setAlloc(prev => ({
      ...prev,
      [gameId]: { enabled: false, rate: null, minPoints: null, ...prev[gameId], ...patch },
    }))
  }

  const save = async () => {
    setSaving(true)
    try {
      const allocations = games.map(g => ({
        gameId: g.id,
        enabled: alloc[g.id]?.enabled ?? false,
        rate: alloc[g.id]?.rate ?? null,
        minPoints: alloc[g.id]?.minPoints ?? null,
      }))
      await apiFetch('/api/app-admin/games/allocate', {
        method: 'PUT', body: JSON.stringify({ marketCode: mk, allocations }),
      })
      setMsg('Allocation saved for ' + (markets.find(m => m.code === mk)?.name || mk))
      loadAlloc(mk)
    } catch (e) { setMsg((e as Error).message) }
    setSaving(false)
  }

  const enabledCount = games.filter(g => alloc[g.id]?.enabled).length

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5">
        <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Game Allocation</h1>
        <p className="text-[12px] text-[#9CA3AF] mt-1">Choose which games customers can play on each market, with optional rate / min-point overrides</p>
      </div>

      {msg && <div className="mb-3 text-[12px] font-semibold text-[#2563EB]">{msg}</div>}

      <div className="flex flex-wrap gap-2 mb-4">
        {markets.map(m => (
          <button key={m.code} onClick={() => setMk(m.code)}
            className={'px-3.5 py-1.5 rounded-full text-[12px] font-bold border transition ' +
              (mk === m.code ? 'bg-[#2563EB] text-white border-[#2563EB]' : 'bg-white text-[#374151] border-[#E5E7EB] hover:border-[#2563EB]')}>
            {m.name}{m.isActive ? '' : ' (off)'}
          </button>
        ))}
      </div>

      <SectionCard
        title={'Games on ' + (markets.find(m => m.code === mk)?.name || '…')}
        headerRight={<Chip cls="bg-[#EFF6FF] text-[#2563EB]">{enabledCount} / {games.length} enabled</Chip>}
      >
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#9CA3AF] border-b border-[#E5E7EB]">
                <th className="py-2 pr-3">Game</th>
                <th className="py-2 pr-3">Category</th>
                <th className="py-2 pr-3">Default Rate</th>
                <th className="py-2 pr-3">Rate Override</th>
                <th className="py-2 pr-3">Min Override</th>
                <th className="py-2">Enabled</th>
              </tr>
            </thead>
            <tbody>
              {games.map(g => {
                const row = alloc[g.id]
                return (
                  <tr key={g.id} className={'border-b border-[#F3F4F6] ' + (row?.enabled ? 'bg-[#EFF6FF]/40' : '')}>
                    <td className="py-2.5 pr-3">
                      <div className="font-bold text-[#111827]">{g.name}</div>
                      <div className="text-[10.5px] text-[#9CA3AF] font-mono">{g.code}</div>
                    </td>
                    <td className="py-2.5 pr-3"><Chip cls="bg-[#F3F4F6] text-[#374151]">{g.category}</Chip></td>
                    <td className="py-2.5 pr-3 font-mono text-[11px] text-[#6B7280]">
                      {Object.entries(g.rates).map(([k, v]) => k + ':1:' + v).join(' · ')}
                    </td>
                    <td className="py-2.5 pr-3">
                      <FormInput type="number" placeholder="—" className="!w-24"
                        value={row?.rate ?? ''} onChange={e => setRow(g.id, { rate: e.target.value === '' ? null : Number(e.target.value) })} />
                    </td>
                    <td className="py-2.5 pr-3">
                      <FormInput type="number" placeholder="—" className="!w-20"
                        value={row?.minPoints ?? ''} onChange={e => setRow(g.id, { minPoints: e.target.value === '' ? null : Number(e.target.value) })} />
                    </td>
                    <td className="py-2.5"><Toggle on={row?.enabled ?? false} onChange={v => setRow(g.id, { enabled: v })} /></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-4">
          <BlueButton onClick={save} disabled={saving || !mk}>{saving ? 'Saving…' : 'Save Allocation'}</BlueButton>
        </div>
      </SectionCard>
    </div>
  )
}
// ══════════════════════════════════════════════════════════
// MARKET TIMINGS — add market (timings at creation, AM/PM) +
// weekly schedule + on/off + bet-closing minutes + cron bot
// ══════════════════════════════════════════════════════════
interface MarketRow {
  id: string; code: string; name: string; category: string
  openTime: string; closeTime: string
  weeklySchedule: string; isActive: boolean
  betCloseMinutes?: number
  gamesEnabled: number; gamesTotal: number
}
interface DayRow { open: string; close: string; enabled: boolean }

function parseSched(json: string): Record<string, DayRow> {
  try { return JSON.parse(json || '{}') } catch { return {} }
}

// 24h "HH:MM" → 12h parts
function to12(t: string): { h: string; m: string; p: 'AM' | 'PM' } {
  const [H, M] = t.split(':').map(Number)
  const p: 'AM' | 'PM' = H < 12 ? 'AM' : 'PM'
  const h = H % 12 === 0 ? 12 : H % 12
  return { h: String(h), m: String(M).padStart(2, '0'), p }
}
function from12(h: string, m: string, p: string): string {
  const H = (Number(h) % 12) + (p === 'PM' ? 12 : 0)
  return String(H).padStart(2, '0') + ':' + m
}

/** AM/PM time picker → emits 24h HH:MM. */
function TimeAmPm({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const v = to12(/^\d{1,2}:\d{2}$/.test(value) ? value : '10:00')
  const box = 'border border-[#E5E7EB] rounded-lg px-1.5 py-[5px] text-[12px] font-bold text-[#374151] bg-white outline-none focus:border-[#2563EB]'
  return (
    <div className="inline-flex items-center gap-1">
      <select className={box} value={v.h} onChange={e => onChange(from12(e.target.value, v.m, v.p))}>
        {Array.from({ length: 12 }, (_, i) => <option key={i + 1} value={String(i + 1)}>{i + 1}</option>)}
      </select>
      <span className="font-bold text-slate-400">:</span>
      <select className={box} value={v.m} onChange={e => onChange(from12(v.h, e.target.value, v.p))}>
        {['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'].map(m => <option key={m} value={m}>{m}</option>)}
      </select>
      <select className={box} value={v.p} onChange={e => onChange(from12(v.h, v.m, e.target.value))}>
        <option>AM</option><option>PM</option>
      </select>
    </div>
  )
}

const STATE_STYLES: Record<string, { label: string; cls: string }> = {
  'open': { label: 'OPEN · ACCEPTING', cls: 'bg-emerald-100 text-emerald-700' },
  'in-session': { label: 'CLOSE SESSION LIVE', cls: 'bg-blue-100 text-blue-700' },
  'closed': { label: 'CLOSED', cls: 'bg-slate-100 text-slate-500' },
  'weekly-off': { label: 'WEEKLY OFF', cls: 'bg-amber-100 text-amber-700' },
  'off': { label: 'DEACTIVATED', cls: 'bg-red-100 text-red-600' },
}

interface CronInfo {
  running: boolean; lastTick: string | null; ticks: number
  markets: Array<{ code: string; state: string; name: string }>
}

export function MarketTimingsPage() {
  const [markets, setMarkets] = useState<MarketRow[]>([])
  const [msg, setMsg] = useState('')
  const [edit, setEdit] = useState<MarketRow | null>(null)
  const [days, setDays] = useState<Record<string, DayRow>>({})
  const [defOpen, setDefOpen] = useState('')
  const [defClose, setDefClose] = useState('')
  const [betClose, setBetClose] = useState('5')
  const [saving, setSaving] = useState(false)
  // Add market
  const [addOpen, setAddOpen] = useState(false)
  const [nm, setNm] = useState(''); const [cd, setCd] = useState('')
  const [nOpen, setNOpen] = useState('10:00'); const [nClose, setNClose] = useState('12:00')
  const [nBet, setNBet] = useState('5')
  const [adding, setAdding] = useState(false)
  // Cron
  const [cron, setCron] = useState<CronInfo | null>(null)

  const loadCron = useCallback(() => {
    apiFetch('/api/app-admin/cron').then((d: CronInfo) => setCron(d)).catch(() => {})
  }, [])

  const load = useCallback(async () => {
    try {
      const d = await apiFetch('/api/app-admin/markets')
      setMarkets((d as { markets: MarketRow[] }).markets)
    } catch (e) { setMsg((e as Error).message) }
    loadCron()
  }, [loadCron])
  useEffect(() => {
    load()
    const t = setInterval(loadCron, 15000)
    return () => clearInterval(t)
  }, [load, loadCron])

  const openEdit = (m: MarketRow) => {
    setEdit(m)
    const sched = parseSched(m.weeklySchedule)
    const filled: Record<string, DayRow> = {}
    for (let d = 0; d <= 6; d++) {
      filled[String(d)] = sched[String(d)] || { open: m.openTime, close: m.closeTime, enabled: true }
    }
    setDays(filled)
    setDefOpen(m.openTime)
    setDefClose(m.closeTime)
    setBetClose(String(m.betCloseMinutes ?? 5))
  }

  const toggleActive = async (m: MarketRow, v: boolean) => {
    try {
      await apiFetch('/api/app-admin/markets', {
        method: 'PUT', body: JSON.stringify({ id: m.id, isActive: v }),
      })
      setMsg(m.name + (v ? ' activated' : ' deactivated'))
      load()
    } catch (e) { setMsg((e as Error).message) }
  }

  const saveEdit = async () => {
    if (!edit) return
    setSaving(true)
    try {
      await apiFetch('/api/app-admin/markets', {
        method: 'PUT',
        body: JSON.stringify({ id: edit.id, weeklySchedule: days, openTime: defOpen, closeTime: defClose, betCloseMinutes: Number(betClose) || 0 }),
      })
      setMsg('Timings saved for ' + edit.name)
      setEdit(null)
      load()
    } catch (e) { setMsg((e as Error).message) }
    setSaving(false)
  }

  const submitAdd = async () => {
    if (!nm.trim()) { setMsg('Market name is required'); return }
    setAdding(true)
    try {
      await apiFetch('/api/app-admin/markets', {
        method: 'POST',
        body: JSON.stringify({ name: nm, code: cd, openTime: nOpen, closeTime: nClose, betCloseMinutes: Number(nBet) || 0 }),
      })
      setMsg('Market "' + nm + '" created with its timings — the app picks it up instantly')
      setAddOpen(false); setNm(''); setCd(''); setNOpen('10:00'); setNClose('12:00'); setNBet('5')
      load()
    } catch (e) { setMsg((e as Error).message) }
    setAdding(false)
  }

  const setDay = (d: string, patch: Partial<DayRow>) => {
    setDays(prev => ({ ...prev, [d]: { ...prev[d], ...patch } }))
  }

  const todayIdx = new Date().getDay()
  const openMarkets = cron?.markets.filter(m => m.state === 'open' || m.state === 'in-session').length ?? 0

  return (
    <div className="p-7 animate-in fade-in duration-300">
      <div className="mb-5 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-cinzel text-[22px] font-bold text-[#111827] tracking-wide">Market Timings</h1>
          <p className="text-[12px] text-[#6B7280] mt-1">Create markets with their timings, manage each market's schedule below it — the cron bot opens &amp; closes markets automatically</p>
        </div>
        <button onClick={() => setAddOpen(true)}
          className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold px-4 py-2 rounded-[10px] bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-white hover:brightness-110">
          + Add Market
        </button>
      </div>

      {msg && <div className="mb-3 text-[12px] font-semibold text-[#2563EB]">{msg}</div>}

      {/* Cron status */}
      <div className="bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 mb-4 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <span className={'relative flex h-2.5 w-2.5'}>
            <span className={'absolute inline-flex h-full w-full rounded-full opacity-60 animate-ping ' + (cron?.running ? 'bg-emerald-500' : 'bg-red-400')} />
            <span className={'relative inline-flex rounded-full h-2.5 w-2.5 ' + (cron?.running ? 'bg-emerald-600' : 'bg-red-500')} />
          </span>
          <div>
            <div className="text-[13px] font-bold text-[#111827]">Market Automation Bot (cron)</div>
            <div className="text-[11px] text-[#6B7280]">
              {cron?.running
                ? <>Running · tick every 30s · last tick {cron.lastTick ? new Date(cron.lastTick).toLocaleTimeString('en-IN') : '…'} · {cron.ticks} ticks</>
                : 'Waiting for first tick…'}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-bold text-[#6B7280]">{openMarkets} / {cron?.markets.length ?? markets.length} markets live</span>
          {cron?.markets.map(m => (
            <span key={m.code} className={'text-[10px] font-bold px-2 py-[3px] rounded-full ' + (STATE_STYLES[m.state]?.cls || 'bg-slate-100 text-slate-500')}>
              {m.name}: {STATE_STYLES[m.state]?.label || m.state}
            </span>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {markets.map(m => {
          const sched = parseSched(m.weeklySchedule)
          const today = sched[String(todayIdx)]
          const st = cron?.markets.find(x => x.code === m.code)?.state
          return (
            <div key={m.id} className="bg-white border border-[#E5E7EB] rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-bold text-[14px] text-[#111827]">{m.name}</div>
                  <div className="text-[10.5px] text-[#9CA3AF] font-mono">{m.code} · {m.category}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={'text-[10px] font-bold px-2 py-[3px] rounded-full ' + (STATE_STYLES[st || 'off']?.cls || 'bg-slate-100 text-slate-500')}>
                    {STATE_STYLES[st || 'off']?.label || '—'}
                  </span>
                  <Toggle on={m.isActive} onChange={v => toggleActive(m, v)} />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-3">
                <div className="bg-[#F9FAFB] border border-[#F3F4F6] rounded-xl px-3 py-2">
                  <div className="text-[9.5px] font-bold uppercase text-[#9CA3AF]">Open</div>
                  <div className="font-mono font-bold text-[12.5px] text-[#111827]">{to12(m.openTime).h}:{to12(m.openTime).m} {to12(m.openTime).p}</div>
                </div>
                <div className="bg-[#F9FAFB] border border-[#F3F4F6] rounded-xl px-3 py-2">
                  <div className="text-[9.5px] font-bold uppercase text-[#9CA3AF]">Close</div>
                  <div className="font-mono font-bold text-[12.5px] text-[#111827]">{to12(m.closeTime).h}:{to12(m.closeTime).m} {to12(m.closeTime).p}</div>
                </div>
                <div className="bg-[#F9FAFB] border border-[#F3F4F6] rounded-xl px-3 py-2">
                  <div className="text-[9.5px] font-bold uppercase text-[#9CA3AF]">Bets stop</div>
                  <div className="font-mono font-bold text-[12.5px] text-[#B45309]">{m.betCloseMinutes ?? 5} min before</div>
                </div>
              </div>
              <div className="mt-3 text-[11px] text-[#6B7280]">
                Today ({DAY_LABELS[String(todayIdx)]}):{' '}
                {today
                  ? <span className={today.enabled ? 'font-bold text-[#15803D]' : 'font-bold text-[#B91C1C]'}>{today.enabled ? `${to12(today.open).h}:${to12(today.open).m} ${to12(today.open).p} – ${to12(today.close).h}:${to12(today.close).m} ${to12(today.close).p}` : 'weekly off'}</span>
                  : <span className="font-bold text-[#374151]">default timings</span>}
              </div>
              <div className="mt-2 text-[11px] text-[#6B7280]">
                Games allocated: <b className="text-[#2563EB]">{m.gamesEnabled}</b> / {m.gamesTotal}
              </div>
              <div className="mt-3">
                <OutlineButton onClick={() => openEdit(m)}>Edit Weekly Timings</OutlineButton>
              </div>
            </div>
          )
        })}
      </div>

      {/* Add market modal */}
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Add Market — with timings">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Market name">
            <FormInput value={nm} onChange={e => setNm(e.target.value)} placeholder="e.g. Main Bazaar Morning" />
          </FormField>
          <FormField label="Code (optional — auto from name)">
            <FormInput value={cd} onChange={e => setCd(e.target.value)} placeholder="main_bazar_morning" className="font-mono" />
          </FormField>
          <FormField label="Open result time (AM/PM)">
            <TimeAmPm value={nOpen} onChange={setNOpen} />
          </FormField>
          <FormField label="Close result time (AM/PM)">
            <TimeAmPm value={nClose} onChange={setNClose} />
          </FormField>
          <FormField label="Stop bets (minutes before result)">
            <FormInput type="number" min={0} max={120} value={nBet} onChange={e => setNBet(e.target.value)} />
          </FormField>
        </div>
        <p className="text-[11px] text-[#9CA3AF] mt-3">
          Open betting runs until the open time, close betting until the close time — bids stop the given minutes before each result. Weekly schedule can be customized after creation.
        </p>
        <div className="flex justify-end gap-2 mt-4">
          <OutlineButton onClick={() => setAddOpen(false)}>Cancel</OutlineButton>
          <BlueButton onClick={submitAdd} disabled={adding}>{adding ? 'Creating…' : 'Create Market'}</BlueButton>
        </div>
      </Modal>

      {/* Weekly timings modal */}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={'Weekly Timings — ' + (edit?.name || '')} wide>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 items-end">
          <FormField label="Default Open (fallback)">
            <TimeAmPm value={defOpen} onChange={setDefOpen} />
          </FormField>
          <FormField label="Default Close (fallback)">
            <TimeAmPm value={defClose} onChange={setDefClose} />
          </FormField>
          <FormField label="Stop bets (min before result)">
            <FormInput type="number" min={0} max={120} value={betClose} onChange={e => setBetClose(e.target.value)} />
          </FormField>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="text-left text-[10.5px] uppercase tracking-[0.05em] text-[#9CA3AF] border-b border-[#E5E7EB]">
                <th className="py-2 pr-3">Day</th>
                <th className="py-2 pr-3">Open result time</th>
                <th className="py-2 pr-3">Close result time</th>
                <th className="py-2">Accepting Bids</th>
              </tr>
            </thead>
            <tbody>
              {['0', '1', '2', '3', '4', '5', '6'].map(d => (
                <tr key={d} className={'border-b border-[#F3F4F6] ' + (Number(d) === todayIdx ? 'bg-[#EFF6FF]/50' : '')}>
                  <td className="py-2 pr-3 font-bold text-[#111827]">
                    {DAY_LABELS[d]}{Number(d) === todayIdx ? <span className="text-[9.5px] text-[#2563EB] font-bold ml-1.5">TODAY</span> : ''}
                  </td>
                  <td className="py-2 pr-3">
                    <TimeAmPm value={days[d]?.open || defOpen} onChange={v => setDay(d, { open: v })} />
                  </td>
                  <td className="py-2 pr-3">
                    <TimeAmPm value={days[d]?.close || defClose} onChange={v => setDay(d, { close: v })} />
                  </td>
                  <td className="py-2"><Toggle on={days[d]?.enabled ?? true} onChange={v => setDay(d, { enabled: v })} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-[11px] text-[#9CA3AF] mt-3">
          Times are in AM/PM (12-hour). Bids automatically stop {betClose || 0} minutes before each result time — even if the result is not declared yet. Turn a day off for a weekly off.
        </p>
        <div className="flex justify-end gap-2 mt-3">
          <OutlineButton onClick={() => setEdit(null)}>Cancel</OutlineButton>
          <BlueButton onClick={saveEdit} disabled={saving}>{saving ? 'Saving…' : 'Save Weekly Timings'}</BlueButton>
        </div>
      </Modal>
    </div>
  )
}
