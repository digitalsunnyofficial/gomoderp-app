'use client'

// Download CTA for the public landing page (/) and the official share link
// (/customerapp). Points at the canonical APK URL, served by THIS app from the
// operator's ERP upload (ERP ▸ App Build (APK) → ApkArtifact):
//
//     /apk/sm-gomod.apk   →  https://godmoderp.online/apk/sm-gomod.apk
//
// The operator uploads a new build in the ERP and this link serves it
// instantly — the URL customers already have never changes.
//
// The availability probe is FAIL-OPEN on purpose: if it cannot confirm the
// file (offline preview, cross-origin restriction, slow network) the
// download button STILL renders — a browser navigation to the link is never
// blocked, only the fetch() probe can be. A green "Verified live" badge
// appears once the HEAD check succeeds.

import React, { useEffect, useState } from 'react'
import { Download, ShieldCheck, Smartphone } from 'lucide-react'

const APK_URL = '/apk/sm-gomod.apk'
const APP_VERSION = '1.1.0'

export function DownloadCta() {
  const [apkReady, setApkReady] = useState<boolean | null>(null) // null = checking

  useEffect(() => {
    fetch(APK_URL, { method: 'HEAD' })
      .then(r => setApkReady(r.ok))
      .catch(() => setApkReady(false)) // fail-open: button below still renders
  }, [])

  return (
    <div className="w-full max-w-md mx-auto">
      <a
        href={APK_URL}
        download
        className="group inline-flex items-center justify-center gap-2.5 w-full px-8 py-4 rounded-2xl bg-gradient-to-r from-[#F5C451] to-[#E8A820] text-[#1A1305] text-[16px] font-black shadow-[0_10px_40px_rgba(245,196,81,0.35)] hover:shadow-[0_14px_50px_rgba(245,196,81,0.5)] hover:-translate-y-0.5 transition-all"
      >
        <Download size={19} className="group-hover:translate-y-0.5 transition-transform" />
        Download App (APK · v{APP_VERSION})
      </a>
      <p className="text-[11.5px] text-[rgba(255,255,255,0.45)] mt-3 flex items-center justify-center gap-1.5">
        {apkReady ? <ShieldCheck size={12} className="text-[#7BD88F]" /> : <Smartphone size={12} />}
        {apkReady
          ? 'Verified live · Android 8.0+ · Direct APK install — no Play Store'
          : 'Android 8.0+ · No Play Store needed — direct APK install'}
      </p>
    </div>
  )
}
