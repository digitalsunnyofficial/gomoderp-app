'use client'

import React from 'react'
import { ChevronLeft, ChevronRight, X } from 'lucide-react'

// ────────────────────────────────────────
// SHARED UI COMPONENTS
// ────────────────────────────────────────

export function SectionCard({ title, headerRight, children, className = '' }: { title: string; headerRight?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl overflow-hidden mb-6 ${className}`}>
      <div className="px-5 py-4 bg-[#FFFFFF] border-b border-[#E5E7EB] flex items-center justify-between gap-3">
        <h3 className="font-cinzel text-[13px] font-semibold text-[#3730A3] tracking-wider uppercase">{title}</h3>
        {headerRight}
      </div>
      <div className="p-5">{children}</div>
    </div>
  )
}

export function FormField({ label, children, className = '' }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF]">{label}</label>
      {children}
    </div>
  )
}

export function FormInput({ ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] placeholder:text-[#9CA3AF] w-full"
      {...props}
    />
  )
}

export function FormSelect({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement> & { children: React.ReactNode }) {
  return (
    <select
      className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] w-full appearance-none cursor-pointer"
      style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%235A6E84'/%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 12px center', paddingRight: '32px' }}
      {...props}
    >
      {children}
    </select>
  )
}

export function GoldButton({ children, onClick, type = 'button', disabled = false }: { children: React.ReactNode; onClick?: () => void; type?: 'button' | 'submit'; disabled?: boolean }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      style={{ touchAction: 'manipulation' }}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-semibold bg-gradient-to-br from-[#3730A3] to-[#2E2785] text-[#FFFFFF] transition-all hover:from-[#6366F1] hover:to-[#3730A3] hover:-translate-y-0.5 hover:shadow-[0_4px_12px_rgba(55,48,163,0.3)] disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {children}
    </button>
  )
}

export function OutlineButton({ children, onClick, type = 'button' }: { children: React.ReactNode; onClick?: () => void; type?: 'button' | 'submit' }) {
  return (
    <button
      type={type}
      onClick={onClick}
      style={{ touchAction: 'manipulation' }}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-semibold bg-transparent border border-[#D1D5DB] text-[#6B7280] transition-all hover:border-[#3730A3] hover:text-[#3730A3]"
    >
      {children}
    </button>
  )
}

export function BlueButton({ children, onClick, disabled = false }: { children: React.ReactNode; onClick?: () => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      style={{ touchAction: 'manipulation' }}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-semibold bg-[#0284C7] text-white transition-all hover:bg-[#0369A1] disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {children}
    </button>
  )
}

export function Pagination({ page, totalPages, onPageChange }: { page: number; totalPages: number; onPageChange: (p: number) => void }) {
  const pages = []
  const maxVisible = 5
  let start = Math.max(1, page - Math.floor(maxVisible / 2))
  let end = Math.min(totalPages, start + maxVisible - 1)
  if (end - start < maxVisible - 1) start = Math.max(1, end - maxVisible + 1)

  for (let i = start; i <= end; i++) pages.push(i)

  return (
    <div className="flex items-center gap-1">
      <button
        onClick={() => onPageChange(page - 1)}
        disabled={page <= 1}
        className="w-8 h-8 flex items-center justify-center rounded-md text-xs border border-[#E5E7EB] text-[#6B7280] bg-[#FFFFFF] transition-all hover:border-[#3730A3] hover:text-[#3730A3] disabled:opacity-30 disabled:cursor-default"
      >
        <ChevronLeft size={14} />
      </button>
      {start > 1 && (
        <>
          <button onClick={() => onPageChange(1)} className="w-8 h-8 flex items-center justify-center rounded-md text-xs border border-[#E5E7EB] text-[#6B7280] bg-[#FFFFFF]">1</button>
          {start > 2 && <span className="text-[#9CA3AF] px-1">&hellip;</span>}
        </>
      )}
      {pages.map(p => (
        <button
          key={p}
          onClick={() => onPageChange(p)}
          className={`w-8 h-8 flex items-center justify-center rounded-md text-xs font-semibold transition-all ${p === page ? 'bg-[#3730A3] border border-[#3730A3] text-[#FFFFFF]' : 'border border-[#E5E7EB] text-[#6B7280] bg-[#FFFFFF] hover:border-[#3730A3] hover:text-[#3730A3]'}`}
        >
          {p}
        </button>
      ))}
      {end < totalPages && (
        <>
          {end < totalPages - 1 && <span className="text-[#9CA3AF] px-1">&hellip;</span>}
          <button onClick={() => onPageChange(totalPages)} className="w-8 h-8 flex items-center justify-center rounded-md text-xs border border-[#E5E7EB] text-[#6B7280] bg-[#FFFFFF]">{totalPages}</button>
        </>
      )}
      <button
        onClick={() => onPageChange(page + 1)}
        disabled={page >= totalPages}
        className="w-8 h-8 flex items-center justify-center rounded-md text-xs border border-[#E5E7EB] text-[#6B7280] bg-[#FFFFFF] transition-all hover:border-[#3730A3] hover:text-[#3730A3] disabled:opacity-30 disabled:cursor-default"
      >
        <ChevronRight size={14} />
      </button>
    </div>
  )
}

export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className={`relative bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto ${wide ? 'w-full max-w-4xl' : 'w-full max-w-lg'}`}
        onClick={e => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-[#FFFFFF] border-b border-[#E5E7EB] px-5 py-4 flex items-center justify-between z-10">
          <h3 className="font-cinzel text-[13px] font-semibold text-[#3730A3] tracking-wider uppercase">{title}</h3>
          <button onClick={onClose} className="w-7 h-7 flex items-center justify-center rounded-md text-[#9CA3AF] hover:text-[#DC2626] hover:bg-[rgba(220,38,38,0.1)] transition-all">
            <X size={16} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}
