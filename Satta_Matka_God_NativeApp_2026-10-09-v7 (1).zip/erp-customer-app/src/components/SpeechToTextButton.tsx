'use client'

import React, { useState, useRef, useCallback, useEffect } from 'react'
import { Mic, MicOff, Volume2 } from 'lucide-react'

/* ═══════════════════════════════════════════
   Speech-to-Text Button
   – Only recognises digits 0-9 + keywords
   – Auto-formats based on mode (single/double/triple/group)
   – Appends formatted text to parent textarea on stop
   ═══════════════════════════════════════════ */

export type SpeechMode = 'single' | 'double' | 'triple' | 'group'

interface SpeechToTextButtonProps {
  mode: SpeechMode
  onResult: (formattedText: string) => void
  className?: string
}

/* ── Digit word mapping (English + Hindi) ── */
const DIGIT_WORDS: Record<string, string> = {
  zero: '0', one: '1', two: '2', three: '3', four: '4',
  five: '5', six: '6', seven: '7', eight: '8', nine: '9',
  // Hindi digit words
  ek: '1', do: '2', teen: '3', char: '4',
  paanch: '5', panch: '5', che: '6', saat: '7',
  aath: '8', ath: '8', nau: '9', nav: '9', shunya: '0',
}

const EQUALS_WORDS = ['equals', 'equal', 'barabr', 'barabar', 'baraber']
const RS_WORDS = ['rs', 'rupees', 'rupee', 'rupaye']

/* How many digits form one number-group per mode */
const GROUP_SIZE: Record<SpeechMode, number> = {
  single: 1,
  double: 2,
  triple: 3,
  group: 3,
}

/* ── Transcript formatter ── */
function formatTranscript(transcript: string, mode: SpeechMode): string {
  const groupSize = GROUP_SIZE[mode]
  const tokens = transcript.toLowerCase().trim().split(/[\s,;.]+/)

  const numberParts: string[] = []
  let digitBuffer = ''
  let inAmount = false
  let amountBuffer = ''
  let hasEquals = false

  for (const token of tokens) {
    /* ── Equals keyword → switch to amount mode ── */
    if (EQUALS_WORDS.includes(token)) {
      hasEquals = true
      inAmount = true
      if (digitBuffer) {
        numberParts.push(digitBuffer)
        digitBuffer = ''
      }
      continue
    }

    /* ── Rupee keyword → skip (we append 'rs' at the end) ── */
    if (RS_WORDS.includes(token)) continue

    /* ── Single digit character ── */
    if (/^\d$/.test(token)) {
      if (inAmount) {
        amountBuffer += token
      } else {
        digitBuffer += token
        if (digitBuffer.length === groupSize) {
          numberParts.push(digitBuffer)
          digitBuffer = ''
        }
      }
      continue
    }

    /* ── Multi-digit character sequence (e.g. "150" from speech engine) ── */
    if (/^\d+$/.test(token)) {
      if (inAmount) {
        amountBuffer += token
      } else {
        for (const ch of token) {
          digitBuffer += ch
          if (digitBuffer.length === groupSize) {
            numberParts.push(digitBuffer)
            digitBuffer = ''
          }
        }
      }
      continue
    }

    /* ── Digit word (English / Hindi) ── */
    const digit = DIGIT_WORDS[token]
    if (digit) {
      if (inAmount) {
        amountBuffer += digit
      } else {
        digitBuffer += digit
        if (digitBuffer.length === groupSize) {
          numberParts.push(digitBuffer)
          digitBuffer = ''
        }
      }
      continue
    }

    /* Unknown token → ignore */
  }

  /* Flush remaining digit buffer */
  if (digitBuffer) {
    numberParts.push(digitBuffer)
  }

  /* ── Build final formatted string ── */
  if (mode === 'single' && !hasEquals) {
    /* Single mode without equals → concatenate digits (matches "raw digits" format) */
    const allDigits = numberParts.join('')
    if (!allDigits && !amountBuffer) return ''
    return allDigits + (amountBuffer ? '=' + amountBuffer + 'rs' : '')
  }

  /* Double / Triple / Group modes, or single WITH equals → use comma-separated groups */
  let result = numberParts.join(',')
  if (hasEquals || amountBuffer) {
    result += '=' + amountBuffer + 'rs'
  }
  return result
}

/* ═══════════════════════════════════════════
   Component
   ═══════════════════════════════════════════ */
export function SpeechToTextButton({ mode, onResult, className = '' }: SpeechToTextButtonProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [liveText, setLiveText] = useState('')
  const [isSupported, setIsSupported] = useState(true)
  const recognitionRef = useRef<any>(null)
  const fullTranscriptRef = useRef('')
  const onResultRef = useRef(onResult)

  /* Keep onResult ref fresh */
  useEffect(() => { onResultRef.current = onResult }, [onResult])

  /* Check browser support once on mount */
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const supported = !!(window as any).SpeechRecognition || !!(window as any).webkitSpeechRecognition
      if (!supported) setIsSupported(false)
    }
  }, [])

  const formatCb = useCallback((t: string) => formatTranscript(t, mode), [mode])

  const startRecording = useCallback(() => {
    const API = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!API) return

    const recognition = new API()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = 'en-IN'          // Indian English – handles mixed Hindi-English
    recognition.maxAlternatives = 1

    fullTranscriptRef.current = ''
    setLiveText('')

    recognition.onresult = (event: any) => {
      let full = ''
      for (let i = 0; i < event.results.length; i++) {
        full += event.results[i][0].transcript
      }
      fullTranscriptRef.current = full
      const formatted = formatCb(full)
      setLiveText(formatted || full)
    }

    recognition.onerror = (event: any) => {
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        console.warn('[SpeechToText] error:', event.error)
      }
      // Don't auto-stop on no-speech – let continuous mode handle it
      if (event.error === 'not-allowed') {
        setIsRecording(false)
        setLiveText('')
      }
    }

    recognition.onend = () => {
 /* Auto-restart while user hasn't explicitly stopped */
      if (recognitionRef.current === recognition && isRecording) {
        try { recognition.start() } catch { /* already started */ }
      }
    }

    recognitionRef.current = recognition
    recognition.start()
    setIsRecording(true)
  }, [formatCb, isRecording])

  const stopRecording = useCallback(() => {
    const rec = recognitionRef.current
    if (!rec) return

    rec.onend = null          // prevent auto-restart
    try { rec.stop() } catch { /* already stopped */ }

    const formatted = formatCb(fullTranscriptRef.current)
    if (formatted.trim()) {
      onResultRef.current(formatted)
    }

    recognitionRef.current = null
    setIsRecording(false)
    setLiveText('')
  }, [formatCb])

  const toggle = useCallback(() => {
    if (isRecording) stopRecording()
    else startRecording()
  }, [isRecording, startRecording, stopRecording])

  /* Cleanup on unmount */
  useEffect(() => {
    return () => {
      const rec = recognitionRef.current
      if (rec) { rec.onend = null; rec.abort() }
    }
  }, [])

  if (!isSupported) return null

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <button
        type="button"
        onClick={toggle}
        className={`p-1.5 rounded-lg transition-all select-none ${
          isRecording
            ? 'bg-red-100 text-red-600 animate-pulse'
            : 'bg-slate-100 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600'
        }`}
        title={isRecording ? 'Stop voice input' : 'Start voice input (digits only)'}
      >
        {isRecording ? <MicOff size={14} /> : <Mic size={14} />}
      </button>

      {/* Live preview pill while recording */}
      {isRecording && liveText && (
        <div className="flex items-center gap-1 text-[11px] text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-1 rounded-md max-w-[220px]">
          <Volume2 size={11} className="flex-shrink-0 animate-pulse" />
          <span className="truncate font-mono">{liveText}</span>
        </div>
      )}
    </div>
  )
}
