'use client'

// ────────────────────────────────────────────────────────────────────────────
// DictationFormatButton — Gboard voice-typing → ERP entry format converter
// ────────────────────────────────────────────────────────────────────────────
// WHY GBOARD: the browser SpeechRecognition API proved unreliable on the
// team's devices (duplicated text, dropped words). Google Keyboard (Gboard)
// voice typing recognizes the same speech far more accurately — but a web
// page cannot call Gboard's engine directly. Instead, Gboard TYPES its
// transcript into the focused textarea, and this button + the textarea's
// on-blur hook convert that spoken text into ERP entry format.
//
// FLOW (WhatsApp-style accuracy, zero mic permissions):
//   1. Tap the textarea → Gboard opens
//   2. Tap the Gboard mic 🎤 and speak — raw words appear in the field
//      e.g. "three seven zero barabar thirty rs"
//   3. Tap "Format" (or just leave the field) — spoken lines convert:
//      "three seven zero barabar thirty rs" → "370=30rs"
//      Multi-entry: say "rs" after each amount → each becomes its own line.
//   4. Export / Preview as usual.
//
// SAFETY: only lines that LOOK like dictation (contain number words in
// English/Hindi/Devanagari, or spaced single digits) are converted. Typed
// and pasted content ("370=30₹", "23.42.72.", "13469", "Milan") is never
// modified. Conversion is idempotent — pressing Format repeatedly is safe.
// ────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useRef, useState } from 'react'
import { formatDictationContent } from '@/lib/speech-dictation'

// ── Props mirror the old SpeechMicButton — drop-in replacement ─────────────
interface DictationFormatButtonProps {
  /** Digits per ank before auto-comma: 1=single, 2=double, 3=triple; null = no grouping (group seeds) */
  groupSize: number | null
  /** Read the textarea's current value */
  getValue: () => string
  /** Receive the converted full text (same string that would come from onChange) */
  onText: (fullText: string) => void
}

const TOOLTIP =
  'Dictate with your keyboard\'s voice typing (Gboard mic) into this field, ' +
  'then tap Format: spoken words become numbers — e.g. "one two three barabar ' +
  'fifty rs" → 123=50rs. Say "rs" after each amount to finish an entry. ' +
  'Typed or pasted digits are never changed.'

export function DictationFormatButton({ groupSize, getValue, onText }: DictationFormatButtonProps) {
  const [flash, setFlash] = useState<'' | 'ok' | 'none'>('')
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const getValueRef = useRef(getValue)
  const onTextRef = useRef(onText)
  const groupSizeRef = useRef(groupSize)
  getValueRef.current = getValue
  onTextRef.current = onText
  groupSizeRef.current = groupSize

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  const handleClick = useCallback(() => {
    const raw = getValueRef.current()
    const out = formatDictationContent(raw, groupSizeRef.current)
    if (out !== raw) {
      onTextRef.current(out)
      setFlash('ok')
    } else {
      setFlash('none')
    }
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => setFlash(''), 2000)
  }, [])

  return (
    <div className="flex items-center gap-1.5">
      {flash === 'ok' && (
        <span className="text-[9px] leading-none font-semibold text-emerald-600 whitespace-nowrap">
          ✓ converted
        </span>
      )}
      {flash === 'none' && (
        <span className="text-[9px] leading-none text-slate-400 whitespace-nowrap">
          no spoken text
        </span>
      )}
      <button
        type="button"
        onClick={handleClick}
        title={TOOLTIP}
        className="shrink-0 inline-flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-semibold border border-indigo-600 bg-indigo-600 text-white shadow-sm hover:bg-indigo-700 transition-all cursor-pointer select-none"
      >
        <svg viewBox="0 0 24 24" className="h-3 w-3 fill-current" aria-hidden="true">
          {/* keyboard icon */}
          <path d="M20 5H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm-9 3h2v2h-2V8zm0 3h2v2h-2v-2zM8 8h2v2H8V8zm0 3h2v2H8v-2zm-1 2H5v-2h2v2zm0-3H5V8h2v2zm9 7H8v-2h8v2zm0-4h-2v-2h2v2zm0-3h-2V8h2v2zm3 3h-2v-2h2v2zm0-3h-2V8h2v2z" />
        </svg>
        Format
      </button>
    </div>
  )
}
