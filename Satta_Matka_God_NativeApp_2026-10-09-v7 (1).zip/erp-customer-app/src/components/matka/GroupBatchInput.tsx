'use client'

/**
 * GroupBatchInput — Multi-seed batch input textarea for Group Chart Modes.
 *
 * Features:
 *   - Textarea for entering up to 10 seeds (newline/comma/space separated)
 *   - Live counter: "X of 10 seeds entered"
 *   - Placeholder adapts per selected GroupOption
 *   - Inline validation chips: green = valid, red = invalid with reason
 *
 * This component is presentational — it receives the raw text and validation
 * results, and reports changes via onChange. The parent (page.tsx) owns the
 * state and calls buildGroupBatch() to produce the result.
 */

import React from 'react'
import type { GroupOption, SeedValidationResult } from '@/lib/matka/group-types'
import { GROUP_OPTION_LABELS } from '@/lib/matka/group-types'
import { MAX_SEEDS } from '@/lib/matka/seed-parser'

// ────────────────────────────────────────────────────────────────────────────
// Placeholder text per Group option
// ────────────────────────────────────────────────────────────────────────────
const PLACEHOLDERS: Record<GroupOption, string> = {
  SP: 'Enter SP pannas (e.g. 128, 137, 235)',
  DP: 'Enter DP pannas (e.g. 112, 100, 550)',
  TP: 'Enter TP pannas (e.g. 111, 222, 000)',
  SPDP: 'Enter SP or DP pannas (e.g. 128, 112, 235)',
  SPTP: 'Enter SP or TP pannas (e.g. 128, 111, 235)',
  DPTP: 'Enter DP or TP pannas (e.g. 112, 111, 550)',
  SPDPTP: 'Enter SP, DP, or TP pannas (e.g. 128, 112, 111)',
  'Motor Pana': 'Enter motor seeds (e.g. 4567890, 1234567, 9876543)',
  'SP Motor': 'Enter SP pannas — same data as SP, tagged SP_MOTOR (e.g. 128, 137, 235)',
  'DP Motor': 'Enter DP pannas — same data as DP, tagged DP_MOTOR (e.g. 112, 100, 550)',
  '20 Chart': 'Enter pannas or ank refs (e.g. 137, Ank1, 2)',
  '30 Chart': 'Enter pannas or ank refs (e.g. 139, Ank1, 3)',
  '40 Chart': 'Enter pannas or ank refs (e.g. 149, Ank1, 4)',
  '50 Chart': 'Enter pannas or ank refs (e.g. 128, Ank5, 3)',
  '60 Chart': 'Enter pannas or ank refs (e.g. 128, Ank5, 3)',
  '70 Chart': 'Enter pannas or ank refs (e.g. 128, Ank5, 3)',
  '90 DP Chart': 'Enter pannas or ank refs (e.g. 055, Ank5, 3)',
  '90 ABR Chart': 'Enter pannas or ank refs (e.g. 128, Ank5, 3)',
  'Family Set 4': 'Enter digit-sets or pannas (e.g. 321, 112, 111)',
  'Family Set 6': 'Enter digit-sets or pannas (e.g. 321, 112, 111)',
  'Family Set 8': 'Enter digit-sets or pannas (e.g. 321, 112, 111)',
  'Family Chart': 'Enter digit-sets or pannas (e.g. 321, 112, 111)',
}

// ────────────────────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────────────────────
interface GroupBatchInputProps {
  /** Currently selected Group option */
  option: GroupOption
  /** Current textarea value */
  value: string
  /** Called when textarea content changes */
  onChange: (value: string) => void
  /** Validation results for each seed (computed by parent via buildGroupBatch) */
  seedResults: SeedValidationResult[]
  /** Number of rejected overflow seeds (beyond the 10 cap) */
  overflowCount: number
}

// ────────────────────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────────────────────
export function GroupBatchInput({
  option,
  value,
  onChange,
  seedResults,
  overflowCount,
}: GroupBatchInputProps) {
  const seedCount = seedResults.length
  const validCount = seedResults.filter(s => s.valid).length
  const invalidCount = seedResults.filter(s => !s.valid).length

  return (
    <div className="flex flex-col gap-3">
      {/* Label + counter */}
      <div className="flex items-center justify-between">
        <label className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF]">
          Batch Seeds — {GROUP_OPTION_LABELS[option]}
        </label>
        <span className={`text-[11px] font-semibold font-mono ${seedCount >= MAX_SEEDS ? 'text-[#D97706]' : 'text-[#6B7280]'}`}>
          {seedCount} of {MAX_SEEDS} seeds
        </span>
      </div>

      {/* Textarea */}
      <textarea
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={PLACEHOLDERS[option] || 'Enter seeds (one per line or comma-separated)'}
        rows={4}
        className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg px-3 py-2 text-[13px] text-[#111827] outline-none transition-all focus:border-[#3730A3] focus:shadow-[0_0_0_3px_rgba(55,48,163,0.1)] placeholder:text-[#9CA3AF] w-full resize-y font-mono"
      />

      {/* Validation summary */}
      {(validCount > 0 || invalidCount > 0 || overflowCount > 0) && (
        <div className="flex flex-wrap gap-2 items-center">
          {validCount > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#D1FAE5] text-[#059669]">
              ✓ {validCount} valid
            </span>
          )}
          {invalidCount > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FEE2E2] text-[#DC2626]">
              ✗ {invalidCount} invalid
            </span>
          )}
          {overflowCount > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FEF3C7] text-[#D97706]">
              ⚠ {overflowCount} overflow (max {MAX_SEEDS})
            </span>
          )}
        </div>
      )}

      {/* Invalid seed details */}
      {seedResults.filter(s => !s.valid).length > 0 && (
        <div className="bg-[#FEE2E2] border border-[#FCA5A5] rounded-lg p-2.5 flex flex-col gap-1">
          {seedResults.filter(s => !s.valid).map((s, i) => (
            <div key={i} className="text-[11px] text-[#DC2626] flex items-start gap-1.5">
              <span className="font-mono font-bold flex-shrink-0">"{s.raw}"</span>
              <span className="text-[#991B1B]">— {s.reason || 'Invalid'}</span>
            </div>
          ))}
        </div>
      )}

      {/* Valid seed chips */}
      {seedResults.filter(s => s.valid).length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {seedResults.filter(s => s.valid).map((s, i) => (
            <span key={i} className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-mono font-semibold bg-[#D1FAE5] text-[#059669] border border-[#A7F3D0]">
              {s.cleaned}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}
