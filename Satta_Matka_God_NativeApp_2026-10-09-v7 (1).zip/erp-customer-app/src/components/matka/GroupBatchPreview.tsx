'use client'

/**
 * GroupBatchPreview — Combined preview grid for batch-expanded pannas.
 *
 * Renders the merged pannas grouped by Ank (column 1-10), matching the
 * visual style of the existing Group preview grid in page.tsx.
 *
 * Shows:
 *   - Per-column (ank) panna chips
 *   - Per-column totals
 *   - Grand total
 *   - Invalid seeds warning box (if any seeds failed)
 */

import React from 'react'
import type { GroupBatchResult } from '@/lib/matka/group-types'
import { pannaToAnk } from '@/lib/matka/chart-definitions'
import { getGrandTotal } from '@/lib/matka/group-batch-engine'

// ────────────────────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────────────────────
interface GroupBatchPreviewProps {
  /** The batch result to display */
  result: GroupBatchResult
}

// ────────────────────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────────────────────
export function GroupBatchPreview({ result }: GroupBatchPreviewProps) {
  const { mergedMap, invalidSeeds, entries } = result

  // If no entries at all, show empty state
  if (entries.length === 0 && invalidSeeds.length === 0) {
    return null
  }

  // Build per-column buckets: { [ank: 1-10]: Array<{panna, rate}> }
  const columns: Record<number, Array<{ panna: string; rate: number }>> = {}
  for (let ank = 1; ank <= 10; ank++) columns[ank] = []

  for (const [panna, rate] of mergedMap.entries()) {
    const ank = pannaToAnk(panna)
    if (ank >= 1 && ank <= 10) {
      columns[ank].push({ panna, rate })
    }
  }

  // Per-column totals
  const columnTotals: Record<number, number> = {}
  for (let ank = 1; ank <= 10; ank++) {
    columnTotals[ank] = columns[ank].reduce((sum, e) => sum + e.rate, 0)
  }

  const grandTotal = getGrandTotal(result)
  const totalPannas = mergedMap.size

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h4 className="text-[13px] font-bold text-[#3730A3] uppercase tracking-wider">
          Batch Preview — {totalPannas} unique pannas
        </h4>
        <span className="text-[11px] font-mono text-[#6B7280]">
          {entries.length} total entries (before merge)
        </span>
      </div>

      {/* Invalid seeds warning */}
      {invalidSeeds.length > 0 && (
        <div className="bg-[#FEF3C7] border border-[#FCD34D] rounded-lg p-2.5 flex flex-col gap-1">
          <div className="text-[11px] font-bold text-[#92400E] flex items-center gap-1.5">
            ⚠ {invalidSeeds.length} invalid seed{invalidSeeds.length !== 1 ? 's' : ''} skipped:
          </div>
          {invalidSeeds.map((s, i) => (
            <div key={i} className="text-[10px] text-[#92400E] flex items-start gap-1 ml-3">
              <span className="font-mono font-bold">"{s.raw}"</span>
              <span>— {s.reason}</span>
            </div>
          ))}
        </div>
      )}

      {/* Grid table — same visual style as existing Group preview */}
      <div className="overflow-x-auto border border-[#E5E7EB] rounded-lg">
        <table className="w-full border-collapse" style={{ borderSpacing: 0 }}>
          <thead>
            <tr className="bg-[#FFFFFF]">
              {Array.from({ length: 10 }, (_, i) => i + 1).map(ank => (
                <th
                  key={ank}
                  className="px-2 py-2 text-center text-[12px] font-bold text-[#0284C7] border border-[#E5E7EB] bg-[#FFFFFF] min-w-[80px]"
                >
                  {ank === 10 ? '0' : ank}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {/* Panna chips row */}
            <tr className="bg-[#FFFFFF]">
              {Array.from({ length: 10 }, (_, i) => i + 1).map(ank => (
                <td
                  key={ank}
                  className="px-1.5 py-1.5 align-top border border-[#E5E7EB] bg-[rgba(55,48,163,0.04)]"
                >
                  <div className="flex flex-col gap-0.5 items-center">
                    {columns[ank].length === 0 ? (
                      <span className="text-[10px] text-[#D1D5DB]">-</span>
                    ) : (
                      columns[ank].map((entry, idx) => (
                        <div key={idx} className="text-[10px] leading-tight text-center">
                          <span className="font-mono font-semibold text-[#111827]">{entry.panna}</span>
                          <span className="text-[#6B7280]"> = </span>
                          <span className="font-mono font-semibold text-[#3730A3]">{entry.rate}₹</span>
                        </div>
                      ))
                    )}
                  </div>
                </td>
              ))}
            </tr>
            {/* Per-column totals row */}
            <tr className="bg-[#FFFFFF]">
              {Array.from({ length: 10 }, (_, i) => i + 1).map(ank => (
                <td
                  key={ank}
                  className="px-2 py-2 text-center text-[12px] font-bold font-mono text-[#3730A3] border border-[#E5E7EB] bg-[#FFFFFF]"
                >
                  {columnTotals[ank] > 0 ? `${columnTotals[ank]}₹` : '0₹'}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Footer summary */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-[12px] font-semibold text-[#6B7280]">
          Total Pannas: <span className="font-mono text-[#111827]">{totalPannas}</span>
        </span>
        <span className="text-[14px] font-bold text-[#111827]">
          Grand Total:{' '}
          <span className="font-mono text-[#3730A3]">
            ₹ {grandTotal.toLocaleString('en-IN')}
          </span>
        </span>
      </div>
    </div>
  )
}
