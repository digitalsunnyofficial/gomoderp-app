'use client'

// ──────────────────────────────────────────────────────────
// INFO SCREENS — My Bids · Results & Charts · Wallet · Profile · Notifications
// ──────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react'
import {
  I, appApi, fmt, dtStr, dateLabel, todayStr, daysAgoStr,
  type AppCustomerView, type MarketView, type HomeData,
  STATUS_CHIP, TYPE_CHIP, RATE_LBL_CLIENT,
} from './shell'
import { gameLabel } from '@/lib/matka/games-engine'
import { canonicalPanna } from '@/lib/matka/chart-definitions'
import { LANGUAGES, type Lang } from '@/lib/matka/i18n'

type Toast = (m: string, t?: string) => void

interface BetView {
  id: string; marketCode: string; marketName: string; betDate: string
  slot: string; type: string; num: string; gameCode: string | null
  points: number; rate: number; win: number; status: string; createdAt: string
}

function mkNameFromCode(code: string, markets?: MarketView[]): string {
  if (code.startsWith('st')) return 'Starline ' + code.slice(2).padStart(2, '0') + ':00'
  const m = markets?.find(x => x.code === code)
  return m?.displayName || m?.name || code
}

// ── My Bids ──
export function MyBetsScreen({ lang, wallet, showToast, onExpired }: {
  lang: Lang; wallet: number; showToast: Toast; onExpired: () => void
}) {
  const [filter, setFilter] = useState('all')
  const [bets, setBets] = useState<BetView[]>([])
  const [counts, setCounts] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let live = true
    const load = (withSpinner: boolean) => {
      if (withSpinner) setLoading(true)
      appApi('/api/customer-app/bets?status=' + filter)
        .then(d => {
          if (!live) return
          setBets((d.bets as BetView[]) || [])
          setCounts((d.counts as Record<string, number>) || {})
        })
        .catch(e => {
          if ((e as Error).message === 'SESSION_EXPIRED') onExpired()
          else showToast((e as Error).message, 'err')
        })
        .finally(() => live && setLoading(false))
    }
    load(true)
    // AUTO REFRESH (2026-09): the moment a result is declared, pending bids
    // settle to won/lost — silent 10 s polling keeps this list current.
    const t2 = setInterval(() => load(false), 10000)
    const onVis = () => { if (document.visibilityState === 'visible') load(false) }
    document.addEventListener('visibilitychange', onVis)
    return () => { live = false; clearInterval(t2); document.removeEventListener('visibilitychange', onVis) }
  }, [filter, showToast, onExpired])

  return (
    <>
      <div className="appbar">
        <div className="ttl"><b>My Bids</b><span>{counts.all || 0} total bids</span></div>
        <span className="wchip"><I n="wallet" />{fmt(wallet)}</span>
      </div>
      <div className="pbody">
        <div className="row" style={{ gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
          {['all', 'pending', 'won', 'lost'].map(f => (
            <button key={f} className={'chip ' + (filter === f ? 'c-pink' : 'c-gray')} style={{ padding: '6px 14px' }} onClick={() => setFilter(f)}>
              {f.toUpperCase()} {f === 'all' ? `(${counts.all || 0})` : ''}
            </button>
          ))}
        </div>
        {loading ? <p className="muted small" style={{ padding: 14 }}>Loading…</p> : null}
        {!loading && !bets.length ? <p className="muted small" style={{ padding: '14px 2px' }}>No bids here yet — go play!</p> : null}
        {bets.map(b => (
          <div className="betcard" key={b.id}>
            <div className="bt">
              <b style={{ fontSize: 13 }}>{b.marketName}</b>
              <span className={'chip ' + (STATUS_CHIP[b.status] || 'c-gray')}>{b.status}</span>
            </div>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <div className="row" style={{ gap: 8 }}>
                <span className={'chip ' + (TYPE_CHIP[b.type] || 'c-gray')}>{b.type.toUpperCase()}</span>
                <span className="num-b">{canonicalPanna(b.num)}</span>
                <span className="tiny muted">{b.slot}</span>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="small"><b>{fmt(b.points)}</b> <span className="tiny muted">@1:{b.rate}</span></div>
                <div className="tiny" style={{ color: b.status === 'won' ? '#15803d' : 'var(--mut)' }}>
                  {b.status === 'won' ? 'won ' + fmt(b.win) : 'win pot. ' + fmt(b.points * b.rate)}
                </div>
              </div>
            </div>
            {b.gameCode && !['single', 'jodi', 'sp', 'dp', 'tp', 'hs', 'fs', 'oddeven'].includes(b.gameCode) ? (
              <div className="tiny muted" style={{ marginTop: 5 }}><I n="layers" size={10} /> {gameLabel(b.gameCode)}</div>
            ) : null}
            <div className="tiny muted" style={{ marginTop: 7 }}>{b.betDate} · {dtStr(b.createdAt)}</div>
          </div>
        ))}
      </div>
    </>
  )
}

// ── Results & Charts ──
export interface ResultRow {
  marketCode: string; resultDate: string
  openPanna: string | null; closePanna: string | null
  openDigit: string | null; closeDigit: string | null; jodi: string | null
}
export function ResultsScreen({ markets }: { markets: MarketView[] }) {
  const [tab, setTab] = useState('results')
  const [chartMk, setChartMk] = useState(markets[0]?.code || 'kalyan')
  const [results, setResults] = useState<ResultRow[]>([])
  const [starBoard, setStarBoard] = useState<Array<{ hour: number; panna: string | null; digit: string | null }>>([])
  const curH = new Date().getHours()

  useEffect(() => {
    let live = true
    const load = () => {
      if (tab === 'board') {
        appApi('/api/customer-app/results?starline=1')
          .then(d => { if (live) setStarBoard((d.board as typeof starBoard) || []) })
          .catch(() => {})
        return
      }
      appApi('/api/customer-app/results?market=' + chartMk)
        .then(d => { if (live) setResults((d.results as ResultRow[]) || []) })
        .catch(() => {})
    }
    load()
    // AUTO REFRESH (2026-09): results declared or corrected in the admin panel
    // appear here within seconds — silent 10 s polling + foreground refetch,
    // no manual refresh. Jodi cells stay "awaiting" until BOTH the open and
    // close digits are declared, then fill in automatically.
    const t2 = setInterval(load, 10000)
    const onVis = () => { if (document.visibilityState === 'visible') load() }
    document.addEventListener('visibilitychange', onVis)
    return () => { live = false; clearInterval(t2); document.removeEventListener('visibilitychange', onVis) }
  }, [chartMk, tab])

  const allMarketChips = [...markets.map(m => ({ code: m.code, name: m.displayName || m.name }))]

  return (
    <>
      <div className="appbar">
        <div className="ttl"><b>Results &amp; Charts</b><span>Official declared results</span></div>
      </div>
      <div className="pbody">
        <div className="tabs" style={{ marginTop: 0 }}>
          {[['results', 'Results'], ['jodi', 'Jodi Chart'], ['panel', 'Panel Chart'], ['board', 'Starline']].map(([k, l]) => (
            <button key={k} className={'tab' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>{l}</button>
          ))}
        </div>
        {tab !== 'board' ? (
          <div className="achips" style={{ background: '#fff', border: '1px solid var(--line)', borderRadius: 12, padding: '7px 6px 2px' }}>
            {allMarketChips.map(m => (
              <button key={m.code} className={'achip' + (chartMk === m.code ? ' on' : '')} style={{ fontFamily: 'Inter', fontSize: 11 }} onClick={() => setChartMk(m.code)}>
                {m.name}
              </button>
            ))}
          </div>
        ) : null}
        {tab === 'results' ? results.map(r => (
          <div key={r.resultDate}>
            <div style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--mut)', textTransform: 'uppercase', margin: '12px 2px 7px' }}>
              {dateLabel(r.resultDate)}
            </div>
            <div className="resrow">
              <div>
                <b style={{ fontSize: 13 }}>{mkNameFromCode(r.marketCode, markets)}</b>
                <div className="mono small muted" style={{ marginTop: 2 }}>
                  {r.openPanna ? r.openPanna + '-' + r.openDigit : '—'} <span style={{ color: '#cbd5e1' }}>×</span> {r.closePanna ? r.closePanna + '-' + r.closeDigit : '—'}
                </div>
              </div>
              {r.jodi ? <span className="jodi-b">{r.jodi}</span> : <span className="chip c-orange">awaiting</span>}
            </div>
          </div>
        )) : null}
        {tab === 'results' && !results.length ? <p className="muted small" style={{ padding: 12 }}>No results declared yet for this market.</p> : null}
        {tab === 'jodi' ? <JodiChart results={results} mkName={mkNameFromCode(chartMk, markets)} /> : null}
        {tab === 'panel' ? <PanelChart results={results} mkName={mkNameFromCode(chartMk, markets)} /> : null}
        {tab === 'board' ? <StarBoard board={starBoard} curH={curH} /> : null}
      </div>
    </>
  )
}

export function JodiChart({ results, mkName }: { results: ResultRow[]; mkName: string }) {
  // month navigation — historical chart data (backend backfill) becomes visible
  const [monthOff, setMonthOff] = React.useState(0)
  const base = new Date()
  const n = new Date(base.getFullYear(), base.getMonth() + monthOff, 1)
  const y = n.getFullYear(), mo = n.getMonth()
  const days = new Date(y, mo + 1, 0).getDate()
  const start = (new Date(y, mo, 1).getDay() + 6) % 7
  const jodiMap: Record<string, string | null> = {}
  results.forEach(r => { jodiMap[r.resultDate] = r.jodi })
  const rows: React.ReactNode[] = []
  let day = 1
  while (day <= days) {
    const cells: React.ReactNode[] = []
    for (let c = 0; c < 7; c++) {
      if ((day === 1 && c < start) || day > days) {
        cells.push(<td key={c} />)
      } else {
        const ds = `${y}-${String(mo + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
        const j = jodiMap[ds] ?? null
        const red = j && j[0] === j[1]
        cells.push(<td key={c} className={red ? 'rd' : ''}>{j || <span style={{ color: '#cbd5e1' }}>·</span>}</td>)
        day++
      }
    }
    rows.push(<tr key={day}>{cells}</tr>)
  }
  const head = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  return (
    <div className="card" style={{ marginTop: 12, padding: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 9 }}>
        <b className="small">{mkName} — Jodi Chart</b>
        <span className="row" style={{ gap: 6, alignItems: 'center' }}>
          <button onClick={() => setMonthOff(o => o - 1)} style={{ border: '1px solid var(--line)', borderRadius: 8, width: 24, height: 24, fontWeight: 800, color: 'var(--mut)' }} aria-label="previous month">‹</button>
          <span className="chip c-pink">{n.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</span>
          <button onClick={() => setMonthOff(o => Math.min(o + 1, 0))} disabled={monthOff >= 0} style={{ border: '1px solid var(--line)', borderRadius: 8, width: 24, height: 24, fontWeight: 800, color: 'var(--mut)', opacity: monthOff >= 0 ? .4 : 1 }} aria-label="next month">›</button>
        </span>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="jtable">
          <tbody>
            <tr>{head.map(d => <th key={d}>{d}</th>)}</tr>
            {rows}
          </tbody>
        </table>
      </div>
      <p className="tiny muted" style={{ marginTop: 8 }}>Red cells = repeating-digit jodis · data fills as results are declared</p>
    </div>
  )
}

export function PanelChart({ results, mkName }: { results: ResultRow[]; mkName: string }) {
  // ── dpboss-style weekly panel chart (operator rule 2026-10) ──
  // Rows = weekly periods ("26/07 to 02/08"), columns = the days of that
  // week. Each cell shows the OPEN panna digits stacked VERTICALLY on the
  // left, the JODI big + horizontal in the centre and the CLOSE panna
  // digits stacked VERTICALLY on the right — exactly like the reference
  // chart. Days without a declared result render red "**".
  const weeks = React.useMemo(() => {
    const groups = new Map<string, Map<string, ResultRow>>()
    const mondayOf = (ds: string): string => {
      const d = new Date(ds + 'T12:00:00Z')
      const shift = (d.getUTCDay() + 6) % 7 // 0 = Monday
      d.setUTCDate(d.getUTCDate() - shift)
      return d.toISOString().slice(0, 10)
    }
    for (const r of results) {
      const wk = mondayOf(r.resultDate)
      if (!groups.has(wk)) groups.set(wk, new Map())
      groups.get(wk)!.set(r.resultDate, r)
    }
    return [...groups.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([start, dayMap]) => {
        const s = new Date(start + 'T12:00:00Z')
        const e = new Date(s); e.setUTCDate(e.getUTCDate() + 6)
        const dmy = (d: Date) => `${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')}`
        const days: Array<{ ds: string; r: ResultRow | null }> = []
        for (let i = 0; i < 7; i++) {
          const d = new Date(s); d.setUTCDate(d.getUTCDate() + i)
          const ds = d.toISOString().slice(0, 10)
          days.push({ ds, r: dayMap.get(ds) || null })
        }
        return { label: `${dmy(s)} to ${dmy(e)}`, days }
      })
  }, [results])

  const digitCol = (panna: string | null, color: string): React.ReactNode => (
    <span style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1.05, fontSize: 9.5, fontWeight: 700, color, fontFamily: 'var(--font)' }}>
      {panna ? panna.split('').map((ch, i) => <span key={i}>{ch}</span>) : <span style={{ color: '#dc2626' }}>**</span>}
    </span>
  )

  return (
    <div style={{ marginTop: 12 }}>
      <div className="sech" style={{ marginTop: 0 }}>
        <b>{mkName} — Panel Chart</b>
        <span className="chip c-pink">Weekly</span>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="jtable" style={{ minWidth: 560 }}>
          <tbody>
            {weeks.map(wk => (
              <tr key={wk.label}>
                <td style={{ fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap', color: 'var(--mut)', minWidth: 86 }}>{wk.label}</td>
                {wk.days.map(d => {
                  const red = !!d.r?.jodi && d.r.jodi[0] === d.r.jodi[1]
                  return (
                    <td key={d.ds}>
                      {d.r ? (
                        <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
                          {digitCol(d.r.openPanna, '#111827')}
                          <b style={{ fontSize: 14.5, color: red ? '#dc2626' : '#111827', minWidth: 20, textAlign: 'center' }}>{d.r.jodi || '**'}</b>
                          {digitCol(d.r.closePanna, '#111827')}
                        </span>
                      ) : (
                        <span style={{ color: '#dc2626', fontWeight: 800, fontSize: 12 }}>**</span>
                      )}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!results.length ? <p className="muted small" style={{ padding: 12 }}>No results yet.</p> : null}
      <p className="tiny muted" style={{ marginTop: 8 }}>Open panna digits vertical · jodi horizontal · close panna digits vertical · red = repeating-digit jodi / missing result · data fills weekly as results are declared</p>
    </div>
  )
}

function StarBoard({ board, curH }: { board: Array<{ hour: number; panna: string | null; digit: string | null }>; curH: number }) {
  return (
    <div style={{ marginTop: 12 }}>
      <div className="sech" style={{ marginTop: 0 }}>
        <b>BABA STARLINE — Today&apos;s Board</b>
        <span className="chip c-grn">{curH}:00 running</span>
      </div>
      <div className="grid g4">
        {Array.from({ length: 24 }, (_, h) => {
          const r = board.find(b => b.hour === h)
          return (
            <div key={h} className="bcell" style={h === curH ? { borderColor: 'var(--gold)', background: '#fffbeb' } : h < curH ? undefined : { opacity: .55 }}>
              <small>{String(h).padStart(2, '0')}:00 {h === curH ? '· LIVE' : h < curH ? '· done' : '· upcoming'}</small>
              <b>{r && r.panna ? r.panna + '-' + r.digit : h === curH ? '…' : '—'}</b>
            </div>
          )
        })}
      </div>
      <p className="tiny muted" style={{ marginTop: 9 }}>Declared hourly · panna + derived digit</p>
    </div>
  )
}

// ── Wallet ──
interface TxnView { id: string; type: string; amount: number; balanceAfter: number; remark: string; createdAt: string }
export function WalletScreen({ tr, customer, onAddPoints, onWithdraw, showToast, onExpired }: {
  tr: (k: string) => string
  customer: AppCustomerView | null
  onAddPoints: () => void
  onWithdraw: () => void
  showToast: Toast
  onExpired: () => void
}) {
  const [txns, setTxns] = useState<TxnView[]>([])
  const [pendingFunds, setPendingFunds] = useState<Array<{ id: string; amount: number; utr: string; createdAt: string }>>([])
  const [pendingWithdraws, setPendingWithdraws] = useState<Array<{ id: string; amount: number; createdAt: string }>>([])
  const TI: Record<string, [string, string, string]> = {
    deposit: ['arrow-down-circle', 'rgba(34,197,94,.14)', '#15803d'],
    win: ['trophy', 'rgba(245,158,11,.14)', '#b45309'],
    bet: ['receipt', 'rgba(100,116,139,.12)', '#475569'],
    withdraw_hold: ['arrow-up-circle', 'rgba(239,68,68,.12)', '#b91c1c'],
    withdraw_refund: ['arrow-down-circle', 'rgba(34,197,94,.14)', '#15803d'],
    withdraw_paid: ['arrow-up-circle', 'rgba(239,68,68,.12)', '#b91c1c'],
    admin_credit: ['plus-circle', 'rgba(13,148,136,.12)', '#0f766e'],
    admin_debit: ['minus-circle', 'rgba(239,68,68,.12)', '#b91c1c'],
  }
  const load = () => {
    appApi('/api/customer-app/wallet')
      .then(d => {
        setTxns((d.transactions as TxnView[]) || [])
        setPendingFunds((d.pendingFunds as typeof pendingFunds) || [])
        setPendingWithdraws((d.pendingWithdraws as typeof pendingWithdraws) || [])
      })
      .catch(e => {
        if ((e as Error).message === 'SESSION_EXPIRED') onExpired()
        else showToast((e as Error).message, 'err')
      })
  }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(load, [])

  if (!customer) return <div className="pbody"><p className="muted small">{tr('loading')}</p></div>
  return (
    <>
      <div className="appbar">
        <div className="ttl"><b>{tr('wallet')}</b><span>Points · deposits · withdrawals</span></div>
      </div>
      <div className="pbody">
        <div className="wcard">
          <small>WALLET POINTS</small>
          <div className="amt">{fmt(customer.wallet)}</div>
          <div className="tiny" style={{ opacity: .85 }}>{customer.name} · {customer.mobile}</div>
          <div className="wbtns">
            <button className="btn btn-g" onClick={onAddPoints}><I n="arrow-down-circle" />{tr('add_points')}</button>
            <button className="btn" style={{ background: 'rgba(255,255,255,.22)', color: '#fff' }} onClick={onWithdraw}>
              <I n="arrow-up-circle" />{tr('withdraw_title')}
            </button>
          </div>
        </div>
        {pendingFunds.length || pendingWithdraws.length ? (
          <>
            <div className="sech" style={{ marginTop: 2 }}><b>Pending Requests</b></div>
            {pendingFunds.map(f => (
              <div className="resrow" key={f.id}>
                <div><b style={{ fontSize: 12.5 }}>Deposit {fmt(f.amount)}</b><div className="tiny muted">{dtStr(f.createdAt)} · {f.utr}</div></div>
                <span className="chip c-orange">pending</span>
              </div>
            ))}
            {pendingWithdraws.map(w => (
              <div className="resrow" key={w.id}>
                <div><b style={{ fontSize: 12.5 }}>Withdraw {fmt(w.amount)}</b><div className="tiny muted">{dtStr(w.createdAt)} · amount on hold</div></div>
                <span className="chip c-orange">pending</span>
              </div>
            ))}
          </>
        ) : null}
        <div className="sech"><b>Transactions</b><span className="chip c-gray">{txns.length}</span></div>
        {txns.map(t => {
          const ti = TI[t.type] || ['circle', '#f1f5f9', '#64748b']
          return (
            <div className="txn" key={t.id}>
              <div className="ti" style={{ background: ti[1], color: ti[2] }}><I n={ti[0]} /></div>
              <div>
                <div className="lbl">{t.remark}</div>
                <div className="sub">{dtStr(t.createdAt)} · bal {fmt(t.balanceAfter)}</div>
              </div>
              <div className={'amt ' + (t.amount > 0 ? 'plus' : 'minus')}>{t.amount > 0 ? '+' : ''}{fmt(t.amount)}</div>
            </div>
          )
        })}
        {!txns.length ? <p className="muted small" style={{ padding: 12 }}>No transactions yet.</p> : null}
      </div>
    </>
  )
}

// ── Profile ──
export function ProfileScreen({ customer, tr, go, onLogout, onChangePassword, onSelectLanguage }: {
  customer: AppCustomerView | null
  tr: (k: string) => string
  go: (s: string) => void
  onLogout: () => void
  onChangePassword: () => void
  onSelectLanguage: () => void
}) {
  if (!customer) return <div className="pbody"><p className="muted small">{tr('loading')}</p></div>
  const langNative = LANGUAGES.find(l => l.code === (customer.language || 'en'))?.native || 'English'
  return (
    <>
      <div className="appbar">
        <div className="ttl"><b>{tr('nav_profile')}</b><span>Account &amp; settings</span></div>
      </div>
      <div className="pbody">
        <div className="card" style={{ padding: 20, textAlign: 'center', marginBottom: 12 }}>
          <div className="pav">{customer.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}</div>
          <b style={{ fontSize: 15, display: 'block', marginTop: 10 }}>{customer.name}</b>
          <p className="tiny muted mono" style={{ marginTop: 2 }}>{customer.mobile}</p>
          <div className="row" style={{ justifyContent: 'center', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
            <span className={'chip ' + (customer.status === 'active' ? 'c-grn' : 'c-red')}>{customer.status}</span>
            <span className={'chip ' + (customer.canBet ? 'c-teal' : 'c-red')}>Betting {customer.canBet ? 'On' : 'Off'}</span>
            <span className={'chip ' + (customer.canWithdraw ? 'c-teal' : 'c-red')}>Withdraw {customer.canWithdraw ? 'On' : 'Off'}</span>
          </div>
          {customer.agentName ? (
            <p className="tiny muted" style={{ marginTop: 9 }}><I n="user" size={12} style={{ verticalAlign: -2 }} /> Agent: <b style={{ color: 'var(--ink)' }}>{customer.agentName}</b></p>
          ) : null}
          <div className="row" style={{ marginTop: 14, gap: 9 }}>
            <button className="btn btn-g" style={{ flex: 1 }} onClick={() => go('wallet')}><I n="wallet" />{fmt(customer.wallet)}</button>
          </div>
        </div>
        <div className="card">
          <button className="prow-i" onClick={() => go('mybets')}><I n="receipt" />{tr('nav_bids')}<span className="ar"><I n="chevron-right" size={15} /></span></button>
          <button className="prow-i" onClick={() => go('notifs')}><I n="bell" />Notifications<span className="ar"><I n="chevron-right" size={15} /></span></button>
          <button className="prow-i" onClick={onSelectLanguage}><I n="circle" />{tr('language')}<span className="tiny muted" style={{ marginLeft: 8 }}>{langNative}</span><span className="ar"><I n="chevron-right" size={15} /></span></button>
          <button className="prow-i" onClick={onChangePassword}><I n="key-round" />{tr('change_password')}<span className="ar"><I n="chevron-right" size={15} /></span></button>
          <button className="prow-i" onClick={() => alert('Open this site in Chrome → Menu → Add to Home screen to install the app')}><I n="download" />Install App<span className="ar"><I n="chevron-right" size={15} /></span></button>
          <button className="prow-i" style={{ borderBottom: 'none' }} onClick={() => alert('Support: 24×7 on WhatsApp')}><I n="headphones" />Support<span className="ar"><I n="chevron-right" size={15} /></span></button>
        </div>
        <div className="card" style={{ marginTop: 12 }}>
          <div className="prow-i" style={{ cursor: 'default', borderBottom: 'none' }}>
            <I n="info" /><span className="tiny muted">Satta Matka God · v1.2 · customer app</span>
          </div>
        </div>
        <button className="btn" style={{ width: '100%', marginTop: 12, background: '#fee2e2', color: '#b91c1c', padding: 13 }} onClick={onLogout}>
          <I n="log-out" />{tr('logout')}
        </button>
      </div>
    </>
  )
}

// ── Notifications ──
export function NotifsScreen({ onBack }: { onBack: () => void }) {
  const [notifs, setNotifs] = useState<Array<{ id: string; icon: string; text: string; createdAt: string }>>([])
  useEffect(() => {
    appApi('/api/customer-app/notifications')
      .then(d => setNotifs((d.notifications as typeof notifs) || []))
      .catch(() => {})
  }, [])
  return (
    <>
      <div className="appbar">
        <button className="ibtn" onClick={onBack}><I n="chevron-left" /></button>
        <div className="ttl"><b>Notifications</b><span>{notifs.length} messages</span></div>
      </div>
      <div className="pbody">
        {notifs.map(n => (
          <div className="resrow" key={n.id}>
            <div style={{ width: 34, height: 34, borderRadius: 11, background: '#ede9fe', color: 'var(--p1)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              <I n={n.icon} />
            </div>
            <div style={{ flex: 1 }}>
              <b style={{ fontSize: 12.5 }}>{n.text}</b>
              <div className="tiny muted" style={{ marginTop: 2 }}>{dtStr(n.createdAt)}</div>
            </div>
          </div>
        ))}
        {!notifs.length ? <p className="muted small" style={{ padding: 12 }}>No notifications yet.</p> : null}
      </div>
    </>
  )
}
