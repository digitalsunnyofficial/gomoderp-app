'use client'

// ──────────────────────────────────────────────────────────
// CUSTOMER APP SHELL — CSS, icons, types, API helpers
// Faithful port of the Satta Matka God Android app prototype
// ──────────────────────────────────────────────────────────
import React from 'react'
import {
  Signal, Wifi, BatteryFull, Gem, Bell, Wallet, Plus, Zap, ChevronLeft, ChevronRight,
  Check, X, Receipt, Trophy, User, Home, Star, ArrowDownCircle, ArrowUpCircle,
  PlusCircle, Moon, Lock, LogIn, KeyRound, Download, Headphones, FlaskConical,
  Info, LogOut, Megaphone, Layers, Circle, AlertTriangle, MinusCircle,
  Play, Clock, Target, Hash, Link2, LayoutGrid, Boxes, GitMerge, Puzzle,
  Dices, Cog, Shapes, Sparkles, Split, TrendingUp, PartyPopper, Timer,
} from 'lucide-react'

export const APP_CSS = `
:root{--p1:#6d28d9;--p2:#db2777;--gold:#f59e0b;--gold2:#fbbf24;--grn:#16a34a;--tile:#dcfce7;--tilet:#166534;--pink:#fce7f3;--pinkT:#be185d;--ink:#1e293b;--bg:#f4f6fb;--line:#e2e8f0;--mut:#64748b}
.mb-root *{box-sizing:border-box;margin:0;padding:0}
.mb-root{font-family:'Inter',system-ui,sans-serif;background:#dfe4ee;color:var(--ink);-webkit-font-smoothing:antialiased}
.mb-root h1,.mb-root h2,.mb-root h3,.mb-root .dsp{font-family:'Sora','Inter',sans-serif}
.mb-root button{font-family:inherit;cursor:pointer;border:none;background:none;color:inherit}
.mb-root input,.mb-root select,.mb-root textarea{font-family:inherit;font-size:13px;border:1px solid var(--line);border-radius:10px;padding:9px 12px;background:#fff;color:var(--ink);outline:none;width:100%}
.mb-root input:focus{border-color:var(--p2);box-shadow:0 0 0 3px rgba(219,39,119,.12)}
.mb-root .mono{font-family:ui-monospace,Menlo,monospace}
.mb-root .muted{color:var(--mut)}.mb-root .small{font-size:12px}.mb-root .tiny{font-size:11px}
.mb-root .row{display:flex;align-items:center;gap:10px}
.mb-root .btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;font-size:13px;font-weight:700;padding:10px 16px;border-radius:12px}
.mb-root .btn svg{width:15px;height:15px}
.mb-root .btn-g{background:linear-gradient(135deg,var(--gold),var(--gold2));color:#78350f;box-shadow:0 4px 14px rgba(245,158,11,.35)}
.mb-root .btn-g:active{transform:scale(.97)}
.mb-root .btn-w{background:#fff;border:1px solid var(--line)}
.mb-root .btn-p{background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff}
.mb-root .btn:disabled{opacity:.45;cursor:not-allowed}
.mb-root .chip{display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;padding:3px 9px;border-radius:999px}
.mb-root .c-grn{background:#dcfce7;color:#15803d}.mb-root .c-gray{background:#f1f5f9;color:#64748b}.mb-root .c-red{background:#fee2e2;color:#b91c1c}.mb-root .c-gold{background:#fef3c7;color:#b45309}.mb-root .c-pink{background:var(--pink);color:var(--pinkT)}
.mb-root .c-teal{background:#ccfbf1;color:#0f766e}.mb-root .c-cyan{background:#cffafe;color:#0e7490}.mb-root .c-orange{background:#ffedd5;color:#c2410c}.mb-root .c-yellow{background:#fef08a;color:#854d0e}
.mb-root .card{background:#fff;border:1px solid var(--line);border-radius:16px}
.mb-root .stage{min-height:100vh;display:flex;justify-content:center;background:radial-gradient(900px 500px at 50% -100px,#c7d2ea,#dfe4ee)}
.mb-root .phone{width:100%;max-width:412px;min-height:100vh;background:var(--bg);position:relative;box-shadow:0 0 0 1px rgba(109,40,217,.15),0 30px 90px rgba(30,41,59,.25);display:flex;flex-direction:column;overflow:hidden}
@media(max-width:520px){.mb-root .phone{box-shadow:none;max-width:none}.mb-root .stage{background:var(--bg)}}
.mb-root .sb{background:linear-gradient(92deg,var(--p1),var(--p2));color:#fff;display:flex;justify-content:space-between;align-items:center;padding:6px 16px 4px;font-size:11px;font-weight:600}
.mb-root .sb .r{display:flex;gap:5px;align-items:center}
.mb-root .sb svg{width:13px;height:13px}
.mb-root .appbar{background:linear-gradient(92deg,var(--p1),var(--p2));color:#fff;padding:8px 14px 12px;display:flex;align-items:center;gap:10px}
.mb-root .appbar .ttl{flex:1;min-width:0}
.mb-root .appbar .ttl b{font-size:15px;font-family:'Sora';display:block}
.mb-root .appbar .ttl span{font-size:10.5px;opacity:.85;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mb-root .ibtn{width:34px;height:34px;border-radius:11px;background:rgba(255,255,255,.18);display:grid;place-items:center;color:#fff;flex-shrink:0}
.mb-root .ibtn:active{background:rgba(255,255,255,.32)}
.mb-root .ibtn svg{width:16px;height:16px}
.mb-root .wchip{background:rgba(255,255,255,.92);color:#78350f;font-size:11.5px;font-weight:800;padding:6px 11px;border-radius:999px;display:flex;align-items:center;gap:5px;white-space:nowrap}
.mb-root .wchip svg{width:13px;height:13px}
.mb-root .pbody{flex:1;padding:14px 12px 92px;overflow-y:auto}
.mb-root .bnav{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:412px;background:rgba(255,255,255,.97);backdrop-filter:blur(10px);border-top:1px solid var(--line);display:flex;z-index:25;padding:6px 0 8px}
.mb-root .btab{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 0 2px;font-size:9.5px;font-weight:700;color:#94a3b8;position:relative}
.mb-root .btab svg{width:20px;height:20px}
.mb-root .btab.active{color:var(--p2)}
.mb-root .btab.active::before{content:'';position:absolute;top:-7px;width:34px;height:3px;border-radius:99px;background:linear-gradient(90deg,var(--p1),var(--p2))}
.mb-root .splash{min-height:100vh;background:linear-gradient(160deg,var(--p1),var(--p2) 60%,#9d174d);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;gap:14px}
.mb-root .splash .lg{width:84px;height:84px;border-radius:26px;background:rgba(255,255,255,.16);display:grid;place-items:center;animation:mbpulse 1.6s infinite}
.mb-root .splash .lg svg{width:40px;height:40px}
@keyframes mbpulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}
.mb-root .marq{background:#fff;border:1px solid var(--line);border-radius:12px;padding:8px 12px;display:flex;gap:8px;align-items:center;overflow:hidden;margin-bottom:12px}
.mb-root .marq .tag{background:var(--pinkT);color:#fff;font-size:9px;font-weight:800;padding:3px 7px;border-radius:6px;flex-shrink:0}
.mb-root .marq .txt{white-space:nowrap;font-size:12px;font-weight:600;color:var(--pinkT);animation:mbslide 12s linear infinite}
@keyframes mbslide{0%{transform:translateX(100%)}100%{transform:translateX(-100%)}}
.mb-root .banner{border-radius:16px;padding:18px 16px;color:#fff;min-height:92px;display:flex;flex-direction:column;justify-content:center;margin-bottom:12px;position:relative;overflow:hidden}
.mb-root .banner::after{content:'';position:absolute;right:-30px;top:-30px;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,.15)}
.mb-root .banner b{font-family:'Sora';font-size:19px}
.mb-root .banner .dots{display:flex;gap:4px;margin-top:10px}
.mb-root .banner .dots i{width:5px;height:5px;border-radius:99px;background:rgba(255,255,255,.4)}
.mb-root .banner .dots i.on{background:#fff;width:14px}
.mb-root .sech{display:flex;justify-content:space-between;align-items:center;margin:14px 2px 8px}
.mb-root .sech b{font-size:14px}
.mb-root .sech button{font-size:11px;font-weight:700;color:var(--p2)}
.mb-root .mcard{background:#fff;border:1px solid var(--line);border-radius:16px;padding:13px;margin-bottom:10px}
.mb-root .mcard .top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}
.mb-root .mcard h4{font-size:14.5px;font-family:'Sora'}
.mb-root .mcard .tm{font-size:11px;color:var(--mut);margin-top:2px}
.mb-root .mcard .slots{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}
.mb-root .slotb{border-radius:10px;padding:7px 9px;font-size:11px;background:#f8fafc}
.mb-root .slotb small{display:block;font-size:9px;color:var(--mut)}
.mb-root .acc{color:var(--grn);font-weight:800}.mb-root .cls{color:#94a3b8;font-weight:600}
.mb-root .resrow{background:#fff;border:1px solid var(--line);border-radius:13px;padding:11px 13px;display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.mb-root .jodi-b{font-family:ui-monospace,monospace;font-weight:800;font-size:16px;color:#fff;background:linear-gradient(135deg,var(--p1),var(--p2));border-radius:9px;padding:4px 11px}
.mb-root .subbar{display:flex;align-items:center;gap:9px;background:linear-gradient(92deg,var(--p1),var(--p2));color:#fff;padding:9px 12px}
.mb-root .subbar .info{flex:1;min-width:0}
.mb-root .subbar .info b{font-size:14px;font-family:'Sora';display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mb-root .subbar .info span{font-size:10px;opacity:.85}
.mb-root .sess{display:flex;gap:7px;margin:11px 0 0}
.mb-root .sess button{flex:1;padding:9px;border-radius:11px;background:#fff;border:1px solid var(--line);font-size:12.5px;font-weight:700}
.mb-root .sess button.on{background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff;border-color:transparent}
.mb-root .tabs{display:flex;background:#ede9fe;border-radius:12px;padding:4px;gap:3px;margin:12px 0 10px;overflow-x:auto}
.mb-root .tab{flex:1;padding:8px 6px;border-radius:9px;font-size:11px;font-weight:800;color:#6d28d9;white-space:nowrap}
.mb-root .tab.on{background:#fff;color:var(--p2);box-shadow:0 2px 8px rgba(30,41,59,.1)}
.mb-root .ratebar{display:flex;justify-content:space-between;align-items:center;background:#fff;border:1px dashed #d8b4fe;border-radius:11px;padding:8px 12px;margin-bottom:11px}
.mb-root .ratebar .rr{font-size:11px;color:var(--mut)}.mb-root .ratebar .rr b{color:var(--pinkT);font-size:13px}
.mb-root .grid{display:grid;gap:8px}
.mb-root .g5{grid-template-columns:repeat(5,1fr)}
.mb-root .g6{grid-template-columns:repeat(6,1fr)}
.mb-root .g4{grid-template-columns:repeat(4,1fr)}
.mb-root .tile{background:var(--tile);border:1px solid #bbf7d0;border-radius:11px;text-align:center;padding:7px 2px 8px}
.mb-root .tile .tn{font-weight:800;font-size:13.5px;color:var(--tilet);font-family:ui-monospace,monospace}
.mb-root .tile input{margin-top:5px;width:100%;border:1px solid #bbf7d0;border-radius:7px;padding:4px 2px;font-size:11.5px;text-align:center;font-weight:700;color:var(--ink);background:#fff;height:28px}
.mb-root .tile.has input{background:#fef3c7;border-color:var(--gold);color:#78350f}
.mb-root .tile.big .tn{font-size:15px;padding:2px 0}
.mb-root .achips{display:flex;gap:6px;overflow-x:auto;padding-bottom:4px;margin-bottom:10px}
.mb-root .achip{background:var(--pink);color:var(--pinkT);border:1px solid #fbcfe8;font-weight:800;font-size:13px;border-radius:10px;padding:7px 13px;flex-shrink:0;font-family:ui-monospace,monospace}
.mb-root .achip.on{background:var(--pinkT);color:#fff}
.mb-root .pickrow{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}
.mb-root .pick{background:#ede9fe;color:#5b21b6;font-weight:700;font-size:12px;border-radius:9px;padding:6px 11px;font-family:ui-monospace,monospace}
.mb-root .pick.on{background:var(--p1);color:#fff}
.mb-root .closed{background:#fee2e2;border:1px solid #fecaca;color:#b91c1c;border-radius:12px;padding:10px 13px;font-size:12px;font-weight:700;margin-bottom:11px;display:flex;gap:8px;align-items:center}
.mb-root .closed svg{width:15px;height:15px;flex-shrink:0}
.mb-root .slip{background:#fff;border:1px solid var(--line);border-radius:16px;box-shadow:0 4px 18px rgba(30,41,59,.08);padding:12px 13px;margin:14px 0 4px}
.mb-root .slip-list{max-height:130px;overflow-y:auto;margin-bottom:8px}
.mb-root .srow{display:flex;align-items:center;gap:7px;padding:6px 0;border-bottom:1px dashed var(--line);font-size:12px}
.mb-root .srow .rm{color:#cbd5e1;padding:3px}.mb-root .srow .rm:active{color:#b91c1c}
.mb-root .srow .rm svg{width:13px;height:13px}
.mb-root .foot{display:flex;align-items:center;gap:10px}
.mb-root .foot .tot{flex:1}
.mb-root .foot .tot .a{font-size:10px;color:var(--mut);font-weight:700}
.mb-root .foot .tot .b{font-size:14px;font-weight:800}
.mb-root .foot .tot .b em{font-style:normal;color:var(--pinkT)}
.mb-root .wcard{background:linear-gradient(125deg,var(--p1),var(--p2));border-radius:20px;color:#fff;padding:20px;position:relative;overflow:hidden;margin-bottom:14px}
.mb-root .wcard::after{content:'';position:absolute;right:-40px;top:-40px;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,.13)}
.mb-root .wcard small{opacity:.85;font-size:10.5px;font-weight:700;letter-spacing:.06em}
.mb-root .wcard .amt{font-size:28px;font-weight:800;font-family:'Sora';margin:4px 0 2px}
.mb-root .wbtns{display:flex;gap:9px;margin-top:14px;position:relative;z-index:1}
.mb-root .wbtns .btn{flex:1}
.mb-root .txn{display:flex;gap:11px;align-items:center;padding:11px 3px;border-bottom:1px solid var(--line)}
.mb-root .txn .ti{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;flex-shrink:0}
.mb-root .txn .ti svg{width:16px;height:16px}
.mb-root .txn .lbl{font-size:12.5px;font-weight:700}
.mb-root .txn .sub{font-size:10.5px;color:var(--mut)}
.mb-root .txn .amt{margin-left:auto;font-weight:800;font-size:13px;white-space:nowrap}
.mb-root .plus{color:#15803d}.mb-root .minus{color:#b91c1c}
.mb-root .betcard{background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin-bottom:9px}
.mb-root .betcard .bt{display:flex;justify-content:space-between;align-items:center;margin-bottom:7px}
.mb-root .num-b{font-family:ui-monospace,monospace;font-weight:800;font-size:14px;background:#ede9fe;color:#5b21b6;border-radius:8px;padding:2px 9px}
.mb-root .jtable{border-collapse:collapse;width:100%;font-size:10.5px}
.mb-root .jtable th{background:#ede9fe;color:#5b21b6;padding:6px 3px;font-size:9px;border:1px solid #e9d5ff}
.mb-root .jtable td{border:1px solid #e9d5ff;text-align:center;padding:6px 2px;font-family:ui-monospace,monospace;font-weight:700;color:var(--ink);min-width:26px;height:30px}
.mb-root .jtable td.rd{color:#dc2626}
.mb-root .prow{display:flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:11px;padding:9px 12px;margin-bottom:7px;font-family:ui-monospace,monospace}
.mb-root .prow .pd{width:66px;font-size:10.5px;color:var(--mut);font-family:'Inter'}
.mb-root .prow .pv{font-weight:800;font-size:13.5px}
.mb-root .prow .pj{margin-left:auto;background:#f3e8ff;color:#6b21a8;border-radius:8px;padding:2px 9px;font-weight:800}
.mb-root .bcell{background:#fff;border:1px solid var(--line);border-radius:10px;text-align:center;padding:7px 2px;font-family:ui-monospace,monospace}
.mb-root .bcell small{display:block;font-size:8.5px;color:var(--mut);font-family:'Inter'}
.mb-root .bcell b{font-size:12px}
.mb-root .pav{width:64px;height:64px;border-radius:20px;background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff;display:grid;place-items:center;font-size:22px;font-weight:800;font-family:'Sora';margin:0 auto}
.mb-root .prow-i{display:flex;align-items:center;gap:12px;padding:13px 14px;border-bottom:1px solid var(--line);font-size:13.5px;font-weight:600;width:100%;text-align:left}
.mb-root .prow-i svg{width:17px;height:17px;color:var(--p2)}
.mb-root .prow-i .ar{margin-left:auto;color:#cbd5e5}.mb-root .prow-i .ar svg{width:15px;height:15px}
.mb-root .hstrip{display:flex;gap:6px;overflow-x:auto;padding:2px 2px 8px}
.mb-root .hchip{flex-shrink:0;background:#fff;border:1px solid var(--line);border-radius:11px;padding:8px 12px;text-align:center}
.mb-root .hchip small{display:block;font-size:8.5px;color:var(--mut);font-weight:700}
.mb-root .hchip b{font-size:13px;font-family:ui-monospace,monospace}
.mb-root .hchip.on{background:linear-gradient(135deg,var(--p1),var(--p2));border-color:transparent;color:#fff}
.mb-root .hchip.on small{color:rgba(255,255,255,.8)}
.mb-root .hchip.done{opacity:.45}
.mb-root .overlay{position:fixed;inset:0;background:rgba(30,41,59,.55);display:flex;align-items:flex-end;justify-content:center;z-index:60}
.mb-root .modal{background:#fff;border-radius:22px 22px 0 0;max-width:412px;width:100%;padding:20px 18px 24px;max-height:85vh;overflow:auto}
.mb-root .modal h3{font-size:15px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center}
.mb-root .modal label{display:block;font-size:10px;color:var(--mut);font-weight:800;letter-spacing:.05em;margin:12px 0 4px}
.mb-root .bank{background:#f8fafc;border:1px solid var(--line);border-radius:12px;padding:11px 13px;margin:10px 0;font-size:12px}
.mb-root .bank .br{display:flex;justify-content:space-between;padding:3px 0}
.mb-root .bank .br b{font-family:ui-monospace,monospace}
.mb-root #mbtoast{position:fixed;bottom:96px;left:50%;transform:translateX(-50%) translateY(16px);background:#1e293b;color:#fff;padding:10px 20px;border-radius:999px;font-size:12.5px;font-weight:700;opacity:0;transition:.25s;z-index:90;pointer-events:none;max-width:92%;text-align:center}
.mb-root #mbtoast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.mb-root #mbtoast.err{background:#b91c1c}.mb-root #mbtoast.ok{background:#0f766e}
/* ── Market card v2 (reference: BOLO567) — time badges / name+result / status bar ── */
.mb-root .mcard2{background:#fff;border:1px solid var(--line);border-radius:18px;margin-bottom:12px;overflow:hidden;box-shadow:0 2px 10px rgba(30,41,59,.05)}
.mb-root .mcard2 .mtimes{display:flex;gap:7px;padding:10px 10px 0}
.mb-root .mcard2 .tb{flex:1;display:flex;align-items:center;justify-content:center;gap:5px;font-size:10.5px;font-weight:800;padding:7px 4px;border-radius:999px;white-space:nowrap}
.mb-root .mcard2 .tb svg{width:12px;height:12px;flex-shrink:0}
.mb-root .mcard2 .tb.o{background:#fef3c7;color:#92400e}
.mb-root .mcard2 .tb.c{background:#451a03;color:#fde68a}
.mb-root .mcard2 .mmid{display:flex;align-items:center;gap:10px;padding:11px 12px 12px}
.mb-root .mcard2 .mico{width:44px;height:44px;border-radius:13px;background:linear-gradient(135deg,#fef3c7,#fde68a);display:grid;place-items:center;color:#b45309;flex-shrink:0}
.mb-root .mcard2 .mico svg{width:21px;height:21px}
.mb-root .mcard2 .mmidC{flex:1;min-width:0;text-align:center}
.mb-root .mcard2 .mmidC h4{font-family:'Sora';font-size:15.5px;letter-spacing:.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mb-root .mcard2 .mres{display:inline-block;margin-top:5px;font-family:ui-monospace,monospace;font-weight:800;font-size:15px;letter-spacing:.05em;background:#fff;border:1.5px solid var(--line);border-radius:999px;padding:4px 14px;color:var(--ink)}
.mb-root .mcard2 .mres.out{border-color:#e9d5ff;background:#faf5ff;color:#7e22ce}
.mb-root .mcard2 .mplay{width:46px;height:46px;border-radius:999px;display:grid;place-items:center;color:#fff;flex-shrink:0;box-shadow:0 3px 12px rgba(30,41,59,.18)}
.mb-root .mcard2 .mplay svg{width:20px;height:20px}
.mb-root .mcard2 .mplay.go{background:linear-gradient(135deg,#16a34a,#22c55e)}
.mb-root .mcard2 .mplay.no{background:linear-gradient(135deg,#dc2626,#ef4444)}
.mb-root .mcard2 .mplay.res{background:linear-gradient(135deg,#7c3aed,#a855f7)}
.mb-root .mcard2 .mplay:active{transform:scale(.94)}
.mb-root .mcard2 .mstat{display:flex;align-items:center;justify-content:center;gap:7px;font-size:11.5px;font-weight:800;letter-spacing:.04em;padding:9px 8px;color:#fff}
.mb-root .mcard2 .mstat svg{width:13px;height:13px}
.mb-root .mcard2 .mstat.run{background:linear-gradient(90deg,#15803d,#16a34a,#15803d)}
.mb-root .mcard2 .mstat.stop{background:linear-gradient(90deg,#b91c1c,#dc2626,#b91c1c)}
.mb-root .mcard2 .mstat.res{background:linear-gradient(90deg,#6d28d9,#9333ea,#6d28d9)}
.mb-root .mcard2 .mstat.off{background:#64748b}
.mb-root .mcard2 .mstat .cd{font-family:ui-monospace,monospace;background:rgba(255,255,255,.22);border-radius:999px;padding:1px 9px;font-size:11px;letter-spacing:.06em}
/* ── Big centered prompts (market closed / result declared) ── */
.mb-root .pov{position:fixed;inset:0;background:rgba(15,23,42,.62);display:flex;align-items:center;justify-content:center;z-index:80;padding:22px;animation:mbfade .18s ease}
@keyframes mbfade{from{opacity:0}to{opacity:1}}
@keyframes mbpop{from{transform:scale(.86);opacity:0}to{transform:scale(1);opacity:1}}
.mb-root .pmodal{background:#fdf6ec;border-radius:24px;width:100%;max-width:330px;overflow:hidden;animation:mbpop .22s ease;text-align:center;box-shadow:0 24px 70px rgba(15,23,42,.4)}
.mb-root .pmodal .ph{padding:20px 18px 14px;color:#fff}
.mb-root .pmodal .ph.closed{background:linear-gradient(160deg,#f43f5e,#dc2626)}
.mb-root .pmodal .ph.result{background:linear-gradient(160deg,#7c3aed,#db2777)}
.mb-root .pmodal .ph .pic{width:64px;height:64px;border-radius:20px;background:rgba(255,255,255,.18);display:grid;place-items:center;margin:0 auto}
.mb-root .pmodal .ph .pic svg{width:32px;height:32px}
.mb-root .pmodal .pb{padding:16px 18px 18px}
.mb-root .pmodal .pt{font-family:'Sora';font-size:18px;color:var(--ink)}
.mb-root .pmodal .ps{font-size:13px;font-weight:800;color:#b91c1c;margin-top:5px;letter-spacing:.03em}
.mb-root .pmodal .ps.g{color:#7e22ce}
.mb-root .pmodal .ptimes{display:flex;align-items:center;margin:14px 0 4px;background:#fff;border-radius:14px;padding:10px 8px;border:1px solid var(--line)}
.mb-root .pmodal .ptimes>div{flex:1}
.mb-root .pmodal .ptimes small{display:block;font-size:9px;font-weight:800;color:#94a3b8;letter-spacing:.08em}
.mb-root .pmodal .ptimes b{font-size:13.5px;color:var(--ink)}
.mb-root .pmodal .ptimes .sep{flex:0 0 1px;height:30px;background:var(--line)}
.mb-root .pmodal .rpill{display:inline-block;margin-top:10px;font-family:ui-monospace,monospace;font-weight:800;font-size:21px;letter-spacing:.06em;background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff;border-radius:14px;padding:8px 18px}
.mb-root .pmodal .rstat{margin-top:12px;border-radius:14px;padding:11px 10px;font-weight:800;font-size:14.5px}
.mb-root .pmodal .rstat.win{background:#dcfce7;color:#15803d;border:1px solid #bbf7d0}
.mb-root .pmodal .rstat.lose{background:#fee2e2;color:#b91c1c;border:1px solid #fecaca}
.mb-root .pmodal .rmeta{display:flex;justify-content:center;gap:14px;margin-top:10px;font-size:10.5px;color:var(--mut)}
.mb-root .pmodal .rmeta b{color:var(--ink)}
.mb-root .pmodal .pok{width:100%;margin-top:14px;padding:13px;border-radius:14px;background:#fde68a;color:#78350f;font-weight:800;font-size:13.5px;letter-spacing:.03em}
.mb-root .pmodal .pok:active{transform:scale(.97)}
/* ── Game picker cards (Single / Jodi / SP / DP / TP …) ── */
.mb-root .gametabs{display:flex;gap:8px;margin:12px 0 10px;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x proximity;-webkit-overflow-scrolling:touch;padding:2px 2px 8px;scrollbar-width:none;-ms-overflow-style:none}
.mb-root .gametabs::-webkit-scrollbar{display:none}
.mb-root .gametabs:after{content:'';flex:0 0 2px}
.mb-root .gtab{background:#fff;border:1.5px solid var(--line);border-radius:14px;padding:9px 4px 8px;display:flex;flex-direction:column;align-items:center;gap:5px;transition:.15s;flex:0 0 auto;width:88px;scroll-snap-align:start}
.mb-root .gtab .gi{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:#f1f5f9;color:#64748b}
.mb-root .gtab .gi svg{width:17px;height:17px}
.mb-root .gtab .gn{font-size:10px;font-weight:800;color:#475569;text-align:center;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.mb-root .gtab .gr{font-size:8.5px;font-weight:800;color:#94a3b8;letter-spacing:.02em}
.mb-root .gtab.on{border-color:var(--p2);background:#FDF2F8;box-shadow:0 3px 12px rgba(219,39,119,.16)}
.mb-root .gtab.on .gi{background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff}
.mb-root .gtab.on .gn{color:var(--pinkT)}
.mb-root .gtab.on .gr{color:var(--p2)}
.mb-root .gtab:active{transform:scale(.95)}
/* ── Live countdown pill (play screen) ── */
.mb-root .cdwrap{display:flex;align-items:center;justify-content:center;gap:8px;border-radius:13px;padding:9px 12px;margin-bottom:10px;font-weight:800;font-size:12px;letter-spacing:.04em}
.mb-root .cdwrap.run{background:linear-gradient(90deg,#ecfdf5,#d1fae5);color:#065f46;border:1px solid #a7f3d0}
.mb-root .cdwrap.stop{background:#fee2e2;color:#b91c1c;border:1px solid #fecaca}
.mb-root .cdwrap .cdt{font-family:ui-monospace,monospace;font-size:15px;letter-spacing:.08em}
.mb-root .cdwrap svg{width:14px;height:14px}
`

const ICONS: Record<string, React.ComponentType<{ size?: number | string; className?: string; style?: React.CSSProperties }>> = {
  signal: Signal, wifi: Wifi, 'battery-full': BatteryFull, gem: Gem, bell: Bell,
  wallet: Wallet, plus: Plus, zap: Zap, 'chevron-left': ChevronLeft, 'chevron-right': ChevronRight,
  check: Check, x: X, receipt: Receipt, trophy: Trophy, user: User, home: Home, star: Star,
  'arrow-down-circle': ArrowDownCircle, 'arrow-up-circle': ArrowUpCircle, 'plus-circle': PlusCircle,
  'minus-circle': MinusCircle, moon: Moon, lock: Lock, 'log-in': LogIn, 'key-round': KeyRound,
  download: Download, headphones: Headphones, 'flask-conical': FlaskConical, info: Info,
  'log-out': LogOut, megaphone: Megaphone, layers: Layers, circle: Circle, 'alert-triangle': AlertTriangle,
  play: Play, clock: Clock, target: Target, hash: Hash, 'link-2': Link2, 'layout-grid': LayoutGrid,
  boxes: Boxes, 'git-merge': GitMerge, puzzle: Puzzle, dices: Dices, cog: Cog, shapes: Shapes,
  sparkles: Sparkles, split: Split, 'trending-up': TrendingUp, party: PartyPopper, timer: Timer,
}

// Icon per game code — used by the game-picker cards on the play screen
export const GAME_ICONS: Record<string, string> = {
  single: 'target', jodi: 'link-2', sp: 'hash', dp: 'layout-grid', tp: 'boxes',
  hs: 'git-merge', hsb: 'git-merge', fs: 'puzzle', oddeven: 'split',
  'sp-motor': 'cog', 'dp-motor': 'cog', motor: 'cog', spdp: 'shapes', sptp: 'shapes',
  dptp: 'shapes', spdptp: 'shapes', 'family-4': 'shapes', 'family-6': 'shapes', 'family-8': 'shapes',
  family: 'shapes',
  'chart-20': 'dices', 'chart-30': 'dices', 'chart-40': 'dices', 'chart-50': 'dices',
  'chart-60': 'dices', 'chart-70': 'dices', 'chart-90dp': 'dices', 'chart-abr': 'dices',
  'dp-50': 'dices', 'dp-60': 'dices', 'dp-70': 'dices', 'dp-90': 'dices', 'dp-90ab': 'dices',
}

// Icon by prototype name
export function I({ n, size = 16, className, style }: { n: string; size?: number | string; className?: string; style?: React.CSSProperties }) {
  const C = ICONS[n] || Circle
  return <C size={size} className={className} style={style} />
}

// ── API helper (Bearer token stored in localStorage) ──
export const TOKEN_KEY = 'mb_token'

export async function appApi(url: string, options?: RequestInit): Promise<Record<string, unknown>> {
  const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
      ...options?.headers,
    },
  })
  if (res.status === 401) {
    if (typeof window !== 'undefined') localStorage.removeItem(TOKEN_KEY)
    throw new Error('SESSION_EXPIRED')
  }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as { error?: string }).error || 'Request failed')
  return data as Record<string, unknown>
}

export function fmt(n: number | string | null | undefined): string {
  return '₹' + Number(n || 0).toLocaleString('en-IN')
}
export function iso(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
export function daysAgoStr(n: number): string {
  const d = new Date(); d.setDate(d.getDate() - n); return iso(d)
}
export function todayStr(): string { return iso(new Date()) }
export function nowStr(): string {
  return new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true })
}
export function dtStr(v: string | Date): string {
  return new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true })
}
export function dateLabel(ds: string): string {
  return new Date(ds + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })
}

// ── Shared view types ──
export interface SlipItem {
  key: string; mk: string; slot: string; type: string
  num: string; pts: number; rate: number; label: string
  gameCode?: string | null
}
export interface AppCustomerView {
  id: string; name: string; mobile: string; wallet: number
  status: string; canBet: boolean; canWithdraw: boolean
  language?: string; approvalStatus?: string
  agentName?: string | null  // agent the customer is filed under ("" = none)
}
export interface GameAllocView {
  code: string; name: string; base: string; session: string
  expansion: string; icon: string; erpMapping: string; rate: number; minPoints: number
}
export interface TodayResultView {
  openPanna: string | null; closePanna: string | null
  openDigit: string | null; closeDigit: string | null
  jodi: string | null; declaredAt: string; updatedAt?: string
}
export interface MySummaryView { bids: number; staked: number; winAmount: number; won: number; lost: number }
export interface MarketView {
  id: string; code: string; name: string; category: string
  phase?: string; session?: string; displayName?: string
  openTime: string; closeTime: string; openAccepting: boolean; closeAccepting: boolean
  betClosingMinutes?: number
  marketStatus?: string
  isOn?: boolean
  resultDeclared?: boolean
  todayResult?: TodayResultView | null
  mySummary?: MySummaryView
  games: GameAllocView[]
}
export interface HomeData {
  notice: string
  banners: Array<{ t: string; s: string; bg: string }>
  markets: MarketView[]
  latestResults: Array<{ marketCode: string; marketName: string; date: string; open: string; close: string; jodi: string | null }>
  starline: { nextHour: number; nextAccepting: boolean; board: Array<{ hour: number; panna: string | null; digit: string | null }>; starlines?: Array<{ code: string; name: string; hour: number; minute: number; betClosingMinutes: number; accepting: boolean; panna: string | null; digit: string | null }> }
}

export const STATUS_CHIP: Record<string, string> = { pending: 'c-orange', won: 'c-grn', lost: 'c-gray' }
export const TYPE_CHIP: Record<string, string> = {
  single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow',
  hs: 'c-pink', fs: 'c-pink', oddeven: 'c-cyan', tp: 'c-yellow',
}
export const RATE_LBL_CLIENT: Record<string, string> = {
  single: 'Single', jodi: 'Jodi', sp: 'SP Pana', dp: 'DP Pana',
  hs: 'Half Sangam', fs: 'Full Sangam', oddeven: 'Odd/Even', tp: 'TP Pana',
}

// Save the customer's language (silent — used by the ask screen + profile switcher)
export async function saveLanguage(lang: string): Promise<boolean> {
  try {
    await appApi('/api/customer-app/me', { method: 'PATCH', body: JSON.stringify({ language: lang }) })
    return true
  } catch { return false }
}
