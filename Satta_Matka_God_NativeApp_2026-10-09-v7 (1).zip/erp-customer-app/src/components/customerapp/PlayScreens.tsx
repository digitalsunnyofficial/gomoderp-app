'use client'

// ──────────────────────────────────────────────────────────
// PLAY SCREENS — main market play + starline hourly games
//   • sessions labelled "Open" / "Close"
//   • game tabs driven by the ERP Game Allocation per market
//   • grid games: Single Digit, Jodi, Single/Double/Triple
//     Pana, Half/Full Sangam, Odd/Even
//   • seed games (Motor / SP-DP-TP combos / Family Sets /
//     50·60·70·90 charts): enter seed + points → CALCULATE →
//     expansion preview → review → add to slip
//   • live chart preview under the picked ank/panna/digit
//   • paste WhatsApp data → auto-calc → review → bet
// ──────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useState } from 'react'
import { I, fmt, todayStr, GAME_ICONS, appApi, type MarketView, type SlipItem, type GameAllocView } from './shell'
import {
  SPB, DPB, TP, RATE_LBL, rateFor, deriveDigit,
  slotAccepting, starHourAccepting, starlineName, secsLeftToClose, fmtCountdown,
  parseQuickData, type QuickParsed,
} from '@/lib/matka/app-engine'
import { expandGame, gameLabel, type ExpandRow } from '@/lib/matka/games-engine'
import { canonicalPanna } from '@/lib/matka/chart-definitions'
import { JodiChart, PanelChart, type ResultRow } from './InfoScreens'
import { t, type Lang } from '@/lib/matka/i18n'

type Toast = (m: string, t?: string) => void

// Operator-canonical panna spelling for every grid/picker (ascending
// digits, 0 last: 012→120, 595→559). Settlement is digit-set based, so
// this is presentation + bet-number canonicalization in ONE place.
const SPB_C: Record<string, string[]> = Object.fromEntries(
  Object.entries(SPB).map(([k, v]) => [k, v.map(canonicalPanna)]))
const DPB_C: Record<string, string[]> = Object.fromEntries(
  Object.entries(DPB).map(([k, v]) => [k, v.map(canonicalPanna)]))




type SlipInputFn = (
  inp: HTMLInputElement, key: string, mk: string, slot: string,
  type: string, num: string, rate: number, mkName: string, gameCode?: string | null
) => void

// UI kind for a game code
type Kind = 'single' | 'jodi' | 'panna' | 'tp' | 'hs' | 'hsb' | 'fs' | 'oddeven' | 'seed'
function kindOf(g: GameAllocView | null, code: string): Kind {
  if (!g) {
    if (code === 'single') return 'single'
    if (code === 'jodi') return 'jodi'
    if (code === 'sp' || code === 'dp') return 'panna'
    if (code === 'tp') return 'tp'
    if (code === 'hs') return 'hs'
    if (code === 'hsb') return 'hsb'
    if (code === 'fs') return 'fs'
    if (code === 'oddeven') return 'oddeven'
    return 'seed'
  }
  if (g.base === 'digits') return 'seed'
  if (g.expansion !== 'none' && g.expansion !== 'sp' && g.expansion !== 'dp' && g.expansion !== 'tp') return 'seed'
  if (g.code === 'single') return 'single'
  if (g.code === 'jodi') return 'jodi'
  if (g.code === 'sp' || g.code === 'dp') return 'panna'
  if (g.code === 'tp') return 'tp'
  if (g.code === 'hs') return 'hs'
  if (g.code === 'hsb') return 'hsb'
  if (g.code === 'fs') return 'fs'
  if (g.code === 'oddeven') return 'oddeven'
  return 'seed'
}

// Icon name for a game card — catalog map first, kind-based fallback
function iconForGame(g: GameAllocView): string {
  return GAME_ICONS[g.code] || (kindOf(g, g.code) === 'seed' ? 'flask-conical' : 'sparkles')
}

// ── Bet Slip (shared) ──
function Slip({ tr, slip, removeSlip, clearSlip, onSubmit, disabled }: {
  tr: (k: string) => string
  slip: SlipItem[]
  removeSlip: (i: number) => void
  clearSlip: () => void
  onSubmit: () => void
  disabled?: boolean
}) {
  const pts = slip.reduce((a, s) => a + s.pts, 0)
  return (
    <div className="slip">
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
        <b className="small">{tr('bet_slip')} ({slip.length})</b>
        {slip.length ? <button className="tiny" style={{ color: '#b91c1c', fontWeight: 800 }} onClick={clearSlip}>{tr('clear_all')}</button> : null}
      </div>
      {slip.length ? (
        <div className="slip-list">
          {slip.map((s, i) => (
            <div className="srow" key={s.key}>
              <span className={'chip ' + (s.type === 'hs' || s.type === 'hsb' || s.type === 'fs' ? 'c-pink' : 'c-gray')}>{s.type.toUpperCase()}</span>
              <span className="mono" style={{ fontWeight: 800 }}>{canonicalPanna(s.num)}</span>
              <span className="tiny muted" style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.label.split('·')[0]}</span>
              <b>{s.pts} pts</b>
              <button className="rm" onClick={() => removeSlip(i)}><I n="x" size={13} /></button>
            </div>
          ))}
        </div>
      ) : <p className="tiny muted" style={{ padding: '5px 0' }}>{tr('enter_points')}</p>}
      <div className="foot">
        <div className="tot">
          <div className="a">{tr('bids')}: {slip.length}</div>
          <div className="b">{tr('points')}: <em>{pts}</em></div>
        </div>
        <button className="btn btn-g" style={{ padding: '13px 26px', fontSize: 14 }} disabled={disabled} onClick={onSubmit}>
          <I n="check" />{tr('submit')}
        </button>
      </div>
    </div>
  )
}

function Tile({ mk, mkName, slot, type, num, big, rate, gameCode, slip, slipInput }: {
  mk: string; mkName: string; slot: string; type: string; num: string; big?: boolean
  rate: number; gameCode: string | null
  slip: SlipItem[]; slipInput: SlipInputFn
}) {
  const key = mk + '|' + slot + '|' + type + '|' + num
  const e = slip.find(x => x.key === key)
  return (
    <div className={'tile' + (e ? ' has' : '') + (big ? ' big' : '')}>
      <div className="tn">{num}</div>
      <input
        type="number" inputMode="numeric" min={1} placeholder="-" defaultValue={e ? e.pts : ''}
        onInput={ev => slipInput(ev.target as HTMLInputElement, key, mk, slot, type, num, rate, mkName, gameCode)}
      />
    </div>
  )
}

// ── Live chart preview: the chart for the picked digit/panna renders in real time ──
function ChartPreview({ mode, ank, session, marketName, slip }: {
  mode: string; ank: number; session: string; marketName: string; slip: SlipItem[]
}) {
  const chip = (n: string) => {
    const inSlip = slip.some(s => s.num === n)
    return (
      <span key={n} className={'pick' + (inSlip ? ' on' : '')} style={{ fontFamily: 'ui-monospace,monospace' }}>{n}</span>
    )
  }
  let title = ''
  let body: React.ReactNode = null
  if (mode === 'single') {
    title = 'Single Digit Chart — 0 to 9'
    body = <div className="pickrow">{Array.from({ length: 10 }, (_, i) => chip(String(i)))}</div>
  } else if (mode === 'jodi') {
    title = 'Jodi Chart — 00 to 99'
    body = <div className="pickrow">{Array.from({ length: 100 }, (_, j) => chip(String(j).padStart(2, '0')))}</div>
  } else if (mode === 'sp' || mode === 'dp') {
    const U = mode === 'sp' ? SPB_C : DPB_C
    title = (mode === 'sp' ? 'Single Panna' : 'Double Pana') + ' Chart — ank ' + ank
    body = <div className="pickrow">{U[ank].map(chip)}</div>
  } else if (mode === 'tp') {
    title = 'Triple Pana Chart'
    body = <div className="pickrow">{TP.map(chip)}</div>
  }
  return (
    <div className="card" style={{ padding: 12, marginTop: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 8 }}>
        <b className="small">{title}</b>
        <span className="chip c-teal">LIVE PREVIEW · {marketName} · {session.toUpperCase()}</span>
      </div>
      {body}
      <p className="tiny muted" style={{ marginTop: 8 }}>Highlighted numbers are already in your slip — the chart updates as you pick.</p>
    </div>
  )
}

// ── Paste WhatsApp data → auto-calc → review → add to slip ──
function PasteModal({ market, session, tr, onClose, onAdd, showToast }: {
  market: MarketView; session: string; tr: (k: string) => string
  onClose: () => void
  onAdd: (items: Array<{ num: string; type: string; points: number }>) => number
  showToast: Toast
}) {
  const [text, setText] = useState('')
  const parsed = useMemo(() => parseQuickData(text), [text])
  const total = parsed.items.reduce((a, i) => a + i.points, 0)
  const typeChip: Record<string, string> = { single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow', tp: 'c-yellow' }

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>{tr('paste_title')}<button onClick={onClose} style={{ color: '#94a3b8' }}><I n="x" /></button></h3>
        <p className="tiny muted" style={{ marginBottom: 8 }}>
          {market.name} · <b>{session === 'open' ? tr('open') : tr('close')}</b> {tr('session_word')} — {tr('paste_hint')}
        </p>
        <textarea
          rows={6}
          placeholder={'1,2,5 = 100\n70 = 50\n128 = 25'}
          value={text}
          onChange={e => setText(e.target.value)}
          style={{ fontFamily: 'ui-monospace,monospace', fontSize: 12.5, lineHeight: 1.55 }}
        />
        {parsed.items.length ? (
          <div className="card" style={{ padding: 10, marginTop: 10 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
              <b className="small">{tr('auto_calc')} ({parsed.items.length})</b>
              <span className="chip c-gold">TOTAL {total} pts</span>
            </div>
            <div className="slip-list" style={{ maxHeight: 150 }}>
              {parsed.items.map((it, i) => (
                <div className="srow" key={i}>
                  <span className={'chip ' + (typeChip[it.type] || 'c-gray')}>{it.type.toUpperCase()}</span>
                  <span className="mono" style={{ fontWeight: 800 }}>{it.num}</span>
                  <span className="tiny muted" style={{ flex: 1 }}>{RATE_LBL[it.type] || it.type}</span>
                  <b>{it.points} pts</b>
                </div>
              ))}
            </div>
          </div>
        ) : null}
        {parsed.errors.length ? (
          <p className="tiny" style={{ color: '#b91c1c', marginTop: 8 }}>{tr('skipped')} {parsed.errors.length}: <span className="mono">{parsed.errors.slice(0, 3).join(' · ')}</span>{parsed.errors.length > 3 ? ' …' : ''}</p>
        ) : null}
        <button
          className="btn btn-g" style={{ width: '100%', marginTop: 12, padding: 13 }}
          disabled={!parsed.items.length}
          onClick={() => {
            const n = onAdd(parsed.items)
            showToast(n + ' ' + tr('bids_added'), 'ok')
            onClose()
          }}
        >
          <I n="check" />{tr('review_add')} {parsed.items.length ? `(${parsed.items.length} · ${total} PTS)` : ''}
        </button>
      </div>
    </div>
  )
}

// ── Seed-game panel: enter seed + points → expand → review → add ──
function SeedGamePanel({ game, mk, mkName, slot, tr, onAdd, showToast }: {
  game: GameAllocView; mk: string; mkName: string; slot: string; tr: (k: string) => string
  onAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: Toast
}) {
  const [seed, setSeed] = useState('')
  const [pts, setPts] = useState('')

  const hint = game.base === 'digits' ? tr('seed_hint_digits') : game.expansion.startsWith('chart') || game.base === 'panna' ? tr('seed_hint_panna') : tr('seed_hint_ank')
  const points = Number(pts) || 0

  // LIVE PREVIEW (2026-09): the expansion recomputes on every keystroke —
  // no Calculate step. Same engine call the old button used.
  const res = useMemo(() => {
    if (!seed.trim()) return null
    return expandGame(game.code, seed)
  }, [game.code, seed])
  const rows = res?.rows || null
  const okRows = (rows || []).filter(r => r.ok)
  const total = okRows.length * points
  const minOk = points >= (game.minPoints || 10)
  const errMsg = !seed.trim() ? ''
    : res?.error ? res.error
    : rows && rows.length && !okRows.length ? (rows[0]?.reason || 'No valid numbers')
    : !minOk ? tr('min_points') + ' (' + (game.minPoints || 10) + ')'
    : ''

  const addAll = () => {
    if (!okRows.length || !minOk) return
    onAdd(okRows.map(r => ({
      marketCode: mk, slot, type: r.type, num: canonicalPanna(r.num), points,
      rate: game.rate || rateFor(mk, r.type), marketName: mkName, gameCode: game.code,
    })))
    showToast(okRows.length + ' ' + tr('bids_added'), 'ok')
    setSeed(''); setPts('')
  }

  const typeChip: Record<string, string> = { single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow', tp: 'c-yellow' }

  return (
    <div className="card" style={{ padding: 12, marginTop: 2 }}>
      <p className="small muted" style={{ marginBottom: 8 }}>
        {game.name} — <span className="mono">{game.erpMapping}</span> · pays 1:{game.rate || rateFor(mk, 'sp')}
      </p>
      <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)' }}>{tr('enter_seed').toUpperCase()} ({hint})</label>
      <input className="mono" style={{ marginTop: 4, fontWeight: 800, letterSpacing: '.06em' }} placeholder={hint}
        value={seed} onChange={e => setSeed(e.target.value)} />
      <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 9 }}>{tr('per_row').toUpperCase()} (MIN {game.minPoints || 10})</label>
      <input type="number" min={game.minPoints || 10} style={{ marginTop: 4 }} placeholder={String(game.minPoints || 10)}
        value={pts} onChange={e => setPts(e.target.value)} />
      {errMsg ? <p className="tiny" style={{ color: '#b91c1c', marginTop: 8 }}>{errMsg}</p> : null}
      {rows && okRows.length ? (
        <div className="card" style={{ padding: 10, marginTop: 10, background: '#FDF2F8', border: '1px solid #fbcfe8' }}>
          <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
            <b className="small">{tr('expansion_preview')} ({okRows.length})</b>
            <span className="chip c-pink">{okRows.length} × {points} = {total} pts</span>
          </div>
          <div className="slip-list" style={{ maxHeight: 160 }}>
            {rows.map((r, i) => (
              <div className="srow" key={i} style={r.ok ? undefined : { opacity: .5 }}>
                <span className={'chip ' + (typeChip[r.type] || 'c-gray')}>{r.type.toUpperCase()}</span>
                <span className="mono" style={{ fontWeight: 800 }}>{canonicalPanna(r.num)}</span>
                <span className="tiny muted" style={{ flex: 1 }}>{r.ok ? '' : (r.reason || '')}</span>
                <b>{r.ok ? points : '—'}</b>
              </div>
            ))}
          </div>
          <button className="btn btn-g" style={{ width: '100%', marginTop: 8 }} disabled={!okRows.length || !minOk} onClick={addAll}>
            <I n="check" />{tr('add_to_slip')} ({okRows.length} {tr('rows_will_place')} · {total} PTS)
          </button>
        </div>
      ) : null}
    </div>
  )
}

// ── Ank-family panel (2026-09): pick ONE ank → every panna of that ank ──
// SP/DP/TP/SPDP/SPTP/DPTP/SPDPTP use the master-admin digit-sum grouping
// (SP 12 per ank, DP 9, TP the matching triple); DP Motor uses the operator
// DP Motor chart. The preview regenerates live as the customer taps — no
// Calculate step. One points value → the whole ank goes to the slip.
function AnkFamilyPanel({ game, mk, mkName, slot, tr, onAdd, showToast }: {
  game: GameAllocView; mk: string; mkName: string; slot: string; tr: (k: string) => string
  onAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: Toast
}) {
  const [ank, setAnk] = useState(0)
  const [pts, setPts] = useState('')

  const res = useMemo(() => expandGame(game.code, String(ank)), [game.code, ank])
  const okRows = (res?.rows || []).filter(r => r.ok)
  const points = Number(pts) || 0
  const total = okRows.length * points
  const minOk = points >= (game.minPoints || 10)
  const byType = okRows.reduce<Record<string, number>>((a, r) => { a[r.type] = (a[r.type] || 0) + 1; return a }, {})
  const typeChip: Record<string, string> = { single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow', tp: 'c-yellow' }

  const addAll = () => {
    if (!okRows.length || !minOk) return
    onAdd(okRows.map(r => ({
      marketCode: mk, slot, type: r.type, num: canonicalPanna(r.num), points,
      rate: game.rate || rateFor(mk, r.type), marketName: mkName, gameCode: game.code,
    })))
    showToast(okRows.length + ' ' + tr('bids_added'), 'ok')
    setPts('')
  }

  return (
    <div className="card" style={{ padding: 12, marginTop: 2 }}>
      <p className="small muted" style={{ marginBottom: 8 }}>
        {game.name} — <span className="mono">{game.erpMapping}</span> · pays 1:{game.rate || rateFor(mk, 'sp')} — pick an ank, every panna of that ank is played
      </p>
      <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)' }}>{tr('pick_ank').toUpperCase()}</label>
      <div className="achips">{Array.from({ length: 10 }, (_, a) =>
        <button key={a} className={'achip' + (ank === a ? ' on' : '')} onClick={() => setAnk(a)}>{a}</button>)}</div>
      {okRows.length ? (
        <div className="card" style={{ padding: 10, marginTop: 10, background: '#FDF2F8', border: '1px solid #fbcfe8' }}>
          <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6, flexWrap: 'wrap', gap: 4 }}>
            <b className="small">{tr('expansion_preview')} ({okRows.length})</b>
            <span className="row" style={{ gap: 4 }}>
              {Object.entries(byType).map(([tp, n]) => (
                <span key={tp} className={'chip ' + (typeChip[tp] || 'c-gray')}>{n} {tp.toUpperCase()}</span>
              ))}
            </span>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
            {okRows.map((r, i) => (
              <span key={i} className={'chip ' + (typeChip[r.type] || 'c-gray')} style={{ fontFamily: 'ui-monospace,monospace', fontWeight: 800 }}>{canonicalPanna(r.num)}</span>
            ))}
          </div>
        </div>
      ) : (
        <p className="tiny muted" style={{ marginTop: 10 }}>
          No entries for ank {ank} in this game{game.code === 'dp-motor' ? ' — the DP Motor chart covers anks 1-9' : ''}.
        </p>
      )}
      <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 9 }}>{tr('per_row').toUpperCase()} (MIN {game.minPoints || 10})</label>
      <input type="number" min={game.minPoints || 10} style={{ marginTop: 4 }} placeholder={String(game.minPoints || 10)}
        value={pts} onChange={e => setPts(e.target.value)} />
      <button className="btn btn-g" style={{ width: '100%', marginTop: 11 }} disabled={!okRows.length || !minOk} onClick={addAll}>
        <I n="check" />{tr('add_to_slip')} {okRows.length ? `(${okRows.length} ${tr('rows_will_place')} · ${total} PTS)` : ''}
      </button>
    </div>
  )
}

// ── Bet-the-whole-ank strip for the sp/dp/tp grids (2026-09) ──
// One points value adds EVERY panna of the selected ank to the slip —
// the ank-based play the panna family games now share with the ERP.
function AnkBulkStrip({ mk, mkName, slot, type, nums, rate, minPoints, gameCode, tr, onBulkAdd, showToast }: {
  mk: string; mkName: string; slot: string; type: string; nums: string[]
  rate: number; minPoints: number; gameCode: string | null; tr: (k: string) => string
  onBulkAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: Toast
}) {
  const [pts, setPts] = useState('')
  const points = Number(pts) || 0
  const ok = nums.length > 0 && points >= minPoints
  return (
    <div className="card" style={{ padding: 10, marginTop: 10, background: '#EFF6FF', border: '1px solid #bfdbfe' }}>
      <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'wrap', gap: 4 }}>
        <b className="small">Bet the whole ank — all {nums.length} {type.toUpperCase()} pannas of ank</b>
        <span className="chip c-teal">{nums.length} × {points || '…'} = {nums.length * (points || 0)} pts</span>
      </div>
      <div className="row" style={{ gap: 8, marginTop: 8 }}>
        <input type="number" min={minPoints} placeholder={`points per panna (min ${minPoints})`} value={pts} onChange={e => setPts(e.target.value)} style={{ flex: 1 }} />
        <button className="btn btn-g" style={{ padding: '11px 16px', whiteSpace: 'nowrap' }} disabled={!ok}
          onClick={() => {
            onBulkAdd(nums.map(n => ({ marketCode: mk, slot, type, num: n, points, rate, marketName: mkName, gameCode })))
            showToast(nums.length + ' ' + tr('bids_added'), 'ok')
            setPts('')
          }}>
          <I n="layers" />Add {nums.length} to Slip
        </button>
      </div>
    </div>
  )
}

// ── In-play results charts (2026-09): the graph button on the play screen ──
// Opens the market's Jodi chart + Panel chart (declared results history),
// same views as the Results screen — silently refreshed every 10 s.
function PlayChartsModal({ marketCode, marketName, onClose }: {
  marketCode: string; marketName: string; onClose: () => void
}) {
  const [tab, setTab] = useState<'jodi' | 'panel'>('jodi')
  const [results, setResults] = useState<ResultRow[]>([])

  useEffect(() => {
    let live = true
    const load = () => {
      appApi('/api/customer-app/results?market=' + marketCode)
        .then(d => { if (live) setResults((d.results as ResultRow[]) || []) })
        .catch(() => {})
    }
    load()
    const t2 = setInterval(load, 10000)
    const onVis = () => { if (document.visibilityState === 'visible') load() }
    document.addEventListener('visibilitychange', onVis)
    return () => { live = false; clearInterval(t2); document.removeEventListener('visibilitychange', onVis) }
  }, [marketCode])

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>{marketName} — Results Chart<button onClick={onClose} style={{ color: '#94a3b8' }}><I n="x" /></button></h3>
        <div className="tabs" style={{ marginTop: 0 }}>
          {[['jodi', 'Jodi Chart'], ['panel', 'Panel Chart']].map(([k, l]) => (
            <button key={k} className={'tab' + (tab === k ? ' on' : '')} onClick={() => setTab(k as 'jodi' | 'panel')}>{l}</button>
          ))}
        </div>
        {tab === 'jodi' ? <JodiChart results={results} mkName={marketName} /> : <PanelChart results={results} mkName={marketName} />}
      </div>
    </div>
  )
}

// ── Main market play ──
export function PlayScreen({ market, lang, tr, wallet, slip, slipInput, removeSlip, clearSlip, onSubmit, onBack, onBulkAdd, showToast }: {
  market: MarketView
  lang: Lang
  tr: (k: string) => string
  wallet: number
  slip: SlipItem[]
  slipInput: SlipInputFn
  removeSlip: (i: number) => void
  clearSlip: () => void
  onSubmit: () => void
  onBack: () => void
  onBulkAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: Toast
}) {
  // Market structure: "Name + Phase + Session" — session-specific markets fix the tab
  const mkSession: 'open' | 'close' | 'both' = market.session === 'open' || market.session === 'close' ? market.session : 'both'
  // Game tabs from the allocation (fallback to the classic set).
  // Jodi session rule (2026-09): jodi = open digit + close digit — it is
  // hidden on close-only markets and locked once the open window ends.
  const games: GameAllocView[] = (market.games?.length ? market.games : [
    { code: 'single', name: 'Single Digit', base: 'ank', session: 'both', expansion: 'none', icon: 'zap', erpMapping: 'Single', rate: 9, minPoints: 10 },
    { code: 'jodi', name: 'Jodi', base: 'jodi', session: 'both', expansion: 'none', icon: 'layers', erpMapping: 'Jodi', rate: 90, minPoints: 10 },
    { code: 'sp', name: 'Single Pana', base: 'panna', session: 'both', expansion: 'none', icon: 'layers', erpMapping: 'SP', rate: 140, minPoints: 10 },
    { code: 'dp', name: 'Double Pana', base: 'panna', session: 'both', expansion: 'none', icon: 'layers', erpMapping: 'DP', rate: 280, minPoints: 10 },
    { code: 'tp', name: 'Triple Pana', base: 'panna', session: 'close', expansion: 'none', icon: 'layers', erpMapping: 'TP', rate: 700, minPoints: 10 },
  ]).filter(g => g.code !== 'jodi' || mkSession !== 'close')
  const [mode, setMode] = useState<string>(games[0]?.code || 'single')
  const [session, setSession] = useState<'open' | 'close'>(mkSession === 'close' ? 'close' : 'open')
  const [ank, setAnk] = useState(0)
  const [showPaste, setShowPaste] = useState(false)
  const [showCharts, setShowCharts] = useState(false)
  const [hsDigit, setHsDigit] = useState<number | null>(null)
  const [hsAnk, setHsAnk] = useState(0)
  const [hsPanna, setHsPanna] = useState<string | null>(null)
  const [hbAnk, setHbAnk] = useState(0)
  const [hbPanna, setHbPanna] = useState<string | null>(null)
  const [hbDigit, setHbDigit] = useState<number | null>(null)
  const [fsOAnk, setFsOAnk] = useState(0)
  const [fsOpen, setFsOpen] = useState<string | null>(null)
  const [fsCAnk, setFsCAnk] = useState(0)
  const [fsClose, setFsClose] = useState<string | null>(null)
  const [hsPts, setHsPts] = useState('')
  const [hbPts, setHbPts] = useState('')
  const [fsPts, setFsPts] = useState('')
  const [, forceTick] = useState(0)

  const game = games.find(g => g.code === mode) || games[0]
  const kind = kindOf(game, mode)
  // live 1-second heartbeat — powers the real-time betting countdown
  useEffect(() => {
    const t2 = setInterval(() => forceTick(x => x + 1), 1000)
    return () => clearInterval(t2)
  }, [])

  const fixedClose = kind === 'tp' || game?.session === 'close'
  const fixedOpen = game?.session === 'open' && kind !== 'oddeven'
  const sessioned = ['single', 'panna'].includes(kind)
    ? !fixedClose && !fixedOpen
    : kind === 'seed'
      ? game?.session === 'both'
      : false
  const cm = market.betClosingMinutes || 0
  const off = market.isOn === false
  const slot: 'open' | 'close' = fixedClose ? 'close' : 'open'
  // Jodi accepts only while the OPEN session window is live (its outcome needs
  // both digits, but the bet must be placed before the open result)
  const jodiLive = mkSession !== 'close' && slotAccepting(market.openTime, market.closeTime, 'open', new Date(), cm)
  const effSlot: string = kind === 'jodi' ? 'jodi' : (kind === 'hs' || kind === 'hsb') ? 'hs' : kind === 'fs' ? 'fs' : sessioned ? session : slot
  const open = off || market.resultDeclared
    ? false
    : ['single', 'panna', 'tp', 'seed'].includes(kind)
      ? slotAccepting(market.openTime, market.closeTime, (fixedClose ? 'close' : session) as 'open' | 'close', new Date(), cm)
      : kind === 'jodi' ? jodiLive : true
  const left = ['single', 'panna', 'tp', 'seed'].includes(kind)
    ? secsLeftToClose(market.openTime, market.closeTime, (fixedClose ? 'close' : session) as 'open' | 'close', new Date(), cm)
    : 0

  const addSangam = (kind2: 'hs' | 'hsb' | 'fs') => {
    if (kind2 === 'hs') {
      if (hsDigit == null || !hsPanna) return
      const pts = Number(hsPts)
      if (!pts || pts < (game?.minPoints || 10)) return
      const num = hsDigit + '-' + hsPanna
      const key = market.code + '|hs|hs|' + num
      if (slip.some(x => x.key === key)) return
      slipInput({ value: String(pts), closest: () => null } as unknown as HTMLInputElement,
        key, market.code, 'hs', 'hs', num, game?.rate || rateFor(market.code, 'hs'), market.name, game?.code || 'hs')
      setHsPts('')
    } else if (kind2 === 'hsb') {
      // Half Sangam B: open panna + close digit → num "PPP-X"
      if (!hbPanna || hbDigit == null) return
      const pts = Number(hbPts)
      if (!pts || pts < (game?.minPoints || 10)) return
      const num = hbPanna + '-' + hbDigit
      const key = market.code + '|hs|hsb|' + num
      if (slip.some(x => x.key === key)) return
      slipInput({ value: String(pts), closest: () => null } as unknown as HTMLInputElement,
        key, market.code, 'hs', 'hsb', num, game?.rate || rateFor(market.code, 'hsb'), market.name, game?.code || 'hsb')
      setHbPts('')
    } else {
      if (!fsOpen || !fsClose) return
      const pts = Number(fsPts)
      if (!pts || pts < (game?.minPoints || 10)) return
      const num = fsOpen + '-' + fsClose
      const key = market.code + '|fs|fs|' + num
      if (slip.some(x => x.key === key)) return
      slipInput({ value: String(pts), closest: () => null } as unknown as HTMLInputElement,
        key, market.code, 'fs', 'fs', num, game?.rate || rateFor(market.code, 'fs'), market.name, game?.code || 'fs')
      setFsPts('')
    }
  }

  const grid = () => {
    const mk = market.code, mkName = market.name
    const rate = game?.rate || rateFor(mk, mode === 'sp' ? 'sp' : mode === 'dp' ? 'dp' : mode)
    const gc = game?.code || mode
    if (kind === 'single') {
      return <div className="grid g5">{Array.from({ length: 10 }, (_, i) =>
        <Tile key={i} mk={mk} mkName={mkName} slot={session} type="single" num={String(i)} big rate={rate} gameCode={gc} slip={slip} slipInput={slipInput} />)}</div>
    }
    if (kind === 'jodi') {
      return (
        <>
          <div className="grid g5" style={{ maxHeight: 260, overflowY: 'auto' }}>{Array.from({ length: 100 }, (_, j) => {
            const n = String(j).padStart(2, '0')
            return <Tile key={n} mk={mk} mkName={mkName} slot="jodi" type="jodi" num={n} rate={rate} gameCode={gc} slip={slip} slipInput={slipInput} />
          })}</div>
          <p className="tiny muted" style={{ marginTop: 8 }}>Jodi = Open digit + Close digit · settles on the full result · open session only</p>
        </>
      )
    }
    if (kind === 'panna') {
      const U = mode === 'sp' ? SPB_C : DPB_C
      return (
        <>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (ank === a ? ' on' : '')} onClick={() => setAnk(a)}>{a}</button>)}</div>
          <div className="grid g4">{U[ank].map(p =>
            <Tile key={p} mk={mk} mkName={mkName} slot={session} type={mode} num={p} rate={rate} gameCode={gc} slip={slip} slipInput={slipInput} />)}</div>
          <p className="tiny muted" style={{ marginTop: 8 }}>Ank {ank} · {U[ank].length} pannas · grouped by result digit (same as the master chart)</p>
          <AnkBulkStrip
            mk={mk} mkName={mkName} slot={session} type={mode} nums={U[ank]}
            rate={rate} minPoints={game?.minPoints || 10} gameCode={gc}
            tr={tr} onBulkAdd={onBulkAdd} showToast={showToast}
          />
        </>
      )
    }
    if (kind === 'tp') {
      // TP by ank — the master-admin TP chart groups triples by result digit:
      // ank 1 → 777, 2 → 444, 3 → 111 … ank 0 → 000 (digit-sum ank)
      const tpForAnk = canonicalPanna(TP.find(x => deriveDigit(x) === String(ank)) || TP[0])
      return (
        <>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (ank === a ? ' on' : '')} onClick={() => setAnk(a)}>{a}</button>)}</div>
          <div className="grid g5">{TP.map(rawP => { const p = canonicalPanna(rawP); return (
            <Tile key={p} mk={mk} mkName={mkName} slot="close" type="tp" num={p} rate={rate} gameCode={gc} slip={slip} slipInput={slipInput} />); })}</div>
          <p className="tiny muted" style={{ marginTop: 8 }}>Triple Pana · all three digits same · pays 1:{rate} · settles on the close panna · ank {ank} → {tpForAnk}</p>
          <AnkBulkStrip
            mk={mk} mkName={mkName} slot="close" type="tp" nums={[tpForAnk]}
            rate={rate} minPoints={game?.minPoints || 10} gameCode={gc}
            tr={tr} onBulkAdd={onBulkAdd} showToast={showToast}
          />
        </>
      )
    }
    if (kind === 'seed') {
      if (!game) return null
      // Ank-family games (2026-09): pick ONE ank → every panna of that ank,
      // live preview — no seed typing, no Calculate step
      if (['spdp', 'sptp', 'dptp', 'spdptp', 'dp-motor'].includes(game.code)) {
        return (
          <AnkFamilyPanel
            game={game} mk={mk} mkName={mkName}
            slot={game.session === 'close' ? 'close' : session}
            tr={tr} onAdd={onBulkAdd} showToast={showToast}
          />
        )
      }
      return (
        <SeedGamePanel
          game={game} mk={mk} mkName={mkName}
          slot={game.session === 'close' ? 'close' : session}
          tr={tr} onAdd={onBulkAdd} showToast={showToast}
        />
      )
    }
    if (kind === 'hs') {
      return (
        <>
          <p className="small muted" style={{ marginBottom: 8 }}>Half Sangam — pick <b>Open digit</b> + <b>Close panna</b> · pays 1:{game?.rate || rateFor(mk, 'hs')}</p>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)' }}>OPEN DIGIT</label>
          <div className="pickrow">{Array.from({ length: 10 }, (_, i) =>
            <button key={i} className={'pick' + (hsDigit === i ? ' on' : '')} onClick={() => setHsDigit(i)}>{i}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 6 }}>CLOSE PANNA (SP)</label>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (hsAnk === a ? ' on' : '')} onClick={() => setHsAnk(a)}>{a}</button>)}</div>
          <div className="pickrow">{SPB_C[hsAnk].map(p =>
            <button key={p} className={'pick' + (hsPanna === p ? ' on' : '')} onClick={() => setHsPanna(p)}>{p}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 6 }}>POINTS (MIN {game?.minPoints || 10})</label>
          <input type="number" min={game?.minPoints || 10} placeholder="points" style={{ marginTop: 4 }} value={hsPts} onChange={e => setHsPts(e.target.value)} />
          <button className="btn btn-g" style={{ width: '100%', marginTop: 10 }} onClick={() => addSangam('hs')}>
            <I n="plus" />Add Half Sangam to Slip
          </button>
        </>
      )
    }
    if (kind === 'hsb') {
      return (
        <>
          <p className="small muted" style={{ marginBottom: 8 }}>Half Sangam B — pick <b>Open panna</b> + <b>Close digit</b> · pays 1:{game?.rate || rateFor(mk, 'hsb')}</p>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)' }}>OPEN PANNA (SP)</label>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (hbAnk === a ? ' on' : '')} onClick={() => setHbAnk(a)}>{a}</button>)}</div>
          <div className="pickrow">{SPB_C[hbAnk].map(p =>
            <button key={p} className={'pick' + (hbPanna === p ? ' on' : '')} onClick={() => setHbPanna(p)}>{p}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 6 }}>CLOSE DIGIT</label>
          <div className="pickrow">{Array.from({ length: 10 }, (_, i) =>
            <button key={i} className={'pick' + (hbDigit === i ? ' on' : '')} onClick={() => setHbDigit(i)}>{i}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 6 }}>POINTS (MIN {game?.minPoints || 10})</label>
          <input type="number" min={game?.minPoints || 10} placeholder="points" style={{ marginTop: 4 }} value={hbPts} onChange={e => setHbPts(e.target.value)} />
          <button className="btn btn-g" style={{ width: '100%', marginTop: 10 }} onClick={() => addSangam('hsb')}>
            <I n="plus" />Add Half Sangam B to Slip
          </button>
        </>
      )
    }
    if (kind === 'fs') {
      return (
        <>
          <p className="small muted" style={{ marginBottom: 8 }}>Full Sangam — pick <b>Open panna</b> + <b>Close panna</b> · pays 1:{game?.rate || rateFor(mk, 'fs')}</p>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)' }}>OPEN PANNA (SP)</label>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (fsOAnk === a ? ' on' : '')} onClick={() => setFsOAnk(a)}>{a}</button>)}</div>
          <div className="pickrow">{SPB_C[fsOAnk].map(p =>
            <button key={p} className={'pick' + (fsOpen === p ? ' on' : '')} onClick={() => setFsOpen(p)}>{p}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 8 }}>CLOSE PANNA (SP)</label>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (fsCAnk === a ? ' on' : '')} onClick={() => setFsCAnk(a)}>{a}</button>)}</div>
          <div className="pickrow">{SPB_C[fsCAnk].map(p =>
            <button key={p} className={'pick' + (fsClose === p ? ' on' : '')} onClick={() => setFsClose(p)}>{p}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 6 }}>POINTS (MIN {game?.minPoints || 10})</label>
          <input type="number" min={game?.minPoints || 10} placeholder="points" style={{ marginTop: 4 }} value={fsPts} onChange={e => setFsPts(e.target.value)} />
          <button className="btn btn-g" style={{ width: '100%', marginTop: 10 }} onClick={() => addSangam('fs')}>
            <I n="plus" />Add Full Sangam to Slip
          </button>
        </>
      )
    }
    if (kind === 'oddeven') {
      const mk = market.code
      return (
        <>
          <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {['ODD', 'EVEN'].map(o => {
              const key = mk + '|open|oddeven|' + o.toLowerCase()
              const e = slip.find(x => x.key === key)
              return (
                <div key={o} className={'tile big' + (e ? ' has' : '')} style={{ padding: '12px 2px 13px' }}>
                  <div className="tn" style={{ fontSize: 16 }}>{o}</div>
                  <input type="number" inputMode="numeric" min={10} placeholder="-" style={{ marginTop: 7 }} defaultValue={e ? e.pts : ''}
                    onInput={ev => slipInput(ev.target as HTMLInputElement, key, mk, 'open', 'oddeven', o, game?.rate || rateFor(mk, 'oddeven'), market.name, gc)} />
                </div>
              )
            })}
          </div>
          <p className="tiny muted" style={{ marginTop: 8 }}>Result digit odd/even · pays 1:{game?.rate || rateFor(mk, 'oddeven')}</p>
        </>
      )
    }
    return null
  }

  return (
    <>
      <div className="subbar">
        <button className="ibtn" title="Results chart" onClick={() => setShowCharts(true)}><I n="trending-up" /></button>
        <button className="ibtn" onClick={onBack}><I n="chevron-left" /></button>
        <div className="info">
          <b>{(market.displayName || market.name).toUpperCase()}</b>
          <span>{todayStr()} · {tr('open_time_l')} {market.openTime} · {tr('close_time_l')} {market.closeTime}{cm ? ` · ${tr('closes_early')} ${cm}${tr('early')}` : ''}</span>
        </div>
        <span className="wchip"><I n="wallet" />{fmt(wallet)}</span>
      </div>
      <div className="pbody" style={{ paddingBottom: 24 }}>
        {sessioned ? (
          mkSession === 'both' ? (
            <div className="sess">
              <button className={session === 'open' ? 'on' : ''} onClick={() => setSession('open')}>
                {tr('open')}{market.openAccepting && session === 'open' && open ? ' · ' + tr('live') : ''}
              </button>
              <button className={session === 'close' ? 'on' : ''} onClick={() => setSession('close')}>
                {tr('close')}{market.closeAccepting && session === 'close' && open ? ' · ' + tr('live') : ''}
              </button>
            </div>
          ) : (
            <div className="sess">
              <button className="on">{mkSession === 'open' ? tr('open') : tr('close')} · {tr('session_word').toUpperCase()}</button>
            </div>
          )
        ) : null}
        {/* real-time countdown — how long the customer has to place bets */}
        {off || market.resultDeclared ? (
          <div className="cdwrap stop"><I n="lock" />{off ? `${market.name} OFF` : tr('result_locked')}</div>
        ) : !open ? (
          <div className="cdwrap stop"><I n="lock" />{kind === 'jodi'
            ? 'Jodi is open only during the Open session — jodi combines the open + close digits'
            : <>{tr('betting_closed')} {(fixedClose || !sessioned) ? (effSlot === 'jodi' ? 'Jodi' : tr('close')) : tr('open')} {tr('session_word')} {market.name}</>}</div>
        ) : ['single', 'panna', 'tp', 'seed'].includes(kind) ? (
          <div className="cdwrap run"><I n="timer" />{tr('time_left')} <span className="cdt">{fmtCountdown(left)}</span></div>
        ) : null}
        <div className="gametabs">
          {games.map(g => {
            const jodiLocked = g.code === 'jodi' && !jodiLive
            return (
              <button key={g.code} className={'gtab' + (mode === g.code ? ' on' : '')} style={jodiLocked ? { opacity: .45 } : undefined}
                disabled={jodiLocked} onClick={() => setMode(g.code)} title={jodiLocked ? 'Jodi is available only during the Open session' : undefined}>
                <span className="gi"><I n={jodiLocked ? 'lock' : iconForGame(g)} /></span>
                <span className="gn">{g.name}</span>
                <span className="gr">1:{g.rate || rateFor(market.code, g.code)}</span>
              </button>
            )
          })}
        </div>
        <div className="ratebar">
          <span className="rr">{tr('rate')} · {game?.name || gameLabel(mode)}</span>
          <span className="rr"><b>1 : {game?.rate || rateFor(market.code, mode)}</b></span>
          <button className="btn btn-w" style={{ padding: '6px 11px', fontSize: 11, borderRadius: 9 }} onClick={() => setShowPaste(true)}>
            <I n="layers" />{tr('paste_data')}
          </button>
        </div>
        <div style={!open ? { pointerEvents: 'none', opacity: .5 } : undefined}>{grid()}</div>
        {['single', 'jodi', 'panna', 'tp'].includes(kind) ? (
          <ChartPreview mode={mode === 'sp' ? 'sp' : mode === 'dp' ? 'dp' : kind} ank={ank} session={session} marketName={market.name} slip={slip} />
        ) : null}
        <Slip tr={tr} slip={slip} removeSlip={removeSlip} clearSlip={clearSlip} onSubmit={onSubmit} />
      </div>
      {showPaste ? (
        <PasteModal
          market={market} session={session} tr={tr} onClose={() => setShowPaste(false)} showToast={showToast}
          onAdd={(items) => {
            const usable = items.filter(it => it.type !== 'tp' || kind === 'tp' || sessioned)
            const mapped = usable.map(it => ({
              marketCode: market.code,
              slot: it.type === 'jodi' ? 'jodi' : it.type === 'tp' ? 'close' : session,
              type: it.type, num: it.num, points: it.points,
              rate: game?.rate || rateFor(market.code, it.type), marketName: market.name,
              gameCode: ['single', 'jodi', 'sp', 'dp', 'tp'].includes(it.type) ? it.type : null,
            }))
            onBulkAdd(mapped)
            return mapped.length
          }}
        />
      ) : null}
      {showCharts ? (
        <PlayChartsModal
          marketCode={market.code}
          marketName={market.displayName || market.name}
          onClose={() => setShowCharts(false)}
        />
      ) : null}
    </>
  )
}

// ── Starline hourly games ──
export function StarlineScreen({ initialHour, lang, tr, wallet, board, starlines = [], slip, slipInput, removeSlip, clearSlip, onSubmit, onBack, showToast }: {
  initialHour: number | null
  lang: Lang
  tr: (k: string) => string
  wallet: number
  board: Array<{ hour: number; panna: string | null; digit: string | null }>
  starlines?: Array<{ code: string; name: string; hour: number; minute: number; betClosingMinutes: number; accepting: boolean }>
  slip: SlipItem[]
  slipInput: SlipInputFn
  removeSlip: (i: number) => void
  clearSlip: () => void
  onSubmit: () => void
  onBack: () => void
  showToast: Toast
}) {
  const curH = new Date().getHours()
  const [hour, setHour] = useState<number>(initialHour ?? curH)
  const [mode, setMode] = useState<string>('single')
  const [, tick] = useState(0)
  // 1-second heartbeat for the live hour countdown
  useEffect(() => {
    const t2 = setInterval(() => tick(x => x + 1), 1000)
    return () => clearInterval(t2)
  }, [])
  const n = new Date()
  const secsToHour = 3600 - (n.getMinutes() * 60 + n.getSeconds())
  const [ank, setAnk] = useState(0)
  const [bulkAnk, setBulkAnk] = useState<number | null>(null)
  const [bulkPts, setBulkPts] = useState('')
  const [bulkHours, setBulkHours] = useState<number[]>([])

  useEffect(() => { if (initialHour != null) setHour(initialHour) }, [initialHour])

  // Configured starlines (ERP-managed) take precedence: acceptance uses the
  // result time + closing minutes, display uses the custom name.
  const slCfg = starlines.find(s => s.code === 'st' + hour)
  const open = slCfg ? slCfg.accepting : starHourAccepting(hour)
  const mk = 'st' + hour
  const mkName = slCfg?.name || starlineName(hour)
  const result = board.find(b => b.hour === hour)

  const addBulk = () => {
    if (bulkAnk == null) return showToast(tr('pick_ank'), 'err')
    const pts = Number(bulkPts)
    if (!pts || pts < 10) return showToast(tr('min_points'), 'err')
    if (!bulkHours.length) return showToast(tr('pick_hour'), 'err')
    let added = 0
    for (const x of bulkHours) {
      const key = 'st' + x + '|open|single|' + bulkAnk
      if (slip.some(s => s.key === key)) continue
      slipInput({ value: String(pts), closest: () => null } as unknown as HTMLInputElement,
        key, 'st' + x, 'open', 'single', String(bulkAnk), rateFor('st' + x, 'single'), starlines.find(s => s.code === 'st' + x)?.name || starlineName(x))
      added++
    }
    setBulkHours([])
    showToast(added + ' ' + tr('added_games'), 'ok')
  }

  const grid = () => {
    const slot = 'open'
    if (mode === 'single') {
      return <div className="grid g5">{Array.from({ length: 10 }, (_, i) =>
        <Tile key={i} mk={mk} mkName={mkName} slot={slot} type="single" num={String(i)} big rate={rateFor(mk, 'single')} gameCode={null} slip={slip} slipInput={slipInput} />)}</div>
    }
    if (mode === 'oddeven') {
      return (
        <>
          <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {['ODD', 'EVEN'].map(o => {
              const key = mk + '|open|oddeven|' + o.toLowerCase()
              const e = slip.find(x => x.key === key)
              return (
                <div key={o} className={'tile big' + (e ? ' has' : '')} style={{ padding: '12px 2px 13px' }}>
                  <div className="tn" style={{ fontSize: 16 }}>{o}</div>
                  <input type="number" inputMode="numeric" min={10} placeholder="-" style={{ marginTop: 7 }} defaultValue={e ? e.pts : ''}
                    onInput={ev => slipInput(ev.target as HTMLInputElement, key, mk, 'open', 'oddeven', o, rateFor(mk, 'oddeven'), mkName)} />
                </div>
              )
            })}
          </div>
          <p className="tiny muted" style={{ marginTop: 8 }}>Result digit odd/even · pays 1:{rateFor(mk, 'oddeven')}</p>
        </>
      )
    }
    if (mode === 'sp' || mode === 'dp') {
      const U = mode === 'sp' ? SPB_C : DPB_C
      return (
        <>
          <div className="achips">{Array.from({ length: 10 }, (_, a) =>
            <button key={a} className={'achip' + (ank === a ? ' on' : '')} onClick={() => setAnk(a)}>{a}</button>)}</div>
          <div className="grid g4">{U[ank].map(p =>
            <Tile key={p} mk={mk} mkName={mkName} slot={slot} type={mode} num={p} rate={rateFor(mk, mode)} gameCode={null} slip={slip} slipInput={slipInput} />)}</div>
        </>
      )
    }
    if (mode === 'tp') {
      return (
        <>
          <div className="grid g5">{TP.map(rawP => { const p = canonicalPanna(rawP); return (
            <Tile key={p} mk={mk} mkName={mkName} slot={slot} type="tp" num={p} rate={rateFor(mk, 'tp')} gameCode={null} slip={slip} slipInput={slipInput} />); })}</div>
          <p className="tiny muted" style={{ marginTop: 8 }}>Triple Pana · all three digits same · pays 1:{rateFor(mk, 'tp')}</p>
        </>
      )
    }
    if (mode === 'bulk') {
      return (
        <>
          <p className="small muted" style={{ marginBottom: 8 }}>Single Ank Bulk — one digit across multiple hour games · pays 1:{rateFor(mk, 'single')} each</p>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)' }}>PICK ANK</label>
          <div className="pickrow">{Array.from({ length: 10 }, (_, i) =>
            <button key={i} className={'pick' + (bulkAnk === i ? ' on' : '')} onClick={() => setBulkAnk(i)}>{i}</button>)}</div>
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 8 }}>POINTS PER GAME (MIN 10)</label>
          <input type="number" min={10} placeholder="points" style={{ marginTop: 4 }} value={bulkPts} onChange={e => setBulkPts(e.target.value)} />
          <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 10 }}>HOURS</label>
          <div className="pickrow">
            {Array.from({ length: 24 }, (_, x) => {
              const slX = starlines.find(s => s.code === 'st' + x)
              const av = slX ? slX.accepting : starHourAccepting(x)
              if (!av) return null
              return <button key={x} className={'pick' + (bulkHours.includes(x) ? ' on' : '')}
                onClick={() => setBulkHours(prev => prev.includes(x) ? prev.filter(h => h !== x) : [...prev, x])}>
                {String(x).padStart(2, '0')}
              </button>
            })}
            {!bulkHours.length && Array.from({ length: 24 }, (_, x) => {
              const slX = starlines.find(s => s.code === 'st' + x)
              return slX ? slX.accepting : starHourAccepting(x)
            }).every(v => !v)
              ? <span className="tiny muted">No open hours</span> : null}
          </div>
          <button className="btn btn-g" style={{ width: '100%', marginTop: 8 }} onClick={addBulk}>
            <I n="layers" />Add {bulkHours.length || '…'} games to Slip
          </button>
        </>
      )
    }
    return null
  }

  return (
    <>
      <div className="subbar">
        <button className="ibtn" onClick={onBack}><I n="chevron-left" /></button>
        <div className="info"><b>{tr('starline_title')}</b><span>{todayStr()} · Hourly games · declare on the hour</span></div>
        <span className="wchip"><I n="wallet" />{fmt(wallet)}</span>
      </div>
      <div className="pbody" style={{ paddingBottom: 150 }}>
        <div className="hstrip">
          {Array.from({ length: 24 }, (_, x) => {
            const done = x < curH
            const declared = board.find(b => b.hour === x)
            const sel = x === hour
            return (
              <button key={x} className={'hchip' + (sel ? ' on' : '') + (done ? ' done' : '')} onClick={() => setHour(x)}>
                <small>{declared ? 'DECLARED' : sel ? 'PLAYING' : x === ((curH + 1) % 24) ? 'NEXT' : 'GAME'}</small>
                <b>{String(x).padStart(2, '0')}:{String(starlines.find(s => s.code === 'st' + x)?.minute ?? 0).padStart(2, '0')}</b>
              </button>
            )
          })}
        </div>
        <div className="ratebar">
          <span className="rr">{mkName} · {open ? <b style={{ color: 'var(--grn)' }}>{tr('accepting').toUpperCase()}</b> : tr('closed').toUpperCase()}</span>
          <span className="rr">{RATE_LBL[mode] || 'Ank Bulk'} <b>1 : {rateFor(mk, mode === 'bulk' ? 'single' : mode)}</b></span>
        </div>
        {open ? (
          <div className="cdwrap run"><I n="timer" />{tr('time_left')} <span className="cdt">{fmtCountdown(secsToHour)}</span></div>
        ) : (
          <div className="cdwrap stop"><I n="lock" />This hour game is closed — pick a later hour above</div>
        )}
        {result && result.panna ? (
          <div className="resrow" style={{ marginBottom: 11 }}>
            <div><b style={{ fontSize: 13 }}>Result — {mkName}</b></div>
            <span className="jodi-b">{result.panna}-{result.digit}</span>
          </div>
        ) : null}
        {!open ? null : null}
        <div style={!open ? { pointerEvents: 'none', opacity: .5 } : undefined}>{grid()}</div>
        <Slip tr={tr} slip={slip} removeSlip={removeSlip} clearSlip={clearSlip} onSubmit={onSubmit} />
      </div>
    </>
  )
}
