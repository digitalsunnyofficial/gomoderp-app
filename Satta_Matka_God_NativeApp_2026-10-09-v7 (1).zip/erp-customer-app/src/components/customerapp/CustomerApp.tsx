'use client'

// ──────────────────────────────────────────────────────────
// MATKA BAZAAR — CUSTOMER APP (state machine + auth + home)
// v1.2: language flow (EN/HI/GU/MR), game-allocation aware
// slip, approval flow, business-QR deposits, live sync.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useRef, useState } from 'react'
import {
  APP_CSS, I, appApi, TOKEN_KEY, fmt, nowStr, saveLanguage,
  type AppCustomerView, type HomeData, type SlipItem, type MarketView,
} from './shell'
import { PlayScreen, StarlineScreen } from './PlayScreens'
import { MyBetsScreen, ResultsScreen, WalletScreen, ProfileScreen, NotifsScreen } from './InfoScreens'
import { RATES, RATE_LBL, fmt12, istDate, slotAccepting, secsLeftToClose, fmtCountdown } from '@/lib/matka/app-engine'
import { t, LANGUAGES, isLang, type Lang } from '@/lib/matka/i18n'

type Screen = 'splash' | 'login' | 'signup' | 'await' | 'lang' | 'home' | 'play' | 'starline' | 'mybets' | 'results' | 'wallet' | 'profile' | 'notifs'
type ModalType = 'deposit' | 'withdraw' | 'confirm' | 'password' | null
type Prompt = { kind: 'closed' | 'result'; mk: MarketView } | null

export default function CustomerApp() {
  const [booted, setBooted] = useState(false)
  const [screen, setScreen] = useState<Screen>('splash')
  const [customer, setCustomer] = useState<AppCustomerView | null>(null)
  const [home, setHome] = useState<HomeData | null>(null)
  const [marketCode, setMarketCode] = useState<string | null>(null)
  const [starHour, setStarHour] = useState<number | null>(null)
  const [slip, setSlip] = useState<SlipItem[]>([])
  const [modal, setModal] = useState<ModalType>(null)
  const [prompt, setPrompt] = useState<Prompt>(null)
  const [toast, setToast] = useState<{ msg: string; cls: string } | null>(null)
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [slider, setSlider] = useState(0)
  // where the language screen returns to ('' = first-run ask → home)
  const [langReturn, setLangReturn] = useState<'' | 'profile'>('')
  // results already announced to this device ("code|date" keys) — localStorage backed
  const seenRef = useRef<Set<string>>(new Set())
  // Idempotent placement: one in-flight request at a time; each slip line keeps
  // a stable clientRequestId across re-attempts so a lost response can never
  // turn into a double debit (the server dedups on the id).
  const sendingRef = useRef(false)
  const cridRef = useRef<Record<string, string>>({})

  // UI language: the customer's saved choice until they pick one
  const lang: Lang = isLang(customer?.language) ? customer!.language as Lang : 'en'
  const tr = useCallback((key: string) => t(lang, key), [lang])

  const showToast = useCallback((msg: string, cls = '') => {
    setToast({ msg, cls })
    if (toastTimer.current) clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToast(null), 3200)
  }, [])

  const go = useCallback((s: string) => { setModal(null); setScreen(s as Screen); window.scrollTo(0, 0) }, [])
  const backTo = useCallback((s: string) => { setModal(null); setScreen((s || 'home') as Screen); window.scrollTo(0, 0) }, [])

  const refreshCustomer = useCallback(async () => {
    try {
      const d = await appApi('/api/customer-app/me')
      setCustomer(d.customer as AppCustomerView)
      return d.customer as AppCustomerView
    } catch (e) {
      if ((e as Error).message === 'SESSION_EXPIRED') { go('login') }
      return null
    }
  }, [go])

  const refreshHome = useCallback(async () => {
    try {
      const d = await appApi('/api/customer-app/home')
      setHome(d as unknown as HomeData)
      setCustomer((d as unknown as { customer: AppCustomerView }).customer)
    } catch (e) {
      if ((e as Error).message === 'SESSION_EXPIRED') go('login')
    }
  }, [go])

  // ── Boot: splash → (token? verify : login) ──
  useEffect(() => {
    const tm = setTimeout(async () => {
      const token = localStorage.getItem(TOKEN_KEY)
      if (token) {
        const c = await refreshCustomer()
        if (c) {
          if (!isLang(c.language)) { setScreen('lang'); setLangReturn('') }
          else { setScreen('home'); refreshHome() }
          setBooted(true)
          return
        }
      }
      setScreen('login')
      setBooted(true)
    }, 1400)
    return () => clearTimeout(tm)
  }, [refreshCustomer, refreshHome])

  // Home banner slider
  useEffect(() => {
    if (screen !== 'home' || !home?.banners?.length) return
    const t2 = setInterval(() => setSlider(s => (s + 1) % home.banners.length), 5000)
    return () => clearInterval(t2)
  }, [screen, home?.banners?.length])

  // ── Result announcement prompts: when a market result is declared, a big
  //    popup opens once showing the result + the customer's win/loss status
  //    (results only when they had no bids). Seen keys persist per device. ──
  useEffect(() => {
    try {
      const raw = localStorage.getItem('mb_seen_results')
      if (raw) seenRef.current = new Set(JSON.parse(raw) as string[])
    } catch { /* fresh device */ }
  }, [])
  useEffect(() => {
    if (!home || !customer) return
    const today = istDate()
    for (const m of home.markets) {
      if (m.resultDeclared && m.todayResult) {
        // Key includes the result's updatedAt: a CORRECTED result (new version)
        // changes the stamp and re-opens the popup — customers never miss it.
        const key = m.code + '|' + today + '|' + String(m.todayResult.updatedAt || m.todayResult.declaredAt || '')
        if (!seenRef.current.has(key)) {
          seenRef.current.add(key)
          try { localStorage.setItem('mb_seen_results', JSON.stringify([...seenRef.current].slice(-100))) } catch { /* ignore */ }
          setPrompt({ kind: 'result', mk: m })
          break
        }
      }
    }
  }, [home, customer?.id])

  // ── Real-time sync: admin-side changes (results declared or CORRECTED,
  //    wallet credit, market timings, block/approve, game allocation) reflect
  //    in the app without any refresh — light polling of profile + home every
  //    10 s on every logged-in screen, plus an instant refetch when the app
  //    comes back to the foreground. The betting timer never gates result
  //    visibility; only the poll interval bounds it. ──
  useEffect(() => {
    if (!customer) return
    if (['splash', 'login', 'signup', 'await', 'lang'].includes(screen)) return
    const t2 = setInterval(() => {
      refreshCustomer()
      refreshHome()
    }, 10000)
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        refreshCustomer()
        refreshHome()
      }
    }
    document.addEventListener('visibilitychange', onVisible)
    window.addEventListener('focus', onVisible)
    return () => {
      clearInterval(t2)
      document.removeEventListener('visibilitychange', onVisible)
      window.removeEventListener('focus', onVisible)
    }
  }, [screen, customer?.id, refreshCustomer, refreshHome])

  // ── Auth actions ──
  const doLogin = async (mobile: string, password: string) => {
    try {
      const d = await appApi('/api/customer-app/auth/login', {
        method: 'POST', body: JSON.stringify({ mobile, password }),
      })
      localStorage.setItem(TOKEN_KEY, (d as { token: string }).token)
      const c = (d as unknown as { customer: AppCustomerView }).customer
      setCustomer(c)
      showToast(tr('welcome_back'), 'ok')
      if (!isLang(c.language)) { setLangReturn(''); go('lang') }
      else { go('home'); refreshHome() }
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const doSignup = async (name: string, mobile: string, password: string, referral: string) => {
    try {
      const d = await appApi('/api/customer-app/auth/signup', {
        method: 'POST', body: JSON.stringify({ name, mobile, password, referral: referral.trim() || undefined }),
      })
      if ((d as { pendingApproval?: boolean }).pendingApproval) {
        // Approval flow: the account is usable only after the ERP admin approves it
        go('await')
        return
      }
      localStorage.setItem(TOKEN_KEY, (d as { token: string }).token)
      setCustomer((d as unknown as { customer: AppCustomerView }).customer)
      showToast('Account created — welcome!', 'ok')
      go('home')
      refreshHome()
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const doLogout = async () => {
    try { await appApi('/api/customer-app/auth/logout', { method: 'POST' }) } catch { /* ignore */ }
    localStorage.removeItem(TOKEN_KEY)
    setCustomer(null); setHome(null); setSlip([])
    go('login')
  }

  // ── Language selection (post-login ask + profile switch) ──
  const pickLanguage = async (code: Lang) => {
    setCustomer(c => c ? { ...c, language: code } : c)
    const ok = await saveLanguage(code)
    showToast(tr('language_saved'), 'ok')
    if (langReturn === 'profile') go('profile')
    else { go('home'); if (!ok || !home) refreshHome() }
  }

  // ── Play navigation ──
  const openPlay = (code: string) => { setMarketCode(code); go('play') }
  const openStar = (h: number) => { setStarHour(h); go('starline') }
  const openLangFromProfile = () => { setLangReturn('profile'); go('lang') }

  // ── Slip helpers ──
  const slipInput = (inp: HTMLInputElement, key: string, mk: string, slot: string, type: string, num: string, rate: number, mkName: string, gameCode?: string | null) => {
    const v = Number(inp.value) || 0
    setSlip(prev => {
      const e = prev.find(x => x.key === key)
      if (v > 0) {
        if (e) return prev.map(x => x.key === key ? { ...x, pts: v } : x)
        return [...prev, { key, mk, slot, type, num, pts: v, rate, label: mkName + ' · ' + (RATE_LBL[type] || type) + ' ' + num, gameCode: gameCode || null }]
      }
      return prev.filter(x => x.key !== key)
    })
    const el = inp.closest('.tile') as HTMLElement | null
    if (el) el.classList.toggle('has', v > 0)
  }
  const removeSlip = (i: number) => setSlip(prev => prev.filter((_, idx) => idx !== i))
  const clearSlip = () => setSlip([])

  // Bulk add from the WhatsApp paste / game-expansion review (merge-by-sum)
  const bulkAddToSlip = useCallback((items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => {
    setSlip(prev => {
      let next = [...prev]
      for (const it of items) {
        const key = it.marketCode + '|' + it.slot + '|' + it.type + '|' + it.num
        const idx = next.findIndex(x => x.key === key)
        if (idx >= 0) {
          next = next.map((x, i) => i === idx ? { ...x, pts: x.pts + it.points } : x)
        } else {
          next.push({ key, mk: it.marketCode, slot: it.slot, type: it.type, num: it.num, pts: it.points, rate: it.rate, label: it.marketName + ' · ' + (RATE_LBL[it.type] || it.type) + ' ' + it.num, gameCode: it.gameCode || null })
        }
      }
      return next
    })
  }, [])

  const submitSlip = () => {
    if (!slip.length) return showToast(tr('enter_first'), 'err')
    if (customer && !customer.canBet) return showToast('Betting disabled for your account — contact support', 'err')
    setModal('confirm')
  }

  const confirmBets = async () => {
    if (sendingRef.current) return
    if (!slip.length) return
    sendingRef.current = true
    const total = slip.reduce((a, s) => a + s.pts, 0)
    try {
      const d = await appApi('/api/customer-app/bets', {
        method: 'POST',
        body: JSON.stringify({
          items: slip.map(s => ({
            marketCode: s.mk, slot: s.slot, type: s.type, num: s.num, points: s.pts,
            gameCode: s.gameCode || undefined,
            clientRequestId: (cridRef.current[s.key] ||= (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(36).slice(2))),
          })),
        }),
      })
      setCustomer(c => c ? { ...c, wallet: (d as { wallet: number }).wallet } : c)
      const n = (d as { placedCount: number }).placedCount
      const dups = (d as { duplicates?: number }).duplicates || 0
      cridRef.current = {}
      setSlip([]); setModal(null); setScreen('mybets')
      showToast(n + ' ' + tr('placed_toast') + ' ' + fmt(total) + ' ' + tr('debited') + (dups ? ` · ${dups} duplicate(s) ignored` : ''), 'ok')
    } catch (e) {
      setModal(null)
      showToast((e as Error).message, 'err')
      if ((e as Error).message === 'SESSION_EXPIRED') go('login')
    } finally {
      sendingRef.current = false
    }
  }

  // ── Funds / withdrawals / password ──
  const submitDeposit = async (amount: number, method: string, utr: string) => {
    try {
      await appApi('/api/customer-app/funds', { method: 'POST', body: JSON.stringify({ amount, method, utr }) })
      setModal(null)
      showToast(tr('deposit_done'), 'ok')
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const submitWithdraw = async (amount: number) => {
    try {
      const d = await appApi('/api/customer-app/withdrawals', { method: 'POST', body: JSON.stringify({ amount }) })
      setCustomer(c => c ? { ...c, wallet: (d as { wallet: number }).wallet } : c)
      setModal(null)
      showToast(tr('withdraw_done'), 'ok')
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const submitPassword = async (oldPassword: string, newPassword: string) => {
    try {
      await appApi('/api/customer-app/me', { method: 'PATCH', body: JSON.stringify({ oldPassword, newPassword }) })
      setModal(null)
      showToast(tr('password_changed'), 'ok')
    } catch (e) { showToast((e as Error).message, 'err') }
  }

  // ── Render ──
  const bottomNav = (
    <nav className="bnav">
      {([['home', 'home', tr('nav_home')], ['starline', 'star', tr('nav_star')], ['mybets', 'receipt', tr('nav_bids')], ['results', 'trophy', tr('nav_results')], ['profile', 'user', tr('nav_profile')]] as const).map(([id, ic, lb]) => (
        <button key={id} className={'btab' + (screen === id ? ' active' : '')} onClick={() => go(id)}>
          <I n={ic} />{lb}
        </button>
      ))}
    </nav>
  )

  let body: React.ReactNode
  if (screen === 'splash') body = <SplashView />
  else if (screen === 'login') body = <LoginView onLogin={doLogin} onSignup={() => go('signup')} />
  else if (screen === 'signup') body = <SignupView onSignup={doSignup} onBack={() => go('login')} />
  else if (screen === 'await') body = <AwaitApprovalView tr={tr} onBack={() => go('login')} />
  else if (screen === 'lang') body = <LangAskView current={lang} onPick={pickLanguage} />
  else if (screen === 'home') body = (
    <HomeScreen home={home} customer={customer} slider={slider} tr={tr} go={go} openPlay={openPlay} openStar={openStar} onAddPoints={() => setModal('deposit')} onPrompt={setPrompt} />
  )
  else if (screen === 'play' && marketCode && home) body = (
    <PlayScreen
      market={home.markets.find(m => m.code === marketCode)!}
      lang={lang}
      tr={tr}
      wallet={customer?.wallet || 0}
      slip={slip} slipInput={slipInput} removeSlip={removeSlip} clearSlip={clearSlip}
      onSubmit={submitSlip} onBack={() => backTo('home')}
      onBulkAdd={bulkAddToSlip} showToast={showToast}
    />
  )
  else if (screen === 'starline') body = (
    <StarlineScreen
      initialHour={starHour}
      lang={lang} tr={tr}
      wallet={customer?.wallet || 0}
      board={home?.starline?.board || []}
      starlines={home?.starline?.starlines || []}
      slip={slip} slipInput={slipInput} removeSlip={removeSlip} clearSlip={clearSlip}
      onSubmit={submitSlip} onBack={() => backTo('home')} showToast={showToast}
    />
  )
  else if (screen === 'mybets') body = <MyBetsScreen lang={lang} wallet={customer?.wallet || 0} showToast={showToast} onExpired={() => go('login')} />
  else if (screen === 'results') body = <ResultsScreen markets={home?.markets || []} />
  else if (screen === 'wallet') body = (
    <WalletScreen
      customer={customer} tr={tr}
      onAddPoints={() => setModal('deposit')}
      onWithdraw={() => setModal('withdraw')}
      showToast={showToast}
      onExpired={() => go('login')}
    />
  )
  else if (screen === 'profile') body = (
    <ProfileScreen customer={customer} tr={tr} go={go} onLogout={doLogout} onChangePassword={() => setModal('password')} onSelectLanguage={openLangFromProfile} />
  )
  else if (screen === 'notifs') body = <NotifsScreen onBack={() => backTo('home')} />
  else body = <SplashView />

  const shell = screen !== 'splash' && screen !== 'login' && screen !== 'signup' && screen !== 'await' && screen !== 'lang'
  const nav = (screen === 'play' || screen === 'starline') ? null : bottomNav

  return (
    <div className="mb-root">
      <style dangerouslySetInnerHTML={{ __html: APP_CSS }} />
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Sora:wght@600;700;800&display=swap" />
      <div className="stage">
        <div className="phone" id="phone">
          {shell ? <StatusBar /> : null}
          {body}
          {shell ? nav : null}
        </div>
      </div>
      {modal === 'deposit' && <DepositModal tr={tr} onClose={() => setModal(null)} onSubmit={submitDeposit} />}
      {modal === 'withdraw' && <WithdrawModal tr={tr} wallet={customer?.wallet || 0} canWithdraw={customer?.canWithdraw ?? true} onClose={() => setModal(null)} onSubmit={submitWithdraw} />}
      {modal === 'confirm' && <ConfirmModal tr={tr} slip={slip} onClose={() => setModal(null)} onConfirm={confirmBets} />}
      {modal === 'password' && <PasswordModal tr={tr} onClose={() => setModal(null)} onSubmit={submitPassword} />}
      {prompt?.kind === 'closed' && <ClosedModal tr={tr} mk={prompt.mk} onClose={() => setPrompt(null)} />}
      {prompt?.kind === 'result' && <ResultPrompt tr={tr} mk={prompt.mk} onClose={() => setPrompt(null)} />}
      <div id="mbtoast" className={toast ? 'show ' + toast.cls : ''}>{toast?.msg}</div>
      {!booted ? null : null}
    </div>
  )
}

// ── Status bar ──
function StatusBar() {
  const [now, setNow] = useState('')
  useEffect(() => {
    const tick = () => {
      const n = new Date()
      const tm = String(n.getHours() % 12 || 12).padStart(2, '0') + ':' + String(n.getMinutes()).padStart(2, '0') + ' ' + (n.getHours() < 12 ? 'AM' : 'PM')
      setNow(tm)
    }
    tick()
    const t2 = setInterval(tick, 30000)
    return () => clearInterval(t2)
  }, [])
  return <div className="sb"><span>{now}</span><span className="r"><I n="signal" /><I n="wifi" /><I n="battery-full" /></span></div>
}

// ── Splash ──
function SplashView() {
  return (
    <div className="splash">
      <div className="lg"><I n="gem" size={40} /></div>
      <div style={{ textAlign: 'center' }}>
        <b style={{ fontFamily: 'Sora', fontSize: 26 }}>MATKA BAZAAR</b>
        <div style={{ opacity: .8, fontSize: 12, marginTop: 4 }}>Play · Results · Wallet</div>
      </div>
      <div className="tiny" style={{ opacity: .7 }}>Loading…</div>
    </div>
  )
}

// ── Login (with pre-login language chips) ──
function LoginView({ onLogin, onSignup }: { onLogin: (m: string, p: string) => void; onSignup: () => void }) {
  const [mobile, setMobile] = useState('')
  const [password, setPassword] = useState('')
  const [ui, setUi] = useState<Lang>('en')
  const tr = (k: string) => t(ui, k)
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(165deg,var(--p1),var(--p2) 55%,#9d174d)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 28, color: '#fff' }}>
      <div style={{ textAlign: 'center', marginBottom: 20 }}>
        <div style={{ width: 74, height: 74, borderRadius: 24, background: 'rgba(255,255,255,.16)', display: 'grid', placeItems: 'center', margin: '0 auto 14px' }}><I n="gem" size={34} /></div>
        <b style={{ fontFamily: 'Sora', fontSize: 23 }}>{tr('login_title')}</b>
        <p style={{ fontSize: 11.5, opacity: .8, marginTop: 4 }}>{tr('login_sub')}</p>
      </div>
      <div style={{ background: '#fff', color: 'var(--ink)', borderRadius: 20, padding: 22 }}>
        <div style={{ display: 'flex', gap: 7, justifyContent: 'center', marginBottom: 16 }}>
          {LANGUAGES.map(l => (
            <button key={l.code} onClick={() => setUi(l.code)}
              className={'chip ' + (ui === l.code ? 'c-pink' : 'c-gray')}
              style={{ padding: '6px 12px', fontSize: 12 }}>{l.native}</button>
          ))}
        </div>
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block' }}>{tr('mobile')}</label>
        <input inputMode="numeric" maxLength={10} value={mobile} onChange={e => setMobile(e.target.value.replace(/\D/g, ''))} style={{ marginTop: 4 }} />
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 13 }}>{tr('password')}</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} style={{ marginTop: 4 }} />
        <button className="btn btn-g" style={{ width: '100%', marginTop: 18, padding: 13 }} onClick={() => onLogin(mobile, password)}>
          <I n="log-in" />{tr('login_btn')}
        </button>
        <div style={{ textAlign: 'center', marginTop: 14 }}>
          <button className="tiny" style={{ color: 'var(--p2)', fontWeight: 700 }} onClick={onSignup}>{tr('new_here')}</button>
        </div>
      </div>
    </div>
  )
}

// ── Signup (customers self-register → ERP approval) ──
// Agent mapping: the optional agent code (the agent's username or mobile)
// files this customer under that agent — "customer A of agent A" — which
// drives the ERP hierarchy views and the agent play commission (the agent
// earns on what their customers PLAY, not on deposits).
function SignupView({ onSignup, onBack }: { onSignup: (n: string, m: string, p: string, ref: string) => void; onBack: () => void }) {
  const [name, setName] = useState('')
  const [mobile, setMobile] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [agentCode, setAgentCode] = useState('')
  const submit = () => {
    if (!name.trim()) return
    if (!/^\d{10}$/.test(mobile)) return
    if (password.length < 6) return
    if (password !== confirm) return
    onSignup(name.trim(), mobile, password, agentCode.trim())
  }
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(165deg,var(--p1),var(--p2) 55%,#9d174d)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 28, color: '#fff' }}>
      <div style={{ textAlign: 'center', marginBottom: 22 }}>
        <div style={{ width: 64, height: 64, borderRadius: 22, background: 'rgba(255,255,255,.16)', display: 'grid', placeItems: 'center', margin: '0 auto 12px' }}><I n="gem" size={30} /></div>
        <b style={{ fontFamily: 'Sora', fontSize: 21 }}>CREATE ACCOUNT</b>
        <p style={{ fontSize: 11.5, opacity: .8, marginTop: 4 }}>Signup and place your vyapar from the app</p>
      </div>
      <div style={{ background: '#fff', color: 'var(--ink)', borderRadius: 20, padding: 22 }}>
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block' }}>FULL NAME</label>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" style={{ marginTop: 4 }} />
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 12 }}>MOBILE NUMBER</label>
        <input inputMode="numeric" maxLength={10} value={mobile} onChange={e => setMobile(e.target.value.replace(/\D/g, ''))} placeholder="10-digit mobile" style={{ marginTop: 4 }} />
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 12 }}>PASSWORD</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="min 6 characters" style={{ marginTop: 4 }} />
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 12 }}>CONFIRM PASSWORD</label>
        <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} style={{ marginTop: 4 }} />
        <label className="tiny" style={{ fontWeight: 800, color: 'var(--mut)', display: 'block', marginTop: 12 }}>AGENT CODE <span style={{ fontWeight: 600, opacity: .75 }}>(OPTIONAL)</span></label>
        <input value={agentCode} onChange={e => setAgentCode(e.target.value)} placeholder="Your agent's code / mobile" style={{ marginTop: 4 }} />
        <p className="tiny" style={{ color: 'var(--mut)', marginTop: 5, lineHeight: 1.5 }}>Enter the code your agent gave you so your account is filed under them. You can also join without one.</p>
        <button className="btn btn-g" style={{ width: '100%', marginTop: 18, padding: 13 }} onClick={submit}>
          <I n="check" />CREATE ACCOUNT
        </button>
        <div style={{ textAlign: 'center', marginTop: 14 }}>
          <button className="tiny" style={{ color: 'var(--p2)', fontWeight: 700 }} onClick={onBack}>← Back to login</button>
        </div>
      </div>
    </div>
  )
}

// ── Awaiting approval (post-signup) ──
function AwaitApprovalView({ tr, onBack }: { tr: (k: string) => string; onBack: () => void }) {
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(165deg,var(--p1),var(--p2) 55%,#9d174d)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 28, color: '#fff' }}>
      <div style={{ textAlign: 'center', marginBottom: 20 }}>
        <div style={{ width: 74, height: 74, borderRadius: 24, background: 'rgba(255,255,255,.16)', display: 'grid', placeItems: 'center', margin: '0 auto 14px' }}><I n="info" size={34} /></div>
        <b style={{ fontFamily: 'Sora', fontSize: 21 }}>{tr('await_title')}</b>
      </div>
      <div style={{ background: '#fff', color: 'var(--ink)', borderRadius: 20, padding: 22 }}>
        <p className="small" style={{ lineHeight: 1.6 }}>{tr('await_text')}</p>
        <div className="row" style={{ background: '#fef3c7', borderRadius: 11, padding: '10px 13px', marginTop: 14, gap: 8 }}>
          <I n="alert-triangle" size={15} />
          <span className="tiny" style={{ color: '#78350f', fontWeight: 700 }}>{tr('await_warn')}</span>
        </div>
        <button className="btn btn-g" style={{ width: '100%', marginTop: 16, padding: 13 }} onClick={onBack}>
          <I n="log-in" />{tr('back_to_login')}
        </button>
      </div>
    </div>
  )
}

// ── Language ask (post-login first run + profile switch) ──
function LangAskView({ current, onPick }: { current: Lang; onPick: (l: Lang) => void }) {
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(165deg,var(--p1),var(--p2) 55%,#9d174d)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 28, color: '#fff' }}>
      <div style={{ textAlign: 'center', marginBottom: 22 }}>
        <div style={{ width: 74, height: 74, borderRadius: 24, background: 'rgba(255,255,255,.16)', display: 'grid', placeItems: 'center', margin: '0 auto 14px' }}><I n="circle" size={34} /></div>
        <b style={{ fontFamily: 'Sora', fontSize: 21 }}>{t(current, 'choose_language')}</b>
        <p style={{ fontSize: 11.5, opacity: .8, marginTop: 4 }}>{t(current, 'choose_language_sub')}</p>
      </div>
      <div style={{ background: '#fff', color: 'var(--ink)', borderRadius: 20, padding: 18, display: 'grid', gap: 9 }}>
        {LANGUAGES.map(l => (
          <button key={l.code}
            onClick={() => onPick(l.code)}
            className={'prow-i' + (current === l.code ? ' ' : ' ')}
            style={{ border: '1px solid var(--line)', borderRadius: 13, background: current === l.code ? '#FDF2F8' : '#fff' }}
          >
            <I n="circle" />{l.native}
            <span className="tiny muted" style={{ marginLeft: 8 }}>{l.label}</span>
            <span className="ar"><I n="chevron-right" size={15} /></span>
          </button>
        ))}
      </div>
    </div>
  )
}

// ── Home ──
function HomeScreen({ home, customer, slider, tr, go, openPlay, openStar, onAddPoints, onPrompt }: {
  home: HomeData | null
  customer: AppCustomerView | null
  slider: number
  tr: (k: string) => string
  go: (s: string) => void
  openPlay: (code: string) => void
  openStar: (h: number) => void
  onAddPoints: () => void
  onPrompt: (p: { kind: 'closed' | 'result'; mk: MarketView }) => void
}) {
  if (!home || !customer) return <div className="pbody"><p className="muted small">{tr('loading')}</p></div>
  const cur = new Date().getHours(), nx = (cur + 1) % 24
  const BANNERS = home.banners.length ? home.banners : [{ t: 'MATKA BAZAAR', s: tr('play_all'), bg: 'linear-gradient(120deg,#7c3aed,#db2777)' }]
  const b = BANNERS[slider % BANNERS.length]
  return (
    <>
      <div className="appbar">
        <div style={{ width: 38, height: 38, borderRadius: 12, background: 'rgba(255,255,255,.18)', display: 'grid', placeItems: 'center' }}><I n="gem" size={18} /></div>
        <div className="ttl"><b>MATKA BAZAAR</b><span>{customer.name} · {customer.mobile}</span></div>
        <button className="ibtn" onClick={() => go('notifs')} style={{ position: 'relative' }}><I n="bell" />
          <span style={{ position: 'absolute', top: 2, right: 3, width: 8, height: 8, borderRadius: 99, background: 'var(--gold)' }} />
        </button>
      </div>
      <div className="pbody">
        <div className="row" style={{ marginBottom: 12, gap: 9 }}>
          <button className="wchip" onClick={() => go('wallet')} style={{ flex: 1, justifyContent: 'center' }}><I n="wallet" />{fmt(customer.wallet)}</button>
          <button className="btn btn-g" style={{ flex: 1 }} onClick={onAddPoints}><I n="plus" />{tr('add_points')}</button>
        </div>
        <div className="marq"><span className="tag">{tr('notice')}</span><div className="txt">{home.notice}</div></div>
        <div className="banner" style={{ background: b.bg }}>
          <b>{b.t}</b><span className="small" style={{ opacity: .9 }}>{b.s}</span>
          <div className="dots">{BANNERS.map((_, i) => <i key={i} className={i === (slider % BANNERS.length) ? 'on' : ''} />)}</div>
        </div>
        <div className="sech"><b>{tr('main_markets')}</b><button onClick={() => go('results')}>{tr('results')} →</button></div>
        {home.markets.map(m => (
          <MarketCard key={m.code} m={m} tr={tr} onPlay={openPlay} onPrompt={onPrompt} />
        ))}
        <div className="sech"><b>Starline — Hourly Games</b><button onClick={() => go('starline')}>{tr('all_markets')} →</button></div>
        <div className="mcard" style={{ background: 'linear-gradient(120deg,#ede9fe,#fce7f3)' }}>
          <div className="top">
            <div><h4>{tr('starline_title')}</h4><div className="tm">Next game closes at {String(nx).padStart(2, '0')}:00</div></div>
            <span className="chip c-grn">● {tr('live')}</span>
          </div>
          <div className="row" style={{ gap: 7, marginTop: 10 }}>
            <button className="btn btn-p" style={{ flex: 1 }} onClick={() => openStar(nx)}><I n="zap" />{tr('play')} {String(nx).padStart(2, '0')}:00</button>
            <button className="btn btn-w" style={{ flex: 1 }} onClick={() => go('starline')}>{tr('hour_board')}</button>
          </div>
          <div className="tiny muted" style={{ marginTop: 9 }}>
            Single 1:{RATES.star.single} · SP 1:{RATES.star.sp} · DP 1:{RATES.star.dp} · TP 1:{RATES.star.tp} · Odd/Even 1:{RATES.star.oddeven}
          </div>
        </div>
        <div className="sech"><b>{tr('latest_results')}</b></div>
        {home.latestResults.map(r => {
          const m = home.markets.find(x => x.code === r.marketCode)
          const clickable = !!(m?.resultDeclared && m.todayResult)
          return (
            <div className="resrow" key={r.marketCode} style={clickable ? { cursor: 'pointer' } : undefined}
              onClick={clickable ? () => onPrompt({ kind: 'result', mk: m! }) : undefined}>
              <div>
                <b style={{ fontSize: 13 }}>{r.marketName}</b>
                <div className="mono small muted" style={{ marginTop: 2 }}>{r.open} × {r.close}</div>
              </div>
              {r.jodi ? <span className="jodi-b">{r.jodi}</span> : <span className="chip c-orange">{tr('awaiting')}</span>}
            </div>
          )
        })}
      </div>
    </>
  )
}

// ── Market card v2 — OPEN/CLOSE time badges, name + live result pill,
//    play/disabled round button, live status bar with a ticking countdown ──
function MarketCard({ m, tr, onPlay, onPrompt }: {
  m: MarketView
  tr: (k: string) => string
  onPlay: (code: string) => void
  onPrompt: (p: { kind: 'closed' | 'result'; mk: MarketView }) => void
}) {
  const [, tick] = useState(0)
  // 1-second heartbeat — the countdown and the open/closed state stay live
  useEffect(() => {
    const t = setInterval(() => tick(x => x + 1), 1000)
    return () => clearInterval(t)
  }, [])
  const off = m.isOn === false
  const cm = m.betClosingMinutes || 0
  const now = new Date()
  const openAcc = !off && !m.resultDeclared && slotAccepting(m.openTime, m.closeTime, 'open', now, cm)
  const closeAcc = !off && !m.resultDeclared && slotAccepting(m.openTime, m.closeTime, 'close', now, cm)
  const accepting = openAcc || closeAcc
  const r = m.todayResult
  const resLabel = r ? `${r.openPanna || '***'}-${r.jodi || '**'}-${r.closePanna || '***'}` : '***_**_***'

  const status = off ? 'off' : m.resultDeclared ? 'res' : accepting ? 'run' : 'stop'
  const cd = secsLeftToClose(m.openTime, m.closeTime, openAcc ? 'open' : 'close', new Date(), cm)

  const act = () => {
    if (m.resultDeclared) onPrompt({ kind: 'result', mk: m })
    else if (accepting) onPlay(m.code)
    else onPrompt({ kind: 'closed', mk: m })
  }

  return (
    <div className="mcard2" style={off ? { opacity: .72 } : undefined} onClick={act}>
      <div className="mtimes">
        <span className="tb o"><I n="clock" />{tr('open_time_l')}: {fmt12(m.openTime)}</span>
        <span className="tb c"><I n="clock" />{tr('close_time_l')}: {fmt12(m.closeTime)}</span>
      </div>
      <div className="mmid">
        <div className="mico"><I n="trending-up" /></div>
        <div className="mmidC">
          <h4>{(m.displayName || m.name).toUpperCase()}</h4>
          <span className={'mres' + (m.resultDeclared ? ' out' : '')}>{resLabel}</span>
        </div>
        <div className={'mplay ' + (status === 'res' ? 'res' : accepting ? 'go' : 'no')}>
          <I n={status === 'res' ? 'trophy' : accepting ? 'play' : 'x'} />
        </div>
      </div>
      <div className={'mstat ' + status}>
        {status === 'run' ? (
          <>
            <I n="zap" />{(openAcc ? tr('betting_open_running') : tr('betting_close_running'))}
            <span className="cd">{tr('closes_in')} {fmtCountdown(cd)}</span>
          </>
        ) : status === 'res' ? (
          <><I n="trophy" />{tr('result_out')} · {tr('result_out_tap')}</>
        ) : (
          <><I n={off ? 'moon' : 'lock'} />{off ? tr('market_off_t') : tr('market_closed_t')}</>
        )}
      </div>
    </div>
  )
}

// ── Big centered prompt — MARKET IS CLOSED (reference layout) ──
function ClosedModal({ tr, mk, onClose }: { tr: (k: string) => string; mk: MarketView; onClose: () => void }) {
  return (
    <div className="pov" onClick={onClose}>
      <div className="pmodal" onClick={e => e.stopPropagation()}>
        <div className="ph closed">
          <div className="pic"><I n="lock" size={32} /></div>
        </div>
        <div className="pb">
          <div className="pt">{(mk.displayName || mk.name).toUpperCase()}</div>
          <div className="ps">{mk.isOn === false ? tr('market_off_t') : tr('market_closed_t')}</div>
          <div className="ptimes">
            <div><small>{tr('open_time_l')}</small><b>{fmt12(mk.openTime)}</b></div>
            <div className="sep" />
            <div><small>{tr('close_time_l')}</small><b>{fmt12(mk.closeTime)}</b></div>
          </div>
          {mk.betClosingMinutes ? (
            <p className="tiny muted" style={{ marginTop: 10 }}>Bets stop {mk.betClosingMinutes} min before each declaration time</p>
          ) : null}
          <button className="pok" onClick={onClose}>{tr('ok_understood')}</button>
        </div>
      </div>
    </div>
  )
}

// ── Big centered prompt — RESULT DECLARED (+ win/loss status when the customer had bids) ──
function ResultPrompt({ tr, mk, onClose }: { tr: (k: string) => string; mk: MarketView; onClose: () => void }) {
  const r = mk.todayResult
  const s = mk.mySummary
  const won = !!s && s.winAmount > 0
  return (
    <div className="pov" onClick={onClose}>
      <div className="pmodal" onClick={e => e.stopPropagation()}>
        <div className="ph result">
          <div className="pic"><I n="party" size={32} /></div>
        </div>
        <div className="pb">
          <div className="pt">{(mk.displayName || mk.name).toUpperCase()}</div>
          <div className="ps g">{tr('result_declared_t')}</div>
          <div className="rpill">{r ? `${r.openPanna || '***'}-${r.jodi || '**'}-${r.closePanna || '***'}` : '—'}</div>
          {r?.openPanna && r?.closePanna ? (
            <p className="tiny muted" style={{ marginTop: 7 }}>{r.openPanna} → {r.openDigit} · {r.closePanna} → {r.closeDigit}</p>
          ) : null}
          {s && s.bids > 0 ? (
            <>
              <div className={'rstat ' + (won ? 'win' : 'lose')}>{won ? tr('you_won') + ' ' + fmt(s.winAmount) : tr('better_luck')}</div>
              <div className="rmeta">
                <span>{tr('bids')}: <b>{s.bids}</b></span>
                <span>{tr('staked_l')}: <b>{fmt(s.staked)}</b></span>
                <span>{tr('won_bids')}: <b>{s.won}</b></span>
                <span>{tr('lost_bids')}: <b>{s.lost}</b></span>
              </div>
            </>
          ) : (
            <p className="tiny muted" style={{ marginTop: 12 }}>{tr('no_bids_in')}</p>
          )}
          {r?.declaredAt ? (
            <p className="tiny muted" style={{ marginTop: 9 }}>{tr('declared_at_l')}: {new Date(r.declaredAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true })}</p>
          ) : null}
          <button className="pok" onClick={onClose}>{tr('got_it')}</button>
        </div>
      </div>
    </div>
  )
}

// ── Modals ──
function ModalShell({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>{title}<button onClick={onClose} style={{ color: '#94a3b8' }}><I n="x" /></button></h3>
        {children}
      </div>
    </div>
  )
}

function DepositModal({ tr, onClose, onSubmit }: { tr: (k: string) => string; onClose: () => void; onSubmit: (amt: number, method: string, utr: string) => void }) {
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState('UPI')
  const [utr, setUtr] = useState('')
  const [qr, setQr] = useState<{ upiId: string; payeeName: string; qrImage: string; note: string; minDeposit: number } | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    appApi('/api/customer-app/payment-qr')
      .then(d => setQr(d as never))
      .catch(() => setQr(null))
  }, [])

  const min = qr?.minDeposit || 100
  const copyUpi = async () => {
    if (!qr?.upiId) return
    try {
      await navigator.clipboard.writeText(qr.upiId)
      setCopied(true); setTimeout(() => setCopied(false), 2000)
    } catch { /* clipboard unavailable */ }
  }

  return (
    <ModalShell title={tr('deposit_title')} onClose={onClose}>
      <div className="tiny muted" style={{ fontWeight: 800, marginBottom: 6 }}>{tr('pay_upi')}</div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, background: '#f8fafc', border: '1px solid var(--line)', borderRadius: 14, padding: 14 }}>
        {qr?.qrImage ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={qr.qrImage} alt="Business QR" style={{ width: 190, height: 190, objectFit: 'contain', background: '#fff', borderRadius: 12, border: '1px solid var(--line)' }} />
        ) : (
          <div style={{ width: 190, height: 190, borderRadius: 12, border: '1px dashed var(--line)', display: 'grid', placeItems: 'center', textAlign: 'center', padding: 12 }} className="tiny muted">
            {qr ? tr('qr_not_uploaded') : tr('loading_payment')}
          </div>
        )}
        {qr?.payeeName ? <b className="small">{qr.payeeName}</b> : null}
        {qr?.upiId ? (
          <button className="chip c-teal" style={{ padding: '7px 14px', fontSize: 12 }} onClick={copyUpi}>
            <I n="wallet" size={13} />{copied ? 'UPI ID copied!' : qr.upiId}
          </button>
        ) : null}
        {qr?.note ? <span className="tiny muted" style={{ textAlign: 'center' }}>{qr.note}</span> : null}
      </div>
      <p className="tiny muted" style={{ margin: '10px 0 0' }}>{tr('deposit_note')} <b>{fmt(amount || min)}</b>{tr('then_submit')}</p>
      <label>{tr('amount')} — {tr('min')} {min}</label>
      <input type="number" min={min} placeholder={tr('min') + ' ₹' + min} value={amount} onChange={e => setAmount(e.target.value)} />
      <label>{tr('method')}</label>
      <select value={method} onChange={e => setMethod(e.target.value)}>
        <option>UPI</option><option>Bank Transfer</option>
      </select>
      <label>{tr('utr')}</label>
      <input className="mono" placeholder="e.g. UTR883421900" value={utr} onChange={e => setUtr(e.target.value)} />
      <button className="btn btn-g" style={{ width: '100%', marginTop: 14, padding: 13 }} disabled={!amount || Number(amount) < min || !utr.trim()} onClick={() => onSubmit(Number(amount), method, utr)}>
        <I n="arrow-down-circle" />{tr('submit_request')}
      </button>
    </ModalShell>
  )
}

function WithdrawModal({ tr, wallet, canWithdraw, onClose, onSubmit }: {
  tr: (k: string) => string; wallet: number; canWithdraw: boolean; onClose: () => void; onSubmit: (amt: number) => void
}) {
  const [amount, setAmount] = useState('')
  return (
    <ModalShell title={tr('withdraw_title')} onClose={onClose}>
      <p className="small" style={{ marginBottom: 2 }}>{tr('available')} <b>{fmt(wallet)}</b></p>
      <label>{tr('amount')}</label>
      <input type="number" min={500} placeholder="minimum ₹500" value={amount} onChange={e => setAmount(e.target.value)} />
      <p className="tiny muted" style={{ margin: '12px 0 14px' }}>{tr('withdraw_note')}</p>
      <button className="btn btn-g" style={{ width: '100%', padding: 13 }} disabled={!canWithdraw}
        onClick={() => onSubmit(Number(amount))}>
        <I n="arrow-up-circle" />{tr('submit_request')}
      </button>
      {!canWithdraw ? <p className="tiny c-red" style={{ marginTop: 8 }}>{tr('withdraw_disabled')}</p> : null}
    </ModalShell>
  )
}

function ConfirmModal({ tr, slip, onClose, onConfirm }: { tr: (k: string) => string; slip: SlipItem[]; onClose: () => void; onConfirm: () => void }) {
  const pts = slip.reduce((a, s) => a + s.pts, 0)
  return (
    <ModalShell title={tr('confirm_title')} onClose={onClose}>
      <div className="slip-list" style={{ maxHeight: 180 }}>
        {slip.map((s, i) => (
          <div className="srow" key={i}>
            <span className={'chip ' + (s.type === 'hs' || s.type === 'fs' ? 'c-pink' : 'c-gray')}>{s.type.toUpperCase()}</span>
            <span className="mono" style={{ fontWeight: 800 }}>{s.num}</span>
            <span className="tiny muted" style={{ flex: 1 }}>{s.label.split('·')[0]}</span>
            <b>{s.pts}</b>
          </div>
        ))}
      </div>
      <div className="row" style={{ justifyContent: 'space-between', background: '#fef3c7', borderRadius: 11, padding: '10px 13px', margin: '10px 0 14px' }}>
        <span className="small" style={{ fontWeight: 800, color: '#78350f' }}>{tr('total_bids')} {slip.length} {tr('bids')}</span>
        <b style={{ color: '#78350f', fontSize: 16 }}>{fmt(pts)}</b>
      </div>
      <div className="row" style={{ gap: 9 }}>
        <button className="btn btn-w" style={{ flex: 1, padding: 12 }} onClick={onClose}>{tr('cancel')}</button>
        <button className="btn btn-g" style={{ flex: 1, padding: 12 }} onClick={onConfirm}><I n="check" />{tr('confirm')}</button>
      </div>
    </ModalShell>
  )
}

function PasswordModal({ tr, onClose, onSubmit }: { tr: (k: string) => string; onClose: () => void; onSubmit: (o: string, n: string) => void }) {
  const [oldP, setOldP] = useState('')
  const [newP, setNewP] = useState('')
  return (
    <ModalShell title={tr('change_password')} onClose={onClose}>
      <label>{tr('current_password')}</label>
      <input type="password" value={oldP} onChange={e => setOldP(e.target.value)} />
      <label>{tr('new_password')}</label>
      <input type="password" value={newP} onChange={e => setNewP(e.target.value)} placeholder="min 6 characters" />
      <button className="btn btn-g" style={{ width: '100%', marginTop: 16, padding: 13 }} onClick={() => onSubmit(oldP, newP)}>
        <I n="key-round" />{tr('update_password')}
      </button>
    </ModalShell>
  )
}

// Re-export rate label for play screens
export { RATE_LBL, nowStr }
