'use client'

import React from 'react'
import { useAppStore, type PageName } from '@/lib/store'
import { NAV_ITEMS_MASTER, NAV_ITEMS_MANAGER, NAV_ITEMS_USER } from '@/lib/navigation'
import { LogOut } from 'lucide-react'

export function Sidebar({ inventoryCount }: { inventoryCount: number }) {
  const { currentPage, setCurrentPage, setSidebarOpen, logout, currentUser } = useAppStore()
  const role = currentUser?.role
  const navItems = role === 'super' ? NAV_ITEMS_MASTER : role === 'manager' ? NAV_ITEMS_MANAGER : NAV_ITEMS_USER

  const handleClick = (page: PageName) => {
    setCurrentPage(page)
    setSidebarOpen(false)
  }

  return (
    <nav className="bg-[#0F172A] py-4 overflow-y-auto h-full flex flex-col">
      {/* Brand */}
      <div className="px-4 pb-3 mb-2 border-b border-slate-800 flex items-center gap-2.5 flex-shrink-0">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] flex items-center justify-center text-white font-extrabold text-xs flex-shrink-0">CH</div>
        <div>
          <div className="text-sm font-semibold text-white leading-tight">Card & Hisab</div>
          <div className="text-[0.6rem] text-slate-500 font-medium">System</div>
        </div>
      </div>

      {/* Nav Items */}
      <div className="flex-1 py-3 px-1">
        {navItems.map(group => (
          <div key={group.section} className="mb-3">
            <div className="text-[0.6rem] font-bold uppercase tracking-[0.12em] text-slate-500 px-3 mb-1.5">{group.section}</div>
            {group.items.map(item => {
              const Icon = item.icon
              const active = currentPage === item.id
              return (
                <button
                  key={item.id}
                  onClick={() => handleClick(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 my-px mx-2 rounded-md text-[0.8rem] font-medium transition-all border-l-[3px] ${
                    active
                      ? 'bg-[#1E293B] text-white border-l-[#4F46E5]'
                      : 'text-slate-400 border-l-transparent hover:bg-[#1E293B] hover:text-slate-200'
                  }`}
                >
                  <Icon size={16} />
                  <span>{item.label}</span>
                  {item.badge && inventoryCount > 0 && (
                    <span className="ml-auto text-[0.6rem] bg-[#4F46E5] text-white px-1.5 py-0.5 rounded-full font-bold">{inventoryCount}</span>
                  )}
                </button>
              )
            })}
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="border-t border-slate-800 py-3 px-1 flex-shrink-0">
        <div className="text-[0.6rem] font-bold uppercase tracking-[0.12em] text-slate-500 px-3 mb-1.5">Account</div>
        <button
          onClick={logout}
          className="w-full flex items-center gap-2.5 px-3 py-2 mx-2 rounded-md text-[0.8rem] font-medium text-slate-400 border-l-[3px] border-l-transparent hover:bg-[#1E293B] hover:text-slate-200 transition-all"
        >
          <LogOut size={16} />
          <span>Log Out</span>
        </button>
      </div>
    </nav>
  )
}
