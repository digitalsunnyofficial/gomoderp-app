'use client'

import React from 'react'
import { useAppStore } from '@/lib/store'
import { Menu, ChevronRight, Search, Bell } from 'lucide-react'
import { PAGE_TITLES } from '@/lib/navigation'

export function Topbar({ inventoryCount }: { inventoryCount: number }) {
  const { currentPage, currentUser, setSidebarOpen } = useAppStore()

  const breadcrumb = PAGE_TITLES[currentPage] || 'Dashboard'
  const initials = currentUser?.name?.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'U'

  return (
    <header className="h-[60px] bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-30 flex-shrink-0">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setSidebarOpen(true)}
          className="lg:hidden p-1.5 rounded-md hover:bg-slate-100 transition"
          aria-label="Toggle navigation"
        >
          <Menu size={20} className="text-slate-600" />
        </button>
        <nav className="flex items-center gap-1.5 text-sm">
          <span className="text-slate-400 font-medium">Home</span>
          <ChevronRight size={14} className="text-slate-300" />
          <span className="text-slate-700 font-semibold">{breadcrumb}</span>
        </nav>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 w-[260px] focus-within:border-indigo-400 focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
          <Search size={15} className="text-slate-400 flex-shrink-0" />
          <input type="text" placeholder="Search entries, customers..." className="bg-none border-none outline-none text-[0.78rem] text-slate-800 w-full placeholder:text-slate-400" aria-label="Search" />
        </div>
        <button className="p-2 rounded-lg hover:bg-slate-100 transition relative" aria-label="Notifications">
          <Bell size={18} className="text-slate-500" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white" />
        </button>
        <div className="flex items-center gap-2 pl-3 border-l border-slate-200">
          <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 text-xs font-bold">{initials}</div>
          <div className="hidden sm:block">
            <div className="text-xs font-semibold text-slate-700 leading-tight">{currentUser?.name || 'User'}</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <div className="w-[7px] h-[7px] rounded-full bg-emerald-500 relative flex-shrink-0">
                <div className="absolute inset-[-3px] rounded-full bg-emerald-500/30 animate-ping" />
              </div>
              <span className="text-[0.55rem] text-slate-400 font-medium">Online</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
