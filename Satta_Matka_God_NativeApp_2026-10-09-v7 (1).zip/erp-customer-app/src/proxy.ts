// In-memory session registry for single-device enforcement
// Maps userId → latest sessionToken (set on login, checked on every API call)
// For non-master users only. This is a lightweight check that doesn't require DB access.
function getRegistry(): Map<string, string> {
  const g = globalThis as Record<string, unknown>
  if (!g.__sessionRegistry) g.__sessionRegistry = new Map<string, string>()
  return g.__sessionRegistry as Map<string, string>
}

import { NextRequest, NextResponse } from 'next/server'
import { getSessionFromRequest } from './lib/session'
import { isSuperRole } from './lib/roles'

// ============================================================
// COMBINED PROXY + AUTH MIDDLEWARE (Next.js 16 proxy convention)
// ============================================================
// This file serves both roles:
//   1. (Primary) Auth gate for every /api/* route — validates the signed
//      session cookie issued by /api/auth on login.
//   2. (Legacy) Falls through to a Laravel backend if it is reachable.
//      Laravel isn't running in most deployments, so this is essentially a
//      no-op that just calls NextResponse.next().

const LARAVEL_BASE = process.env.LARAVEL_BASE || 'http://localhost:8000';

// Public API routes — no session required.
const PUBLIC_API_ROUTES = new Set<string>([
  '/api/auth',
  '/api/auth/signup',
  '/api/auth/logout',
  '/api/auth/check-session',
  '/api/auth/register-session',
  '/api/health',
]);

// Public API route prefixes — no session required for these routes and their sub-paths.
// NOTE: /api/customer-app is the customer mobile-app API — it authenticates with its
// own Bearer tokens (AppSession), NOT the ERP session cookie. Keep /api/app-admin
// (ERP-side app management panels) OUT of this list so it stays session-gated.
const PUBLIC_API_PREFIXES = [
  '/api/subscription-plans',
  '/api/customer-app',
  '/api/cron', // market scheduler — key-protected inside the route
  '/api/agent/access', // passwordless agent link activation — token-validated inside the route
  '/api/whatsapp/webhook', // Meta WhatsApp Cloud API webhook — signature/verify-token validated inside the route
  '/api/upi', // UPI auto-verify webhook — autoVerifySecret-validated inside the route (payment feeder has no ERP session)
];

// Cache whether Laravel is available
let laravelAvailable: boolean | null = null;
let lastChecked = 0;
const CHECK_INTERVAL = 30000;

async function checkLaravelAvailable(): Promise<boolean> {
  const now = Date.now();
  if (laravelAvailable !== null && (now - lastChecked) < CHECK_INTERVAL) {
    return laravelAvailable;
  }
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2000);
    const response = await fetch(`${LARAVEL_BASE}/api/auth`, {
      method: 'HEAD',
      signal: controller.signal,
    });
    clearTimeout(timeout);
    laravelAvailable = response.ok || response.status === 405;
    lastChecked = now;
    return laravelAvailable;
  } catch {
    laravelAvailable = false;
    lastChecked = now;
    return false;
  }
}

export default async function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl

  // ──────────────────────────────────────────────────────────
  // AUTH GATE for /api/* routes
  // ──────────────────────────────────────────────────────────
  if (pathname.startsWith('/api/')) {
    if (PUBLIC_API_ROUTES.has(pathname)) {
      return NextResponse.next();
    }
    // Check public API prefixes
    if (PUBLIC_API_PREFIXES.some(prefix => pathname === prefix || pathname.startsWith(prefix + '/'))) {
      return NextResponse.next();
    }
    const session = await getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json(
        { error: 'Unauthorized — session required' },
        { status: 401 }
      );
    }
    // Single-device enforcement: for non-master users, verify the session token
    // in the cookie matches the latest registered session for this user.
    // The session token (sid) is embedded in the cookie payload.
    if (!isSuperRole(session.role)) {
      const cookie = request.cookies.get('erp_session')?.value || ''
      // Extract the sid from the cookie's base64 payload
      try {
        const b64Part = cookie.split('.')[0]
        if (b64Part) {
          const payload = JSON.parse(decodeURIComponent(escape(atob(b64Part))))
          const registeredToken = getRegistry().get(session.id)
          // If there's a registered session and it doesn't match, reject
          if (registeredToken && payload.sid && payload.sid !== registeredToken) {
            return NextResponse.json(
              { error: 'Your account was logged in from another device. Please log in again.' },
              { status: 401 }
            )
          }
        }
      } catch {
        // If we can't parse the session, let it through (HMAC already validated)
      }
    }
    // Pass session info via headers for downstream handlers
    const response = NextResponse.next();
    response.headers.set('x-session-userid', session.id);
    response.headers.set('x-session-username', session.username);
    response.headers.set('x-session-role', session.role);
    return response;
  }

  // ──────────────────────────────────────────────────────────
  // LEGACY LARAVEL PROXY (only for non-API routes)
  // ──────────────────────────────────────────────────────────
  const SKIP_PATHS = ['/_next', '/_error', '/favicon.ico', '/__nextjs'];
  if (SKIP_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const isAvailable = await checkLaravelAvailable();
  if (!isAvailable) {
    return NextResponse.next();
  }

  const targetUrl = `${LARAVEL_BASE}${pathname}${search}`;

  const headers = new Headers(request.headers);
  headers.set('Host', 'localhost:8000');
  headers.set('X-Forwarded-Host', request.headers.get('host') || 'localhost');
  headers.set('X-Forwarded-Proto', request.nextUrl.protocol.replace(':', '') || 'https');
  headers.set('X-Forwarded-Port', request.nextUrl.port || '443');
  headers.set('X-Forwarded-For', request.headers.get('x-forwarded-for') || '127.0.0.1');

  let body: BodyInit | null = null;
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    try {
      body = await request.arrayBuffer();
      if ((body as ArrayBuffer).byteLength === 0) body = null;
    } catch { body = null; }
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const response = await fetch(targetUrl, { method: request.method, headers, body, redirect: 'manual', signal: controller.signal });
    clearTimeout(timeout);

    const responseHeaders = new Headers(response.headers);
    const location = responseHeaders.get('Location');
    if (location) {
      responseHeaders.set('Location', location.replace(/https?:\/\/localhost:8000/g, ''));
    }
    responseHeaders.delete('transfer-encoding');
    responseHeaders.delete('content-encoding');
    responseHeaders.delete('content-length');

    const contentType = responseHeaders.get('content-type') || '';
    if (contentType.includes('text/html')) {
      let html = await response.text();
      html = html.replace(/https?:\/\/localhost:8000/g, '');
      return new NextResponse(html, { status: response.status, statusText: response.statusText, headers: responseHeaders });
    }
    return new NextResponse(response.body, { status: response.status, statusText: response.statusText, headers: responseHeaders });
  } catch {
    laravelAvailable = false;
    lastChecked = Date.now();
    return NextResponse.next();
  }
}

export const config = {
  // Match every path except Next internals
  matcher: ['/((?!_next/static|_next/image|_next/data|favicon\\.ico).*)'],
};
