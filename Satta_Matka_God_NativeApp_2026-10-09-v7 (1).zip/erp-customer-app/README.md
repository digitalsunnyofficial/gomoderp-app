# Satta Matka God — ERP + Customer Android App

A two-sided matka bookkeeping and betting-operations platform:

- **Admin ERP** (`/merp`) — role-based SPA for markets, inventory codes, card entries ("vyapar"), customers, settlements ("hisab"), a unified text parser, game management (23 games), result declaration/settlement, payments with a business UPI QR, subscriptions and audits.
- **Customer App** (`/app`) — mobile-styled web app for customers: approval-gated signup, live market cards with countdown timers, bets across single/jodi/panna/motor/chart games, WhatsApp paste-play, wallet with deposits (business QR) and withdrawals, result announcements with personal win/loss prompts, 4 languages (EN/HI/GU/MR).

Full system documentation: **[`ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md`](./ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md)** — architecture, every page, database, API reference, business rules, examples, known issues.

## Technology stack

| Layer | Tech |
|---|---|
| Framework | Next.js 16 (App Router, Turbopack, `output: "standalone"`) |
| Language | TypeScript 5 · React 19 |
| Database | SQLite via Prisma 6 (`db/custom.db`, 35 models) |
| UI | Tailwind CSS 4 + shadcn/ui (Radix), Zustand 5, lucide-react |
| Auth | Signed HMAC session cookie (ERP) + Bearer AppSession (app), bcryptjs |
| Runtime | bun (or Node 20+) |

## Installation

```bash
# 1. install dependencies
bun install            # or: npm install

# 2. environment
cp .env.example .env   # then edit values (SESSION_SECRET required in production)

# 3. generate the Prisma client
bun run db:generate    # or: npx prisma generate

# 4. create/sync the database (no migration history — this project uses db push)
bun run db:push

# 5. seed demo/production data
bun run db:seed                                    # ERP users, codes, plans
node scripts/seed-app.js                           # app markets, 23 games, allocations, demo customers
```

## Commands

| Purpose | Command |
|---|---|
| Development | `bun run dev` (port 3000) |
| Build | `bun run build` |
| Production start | `bun run start` (runs the standalone server) |
| Lint | `bun run lint` |
| DB sync (no migrations) | `bun run db:push` |
| DB seed | `bun run db:seed` |
| Parser regression suite | `bun scripts/test-entry-parser.ts` (51 checks) |
| Games engine suite | `bun scripts/test-games-engine.ts` (23 checks) |

## Database

- SQLite file at `db/custom.db`; `DATABASE_URL` relative paths are resolved to absolute paths at runtime (`src/lib/db.ts`) so the standalone build finds the DB.
- Schema changes use **`prisma db push`** (this project intentionally has no migrations folder). For production change history, introduce `prisma migrate` (see documentation §27).
- `prisma/seed.js` seeds ERP accounts; `scripts/seed-app.js` seeds the customer app (markets with weekly schedules, 23-game catalog, allocations, 5 demo customers, payment settings).

**Seeded demo accounts** (change in production!):

| System | Account | Password |
|---|---|---|
| ERP Super Admin | `superadmin@mb.com` | `SAdmin@123_321` |
| ERP Manager | `admin@mb.com` | `Admin@123_321` |
| ERP Agent | `agent@mb.com` | `Agent@123_321` |
| Customer App | `9812345601` (Rahul) … 5 customers | `Rahul@123` etc. |

## Project structure

```
├── ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md   # master documentation (27 sections)
├── prisma/schema.prisma                       # 35 models (ERP + Customer App)
├── prisma/seed.js                             # ERP seed
├── db/custom.db                               # SQLite database (dev/demo data)
├── scripts/                                   # seeds, test suites, ops scripts
├── src/
│   ├── proxy.ts                               # auth gate for all /api/* + public prefixes
│   ├── instrumentation.ts                     # market scheduler bootstrap (60 s cron)
│   ├── app/
│   │   ├── merp/page.tsx                      # ERP SPA (shell + card view + legacy parser)
│   │   ├── app/page.tsx                       # mounts the Customer App
│   │   ├── landing/ · marketing/ · agent/access/[token]/
│   │   └── api/                               # ~50 route handlers (customer-app, app-admin, ERP)
│   ├── components/
│   │   ├── pages/                             # ERP page components (per PageName)
│   │   ├── customerapp/                       # Customer App screens/modals
│   │   ├── matka/                             # group batch input/preview
│   │   ├── layout/ · ui/                      # sidebar/topbar · shadcn primitives
│   │   └── shared-ui.tsx
│   └── lib/
│       ├── matka/                             # entry-parser, term-registry, games-engine,
│       │                                      # app-engine, games, group engines, i18n
│       ├── auth.ts · session.ts · app-auth.ts # auth/session/wallet
│       ├── market-cron.ts · cron.ts           # market lifecycle
│       ├── store.ts · navigation.ts           # SPA state + nav
│       └── db.ts · audit.ts · api-helpers.ts
└── .env.example
```

## Important configuration

- `src/proxy.ts` — every `/api/*` route is gated by the signed `erp_session` cookie except public prefixes (`/api/customer-app`, `/api/cron`, `/api/agent/access`, `/api/subscription-plans`) and exact public routes. Customer-app routes authenticate with Bearer tokens (`AppSession`).
- `src/instrumentation.ts` — starts the market scheduler on server boot: flips app markets `scheduled → open → closed` per weekly timings + bet-closing minutes (IST) every 60 s.
- `next.config.ts` — `typescript.ignoreBuildErrors: true`, standalone output; adjust `allowedDevOrigins` for preview domains.
- Set strong `SESSION_SECRET` and `CRON_SECRET` in production (see `.env.example`).

## Documentation

- **Master doc:** `ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md` (overview, architecture, every admin/app page, market management, inventory, transaction flow, parser, validation, results, settlement, balance, database, API reference, business rules, error handling, examples, code map, testing, status, known issues, roadmap).
- Work log of incremental changes: `worklog.md`.
