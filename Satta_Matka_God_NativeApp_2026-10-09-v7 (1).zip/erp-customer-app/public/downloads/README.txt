# Satta Matka God — Customer Android App — APK Drop Folder

Place the built Android app package here with the EXACT filename:

    satta-matka-god.apk

The public landing page (/) checks for this file automatically:
- File present  → gold "Download App (APK)" button works
- File absent   → friendly "App package not published yet" state

How to build the APK: see `download/Customer_App_Android_APK_and_Hosting_Guide.docx`
(Capacitor wrapper build, signing, and the domain/hosting changes).

After replacing the APK, also bump APP_VERSION in
src/components/public/DownloadCta.tsx so customers see the correct
version on the download page.
