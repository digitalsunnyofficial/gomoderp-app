# Satta Matka God — backend quick start
Full guide: ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md · Native app: ../SETUP_NATIVE_APP.md
```bash
npm install
npx prisma generate
npm run dev            # http://localhost:3000  (landing /  /merp ERP  /app web-customer)
```
Demo state ships in db/custom.db (agentsanjay + 3 customers, ₹280 pending commission @2%).
Includes the Task-31 push layer + Task-32 Phase-2 API surface (results months
param) for the native customer app.
