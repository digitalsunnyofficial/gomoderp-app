// Probe: how does the parser treat an unknown label line followed by entries?
import { parseUnifiedEntry } from '../src/lib/matka/entry-parser'
const p = parseUnifiedEntry('wamalang\n128=75', 100, [])
console.log(JSON.stringify({
  singles: p.singles, unknownLabels: p.unknownLabels, skipped: p.skipped,
}, null, 2))
const p2 = parseUnifiedEntry('wamalang\nhello', 100, [])
console.log(JSON.stringify({ u2: p2.unknownLabels, s2: p2.skipped }, null, 2))
