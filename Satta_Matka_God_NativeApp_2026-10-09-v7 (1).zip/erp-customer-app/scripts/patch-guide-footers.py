#!/usr/bin/env python3
# patch-guide-footers.py — WPS compatibility post-processing per docx skill toc.md:
#   1. Remove empty <w:pgNumType/> (docx-js emits it on the cover section)
#   2. Patch footer PAGE instrText with explicit format switches:
#      front-matter footer → PAGE \* ROMAN \* MERGEFORMAT
#      body footer         → PAGE \* arabic \* MERGEFORMAT
# Footer→section mapping resolved via document.xml sectPr order + rels.
import re, sys, zipfile, shutil, os

DOCX = "/home/z/my-project/download/Satta_Matka_God_Deployment_and_Operations_Guide.docx"
TMP = DOCX + ".tmp"

with zipfile.ZipFile(DOCX, "r") as z:
    names = z.namelist()
    files = {n: z.read(n) for n in names}

doc = files["word/document.xml"].decode("utf-8")

# 1. strip empty pgNumType
before = doc.count("<w:pgNumType/>")
doc = doc.replace("<w:pgNumType/>", "")
print(f"removed {before} empty <w:pgNumType/>")

# 2. map sectPr order → footer rIds (default footerReference per section)
sect_blocks = re.findall(r"<w:sectPr[^>]*>.*?</w:sectPr>", doc, flags=re.S)
print(f"found {len(sect_blocks)} sectPr blocks")
rels = files["word/_rels/document.xml.rels"].decode("utf-8")
rid_to_target = dict(re.findall(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels))

section_footers = []  # in section order
for blk in sect_blocks:
    m = re.search(r'<w:footerReference w:type="default" r:id="([^"]+)"', blk)
    section_footers.append(rid_to_target.get(m.group(1)) if m else None)
print("section footers in order:", section_footers)

# Expected: [None (cover), footerN (front matter → ROMAN), footerM (body → arabic)]
roman_footer = section_footers[1] if len(section_footers) > 1 else None
arabic_footer = section_footers[2] if len(section_footers) > 2 else None
assert roman_footer and arabic_footer and roman_footer != arabic_footer, "unexpected footer layout"

def patch_footer(fname, fmt):
    xml = files["word/" + fname].decode("utf-8")
    xml2, n = re.subn(
        r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
        rf"\1 PAGE \\* {fmt} \\* MERGEFORMAT \2",
        xml,
    )
    files["word/" + fname] = xml2.encode("utf-8")
    print(f"patched {fname} → {fmt} ({n} field(s))")

patch_footer(roman_footer, "ROMAN")
patch_footer(arabic_footer, "arabic")
files["word/document.xml"] = doc.encode("utf-8")

with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        z.writestr(n, files[n])
shutil.move(TMP, DOCX)
print("OK", os.path.getsize(DOCX), "bytes")
