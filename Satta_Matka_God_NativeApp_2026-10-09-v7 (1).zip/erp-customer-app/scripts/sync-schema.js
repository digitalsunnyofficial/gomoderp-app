// Schema self-heal for deployments — runs `prisma db push --skip-generate`
// against THIS project's SQLite file with an ABSOLUTE path.
//
// Why not bare `prisma db push`?
//   1. Prisma resolves RELATIVE sqlite urls against the schema directory, not
//      the project root — a `.env` value of `file:./db/custom.db` can push to
//      the wrong file depending on host/cwd.
//   2. Some hosts export a stale global DATABASE_URL that would silently win.
// This script kills both ambiguities: it always targets
//   <project-root>/db/custom.db
// which is exactly the file src/lib/db.ts opens at runtime.
//
// Additive-only: `db push` without --accept-data-loss adds missing
// tables/columns and REFUSES anything destructive — customer data can never
// be dropped by a deploy.

const path = require('path')
const { execSync } = require('child_process')

const root = path.resolve(__dirname, '..')
const dbFile = path.join(root, 'db', 'custom.db')
const url = 'file:' + dbFile

try {
  execSync('npx prisma db push --skip-generate', {
    cwd: root,
    stdio: 'inherit',
    env: { ...process.env, DATABASE_URL: url },
  })
} catch (e) {
  // Loud failure — a deploy whose schema cannot sync must not boot silently.
  console.error('[sync-schema] FAILED for ' + dbFile)
  process.exit(1)
}
