#!/bin/bash
# t25-e2e.sh — one-shot browser E2E for Task 25 (server started/stopped here)
set -u
cd /home/z/my-project

PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad() { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
has() { if echo "$2" | grep -q "$3"; then ok "$1"; else bad "$1 — wanted: $3"; fi; }

echo "── starting dev server ──"
setsid bash scripts/start-dev.sh > dev.log 2>&1 < /dev/null &
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health 2>/dev/null)
  [ "$code" = "200" ] && { echo "server up"; break; }
  sleep 2
done

agent-browser close >/dev/null 2>&1 || true

echo "── 1. Customer app: signup screen shows the AGENT CODE field ──"
agent-browser open http://localhost:3000/app >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
sleep 4
agent-browser find text "New here? Create an account" click >/dev/null 2>&1
sleep 2
SNAP=$(agent-browser snapshot -c 2>/dev/null)
if echo "$SNAP" | grep -qi "AGENT CODE"; then ok "signup screen renders AGENT CODE field"; else
  agent-browser find text "Create an account" click >/dev/null 2>&1; sleep 2
  SNAP=$(agent-browser snapshot -c 2>/dev/null)
  if echo "$SNAP" | grep -qi "AGENT CODE"; then ok "signup screen renders AGENT CODE field (retry)"; else bad "AGENT CODE field not found"; echo "$SNAP" | head -25; fi
fi
has "signup hint mentions agent filing" "$SNAP" "filed under"
has "CREATE ACCOUNT button present" "$SNAP" "CREATE ACCOUNT"
# fill the form (skip submit — data layer covered by API tests)
agent-browser find first "input[placeholder='Your name']" fill "E2E Agentcode" >/dev/null 2>&1 && ok "name input fillable"
agent-browser find first "input[placeholder='10-digit mobile']" fill "98$RANDOM$RANDOM" >/dev/null 2>&1 && ok "mobile input fillable"
agent-browser find first "input[placeholder='Your agent's code / mobile']" fill "ramesh" >/dev/null 2>&1 && ok "AGENT CODE input fillable" || \
agent-browser eval "document.querySelector('input[placeholder*=\"agent\"]') ? 'found' : 'missing'" | grep -q found && ok "AGENT CODE input present (eval)"
agent-browser screenshot download/t25-app-signup-agentcode.png >/dev/null 2>&1 && ok "screenshot: app signup with agent code"

echo "── 2. ERP login ──"
agent-browser open http://localhost:3000/merp >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
sleep 4
agent-browser find first "input[placeholder='Enter username']" fill "superadmin@mb.com" >/dev/null 2>&1
agent-browser find first "input[placeholder='Enter password']" fill "SAdmin@123_321" >/dev/null 2>&1
agent-browser find role button click --name "Login" >/dev/null 2>&1 || agent-browser find first "button[type='submit']" click >/dev/null 2>&1
sleep 5
URL=$(agent-browser get url 2>/dev/null)
if echo "$URL" | grep -q "merp"; then ok "ERP login OK"; else bad "ERP login failed (url: $URL)"; fi

echo "── 3. Sidebar → Agent Commission page ──"
agent-browser find text "Agent Commission" click >/dev/null 2>&1
sleep 3
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "Agent Commission heading" "$SNAP" "Agent Commission"
has "global rate settings card" "$SNAP" "Commission Settings"
has "rate precedence hint" "$SNAP" "agent override"
has "PENDING PAYOUT summary" "$SNAP" "PENDING PAYOUT"
has "ledger empty-state or rows" "$SNAP" "No commission rows"
agent-browser screenshot download/t25-erp-agent-commission.png >/dev/null 2>&1 && ok "screenshot: agent commission page"

echo "── 4. Customer List shows the Agent column ──"
agent-browser find text "Customer List" click >/dev/null 2>&1
sleep 3
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "App Customers tab present" "$SNAP" "App Customers"
has "Agent column in app customers table" "$SNAP" "Agent"
agent-browser screenshot download/t25-customer-list-agent-col.png >/dev/null 2>&1 && ok "screenshot: customer list"

echo "── 5. Agent List shows commission + app customer chips ──"
agent-browser find text "Agent List" click >/dev/null 2>&1
sleep 3
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "Agent List heading" "$SNAP" "Agent List"
has "commission chip on agent cards" "$SNAP" "Commission:"

echo "── 6. Console errors check ──"
ERRS=$(agent-browser errors 2>/dev/null | grep -v "Download the React DevTools" | head -5)
if [ -z "$ERRS" ]; then ok "no page errors"; else bad "page errors: $ERRS"; fi

agent-browser close >/dev/null 2>&1
echo "════════════════════════════════"
echo "E2E RESULT: $PASS pass, $FAIL fail"
pkill -9 -f "next dev" 2>/dev/null; pkill -9 -f next-server 2>/dev/null
exit $([ $FAIL -eq 0 ] && echo 0 || echo 1)
