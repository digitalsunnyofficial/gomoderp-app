// Consolidate legacy per-customer Customer App mirror rows into the new
// consolidated-entry design (Task 16.4):
//   - ONE row per (inventory card × model × type × slot) for the app channel
//   - "Submitted By" (createdBy) = 'app' on every card + row
//   - per-customer attribution in parsedData.byCustomer (keys validated as
//     "Name (mobile)" — stray keys from earlier mis-parses are dropped)
//   - details rebuilt deterministically: "Customer App · <code name> · <what> · N customers"
//   - parent card totals recomputed
// Idempotent: running it again is a no-op.
//
// Run: node scripts/consolidate-app-mirror-rows.js
const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

const APP_OWNER = 'app'
// A real customer key always looks like "Name (digits)" — anything else
// (e.g. a market name picked up by an earlier mis-parse) is dropped.
const CUST_KEY_RE = /^(.+) \((\d+)\)$/

function parsePd(raw) {
  try { return JSON.parse(raw || '{}') } catch { return {} }
}

// OLD per-customer details format: "Customer App · Name (mobile) · Display · what"
function customerKeyFromDetails(details) {
  const segs = String(details || '').split(' · ')
  if (segs.length >= 3 && segs[0] === 'Customer App' && CUST_KEY_RE.test(segs[1])) return segs[1]
  return null
}

function detailsIsOldFormat(details) {
  const segs = String(details || '').split(' · ')
  return segs.length >= 3 && segs[0] === 'Customer App' && CUST_KEY_RE.test(segs[1])
}

function whatFromType(type, slot) {
  if (type === 'sangam') return 'sangam bets'
  if (type === 'double') return 'jodi bets'
  if (type === 'single') return 'single bets'
  const s = String(slot || '').split('/')[0]
  return s === 'open' || s === 'close' ? `${s} panna bets` : 'panna bets'
}

async function consolidateModel(rows, model, cardName) {
  if (!rows.length) return { merged: 0, deleted: 0, renamed: 0 }

  // Group by (type, slot) — different slots are different session buckets
  // and must never merge together.
  const groups = new Map()
  for (const r of rows) {
    const pd = parsePd(r.parsedData)
    const key = `${r.type}|${pd.slot || ''}`
    const arr = groups.get(key) || []
    arr.push({ row: r, pd })
    groups.set(key, arr)
  }

  let merged = 0, deleted = 0, renamed = 0
  for (const [, members] of groups) {
    // primary = earliest created row
    members.sort((a, b) => new Date(a.row.createdAt) - new Date(b.row.createdAt))
    const primary = members[0]
    const rest = members.slice(1)

    // ── collect customer attribution from every member ──
    const byCustomer = {}
    const addCustomer = (key, num, pts) => {
      if (!key || !num || !pts || !CUST_KEY_RE.test(key)) return
      byCustomer[num] = byCustomer[num] || {}
      byCustomer[num][key] = (byCustomer[num][key] || 0) + pts
    }
    for (const m of members) {
      const ck = customerKeyFromDetails(m.row.details) // only OLD-format rows
      for (const [num, custs] of Object.entries(m.pd.byCustomer || {})) {
        for (const [k, pts] of Object.entries(custs)) addCustomer(k, num, Number(pts) || 0)
      }
      for (const n of m.pd.numbers || []) {
        if (!ck) continue
        addCustomer(ck, n.number, Number(n.price) || 0)
      }
    }
    const customers = [...new Set(Object.values(byCustomer).flatMap(c => Object.keys(c)))]

    // ── merge numbers across all members ──
    const numMap = new Map()
    let totalEntriesCount = 0
    const gameCodes = new Set()
    const slots = new Set()
    for (const m of members) {
      for (const n of m.pd.numbers || []) {
        const p = Number(n.price) || 0
        if (!p) continue
        numMap.set(n.number, (numMap.get(n.number) || 0) + p)
      }
      totalEntriesCount += Number(m.pd.totalEntriesCount || (m.pd.numbers || []).length)
      for (const g of m.pd.gameCodes || []) { if (g) gameCodes.add(g) }
      if (m.pd.slot) String(m.pd.slot).split('/').forEach(s => slots.add(s))
    }
    // ascending order for a deterministic display
    const numbers = [...numMap.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([number, price]) => ({ number, price }))
    const total = numbers.reduce((a, n) => a + n.price, 0)

    const isSangam = primary.row.type === 'sangam'
    const slot = [...slots].join('/')
    const outPd = {
      entries: isSangam ? numbers.map(n => ({ ...n, sangam: true })) : numbers,
      numbers,
      byCustomer,
      customers,
      totalEntriesCount,
      source: 'customer-app',
      marketCode: primary.pd.marketCode,
      slot,
      gameCodes: [...gameCodes],
    }
    const what = whatFromType(primary.row.type, slot)
    const details = `Customer App · ${cardName} · ${what} · ${customers.length} customer${customers.length === 1 ? '' : 's'}`

    const hasStrayKeys = Object.values(primary.pd.byCustomer || {})
      .some(custs => Object.keys(custs).some(k => !CUST_KEY_RE.test(k)))

    const needsUpdate =
      rest.length > 0 ||
      primary.row.createdBy !== APP_OWNER ||
      !primary.pd.byCustomer ||
      hasStrayKeys ||
      primary.row.details !== details ||
      JSON.stringify(primary.pd.numbers || []) !== JSON.stringify(numbers)

    if (needsUpdate) {
      const data = { details, parsedData: JSON.stringify(outPd), totalAmount: total }
      if (primary.row.createdBy !== APP_OWNER) { data.createdBy = APP_OWNER; renamed++ }
      if (model === 'triple') {
        await db.tripleInventory.update({ where: { id: primary.row.id }, data })
      } else {
        await db.doubleSingleInventory.update({ where: { id: primary.row.id }, data })
      }
      merged++
    }
    for (const m of rest) {
      if (model === 'triple') await db.tripleInventory.delete({ where: { id: m.row.id } })
      else await db.doubleSingleInventory.delete({ where: { id: m.row.id } })
      deleted++
    }
  }
  return { merged, deleted, renamed }
}

async function main() {
  const [triples, doubles] = await Promise.all([
    db.tripleInventory.findMany({ orderBy: { createdAt: 'asc' } }),
    db.doubleSingleInventory.findMany({ orderBy: { createdAt: 'asc' } }),
  ])
  const appTriples = triples.filter(r => parsePd(r.parsedData).source === 'customer-app')
  const appDoubles = doubles.filter(r => parsePd(r.parsedData).source === 'customer-app')
  const cardIds = new Set([...appTriples, ...appDoubles].map(r => r.inventoryId))
  console.log(`app-source rows: triple=${appTriples.length} ds=${appDoubles.length} across ${cardIds.size} card(s)`)

  const cards = await db.inventory.findMany({ where: { id: { in: [...cardIds] } }, include: { inventoryCode: true } })
  const cardName = new Map(cards.map(c => [c.id, c.inventoryCode.name]))

  let tMerged = 0, tDeleted = 0, dMerged = 0, dDeleted = 0
  for (const invId of cardIds) {
    const a = await consolidateModel(appTriples.filter(r => r.inventoryId === invId), 'triple', cardName.get(invId) || '')
    const b = await consolidateModel(appDoubles.filter(r => r.inventoryId === invId), 'ds', cardName.get(invId) || '')
    tMerged += a.merged; tDeleted += a.deleted
    dMerged += b.merged; dDeleted += b.deleted
  }

  // Cards + rows: Submitted By = the channel itself
  const cardUpdate = await db.inventory.updateMany({ where: { id: { in: [...cardIds] }, NOT: { createdBy: APP_OWNER } }, data: { createdBy: APP_OWNER } })
  const tOwner = await db.tripleInventory.updateMany({ where: { id: { in: appTriples.map(r => r.id) }, NOT: { createdBy: APP_OWNER } }, data: { createdBy: APP_OWNER } })
  const dOwner = await db.doubleSingleInventory.updateMany({ where: { id: { in: appDoubles.map(r => r.id) }, NOT: { createdBy: APP_OWNER } }, data: { createdBy: APP_OWNER } })

  // Recompute parent totals
  for (const invId of cardIds) {
    const [ts, ds] = await Promise.all([
      db.tripleInventory.findMany({ where: { inventoryId: invId } }),
      db.doubleSingleInventory.findMany({ where: { inventoryId: invId } }),
    ])
    const total = ts.reduce((s, t) => s + t.totalAmount, 0) + ds.reduce((s, t) => s + t.totalAmount, 0)
    await db.inventory.update({ where: { id: invId }, data: { totalAmount: total, totalTxn: total } })
  }

  console.log(`triple rows updated=${tMerged} deleted=${tDeleted}; ds rows updated=${dMerged} deleted=${dDeleted}`)
  console.log(`submittedBy -> 'app': cards=${cardUpdate.count} tripleRows=${tOwner.count} dsRows=${dOwner.count}`)

  // ── verification dump (compact) ──
  for (const invId of cardIds) {
    const inv = cards.find(c => c.id === invId)
    const [ts, ds] = await Promise.all([
      db.tripleInventory.findMany({ where: { inventoryId: invId } }),
      db.doubleSingleInventory.findMany({ where: { inventoryId: invId } }),
    ])
    console.log(`\nCard ${inv.inventoryCode.name} createdBy=${inv.createdBy} total=${inv.totalAmount}`)
    for (const t of ts) {
      const pd = parsePd(t.parsedData)
      const stray = Object.values(pd.byCustomer || {}).flatMap(c => Object.keys(c)).filter(k => !CUST_KEY_RE.test(k))
      console.log(`  T[${t.type}/${pd.slot}] "${t.details}" nums=${(pd.numbers || []).length} amt=${t.totalAmount} by=${t.createdBy} customers=${JSON.stringify(pd.customers)}${stray.length ? ` STRAY_KEYS=${JSON.stringify(stray)}` : ''}`)
    }
    for (const d of ds) {
      const pd = parsePd(d.parsedData)
      const stray = Object.values(pd.byCustomer || {}).flatMap(c => Object.keys(c)).filter(k => !CUST_KEY_RE.test(k))
      console.log(`  D[${d.type}/${pd.slot}] "${d.details}" nums=${JSON.stringify(pd.numbers)} by=${d.createdBy}${stray.length ? ` STRAY_KEYS=${JSON.stringify(stray)}` : ''}`)
    }
  }
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
