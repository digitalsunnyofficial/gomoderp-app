// E2E: jodi open-session guard + ank-family bet acceptance (2026-09 update)
// 1) login as demo customer Rahul
// 2) find a market whose OPEN session is NOT accepting -> jodi bet must 400
//    with the jodi session message
// 3) find a market whose OPEN session IS accepting -> jodi bet must place
//    (10 pts) and wallet must drop by exactly 10
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()
const BASE = 'http://127.0.0.1:3000'
let fails = 0
function check(label, cond, extra = '') {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + label + (extra ? ' — ' + extra : ''))
  if (!cond) fails++
}

const loginRes = await fetch(BASE + '/api/customer-app/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ mobile: '9812345601', password: 'Rahul@123' }),
})
const login = await loginRes.json()
check('login ok', loginRes.ok && !!login.token, loginRes.status)
const auth = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + login.token }

const homeRes = await fetch(BASE + '/api/customer-app/home', { headers: auth })
const home = await homeRes.json()
const markets = home.markets.filter(m => !String(m.code).startsWith('st'))
check('home markets loaded', markets.length > 0, String(markets.length))

const closedOpen = markets.find(m => m.session === 'close') || markets.find(m => m.isOn !== false && m.openAccepting === false)
const openLive = markets.find(m => m.isOn !== false && m.session !== 'close' && m.openAccepting === true && m.resultDeclared !== true)

// ── rejection case: open session not accepting → jodi blocked ──
if (closedOpen) {
  const r = await fetch(BASE + '/api/customer-app/bets', {
    method: 'POST', headers: auth,
    body: JSON.stringify({ items: [{ marketCode: closedOpen.code, slot: 'jodi', type: 'jodi', num: '12', points: 10 }] }),
  })
  const d = await r.json()
  check('jodi blocked when open session closed (' + closedOpen.code + ')', r.status === 400, r.status + ' ' + String(d.error || '').slice(0, 90))
  check('error mentions the jodi session rule', String(d.error || '').toLowerCase().includes('jodi'))
  if (closedOpen.session === 'close') check('close-session market row rejects jodi outright', r.status === 400)
} else {
  console.log('SKIP  no market with closed open session right now — rejection case covered by engine logic')
}

// ── acceptance case: open session live → jodi places, wallet math exact ──
if (openLive) {
  const me1 = await (await fetch(BASE + '/api/customer-app/me', { headers: auth })).json()
  const walletBefore = me1.customer.wallet
  const r = await fetch(BASE + '/api/customer-app/bets', {
    method: 'POST', headers: auth,
    body: JSON.stringify({ items: [{ marketCode: openLive.code, slot: 'jodi', type: 'jodi', num: '12', points: 10 }] }),
  })
  const d = await r.json()
  check('jodi placed while open session live (' + openLive.code + ')', r.status === 200 && d.ok === true, r.status + ' ' + String(d.error || '').slice(0, 90))
  const me2 = await (await fetch(BASE + '/api/customer-app/me', { headers: auth })).json()
  check('wallet debited exactly 10', me2.customer.wallet === walletBefore - 10, walletBefore + ' → ' + me2.customer.wallet)
  check('ERP mirror ran', String(d.mirrorNote || '').includes('ERP entry'), d.mirrorNote)
} else {
  console.log('SKIP  no market with live open session right now')
}

// ── sanity: engine-level dp-motor + family rows already verified in
// scripts/test-games-engine.ts (96 checks) — here just confirm the app home
// exposes the ank-family games for play screens ──
const anyMk = markets[0]
const codes = (anyMk.games || []).map(g => g.code)
check('ank-family games allocated to ' + anyMk.code, ['sp', 'dp', 'tp', 'spdp', 'sptp', 'dptp', 'spdptp', 'dp-motor'].every(c => codes.includes(c)), codes.join(','))

await db.$disconnect()
process.exit(fails ? 1 : 0)
