/**
 * shot-fixtures.ts — screenshot-session fixtures for the CUSTOMER GUIDE
 * screenshots (landing page + operator manual). Creates a rich, realistic
 * demo state, the capture script photographs it, then `down` removes every
 * trace. Safe against the RUNNING server on :3000 (no restart, no pkill).
 *
 *   bun scripts/shot-fixtures.ts up
 *   bun scripts/shot-fixtures.ts down
 *
 * Fixtures:
 *   customer A  9912900001 / Shot@12345  approved, wallet ~4300, bets, ledger
 *   market      zzshot "Milan Star"      open window = now+2h (IST), 4 games
 *   starline    st<curHour> declared TODAY (panna 456 / digit 5)
 *   withdraw    ₹500 pending (ON HOLD section)
 */
import { PrismaClient } from '@prisma/client'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

const A_MOBILE = '9912900001'
const PW = 'Shot@12345'
const MK = 'zzshot'

async function j(method: string, path: string, body?: unknown, headers: Record<string, string> = {}) {
  const r = await fetch(`${BASE}${path}`, {
    method,
    headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  })
  let data: any = null
  try { data = await r.json() } catch { /* html */ }
  return { status: r.status, data }
}

async function deleteCustomer(mobile: string) {
  const c = await db.appCustomer.findUnique({ where: { mobile } })
  if (!c) return
  await db.appBet.deleteMany({ where: { customerId: c.id } })
  await db.appTransaction.deleteMany({ where: { customerId: c.id } })
  await db.appWithdrawRequest.deleteMany({ where: { customerId: c.id } })
  await db.appFundRequest.deleteMany({ where: { customerId: c.id } })
  await db.appNotification.deleteMany({ where: { customerId: c.id } })
  await db.appSession.deleteMany({ where: { customerId: c.id } })
  await db.appCustomer.delete({ where: { id: c.id } })
}

export async function down() {
  const ist = new Date(Date.now() + 5.5 * 3600 * 1000)
  const curH = ist.getUTCHours()
  await db.appResult.deleteMany({ where: { marketCode: 'st' + curH, declaredBy: 'shot-fixture' } })
  await deleteCustomer(A_MOBILE)
  await deleteCustomer('9912900002') // customer B created from the UI signup shot
  await db.gameAllocation.deleteMany({ where: { marketCode: MK } })
  await db.appMarket.deleteMany({ where: { code: MK } })
  console.log('fixtures down — all screenshot state removed')
}

async function up() {
  await down()

  // ── customer A: signup → approve → login ──
  const su = await j('POST', '/api/customer-app/auth/signup', { name: 'Ravi Sharma', mobile: A_MOBILE, password: PW })
  if (su.status !== 200) throw new Error('signup failed: ' + JSON.stringify(su.data))
  await db.appCustomer.update({ where: { mobile: A_MOBILE }, data: { approvalStatus: 'approved', approvedBy: 'shot-fixture', approvedAt: new Date() } })
  const li = await j('POST', '/api/customer-app/auth/login', { mobile: A_MOBILE, password: PW })
  const token = li.data?.token as string
  if (!token) throw new Error('login failed: ' + JSON.stringify(li.data))
  const H = { Authorization: 'Bearer ' + token }

  // ── ERP session for approvals ──
  const adm = await fetch(`${BASE}/api/auth`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'superadmin@mb.com', password: 'SAdmin@123_321' }),
  })
  const cookie = (adm.headers.get('set-cookie') || '').split(';')[0].replace(/\r/g, '')

  // ── deposit ₹5000 → approve (wallet + ledger + notification) ──
  const fr = await j('POST', '/api/customer-app/funds', { amount: 5000, method: 'UPI', utr: 'SHOT' + Date.now().toString().slice(-8) }, H)
  const fundId = fr.data?.fund?.id || fr.data?.id || fr.data?.requestId
  const fap = await j('POST', '/api/app-admin/funds', { id: fundId, action: 'approve' }, { Cookie: cookie })
  if (fap.status !== 200) throw new Error('fund approve failed: ' + JSON.stringify(fap.data))

  // ── temp market "Milan Star" accepting right now + 4 game allocations ──
  const ist = new Date(Date.now() + 5.5 * 3600 * 1000)
  const curMins = ist.getUTCHours() * 60 + ist.getUTCMinutes()
  const oMins = Math.min(curMins + 120, 1439)
  const cMins = Math.min(oMins + 60, 1439)
  const hm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
  await db.appMarket.create({ data: {
    code: MK, name: 'Milan Star', phase: 'none', session: 'both',
    openTime: hm(oMins), closeTime: hm(cMins), betClosingMinutes: 0, isOn: true, isActive: true, sortOrder: -1,
  } })
  const games = await db.game.findMany({ where: { code: { in: ['single', 'jodi', 'sp', 'dp'] } } })
  const rates: Record<string, number> = { single: 9, jodi: 90, sp: 140, dp: 280 }
  for (const g of games) {
    await db.gameAllocation.create({ data: { gameId: g.id, marketCode: MK, rate: rates[g.code] ?? null, minPoints: 10, isActive: true } })
  }

  // ── declared starline for the current hour (board + starline screen) ──
  const curH = ist.getUTCHours()
  await db.appResult.create({ data: {
    marketCode: 'st' + curH, marketName: 'Starline ' + String(curH).padStart(2, '0') + ':00',
    resultDate: ist.toISOString().slice(0, 10), openPanna: '456', openDigit: '5', declaredBy: 'shot-fixture',
  } })

  // ── a few bets (My Bids + home latest-results state) ──
  const b1 = await j('POST', '/api/customer-app/bets', { items: [
    { marketCode: MK, slot: 'open', type: 'single', num: '5', points: 100, clientRequestId: 'shot-' + Date.now() + '-a' },
  ] }, H)
  if (b1.status !== 200 || b1.data?.placedCount !== 1) throw new Error('single bet failed: ' + JSON.stringify(b1.data))
  const b2 = await j('POST', '/api/customer-app/bets', { items: [
    { marketCode: MK, slot: 'open', type: 'jodi', num: '56', points: 20, clientRequestId: 'shot-' + Date.now() + '-b' },
  ] }, H)
  if (b2.status !== 200 || b2.data?.placedCount !== 1) throw new Error('jodi bet failed: ' + JSON.stringify(b2.data))

  // ── pending withdrawal ₹500 (ON HOLD section in wallet) ──
  const wd = await j('POST', '/api/customer-app/withdrawals', { amount: 500 }, H)
  if (wd.status !== 200) throw new Error('withdraw failed: ' + JSON.stringify(wd.data))

  const me = await j('GET', '/api/customer-app/me', undefined, H)
  console.log('fixtures up — customer A wallet:', me.data?.customer?.wallet, '| market zzshot +', games.length, 'games | starline st' + curH)
}

const cmd = process.argv[2]
if (cmd === 'up') up().catch(e => { console.error(e); process.exitCode = 1 }).finally(() => db.$disconnect())
else if (cmd === 'down') down().catch(e => { console.error(e); process.exitCode = 1 }).finally(() => db.$disconnect())
else { console.error('usage: bun scripts/shot-fixtures.ts up|down'); process.exitCode = 1; db.$disconnect() }
