// Quick verification of the games engine expansions
import { expandGame } from '../src/lib/matka/games-engine'

let fails = 0
function check(label: string, cond: boolean, extra = '') {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + label + (extra ? ' — ' + extra : ''))
  if (!cond) fails++
}

// ── Motor Pana + SP Motor — ADMIN PARITY (2026-09 operator fix) ──
// The operator showed the admin panel motor calculation listing 120 pannas
// (full digit set) while the app produced 125 for a 5-digit seed (5³
// arrangements incl. DP/TP rows and 6 orderings of the same panna). Both
// games now calculate EXACTLY like the admin panel's Motor Pana group
// preview: every C(n,3) combination of 3 DIFFERENT digits, one canonical
// (ascending, 0 last) spelling each.
const spMotor = expandGame('sp-motor', '13467')
check('SP Motor 13467 → 10 rows (C(5,3), admin parity)', spMotor.rows.filter(r => r.ok).length === 10, String(spMotor.rows.filter(r => r.ok).length))
check('SP Motor all sp type', spMotor.rows.every(r => r.type === 'sp'))

const motor = expandGame('motor', '13467')
check('Motor 13467 → 10 rows (C(5,3), admin parity)', motor.rows.filter(r => r.ok).length === 10, String(motor.rows.filter(r => r.ok).length))
check('Motor identical to SP Motor (logic always same)', JSON.stringify(motor.rows) === JSON.stringify(spMotor.rows))
check('Motor has NO dp/tp rows (admin motor is SP-only)', motor.rows.every(r => r.type === 'sp'))
check('Motor rows canonical with 3 different digits', motor.rows.every(r => r.ok && new Set(r.num).size === 3 && canonicalPanna(r.num) === r.num))
check('Motor 13467 exact panna set', JSON.stringify(motor.rows.filter(r => r.ok).map(r => r.num)) === JSON.stringify(['134', '136', '137', '146', '147', '167', '346', '347', '367', '467']))

// 6-digit seed → C(6,3) = 20
const motor6 = expandGame('motor', '123456')
check('Motor 123456 → 20 rows (C(6,3))', motor6.rows.filter(r => r.ok).length === 20, String(motor6.rows.filter(r => r.ok).length))

// Full digit set 0-9 → the 120-panna SP universe — the admin Group Preview count
const motorFull = expandGame('motor', '0123456789')
const motorFullOk = motorFull.rows.filter(r => r.ok)
check('Motor full digit set 0-9 → 120 pannas (admin preview)', motorFullOk.length === 120, String(motorFullOk.length))
const spUniverse = new Set([...SP_CHART_CANONICAL.values()].flat().map(pannaKey))
check('Motor full digit set covers the exact SP universe', motorFullOk.every(r => spUniverse.has(pannaKey(r.num))) && new Set(motorFullOk.map(r => pannaKey(r.num))).size === 120)

// zero-containing seed → single canonical 0-last panna
const motorZero = expandGame('motor', '038')
check('Motor 038 → single canonical panna 380', motorZero.rows.length === 1 && motorZero.rows[0]?.ok === true && motorZero.rows[0]?.num === '380', motorZero.rows[0]?.num)

// fewer than 3 DIFFERENT digits → explicit error row (admin parity message)
const motorShort = expandGame('motor', '1133')
check('Motor 1133 (2 different digits) → not ok with reason', motorShort.rows.length === 1 && motorShort.rows[0]?.ok === false && /3 DIFFERENT/.test(motorShort.rows[0]?.reason || ''), motorShort.rows[0]?.reason)
const motorDup = expandGame('motor', '1134')
check('Motor 1134 dedupes repeats → 1 row 134', motorDup.rows.length === 1 && motorDup.rows[0]?.ok === true && motorDup.rows[0]?.num === '134', motorDup.rows[0]?.num)

// classics
check('single ok', expandGame('single', '5').rows[0]?.ok === true)
check('single rejects 55', expandGame('single', '55').rows.length === 0 || expandGame('single', '55').rows[0]?.ok === false)
check('jodi ok', expandGame('jodi', '70').rows[0]?.num === '70')
check('sp ok 128', expandGame('sp', '128').rows[0]?.type === 'sp')
check('sp rejects 118 (dp)', expandGame('sp', '118').rows.length === 0 && !!expandGame('sp', '118').error)
check('dp ok 118', expandGame('dp', '118').rows[0]?.type === 'dp')
check('tp ok 000', expandGame('tp', '000').rows[0]?.type === 'tp')
check('spdp ok 118→dp', expandGame('spdp', '118').rows[0]?.type === 'dp')
check('sptp rejects 118', expandGame('sptp', '118').rows[0]?.ok === false)

// family set — 112 is a Family Set 6 key
const fam = expandGame('family-6', '112')
check('family-6 112 → 6 rows', fam.rows.filter(r => r.ok).length === 6, String(fam.rows.filter(r => r.ok).length))
check('family-6 contains 112', fam.rows.some(r => r.num === '112'))
const famWrong = expandGame('family-6', '111') // 111 belongs to Set 4
check('family-6 111 explains set mismatch', famWrong.rows[0]?.ok === false && (famWrong.rows[0]?.reason || '').includes('Family Set 4'), famWrong.rows[0]?.reason)
const fam4 = expandGame('family-4', '111')
check('family-4 111 → 4 rows', fam4.rows.filter(r => r.ok).length === 4, String(fam4.rows.filter(r => r.ok).length))

// charts by ank + by panna
const c50 = expandGame('chart-50', '5')
check('chart-50 ank 5 → rows', c50.rows.filter(r => r.ok).length > 0, String(c50.rows.filter(r => r.ok).length))
const c50p = expandGame('chart-50', c50.rows[0].num)
check('chart-50 by panna works', c50p.rows[0]?.ok === true)
const c90 = expandGame('chart-90dp', '0')
check('chart-90dp ank 0 → dp rows', c90.rows.every(r => r.type === 'dp') && c90.rows.length > 0, String(c90.rows.length))

// ──────────────────────────────────────────────────────────
// 2026-09 operator update — canonical charts, 20/30/40 charts,
// combined Family Chart, Half Sangam B, digit-set settlement
// ──────────────────────────────────────────────────────────
import {
  SP_CHART_CANONICAL, DP_CHART_CANONICAL,
  CHART_20_PANNAS, CHART_30_PANNAS, CHART_40_PANNAS,
  isSP, pannaToAnk,
  pannaKey, pannaMatches, canonicalPanna,
} from '../src/lib/matka/chart-definitions'
import { buildFamilyCombined } from '../src/lib/matka/panna-family'
import { betWins, isValidPanna } from '../src/lib/matka/app-engine'
import { GAME_CATALOG } from '../src/lib/matka/games-engine'

// canonical SP chart: 120 pannas, 12 per ank, operator spelling
const spTotal = [...SP_CHART_CANONICAL.values()].reduce((a, v) => a + v.length, 0)
check('canonical SP chart → 120 pannas', spTotal === 120, String(spTotal))
check('canonical SP ank1 starts 137 ends 678', SP_CHART_CANONICAL.get(1)![0] === '137' && SP_CHART_CANONICAL.get(1)![11] === '678')
check('canonical DP chart → 90 pannas', [...DP_CHART_CANONICAL.values()].reduce((a, v) => a + v.length, 0) === 90)

// digit-set equivalence: every canonical panna matches its app-universe twin
const appSpKeys = new Set(Object.values({'0':'019,028','1':'029,038,047,056,128,137,146,236,245,489,579,678'}).join(',').split(',').map(pannaKey))
check('canonical ank1 ≡ app SPB ank1 (digit-sets)', SP_CHART_CANONICAL.get(1)!.every(p => appSpKeys.has(pannaKey(p))))
check('pannaKey 380 → 038', pannaKey('380') === '038')
check('pannaMatches 380/038', pannaMatches('380', '038'))
check('canonicalPanna 038 → 380', canonicalPanna('038') === '380')
check('canonicalPanna 128 stays 128', canonicalPanna('128') === '128')

// 20/30/40 charts — operator-verbatim tables (2026-10 fix: 2/3/4 pannas
// per ank across ALL 10 anks; key 10 = ank 0)
check('20 chart ank1 exact', JSON.stringify(CHART_20_PANNAS.get(1)) === JSON.stringify(['489', '560']))
check('20 chart ank2 exact', JSON.stringify(CHART_20_PANNAS.get(2)) === JSON.stringify(['237', '156']))
check('20 chart ank0 exact (key 10)', JSON.stringify(CHART_20_PANNAS.get(10)) === JSON.stringify(['127', '389']))
check('20 chart → 20 pannas (2 × 10 anks)', [...CHART_20_PANNAS.values()].reduce((a, v) => a + v.length, 0) === 20 && CHART_20_PANNAS.size === 10)
check('30 chart ank1 exact', JSON.stringify(CHART_30_PANNAS.get(1)) === JSON.stringify(['380', '470', '146']))
check('30 chart ank2 exact', JSON.stringify(CHART_30_PANNAS.get(2)) === JSON.stringify(['570', '147', '138']))
check('30 chart → 30 pannas (3 × 10 anks)', [...CHART_30_PANNAS.values()].reduce((a, v) => a + v.length, 0) === 30 && CHART_30_PANNAS.size === 10)
check('40 chart ank1 exact', JSON.stringify(CHART_40_PANNAS.get(1)) === JSON.stringify(['245', '290', '236', '128']))
check('40 chart ank5 exact', JSON.stringify(CHART_40_PANNAS.get(5)) === JSON.stringify(['780', '230', '140', '690']))
check('40 chart → 40 pannas (4 × 10 anks)', [...CHART_40_PANNAS.values()].reduce((a, v) => a + v.length, 0) === 40 && CHART_40_PANNAS.size === 10)

// integrity: every 20/30/40 entry must be a valid SP panna sitting in its
// own ank column (digit-sum % 10, 0 → key 10)
for (const [label, chart] of [['20', CHART_20_PANNAS], ['30', CHART_30_PANNAS], ['40', CHART_40_PANNAS]] as const) {
  let bad = 0
  for (const [ank, rows] of chart) {
    for (const p of rows) {
      if (!isSP(p) || pannaToAnk(p) !== ank) bad++
    }
  }
  check(`chart ${label}: every entry is SP in its own ank column`, bad === 0, `${bad} bad entries`)
}

// new game expansions
const c20 = expandGame('chart-20', '1')
check('chart-20 ank 1 → 2 sp rows 489,560', c20.rows.filter(r => r.ok).length === 2 && c20.rows[0]?.num === '489' && c20.rows[1]?.num === '560' && c20.rows.every(r => r.type === 'sp'))
const c20p = expandGame('chart-20', '560')
check('chart-20 by panna 560 ok', c20p.rows[0]?.ok === true)
const c20x = expandGame('chart-20', '137')
check('chart-20 rejects panna not in chart', c20x.rows[0]?.ok === false)
const c30 = expandGame('chart-30', '3')
check('chart-30 ank 3 → 3 rows', c30.rows.filter(r => r.ok).length === 3)
const c40 = expandGame('chart-40', '4')
check('chart-40 ank 4 → 4 rows', c40.rows.filter(r => r.ok).length === 4)

// combined Family chart resolves across all three sets
const famC8 = expandGame('family', '123')
check('family 123 → 8 rows (Set 8 member)', famC8.rows.filter(r => r.ok).length === 8, String(famC8.rows.filter(r => r.ok).length))
const famC6 = expandGame('family', '112')
check('family 112 → 6 rows (Set 6 member)', famC6.rows.filter(r => r.ok).length === 6)
const famC4 = expandGame('family', '111')
check('family 111 → 4 rows (Set 4 member)', famC4.rows.filter(r => r.ok).length === 4)
const comb = buildFamilyCombined('150')
check('buildFamilyCombined 150 → Set 6 family', comb.setType === 'Family Set 6' && comb.pannas.length === 6, comb.setType || 'none')
check('buildFamilyCombined 999 → Set 4 family (999 is a member)', buildFamilyCombined('999').setType === 'Family Set 4' && buildFamilyCombined('999').pannas.length === 4)
check('buildFamilyCombined empty → null', buildFamilyCombined('').setType === null)

// catalog grew: 28 games with the new codes present
check('catalog has 28 games', GAME_CATALOG.length === 28, String(GAME_CATALOG.length))
check('new game codes present', ['chart-20', 'chart-30', 'chart-40', 'family', 'hsb'].every(c => GAME_CATALOG.some(g => g.code === c)))
check('hs renamed Half Sangam A', GAME_CATALOG.find(g => g.code === 'hs')?.name === 'Half Sangam A')

// Half Sangam B pass-through expansion + settlement
const hsbExp = expandGame('hsb', '128-5')
check('hsb expansion passes through', hsbExp.rows[0]?.ok === true && hsbExp.rows[0]?.type === 'hsb')
const hsRes = { openPanna: '380', closePanna: '038', openDigit: '1', closeDigit: '1', jodi: '11' }
check('hsb wins on open panna + close digit (digit-set)', betWins({ type: 'hsb', slot: 'hs', num: '038-1' }, hsRes) === true)
check('hsb loses on wrong close digit', betWins({ type: 'hsb', slot: 'hs', num: '038-2' }, hsRes) === false)
check('hs A still wins (digit-set panna part)', betWins({ type: 'hs', slot: 'hs', num: '1-128' }, { openPanna: '812', closePanna: '821', openDigit: '1', closeDigit: '2', jodi: '12' }) === true)

// digit-set settlement: app grid bet vs operator chart result and vice versa
check('sp bet 038 wins vs result 380 (open)', betWins({ type: 'sp', slot: 'open', num: '038' }, { openPanna: '380', closePanna: null, openDigit: '1', closeDigit: null, jodi: null }) === true)
check('sp bet 380 wins vs result 038 (close)', betWins({ type: 'sp', slot: 'close', num: '380' }, { openPanna: null, closePanna: '038', openDigit: null, closeDigit: '1', jodi: null }) === true)
check('sp different panna loses', betWins({ type: 'sp', slot: 'open', num: '038' }, { openPanna: '137', closePanna: null, openDigit: '1', closeDigit: null, jodi: null }) === false)
check('dp bet 880 wins vs result 088', betWins({ type: 'dp', slot: 'open', num: '880' }, { openPanna: '088', closePanna: null, openDigit: '7', closeDigit: null, jodi: null }) === true)
check('fs digit-set both pannas', betWins({ type: 'fs', slot: 'fs', num: '038-128' }, { openPanna: '380', closePanna: '812', openDigit: '1', closeDigit: '2', jodi: '12' }) === true)
check('jodi still exact match', betWins({ type: 'jodi', slot: 'jodi', num: '12' }, { openPanna: '128', closePanna: '234', openDigit: '1', closeDigit: '4', jodi: '14' }) === false)
check('single exact digit', betWins({ type: 'single', slot: 'open', num: '1' }, { openPanna: '380', closePanna: null, openDigit: '1', closeDigit: null, jodi: null }) === true)

// ── tp/dp rows follow their session (regression: motor panna 400 fix) ──
// The slot-aware settlement rule is row-level (session follows the bet's
// slot) and stays in force for classic TP and for any legacy motor rows
// already placed under the old n³ expansion. Checks use hardcoded rows —
// the new admin-parity motor expansion emits SP rows only.
check('motor tp row 111 wins on OPEN panna (slot open)', betWins({ type: 'tp', slot: 'open', num: '111' }, { openPanna: '111', closePanna: null, openDigit: '3', closeDigit: null, jodi: null }) === true)
check('motor tp row 111 does NOT settle on close panna when played open', betWins({ type: 'tp', slot: 'open', num: '111' }, { openPanna: '222', closePanna: '111', openDigit: '6', closeDigit: '3', jodi: '63' }) === false)
check('classic tp (slot close) still settles on close panna', betWins({ type: 'tp', slot: 'close', num: '111' }, { openPanna: '222', closePanna: '111', openDigit: '6', closeDigit: '3', jodi: '63' }) === true)
check('motor dp row 112 wins on open (slot open, digit-set)', betWins({ type: 'dp', slot: 'open', num: '112' }, { openPanna: '121', closePanna: null, openDigit: '4', closeDigit: null, jodi: null }) === true)

// permutation-tolerant panna validation (operator chart spelling now valid)
check('isValidPanna 380 (operator order)', isValidPanna('380') === true)
check('isValidPanna 038 (app order)', isValidPanna('038') === true)
check('isValidPanna rejects non-3-digit', isValidPanna('38') === false)

// regression: existing charts untouched
const c50again = expandGame('chart-50', '1')
check('chart-50 ank 1 → 5 rows', c50again.rows.filter(r => r.ok).length === 5)
const c70 = expandGame('chart-70', '1')
check('chart-70 ank 1 → 7 rows', c70.rows.filter(r => r.ok).length === 7)
const oldFam = expandGame('family-6', '112')
check('family-6 still works alongside combined', oldFam.rows.filter(r => r.ok).length === 6)

// DP Motor — CHANGED 2026-09 per operator spec: no longer digit-seed
// permutations; it now expands the operator's DP Motor chart (ank → full DP
// family by smallest-non-zero-digit ownership). Motor Pana + SP Motor now
// use the admin-parity C(n,3) calculation (tests above). DP Motor itself is
// untouched by the 2026-09 parity fix.
const dpMotorAnk1 = expandGame('dp-motor', '1')
check('DP Motor ank 1 → 18 dp rows', dpMotorAnk1.rows.filter(r => r.ok).length === 18, String(dpMotorAnk1.rows.filter(r => r.ok).length))
check('DP Motor rows all dp type', dpMotorAnk1.rows.every(r => r.type === 'dp'))
check('DP Motor digit-seed no longer expands (13467 → 0 ok rows)', expandGame('dp-motor', '13467').rows.every(r => !r.ok))

// ──────────────────────────────────────────────────────────
// 2026-09 operator update — DP Motor verbatim chart + ank
// family games (SP/DP/TP/SPDP/SPTP/DPTP/SPDPTP)
// ──────────────────────────────────────────────────────────
import { DP_MOTOR_CHART } from '../src/lib/matka/chart-definitions'
import { ankFamilyRows } from '../src/lib/matka/games-engine'
import { EXPANDER_REGISTRY } from '../src/lib/matka/group-expanders'

// The operator's verbatim 90-number DP Motor chart, grouped per ank.
// Ank d owns every DP panna whose SMALLEST NON-ZERO digit is d —
// spelled non-zero digits ascending with zeros trailing (100, 110, 220, 990).
const DP_MOTOR_OPERATOR_CHART: Record<string, string[]> = {
  '1': ['100','110','112','113','114','115','116','117','118','119','122','133','144','155','166','177','188','199'],
  '2': ['200','220','223','224','225','226','227','228','229','233','244','255','266','277','288','299'],
  '3': ['300','330','334','335','336','337','338','339','344','355','366','377','388','399'],
  '4': ['400','440','445','446','447','448','449','455','466','477','488','499'],
  '5': ['500','550','556','557','558','559','566','577','588','599'],
  '6': ['600','660','667','668','669','677','688','699'],
  '7': ['700','770','778','779','788','799'],
  '8': ['800','880','889','899'],
  '9': ['900','990'],
}
let chartVerbatim = true
let chartTotal = 0
for (const [ank, expected] of Object.entries(DP_MOTOR_OPERATOR_CHART)) {
  chartTotal += expected.length
  const got = (DP_MOTOR_CHART.get(Number(ank)) || []).join(',')
  if (got !== expected.join(',')) {
    chartVerbatim = false
    console.log('   ank ' + ank + ' mismatch:\n   expected ' + expected.join(',') + '\n   got      ' + got)
  }
  const viaEngine = expandGame('dp-motor', ank).rows.filter(r => r.ok).map(r => r.num)
  if (viaEngine.join(',') !== expected.join(',')) {
    chartVerbatim = false
    console.log('   engine ank ' + ank + ' mismatch vs operator chart')
  }
}
check('DP Motor chart matches the operator chart VERBATIM (all 9 anks, order included)', chartVerbatim)
check('DP Motor chart totals 90 rows', chartTotal === 90, String(chartTotal))
check('DP Motor ank 0 has no rows (operator chart lists anks 1-9)', (DP_MOTOR_CHART.get(10) || []).length === 0 && expandGame('dp-motor', '0').rows.every(r => !r.ok))
// digit-set membership: app-grid spelling "001" resolves to chart "100"
const dpMotorPanna = expandGame('dp-motor', '001')
check('DP Motor panna seed 001 → chart spelling 100', dpMotorPanna.rows[0]?.ok === true && dpMotorPanna.rows[0]?.num === '100', dpMotorPanna.rows[0]?.num)
check('DP Motor rejects an SP panna (not in chart)', expandGame('dp-motor', '137').rows[0]?.ok === false)

// ── Ank family games: pick ONE ank → every panna of that ank ──
// Digit-sum grouping, identical to the master-admin SP/DP/TP charts
// (SP 12 per ank, DP 9, TP the one triple whose digit-sum ank matches).
const afSp = ankFamilyRows('sp', '1')
check('ank family SP 1 → 12 rows, all sp', afSp.length === 12 && afSp.every(r => r.type === 'sp'), String(afSp.length))
const afDp = ankFamilyRows('dp', '3')
check('ank family DP 3 → 9 rows, all dp', afDp.length === 9 && afDp.every(r => r.type === 'dp'), String(afDp.length))
check('ank family TP 1 → 777 (digit-sum ank)', ankFamilyRows('tp', '1').map(r => r.num).join(',') === '777')
check('ank family TP 0 → 000', ankFamilyRows('tp', '0').map(r => r.num).join(',') === '000')
check('ank family TP 9 → 333', ankFamilyRows('tp', '9').map(r => r.num).join(',') === '333')
const afSpdp = ankFamilyRows('spdp', '5')
check('ank family SPDP 5 → 21 rows (12 sp + 9 dp)', afSpdp.length === 21 && afSpdp.filter(r => r.type === 'sp').length === 12 && afSpdp.filter(r => r.type === 'dp').length === 9, String(afSpdp.length))
const afSptp = ankFamilyRows('sptp', '2')
check('ank family SPTP 2 → 13 rows (12 sp + tp 444)', afSptp.length === 13 && afSptp.some(r => r.type === 'tp' && r.num === '444'), String(afSptp.length))
const afDptp = ankFamilyRows('dptp', '4')
check('ank family DPTP 4 → 10 rows (9 dp + tp 888)', afDptp.length === 10 && afDptp.some(r => r.type === 'tp' && r.num === '888'), String(afDptp.length))
const afSpdptp = ankFamilyRows('spdptp', '9')
check('ank family SPDPTP 9 → 22 rows (12+9+1 tp 333)', afSpdptp.length === 22 && afSpdptp.some(r => r.type === 'tp' && r.num === '333'), String(afSpdptp.length))
// backward compatibility: a full 3-digit panna seed still bets that one panna
const singlePanna = expandGame('spdp', '118')
check('SPDP keeps 3-digit panna seed (single dp row)', singlePanna.rows.length === 1 && singlePanna.rows[0]?.type === 'dp' && singlePanna.rows[0]?.ok === true)
const spAnkViaEngine = expandGame('sp', '1')
check('expandGame SP single-digit → whole ank (12 rows)', spAnkViaEngine.rows.length === 12)

// ── ERP expander parity for DP Motor (same chart, one source of truth) ──
const erpDmAnk = EXPANDER_REGISTRY['DP Motor']('Ank1', { rate: 10 })
check('ERP DP Motor Ank1 → 18 entries', Array.isArray(erpDmAnk) && erpDmAnk.length === 18, String(Array.isArray(erpDmAnk) ? erpDmAnk.length : 'error'))
check('ERP DP Motor entries match the app engine order', Array.isArray(erpDmAnk) && erpDmAnk.map(e => e.panna).join(',') === DP_MOTOR_OPERATOR_CHART['1'].join(','))
const erpDmPanna = EXPANDER_REGISTRY['DP Motor']('001', { rate: 10 })
check('ERP DP Motor accepts digit-set member 001 (≡100)', Array.isArray(erpDmPanna) && erpDmPanna.length === 1)
const erpDmBad = EXPANDER_REGISTRY['DP Motor']('137', { rate: 10 })
check('ERP DP Motor rejects non-chart panna 137', !Array.isArray(erpDmBad) && typeof (erpDmBad as { error: string }).error === 'string')
const erpDmAnk0 = EXPANDER_REGISTRY['DP Motor']('0', { rate: 10 })
check('ERP DP Motor ank 0 → explicit error (no chart rows)', !Array.isArray(erpDmAnk0))
const erpSpM = EXPANDER_REGISTRY['SP Motor']('137', { rate: 10 })
check('ERP SP Motor UNCHANGED (single SP panna seed)', Array.isArray(erpSpM) && erpSpM.length === 1 && erpSpM[0].panna === '137')
const erpMotor = EXPANDER_REGISTRY['Motor Pana']('13467', { rate: 10 })
// 2026-09-30: the ERP batch expander is NOW admin-parity too — the operator's
// WhatsApp sample ("open motor / 23457890,100 / 12345678,100 / Total 11200")
// proves they calculate C(n,3) single-spelling on the Smart Entry path as
// well, so the 6-permutation inflation was removed (P1 motor parity).
check('ERP Motor Pana batch expander admin parity (C(5,3) = 10 SP rows)', Array.isArray(erpMotor) && erpMotor.length === 10, String(Array.isArray(erpMotor) ? erpMotor.length : 'error'))
check('ERP Motor Pana batch expander canonical spellings', Array.isArray(erpMotor) && erpMotor.every(e => canonicalPanna(e.panna) === e.panna))
check('ERP Motor Pana batch expander matches app engine', Array.isArray(erpMotor) && erpMotor.map(e => e.panna).join(',') === motor.rows.filter(r => r.ok).map(r => r.num).join(','))

process.exit(fails ? 1 : 0)
