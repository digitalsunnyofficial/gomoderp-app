/**
 * generate-project-doc.js — builds Matka-Card-ERP-Project-Documentation.docx
 */
const H = require("./doc-helpers");
const {
  P, EN, buildCoverR1, h1, h2, h3, body, r, bullet, caption,
  tableTitle, makeTable, image, pageFooter, pageHeader, pgSize, pgMargin,
  Document, Packer, Paragraph, TextRun, PageBreak, AlignmentType,
  TableOfContents, SectionType, NumberFormat, fs,
} = H;

const DL = "/home/z/my-project/download/";

// ═══════════════════════════ BODY CONTENT ══════════════════════════════════
const bodyChildren = [];

// ── 1. Executive Summary ────────────────────────────────────────────────────
bodyChildren.push(h1("1. Executive Summary"));
bodyChildren.push(body([
  r("Matka Card ERP is a web-based management platform for matka card and hisab (ledger) operators. The system digitises the daily paper workflow of the trade: entries arriving as WhatsApp messages or dictated speech are parsed, classified, calculated and stored against a market inventory, after which the platform generates the position charts, tracks customers and payments, and produces settlement (hisab) records. The product is delivered as a subscription service with a two-day free demo, three paid tiers, and a built-in payment tracking module, which makes it both an operational tool and a revenue-generating SaaS business."),
]));
bodyChildren.push(body([
  r("The platform is built on Next.js 16 with a Prisma-managed SQLite database and a shadcn/ui component layer. It is deployed as a standalone build on Hostinger, and a live development workspace is maintained in this sandbox. This document has been produced for a dual audience. For "),
  r("investors", { bold: true }),
  r(", Sections 2, 8 and 9 explain what the product does, how it earns money, and where it can grow. For the "),
  r("development team", { bold: true }),
  r(", Sections 3 through 7 document the architecture, every functional module, the parsing and calculation engine, the data model, and the API surface in enough detail to onboard a new engineer in a day."),
]));
bodyChildren.push(body([
  r("The most significant capability added in the current iteration (September 2026) is the "),
  r("Unified Smart Entry engine", { bold: true }),
  r(". One input box now accepts free-form, labelled text such as \u201CSP - 1,2,5,6,7 = 100 rs\u201D followed by \u201CMotor - 134678 = 200rs\u201D; the system recognises more than one hundred spelling variants of operator terminology, routes each number to its respective store (Single, Double, Triple Mix, Triple Common or Triple Group), expands motor and family seeds into full panna charts, and holds back anything it does not understand for one-click teaching. In the same iteration the top administrative role was renamed from Master Admin to Super Admin throughout the interface, the database and the API contract."),
]));

// ── 2. Product Overview & Business Value ───────────────────────────────────
bodyChildren.push(h1("2. Product Overview and Business Value"));
bodyChildren.push(h2("2.1 The Problem the Product Solves"));
bodyChildren.push(body("Matka operators traditionally run their business on paper and WhatsApp. Customers send bets as free-text messages in dialect, with inconsistent spellings and shorthand; the operator manually transcribes them into charts, sums the columns by hand, and reconciles payments at day's end. This workflow is slow, error-prone and impossible to audit. Matka Card ERP replaces that workflow with a single, phone-friendly web application that parses the same free-text messages automatically, so the operator's existing habits work unchanged — the software adapts to the operator rather than the other way around."));
bodyChildren.push(h2("2.2 Who Uses the System"));
bodyChildren.push(body("The product serves a hierarchy of four roles. A Super Admin owns the installation and has unrestricted access to every market and function. Admins (internally the manager role) manage their own teams of agents and customers within the markets they are assigned. Agents create entries and hisab records for their customers. Customers (vendors in the data model) are the end parties whose card business is tracked. Role-based access, market-level permissions and a complete audit trail are enforced server-side on every API call."));
bodyChildren.push(tableTitle("Table 1: Subscription plans (seeded values)"));
bodyChildren.push(makeTable(
  ["Plan", "Duration", "Price", "Positioning"],
  [
    ["Trial demo", "2 days", "Free", "Self-service onboarding; try all features"],
    ["Starter", "15 days", "₹15,000", "Single operator, low volume"],
    ["Growth", "30 days", "₹25,000", "Growing team with agents"],
    ["Business", "30 days", "₹35,000", "Full hierarchy, highest volume"],
  ],
  [20, 18, 18, 44]
));
bodyChildren.push(body("Revenue is generated through these subscriptions, tracked end-to-end in the platform: plan catalogue, per-user subscription assignment with expiry checks, a payment ledger, and a paywall that automatically gates non-paying users at login. The two-day free demo is a deliberate acquisition funnel — it converts the operator's habit of trying new tools into a low-friction entry point, and the subscription gate converts trial users at the moment they see their first auto-generated chart.", { after: 200 }));
bodyChildren.push(h2("2.3 Investor Highlights"));
bodyChildren.push(body("Three characteristics make the product defensible. First, the terminology dictionary: the parser recognises over one hundred operator spellings (SP, Single Panna, Ank Panna, Jodi, Joti, Motar, Cycle Patti and so on) and can be taught new ones in one click, which is a data network effect — the system gets better with every customer. Second, the calculation depth: motor seeds expand into combinatorial panna charts of 120+ positions, family sets and cut charts are operator-verified datasets, and all totals re-sum automatically across every entry type. Third, the audit infrastructure: every create, edit and delete is logged with user, market and metadata, which is a prerequisite for scaling beyond a trust-based customer base."));

// ── 3. System Architecture & Technology Stack ──────────────────────────────
bodyChildren.push(h1("2. System Architecture and Technology Stack").heading === undefined ? h1("3. System Architecture and Technology Stack") : h1("3. System Architecture and Technology Stack"));
bodyChildren.push(body("The application is a single Next.js 16 project using the App Router with TypeScript throughout. React 19 renders the interface, styled with Tailwind CSS 4 and the shadcn/ui component library; state is managed with Zustand (client) and TanStack Query is available for server state. The database is SQLite accessed exclusively through Prisma ORM, which keeps deployment self-contained — there is no external database server to operate. Voice input uses the Web Speech API through a Gboard-compatible dictation formatter, and chart export uses html2canvas with pagedjs support."));
bodyChildren.push(body("Requests flow through a combined middleware (src/proxy.ts) that validates the session cookie set at login, enforces single-device sessions, and injects identity headers consumed by every API route. Business logic lives in two places: route handlers under src/app/api for CRUD and access control, and pure libraries under src/lib/matka for parsing, chart mathematics and the terminology dictionary. The pure-library split matters — the entire parsing engine runs identically on the client (for live preview while typing) and on the server, with no React or database imports."));
bodyChildren.push(tableTitle("Table 2: Technology stack summary"));
bodyChildren.push(makeTable(
  ["Layer", "Technology", "Notes"],
  [
    ["Framework", "Next.js 16 (App Router, Turbopack)", "React 19, TypeScript 5"],
    ["UI", "Tailwind CSS 4 + shadcn/ui", "50+ pre-built components, Lucide icons"],
    ["State", "Zustand + TanStack Query", "Session store with localStorage persistence"],
    ["Database", "SQLite via Prisma 6", "Single file db/custom.db; 20+ models"],
    ["Auth", "Session cookie + single-device registry", "x-user-* headers verified against DB"],
    ["Parsing", "Pure TS libraries (src/lib/matka)", "Shared client/server, unit tested"],
    ["Deployment", "Standalone build on Hostinger", "bootstrap.js launcher + watchdog"],
  ],
  [18, 40, 42]
));

// ── 4. Module Reference ────────────────────────────────────────────────────
bodyChildren.push(h1("4. Module Reference"));
bodyChildren.push(body("This chapter documents each functional module, its purpose and its principal functions. Route paths refer to files under the project root src/ directory."));
bodyChildren.push(h2("4.1 Authentication, Roles and Hierarchy"));
bodyChildren.push(body("Login (src/app/api/auth) verifies the bcrypt password hash, issues a signed session cookie and registers the session in the UserSession table for single-device enforcement. Signup requests land in a pending-approval queue: agent signups are approved by an Admin or the Super Admin, while admin-role signups require Super Admin approval (src/app/api/users/[id]/approve). The role ladder is Super Admin (DB value super), Admin (manager) and Agent (user), all normalised through src/lib/hierarchy-auth.ts, which also maps the legacy master value for backward compatibility. As of the September 2026 iteration the top role is displayed everywhere as Super Admin; the database rows were migrated and the seed script updated, so all three tiers read and write the new value."));
bodyChildren.push(h2("4.2 Markets and Inventory Codes"));
bodyChildren.push(body("Every entry belongs to a market (kalyan, milan, main bazar and similar) through an InventoryCode record that names the market and the open/close session type. Inventories are created per code, date and time slot; posting a second batch to the same slot reuses the existing inventory via a 409-conflict response carrying the existing id. Market access is enforced by canAccessMarket helpers in src/lib/auth.ts and src/lib/audit.ts: Super Admins and Admins pass unconditionally, agents only for markets listed in their assignedMarkets CSV."));
bodyChildren.push(h2("4.3 Smart Entry — the Unified Input Engine"));
bodyChildren.push(body([
  r("Smart Entry (src/components/pages/UnifiedEntryPage.tsx) is the flagship module. It presents "),
  r("one", { italics: true }),
  r(" textarea in which the operator types, dictates or pastes an entire business message. The live parser (src/lib/matka/entry-parser.ts) reads the text line by line, detects optional section labels through the terminology dictionary (src/lib/matka/term-registry.ts), splits numbers from amounts, and routes every token as described below. A live preview shows five result panels — Single, Double, Triple Mix, Triple Common and one panel per recognised group — before anything is saved."),
]));
bodyChildren.push(image(DL + "doc-smart-entry.png", 1366, 900, 560));
bodyChildren.push(caption("Figure 1: Smart Entry parsing the operator's example — 5 singles, 5 doubles, 216 motor pannas, grand total ₹36,750"));
bodyChildren.push(tableTitle("Table 3: Routing rules of the unified parser"));
bodyChildren.push(makeTable(
  ["Input shape", "Routed to", "Stored as"],
  [
    ["1-digit number", "Single (Ank) store", "double-single-inventories, type=single"],
    ["2-digit number", "Double (Jodi) store", "double-single-inventories, type=double"],
    ["3-digit, no label or mix", "Triple Mix", "triple-inventories, type=mix"],
    ["3-digit, label Common", "Triple Common", "triple-inventories, type=common"],
    ["3-digit, group-type label", "Triple Group (validated panna)", "triple-inventories, type=group"],
    ["4-10 digits under group label", "Triple Group (seed expanded)", "triple-inventories, type=group"],
    ["Unknown label", "Held back + exception logged", "Parser Exceptions queue"],
  ],
  [34, 30, 36]
));
bodyChildren.push(body("Submission order is deliberate: the parent inventory is created (or reused), then triple entries post first, then singles, then doubles last, because the double-single API recomputes the inventory grand total as the sum of all triple and double-single rows. The result screen reports counts per store and offers a direct link to the Card View."));
bodyChildren.push(h2("4.4 The Terminology Dictionary and Its Evolution"));
bodyChildren.push(body([
  r("The dictionary is the heart of the update. Its built-in layer (BUILT_IN_TERMS in term-registry.ts) contains the sixteen group options plus Mix and Common, each with operator synonyms and common misspellings: "),
  r("SP", { bold: true }),
  r(" accepts \u201CSingle Panna\u201D, \u201CAnk Panna\u201D, \u201Csingle patti\u201D; "),
  r("DP", { bold: true }),
  r(" accepts \u201Cdouble panna\u201D, \u201Cjodi\u201D, \u201Cjoti\u201D, \u201Cdouble ank\u201D; "),
  r("Motor Pana", { bold: true }),
  r(" accepts \u201Cmotar\u201D, \u201Cmotor patti\u201D, \u201Ccycle panna\u201D, \u201Ccycle patti\u201D. Lookup is exact after normalisation (lowercase, punctuation collapsed), deliberately without fuzzy matching, so a numbers line such as \u201C50,60,70 = 100\u201D is never mistaken for the \u201C50 Chart\u201D label."),
]));
bodyChildren.push(body("The system evolves along two paths. Manual evolution: administrators click the Teach button next to any unknown term in Smart Entry, choose what it means, and the term is stored in the ParserTerm table (API: /api/parser-terms) where it wins over built-ins and applies instantly. Auto-evolution: every unknown label is also recorded as a Parser Exception with the original text, so the Parser Exceptions page surfaces recurring unknowns even if nobody taught them yet. Unknown-labelled content is always held back — never silently mis-filed — because money data deserves visible handling."));
bodyChildren.push(h2("4.5 Triple Inventories: Mix, Common and Group"));
bodyChildren.push(body("Triple entries (three-digit pannas) are stored in the TripleInventory table with a type discriminator matching the three tabs of the Card View. Mix mode parses pasted WhatsApp content directly into a 10-column ank grid, normalising digits. Common mode expands each seed into the ten pannas of its ank series. Group mode is the deepest: it carries the sixteen group options and an expansion registry (src/lib/matka/group-expanders.ts) that validates or generates pannas per option — SP requires three distinct digits from the verified SP universe, TP only the ten triple values, cut charts look the seed up in operator-verified chart maps (50/60/70/90 DP/90 ABR), family sets resolve through digit-sorted family keys with duplicate-seed protection, and Motor Pana generates every three-digit combination with distinct digits from the seed, six permutations each. Duplicate pannas across seeds merge by summing their rates, never overwriting."));
bodyChildren.push(h2("4.6 Double and Single Inventories"));
bodyChildren.push(body("Two-digit jodis and one-digit anks are stored in DoubleSingleInventory, again with a type discriminator. The module accepts the same broad format family as triples (comma, space, dot, dash and equals separators, with or without an rs/₹ suffix), renders its own grid and chart previews, and supports post-submission editing with an isUpdated audit flag. The double tab additionally renders a 10×10 Milan-style dot-format grid."));
bodyChildren.push(h2("4.7 Card View and Chart Generation"));
bodyChildren.push(body("The Card View (src/app/merp/page.tsx, roughly 6,600 lines) is the operational cockpit for one inventory. It renders the three triple modes side by side with their saved lists, draws the triple position grid (columns 1-10 by digit-sum ank), generates full and blank charts with customisable fonts and colours, applies per-column deductions or percentage adjustments, and exports via html2canvas. A Super-Admin-only \u201CDeduct from Column Total\u201D control adjusts displayed totals without touching the stored cell prices, and the last double/single edit re-sums the inventory automatically."));
bodyChildren.push(h2("4.8 Hisab and Settlements"));
bodyChildren.push(body("Settlements (src/app/api/settlements) record the day-end reconciliation between the operator and each customer. Access is restricted to Super Admin and Admin roles; the module computes per-customer balances from inventory totals, tracks payment status, and feeds the customer hisab views. Vendor settlement pages expose the same data per customer with export support."));
bodyChildren.push(h2("4.9 Customers, Hierarchy and Team Management"));
bodyChildren.push(body("Customers are managed as Vendor records with a unique code, business name and contact details. The hierarchy module (src/components/pages/HierarchyPages.tsx, APIs under /api/managers and /api/agents) lets a Super Admin create Admins, an Admin create Agents, and both manage customers, with data-isolation filters ensuring a manager sees only their own subtree. Market permissions (UserPermission rows) grant per-inventory-code view, edit and delete rights beyond market-level access."));
bodyChildren.push(h2("4.10 Parser Exceptions and Parser Configuration"));
bodyChildren.push(body("Two back-office modules keep the parser healthy. Parser Exceptions lists every skipped or dropped token and unknown label with its original text, market and uploader; items can be resolved, ignored or edited by hand. Parser Configuration manages the low-level pattern registry (src/lib/parser-patterns.ts): 20+ built-in regex patterns such as \u201C00,02,60,67,66.1500rs\u201D or \u201C07---2500\u201D, each with priority, example and applicability, plus admin-added patterns and separators stored in the database — the same self-evolution principle applied to line formats instead of terminology."));
bodyChildren.push(h2("4.11 Subscriptions, Payments and Paywall"));
bodyChildren.push(body("The subscription module manages the plan catalogue, per-user subscriptions with start and expiry dates, and the payment ledger with status transitions (pending, completed, refunded). A middleware-level gate checks the caller's subscription on each login for non-Super-Admin users and redirects lapsed accounts to a paywall page; the demo trial auto-applies on first login."));
bodyChildren.push(h2("4.12 Audit Trail and User Activity"));
bodyChildren.push(body("Every mutation writes a UserActivity row (action, entity, market, records affected, JSON metadata) through logActivity, which is deliberately non-fatal — audit failures never block business operations. The User Activity back-office page presents the trail with market and user filters, and a companion dashboard aggregates creation and edit counts."));
bodyChildren.push(h2("4.13 Marketing Landing Page and Onboarding"));
bodyChildren.push(body("The public landing page (src/app/page.tsx and /marketing) presents the product story — feature grid, how-it-works steps, pricing tiers and a WhatsApp contact float — with an editable configuration endpoint (/api/landing-config) so the operator can change hero text and highlights without a redeploy. Signup links feed directly into the approval queue described in 4.1."));

// ── 5. Worked Example ──────────────────────────────────────────────────────
bodyChildren.push(h1("5. Worked Example: One Message, Fully Calculated"));
bodyChildren.push(body("The following is the operator's reference example, reproduced exactly as the system receives it and as the September 2026 test run processed it."));
bodyChildren.push(tableTitle("Table 4: Reference input and system outcome"));
bodyChildren.push(makeTable(
  ["Input lines", "Interpretation", "Result"],
  [
    ["SP - 1,2,5,6,7 = 100 rs", "Label SP (Single Panna); five 1-digit anks at ₹100 each", "5 Single entries, ₹500"],
    ["DP - 12,23,47,35,18 = 50 rs", "Label DP (Jodi); five 2-digit numbers at ₹50 each", "5 Double entries, ₹250"],
    ["Motor - (blank line)", "Bare header; following lines belong to Motor Pana", "Section switch recorded"],
    ["134678 = 200rs", "Motor seed, six unique digits → C(6,3)=20 combinations × 6 permutations = 120 pannas at ₹200", "120 pannas, ₹24,000"],
    ["347890 = 100 rs", "Second motor seed → 120 pannas at ₹100", "120 pannas, ₹12,000"],
    ["(merged)", "Seeds share digits 3,4,7,8 → 24 pannas appear in both and merge to ₹300", "216 unique pannas, ₹36,000"],
  ],
  [28, 44, 28]
));
bodyChildren.push(body("The inventory grand total is therefore ₹36,750: ₹500 singles plus ₹250 doubles plus ₹36,000 of motor group pannas. A regression suite for this example and eleven other scenarios runs with bun scripts/test-entry-parser.ts and passes 51 of 51 checks, covering the synonym layers, section persistence, numeric-label ambiguity guards, family deduplication and the hold-back rule."));

// ── 6. Data Model ──────────────────────────────────────────────────────────
bodyChildren.push(h1("6. Data Model Summary"));
bodyChildren.push(body("The Prisma schema (prisma/schema.prisma) defines the tables below. The full schema includes indexes on foreign keys and status columns; soft-delete style locking (isLocked) applies to users rather than rows."));
bodyChildren.push(tableTitle("Table 5: Principal database models"));
bodyChildren.push(makeTable(
  ["Model", "Purpose", "Key fields"],
  [
    ["User", "All accounts across the three roles", "role (super/manager/user), status, assignedMarkets, managerId, isLocked"],
    ["UserSession", "Single-device session registry", "token (unique), deviceInfo, lastSeen"],
    ["Inventory", "Parent container per market/date/slot", "inventoryCodeId, date, time, totalAmount, totalTxn"],
    ["InventoryCode", "Market + session type catalogue", "code, name, market, type"],
    ["TripleInventory", "3-digit entries by mode", "type (mix/common/group), parsedData JSON, totalAmount"],
    ["DoubleSingleInventory", "1- and 2-digit entries", "type (single/double), parsedData JSON, totalAmount"],
    ["Vendor", "Customers", "code (unique), businessName, contact"],
    ["Settlement", "Day-end reconciliation", "inventoryCodeId, amounts, status"],
    ["UserPermission", "Per-code view/edit/delete grants", "userId + inventoryCode (unique pair)"],
    ["UserActivity", "Audit trail", "action, entity, market, metadata JSON"],
    ["ParserException", "Skipped/dropped tokens, unknown labels", "originalText, reason, kind, status"],
    ["ParserPattern", "Configurable line-format patterns", "regex, flags, priority, appliesTo"],
    ["ParserTerm", "Admin-taught terminology (new)", "term (unique), category, note, createdBy"],
    ["SubscriptionPlan / UserSubscription / Payment", "Billing", "price, duration, status, expiry"],
  ],
  [24, 34, 42]
));
bodyChildren.push(body("Parsed entries are persisted as JSON strings in parsedData (entries, grid, totals, seeds, group type), which keeps the relational model narrow while allowing each mode to store its natural shape; the Card View parses these JSON blobs at render time. SQLite was chosen deliberately: the whole deployment is one Node process plus one file, backups are a file copy, and the read-heavy workload never approaches SQLite's limits at current customer scale."));

// ── 7. API Surface ─────────────────────────────────────────────────────────
bodyChildren.push(h1("7. API Surface Summary"));
bodyChildren.push(body("All endpoints live under /api and are guarded by the proxy middleware (session cookie) and per-route role or market checks. The list below covers the principal routes a client integrator or test engineer needs."));
bodyChildren.push(tableTitle("Table 6: Principal API routes"));
bodyChildren.push(makeTable(
  ["Endpoint", "Methods", "Guard", "Purpose"],
  [
    ["/api/auth, /api/auth/signup", "POST", "public", "Login; signup request"],
    ["/api/inventories", "GET, POST", "session + market", "List/create parent inventories (409 reuse)"],
    ["/api/triple-inventories", "GET, POST", "session + market", "Mix, common and group triple entries"],
    ["/api/double-single-inventories", "GET, POST", "session + market", "Single and double entries; re-sums totals"],
    ["/api/inventory-codes", "GET, POST", "session", "Market catalogue"],
    ["/api/vendors", "GET, POST", "session", "Customer records"],
    ["/api/users (+ /approve, /lock)", "GET, POST, PATCH", "role-scoped", "Hierarchy and approvals"],
    ["/api/settlements", "GET, POST", "super/manager", "Hisab records"],
    ["/api/subscription-plans, /api/subscriptions, /api/payments", "GET, POST, PATCH", "role-scoped", "Billing"],
    ["/api/parser-terms", "GET, POST", "admin roles", "Teach dictionary terms (new)"],
    ["/api/parser-exceptions, /api/parser-config", "GET, POST", "session", "Parser back-office"],
    ["/api/health", "GET", "public", "Liveness with DB and role checks"],
  ],
  [34, 16, 18, 32]
));

// ── 8. Recent Updates ──────────────────────────────────────────────────────
bodyChildren.push(h1("8. September 2026 Update: What Changed"));
bodyChildren.push(body("Three changes shipped in this iteration, all verified end-to-end in the running application and captured in the regression suite. First, the top role was renamed from Master Admin to Super Admin: display strings across all thirty-one affected files, the seeded database rows (migrated via updateMany), the role-value comparisons in every API route, and the hierarchy normaliser, which now accepts both super and the legacy master value so that pre-update browser sessions continue to work until the next login."));
bodyChildren.push(body("Second, Smart Entry was extended from pure digit-length classification to label-aware routing. Triple entries now reach their respective places — Mix, Common and each of the sixteen Group options — based on the terminology that precedes them, exactly mirroring the three tabs operators already know from the Card View. Third, the terminology dictionary became a first-class, evolvable artefact: a pure-TypeScript registry with more than one hundred built-in terms, a ParserTerm database table with an admin API, a Teach-in-one-click control inside Smart Entry, and automatic recording of unknown labels as Parser Exceptions. together these convert operator vocabulary from a parsing liability into a growing asset."));
bodyChildren.push(body("Verification evidence: the operator's reference message parsed to 5 singles, 5 doubles and 216 motor pannas with a grand total of ₹36,750; the saved Card View rendered the motor chart with correct column totals; an unknown label (HF) was held back, taught as DP through the new UI, and re-parsed correctly within the same page visit; the 51-check parser regression suite passes; and ESLint reports no new errors against the pre-existing baseline."));

// ── 9. Deployment & Operations ─────────────────────────────────────────────
bodyChildren.push(h1("9. Deployment, Environments and Access"));
bodyChildren.push(body("Two environments are maintained. The Hostinger production deployment follows HOSTINGER_DEPLOY.md: the build produces a standalone Next.js server (bootstrap.js) with the SQLite database deliberately stored outside the versioned release tree (/home/<user>/erp-data/custom.db) so that data survives redeploys, and a watchdog script revives the process. The development sandbox runs the same codebase with next dev on port 3000; its database is db/custom.db seeded with the demo accounts listed below. The current sandbox preview is reachable at https://preview-da6d991d-e9ec-4acd-831e-876d3414d7ba.space-z.ai/."));
bodyChildren.push(tableTitle("Table 7: Seeded demo accounts (sandbox)"));
bodyChildren.push(makeTable(
  ["Role", "Username", "Password", "Scope"],
  [
    ["Super Admin", "admin1", "admin123", "Everything, all markets"],
    ["Admin (manager)", "admin2", "admin123", "Own subtree, seeded markets"],
    ["Agent", "agent1", "agent123", "Own entries, seeded markets"],
    ["Agent (user)", "user1", "user123", "Own entries, seeded markets"],
  ],
  [24, 20, 20, 36]
));
bodyChildren.push(body("Operational commands: bun run dev starts the sandbox, bun run db:push applies schema changes, bun run db:seed loads demo data, bun run db:seed is idempotent (upsert by username), and bun scripts/test-entry-parser.ts runs the parser regression suite. The seed also provisions the plan catalogue and the kalyan, milan, main bazar and related inventory codes."));

// ── 10. Limitations & Roadmap ──────────────────────────────────────────────
bodyChildren.push(h1("10. Known Limitations and Recommended Roadmap"));
bodyChildren.push(body("The platform is production-tested for its core loop but several areas merit investment. SQLite is adequate today, but a managed Postgres migration path should be designed before customer count grows into concurrent-write contention; Prisma abstracts most of the change. The parser currently works line-by-line with a curated dictionary; importing the operator's historical WhatsApp archives through the Parser Exceptions workflow would bootstrap each new deployment's dictionary automatically. Mobile performance for very large charts (500+ entries) is mitigated with deferred rendering but would benefit from virtualised lists."));
bodyChildren.push(body("Recommended next steps, in priority order: (1) harden the payments module with reconciliation against an actual payment gateway or UPI notification feed; (2) add per-market rate configuration so default rates live with the market rather than the entry form; (3) expose the terminology dictionary to a dedicated back-office page with import/export so head-office can standardise vocabularies across operators; (4) introduce automated end-to-end browser tests for the Smart Entry submission flow to complement the unit-level parser suite; and (5) produce a customer-facing changelog so subscribers see the pace of improvement. Each item is scoped small and builds on the module boundaries documented in Chapter 4."));

// ═══════════════════════════ DOCUMENT ══════════════════════════════════════
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: EN, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 32, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 28, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 260, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 24, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 220, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    // ── Section 1: Cover (no page number, no footer) ──
    {
      properties: {
        page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1({
        title: "Matka Card ERP",
        subtitle: "Card & Hisab Management System — Complete Project Documentation",
        englishLabel: "PROJECT DOCUMENTATION",
        metaLines: [
          "Prepared for: Investors and Development Team",
          "Product: Matka Card ERP (Hisab System) by Class Infotech",
          "Release: Version 2.1 — September 2026",
          "Classification: Internal and Investor Use",
        ],
        footerLeft: "Matka Card ERP",
        footerRight: "September 2026",
        palette: { bg: P.bg, titleColor: P.cover.titleColor, subtitleColor: P.cover.subtitleColor, metaColor: P.cover.metaColor, footerColor: P.cover.footerColor, accent: P.accent },
      }),
    },
    // ── Section 2: Front matter — TOC (Roman numerals) ──
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: pgSize, margin: pgMargin,
          pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN },
        },
      },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 480, after: 360 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, color: P.headingColor, font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }),
        new Paragraph({
          spacing: { before: 200 },
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: EN,
          })],
        }),
      ],
    },
    // ── Section 3: Body — Arabic numerals from 1 ──
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: pgSize, margin: pgMargin,
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: { default: pageHeader() },
      footers: { default: pageFooter() },
      children: bodyChildren,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(DL + "Matka-Card-ERP-Project-Documentation.docx", buf);
  console.log("Written:", DL + "Matka-Card-ERP-Project-Documentation.docx", buf.length, "bytes");
});
