#!/bin/bash
# Task 41: build r3 Hostinger zip from r2 — one-file landing-page APK-link fix.
set -e
cd /home/z/my-project
R2=download/Satta_Matka_God_Hostinger_Ready_2026-10-09-r2.zip
R3=download/Satta_Matka_God_Hostinger_Ready_2026-10-09-r3.zip
STAGE=/home/z/my-project/zipstage-hostinger-r3

rm -rf "$STAGE" && mkdir -p "$STAGE"
unzip -qq "$R2" -d "$STAGE"

# 1. Replace the one fixed file (workspace = single source of truth)
cp src/components/public/DownloadCta.tsx "$STAGE/src/components/public/DownloadCta.tsx"

# 2. Tiny operator note at zip root
cat > "$STAGE/R3-NOTES.txt" <<'EOF'
R3 (2026-10-09) — Landing page APK link fix
===========================================
One file changed vs r2:  src/components/public/DownloadCta.tsx

The gold Download button on the landing page (/) and on /customerapp
now points at your real hosted APK:
    https://godmoderp.online/apk/sm-gomod.apk
and the "App package not published yet" state is gone — the button is
always visible (fail-open design).

TO UPDATE A LIVE HOSTINGER DEPLOYMENT
-------------------------------------
Option A (fastest, no rebuild): the change is in compiled client JS, so a
source file drop-in is NOT enough on a built deployment — re-run your
normal r2 pipeline with this zip (same steps as before, db untouched).

Option B (recommended for future APK swaps): you do NOT need to touch this
project to ship a new app build — just replace the file on your server at
    public_html/apk/sm-gomod.apk
with the new APK (keep the same filename). The landing page link never
changes.
EOF

# 3. Zip r3
rm -f "$R3"
(cd "$STAGE" && zip -qq -r "/home/z/my-project/$R3" .)

# 4. Verify
echo "--- integrity ---"
unzip -tqq "$R3" && echo "integrity OK"
echo "--- counts ---"
echo "r2: $(unzip -l "$R2" | rg -c '  ' ) lines; r3 files: $(unzip -l "$R3" | tail -1 | rg -o '[0-9]+ files')"
echo "--- spot-check: patched file inside zip ---"
unzip -p "$R3" src/components/public/DownloadCta.tsx | rg -n 'godmoderp.online/apk|APK_URL|FAIL-OPEN|Verified live' | head -6
echo "--- old path must be absent ---"
unzip -p "$R3" src/components/public/DownloadCta.tsx | rg -c 'satta-matka-god\.apk' || echo "old path gone"
echo "--- db md5 unchanged vs r2 ---"
MD5_R2=$(unzip -p "$R2" db/custom.db 2>/dev/null | md5sum | cut -d' ' -f1)
MD5_R3=$(unzip -p "$R3" db/custom.db 2>/dev/null | md5sum | cut -d' ' -f1)
echo "r2 db: $MD5_R2"; echo "r3 db: $MD5_R3"
[ "$MD5_R2" = "$MD5_R3" ] && echo "DB IDENTICAL" || echo "DB DIFF — ABORT"
ls -la "$R3"
