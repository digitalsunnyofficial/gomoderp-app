// Task 42: run the EXACT queries used by /api/app-admin/customers + customer signup/login
// against the GOLD db (the one shipped inside the r3 zip = what's live), no schema catch-up.
import { PrismaClient } from '@prisma/client'

const url = process.argv[2] || 'file:/home/z/my-project/zipstage-hostinger-r3/db/custom.db'
console.log('db:', url)
const db = new PrismaClient({ datasources: { db: { url } } })

async function main() {
  // ── issue 1: customers list queries ──
  const customers = await db.appCustomer.findMany({ orderBy: { createdAt: 'desc' }, take: 300 })
  console.log('appCustomer.findMany OK —', customers.length, 'rows')
  const ids = customers.map(c => c.id)
  const betGroups = await db.appBet.groupBy({ by: ['customerId'], where: { customerId: { in: ids } }, _count: { _all: true }, _sum: { points: true, win: true } })
  console.log('appBet.groupBy OK —', betGroups.length)
  const pendingFunds = await db.appFundRequest.groupBy({ by: ['customerId'], where: { customerId: { in: ids }, status: 'pending' }, _count: { _all: true } })
  console.log('appFundRequest.groupBy OK —', pendingFunds.length)
  const pendingWd = await db.appWithdrawRequest.groupBy({ by: ['customerId'], where: { customerId: { in: ids }, status: 'pending' }, _count: { _all: true } })
  console.log('appWithdrawRequest.groupBy OK —', pendingWd.length)

  // ── issue 2: signup + login db layer ──
  const c = await db.appCustomer.findUnique({ where: { mobile: '9876500001' } })
  console.log('login findUnique OK —', c?.name)
  // dry-run the update the login route does (on a scratch copy value = same value)
  await db.appCustomer.update({ where: { mobile: '9876500001' }, data: { lastLoginAt: c?.lastLoginAt || new Date() } })
  console.log('login lastLoginAt update OK')
  // signup: what does the route check? agent lookup + create — test agent table + a throwaway create/rollback
  const agents = await db.user.findMany({ where: { role: 'agent' }, take: 1 })
  console.log('agent lookup OK —', agents.length)
  const t = await db.appCustomer.create({ data: { name: 'SCHEMA-PROBE', mobile: '0000000000', password: 'x', wallet: 0 } })
  await db.appCustomer.delete({ where: { id: t.id } })
  console.log('signup create/delete probe OK')

  // ── schema diff check: do the "new" objects exist in this db? ──
  try { await db.agentCommissionWithdrawal.findMany({ take: 1 }); console.log('AgentCommissionWithdrawal: PRESENT') }
  catch (e: any) { console.log('AgentCommissionWithdrawal: MISSING →', String(e.message).slice(0, 120)) }
  try { await db.appPaymentSetting.findFirst({ where: { autoCredit: true } }); console.log('AppPaymentSetting.autoCredit: PRESENT') }
  catch (e: any) { console.log('AppPaymentSetting.autoCredit: MISSING →', String(e.message).slice(0, 120)) }
}
main().catch(e => { console.error('REPRODUCED FAILURE:', String(e.message).slice(0, 300)); process.exit(1) }).finally(() => db.$disconnect())
