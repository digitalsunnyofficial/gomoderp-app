// End-to-end motor panna bet test — replicates exactly what the Customer App
// sends when a user plays Motor Pana / SP Motor / DP Motor (seed expansion in
// the browser via expandGame, then POST /api/customer-app/bets).
import { expandGame } from '../src/lib/matka/games-engine.ts'

const BASE = 'http://127.0.0.1:3000'

async function j(method: string, path: string, body?: unknown, token?: string) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  return { status: res.status, data }
}

async function main() {
  // 0) What the app would expand for a typical motor seed
  for (const [game, seed] of [['motor', '123'], ['sp-motor', '123'], ['dp-motor', '123'], ['motor', '55'], ['sp-motor', '456'], ['dp-motor', '22']] as const) {
    const ex = expandGame(game, seed)
    const ok = ex.rows.filter(r => r.ok)
    console.log(`expand ${game}(${seed}): err=${ex.error || '-'} rows=${ex.rows.length} ok=${ok.length} sample=${ok.slice(0, 3).map(r => r.num + '/' + r.type).join(', ') || '-'}`)
  }

  // 1) app login
  const login = await j('POST', '/api/customer-app/auth/login', { mobile: '9812345601', password: 'Rahul@123' })
  const token = login.data.token as string
  console.log('\napp login:', login.status)
  if (!token) { console.log(login.data); return }

  // 2) check the allocation view the home API serves for motor games
  const home = await j('GET', '/api/customer-app/home', undefined, token)
  const mk = (home.data.markets || []).find((m: { code: string }) => m.code === 'milan_night_open')
  const motorGames = (mk?.games || []).filter((g: { code: string }) => g.code.includes('motor'))
  console.log('home milan_night_open games:', (mk?.games || []).length, '| motor views:', JSON.stringify(motorGames))

  // 3) place a REAL motor bet exactly like SeedGamePanel.addAll does
  const ex = expandGame('motor', '123')
  const okRows = ex.rows.filter(r => r.ok)
  const items = okRows.map(r => ({
    marketCode: 'milan_night_open', slot: 'open', type: r.type, num: r.num,
    points: 10, rate: motorGames[0]?.rate || 140, marketName: mk?.displayName || 'Milan Night Open', gameCode: 'motor',
  }))
  console.log(`\nplacing motor bet: ${items.length} rows x 10 pts (total ${items.length * 10}) ...`)
  const bet = await j('POST', '/api/customer-app/bets', { items }, token)
  console.log('bet POST:', bet.status, JSON.stringify(bet.data).slice(0, 500))

  // 4) also sp-motor (6 sp rows from seed 123)
  const ex2 = expandGame('sp-motor', '123')
  const ok2 = ex2.rows.filter(r => r.ok)
  const items2 = ok2.map(r => ({
    marketCode: 'milan_night_open', slot: 'open', type: r.type, num: r.num,
    points: 10, rate: motorGames.find((g: { code: string }) => g.code === 'sp-motor')?.rate || 140,
    marketName: mk?.displayName || 'Milan Night Open', gameCode: 'sp-motor',
  }))
  console.log(`\nplacing sp-motor bet: ${items2.length} rows ...`)
  const bet2 = await j('POST', '/api/customer-app/bets', { items: items2 }, token)
  console.log('sp-motor POST:', bet2.status, JSON.stringify(bet2.data).slice(0, 500))
}

main().catch(e => { console.error('FATAL', e); process.exit(1) })
