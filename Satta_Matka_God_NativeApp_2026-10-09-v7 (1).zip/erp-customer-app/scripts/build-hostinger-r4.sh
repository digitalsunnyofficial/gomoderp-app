#!/bin/bash
# Task 42: build r4 Hostinger zip from r3 stage
#  - schema catch-up self-heal (prestart + postinstall db push)  → fixes live "Request failed" / sign-in failures
#  - APK upload feature (schema + API + serve route + ERP UI + landing CTA)
set -e
cd /home/z/my-project
R3_STAGE=zipstage-hostinger-r3
R4=download/Satta_Matka_God_Hostinger_Ready_2026-10-09-r4.zip

# fresh stage from r3 (keeps everything that already passed the pipeline)
rm -rf zipstage-hostinger-r4 && cp -r "$R3_STAGE" zipstage-hostinger-r4
S=zipstage-hostinger-r4

# 1. changed/new source files (workspace = single source of truth)
cp prisma/schema.prisma                            "$S/prisma/schema.prisma"
mkdir -p "$S/src/app/api/app-admin/apk" "$S/src/app/apk/[file]"
cp src/app/api/app-admin/apk/route.ts              "$S/src/app/api/app-admin/apk/route.ts"
cp "src/app/apk/[file]/route.ts"                   "$S/src/app/apk/[file]/route.ts"
cp src/components/pages/AppAdminPages3.tsx         "$S/src/components/pages/AppAdminPages3.tsx"
cp src/lib/store.ts                                "$S/src/lib/store.ts"
cp src/lib/navigation.ts                           "$S/src/lib/navigation.ts"
cp src/lib/access-control.ts                       "$S/src/lib/access-control.ts"
cp src/app/merp/page.tsx                           "$S/src/app/merp/page.tsx"
cp src/components/public/DownloadCta.tsx           "$S/src/components/public/DownloadCta.tsx"
cp scripts/sync-schema.js                          "$S/scripts/sync-schema.js"

# 2. package.json — SELF-HEALING SCHEMA SYNC on every install and boot
python3 - <<'PYEOF'
import json
p = 'zipstage-hostinger-r4/package.json'
pkg = json.load(open(p))
pkg['scripts']['postinstall'] = 'prisma generate && node scripts/sync-schema.js'
pkg['scripts']['prestart'] = 'node scripts/sync-schema.js'
json.dump(pkg, open(p, 'w'), indent=2)
print('package.json scripts:', json.dumps(pkg['scripts'], indent=1))
PYEOF

# 3. DEPLOY guide §12 — APK upload + self-healing schema
cat >> "$S/DEPLOY_HOSTINGER.md" <<'DOCEOF'

## 12. App Build (APK) — upload releases from the ERP (r4+)

No more file-manager trips to the server:

1. ERP → **App Build (APK)** (Super Admin) → choose the `.apk` → *Upload — go live now*.
2. The landing page (`/`) and `/customerapp` serve it instantly at the canonical URL
   `https://<domain>/apk/sm-gomod.apk` — the link never changes, so QR codes and
   links already shared with customers keep working forever.
3. The APK is stored **inside the SQLite database** (table `ApkArtifact`), so it
   survives every redeploy — when you back up `db/custom.db` (§10), the APK rides along.
4. Optional "Remove" reverts to no-upload state (the download then 404s until the
   next upload).

## 13. Self-healing schema sync (r4+) — why boot now runs `prisma db push`

`package.json` gained:

- `"postinstall": "prisma generate && prisma db push --skip-generate"`
- `"prestart": "prisma db push --skip-generate"`

Every deploy/boot therefore applies any pending schema changes **additively**
(tables/columns are added, data is never touched). This fixes the r3 incident where
the live server ran a database missing newer columns (`AppCustomer.pushToken` et al)
— which made the ERP App-Customers page show *Request failed* and customer
signup/login fail server-side. `db push` without `--accept-data-loss` refuses
destructive changes, so it can never drop data; if it ever fails, the deploy fails
loudly instead of silently mis-serving.
DOCEOF

# 4. operator notes
cat > "$S/R4-NOTES.txt" <<'EOF'
R4 (2026-10-09) — live incident fixes + APK upload feature
==========================================================

FIXES for the two issues reported on the live server (godmoderp.online)

1) ERP ▸ Customer List ▸ App Customers → "Request failed"
   ROOT CAUSE: the deployed database was missing newer schema columns
   (first failure: `AppCustomer.pushToken does not exist`) because the
   platform pipeline never ran a schema catch-up. EVERY query touching
   app customers failed → the page showed "Request failed".
   FIX: package.json now runs `prisma db push --skip-generate` at
   postinstall AND prestart — every deploy/boot self-heals the schema
   additively. Verified: gold db + push = ZERO data loss (11 customers /
   10 markets / 182 bets / 193 txns all intact), all flows pass.

2) Android app → sign up / sign in failed
   TWO stacked causes:
   a) SERVER-SIDE: same missing schema (signup + login write/scan the
      app-customer table). Fixed by the same self-heal above.
   b) THE APK ITSELF: app.json shipped `extra.apiBase = http://10.0.2.2:3000`
      — the ANDROID EMULATOR address. On a real phone every request dies
      before reaching your server. The native app now ships
      `apiBase = https://godmoderp.online` (see the v7 native zip /
      UPDATE_FROM_V7.md). Rebuild the APK and upload it via ERP ▸ App Build.

NEW FEATURE — App Build (APK)
   ERP ▸ App Build (APK) (Super Admin): upload the release APK, optional
   version label, live progress bar, copyable customer link. Stored in the
   database (survives redeploys), served at /apk/sm-gomod.apk, landing page
   picks it up INSTANTLY. No more editing files on the server.

FILES CHANGED vs r3
   prisma/schema.prisma                      (+ApkArtifact model)
   src/app/api/app-admin/apk/route.ts        (new — metadata/upload/delete)
   src/app/apk/[file]/route.ts               (new — public serving)
   src/components/pages/AppAdminPages3.tsx   (+AppBuildPage)
   src/lib/store.ts, navigation.ts, access-control.ts, src/app/merp/page.tsx
                                             (+app-build wiring)
   src/components/public/DownloadCta.tsx     (canonical relative link)
   package.json                              (postinstall/prestart self-heal)
   DEPLOY_HOSTINGER.md                       (§12 APK upload, §13 self-heal)

DEPLOY: upload this zip the same way as r2/r3. First boot prints the
schema catch-up in the deploy log, then everything works.
EOF

# 5. zip + verify
rm -f "$R4"
(cd "$S" && zip -qq -r "/home/z/my-project/$R4" .)
echo "--- integrity ---"; unzip -tqq "$R4" && echo "integrity OK"
echo "files: $(unzip -l "$R4" | tail -1 | rg -o '[0-9]+ files')"
echo "--- spot checks ---"
unzip -p "$R4" package.json | python3 -c "import json,sys; s=json.load(sys.stdin)['scripts']; print('postinstall:', s['postinstall']); print('prestart:', s['prestart'])"
unzip -p "$R4" prisma/schema.prisma | rg -c "model ApkArtifact"
unzip -p "$R4" "src/app/apk/[file]/route.ts" | rg -n "CANONICAL_NAME" | head -1
unzip -p "$R4" src/components/public/DownloadCta.tsx | rg -n "const APK_URL"
echo "--- db md5 (must stay gold) ---"
unzip -p "$R4" db/custom.db | md5sum
ls -la "$R4"
