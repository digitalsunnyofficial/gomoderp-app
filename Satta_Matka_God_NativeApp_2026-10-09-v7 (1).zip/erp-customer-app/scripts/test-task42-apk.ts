// Task 42: APK upload feature + landing CTA + serve route — full API battery
const BASE = 'http://127.0.0.1:3000'
let suCookie = ''
let results: Array<{ n: string; ok: boolean; info?: string }> = []

function check(n: string, ok: boolean, info?: string) {
  results.push({ n, ok, info })
  console.log(`${ok ? 'PASS' : 'FAIL'} — ${n}${info ? ' :: ' + info : ''}`)
}

async function call(method: string, path: string, body?: any, cookie?: string, extraHeaders?: Record<string, string>) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}), ...(extraHeaders || {}) },
    body: body ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined,
  })
  const text = await res.text()
  let json: any = null
  try { json = JSON.parse(text) } catch {}
  return { status: res.status, json, text, headers: res.headers }
}

// a minimal valid "APK": real ZIP magic PK\x03\x04 + EOCD
function fakeApk(seed: string): Buffer {
  const payload = Buffer.from(`apk-payload-${seed}-${'x'.repeat(2048)}`)
  const head = Buffer.from([0x50, 0x4b, 0x03, 0x04])
  const eocd = Buffer.from([0x50, 0x4b, 0x05, 0x06, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
  return Buffer.concat([head, payload, eocd])
}

async function main() {
  // login super
  const adm = await call('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  suCookie = (adm.headers.get('set-cookie') || '').split(';')[0]
  check('super login', adm.status === 200)

  // clean slate
  await call('DELETE', '/api/app-admin/apk', undefined, suCookie)

  // ── auth guards ──
  const unauth = await call('GET', '/api/app-admin/apk')
  check('apk metadata unauthenticated → 401', unauth.status === 401, String(unauth.status))
  const upUnauth = await call('POST', '/api/app-admin/apk', 'x', undefined, { 'Content-Type': 'multipart/form-data; boundary=zz' })
  check('apk upload unauthenticated → 401', upUnauth.status === 401, String(upUnauth.status))

  // agent session → proxy passes but role check 403 (dedicated throwaway agent, db-created)
  const AGENT_U = 'zz-apk-agent'
  const { PrismaClient } = await import('@prisma/client')
  const pdb = new PrismaClient()
  const bcrypt = (await import('bcryptjs')).default
  await pdb.user.upsert({
    where: { username: AGENT_U },
    update: { password: await bcrypt.hash('ApkAgent@42', 10), role: 'agent', status: 'active' },
    create: { username: AGENT_U, password: await bcrypt.hash('ApkAgent@42', 10), role: 'agent', name: 'APK RBAC Agent', status: 'active' },
  })
  await pdb.$disconnect()
  const ag = await call('POST', '/api/auth', { username: AGENT_U, password: 'ApkAgent@42' })
  const agCookie = (ag.headers.get('set-cookie') || '').split(';')[0]
  if (ag.status === 200) {
    const agGet = await call('GET', '/api/app-admin/apk', undefined, agCookie)
    check('apk metadata agent → 403', agGet.status === 403, String(agGet.status))
    const agPost = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: agCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([fakeApk('ag')], { type: 'application/vnd.android.package-archive' }), 'ag.apk'); return fd })() })
    check('apk upload agent → 403', agPost.status === 403, String(agPost.status))
  } else {
    check('agent login available', false, 'agent login failed — agent 403 tests skipped')
  }

  // ── metadata: empty state ──
  const empty = await call('GET', '/api/app-admin/apk', undefined, suCookie)
  check('metadata empty → hasApk false', empty.status === 200 && empty.json?.hasApk === false, JSON.stringify(empty.json))

  // ── serve route: 404 before upload ──
  const nf = await call('GET', '/apk/sm-gomod.apk')
  check('serve 404 before upload', nf.status === 404, String(nf.status))
  const hnf = await call('HEAD', '/apk/sm-gomod.apk')
  check('HEAD 404 before upload', hnf.status === 404, String(hnf.status))

  // ── validation ──
  const badType = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: suCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([Buffer.from('not a zip at all — plain text')]), 'evil.apk'); return fd })() })
  check('non-zip payload rejected 400', badType.status === 400, String(badType.status))
  const badName = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: suCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([fakeApk('n')]), 'app.zip'); return fd })() })
  check('non-.apk name rejected 400', badName.status === 400, String(badName.status))

  // ── upload v1 ──
  const up1 = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: suCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([fakeApk('v1')], { type: 'application/vnd.android.package-archive' }), 'SM-God-v1.1.0.apk'); fd.append('versionLabel', 'v1.1.0 — first ERP upload'); return fd })() })
  const up1j = await up1.json().catch(() => ({}))
  check('upload v1 ok', up1.status === 200 && up1j?.ok === true, JSON.stringify(up1j))

  // metadata reflects it
  const md1 = await call('GET', '/api/app-admin/apk', undefined, suCookie)
  check('metadata shows v1', md1.json?.hasApk === true && md1.json?.apk?.fileName === 'SM-God-v1.1.0.apk' && md1.json?.apk?.size > 2048, JSON.stringify(md1.json?.apk))

  // serve route serves EXACT bytes + headers
  const s1 = await fetch(BASE + '/apk/sm-gomod.apk')
  const buf1 = Buffer.from(await s1.arrayBuffer())
  const want1 = fakeApk('v1')
  check('serve 200 + bytes identical', s1.status === 200 && buf1.equals(want1), `${s1.status} ${buf1.length}B vs ${want1.length}B`)
  check('serve content-type', s1.headers.get('content-type') === 'application/vnd.android.package-archive', String(s1.headers.get('content-type')))
  check('serve disposition sm-gomod.apk', (s1.headers.get('content-disposition') || '').includes('sm-gomod.apk'), String(s1.headers.get('content-disposition')))
  check('serve no-store', (s1.headers.get('cache-control') || '').includes('no-store'), String(s1.headers.get('cache-control')))
  // alias: ANY .apk path serves the same build
  const s2 = await fetch(BASE + '/apk/whatever-old-link.apk')
  check('alias path serves same build', s2.status === 200 && Buffer.from(await s2.arrayBuffer()).equals(want1), String(s2.status))

  // HEAD probe
  const h1 = await fetch(BASE + '/apk/sm-gomod.apk', { method: 'HEAD' })
  check('HEAD 200 + length', h1.status === 200 && h1.headers.get('content-length') === String(want1.length), `${h1.status} len=${h1.headers.get('content-length')}`)

  // ── replace (single-row semantics) ──
  const up2 = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: suCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([fakeApk('v2-larger-payload-' + 'y'.repeat(4096))], { type: 'application/vnd.android.package-archive' }), 'SM-God-v1.2.0.apk'); return fd })() })
  check('upload v2 replace ok', up2.status === 200)
  const s3 = await fetch(BASE + '/apk/sm-gomod.apk')
  const buf3 = Buffer.from(await s3.arrayBuffer())
  check('serve now returns v2 bytes', buf3.equals(fakeApk('v2-larger-payload-' + 'y'.repeat(4096))), `${buf3.length}B`)
  const md2 = await call('GET', '/api/app-admin/apk', undefined, suCookie)
  check('metadata single row v2', md2.json?.apk?.fileName === 'SM-God-v1.2.0.apk', JSON.stringify(md2.json?.apk))

  // ── landing page + customerapp point at the canonical relative path ──
  const landing = await (await fetch(BASE + '/')).text()
  const cap = await (await fetch(BASE + '/customerapp')).text()
  check('landing CTA uses /apk/sm-gomod.apk', landing.includes('/apk/sm-gomod.apk'))
  check('customerapp CTA uses /apk/sm-gomod.apk', cap.includes('/apk/sm-gomod.apk'))
  check('landing has no old absolute hardcode', !landing.includes('https://godmoderp.online/apk'))

  // ── delete ──
  const del = await call('DELETE', '/api/app-admin/apk', undefined, suCookie)
  check('delete ok', del.status === 200 && del.json?.ok === true, JSON.stringify(del.json))
  const nf2 = await call('GET', '/apk/sm-gomod.apk')
  check('serve 404 after delete', nf2.status === 404, String(nf2.status))

  // restore v1 state for the live server (leave something sane uploaded)
  const up3 = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: suCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([fakeApk('v1')], { type: 'application/vnd.android.package-archive' }), 'sm-gomod.apk'); fd.append('versionLabel', 'v1.1.0'); return fd })() })
  check('restore uploaded state', up3.status === 200)

  const fails = results.filter(r => !r.ok)
  console.log(`\n══ ${results.length - fails.length}/${results.length} checks passed ══`)
  if (fails.length) process.exit(1)
}
main().catch(e => { console.error('FATAL', e); process.exit(1) })
