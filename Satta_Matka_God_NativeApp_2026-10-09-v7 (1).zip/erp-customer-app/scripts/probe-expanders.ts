import { EXPANDER_REGISTRY } from '../src/lib/matka/group-expanders'
const cfg = { rate: 10 }
const charts = ['20 Chart', '30 Chart', '40 Chart', '50 Chart', '60 Chart', '70 Chart', '90 DP Chart', '90 ABR Chart']
for (const opt of charts) {
  const exp = EXPANDER_REGISTRY[opt as keyof typeof EXPANDER_REGISTRY]
  const counts: string[] = []
  let total = 0
  for (let ank = 0; ank <= 9; ank++) {
    const res = exp(String(ank), cfg)
    const n = Array.isArray(res) ? res.length : -1
    counts.push(ank + ':' + (n < 0 ? 'ERR' : n))
    if (n > 0) total += n
  }
  console.log(opt.padEnd(13), counts.join(' '), '| total', total)
}
// motor + sp motor + dp motor sanity via registry
const m = EXPANDER_REGISTRY['Motor Pana']('13467', cfg)
console.log('Motor 13467 →', Array.isArray(m) ? m.length + ' entries' : m.error)
const sm = EXPANDER_REGISTRY['SP Motor']('13467', cfg)
console.log('SP Motor 13467 →', Array.isArray(sm) ? sm.length + ' entries' : sm.error)
const dm1 = EXPANDER_REGISTRY['DP Motor']('1', cfg)
const dm0 = EXPANDER_REGISTRY['DP Motor']('0', cfg)
console.log('DP Motor ank1 →', Array.isArray(dm1) ? dm1.length : dm1.error, '| ank0 →', Array.isArray(dm0) ? dm0.length : dm0.error)
const fc = EXPANDER_REGISTRY['Family Chart']('123', cfg)
console.log('Family Chart 123 →', Array.isArray(fc) ? fc.length + ' entries' : fc.error)
const f4 = EXPANDER_REGISTRY['Family Set 4']('128', cfg)
console.log('Family Set 4 128 →', Array.isArray(f4) ? f4.length + ' entries' : f4.error)
