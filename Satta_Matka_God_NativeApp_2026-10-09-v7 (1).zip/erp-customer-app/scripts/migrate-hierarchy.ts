/**
 * Migration Script: Role Hierarchy & Vendor Ownership
 * 
 * This script:
 * 1. Maps existing roles: master → master_admin, manager → admin_manager, user → agent
 * 2. Creates a legacy-agent placeholder for ownerless vendors
 * 3. Assigns all vendors without an agentId to the legacy agent
 * 4. Generates a migration report
 * 
 * Run: npx tsx scripts/migrate-hierarchy.ts
 */

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const ROLE_MAP: Record<string, string> = {
  master: 'master_admin',
  manager: 'admin_manager',
  user: 'agent',
}

async function main() {
  console.log('═══════════════════════════════════════════════════')
  console.log('  HIERARCHY MIGRATION — Role & Vendor Ownership')
  console.log('═══════════════════════════════════════════════════')
  console.log()

  // ── Step 0: Capture before state ──
  const usersBefore = await prisma.user.findMany({ select: { id: true, username: true, role: true } })
  const vendorsBefore = await prisma.vendor.findMany({ select: { id: true, code: true, businessName: true, agentId: true } })

  console.log('── BEFORE MIGRATION ──')
  console.log(`  Users: ${usersBefore.length}`)
  for (const u of usersBefore) {
    console.log(`    ${u.username} — role: ${u.role}`)
  }
  console.log(`  Vendors: ${vendorsBefore.length}`)
  const ownerlessBefore = vendorsBefore.filter(v => !v.agentId)
  console.log(`  Ownerless vendors: ${ownerlessBefore.length}`)
  console.log()

  // ── Step 1: Backfill roles ──
  console.log('── STEP 1: Backfill Roles ──')
  for (const user of usersBefore) {
    const newRole = ROLE_MAP[user.role]
    if (!newRole) {
      console.log(`  ⚠️  Unknown role "${user.role}" for user ${user.username} — skipping`)
      continue
    }
    if (user.role === newRole) {
      console.log(`  ✓  ${user.username}: already ${newRole}`)
      continue
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { role: newRole },
    })
    console.log(`  ✓  ${user.username}: ${user.role} → ${newRole}`)
  }
  console.log()

  // ── Step 2: Create legacy-agent ──
  console.log('── STEP 2: Create Legacy Agent ──')
  const masterAdmin = await prisma.user.findFirst({ where: { role: 'master_admin' } })
  if (!masterAdmin) {
    throw new Error('No master_admin found! Cannot create legacy agent.')
  }

  const legacyAgent = await prisma.user.upsert({
    where: { username: 'legacy-agent' },
    update: {},
    create: {
      username: 'legacy-agent',
      password: 'legacy-agent-unused-' + Date.now(), // No one logs in with this
      role: 'agent',
      name: 'Legacy Agent — Unassigned Records',
      status: 'migration_only',
      assignedMarkets: '',
      isLocked: true, // Locked by default — not for normal use
      createdByUserId: masterAdmin.id,
    },
  })
  console.log(`  ✓  Legacy agent: ${legacyAgent.id} (${legacyAgent.username})`)
  console.log()

  // ── Step 3: Assign ownerless vendors to legacy agent ──
  console.log('── STEP 3: Assign Ownerless Vendors ──')
  const ownerlessVendors = await prisma.vendor.findMany({
    where: { agentId: null },
    select: { id: true, code: true, businessName: true },
  })

  if (ownerlessVendors.length > 0) {
    for (const vendor of ownerlessVendors) {
      await prisma.vendor.update({
        where: { id: vendor.id },
        data: {
          agentId: legacyAgent.id,
          assignedByUserId: masterAdmin.id,
          assignedAt: new Date(),
        },
      })
      console.log(`  ✓  ${vendor.code} (${vendor.businessName}) → legacy-agent`)
    }
  } else {
    console.log('  ✓  No ownerless vendors found')
  }
  console.log()

  // ── Step 4: Verify ──
  console.log('── STEP 4: Verification ──')
  const usersAfter = await prisma.user.findMany({ select: { id: true, username: true, role: true, status: true } })
  const vendorsAfter = await prisma.vendor.findMany({ select: { id: true, code: true, agentId: true } })
  const ownerlessAfter = vendorsAfter.filter(v => !v.agentId)

  console.log(`  Users after: ${usersAfter.length}`)
  const roleCounts: Record<string, number> = {}
  for (const u of usersAfter) {
    roleCounts[u.role] = (roleCounts[u.role] || 0) + 1
  }
  for (const [role, count] of Object.entries(roleCounts)) {
    console.log(`    ${role}: ${count}`)
  }

  console.log(`  Vendors after: ${vendorsAfter.length}`)
  console.log(`  Ownerless vendors: ${ownerlessAfter.length}`)

  const vendorsWithLegacy = vendorsAfter.filter(v => v.agentId === legacyAgent.id)
  console.log(`  Vendors assigned to legacy-agent: ${vendorsWithLegacy.length}`)
  console.log()

  // ── Migration Report ──
  console.log('═══════════════════════════════════════════════════')
  console.log('  MIGRATION REPORT')
  console.log('═══════════════════════════════════════════════════')
  console.log(`  Total users before:     ${usersBefore.length}`)
  console.log(`  Total users after:      ${usersAfter.length}`)
  console.log(`  Users by role:`)
  for (const [role, count] of Object.entries(roleCounts)) {
    console.log(`    ${role}: ${count}`)
  }
  console.log(`  Total vendors before:   ${vendorsBefore.length}`)
  console.log(`  Vendors with real agent:${vendorsAfter.length - vendorsWithLegacy.length}`)
  console.log(`  Vendors with legacy:    ${vendorsWithLegacy.length}`)
  console.log(`  Vendors still ownerless:${ownerlessAfter.length}`)
  console.log()

  if (ownerlessAfter.length > 0) {
    console.log('  ⚠️  WARNING: Some vendors are still without an agent!')
    console.log('  This should be resolved before going to production.')
  } else {
    console.log('  ✓  All vendors have an agent assignment.')
  }

  console.log()
  console.log('═══════════════════════════════════════════════════')
  console.log('  MIGRATION COMPLETE')
  console.log('═══════════════════════════════════════════════════')
}

main()
  .catch((e) => {
    console.error('Migration failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
