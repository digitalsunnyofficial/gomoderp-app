// Smart Entry audit probe — verifies suspected calculation mismatches
// against the LIVE parser so the working doc states verified facts.
import { parseUnifiedEntry } from '../src/lib/matka/entry-parser'
import { lookupTerm } from '../src/lib/matka/term-registry'

function show(label: string, text: string, rate = 0) {
  const r = parseUnifiedEntry(text, rate)
  console.log('── ' + label)
  console.log('   singles:', JSON.stringify(r.singles))
  console.log('   doubles:', JSON.stringify(r.doubles))
  console.log('   mix    :', JSON.stringify(r.triples))
  console.log('   common :', JSON.stringify(r.common))
  console.log('   groups :', r.groups.map(g => `${g.option}(${g.entries.length}): ${JSON.stringify(g.entries.slice(0, 6))}${g.entries.length > 6 ? '…' : ''}`).join(' | ') || '(none)')
  console.log('   skipped:', JSON.stringify(r.skipped))
  console.log('   unknownLabels:', JSON.stringify(r.unknownLabels))
}

console.log('═══ A. dictionary probes ═══')
for (const t of ['single', 'double', 'triple', 'sangam', 'sp motor', 'dp motor', '20 chart', '30 chart', '40 chart', '20', '30', '40', 'family chart', 'jodi', 'joti', 'mix', 'common']) {
  console.log(`   lookupTerm('${t}') =`, lookupTerm(t))
}

console.log('\n═══ B. leading-zero jodi/panna tokens ═══')
show('Jodi 07,70,00', 'Jodi - 07,70,00 = 50')
show('unlabeled pannas 012,038,007', '012,038,007 = 50')

console.log('\n═══ C. newer group labels (SP/DP Motor, 20-40 charts, Family Chart) ═══')
show('SP Motor seed', 'SP Motor - 13467 = 100')
show('DP Motor seed', 'DP Motor - 128 = 100')
show('20 chart seed', '20 Chart - 137 = 50')
show('40 numeric seed', '40 - 137 = 50')
show('Family Chart seed', 'Family Chart - 123 = 100')

console.log('\n═══ D. bare "Single"/"Double"/"Triple" words ═══')
show('Single - 5,7', 'Single - 5,7 = 100')
show('Double - 12,23', 'Double - 12,23 = 100')
show('Triple - 128', 'Triple - 128 = 100')

console.log('\n═══ E. duplicates & merging ═══')
show('duplicate singles', '5 = 100\n5 = 200')
show('duplicate mix', '128 = 100\n128 = 200')
show('duplicate motor seeds', 'Motor -\n13467 = 100\n13467 = 100')

console.log('\n═══ F. motor expansion count in Smart Entry (batch expander) ═══')
show('motor 13467 @200', 'Motor -\n13467 = 200')
show('motor full 0-9', 'Motor -\n0123456789 = 100')

console.log('\n═══ G. class-strict groups ═══')
show('SP label dp panna', 'SP - 112 = 100')
show('Jodi label sp panna', 'Jodi - 128 = 50')
show('TP label', 'TP - 111,117 = 100')

console.log('\n═══ H. zero-amount / default-rate edge ═══')
show('no amount, default 0', '5,3,4')
show('no amount, default 25', '5,3,4', 25)
show('amount 0 explicit', '5 = 0')

console.log('\n═══ I. sangam-style input ═══')
show('sangam pair', 'Sangam - 128-370 = 50')
show('fs pair', 'FS - 128-370 = 50')

console.log('\n═══ J. mixed-label same line + multiline motor ═══')
show('two labels one line', 'SP - 1,2 DP - 12,23 = 50')
show('motor header then seeds', 'Motor -\n134678=200\n347890=100rs')
