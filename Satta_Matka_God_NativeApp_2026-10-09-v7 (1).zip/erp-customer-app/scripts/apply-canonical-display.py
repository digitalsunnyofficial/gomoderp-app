#!/usr/bin/env python3
# Canonical panna representation — apply at every customer-app display site
# plus ERP entry view. Uses exact-string replacements with verification counts.
# (bracket sequences are built via chr(91) to survive tool-layer stripping)
import pathlib

LB = chr(91)  # [
RB = chr(93)  # ]

def edits(path, pairs):
    p = pathlib.Path(path)
    src = p.read_text()
    applied = 0
    for old, new, expect in pairs:
        n = src.count(old)
        if n == expect:
            src = src.replace(old, new)
            applied += expect
        elif n == 0 and new in src:
            print(f"SKIP {path}: already applied: {old[:60]!r}")
        else:
            print(f"FAIL {path}: expected {expect}x, found {n}x for: {old[:70]!r}")
            raise SystemExit(1)
    p.write_text(src)
    print(f"OK   {path}: {applied} replacements")

PLAY = 'src/components/customerapp/PlayScreens.tsx'

# 1) import canonicalPanna
edits(PLAY, [(
    "import { expandGame, gameLabel, type ExpandRow } from '@/lib/matka/games-engine'",
    "import { expandGame, gameLabel, type ExpandRow } from '@/lib/matka/games-engine'\n"
    "import { canonicalPanna } from '@/lib/matka/chart-definitions'",
    1)])

# 2) canonical grid constants (after the Toast type line, module scope)
edits(PLAY, [(
    "type Toast = (m: string, t?: string) => void",
    "type Toast = (m: string, t?: string) => void\n\n"
    "// Operator-canonical panna spelling for every grid/picker (ascending\n"
    "// digits, 0 last: 012→120, 595→559). Settlement is digit-set based, so\n"
    "// this is presentation + bet-number canonicalization in ONE place.\n"
    "const SPB_C: Record<string, string[]> = Object.fromEntries(\n"
    "  Object.entries(SPB).map((" + chr(91) + "k, v]) => " + chr(91) + "k, v.map(canonicalPanna)))\n"
    "const DPB_C: Record<string, string[]> = Object.fromEntries(\n"
    "  Object.entries(DPB).map((" + chr(91) + "k, v]) => " + chr(91) + "k, v.map(canonicalPanna)))",
    1)])

# 3) swap grid references to canonical constants (main + starline + preview)
edits(PLAY, [
    ("const U = mode === 'sp' ? SPB : DPB", "const U = mode === 'sp' ? SPB_C : DPB_C", 3),
])

# 4) TP grids (main play + starline) — canonical num on tiles
edits(PLAY, [(
    '<div className="grid g5">{TP.map(p =>',
    '<div className="grid g5">{TP.map(rawP => { const p = canonicalPanna(rawP); return (',
    2)])
# 4b) close the two TP map bodies (Tile lines carrying type="tp")
pp = pathlib.Path(PLAY)
lines = pp.read_text().split('\n')
fixed = 0
for i, ln in enumerate(lines):
    if 'type="tp"' in ln and 'slipInput={slipInput} />)}</div>' in ln:
        lines[i] = ln.replace('slipInput={slipInput} />)}</div>', 'slipInput={slipInput} />); })}</div>')
        fixed += 1
assert fixed == 2, f"expected 2 TP closers, fixed {fixed}"
pp.write_text('\n'.join(lines))
print(f"OK   {PLAY}: 2 TP closers")

# 5) slip row display
edits(PLAY, [(
    '<span className="mono" style={{ fontWeight: 800 }}>{s.num}</span>',
    '<span className="mono" style={{ fontWeight: 800 }}>{canonicalPanna(s.num)}</span>',
    1)])

# 6) seed expansion preview display
edits(PLAY, [(
    '<span className="mono" style={{ fontWeight: 800 }}>{r.num}</span>',
    '<span className="mono" style={{ fontWeight: 800 }}>{canonicalPanna(r.num)}</span>',
    1)])

# 7) seed addAll — place canonical bet numbers
edits(PLAY, [(
    "onAdd(okRows.map(r => ({\n      marketCode: mk, slot, type: r.type, num: r.num, points,",
    "onAdd(okRows.map(r => ({\n      marketCode: mk, slot, type: r.type, num: canonicalPanna(r.num), points,",
    1)])

INFO = 'src/components/customerapp/InfoScreens.tsx'
edits(INFO, [(
    "import { gameLabel } from '@/lib/matka/games-engine'",
    "import { gameLabel } from '@/lib/matka/games-engine'\nimport { canonicalPanna } from '@/lib/matka/chart-definitions'",
    1), (
    '<span className="num-b">{b.num}</span>',
    '<span className="num-b">{canonicalPanna(b.num)}</span>',
    1)])

MERP = 'src/app/merp/page.tsx'
edits(MERP, [(
    "  pannaToAnk as chartPannaToAnk,\n} from '@/lib/matka/chart-definitions'",
    "  pannaToAnk as chartPannaToAnk, canonicalPanna,\n} from '@/lib/matka/chart-definitions'",
    1), (
    'fullPannaList = pd.numbers\n                          .map((n: { number: string; price: number }) => `${n.number}@${n.price}`)\n                          .join(\'  \')',
    'fullPannaList = pd.numbers\n                          .map((n: { number: string; price: number }) => `${canonicalPanna(n.number)}@${n.price}`)\n                          .join(\'  \')',
    1), (
    'fullPannaList = pd.generatedPannas.join(\'  \')',
    "fullPannaList = pd.generatedPannas.map((g: string) => canonicalPanna(g)).join('  ')",
    1)])

print("ALL EDITS APPLIED")
