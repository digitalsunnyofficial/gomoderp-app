// TP whole-window rule (operator bug report 2026-10-09):
// Triple Pana on Sridevi must be placeable during the OPEN session
// (it settles on the close panna, but betting runs the whole window).
// jodi-guard proves the open session of sridevi_day_open is live now.
const BASE = 'http://127.0.0.1:3000'

async function main() {
  const login = await fetch(BASE + '/api/customer-app/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mobile: '9876500001', password: 'Demo@123' }),
  })
  const { token } = await login.json() as { token: string }
  const auth = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }

  const me = await (await fetch(BASE + '/api/customer-app/me', { headers: auth })).json() as { customer: { wallet: number } }
  const w0 = me.customer.wallet

  // 1) TP bet during OPEN session → must succeed now
  const tp = await fetch(BASE + '/api/customer-app/bets', {
    method: 'POST', headers: auth,
    body: JSON.stringify({ items: [{ marketCode: 'sridevi_day_open', slot: 'close', type: 'tp', num: '000', points: 10, gameCode: 'tp', clientRequestId: 'tp-window-test-' + Date.now() }] }),
  })
  const tpBody = await tp.json() as { ok?: boolean; error?: string; wallet?: number }
  console.log('TP during OPEN session →', tp.status, tpBody.ok ? 'OK (bug fixed — bet placed)' : 'STILL BLOCKED: ' + tpBody.error)
  if (!tpBody.ok) process.exit(1)

  // 2) TP slot must be forced to 'close' (settles on close panna)
  const bets = await (await fetch(BASE + '/api/customer-app/bets?status=pending', { headers: auth })).json() as { bets: Array<{ type: string; slot: string; num: string; marketCode: string }> }
  const mine = bets.bets.find(b => b.type === 'tp' && b.marketCode === 'sridevi_day_open' && b.num === '000')
  console.log('TP stored slot →', mine?.slot, mine?.slot === 'close' ? '(correct — settles close panna)' : '(WRONG!)')
  if (mine?.slot !== 'close') process.exit(1)

  // 3) wallet debited exactly 10
  const me2 = await (await fetch(BASE + '/api/customer-app/me', { headers: auth })).json() as { customer: { wallet: number } }
  console.log(`wallet ${w0} → ${me2.customer.wallet} (debited ${w0 - me2.customer.wallet})`)
  if (w0 - me2.customer.wallet !== 10) process.exit(1)

  console.log('TP WINDOW RULE VERIFIED — 3/3')
}
main().catch(e => { console.error(e); process.exit(1) })
