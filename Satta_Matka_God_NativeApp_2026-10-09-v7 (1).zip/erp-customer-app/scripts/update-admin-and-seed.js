/**
 * Script to:
 * 1. Update admin credentials to admin@master.com / Admin@90_21#
 * 2. Create sample data: 1 manager, 1 agent, 10 customers (vendors) under agent
 * 
 * Uses Prisma Client directly with the SQLite database.
 */

const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  console.log('=== Updating Admin Credentials ===')
  
  // Find the current admin (master) user
  const admin = await prisma.user.findFirst({ where: { role: 'master' } })
  
  if (!admin) {
    console.error('ERROR: No master admin user found in the database!')
    process.exit(1)
  }
  
  console.log(`Found admin: ${admin.username} (id: ${admin.id})`)
  
  // Update credentials
  const updatedAdmin = await prisma.user.update({
    where: { id: admin.id },
    data: {
      username: 'admin@master.com',
      password: 'Admin@90_21#',
      name: 'Master Admin',
    }
  })
  
  console.log(`Updated admin credentials:`)
  console.log(`  Username: ${updatedAdmin.username}`)
  console.log(`  Password: Admin@90_21#`)
  console.log(`  Name: ${updatedAdmin.name}`)
  
  // Check if manager already exists
  const existingManager = await prisma.user.findFirst({ where: { role: 'manager' } })
  
  if (existingManager) {
    console.log('\nManager already exists, skipping creation.')
  } else {
    console.log('\n=== Creating Sample Manager ===')
    const manager = await prisma.user.create({
      data: {
        username: 'manager1',
        password: 'Manager@123',
        name: 'Rajesh Kumar',
        role: 'manager',
        status: 'active',
        assignedMarkets: '',
        managerId: admin.id, // Manager reports to master admin
      }
    })
    console.log(`Created Manager: ${manager.username} (id: ${manager.id})`)
    console.log(`  Password: Manager@123`)
  }
  
  // Check if agent already exists
  const existingAgent = await prisma.user.findFirst({ where: { role: 'user', name: 'Sample Agent' } })
  
  let agentUser = existingAgent
  
  if (existingAgent) {
    console.log('\nSample Agent already exists, skipping creation.')
  } else {
    console.log('\n=== Creating Sample Agent ===')
    agentUser = await prisma.user.create({
      data: {
        username: 'agent1',
        password: 'Agent@123',
        name: 'Sample Agent',
        role: 'user',
        status: 'active',
        assignedMarkets: '',
      }
    })
    console.log(`Created Agent: ${agentUser.username} (id: ${agentUser.id})`)
    console.log(`  Password: Agent@123`)
  }
  
  // Create 10 sample customers (vendors) under the agent
  console.log('\n=== Creating Sample Customers (Vendors) ===')
  
  const customerNames = [
    'Amit Sharma', 'Priya Patel', 'Suresh Jain', 'Meena Desai', 'Ravi Verma',
    'Anita Kulkarni', 'Dinesh Patil', 'Kavita Mehta', 'Ganesh Iyer', 'Lata Nair'
  ]
  
  let created = 0
  let skipped = 0
  
  for (let i = 0; i < customerNames.length; i++) {
    const code = `KH${String(i + 1).padStart(3, '0')}`
    
    // Check if vendor already exists
    const existing = await prisma.vendor.findFirst({ where: { code } })
    if (existing) {
      skipped++
      continue
    }
    
    const vendor = await prisma.vendor.create({
      data: {
        code,
        vendorType: 'individual',
        businessName: customerNames[i],
        mobileNo: `98765${String(43210 + i).padStart(5, '0')}`,
        email: `${customerNames[i].toLowerCase().replace(/\s+/g, '.')}@example.com`,
        businessArea: 'Matka',
        city: 'Mumbai',
        state: 'Maharashtra',
        createdBy: agentUser.username,
      }
    })
    created++
    console.log(`  Created: ${vendor.code} - ${vendor.businessName}`)
  }
  
  console.log(`\nCustomers created: ${created}, skipped (already exist): ${skipped}`)
  
  // Summary
  console.log('\n=== SUMMARY ===')
  console.log('Admin Credentials:')
  console.log('  Username: admin@master.com')
  console.log('  Password: Admin@90_21#')
  console.log('')
  console.log('Manager Credentials:')
  console.log('  Username: manager1')
  console.log('  Password: Manager@123')
  console.log('')
  console.log('Agent Credentials:')
  console.log('  Username: agent1')
  console.log('  Password: Agent@123')
  console.log('')
  console.log('Sample Customers: 10 vendors (KH001-KH010)')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error('Error:', e)
    await prisma.$disconnect()
    process.exit(1)
  })
