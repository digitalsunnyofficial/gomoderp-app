#!/bin/bash
# Task 30 one-shot verification — start server, run all HTTP suites,
# verify new landing/gate/commission behaviour, teardown. Single invocation
# (the sandbox reaps detached servers between tool calls).
set -u
cd /home/z/my-project

PORT=3000
PASS=0; FAIL=0
c() { if [ "$1" = "0" ]; then PASS=$((PASS+1)); echo "PASS  $2"; else FAIL=$((FAIL+1)); echo "FAIL  $2"; fi }

echo "════ starting dev server (one-shot) ════"
rm -f /tmp/one-shot-dev.log
nohup npx next dev -p $PORT > /tmp/one-shot-dev.log 2>&1 &
SRV=$!

# health wait (max ~90s)
UP=1
for i in $(seq 1 90); do
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 "http://localhost:$PORT/api/health" 2>/dev/null || echo 000)
  if [ "$code" = "200" ]; then UP=0; break; fi
  sleep 1
done
c $UP "server healthy on :$PORT"

if [ $UP -ne 0 ]; then
  echo "server did not come up — aborting"; kill $SRV 2>/dev/null; exit 1
fi

echo "════ regression suites ════"
bun scripts/test-entry-parser.ts        > /tmp/t-parser.log 2>&1;  c $? "entry-parser suite (72)"
bun scripts/test-agent-commission.ts    > /tmp/t-comm.log 2>&1;    c $? "agent-commission suite (56, incl. default-2% check)"
bun scripts/test-agent-access-control.ts> /tmp/t-rbac.log 2>&1;   c $? "agent-access-control suite (58)"
bun scripts/test-whatsapp-pipeline.ts   > /tmp/t-wap.log 2>&1;     c $? "whatsapp-pipeline suite (116)"
bun scripts/test-whatsapp-panel.ts      > /tmp/t-wapn.log 2>&1;    c $? "whatsapp-panel suite (37)"
bun scripts/test-signup-approval-toggle.ts > /tmp/t-signup.log 2>&1; c $? "signup-approval-toggle suite (17)"
bun scripts/test-chitthi-render.ts      > /tmp/t-chitthi.log 2>&1; c $? "chitthi render suite (4)"

echo "════ suite tallies ════"
for f in /tmp/t-parser.log /tmp/t-comm.log /tmp/t-rbac.log /tmp/t-wap.log /tmp/t-wapn.log /tmp/t-signup.log /tmp/t-chitthi.log; do
  echo "-- $f"; grep -E "RESULT|pass," "$f" | tail -1
done
grep -E "unset global rate" /tmp/t-comm.log

echo "════ routes + landing + gate ════"
for r in / /merp /app /api/health; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT$r")
  [ "$code" = "200" ]; c $? "route $r → 200 (got $code)"
done
code=$(curl -s -o /dev/null -w "%{http_code}" -L --max-redirs 0 "http://localhost:$PORT/download" 2>/dev/null || true)
# /download now redirects (307/308) to / — accept 3xx without following
code2=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/download")
echo "  /download status: $code2"
case "$code2" in 30*|200) c 0 "/download redirects/works ($code2)";; *) c 1 "/download ($code2)";; esac

# landing content: brand + download + encrypted link, NO old marketing
html=$(curl -s "http://localhost:$PORT/")
echo "$html" | grep -q "Satta Matka God";                      c $? "landing carries 'Satta Matka God'"
echo "$html" | grep -qi "Download";                            c $? "landing has download CTA"
echo "$html" | grep -q 'href="/g/';                            c $? "landing has the encrypted /g/ admin link"
echo "$html" | grep -qi "pricing\|Start Free Demo\|Testimonial"; [ $? -ne 0 ]; c $? "landing has NO old marketing sections"

# gate: valid token redirects to /merp, invalid 404s
TOKEN=$(node -e "const{createHmac}=require('crypto');console.log(createHmac('sha256','satta-matka-god-gate-2026').update('super-admin-login').digest('base64url'))")
code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/g/$TOKEN")
case "$code" in 307|308|302) c 0 "gate valid token → redirect ($code)";; *) c 1 "gate valid token ($code)";; esac
loc=$(curl -s -o /dev/null -w "%{redirect_url}" "http://localhost:$PORT/g/$TOKEN")
echo "  gate redirect target: $loc"
echo "$loc" | grep -q "/merp"; c $? "gate redirects to /merp"
code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/g/wrong-token-xyz")
[ "$code" = "404" ]; c $? "gate invalid token → 404 (got $code)"

# commission API default check (as super)
COOKIE=$(curl -s -i -X POST "http://localhost:$PORT/api/auth" -H 'Content-Type: application/json' \
  -d '{"username":"superadmin@mb.com","password":"SAdmin@123_321"}' | grep -i "^set-cookie:" | sed 's/^[Ss]et-[Cc]ookie: //' | cut -d';' -f1 | tr -d '\r' | tr '\n' ';' )
rate=$(curl -s "http://localhost:$PORT/api/app-admin/commissions" -H "cookie: $COOKIE" | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const j=JSON.parse(s);console.log(j.globalRate+','+j.globalRateIsDefault)})")
echo "  commission API globalRate,IsDefault = $rate"
[ "$rate" = "2,true" ]; c $? "commission default 2% + IsDefault flag (demo state)"
pend=$(curl -s "http://localhost:$PORT/api/app-admin/commissions" -H "cookie: $COOKIE" | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const j=JSON.parse(s);console.log(j.summary.pendingAmount)})")
[ "$pend" = "280" ]; c $? "demo pending commission = ₹280 @2% (got ₹$pend)"

echo "════ teardown ════"
kill $SRV 2>/dev/null
pkill -f "next dev" 2>/dev/null
sleep 1
echo "════════════════════════════════"
echo "RESULT: $PASS pass, $FAIL fail"
[ $FAIL -eq 0 ] || exit 1
