#!/usr/bin/env python3
"""Post-process Smart Entry docx footers per toc.md:
1. Remove empty <w:pgNumType/> from document.xml (WPS compat)
2. Patch each section's footer PAGE field with explicit \\* ROMAN / \\* arabic
"""
import re, sys, zipfile, shutil, os

path = sys.argv[1]
tmp = path + ".tmp"
shutil.copy(path, tmp)

with zipfile.ZipFile(tmp, "r") as zin:
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}

doc = data["word/document.xml"].decode("utf-8")

# 1. remove empty pgNumType
doc_before = doc
doc = re.sub(r"<w:pgNumType/>", "", doc)
removed = doc_before.count("<w:pgNumType/>")

# 2. map sectPr order → footer rIds → fmt
sectprs = re.findall(r"<w:sectPr[^>]*>.*?</w:sectPr>", doc, re.S)
rels = data["word/_rels/document.xml.rels"].decode("utf-8")
rid_to_target = dict(re.findall(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels))

plan = []  # (footer_file, fmt)
for sp in sectprs:
    fmt_m = re.search(r'<w:pgNumType[^>]*w:fmt="([^"]+)"', sp)
    foot_refs = re.findall(r'<w:footerReference[^>]*r:id="([^"]+)"', sp)
    fmt = fmt_m.group(1) if fmt_m else None
    for rid in foot_refs:
        target = rid_to_target.get(rid, "")
        if target.startswith("footer"):
            plan.append((("word/" + target) if not target.startswith("word/") else target, fmt))

print("sections:", len(sectprs), "| footer plan:", plan, "| removed empty pgNumType:", removed)

patched = []
for fname, fmt in plan:
    if fname not in data or fmt is None:
        continue
    switch = "ROMAN" if "oman" in fmt or "OMAN" in fmt else "arabic"
    xml = data[fname].decode("utf-8")
    new_xml, n = re.subn(
        r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
        r"\1 PAGE \\* " + switch + r" \\* MERGEFORMAT \2",
        xml,
    )
    if n:
        data[fname] = new_xml.encode("utf-8")
        patched.append((fname, switch, n))

data["word/document.xml"] = doc.encode("utf-8")

with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zout:
    for n in names:
        zout.writestr(n, data[n])
os.remove(tmp)
print("patched footers:", patched)
print("OK")
