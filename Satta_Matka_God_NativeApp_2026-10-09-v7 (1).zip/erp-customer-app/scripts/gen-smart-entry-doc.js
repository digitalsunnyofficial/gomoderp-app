// ────────────────────────────────────────────────────────────────────────────
// gen-smart-entry-doc.js — Smart Entry Working Document (.docx)
// Recipe R1 (Pure Paragraph Left) + DM-1 Deep Cyan palette, English report,
// Profile A fonts (Times New Roman), 3-section structure (cover / front / body)
// ────────────────────────────────────────────────────────────────────────────
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, AlignmentType, HeadingLevel,
  WidthType, BorderStyle, ShadingType, SectionType, TableOfContents,
  PageBreak, LevelFormat, TableLayoutType,
} = require("docx");
const fs = require("fs");

// ── Palette: DM-1 Deep Cyan (tech report) ──
const P = {
  bg: "162235", accent: "37DCF2",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "1B6B7A", headerText: "FFFFFF", accentLine: "1B6B7A", innerLine: "C8DDE2", surface: "EDF3F5" },
  headingColor: "0B3C4A",
  body: "000000", secondary: "505A64",
};
const FONTS = { ascii: "Times New Roman", eastAsia: "SimSun" };
const MONO = { ascii: "Courier New", eastAsia: "SimSun" };

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ── Text helpers ──
function safeText(v, ph) {
  if (v === undefined || v === null || v === "" || String(v) === "NaN" || String(v) === "undefined") return ph || "[n/a]";
  return String(v);
}
function run(text, opts = {}) {
  return new TextRun({ text: safeText(text), size: 24, color: P.body, font: FONTS, ...opts });
}
function monoRun(text, opts = {}) {
  return new TextRun({ text: safeText(text), size: 20, color: P.body, font: MONO, ...opts });
}
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1, alignment: AlignmentType.CENTER,
    spacing: { before: 360, after: 180, line: 380, lineRule: "atLeast" },
    children: [new TextRun({ text, bold: true, size: 32, color: P.headingColor, font: FONTS })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 130, line: 360, lineRule: "atLeast" },
    children: [new TextRun({ text, bold: true, size: 30, color: P.headingColor, font: FONTS })],
  });
}
function body(textOrRuns, opts = {}) {
  const children = Array.isArray(textOrRuns) ? textOrRuns : [run(textOrRuns)];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children, ...opts,
  });
}
function bullet(textOrRuns) {
  const children = Array.isArray(textOrRuns) ? textOrRuns : [run(textOrRuns)];
  return new Paragraph({ bullet: { level: 0 }, spacing: { line: 312, after: 60 }, children });
}
function numbered(ref, textOrRuns) {
  const children = Array.isArray(textOrRuns) ? textOrRuns : [run(textOrRuns)];
  return new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { line: 312, after: 60 }, children });
}
function caption(text) {
  return new Paragraph({
    keepNext: true, spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: P.headingColor, font: FONTS })],
  });
}
// Cell content: string, or { t, mono, bold, color }
function cellPara(content) {
  if (typeof content === "object" && content.t !== undefined) {
    if (content.mono) return new Paragraph({ spacing: { line: 312 }, children: [monoRun(content.t, { bold: !!content.bold, color: content.color || P.body })] });
    return new Paragraph({ spacing: { line: 312 }, children: [run(content.t, { bold: !!content.bold, size: 21, color: content.color || P.body })] });
  }
  return new Paragraph({ spacing: { line: 312 }, children: [run(String(content), { size: 21 })] });
}
// Horizontal-only business table with zebra option
function tbl(headers, rows, widths, opts = {}) {
  const headerRow = new TableRow({
    tableHeader: true, cantSplit: true,
    children: headers.map((text, i) => new TableCell({
      children: [new Paragraph({ spacing: { line: 312 }, children: [new TextRun({ text, bold: true, size: 21, color: P.table.headerText, font: FONTS })] })],
      shading: { type: ShadingType.CLEAR, fill: P.table.headerBg },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  });
  const dataRows = rows.map((cells, r) => new TableRow({
    cantSplit: true,
    children: cells.map((cell, i) => new TableCell({
      children: [cellPara(cell)],
      shading: { type: ShadingType.CLEAR, fill: r % 2 === 0 ? "FFFFFF" : P.table.surface },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: P.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: P.table.innerLine },
      insideVertical: NB,
    },
    rows: [headerRow, ...dataRows],
  });
}

// ── Cover (R1) — English-aware title layout ──
function estimateTextWidth(text, pt) {
  let width = 0;
  for (const ch of text) {
    const code = ch.codePointAt(0);
    const isCJK = (code >= 0x4E00 && code <= 0x9FFF) || (code >= 0x3400 && code <= 0x4DBF) ||
      (code >= 0x3000 && code <= 0x303F) || (code >= 0xFF00 && code <= 0xFFEF);
    width += isCJK ? pt * 20 : pt * 11;
  }
  return width;
}
function splitTitleLinesEN(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = []; let cur = "";
  for (const w of words) {
    const candidate = cur ? cur + " " + w : w;
    if (estimateTextWidth(candidate, pt) <= maxWidthTwips || !cur) cur = candidate;
    else { lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 4) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLinesEN(title, maxWidthTwips, titlePt);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLinesEN(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(params) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
    metaLineCount = 0, fixedHeight = 800, pageHeight = 16838 } = params;
  const SAFETY = 1200;
  const usableHeight = pageHeight - SAFETY;
  const titleHeight = titleLineCount * (titlePt * 23 + 200);
  const subtitleHeight = hasSubtitle ? (12 * 23 + 600) : 0;
  const englishLabelHeight = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaHeight = metaLineCount * (10 * 23 + 100);
  const implicitParaHeight = 3 * 300;
  const contentHeight = titleHeight + subtitleHeight + englishLabelHeight + metaHeight + fixedHeight + implicitParaHeight;
  const remainingSpace = usableHeight - contentHeight;
  const safeRemaining = Math.max(remainingSpace, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(safeRemaining * 0.45);
  const rawBottom = Math.floor(safeRemaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(safeRemaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}
function buildCoverR1(config) {
  const PC = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: PC.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: PC.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "), size: 18, color: PC.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true, color: PC.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 800, line: 320, lineRule: "atLeast" },
      children: [new TextRun({ text: config.subtitle, size: 24, color: PC.subtitleColor, font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: PC.metaColor, font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: PC.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: PC.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        " }),
      new TextRun({ text: config.footerRight || "", size: 16, color: PC.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: PC.bg }, borders: noBorders,
        children,
      })],
    })],
  })];
}

// ── Shared header/footer ──
function pageHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.innerLine, space: 4 } },
      children: [new TextRun({ text: "Smart Entry — Working Document", size: 18, color: "808080", font: FONTS })],
    })],
  });
}
function pageNumFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: FONTS })],
    })],
  });
}

// ════════════════════════════════════════════════════════════════════════════
// FRONT MATTER — Executive Summary + Table of Contents
// ════════════════════════════════════════════════════════════════════════════
const frontMatter = [
  h1("Executive Summary"),
  body("Smart Entry is the ERP administration page (page key unified-entry, sidebar label \u201CSmart Entry\u201D) that reduces the entire daily entry workflow to one input box. The operator selects a market and a date, then types, dictates, or pastes free-form text in the format operators already use on WhatsApp. The system parses that text live, classifies every number, calculates amounts, and routes each entry to its respective store: single-digit numbers to the Single inventory, two-digit numbers to the Double (Jodi) inventory, and three-digit numbers to the Triple inventory as Mix, Common, or one of twenty-two recognised group types. The design goal is that any input which can arrive from a WhatsApp chat must be either evaluated correctly or visibly held back \u2014 never silently mis-filed."),
  body("This working document was prepared as the agreed baseline before the correction phase. It documents every Smart Entry functional block as it exists today: the three input channels, the terminology dictionary, the parsing pipeline, the routing and calculation rules for every game type, the submit chain, the data model, and the verification tooling. All counts and routing behaviours stated here were verified by executing the live parser and expanders (scripts/audit-smart-entry.ts, scripts/probe-chart-counts.ts, scripts/probe-expanders.ts), not by reading code alone."),
  body([
    run("The verification pass confirmed "),
    run("seven mismatch findings", { bold: true }),
    run(", of which one is financially significant: the Motor group in Smart Entry expands a seed into all C(n,3)\u00D76 digit arrangements (60 pannas for seed 13467, 720 for the full digit set), which is six times the count the admin panel\u2019s own Group Preview shows for the same input (10 and 120 respectively), and every ordering of the same panna receives the full amount. Combined with a set of missing dictionary terms (including \u201CSingle\u201D, \u201CSP Motor\u201D, \u201CDP Motor\u201D, the 20/30/40 charts and \u201CSangam\u201D), leading-zero corruption for jodis and pannas, and inconsistent duplicate handling, these findings define the correction backlog proposed in Chapter 10. The voice dictation module is documented for completeness and is explicitly out of scope for changes, per the operator\u2019s instruction."),
  ]),
  new Paragraph({
    alignment: AlignmentType.JUSTIFIED, spacing: { line: 312, after: 120 },
    children: [
      run("Chapters 1 through 9 describe the system as it stands. Chapter 6 lists the verified findings with evidence, and Chapter 10 proposes the correction plan for sign-off. Nothing has been changed in the codebase for this document; it is a reference and review artefact."),
      new PageBreak(),
    ],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 480, after: 360 },
    children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FONTS, color: P.headingColor })],
  }),
  new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }),
  new Paragraph({
    spacing: { before: 200 },
    children: [new TextRun({ text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \u201CUpdate Field.\u201D", italics: true, size: 18, color: "888888", font: FONTS })],
  }),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 1 — Overview
// ════════════════════════════════════════════════════════════════════════════
const ch1 = [
  h1("1. Overview and Role in the System"),
  body("Smart Entry is one of three entry surfaces in the ERP\u2019s Entry group, alongside New Entry (the classic form-based entry with card view) and Entry List (the day-level consolidated view). Where New Entry requires the operator to open specific sections for singles, doubles, pannas and group charts, Smart Entry collapses all of them into a single textarea with live parsing: the whole calculation happens in the input box itself. The page is implemented in src/components/pages/UnifiedEntryPage.tsx and its pure parsing engine in src/lib/matka/entry-parser.ts, supported by the terminology dictionary in src/lib/matka/term-registry.ts and the group expanders in src/lib/matka/group-expanders.ts."),
  body("The parser is deliberately pure: it runs identically on the client for the live preview and can run on the server, with no React or database imports. Every keystroke re-parses the whole text (memoised), so the operator sees the routing result \u2014 how many singles, doubles, mix pannas, common pannas and group pannas were recognised, at what grand total \u2014 before anything is submitted. Content that cannot be classified is held back and displayed in a skipped list rather than being filed somewhere plausible; this \u201Chold back, never mis-file\u201D principle is the core safety property for money data."),
  body("The system is also designed to evolve. Any section label that the dictionary does not recognise is reported back as an unknown label: the UI shows it with a Teach button (for administrators), and the event is recorded as a Parser Exception so administrators can see exactly which spellings the field is producing. A taught term is stored in the ParserTerm table and applies instantly to every future parse."),
  body("Scope of this document: Smart Entry as the operator-facing entry system \u2014 its inputs, dictionary, parser, routing and calculation rules, submit chain, and data storage. The customer application\u2019s play screens and bet API are a separate chain and are not covered here, except where the two must agree (notably Motor arithmetic, Chapter 6, finding F1). The voice dictation flow is documented in Section 2.2 as-is and, per the operator\u2019s explicit instruction, is marked UNTOUCHED: no correction may modify it."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 2 — Input Channels
// ════════════════════════════════════════════════════════════════════════════
const ch2 = [
  h1("2. Input Channels"),
  h2("2.1 WhatsApp Paste and Manual Typing"),
  body("The primary channel is pasting text transcribed from WhatsApp chats. The expected line grammar is a term, an optional separator, a list of numbers, and an optional amount:"),
  body([monoRun("Term - numbers = amount", { bold: true }), run("   e.g.  "), monoRun("SP - 1,2,5,6,7 = 100 rs"), run("   or   "), monoRun("Motor -")], {}),
  body("One entry per line is the convention, and a bare term line (for example \u201CMotor -\u201D on its own line) acts as a section header: all following content lines belong to that term until another recognised header appears. The parser accepts several amount styles beyond the equals sign, all verified: a dash run (\u201C134678---200\u201D), a dot style (\u201C07.2500rs\u201D), and a trailing glued amount (\u201C5 3 4 100rs\u201D). Numbers on the left side may be separated by spaces, commas, or slashes. When a line carries no amount at all, the page-level Default rate field is applied to every number on that line \u2014 which is also the mechanism behind finding F5 (zero-amount rows) in Chapter 6."),
  caption("Table 2-1: Accepted amount styles (all verified against the live parser)"),
  tbl(
    ["Style", "Example input", "Interpretation"],
    [
      ["Equals", { t: "SP - 1,2,5 = 100 rs", mono: true }, "Numbers 1, 2, 5 at 100 each"],
      ["Dash run", { t: "134678---200", mono: true }, "Seed 134678 at 200"],
      ["Dot style", { t: "07.2500rs", mono: true }, "Number 07 at 2500 (see finding F2 on leading zeros)"],
      ["Trailing amount", { t: "5 3 4 100rs", mono: true }, "Numbers 5, 3, 4 at 100 each"],
      ["No amount", { t: "5,3,4", mono: true }, "Uses the Default rate field (0 if empty \u2014 finding F5)"],
    ],
    [20, 40, 40]
  ),
  h2("2.2 Voice Dictation \u2014 UNTOUCHED MODULE"),
  body([
    run("Status: "),
    run("out of scope for the correction phase \u2014 documented as-is, must not be changed.", { bold: true }),
  ]),
  body("Voice entry uses the device keyboard\u2019s voice typing (Gboard mic) rather than a browser speech API, because the browser SpeechRecognition API proved unreliable on the team\u2019s devices. The spoken transcript is typed into the focused textarea like keyboard input; the Format button (DictationFormatButton) and the textarea\u2019s on-blur hook then convert spoken lines into entry format via the pure module src/lib/speech-dictation.ts. The conversion recognises digit words in English, romanised Hindi and Devanagari (\u201Cthree seven zero\u201D, \u201Cteen saat zero\u201D, \u0969\u096D\u0966), converts \u201Cbarabar\u201D / \u092C\u0930\u093E\u092C\u0930 / \u201Cequals\u201D into \u201C=\u201D, treats \u201Crs\u201D / \u201Crupees\u201D / \u0930\u0941\u092A\u092F\u0947 as the end of an entry (the next number starts a new line), supports compound amount words (\u201Cone thousand\u201D, \u201Cpanch hazaar\u201D), and appends \u201Crs\u201D automatically. Only lines that look like dictation are converted; typed and pasted content is never modified, and conversion is idempotent, so pressing Format repeatedly is safe."),
  body("On Smart Entry the button is mounted with groupSize = null (no comma grouping), since group seeds are of variable length. The output of the conversion is exactly the line grammar described in Section 2.1, so the parser needs no dictation-specific handling. Any correction that touches the parser must preserve this boundary: the dictation module\u2019s output must remain valid parser input without parser-side special-casing."),
  h2("2.3 The One-Input Contract"),
  body("All three channels feed the same textarea and therefore the same contract: whatever lands in the box \u2014 pasted chat text, dictated speech converted to numbers, or hand-typed lines \u2014 must be evaluated by the same parser with the same rules. This is the operator\u2019s requirement that \u201Cit must be any inputs which will come, we have to prepare in such a way that it must be able to evaluate and calculate any type of data.\u201D Chapter 6 measures how far the current implementation falls short of that contract, line by line."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 3 — Terminology Dictionary
// ════════════════════════════════════════════════════════════════════════════
const ch3 = [
  h1("3. Terminology Dictionary"),
  body("The dictionary (term-registry.ts) is the single source of truth that lets one input box accept whatever spelling a player uses. Before lookup, every candidate label is normalised: lowercased, punctuation replaced by spaces, whitespace collapsed (\u201CSingle   Panna!\u201D and \u201Cmotor-pana:\u201D both become \u201Csingle panna\u201D / \u201Cmotor pana\u201D). Lookup is exact on the normalised form \u2014 deliberately no prefix or fuzzy matching, so \u201Cjodi 12 23\u201D never resolves to the label \u201Cjodi\u201D merely by starting with the word. Custom terms stored in the ParserTerm table take precedence over built-ins, which lets an administrator override a default meaning. A small set of noise labels (\u201Crs\u201D, \u201Ctotal\u201D, \u201Cmob\u201D, \u201Cgm\u201D, and similar chat words) is protected so ordinary chatter is never mistaken for a section header."),
  body("The built-in dictionary ships 95 spellings across 18 canonical categories. The complete list is reproduced in Appendix A. The operator\u2019s working vocabulary maps onto the system as follows."),
  caption("Table 3-1: Operator vocabulary mapped to canonical categories"),
  tbl(
    ["Operator term", "Canonical category", "Where entries are routed"],
    [
      ["Single", "digit-length rule (1 digit)", "double-single-inventories, type = single"],
      ["Double / Jodi / Joti", "DP \u2014 but note the digit-length rule wins", "double-single-inventories, type = double"],
      ["Triple \u2014 Mix / Common", "mix / common", "triple-inventories, type = mix / common"],
      ["Triple \u2014 SP, DP, TP, SPDP, SPTP, DPTP, SPDPTP", "same-named group option", "triple-inventories, type = group (one row per option)"],
      ["Triple \u2014 Motor, SP Motor, DP Motor", "Motor Pana / SP Motor / DP Motor", "triple-inventories, type = group"],
      ["Triple \u2014 20/30/40/50/60/70/90 DP/90 ABR charts", "same-named group option", "triple-inventories, type = group"],
      ["Triple \u2014 Family (Sets 4/6/8, combined)", "Family Set 4 / 6 / 8 / Family Chart", "triple-inventories, type = group"],
      ["Triple \u2014 Sangam", "not in the dictionary (finding F3)", "held back today"],
    ],
    [30, 30, 40]
  ),
  body("An important structural property, verified and easily missed: for one- and two-digit numbers the digit-length rule overrides the label entirely. \u201CSP - 1,2,5\u201D books three singles, and \u201CJodi - 12,23\u201D books two doubles, regardless of the term written. Labels only take control from three digits upward. This matches the operator\u2019s framing (\u201CSingle \u2192 single digit, Double \u2192 double/jodi\u201D) but means a label cannot be used to force a short number into a different store \u2014 behaviour to keep in mind when reviewing the findings."),
  h2("3.1 Verified Dictionary Gaps"),
  body("The following probe results are the heart of finding F3. Each lookup was executed against the live term-registry; the parse outcome was executed against the live parser."),
  caption("Table 3-2: Labels with no built-in entry \u2014 verified outcomes"),
  tbl(
    ["Pasted label", "lookupTerm result", "What happens to the numbers today"],
    [
      [{ t: "Single - 5,7 = 100", mono: true }, "null", "Entire line held back; \u201Csingle\u201D reported as unknown label"],
      [{ t: "Double - 12,23 = 100", mono: true }, "null", "Held back; \u201Cdouble\u201D unknown"],
      [{ t: "Triple - 128 = 100", mono: true }, "null", "Held back; \u201Ctriple\u201D unknown"],
      [{ t: "SP Motor - 13467 = 100", mono: true }, "null", "Held back; \u201Csp motor\u201D unknown"],
      [{ t: "DP Motor - 128 = 100", mono: true }, "null", "Held back; \u201Cdp motor\u201D unknown"],
      [{ t: "Family Chart - 123 = 100", mono: true }, "null", "Held back; \u201Cfamily chart\u201D unknown"],
      [{ t: "Sangam - 128-370 = 50", mono: true }, "null", "Held back; \u201Csangam\u201D unknown (also \u201CFS\u201D)"],
      [{ t: "20 Chart - 137 = 50", mono: true }, "null (but \u201C50/60/70\u201D exist)", "Worse than held back \u2014 silent mis-route: jodi 20 booked at 50, \u201CChart\u201D and \u201C-\u201D skipped as non-numbers, panna 137 filed into Mix at 50"],
      [{ t: "40 - 137 = 50", mono: true }, "null (numeric \u201C50/60/70\u201D exist, \u201C40\u201D does not)", "Silent mis-route: jodi 40 booked at 50; 137 into Mix"],
    ],
    [24, 22, 54]
  ),
  body("Two properties make these gaps dangerous. First, the held-back cases are safe but lossy \u2014 real money lines vanish from the day\u2019s totals until someone notices the skipped list. Second, and worse, the 20/30/40 cases do not hold back: the leading number is two digits, so it is booked as a jodi, and the rest of the line is parsed as unlabeled content. The parse result shows no unknown labels at all, so nothing prompts an administrator to teach the term. Of the twenty-two group options the parser can route to, six (SP Motor, DP Motor, 20 Chart, 30 Chart, 40 Chart, Family Chart) have no built-in spelling, and the numeric aliases that exist for 50/60/70 are absent for 20/30/40 even though those charts are structurally identical."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 4 — Parsing Pipeline
// ════════════════════════════════════════════════════════════════════════════
const ch4 = [
  h1("4. Parsing Pipeline Step by Step"),
  body("parseUnifiedEntry(text, defaultRate, customTerms) processes the input line by line and returns one result object with six routing buckets (singles, doubles, triples/mix, common, groups, skipped) plus the recognizedLabels and unknownLabels lists. The steps below describe exactly what happens to each line; all behaviours cited are verified."),
  numbered("pipe-steps", [run("Line splitting. "), run("The text is split on newlines; blank lines are ignored. Section state persists across lines \u2014 a bare header line such as \u201CMotor -\u201D keeps routing all following content lines until the next recognised header.")]),
  numbered("pipe-steps", [run("Label detection, in four ordered strategies. "), run("(a) Bare header line: the whole line is words with one optional trailing separator; if it resolves in the dictionary it becomes the active section (\u201CMotor -\u201D, \u201CCommon:\u201D). (b) Longest-prefix known label: up to the first four words are tried as a label; the remainder must start with a separator or a digit (\u201CSP - 1,2,5 = 100\u201D, \u201CSingle Panna 12=50\u201D). Purely numeric chart labels (\u201C50\u201D, \u201C60\u201D, \u201C70\u201D) additionally require an explicit dash or colon, so \u201C50,60,70 = 100\u201D stays a doubles line \u2014 verified. (c) Explicit-separator unknown label: \u201CHalffix - 12=50\u201D \u2014 the label is reported as unknown and the content is held back, never mis-filed. (d) Otherwise the line is plain content in the current section.")]),
  numbered("pipe-steps", [run("Held-back safety. "), run("When an unknown header is seen, the active section is cleared and every following content line is recorded in the skipped list with the reason \u201Cheld back: unknown label\u201D until a recognised header appears. Money under an unrecognised heading is therefore visible in the skipped list instead of entering the previous section\u2019s totals.")]),
  numbered("pipe-steps", [run("Amount extraction. "), run("The line is split into a left side (numbers) and an amount using the styles of Table 2-1; a missing amount takes the default rate; an explicit amount of zero or less is rejected as invalid \u2014 verified (\u201C5 = 0\u201D is skipped with reason \u201Cinvalid amount\u201D).")]),
  numbered("pipe-steps", [run("Tokenisation. "), run("The left side is split on spaces, commas and slashes into individual number tokens. Non-numeric tokens are skipped with a reason (this is how \u201CChart\u201D and \u201C-\u201D leak out of a mis-routed \u201C20 Chart\u201D line).")]),
  numbered("pipe-steps", [run("Routing. "), run("Each token is routed by digit length and label as described in Chapter 5. Tokens of four or more digits are meaningful only as group seeds; outside a group label they are skipped as invalid digit length.")]),
  body("One limitation is worth stating explicitly because it shapes operator habits: only the first label on a line is recognised. A line such as \u201CSP - 1,2 DP - 12,23 = 50\u201D books 1 and 2 as singles; the token \u201CDP\u201D is skipped as a non-number and 12, 23 are booked as doubles \u2014 all at the same amount of 50 (verified). One entry per line, one label per line, remains the safe format."),
  body("After the last line, the parser materialises group results in the fixed GROUP_OPTION_ORDER, merging duplicates by summing amounts (Chapter 5.3) and attaching the originating seeds for the audit trail. The submit chain of Chapter 7 then consumes this result object."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 5 — Routing & Calculation Rules
// ════════════════════════════════════════════════════════════════════════════
const ch5 = [
  h1("5. Routing and Calculation Rules per Game"),
  h2("5.1 Digit-Length Routing"),
  body("The first routing decision is always the token\u2019s digit length, verified against the live parser. Labels modulate the outcome only from three digits upward."),
  caption("Table 5-1: Digit-length routing (verified)"),
  tbl(
    ["Token length", "Label present?", "Destination"],
    [
      ["1 digit", "ignored", "Single store (number 0-9, leading zeros stripped)"],
      ["2 digits", "ignored", "Double (Jodi) store (leading zeros stripped \u2014 finding F2)"],
      ["3 digits", "common", "Triple Common"],
      ["3 digits", "mix or none", "Triple Mix"],
      ["3 digits", "any group term", "Group seed \u2192 expanded by that option\u2019s expander (5.2)"],
      ["4-10 digits", "any group term", "Group seed \u2192 expanded (Motor / Family / charts)"],
      ["4-10 digits", "none", "Skipped: \u201Cinvalid digit length\u201D"],
      ["over 10 digits", "any", "Skipped: too long (cap is 10 digits)"],
    ],
    [18, 22, 60]
  ),
  h2("5.2 Group Expansion \u2014 the 22 Options"),
  body("Each group option has one expander in the EXPANDER_REGISTRY, shared with the admin panel\u2019s batch input. Every expander returns the generated pannas with the line\u2019s amount attached per panna, or an error string that lands in the skipped list. The table states the rule and the verified counts for each option; counts were produced by executing the expanders, not estimated."),
  caption("Table 5-2: Expansion rules and verified counts per group option"),
  tbl(
    ["Option", "Accepted seed", "Expansion rule (verified)", "Verified counts"],
    [
      ["SP", "3-digit panna", "Validated as an SP panna (all three digits different) and accepted as one panna", "1 panna; 112 rejected (not SP)"],
      ["DP", "3-digit panna", "Validated as DP (exactly two digits the same)", "1 panna; 128 rejected (is SP)"],
      ["TP", "3-digit panna", "Validated as TP (all digits same)", "1 panna; 117 rejected"],
      ["SPDP / SPTP / DPTP / SPDPTP", "3-digit panna", "Classified, accepted if class is in the option\u2019s set", "1 panna (e.g. SPDPTP 128 \u2192 128)"],
      ["Motor Pana", "3-10 digits", [{ t: "All C(n,3) combinations of 3 different digits \u00D7 all 6 orderings each (batch expander). See finding F1: this is 6\u00D7 the admin Group Preview count.", bold: true }], "13467 \u2192 60; 123456 \u2192 120; full 0-9 \u2192 720"],
      ["SP Motor", "3-digit SP panna", "Validated as SP, accepted as one panna (data identical to SP; distinct group label)", "1 panna; 5-digit seed \u2192 rejected"],
      ["DP Motor", "ank 0-9 or 3-digit panna", "Operator\u2019s DP Motor chart: ank \u2192 that ank\u2019s DP family (smallest non-zero digit rule); panna \u2192 accepted if in the chart (digit-set compare)", "ank 1 \u2192 18, ank 9 \u2192 2, ank 0 \u2192 error; chart totals 90"],
      ["20 Chart", "ank 1-4 or 3-digit panna", "First 10 canonical SP pannas per ank for anks 1-2", "10 per covered ank; totals 20"],
      ["30 Chart", "ank 1-9 or 3-digit panna", "Same rule, anks 1-3", "10 per covered ank; totals 30"],
      ["40 Chart", "ank or 3-digit panna", "Same rule, anks 1-4", "10 per covered ank; totals 40"],
      ["50 Chart", "ank or 3-digit panna", "Chart lookup: 5 pannas per ank, all 10 anks", "5 \u00D7 10 = 50"],
      ["60 Chart", "ank or 3-digit panna", "6 pannas per ank", "60"],
      ["70 Chart", "ank or 3-digit panna", "7 pannas per ank", "70"],
      ["90 DP Chart", "ank or 3-digit panna", "9 DP pannas per ank", "90"],
      ["90 ABR Chart", "ank or 3-digit panna", "9 SP pannas per ank", "90"],
      ["Family Set 4 / 6 / 8", "3-digit panna", "Resolves the panna\u2019s family; seeds resolving to an already-seen family are skipped (dedup against double counting)", "4 / 6 / 8 pannas per distinct family; 123 \u2192 Set 8 (8 pannas), rejected in Set 4/6"],
      ["Family Chart", "3-digit panna", "Combined Sets 4+6+8; every panna belongs to exactly one family", "8 pannas for 123 (verified via expander; no dictionary label \u2014 F3)"],
    ],
    [16, 15, 42, 27]
  ),
  body("A consequence of Table 5-1 verified in probing: chart expansion by ank digit is unreachable from Smart Entry today. A single digit under a chart label is routed to the Single store before the label is consulted (\u201C50 Chart - 5 = 100\u201D books single 5), and only a three-digit panna seed reaches the chart lookup (\u201C50 Chart - 137 = 75\u201D correctly books panna 137 at 75). The admin panel\u2019s own group input accepts \u201CAnk5\u201D-style references; Smart Entry does not, because its digit-length rule fires first. If ank-based chart seeding is wanted in Smart Entry, it is a routing-rule change \u2014 noted in the correction plan."),
  h2("5.3 Merging, Deduplication and Caps"),
  body("Group results merge by summing: if two seeds produce the same panna, the panna appears once with the amounts added. This mirrors the long-standing Type-18 aggregation of the classic parser. Verified example: the operator\u2019s standard two-seed Motor message (seeds 134678 and 347890 at 200 and 100) produces 216 unique pannas \u2014 96 at 200, 96 at 100, and the 24 overlapping pannas merged at 300. Family sets additionally deduplicate seeds: entering two pannas of the same family expands only the first and records the second as \u201Cduplicate of family\u201D, because without this the merge-by-sum rule would double every panna in that family."),
  body("The same merge-by-sum does not apply to the singles, doubles, mix and common buckets: there, duplicate numbers stay as separate rows (verified: \u201C5 = 100\u201D and \u201C5 = 200\u201D produce two single rows; \u201C128 = 100\u201D twice produces two mix rows). The inconsistency is finding F4. Hard caps: a maximum of 10 seeds per batch (parseSeedBatch in the group input; the unified parser caps expansion at 5,000 pannas per option as a safety valve against pathological seeds), and seeds longer than 10 digits are rejected."),
  h2("5.4 Triple Grid and Totals"),
  body("Every triple bucket (mix, common, and each group) is additionally organised into the standard 10-column ank grid: a panna\u2019s column is its digit sum modulo 10, with 0 mapping to column 10 (calculateTriplePosition). The grid and per-column totals are stored in the row\u2019s parsedData so the card view can render the classic board without recomputing. The same aggregation drives the live preview\u2019s mini bar charts on the Smart Entry page (singles aggregated over digits 0-9, doubles shown as the top 10 jodis by amount, triples aggregated by ank column)."),
  body("One zero-amount edge must be documented: when a line has no amount and the Default rate field is empty, every number on the line is booked at 0 (verified: \u201C5,3,4\u201D with default 0 produces three rows at amount 0, which then flow into inventory totals as zero). An explicit \u201C5 = 0\u201D is rejected, but the implicit zero via an empty default is not \u2014 finding F5."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 6 — Verified Mismatch Findings
// ════════════════════════════════════════════════════════════════════════════
const ch6 = [
  h1("6. Verified Mismatch Findings (Audit)"),
  body("Every finding below was reproduced against the live parser or expanders on the current build; the evidence column states the exact probe and result. Nothing here is interpretation of screenshots \u2014 where the operator reported a mismatch (the 120-versus-125 motor comparison on the customer application), the same arithmetic family was re-tested here on the Smart Entry side and is recorded as F1."),
  h2("F1 \u2014 Motor expansion books six times the admin panel\u2019s count (critical)"),
  body("Smart Entry\u2019s Motor Pana expander generates, for a seed with n different digits, every three-digit arrangement of those digits: C(n,3) digit combinations times all 6 orderings of each, plus nothing else \u2014 no repeated-digit pannas. The admin panel\u2019s Group Preview for \u201CMotor Pana\u201D (generateGroupPannas in the ERP page) generates each C(n,3) combination once, in ascending spelling. Both were executed for the same seeds:"),
  caption("Table 6-1: Motor arithmetic \u2014 Smart Entry batch expander vs admin Group Preview logic"),
  tbl(
    ["Seed", "Smart Entry (batch expander)", "Admin Group Preview logic", "Factor"],
    [
      [{ t: "13467", mono: true }, "60 pannas (134, 143, 314, 341, 413, 431, \u2026)", "10 pannas (134, 136, 137, 146, 147, 167, 346, 347, 367, 467)", "6\u00D7"],
      [{ t: "123456", mono: true }, "120 pannas", "20 pannas", "6\u00D7"],
      [{ t: "0123456789", mono: true }, "720 pannas, spellings 0-first (012, 021, 102, \u2026)", "120 pannas \u2014 the full single-panna universe", "6\u00D7"],
    ],
    [16, 34, 34, 16]
  ),
  body("Impact: a pasted line \u201CMotor - 13467 = 200\u201D books 200 on each of 60 rows \u2014 a committed exposure of 12,000 \u2014 while the operator\u2019s intended motor (10 pannas, as the admin preview calculates) commits 2,000. Every ordering of the same panna receives the full amount, and because settlement treats 134, 143 and 314 as the same digit set, the same result pays six times over. This is the same 6\u00D7 family of discrepancy the operator already flagged on the customer application (fixed there on 2026-09-30 by adopting the admin preview\u2019s C(n,3) calculation); Smart Entry still runs the old arrangement logic. The batch expander\u2019s 0-first spellings (012, 021) also disagree with the canonical 0-last representation used elsewhere (finding F2)."),
  h2("F2 \u2014 Leading-zero corruption and inconsistent representation"),
  body("The unified parser strips leading zeros from one- and two-digit tokens before storing them (normalizeNumber), and the same strip applies to three-digit mix/common tokens: \u201C012\u201D is stored as \u201C12\u201D, \u201C038\u201D as \u201C38\u201D, \u201C007\u201D as \u201C7\u201D (verified). Consequences: the jodi 07 becomes the single-store-looking number 7 inside the double bucket; the panna 012 loses its three-digit shape entirely, corrupting display, the ank grid (digit sum of \u201C12\u201D is 3, the panna\u2019s ank is 3 only by coincidence of the dropped zero contributing nothing), and any settlement reference. Meanwhile the group path stores expander output verbatim, so a full-digit motor produces 0-first spellings (012, 021) in group rows while the mix path would store 12 for the same pasted panna. Three representations of one concept coexist: 012, 12, and the system-wide canonical 120 (digits ascending, zero last, adopted on 2026-09). The correction should unify on the canonical representation and preserve jodis with leading zeros exactly as written (07 stays 07 \u2014 jodis 07 and 70 are different numbers)."),
  h2("F3 \u2014 Dictionary gaps: held-back money and silent mis-routes"),
  body("Fully documented in Table 3-2: the bare words \u201CSingle\u201D, \u201CDouble\u201D, \u201CTriple\u201D, \u201CSangam\u201D/\u201CFS\u201D, \u201CSP Motor\u201D, \u201CDP Motor\u201D, \u201CFamily Chart\u201D and the 20/30/40 chart labels (word and numeric forms) are not in the built-in dictionary. The held-back cases are visible in the skipped list but leave the day short. The 20/30/40 cases are silent mis-routes: the two-digit leading number books as a jodi and the rest of the line files as unlabeled mix, with no unknown-label report to trigger teaching. Six of the twenty-two routable group options have no spelling an operator can actually type."),
  h2("F4 \u2014 Inconsistent duplicate semantics"),
  body("Singles, doubles, mix and common keep duplicate numbers as separate rows; groups merge duplicates by summing (both verified, Section 5.3). Depending on which surface totals are read from, the same pasted text can therefore present different totals: the Smart Entry grand total sums both duplicate rows, while any group view sums. If merge-by-sum is the intended business rule everywhere (as it is for groups and for the classic Type-18 aggregation), the four non-group buckets should merge the same way; if keeping duplicates is intended for audit, the rule should be stated and made visible. Either way the current split-brain behaviour is a mismatch source when reconciling against the operator\u2019s paper totals."),
  h2("F5 \u2014 Zero-amount rows via an empty default rate"),
  body("A line with no amount and an empty Default rate field books every number at 0 (verified). The rows flow through to the inventories and count toward entry counts while committing nothing \u2014 invisible noise in the day\u2019s data, and a reconciliation trap. An explicit \u201C5 = 0\u201D is correctly rejected; the implicit path should behave the same (or the default rate should be mandatory before submit)."),
  h2("F6 \u2014 Strict class validation under SP/DP/TP labels skips pannas"),
  body("Under a group label, a three-digit token is validated strictly against that option\u2019s panna class and skipped with a clear reason when the class does not match: \u201CSP - 112\u201D (a double) is skipped; \u201CJodi - 128\u201D (a single) is skipped; \u201CTP - 111,117\u201D books 111 and skips 117 (verified). This is safe by design \u2014 nothing is mis-filed \u2014 but it is lossy when a player\u2019s line mixes classes under one label. The skipped rows are visible in the UI list; the correction decision required is whether wrong-class pannas under a panna-class label should re-route to their natural bucket (mix) instead of skipping. No change is proposed without the operator\u2019s ruling."),
  h2("F7 \u2014 One label per line"),
  body("Only the first label of a line is recognised; a second label mid-line degrades to content tokens (verified, Section 4). This is a documented limitation rather than a defect, but it belongs in the working agreement with operators: one entry per line, one label per line. The parser could alternatively split on mid-line label patterns; that is a candidate only if the operator\u2019s chat data frequently contains such lines."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 7 — Submit Chain
// ════════════════════════════════════════════════════════════════════════════
const ch7 = [
  h1("7. Submit Chain and Data Storage"),
  body("Submit All runs a fixed sequence of API calls; the order is contractual because the last step re-sums the parent inventory\u2019s totals. The full chain, as implemented in UnifiedEntryPage.handleSubmit and the two inventory APIs:"),
  numbered("submit-steps", [run("Create or reuse the parent Inventory. "), run("POST /api/inventories with date, time, inventory code and creator. A 409 response (same code + date + time already exists) is resolved to the existing inventory id and reused, with a fallback search by code name.")]),
  numbered("submit-steps", [run("Triple Mix first. "), run("POST /api/triple-inventories with type = mix, carrying the raw input text (truncated at 30,000 characters) in details and a parsedData JSON with the entries, the ank grid and the column totals.")]),
  numbered("submit-steps", [run("Triple Common. "), run("Same API, type = common, with generatedPannas, numbers, grid and totals.")]),
  numbered("submit-steps", [run("Triple Group, one row per option. "), run("For every recognised group option (in fixed order): type = group with the option name, the originating seeds, the expanded pannas, grid and totals in parsedData. The details line records seeds, panna count and total for the audit trail.")]),
  numbered("submit-steps", [run("Single. "), run("POST /api/double-single-inventories with type = single and the numbers array.")]),
  numbered("submit-steps", [run("Double last. "), run("Same API, type = double; its handler then re-reads every triple and double-single row of the inventory and writes their summed totalAmount into the parent Inventory (totalAmount and totalTxn). This is why the double post must be the last write.")]),
  body("Held-back lines are not submitted: the result summary counts them (\u201CN line(s) were held back \u2014 they were NOT submitted\u201D) and unknown labels are additionally recorded as Parser Exceptions (non-fatal; failures are swallowed). The parent inventory\u2019s total is recomputed server-side on every triple and double-single write, so the stored grand total reflects the rows actually persisted. Each write also produces an audit-log entry (action create, entity triple_inventory or double_single_inventory) with the market and amount metadata. After a successful submit the operator can jump to the saved card via View Saved Card."),
  caption("Table 7-1: parsedData shapes written per row type"),
  tbl(
    ["Row type", "parsedData contents"],
    [
      ["Triple \u2014 mix", "entries (number, price, rate 0, skipped flag), totalEntriesCount, grid, totals, skipped lists, droppedTokens; details = raw input text"],
      ["Triple \u2014 common", "series, generatedPannas, numbers, grid, totals, batchInput (raw text)"],
      ["Triple \u2014 group", "seriesCards, select, groupType (option name), generatedPannas, numbers, grid, totals, seeds, inputContent"],
      ["Double-single \u2014 single/double", "numbers (number, price); details = \u201CCard: \u2026 Single:\u201D / \u201CCard: \u2026 Double:\u201D"],
    ],
    [30, 70]
  ),
  body("Rate conventions: Smart Entry posts rate = 0 on every row and embeds the money in each number\u2019s price; the default-rate field exists only at parse time. This differs from some classic rows where a per-unit rate times count convention is used, and is worth remembering when comparing Smart Entry cards with New Entry cards."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 8 — Data Model
// ════════════════════════════════════════════════════════════════════════════
const ch8 = [
  h1("8. Data Model and Evolution Storage"),
  body("Smart Entry writes into the same tables the rest of the ERP reads; nothing is stored in a side-chain. The tables involved, and the role each plays:"),
  caption("Table 8-1: Tables behind Smart Entry"),
  tbl(
    ["Table", "Role for Smart Entry"],
    [
      ["Inventory", "The parent card for one market + date + time; totalAmount and totalTxn are re-summed server-side after every child write"],
      ["TripleInventory", "type = mix | common | group rows; details carries the raw text; parsedData carries entries, grid, totals, seeds"],
      ["DoubleSingleInventory", "type = single | double rows; the double write re-sums the parent"],
      ["InventoryCode", "The market list offered in the Entry Details form"],
      ["Vendor", "Optional customer attribution on every child row"],
      ["ParserTerm", "Manually taught terms: unique normalised term, canonical category, note, isActive, isBuiltin; custom terms win over built-ins at lookup"],
      ["ParserException", "Auto-evolution feed: originalText (first 5,000 characters), the unknown labels as droppedTokens, market and uploader"],
    ],
    [24, 76]
  ),
  body("The evolution loop closes as follows: an unrecognised label holds its content back and is reported in the UI; on submit it is recorded as a Parser Exception; an administrator opens Parser Config (or clicks Teach directly on the Smart Entry page), maps the term to a canonical category, and the term is stored in ParserTerm. From the next parse onward \u2014 including the live preview, without a reload \u2014 the term routes natively. Built-in terms can be overridden the same way, since custom terms are consulted first. Corrections to the dictionary during the correction phase should follow this same path: extend the built-in list for the operator\u2019s standard vocabulary (F3), and leave ParserTerm for house spellings that vary by team."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 9 — Regression & Verification
// ════════════════════════════════════════════════════════════════════════════
const ch9 = [
  h1("9. Regression and Verification Inventory"),
  body("Three runnable artefacts back this document. They are the acceptance harness for the correction phase: every proposed fix must keep these green, and new behaviour must be pinned by extending them."),
  bullet([run("scripts/test-entry-parser.ts", { font: MONO, size: 22 }), run(" \u2014 51 checks over the unified parser and the dictionary: the operator\u2019s canonical message (216 merged motor pannas, 96/96/24 amount split), synonym routing, unlabeled mix, common, unknown-label hold-back, family dedup, chart lookups, numeric-label guards, section persistence, default rate.")]),
  bullet([run("scripts/audit-smart-entry.ts", { font: MONO, size: 22 }), run(" \u2014 the probe written for this document: dictionary lookups for the suspected gap terms, leading-zero behaviour, the silent 20/30/40 mis-route, duplicate semantics, zero-amount edges, motor counts, sangam-style lines, mid-line labels. Re-running it after corrections should show each finding fixed or explicitly accepted.")]),
  bullet([run("scripts/probe-chart-counts.ts", { font: MONO, size: 22 }), run(" + "), run("scripts/probe-expanders.ts", { font: MONO, size: 22 }), run(" \u2014 per-ank counts for all eight cut charts and the motor/family expanders, producing the verified numbers of Table 5-2.")]),
  body("All three run in seconds with the bun runtime (Appendix C gives the commands). The parser modules are pure and need no database or server; only the customer-facing parts of the ERP need a dev server restart after library changes. The engine-level regression suite (scripts/test-games-engine.ts, 104 checks) covers the customer application\u2019s expansions, including the 2026-09-30 motor parity fix, and should be watched whenever the shared expander registry is touched, because Smart Entry and the customer app draw on the same registry for DP Motor and the family sets."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 10 — Correction Plan
// ════════════════════════════════════════════════════════════════════════════
const ch10 = [
  h1("10. Proposed Correction Plan (for Sign-off)"),
  body("The plan below maps each finding to a proposed correction. It is a proposal only \u2014 nothing has been implemented \u2014 and items P2, P4 and P6 change business-visible behaviour, so they need the operator\u2019s explicit ruling on the intended rule before code is written. The guiding constraints are unchanged: extend, do not rebuild; one source of truth per rule; the customer application\u2019s existing motor parity (C(n,3) single-spelling pannas, as fixed on 2026-09-30) is the reference behaviour; and the voice dictation module stays untouched."),
  caption("Table 10-1: Correction backlog with priority and expected behaviour change"),
  tbl(
    ["Pri", "Finding", "Proposed correction", "Behaviour after correction"],
    [
      ["P1", "F1", "Align the Smart Entry Motor expander with the admin Group Preview: C(n,3) combinations, one canonical spelling each, shared with the customer app fix", "Motor 13467 \u2192 10 pannas (not 60); full digit set \u2192 120 (not 720); exposure matches the operator\u2019s paper calculation"],
      ["P2", "F2", "Adopt the canonical representation in the unified parser (digits ascending, zero last for pannas; jodis preserved exactly as written, 07 stays 07)", "012 \u2192 120 everywhere; no more 2-digit panna ghosts; group rows and mix rows spell the same panna identically"],
      ["P3", "F3", "Extend BUILT_IN_TERMS: single, double, triple, sp motor, dp motor, 20/30/40 chart + numeric 20/30/40, family chart; decide Sangam handling (pair format X-PPP) as a new routing rule or explicit hold-back message", "\u201CSingle - 5,7\u201D books singles; \u201CSP Motor\u201D routes; \u201C20 Chart - 137\u201D expands the chart instead of booking jodi 20"],
      ["P4", "F4", "Unify duplicate semantics \u2014 merge-by-sum in all five buckets (operator to confirm), keeping per-line audit in the raw text already stored in details", "One total per number across every view; reconciliation matches paper"],
      ["P5", "F5", "Treat an empty default rate as invalid input for amount-less lines (same rejection as an explicit 0), or make the default rate mandatory before submit", "No zero-amount rows reach the inventories"],
      ["P6", "F6", "Operator ruling: keep strict class skips, or re-route wrong-class pannas to Mix under panna-class labels", "Either a clearly stated skip rule or no lossy skips"],
      ["P7", "F7", "Document one-label-per-line as the working agreement; no parser change unless chat data demands it", "Clear operator expectations; behaviour unchanged"],
    ],
    [8, 10, 46, 36]
  ),
  body("Sequencing recommendation: P3 and P5 are low-risk parser/dictionary edits with immediate operator relief; P1 is the financially significant one and should land with its regression suite extended (motor counts 10/20/120 per Table 6-1); P2 touches stored representations and is therefore best done together with P1 so both land in one regression pass; P4 and P6 change reconciliation behaviour and wait for the operator\u2019s ruling. Out of scope for all items: the speech-dictation module and DictationFormatButton, which remain exactly as delivered."),
];

// ════════════════════════════════════════════════════════════════════════════
// APPENDICES
// ════════════════════════════════════════════════════════════════════════════
const appendices = [
  h1("Appendix A: Built-in Dictionary (Complete)"),
  body("The 95 built-in spellings of term-registry.ts, grouped by canonical category (category: number of spellings \u2014 the spellings). The six group options with no spelling at all are listed at the end; they are reachable only after being taught via ParserTerm."),
  caption("Table A-1: BUILT_IN_TERMS grouped by canonical category"),
  tbl(
    ["Category", "Count", "Spellings (normalised)"],
    [
      ["SP", "11", "sp, s p, single panna, singal panna, single patti, sp panna, sp patti, ank panna, ak panna, ank patti, ank"],
      ["DP", "17", "dp, d p, double panna, double pannta, duble panna, double patti, dp panna, dp patti, jodi, jody, jodi panna, jodi patti, joti, joty, jote, double ank, double ak"],
      ["TP", "8", "tp, t p, triple panna, tripple panna, triple patti, tp panna, tp patti, triple ank"],
      ["SPDP", "2", "spdp, sp dp"],
      ["SPTP", "2", "sptp, sp tp"],
      ["DPTP", "2", "dptp, dp tp"],
      ["SPDPTP", "3", "spdptp, sp dp tp, spdpmo"],
      ["Motor Pana", "11", "motor, motar, motor pana, motor panna, motor patti, motar panna, motar patti, cycle, cycle panna, cycle patti, motor cycle"],
      ["50 Chart", "3", "50 chart, 50, fifty chart"],
      ["60 Chart", "3", "60 chart, 60, sixty chart"],
      ["70 Chart", "3", "70 chart, 70, seventy chart"],
      ["90 DP Chart", "3", "90 dp chart, 90 dp, ninety dp"],
      ["90 ABR Chart", "4", "90 abr chart, 90 abr, abr chart, abr"],
      ["Family Set 4", "4", "family set 4, family set4, family 4, fs4"],
      ["Family Set 6", "4", "family set 6, family set6, family 6, fs6"],
      ["Family Set 8", "5", "family set 8, family set8, family 8, fs8, family set"],
      ["mix", "5", "mix, mix panna, mixed, normal, direct"],
      ["common", "5", "common, coman, comon, common panna, common patti"],
      ["(no alias)", "0", "SP Motor, DP Motor, 20 Chart, 30 Chart, 40 Chart, Family Chart \u2014 six group options with no built-in spelling (finding F3)"],
    ],
    [16, 8, 76]
  ),
  h1("Appendix B: Worked Examples (Verified Output)"),
  h2("B.1 The Operator\u2019s Canonical Message"),
  body([monoRun("SP - 1,2,5,6,7 = 100 rs"), run("  \u2192  five singles (1, 2, 5, 6, 7) at 100 each.")]),
  body([monoRun("DP - 12,23,47,35,18 = 50 rs"), run("  \u2192  five doubles at 50 each.")]),
  body([monoRun("Motor -"), run("  (header) then "), monoRun("134678 = 200rs"), run(" and "), monoRun("347890 = 100 rs"), run("  \u2192  Motor Pana group, 216 unique pannas: 96 at 200, 96 at 100, 24 overlapping pannas merged at 300. Under correction P1 the same message yields the C(n,3) panna set per seed instead (20 per 6-digit seed), merged the same way.")]),
  h2("B.2 Synonym Variants Route Identically"),
  body([monoRun("Single Panna - 1,2,5 = 100"), run(", "), monoRun("Jodi - 12,23 = 50"), run(", "), monoRun("Motar Panna"), run(" + "), monoRun("134678 = 200"), run("  \u2192  three singles at 100, two doubles at 50, Motor group of 120 pannas at 200 (today\u2019s expander; 20 under P1). Misspellings singal, motar, jody, tripple, coman all resolve by design.")]),
  h2("B.3 Unlabeled, Common and Held-Back Lines"),
  body([monoRun("128,234,341=50"), run("  \u2192  Mix, three pannas at 50.  "), monoRun("common - 111,117=25"), run("  \u2192  Common, two pannas at 25.  "), monoRun("SP - 128=100"), run("  \u2192  SP group, panna 128 at 100.  "), monoRun("badseed - 111=10"), run("  \u2192  unknown label \u201Cbadseed\u201D: the panna 111 is held back and the label is reported for teaching \u2014 nothing enters the day\u2019s totals.")]),
  h2("B.4 The Silent 20-Chart Mis-Route (finding F3)"),
  body([monoRun("20 Chart - 137 = 50"), run("  \u2192  today: doubles receive "), monoRun("20"), run(" at 50; the tokens \u201CChart\u201D and \u201C-\u201D are skipped as non-numbers; panna "), monoRun("137"), run(" files into Mix at 50; no unknown label is reported. After P3: the 20 Chart group receives the chart\u2019s 10 pannas for the seed reference instead. Contrast "), monoRun("50 Chart - 137 = 75"), run(", which already works (50 Chart is in the dictionary) and books panna 137 in the 50 Chart group at 75.")]),
  h1("Appendix C: Running the Verification Suites"),
  body("All suites are quick and database-free. From the project root:"),
  body([monoRun("bun scripts/test-entry-parser.ts      # 51 parser + dictionary checks"), ], {}),
  body([monoRun("bun scripts/audit-smart-entry.ts     # the audit probe behind Chapters 3 and 6"), ], {}),
  body([monoRun("bun scripts/probe-chart-counts.ts    # per-ank chart counts"), ], {}),
  body([monoRun("bun scripts/probe-expanders.ts       # expander counts incl. motor / DP motor / family"), ], {}),
  body([monoRun("bun scripts/test-games-engine.ts     # 104 checks incl. the customer-app motor parity fix"), ], {}),
  body("Expected state at the time of writing: 51/51 parser checks pass, 104/104 engine checks pass, and the audit probe reproduces every finding of Chapter 6. After each correction lands, the corresponding probe section should flip to the corrected behaviour and the extended assertions should be added to the test suites so the fix is pinned. Remember that library-level changes require a dev server restart before the Smart Entry page picks them up in the browser."),
];

// ════════════════════════════════════════════════════════════════════════════
// ASSEMBLY — 3 sections (cover / front matter Roman / body Arabic)
// ════════════════════════════════════════════════════════════════════════════
const numberingConfig = ["pipe-steps", "submit-steps"].map(ref => ({
  reference: ref,
  levels: [{
    level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 } } },
  }],
}));

const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: FONTS, size: 24, color: P.body },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FONTS, size: 32, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 360, after: 180, line: 380 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FONTS, size: 30, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 260, after: 130, line: 360 }, outlineLevel: 1 },
      },
    },
  },
  numbering: { config: numberingConfig },
  sections: [
    { // Section 1: Cover — margin 0, no footer/header
      properties: {
        page: { size: { width: 11906, height: 16838 }, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1({
        title: "Smart Entry Working Document",
        subtitle: "Functional reference and verified calculation baseline for the correction phase \u2014 WhatsApp paste, voice dictation and manual input through parse, calculate and route",
        englishLabel: "ERP FUNCTIONAL REFERENCE",
        metaLines: [
          "Module: Smart Entry (unified-entry) \u2014 ERP admin panel",
          "Covers: dictionary, parser, 22 group options, submit chain, data model",
          "Evidence: live parser and expander probes on the current build",
          "Status: baseline for correction \u2014 no code changed",
          "Date: 30 September 2026",
        ],
        footerLeft: "Master-Sanpag ERP",
        footerRight: "Prepared for operator review",
        palette: { bg: P.bg, accent: P.accent, ...P.cover },
      }),
    },
    { // Section 2: Front matter — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN },
        },
      },
      headers: { default: pageHeader() },
      footers: { default: pageNumFooter() },
      children: frontMatter,
    },
    { // Section 3: Body — Arabic from 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: { default: pageHeader() },
      footers: { default: pageNumFooter() },
      children: [...ch1, ...ch2, ...ch3, ...ch4, ...ch5, ...ch6, ...ch7, ...ch8, ...ch9, ...ch10, ...appendices],
    },
  ],
});

const OUT = "/home/z/my-project/download/Smart_Entry_Working_Document_2026-09-30.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("WROTE", OUT, buf.length, "bytes");
});
