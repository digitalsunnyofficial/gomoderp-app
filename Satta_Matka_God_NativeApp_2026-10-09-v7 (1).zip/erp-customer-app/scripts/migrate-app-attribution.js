// One-time migration: legacy mirrored app rows were attributed to the super
// account (data-isolation requirement) with the real customer name only in
// the details text ("Customer App · <name> (<mobile>) · ..."). Rewrite
// createdBy on those rows to the actual app customer name so the ERP Entry
// List "Submitted By" shows who placed the bets. Idempotent.
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

const NAME_RE = /^Customer App · (.+?) \(\+?\d[\d ]*\)/

async function main() {
  const codes = await db.inventoryCode.findMany({ where: { code: { startsWith: 'app_' } }, select: { id: true } })
  const codeIds = codes.map(c => c.id)
  const cards = await db.inventory.findMany({
    where: { inventoryCodeId: { in: codeIds } },
    include: { tripleInventories: true, doubleSingleInventories: true },
  })
  let cardCount = 0, rowTriples = 0, rowDs = 0, skipped = 0
  for (const card of cards) {
    const m = (card.remark || '').match(NAME_RE)
    // details live on the ROWS; fall back to first row's details
    const rowHint = card.tripleInventories[0]?.details || card.doubleSingleInventories[0]?.details || ''
    const name = (m && m[1]) || (rowHint.match(NAME_RE) || [])[1]
    if (!name) { skipped++; continue }
    if (card.createdBy !== name) {
      await db.inventory.update({ where: { id: card.id }, data: { createdBy: name } })
      cardCount++
    }
    for (const t of card.tripleInventories) {
      if (t.createdBy !== name) { await db.tripleInventory.update({ where: { id: t.id }, data: { createdBy: name } }); rowTriples++ }
    }
    for (const d of card.doubleSingleInventories) {
      if (d.createdBy !== name) { await db.doubleSingleInventory.update({ where: { id: d.id }, data: { createdBy: name } }); rowDs++ }
    }
  }
  console.log(`cards=${cards.length} renamedCards=${cardCount} tripleRows=${rowTriples} dsRows=${rowDs} skippedNoName=${skipped}`)
}

main().finally(() => db.$disconnect())
