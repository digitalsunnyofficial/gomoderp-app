#!/bin/bash
# One-shot re-verify: merp warm-up + commission suite full output + corrected demo-state probe.
set -uo pipefail
cd /home/z/my-project

pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP after ~$((i*2))s"; break; fi
done
[ "$UP" != "1" ] && { echo "FATAL: no server"; tail -20 /tmp/devserver.log; exit 1; }

# warm merp with retries (cold Turbopack compile of the 6k-line page)
for i in 1 2 3 4 5; do
  merp=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/app/merp --max-time 180)
  echo "MERP_PAGE_STATUS attempt $i: $merp"
  [ "$merp" = "200" ] && break
  sleep 3
done

echo "════ agent-commission FULL ════"
timeout 300 bun scripts/test-agent-commission.ts 2>&1 | grep -E "FAIL|RESULT|✗|pass," | tail -10

echo "════ DEMO STATE (agentsanjay) ════"
bun -e '
import { PrismaClient } from "@prisma/client";
const p = new PrismaClient();
const agent = await p.user.findFirst({ where: { username: "agentsanjay" }, select: { username: true, name: true, role: true, commissionRate: true } });
console.log("AGENT:", JSON.stringify(agent));
const custs = await p.appCustomer.findMany({ where: { agentUsername: "agentsanjay" }, select: { name: true, mobile: true, wallet: true, status: true } });
console.log("CUSTOMERS:", custs.length, JSON.stringify(custs));
const custIds = custs.map(c => c.name);
const bets = await p.appBet.findMany({ where: { appCustomer: { name: { in: custIds } } }, select: { appCustomerId: true, points: true } });
const playedByCust = {};
for (const b of bets) { playedByCust[b.appCustomerId] = (playedByCust[b.appCustomerId] || 0) + b.points; }
console.log("PLAYED_TOTAL:", bets.reduce((s,b)=>s+b.points,0), "BY_CUST:", JSON.stringify(playedByCust));
const comm = await p.agentCommission.findMany({ select: { agentUsername: true, customerName: true, baseAmount: true, amount: true, status: true, source: true } });
console.log("COMMISSION_ROWS:", comm.length, "TOTAL_RS:", comm.reduce((s,r)=>s+r.amount,0), "BY_STATUS:", JSON.stringify(comm.reduce((m,r)=>{m[r.status]=(m[r.status]||0)+1;return m},{})));
const funds = await p.appFundRequest.findMany({ select: { appCustomerId: true, amount: true, status: true } });
console.log("FUND_ROWS:", funds.length, JSON.stringify(funds));
await p.$disconnect();
' 2>&1 | grep -v "prisma:query"

pkill -f "next dev -p 3000" 2>/dev/null
echo "════ DONE ════"
