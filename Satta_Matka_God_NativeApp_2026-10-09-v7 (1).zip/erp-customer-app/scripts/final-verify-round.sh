#!/bin/bash
# One-shot final verification round: start server → HTTP regressions → merp check → demo state → cleanup.
set -uo pipefail
cd /home/z/my-project
LOG=/tmp/final-verify.log

echo "════ FINAL VERIFICATION ROUND $(date -u +%FT%TZ) ════"

# 0) make sure nothing stale is on :3000
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1

# 1) start server
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
SERVER_PID=$!
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP (health 200) after ~$((i*2))s"; break; fi
done
if [ "$UP" != "1" ]; then echo "FATAL: server never became healthy"; tail -30 /tmp/devserver.log; exit 1; fi

# 2) merp shell status
merp=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/app/merp --max-time 120)
echo "MERP_PAGE_STATUS: $merp"
health=$(curl -s http://localhost:3000/api/health --max-time 10 | head -c 200)
echo "HEALTH_BODY: $health"

# 3) HTTP-based regression suites
echo "════ agent-commission ════"
timeout 300 bun scripts/test-agent-commission.ts 2>&1 | tail -4
echo "════ agent-access-control ════"
timeout 300 bun scripts/test-agent-access-control.ts 2>&1 | tail -4
echo "════ signup-approval-toggle ════"
timeout 300 bun scripts/test-signup-approval-toggle.ts 2>&1 | tail -4

# 4) demo state check via SQLite (read-only)
echo "════ DEMO STATE (agentsanjay) ════"
bun -e '
import { PrismaClient } from "@prisma/client";
const p = new PrismaClient();
const agent = await p.user.findFirst({ where: { username: "agentsanjay" }, select: { username: true, name: true, role: true, commissionRate: true } });
console.log("AGENT:", JSON.stringify(agent));
const custs = await p.appCustomer.findMany({ where: { agentUsername: "agentsanjay" }, select: { name: true, mobileNumber: true } });
console.log("CUSTOMERS:", custs.length, JSON.stringify(custs));
const cNames = custs.map(c => c.name);
const bets = await p.appBet.groupBy({ by: ["appCustomerId"], _sum: { points: true }, _count: true, where: { appCustomer: { name: { in: cNames } } } });
console.log("PLAY_ROWS:", bets.length, JSON.stringify(bets.map(b => ({ customerId: b.appCustomerId, played: b._sum.points, bets: b._count }))));
const comm = await p.agentCommission.findMany({ select: { agentUsername: true, customerName: true, baseAmount: true, amount: true, status: true, source: true } });
const tot = comm.reduce((s, r) => s + r.amount, 0);
console.log("COMMISSION_ROWS:", comm.length, "TOTAL_RS:", tot, "PENDING:", comm.filter(r => r.status === "pending").length);
await p.$disconnect();
' 2>&1

# 5) cleanup
kill $SERVER_PID 2>/dev/null
pkill -f "next dev -p 3000" 2>/dev/null
sleep 1
echo "════ DONE (server stopped) ════"
