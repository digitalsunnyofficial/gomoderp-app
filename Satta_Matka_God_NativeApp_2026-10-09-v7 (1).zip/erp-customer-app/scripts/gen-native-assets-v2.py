#!/usr/bin/env python3
"""Regenerate the native app brand assets in the WEB CUSTOMER APP's exact
palette (purple #6d28d9 → pink #db2777, gold accents) — replaces the old
dark+gold assets so even the launcher/splash match the approved UI."""
from PIL import Image, ImageDraw, ImageFont
import os

OUT = '/home/z/my-project/satta-matka-god-native/assets'
os.makedirs(OUT, exist_ok=True)

P1 = (109, 40, 217)    # #6d28d9
P2 = (219, 39, 119)    # #db2777
DEEP = (157, 23, 77)   # #9d174d
GOLD = (251, 191, 36)  # #fbbf24

def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def gradient(size, c1, c2, c3, diag=True):
    img = Image.new('RGB', size)
    w, h = size
    px = img.load()
    for y in range(h):
        for x in range(0, w, 2):
            t = (y / h) * 0.65 + (x / w) * 0.35 if diag else y / h
            c = lerp(c1, c2, min(1, t * 1.4)) if t < 0.72 else lerp(c2, c3, (t - 0.72) / 0.28)
            px[x, y] = c
            if x + 1 < w:
                px[x + 1, y] = c
    return img

def gem(draw, cx, cy, s, fill):
    """faceted gem — diamond body + table line + sparkle"""
    # crown + pavilion
    draw.polygon([(cx, cy - s), (cx + s * 0.85, cy - s * 0.25), (cx, cy + s), (cx - s * 0.85, cy - s * 0.25)], fill=fill)
    # facet lines
    ln = tuple(min(255, c + 60) for c in fill)
    draw.line([(cx - s * 0.85, cy - s * 0.25), (cx + s * 0.85, cy - s * 0.25)], fill=ln, width=max(2, int(s * 0.09)))
    draw.line([(cx - s * 0.45, cy - s * 0.25), (cx, cy + s)], fill=ln, width=max(1, int(s * 0.06)))
    draw.line([(cx + s * 0.45, cy - s * 0.25), (cx, cy + s)], fill=ln, width=max(1, int(s * 0.06)))
    # sparkle
    sp = cx + s * 0.55, cy - s * 0.62
    r = s * 0.14
    draw.polygon([(sp[0], sp[1] - r * 2), (sp[0] + r * 0.55, sp[1]), (sp[0], sp[1] + r * 2), (sp[0] - r * 0.55, sp[1])], fill=ln)
    draw.polygon([(sp[0] - r * 2, sp[1]), (sp[0], sp[1] - r * 0.55), (sp[0] + r * 2, sp[1]), (sp[0], sp[1] + r * 0.55)], fill=ln)

# ── icon 1024 (brand gradient bg + white-frosted gem) ──
S = 1024
icon = gradient((S, S), P1, P2, DEEP)
d = ImageDraw.Draw(icon, 'RGBA')
# frosted rounded box
bx = S * 0.5, S * 0.5
bs = S * 0.33
d.rounded_rectangle([bx[0] - bs, bx[1] - bs, bx[0] + bs, bx[1] + bs], radius=int(bs * 0.44), fill=(255, 255, 255, 46))
gem(d, bx[0], bx[1] - S * 0.01, S * 0.17, (255, 255, 255, 255))
icon.save(f'{OUT}/icon.png')

# ── adaptive foreground 1024 (gem centered, safe zone 66%) ──
fg = Image.new('RGBA', (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(fg)
gem(d, S / 2, S / 2, S * 0.21, (255, 255, 255, 255))
fg.save(f'{OUT}/adaptive-icon.png')

# ── splash icon 512 (white gem, transparent bg) ──
sp = Image.new('RGBA', (512, 512), (0, 0, 0, 0))
d = ImageDraw.Draw(sp)
gem(d, 256, 246, 110, (255, 255, 255, 255))
sp.save(f'{OUT}/splash-icon.png')

# ── notification icon 96 (white gem on transparent — Android tints it) ──
ni = Image.new('RGBA', (96, 96), (0, 0, 0, 0))
d = ImageDraw.Draw(ni)
gem(d, 48, 48, 26, (255, 255, 255, 255))
ni.save(f'{OUT}/notification-icon.png')

# ── legacy 192 icon ──
i192 = icon.resize((192, 192), Image.LANCZOS)
i192.save(f'{OUT}/icon-192.png')

print('assets regenerated in brand purple/pink:', os.listdir(OUT))
