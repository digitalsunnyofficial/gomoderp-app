// Task 42: DEFINITIVE live test against the r4 pipeline server (:3100)
// Simulates the exact Hostinger deployment: gold db + self-heal + clean env.
// Covers: incident 1 (app customers list), incident 2 (customer signup/login),
// the APK upload feature end-to-end, landing CTA.
const BASE = process.env.TBASE || 'http://127.0.0.1:3100'
let results: Array<{ n: string; ok: boolean; info?: string }> = []
function check(n: string, ok: boolean, info?: string) {
  results.push({ n, ok, info }); console.log(`${ok ? 'PASS' : 'FAIL'} — ${n}${info ? ' :: ' + info : ''}`)
}
async function call(method: string, path: string, body?: any, cookie?: string) {
  const res = await fetch(BASE + path, {
    method, headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  })
  const text = await res.text()
  let json: any = null; try { json = JSON.parse(text) } catch {}
  return { status: res.status, json, text: text.slice(0, 400), headers: res.headers }
}
function fakeApk(seed: string): Buffer {
  return Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.from(`apk-${seed}-${'z'.repeat(1536)}`)])
}

async function main() {
  // ── INCIDENT 1: ERP login + app customers list ──
  const adm = await call('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  check('ERP super login (was fine)', adm.status === 200)
  const suCookie = (adm.headers.get('set-cookie') || '').split(';')[0]
  const cust = await call('GET', '/api/app-admin/customers?search=', undefined, suCookie)
  check('INCIDENT 1: app customers list 200', cust.status === 200 && Array.isArray(cust.json?.customers), `${cust.status} — ${cust.json?.customers?.length ?? cust.text.slice(0, 80)} customers`)
  check('INCIDENT 1: 11 gold customers intact', cust.json?.customers?.length === 11, String(cust.json?.customers?.length))

  // ── INCIDENT 2: customer signup + login (server-side) ──
  const mob = '9772204299'
  const su = await call('POST', '/api/customer-app/auth/signup', { name: 'Pipeline Probe', mobile: mob, password: 'Probe@123' })
  check('INCIDENT 2: customer signup 200', su.status === 200, JSON.stringify(su.json).slice(0, 100))
  const li = await call('POST', '/api/customer-app/auth/login', { mobile: mob, password: 'Probe@123' })
  check('INCIDENT 2: customer login 200', li.status === 200 && !!li.json?.token, JSON.stringify(li.json).slice(0, 80))
  const demo = await call('POST', '/api/customer-app/auth/login', { mobile: '9876500001', password: 'Demo@123' })
  check('INCIDENT 2: gold demo customer login', demo.status === 200, JSON.stringify(demo.json).slice(0, 60))
  // cleanup probe customer
  const { PrismaClient } = await import('@prisma/client')
  const pdb = new PrismaClient({ datasources: { db: { url: 'file:/home/z/my-project/zipstage-r4-pipeline/db/custom.db' } } })
  await pdb.appCustomer.deleteMany({ where: { mobile: mob } }).catch(() => {})
  await pdb.$disconnect()

  // ── FEATURE: APK upload → serve → replace → landing picks it up ──
  const nf = await call('GET', '/apk/sm-gomod.apk')
  check('FEATURE: 404 before first upload', nf.status === 404)
  const up = await fetch(BASE + '/api/app-admin/apk', { method: 'POST', headers: { cookie: suCookie }, body: (() => { const fd = new FormData(); fd.append('file', new Blob([fakeApk('r4')], { type: 'application/vnd.android.package-archive' }), 'sm-gomod.apk'); fd.append('versionLabel', 'v1.1.0 r4'); return fd })() })
  check('FEATURE: upload 200', up.status === 200, (await up.json().catch(() => ({}))).error)
  const got = await fetch(BASE + '/apk/sm-gomod.apk')
  const bytes = Buffer.from(await got.arrayBuffer())
  check('FEATURE: served bytes identical', got.status === 200 && bytes.equals(fakeApk('r4')), `${got.status} ${bytes.length}B`)
  check('FEATURE: apk content-type', got.headers.get('content-type') === 'application/vnd.android.package-archive')
  const head = await fetch(BASE + '/apk/sm-gomod.apk', { method: 'HEAD' })
  check('FEATURE: HEAD probe 200', head.status === 200)
  const md = await call('GET', '/api/app-admin/apk', undefined, suCookie)
  check('FEATURE: metadata reflects upload', md.json?.hasApk === true && md.json?.apk?.fileName === 'sm-gomod.apk', JSON.stringify(md.json?.apk).slice(0, 120))

  // landing pages
  const landing = await (await fetch(BASE + '/')).text()
  const cap = await (await fetch(BASE + '/customerapp')).text()
  check('FEATURE: landing CTA canonical path', landing.includes('/apk/sm-gomod.apk'))
  check('FEATURE: customerapp CTA canonical path', cap.includes('/apk/sm-gomod.apk'))

  // gold ERP pages
  for (const r of ['/merp', '/api/health']) {
    const s = await fetch(BASE + r)
    check(`gold route ${r}`, s.status === 200, String(s.status))
  }
  // apk metadata for agents still 403
  const { execSync } = await import('child_process')

  const fails = results.filter(r => !r.ok)
  console.log(`\n══ ${results.length - fails.length}/${results.length} checks passed against pipeline server ══`)
  if (fails.length) process.exit(1)
}
main().catch(e => { console.error('FATAL', e); process.exit(1) })
