// guide-content-a.js — chapters 1–4 of the Deployment & Operations Guide.
const { h1, h2, h3, p, pMono, bullet, tblTitle, tbl } = require("./guide-helpers");

function chaptersA() {
  const out = [];

  // ══ 1. EXECUTIVE SUMMARY ══
  out.push(h1("1. Executive Summary"));
  out.push(p(["This guide is the single operating manual for taking the Satta Matka God system from the development workspace to production on the domain ", ["https://godmoderp.online/", true], ". It answers the four operator requests in order: how to sync the local VS Code project with the delivered zip package, how to host the complete system (web and app together) on Hostinger, how the native Android app's notifications are managed from the master admin panel, and how the public landing page now teaches customers to use the app with real screenshots of every screen."]));
  out.push(p(["The system is one Next.js deployment with one database. The same server process serves the public landing page, the master admin ERP at /merp, the web customer app at /app, the official APK download page at /customerapp, and every API the native Android app consumes. The Android app itself is a true native Expo/React Native build — it is not hosted anywhere; it is compiled once into an APK, published to the download page, and installed on customers' phones, from where it talks to the same domain over HTTPS with Bearer-token sessions. Hosting therefore means hosting one Node.js server well, not hosting two systems."]));
  out.push(p(["All procedures in this guide reflect the current state of the delivered workspace: the native app is the v3 UI-parity build (every screen a faithful conversion of the web customer app), the master admin notification composer is implemented and verified with 21 automated checks, and the full verification battery — a 29-check live end-to-end journey plus ten regression suites — totals 563 passing checks with zero failures. Where a value must be decided at deploy time (passwords, secrets, database location), the guide marks it explicitly rather than inventing one."]));

  // ══ 2. SYSTEM OVERVIEW ══
  out.push(h1("2. System Overview and Hosting Architecture"));
  out.push(h1("2.1 What Runs Where"));
  out.push(p(["Everything a customer or operator touches is produced by one Node.js process running the Next.js application from the erp-customer-app folder (in the delivered zip; in the workspace it is the project root). The process reads a single SQLite database file through Prisma, so an approval made in the ERP, a bid placed from the native app, and a balance shown on the web app are always the same data. The table below maps every user-facing URL to its role, which doubles as the post-deployment smoke-test list."]));
  out.push(tblTitle("Table 1: One domain, one deployment — every route and its purpose"));
  out.push(tbl(
    ["URL", "What it serves", "Who uses it"],
    [
      ["/", "Landing page: APK download, 5-step guide, screenshot gallery of every app screen", "Prospective + existing customers"],
      ["/merp", "Master admin ERP: markets, games, results, wallets, commissions, notifications", "Operator / master admin"],
      ["/app", "Web customer app (the UI source of truth for the native app)", "Customers on any browser"],
      ["/customerapp", "Official APK download page with 3-step install guide", "Customers on Android phones"],
      ["/api/customer-app/*", "Mobile API: auth, markets, bids, wallet, funds, results, notifications, push", "Native Android app"],
      ["/api/app-admin/*", "ERP management APIs (cookie session, role-guarded)", "ERP pages"],
      ["/how-it-works/*.png", "19 real app screenshots shown on the landing page", "Landing page visitors"],
      ["/downloads/satta-matka-god.apk", "The published Android APK file", "Downloaded by customers"],
    ],
    [24, 46, 30]
  ));
  out.push(p(["The native Android app is distributed, not hosted. It is built with Expo/React Native into a signed APK, copied into the backend's public/downloads folder, and served by the same server. After installation the app knows exactly one address — the production domain configured at build time — and every request carries the customer's own Bearer token, so there is no app-side session infrastructure to host or scale separately."]));
  out.push(h1("2.2 The Hosting Consequence"));
  out.push(p(["Because one process serves everything, the Hostinger requirement is a Virtual Private Server (VPS) plan with Node.js — for example the KVM 1 plan or higher running Ubuntu 24.04. Hostinger's shared and WordPress plans only execute PHP under LiteSpeed and cannot run this application; no amount of configuration changes that. One VPS, one domain with SSL, and one PM2 process are the entire hosting footprint, and the same deployment serves both the web experience and the installed app population."]));

  // ══ 3. PART A — VS CODE SYNC ══
  out.push(h1("3. Part A — Updating the VS Code Project from the Zip"));
  out.push(h1("3.1 What the Delivered Zip Contains"));
  out.push(p(["The package (Satta_Matka_God_NativeApp_…-v3.zip in the delivered workspace; v4 carries the same structure plus the new notification feature) contains two sibling folders and three guide files. The v3 build is the UI-parity build: every screen inside satta-matka-god-native is a faithful React Native conversion of the web customer app — same purple/pink gradients, white cards, gold actions, bottom navigation, language flow, market cards, play engine, charts, wallet and modals. Replacing your local screens with this zip is therefore exactly the UI-parity fix; nothing inside it needs re-designing afterwards."]));
  out.push(tblTitle("Table 2: Zip contents and their roles"));
  out.push(tbl(
    ["Item", "Role"],
    [
      ["erp-customer-app/", "The full Next.js system: landing, ERP, web customer app, every API, Prisma schema, seed database, scripts"],
      ["satta-matka-god-native/", "The Expo/React Native Android app (13 screens, web-exact UI, engines copied verbatim from src/lib/matka)"],
      ["README-FIRST.txt", "One-page orientation: what v3 is, how to run the backend and the app, where the APK guide lives"],
      ["SETUP_NATIVE_APP.md", "The APK manual: prerequisites, apiBase configuration, Firebase push setup, debug and release builds, publishing"],
      ["UPDATE_FROM_V1.md", "The short replace-list for installs that still run an older version"],
    ],
    [28, 72]
  ));
  out.push(h1("3.2 Recommended Replacement Procedure (Full-Folder Sync)"));
  out.push(p(["Because the v3 build rewrote the native folder wholesale (old screens removed, new screens added, dependencies changed), updating file-by-file is error-prone. Replace whole folders instead. In VS Code, with your local project open, follow this sequence exactly; it preserves the three things that are genuinely yours locally — your environment file, your database and your installed dependencies — and replaces everything the zip owns."]));
  out.push(bullet("Step 1 — Close the running dev server (terminal: pkill -f \"next dev\" or stop the debugger) so no process locks files mid-copy."));
  out.push(bullet("Step 2 — Back up your local project once: copy the whole folder to a sibling named erp-customer-app-backup-<date>. This is your rollback path."));
  out.push(bullet("Step 3 — Extract the zip to a temp folder. You get erp-customer-app/ and satta-matka-god-native/."));
  out.push(bullet("Step 4 — Inside your LOCAL erp-customer-app: delete src/, prisma/, scripts/, public/, db/ (only if you do not need the shipped demo data — see Step 6) and the root config files (package.json, tsconfig.json, next.config.ts, tailwind.config.ts, postcss.config.mjs, components.json, eslint.config.mjs). Keep .env, node_modules/ and any android/ build output."));
  out.push(bullet("Step 5 — Copy the SAME items from the zip's erp-customer-app/ over your local folder. They overwrite cleanly because everything stale was deleted."));
  out.push(bullet("Step 6 — Database choice: copy the zip's db/custom.db too if you want the demo state (11 customers, ₹280 pending commission); keep your local db/ if it already holds real production data. Never mix — one database file is the source of truth."));
  out.push(bullet("Step 7 — Reinstall and regenerate in the terminal: npm install, then npx prisma generate, then npm run dev. Open http://localhost:3000 and confirm the landing page, /merp and /app all load."));
  out.push(bullet("Step 8 — Native app: replace your LOCAL satta-matka-god-native/ folder entirely with the zip's (keep nothing except android/ if you already generated it and your keystore, which must never be deleted). Then: npm install, npx expo install --fix, and npm run prebuild if you build APKs."));
  out.push(bullet("Step 9 — Verify the parity UI: run the app in Expo Go or an emulator against your local backend and confirm the login, home, market play, wallet, results and profile screens show the purple/pink web-identical design."));
  out.push(h1("3.3 Future Updates"));
  out.push(p(["Later packages ship the same structure, so the same full-folder sync applies unchanged. When an update is small and surgical, its zip's UPDATE_FROM_V1.md (or the equivalent replace-list in the release note) lists exactly which files to copy; the full-folder procedure above always works and never leaves a half-merged state. Whichever path you take, finish with npm install, npx prisma generate and a dev-server smoke test before touching production."]));

  // ══ 4. PART B — HOSTINGER ══
  out.push(h1("4. Part B — Hosting the Whole System on Hostinger (godmoderp.online)"));
  out.push(h1("4.1 Server Requirements and Provisioning"));
  out.push(p(["Order a Hostinger VPS (KVM 1 or above; Ubuntu 24.04; 1 vCPU, 4 GB RAM is a comfortable minimum because the Next.js production build is memory-hungry) and note its public IP. In the Hostinger DNS panel for godmoderp.online, create an A record for @ and another for www pointing at that IP; propagation is usually minutes. While waiting, enable the firewall in the VPS panel allowing SSH (22), HTTP (80) and HTTPS (443) only. Shared, Cloud startup-PHP and WordPress plans will not run this system — the requirement is a plan where you hold root SSH and control the runtime."]));
  out.push(h1("4.2 Server Preparation (one time, ~15 minutes)"));
  out.push(p(["SSH in as root and install the runtime and the process manager. The project's start script uses bun; Node.js 20+ runs the standalone build equally well — pick one and stay with it. The commands below install Node.js 20, PM2 for process supervision, and Caddy for automatic-HTTPS reverse proxying (the repository already ships a Caddyfile tuned for this deployment; Nginx plus certbot is a fully equivalent alternative if you prefer it)."]));
  out.push(pMono("apt update && apt upgrade -y"));
  out.push(pMono("curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs"));
  out.push(pMono("npm i -g pm2 caddy   # or: curl -fsSL https://bun.sh/install | bash"));
  out.push(h1("4.3 Deploying the Application"));
  out.push(p(["Upload the extracted erp-customer-app folder (from Part A) to /opt/sattamatka — with scp, SFTP (FileZilla) or git. Then create the production environment file; the application refuses to run sensibly without a correct DATABASE_URL, and the secrets below are what make sessions and admin gates safe in production."]));
  out.push(tblTitle("Table 3: Production .env (create at /opt/sattamatka/.env)"));
  out.push(tbl(
    ["Variable", "Production value", "Purpose"],
    [
      ["DATABASE_URL", "file:/opt/sattamatka/db/prod.db (or keep file:./db/custom.db)", "SQLite database file — one file, whole database"],
      ["SESSION_SECRET", "long random string (openssl rand -hex 32)", "Signs ERP admin sessions"],
      ["CRON_SECRET", "long random string", "Authenticates scheduled endpoints"],
      ["ADMIN_GATE_SECRET", "long random string", "Rotates the /g/<token> super-admin entry link"],
      ["PUSH_ENABLED", "true (only after the app's Firebase setup) or false", "Kill switch for native-app push notifications"],
      ["NODE_ENV", "production", "Build and runtime mode"],
    ],
    [22, 42, 36]
  ));
  out.push(p(["Install, generate the Prisma client, prepare the database and build the standalone output with the project's own scripts:"]));
  out.push(pMono("cd /opt/sattamatka && npm install"));
  out.push(pMono("npx prisma generate && npx prisma db push   # db push creates prod.db fresh; copy an existing db file instead to migrate data"));
  out.push(pMono("npm run build    # next build + static/public copied into .next/standalone"));
  out.push(pMono("pm2 start npm --name smg -- start && pm2 save && pm2 startup"));
  out.push(h1("4.4 Domain Binding, SSL and the Web-Plus-App Question"));
  out.push(p(["Point a reverse proxy at the app's port (3000) and let it own ports 80/443. With Caddy this is two lines in /etc/caddy/Caddyfile — godmoderp.online { reverse_proxy 127.0.0.1:3000 } — followed by systemctl reload caddy; Caddy obtains and renews the certificate automatically. With Nginx, proxy_pass to 127.0.0.1:3000 and run certbot --nginx for the certificate. Visit https://godmoderp.online/ and confirm the landing page, https://godmoderp.online/merp for the ERP login, and /app for the web customer app."]));
  out.push(p(["This is also the answer to how web and app run together smoothly: they share this one origin. There is no second server for the app — the Android APK is a client, exactly like a browser tab. Because both customers' apps and operators' browsers hit the same domain and the same database, a deposit approved in the ERP appears in the app within seconds; nothing needs to be synchronised. The only per-environment configuration the app carries is its API base URL, set at build time as described next."]));
  out.push(h1("4.5 Changes Required in the App Config for the Hosted Environment"));
  out.push(p(["The native app reads its server address and push identity from satta-matka-god-native/app.json at build time (surfaced in src/lib/config.ts). For the production build these five values must be correct; everything else in the config stays as delivered."]));
  out.push(tblTitle("Table 4: app.json / native config — production values"));
  out.push(tbl(
    ["Config key", "Production value", "Why"],
    [
      ["expo.extra.apiBase", "https://godmoderp.online  (HTTPS, no trailing slash)", "Every API call from customers' phones goes here — the single most important change"],
      ["expo.extra.eas.projectId", "The ID printed by npx eas init (one time)", "Required for Expo push tokens; empty = push silently disabled"],
      ["google-services.json", "From Firebase console, Android app package com.sattamatkagod.app, placed in the native project root", "Lets Expo Push hand over to Firebase Cloud Messaging"],
      ["expo.version / android.versionCode", "Bump for every release (e.g. 1.1.0 / 3)", "Android refuses same-versionCode upgrades over an installed APK"],
      ["android.package", "com.sattamatkagod.app (already set — never change after first release)", "Changing it turns every installed copy into a different app"],
    ],
    [26, 34, 40]
  ));
  out.push(h1("4.6 Generating the APK — Care Points"));
  out.push(p(["The complete manual is SETUP_NATIVE_APP.md §4; the care points that bite in practice are these. Generate the release keystore once — keytool -genkeypair -v -keystore sattamatkagod.keystore -alias sattamatkagod -keyalg RSA -keysize 2048 -validity 10000 — and back it up off the build machine, because losing it forces every customer to uninstall and re-register. Run npm run prebuild after every app.json change so android/ regenerates with the new apiBase and versionCode, then build with cd android && ./gradlew assembleRelease. Test the release APK on a real phone against https://godmoderp.online before distributing it — a white screen almost always means apiBase still points at the emulator default. Remember the app ships as a direct APK, so the /customerapp page already carries the Play Protect \"install anyway\" guidance for customers."]));
  out.push(h1("4.7 Publishing the APK to /customerapp"));
  out.push(p(["Copy the signed build into the backend as public/downloads/satta-matka-god.apk (exact filename — the download component probes this path and shows a ready-state button only when the file exists), update APP_VERSION in src/components/public/DownloadCta.tsx to match the app version, rebuild and restart (npm run build && pm2 restart smg). https://godmoderp.online/customerapp then serves the page customers should be sent to; the older /download link keeps redirecting to the landing page for backward compatibility."]));
  out.push(h1("4.8 Go-Live Hardening"));
  out.push(p(["Before announcing the domain: log into the ERP and change the demo super-admin password (superadmin@mb.com shipped with SAdmin@123_321) from System Users; replace the demo database with your production database or start clean with db push and your own seed; verify PUSH_ENABLED matches your Firebase state; and schedule a nightly copy of the SQLite file (a simple cron: cp db/prod.db backups/prod-$(date +\\%F).db) — with one database file, backup is one file copy."]));

  return out;
}

module.exports = { chaptersA };
