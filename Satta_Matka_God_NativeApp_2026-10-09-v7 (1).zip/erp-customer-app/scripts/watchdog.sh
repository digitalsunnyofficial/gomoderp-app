#!/bin/bash
# watchdog.sh — ERP server auto-heal loop
# Checks http://localhost:3000 every 60s. If down twice in a row:
#   1. Kill any stray dev-mode processes (next dev / bun run dev)
#   2. Rebuild production if .next/standalone/server.js is missing
#   3. Start the production server (node bootstrap.js)
# Logs to /tmp/watchdog.log. Guarded by pidfile so multiple
# invocations (manual + bootstrap.js spawn) never duplicate.

PIDFILE=/tmp/erp-watchdog.pid
LOG=/tmp/watchdog.log
PROJECT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# ── Singleton guard ──────────────────────────────────────────────────
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "[$(date '+%F %T')] watchdog already running (pid $(cat "$PIDFILE")), exiting" >> "$LOG"
  exit 0
fi
echo $$ > "$PIDFILE"
echo "[$(date '+%F %T')] watchdog started (pid $$)" >> "$LOG"

FAILS=0
while true; do
  sleep 60

  if curl -sf -m 5 http://localhost:3000/api/health > /dev/null 2>&1; then
    FAILS=0
    continue
  fi

  # First failure — quick recheck after 10s before declaring an outage
  # (avoids punishing a brief GC pause / deploy blip with a full minute wait)
  sleep 10
  if curl -sf -m 5 http://localhost:3000/api/health > /dev/null 2>&1; then
    FAILS=0
    continue
  fi
  FAILS=$((FAILS + 1))
  echo "[$(date '+%F %T')] health check failed (confirmed on recheck)" >> "$LOG"
  [ "$FAILS" -lt 2 ] && continue

  echo "[$(date '+%F %T')] SERVER DOWN — recovering" >> "$LOG"

  # 1. Kill stray dev-mode processes (they hang at high CPU and hold port 3000)
  pkill -9 -f "bun run dev"      2>/dev/null
  pkill -9 -f "next dev"         2>/dev/null
  pkill -9 -f "postcss.js"       2>/dev/null
  pkill -9 -f "bootstrap.js"     2>/dev/null
  pkill -9 -f "next-server"      2>/dev/null
  sleep 2

  # 2. Rebuild if the standalone build is missing (dev-mode startup wipes it)
  if [ ! -f "$PROJECT/.next/standalone/server.js" ]; then
    echo "[$(date '+%F %T')] standalone build missing — rebuilding" >> "$LOG"
    cd "$PROJECT" && npm run build >> "$LOG" 2>&1
  fi

  # 3. Start production server
  cd "$PROJECT" && setsid bash -c 'npm start >> /tmp/next-prod.log 2>&1 &'
  echo "[$(date '+%F %T')] production server start issued" >> "$LOG"

  FAILS=0
  sleep 30
done
