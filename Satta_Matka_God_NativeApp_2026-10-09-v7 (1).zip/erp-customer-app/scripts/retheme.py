#!/usr/bin/env python3
"""Retheme the ERP from the dark reference palette to the light
WHITE + BLUE theme, and shift the old indigo accents to blue.
Run once: python3 scripts/retheme.py
"""
import os, re

ROOT = '/home/z/my-project/src'

# dark reference palette → light white/blue
MAP = {
    # surfaces
    '#0F172A': '#F5F6FA',
    '#1E293B': '#FFFFFF',
    '#1B2537': '#F9FAFB',
    '#0B1220': '#FFFFFF',
    '#2A3A55': '#E5E7EB',
    '#26334A': '#F3F4F6',
    '#334155': '#D1D5DB',
    '#223050': '#E5E7EB',
    # text
    '#F1F5F9': '#111827',
    '#E2E8F0': '#374151',
    '#CBD5E1': '#9CA3AF',
    '#94A3B8': '#6B7280',
    '#64748B': '#9CA3AF',
    '#8DA2B8': '#9CA3AF',
    '#7488A0': '#9CA3AF',
    '#475569': '#6B7280',
    # teal accents → blue
    '#0D9488': '#2563EB',
    '#14B8A6': '#3B82F6',
    '#2DD4BF': '#60A5FA',
    '#0F766E': '#1D4ED8',
    '#5EEAD4': '#93C5FD',
    '#99F6E4': '#BFDBFE',
    '#CCFBF1': '#DBEAFE',
    '#22D3EE': '#3B82F6',
    '#67E8F9': '#60A5FA',
    '#04211D': '#FFFFFF',
    # indigo accents → blue
    '#3730A3': '#2563EB',
    '#2E2785': '#1D4ED8',
    '#4F46E5': '#2563EB',
    '#6366F1': '#3B82F6',
    '#4338CA': '#1D4ED8',
    '#6D28D9': '#2563EB',
    '#4C1D95': '#1E40AF',
    '#EEF2FF': '#EFF6FF',
    '#E0E7FF': '#DBEAFE',
    '#C7D2FE': '#BFDBFE',
    '#A5B4FC': '#93C5FD',
    '#818CF8': '#60A5FA',
    '#6366F1': '#3B82F6',
    # translucent teals → translucent blue
    'rgba(45,212,191': 'rgba(37,99,235',
    'rgba(20,184,166': 'rgba(59,130,246',
    'rgba(13,148,136': 'rgba(37,99,235',
}

SKIP_DIRS = {'customerapp'}  # customer app keeps its reference palette

changed = {}
for dirpath, dirnames, filenames in os.walk(ROOT):
    dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
    for fn in filenames:
        if not fn.endswith(('.tsx', '.ts', '.css')):
            continue
        path = os.path.join(dirpath, fn)
        with open(path, encoding='utf-8') as f:
            s = f.read()
        orig = s
        for old, new in MAP.items():
            s = s.replace(old, new).replace(old.lower(), new)
        if s != orig:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(s)
            changed[path] = sum(1 for old in MAP if old in orig)

print('files changed:', len(changed))
for p in sorted(changed):
    print(' -', os.path.relpath(p, '/home/z/my-project'))
