import { parseUnifiedEntry } from '../src/lib/matka/entry-parser'
// per-ank counts for each cut-chart group via Smart Entry seeds
const charts = ['20 Chart', '30 Chart', '40 Chart', '50 Chart', '60 Chart', '70 Chart', '90 DP Chart', '90 ABR Chart']
for (const opt of charts) {
  const counts: string[] = []
  for (let ank = 0; ank <= 9; ank++) {
    const r = parseUnifiedEntry(`${opt} - ${ank} = 10`, 0)
    const g = r.groups.find(x => x.option === opt)
    counts.push(ank + ':' + (g ? g.entries.length : (r.skipped.length ? 'err' : '?')))
  }
  console.log(opt.padEnd(13), counts.join(' '))
}
// chart by panna seed
const r2 = parseUnifiedEntry('50 Chart - 137 = 75', 0)
console.log('50 Chart by panna 137 →', JSON.stringify(r2.groups[0]?.entries))
// family counts
for (const fam of ['Family Set 4', 'Family Set 6', 'Family Set 8', 'Family Chart'] as const) {
  const r = parseUnifiedEntry(`${fam} - 123 = 100`, 0)
  const g = r.groups[0]
  console.log(fam, '123 →', g ? g.entries.length + ' pannas' : 'error: ' + r.skipped.join('; '))
}
// SPDPTP 3-digit seed
const r3 = parseUnifiedEntry('SPDPTP - 128 = 50', 0)
console.log('SPDPTP 128 →', r3.groups.map(g => g.option + ':' + g.entries.length).join(','), 'spelled', JSON.stringify(r3.groups[0]?.entries))
// single-digit under group label?
const r4 = parseUnifiedEntry('SP - 1 = 100', 0)
console.log('SP label 1-digit → singles:', JSON.stringify(r4.singles), 'groups:', r4.groups.length)
