/**
 * RESET TO PRODUCTION-READY TEST DATA
 * ────────────────────────────────────────────────────
 * Per operator instruction: wipe ALL old transactional data and prepare a
 * clean, production-like slate for live market testing.
 *
 * DELETED (transactional + derived):
 *   App bets/results/ledger, fund & withdraw requests, notifications,
 *   sessions; ERP inventories (cards, triple, double-single), settlements,
 *   chart revisions, parser exceptions, user activity log, ERP payments.
 *
 * KEPT (master data):
 *   ERP users, app customers (wallets reset to 0), vendors, the 18 canonical
 *   AppMarket sessions, starlines, game catalogue + allocations, app config,
 *   payment settings, parser configuration.
 *
 * SEEDED (production-like):
 *   - Canonical-linked InventoryCode rows for ALL 18 markets
 *     (code "app_<marketCode>", marketCode set, full display name, correct
 *     open/close/night type) — the ONE market source, ERP + Game shared.
 *   - family-4/6/8 games deactivated (combined "family" chart is the only
 *     active family game) per the Triple-section requirement.
 *   - Test wallet: first approved app customer (vikram preferred) gets a
 *     ₹10,000 approved deposit so live betting can be tested end-to-end.
 */
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  console.log('── Wiping transactional data ──')
  // App side
  await db.appBet.deleteMany()
  await db.appResult.deleteMany()
  await db.appTransaction.deleteMany()
  await db.appFundRequest.deleteMany()
  await db.appWithdrawRequest.deleteMany()
  await db.appNotification.deleteMany()
  await db.appSession.deleteMany()
  // ERP side (children before parents)
  await db.chartRevision.deleteMany()
  await db.parserException.deleteMany()
  await db.tripleInventory.deleteMany()
  await db.doubleSingleInventory.deleteMany()
  await db.card.deleteMany()
  await db.inventory.deleteMany()
  await db.settlement.deleteMany()
  await db.payment.deleteMany()
  await db.userActivity.deleteMany()

  console.log('── Resetting app customer wallets to 0 ──')
  await db.appCustomer.updateMany({ data: { wallet: 0 } })

  console.log('── Canonical InventoryCodes for the 18 market sessions ──')
  await db.inventoryCode.deleteMany()
  const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
  const PHASE_LBL = { day: 'Day', night: 'Night', none: '' }
  const SESS_LBL = { open: 'Open', close: 'Close', both: '' }
  for (const m of markets) {
    const phase = PHASE_LBL[m.phase] ?? ''
    const sess = SESS_LBL[m.session] ?? ''
    const displayName = [m.name, phase, sess].filter(Boolean).join(' ')
    const isNight = m.phase === 'night'
    const isClose = m.session === 'close'
    const type = isNight ? (isClose ? 'night-close' : 'night-open') : (isClose ? 'close' : 'open')
    await db.inventoryCode.upsert({
      where: { code: `app_${m.code}` },
      create: { code: `app_${m.code}`, name: displayName, market: m.name, marketCode: m.code, type },
      update: { name: displayName, market: m.name, marketCode: m.code, type },
    })
    console.log(`  ${type.padEnd(12)} ${displayName}`)
  }

  console.log('── Retiring legacy Family Sets 4/6/8 (combined Family chart stays) ──')
  const fam = await db.game.updateMany({
    where: { code: { in: ['family-4', 'family-6', 'family-8'] } },
    data: { isActive: false },
  })
  console.log(`  deactivated: ${fam.count} games`)

  console.log('── Test wallet for live betting ──')
  let customer = await db.appCustomer.findFirst({
    where: { name: 'vikram', status: 'active' },
  })
  if (!customer) {
    const candidates = await db.appCustomer.findMany({ where: { status: 'active' }, orderBy: { createdAt: 'asc' } })
    customer = candidates.find(c => (c.name || '').toLowerCase() === 'vikram') ||
      candidates.find(c => c.approvalStatus === 'approved') || null
  }
  if (customer) {
    await db.appCustomer.update({ where: { id: customer.id }, data: { wallet: 10000 } })
    await db.appTransaction.create({
      data: {
        customerId: customer.id, type: 'deposit', amount: 10000, balanceAfter: 10000,
        remark: 'Opening balance — production-like test seed',
      },
    })
    console.log(`  ${customer.name} (${customer.mobile}) → wallet 10,000`)
  } else {
    console.log('  no approved app customer found — skip')
  }

  const [mk, sl, ga, g, ic, ac] = await Promise.all([
    db.appMarket.count(), db.appStarline.count(), db.gameAllocation.count(),
    db.game.count({ where: { isActive: true } }), db.inventoryCode.count(),
    db.appCustomer.count(),
  ])
  console.log('── State ──')
  console.log(`  markets: ${mk} · starlines: ${sl} · active games: ${g} · allocations: ${ga} · inventory codes: ${ic} · customers: ${ac}`)
  console.log('  bets/results/ledger/inventories: 0 (clean slate)')
}

main()
  .catch(e => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
