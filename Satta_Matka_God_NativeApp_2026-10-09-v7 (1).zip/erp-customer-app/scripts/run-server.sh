#!/bin/bash
cd /home/z/my-project
export DATABASE_URL="file:/home/z/my-project/db/custom.db"
export NODE_ENV=production
export PORT=3000
export HOSTNAME=0.0.0.0

echo "Starting Matka Card ERP server on port 3000..."
exec node .next/standalone/server.js
