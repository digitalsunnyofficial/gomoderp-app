// Diagnostic: why is POST /api/customer-app/bets returning 400?
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

function istDate(d = new Date()) {
  const ist = new Date(d.getTime() + 5.5 * 3600 * 1000)
  return ist.toISOString().slice(0, 10)
}

async function main() {
  const today = istDate()
  console.log('IST today =', today)

  const customers = await db.appCustomer.findMany({
    select: { mobile: true, name: true, wallet: true, canBet: true, status: true },
  })
  console.log('\n=== CUSTOMERS ===')
  customers.forEach(c => console.log(`${c.mobile} | ${c.name} | wallet=${c.wallet} | canBet=${c.canBet} | status=${c.status}`))

  const markets = await db.appMarket.findMany({ orderBy: { code: 'asc' } })
  console.log('\n=== MARKETS (18 expected) ===')
  markets.forEach(m => {
    const wd = Array.isArray(m.weeklyOff) ? (m.weeklyOff as number[]) : []
    const nowIst = new Date(Date.now() + 5.5 * 3600 * 1000)
    const day = nowIst.getUTCDay()
    console.log(
      `${m.code} | ${m.name} ${m.phase}/${m.session} | active=${m.isActive} | ${m.openTime}-${m.closeTime} close@-${m.betClosingMinutes}m | weeklyOff=[${wd}] todayIdx=${day}${wd.includes(day) ? ' <-- WEEKLY OFF TODAY' : ''}`
    )
  })

  const results = await db.appResult.findMany({ orderBy: { resultDate: 'desc' }, take: 20 })
  console.log('\n=== RECENT RESULTS (lockout source) ===')
  results.forEach(r =>
    console.log(`${r.marketCode} | ${r.resultDate} | open=${r.openPanna || '-'} close=${r.closePanna || '-'} | v${r.version} ${r.state}${r.resultDate === today ? '  <-- TODAY' : ''}`)
  )

  const starlines = await db.appStarline.findMany()
  console.log('\n=== STARLINES ===')
  starlines.forEach(s => console.log(`${s.code} | ${s.name} | ${s.hour}:${String(s.minute).padStart(2, '0')} | on=${s.isOn} active=${s.isActive} | closing ${s.betClosingMinutes}m before`))

  const bets = await db.appBet.findMany({ orderBy: { createdAt: 'desc' }, take: 10 })
  console.log('\n=== LAST 10 BETS ===')
  bets.forEach(b => console.log(`${b.createdAt.toISOString()} | ${b.customerId} | ${b.marketCode} ${b.type} ${b.num} x${b.points} | ${b.status} | reqId=${b.clientRequestId || '-'}`))

  const codes = await db.inventoryCode.findMany({ where: { code: { startsWith: 'app_' } }, select: { code: true, marketCode: true } })
  console.log('\n=== APP_ INVENTORY CODES ===', codes.length)
  codes.slice(0, 20).forEach(c => console.log(`${c.code} -> marketCode=${c.marketCode}`))
}

main().finally(() => db.$disconnect())
