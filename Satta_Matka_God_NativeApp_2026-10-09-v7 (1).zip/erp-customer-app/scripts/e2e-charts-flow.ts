// E2E API flow: new games in app → bets → master boards → settlement
const BASE = 'http://localhost:3000'
let fails = 0
function check(label, cond, extra = '') {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + label + (extra ? ' — ' + extra : ''))
  if (!cond) fails++
}
async function j(url, opts = {}) {
  const res = await fetch(BASE + url, opts)
  let data = null
  try { data = await res.json() } catch {}
  return { status: res.status, data, headers: res.headers }
}

// 1. customer login (Rahul)
const login = await j('/api/customer-app/auth/login', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ mobile: '9812345601', password: 'Rahul@123' }),
})
check('customer login', login.status === 200 && login.data?.token, login.status + '')
const ctk = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + login.data?.token }

// 2. home → new games present, family sets absent
const home = await j('/api/customer-app/home', { headers: ctk })
const mk = (home.data?.markets || []).find(m => m.games && m.games.length)
check('home loads with markets + games', !!mk, mk?.code)
const codes = (mk?.games || []).map(g => g.code)
for (const c of ['chart-20', 'chart-30', 'chart-40', 'family', 'hsb']) {
  check('game in app list: ' + c, codes.includes(c))
}
check('family sets removed from allocation', !codes.includes('family-4') && !codes.includes('family-6') && !codes.includes('family-8'))

// 3. place chart-20 bet (panna 137, 10 pts) + hsb bet (038-1, 10 pts) + single bet
const mkCode = mk.code
const today = new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10)
const betsPayload = { items: [
  { marketCode: mkCode, slot: 'open', type: 'sp', num: '137', points: 10, gameCode: 'chart-20' },
  { marketCode: mkCode, slot: 'hs', type: 'hsb', num: '038-1', points: 10, gameCode: 'hsb' },
  { marketCode: mkCode, slot: 'open', type: 'single', num: '5', points: 10 },
  { marketCode: mkCode, slot: 'jodi', type: 'jodi', num: '51', points: 10 },
] }
const placed = await j('/api/customer-app/bets', { method: 'POST', headers: ctk, body: JSON.stringify(betsPayload) })
check('bets placed (4 rows)', placed.status === 200 && placed.data?.placedCount === 4, placed.status + ' ' + JSON.stringify(placed.data?.error || placed.data?.placedCount))

// 4. ERP login (super) — capture the erp_session cookie
const erp = await j('/api/auth', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'superadmin@mb.com', password: 'SAdmin@123_321' }),
})
const setCookies = erp.headers ? (erp.headers.getSetCookie ? erp.headers.getSetCookie() : []) : []
let sessCookie = ''
for (const c of setCookies) { if (c.startsWith('erp_session=')) sessCookie = c.split(';')[0] }
check('ERP login', erp.status === 200 && !!sessCookie, erp.status + ' cookie=' + (sessCookie ? 'yes' : 'no'))

// find the session cookie name from the response
const etk = { 'Content-Type': 'application/json', Cookie: sessCookie }

// 5. market charts → boards + typeSummary
const charts = await j('/api/app-admin/market-charts?market=' + mkCode + '&date=' + today, { headers: etk })
check('market-charts 200', charts.status === 200, charts.status + '')
const boards = charts.data?.boards
check('boards present', !!boards)
const tOpenCells = boards?.triple?.open?.cells || []
check('triple open board aggregates 137 (digit-set)', tOpenCells.some(c => c.num === '137' && c.points >= 10 && c.points % 10 === 0), JSON.stringify(tOpenCells.slice(0, 3)))
check('single open board has digit 5', (boards?.single?.open?.cells || []).some(c => c.num === '5' && c.points >= 10))
check('double jodi board has 51', (boards?.double?.jodi?.cells || []).some(c => c.num === '51' && c.points >= 10))
const ts = charts.data?.typeSummary || []
check('typeSummary has sp staked', (ts.find(t => t.type === 'sp')?.staked || 0) >= 10, JSON.stringify(ts.map(t => t.type + ':' + t.staked)))
check('typeSummary has hsb staked', (ts.find(t => t.type === 'hsb')?.staked || 0) >= 10)

// 6. declare a result that wins the chart-20 bet (137 → open) and hsb (open panna 038? no — hsb num '038-1' needs open panna 038 + close digit 1)
// open panna 137: open digit 1. hsb bet '038-1' needs open panna '038' — declared open is 137 → hsb loses. Fine, verify both outcomes.
const dec = await j('/api/app-admin/results', {
  method: 'POST', headers: etk,
  body: JSON.stringify({ marketCode: mkCode, openPanna: '137', closePanna: '234' }),
})
check('result declared', dec.status === 200, dec.status + ' ' + JSON.stringify(dec.data?.error || ''))
check('settlement counts include our bets', dec.data?.settlement?.considered >= 4, JSON.stringify(dec.data?.settlement))
check('chart-20 bet won (sp 137 = open panna, digit-set)', dec.data?.settlement?.won >= 1, 'won=' + dec.data?.settlement?.won)

// 7. verify digit-set: declare '380' form should be accepted now (already declared today → validator passes, upsert merges)
const dec2 = await j('/api/app-admin/results', {
  method: 'POST', headers: etk,
  body: JSON.stringify({ marketCode: mkCode, openPanna: '380' }),
})
check('operator-chart spelling 380 accepted by validator', dec2.status === 200, dec2.status + ' ' + JSON.stringify(dec2.data?.error || ''))

console.log(fails ? '\n' + fails + ' FAILURES' : '\nALL E2E API CHECKS PASSED')
process.exit(fails ? 1 : 0)
