/**
 * Unit tests for the Multi-Seed Batch Input feature.
 *
 * Run with: node scripts/verify-group-batch.cjs
 *
 * Tests:
 *   1. parseSeedBatch: comma/newline/space splitting, max-10 cap
 *   2. Each expander with 1 valid + 1 invalid seed
 *   3. Duplicate panna merge/sum across multiple seeds
 *   4. TP "000" preservation
 *   5. Family normalization grouping
 */

// We use CommonJS require() to avoid ts-node dependency.
// The .ts files are compiled on-the-fly by bun, but for a plain Node script
// we'll re-implement the test by importing the compiled JS via bun.
// Since this project uses bun, we can run it with: bun scripts/verify-group-batch.ts

// Actually, let's write it as a .ts file and run with bun for consistency.

import { parseSeedBatch, MAX_SEEDS, cleanSeedDigits } from '../src/lib/matka/seed-parser'
import {
  SP_SET, DP_SET, TP_SET,
  isSP, isDP, isTP,
  pannaToAnk,
  normalizeDigitSet,
  CHART_50_PANNAS, CHART_60_PANNAS, CHART_70_PANNAS, CHART_ABR9_PANNAS,
  FAMILY_CHART,
} from '../src/lib/matka/chart-definitions'
import {
  expandSP, expandDP, expandTP, expandSPDP, expandSPTP, expandDPTP, expandSPDPTP,
  expandMotor, expand50Chart, expand60Chart, expand70Chart, expand90AbrChart, expandFamily,
} from '../src/lib/matka/group-expanders'
import { buildGroupBatch, getMergedEntries, getGrandTotal } from '../src/lib/matka/group-batch-engine'
import type { GroupOption } from '../src/lib/matka/group-types'

// ────────────────────────────────────────────────────────────────────────────
// Test framework (minimal)
// ────────────────────────────────────────────────────────────────────────────
let passed = 0
let failed = 0

function assert(condition: boolean, message: string) {
  if (condition) {
    passed++
    console.log(`  ✓ ${message}`)
  } else {
    failed++
    console.error(`  ✗ ${message}`)
  }
}

function assertEqual<T>(actual: T, expected: T, message: string) {
  const eq = JSON.stringify(actual) === JSON.stringify(expected)
  if (eq) {
    passed++
    console.log(`  ✓ ${message}`)
  } else {
    failed++
    console.error(`  ✗ ${message}`)
    console.error(`    Expected: ${JSON.stringify(expected)}`)
    console.error(`    Actual:   ${JSON.stringify(actual)}`)
  }
}

function section(name: string) {
  console.log(`\n── ${name} ──`)
}

// ────────────────────────────────────────────────────────────────────────────
// 1. parseSeedBatch tests
// ────────────────────────────────────────────────────────────────────────────
section('parseSeedBatch: splitting and max-10 cap')

{
  const { seeds, rejectedOverflow } = parseSeedBatch('128, 137, 235')
  assertEqual(seeds, ['128', '137', '235'], 'Comma-separated seeds parsed')
  assertEqual(rejectedOverflow, [], 'No overflow for 3 seeds')
}

{
  const { seeds } = parseSeedBatch('128\n137\n235')
  assertEqual(seeds, ['128', '137', '235'], 'Newline-separated seeds parsed')
}

{
  const { seeds } = parseSeedBatch('128 137 235')
  assertEqual(seeds, ['128', '137', '235'], 'Space-separated seeds parsed')
}

{
  const { seeds } = parseSeedBatch('128, 137\n235 456')
  assertEqual(seeds, ['128', '137', '235', '456'], 'Mixed separators parsed')
}

{
  const { seeds } = parseSeedBatch('  128  ,  \n\n  137  ')
  assertEqual(seeds, ['128', '137'], 'Trimmed and empties removed')
}

{
  const many = Array.from({ length: 15 }, (_, i) => `12${i}`)
  const { seeds, rejectedOverflow } = parseSeedBatch(many.join(','))
  assertEqual(seeds.length, MAX_SEEDS, `Max ${MAX_SEEDS} seeds enforced`)
  assertEqual(rejectedOverflow.length, 5, 'Overflow reported (5 rejected)')
}

{
  const { seeds } = parseSeedBatch('')
  assertEqual(seeds, [], 'Empty input returns empty array')
}

{
  const { seeds } = parseSeedBatch('   \n\n  ,  ')
  assertEqual(seeds, [], 'Whitespace-only input returns empty array')
}

// ────────────────────────────────────────────────────────────────────────────
// 2. Expander tests — 1 valid + 1 invalid per expander
// ────────────────────────────────────────────────────────────────────────────
section('expandSP: valid + invalid')

{
  const valid = expandSP('128', { rate: 100 })
  assert(!('error' in valid) && valid.length === 1 && valid[0].panna === '128', 'SP valid seed "128" → 1 entry')
  assert(!('error' in valid) && valid[0].rate === 100, 'SP entry has correct rate')
  assert(!('error' in valid) && valid[0].sourceSeed === '128', 'SP entry has sourceSeed')

  const invalid = expandSP('112', { rate: 100 })
  assert('error' in invalid, 'SP rejects DP panna "112"')

  const invalid2 = expandSP('111', { rate: 100 })
  assert('error' in invalid2, 'SP rejects TP panna "111"')

  const invalid3 = expandSP('12', { rate: 100 })
  assert('error' in invalid3, 'SP rejects 2-digit seed "12"')
}

section('expandDP: valid + invalid')

{
  const valid = expandDP('112', { rate: 100 })
  assert(!('error' in valid) && valid.length === 1 && valid[0].panna === '112', 'DP valid seed "112" → 1 entry')

  const invalid = expandDP('128', { rate: 100 })
  assert('error' in invalid, 'DP rejects SP panna "128"')

  const invalid2 = expandDP('111', { rate: 100 })
  assert('error' in invalid2, 'DP rejects TP panna "111"')
}

section('expandTP: valid + invalid + "000" preservation')

{
  const valid = expandTP('111', { rate: 100 })
  assert(!('error' in valid) && valid.length === 1 && valid[0].panna === '111', 'TP valid seed "111" → 1 entry')

  // CRITICAL: "000" must be preserved as "000", not converted to "0"
  const zero = expandTP('000', { rate: 100 })
  assert(!('error' in zero) && zero.length === 1 && zero[0].panna === '000', 'TP preserves "000" as string (not "0")')

  const invalid = expandTP('128', { rate: 100 })
  assert('error' in invalid, 'TP rejects SP panna "128"')

  const invalid2 = expandTP('112', { rate: 100 })
  assert('error' in invalid2, 'TP rejects DP panna "112"')
}

section('expandSPDP: valid + invalid')

{
  const sp = expandSPDP('128', { rate: 100 })
  assert(!('error' in sp) && sp.length === 1, 'SPDP accepts SP panna "128"')

  const dp = expandSPDP('112', { rate: 100 })
  assert(!('error' in dp) && dp.length === 1, 'SPDP accepts DP panna "112"')

  const tp = expandSPDP('111', { rate: 100 })
  assert('error' in tp, 'SPDP rejects TP panna "111"')
}

section('expandSPTP: valid + invalid')

{
  const sp = expandSPTP('128', { rate: 100 })
  assert(!('error' in sp) && sp.length === 1, 'SPTP accepts SP panna "128"')

  const tp = expandSPTP('111', { rate: 100 })
  assert(!('error' in tp) && tp.length === 1, 'SPTP accepts TP panna "111"')

  const dp = expandSPTP('112', { rate: 100 })
  assert('error' in dp, 'SPTP rejects DP panna "112"')
}

section('expandDPTP: valid + invalid')

{
  const dp = expandDPTP('112', { rate: 100 })
  assert(!('error' in dp) && dp.length === 1, 'DPTP accepts DP panna "112"')

  const tp = expandDPTP('111', { rate: 100 })
  assert(!('error' in tp) && tp.length === 1, 'DPTP accepts TP panna "111"')

  const sp = expandDPTP('128', { rate: 100 })
  assert('error' in sp, 'DPTP rejects SP panna "128"')
}

section('expandSPDPTP: valid + invalid')

{
  const sp = expandSPDPTP('128', { rate: 100 })
  assert(!('error' in sp) && sp.length === 1, 'SPDPTP accepts SP panna "128"')

  const dp = expandSPDPTP('112', { rate: 100 })
  assert(!('error' in dp) && dp.length === 1, 'SPDPTP accepts DP panna "112"')

  const tp = expandSPDPTP('111', { rate: 100 })
  assert(!('error' in tp) && tp.length === 1, 'SPDPTP accepts TP panna "111"')

  const invalid = expandSPDPTP('12', { rate: 100 })
  assert('error' in invalid, 'SPDPTP rejects 2-digit seed')
}

section('expandMotor: valid + invalid')

{
  // "4567890" has 7 unique digits → C(7,3) = 35 combinations × 6 perms = 210 pannas
  const valid = expandMotor('4567890', { rate: 100 })
  assert(!('error' in valid) && valid.length === 210, 'Motor "4567890" → 210 SP pannas (C(7,3)×6)')

  // "456" has 3 unique digits → C(3,3) = 1 combination × 6 perms = 6 pannas
  const min = expandMotor('456', { rate: 100 })
  assert(!('error' in min) && min.length === 6, 'Motor "456" → 6 SP pannas (C(3,3)×6)')

  const invalid = expandMotor('12', { rate: 100 })
  assert('error' in invalid, 'Motor rejects <3 digit seed "12"')

  // "111" has only 1 unique digit → error
  const invalid2 = expandMotor('111', { rate: 100 })
  assert('error' in invalid2, 'Motor rejects seed with <3 unique digits "111"')
}

section('expand50Chart: valid + invalid')

{
  // Get a known panna from the 50 chart
  const ank5Pannas = CHART_50_PANNAS.get(5) || []
  assert(ank5Pannas.length === 5, '50 Chart has 5 pannas for ank 5')

  const testPanna = ank5Pannas[0]
  const valid = expand50Chart(testPanna, { rate: 100 })
  assert(!('error' in valid) && valid.length === 1, `50 Chart accepts panna "${testPanna}"`)

  // Ank reference
  const ankValid = expand50Chart('Ank5', { rate: 100 })
  assert(!('error' in ankValid) && ankValid.length === 5, '50 Chart accepts "Ank5" → 5 pannas')

  // A panna NOT in the 50 chart (use one from the full SP universe that's not in the first 5)
  const allSpAnk5 = Array.from(SP_SET).filter(p => pannaToAnk(p) === 5)
  const notInChart = allSpAnk5.find(p => !ank5Pannas.includes(p))
  if (notInChart) {
    const invalid = expand50Chart(notInChart, { rate: 100 })
    assert('error' in invalid, `50 Chart rejects panna "${notInChart}" (not in chart)`)
  }
}

section('expand60Chart: valid + invalid')

{
  const ank3Pannas = CHART_60_PANNAS.get(3) || []
  assert(ank3Pannas.length === 6, '60 Chart has 6 pannas for ank 3')

  const ankValid = expand60Chart('Ank3', { rate: 100 })
  assert(!('error' in ankValid) && ankValid.length === 6, '60 Chart accepts "Ank3" → 6 pannas')
}

section('expand70Chart: valid + invalid')

{
  const ank7Pannas = CHART_70_PANNAS.get(7) || []
  assert(ank7Pannas.length === 7, '70 Chart has 7 pannas for ank 7')

  const ankValid = expand70Chart('Ank7', { rate: 100 })
  assert(!('error' in ankValid) && ankValid.length === 7, '70 Chart accepts "Ank7" → 7 pannas')
}

section('expand90AbrChart: valid + invalid')

{
  const ank1Pannas = CHART_ABR9_PANNAS.get(1) || []
  assert(ank1Pannas.length === 9, '90 ABR Chart has 9 pannas for ank 1')

  const ankValid = expand90AbrChart('Ank1', { rate: 100 })
  assert(!('error' in ankValid) && ankValid.length === 9, '90 ABR Chart accepts "Ank1" → 9 pannas')
}

section('expandFamily: valid + invalid + normalization grouping')

{
  // "321" → normalize → "123" → family of 6 SP permutations
  const family321 = expandFamily('321', { rate: 100 })
  assert(!('error' in family321), 'Family accepts "321"')
  assert(!('error' in family321) && family321.length === 6, 'Family "321" → 6 permutations')
  assert(!('error' in family321) && family321.some(e => e.panna === '123'), 'Family includes "123"')
  assert(!('error' in family321) && family321.some(e => e.panna === '321'), 'Family includes "321"')

  // "112" → normalize → "112" → family of 3 DP arrangements
  const family112 = expandFamily('112', { rate: 100 })
  assert(!('error' in family112) && family112.length === 3, 'Family "112" → 3 DP arrangements')

  // "111" → normalize → "111" → family of 1 TP
  const family111 = expandFamily('111', { rate: 100 })
  assert(!('error' in family111) && family111.length === 1, 'Family "111" → 1 TP')

  const invalid = expandFamily('12', { rate: 100 })
  assert('error' in invalid, 'Family rejects <3 digit seed')
}

// ────────────────────────────────────────────────────────────────────────────
// 3. Duplicate panna merge/sum across multiple seeds
// ────────────────────────────────────────────────────────────────────────────
section('buildGroupBatch: duplicate panna merge/sum')

{
  // Two motor seeds that share digits → overlapping pannas
  // "1234" and "1235" both contain "123" → should be summed
  const result = buildGroupBatch('Motor Pana', '1234, 1235', { rate: 100 })

  // "123" is generated by both seeds → merged rate should be 200
  const rate123 = result.mergedMap.get('123')
  assert(rate123 === 200, 'Duplicate panna "123" summed to 200 (100+100)')

  // Total entries before merge > mergedMap size (there were duplicates)
  assert(result.entries.length > result.mergedMap.size, 'Entries > mergedMap size (duplicates existed)')
}

{
  // SP batch with same panna twice
  const result = buildGroupBatch('SP', '128, 128', { rate: 50 })
  assertEqual(result.mergedMap.get('128'), 100, 'Same SP panna twice → summed to 100')
  assertEqual(result.mergedMap.size, 1, 'Only 1 unique panna in mergedMap')
}

{
  // Mixed valid + invalid seeds
  const result = buildGroupBatch('SP', '128, 112, 137', { rate: 100 })
  assertEqual(result.mergedMap.size, 2, '2 valid SP pannas (112 rejected as DP)')
  assertEqual(result.invalidSeeds.length, 1, '1 invalid seed reported')
  assertEqual(result.invalidSeeds[0].raw, '112', 'Invalid seed "112" reported')
}

// ────────────────────────────────────────────────────────────────────────────
// 4. TP "000" preservation in batch
// ────────────────────────────────────────────────────────────────────────────
section('TP "000" preservation in batch')

{
  const result = buildGroupBatch('TP', '000, 111, 222', { rate: 100 })
  assert(result.mergedMap.has('000'), 'TP batch preserves "000" key (not "0")')
  assertEqual(result.mergedMap.get('000'), 100, 'TP "000" rate is 100')
  assertEqual(result.mergedMap.size, 3, '3 unique TP pannas')
}

// ────────────────────────────────────────────────────────────────────────────
// 5. Family normalization grouping
// ────────────────────────────────────────────────────────────────────────────
section('Family normalization grouping')

{
  // "321" and "123" normalize to the same key "123" → same family
  // In batch mode, both seeds expand to the same 6 pannas, so all 6 are duplicated
  const result = buildGroupBatch('Family Chart', '321, 123', { rate: 100 })
  assertEqual(result.mergedMap.size, 6, 'Family batch: 321+123 → 6 unique pannas (same family)')
  // Each panna should have rate 200 (doubled)
  assertEqual(result.mergedMap.get('123'), 200, 'Family "123" rate summed to 200')
}

// ────────────────────────────────────────────────────────────────────────────
// 6. Overflow handling
// ────────────────────────────────────────────────────────────────────────────
section('Overflow handling')

{
  const seeds = Array.from({ length: 12 }, (_, i) => `12${i.toString().padStart(1, '0')}`)
  const result = buildGroupBatch('SP', seeds.join(','), { rate: 100 })
  assertEqual(result.rejectedOverflow.length, 2, '2 overflow seeds reported')
}

// ────────────────────────────────────────────────────────────────────────────
// 7. Helper functions
// ────────────────────────────────────────────────────────────────────────────
section('Helper functions')

{
  assertEqual(isSP('128'), true, 'isSP("128") = true')
  assertEqual(isSP('112'), false, 'isSP("112") = false')
  assertEqual(isSP('111'), false, 'isSP("111") = false')

  assertEqual(isDP('112'), true, 'isDP("112") = true')
  assertEqual(isDP('128'), false, 'isDP("128") = false')
  assertEqual(isDP('111'), false, 'isDP("111") = false')

  assertEqual(isTP('111'), true, 'isTP("111") = true')
  assertEqual(isTP('000'), true, 'isTP("000") = true')
  assertEqual(isTP('112'), false, 'isTP("112") = false')

  assertEqual(pannaToAnk('128'), 1, 'pannaToAnk("128") = 1 (1+2+8=11→1)')
  assertEqual(pannaToAnk('999'), 7, 'pannaToAnk("999") = 7 (9+9+9=27→7)')
  assertEqual(pannaToAnk('100'), 1, 'pannaToAnk("100") = 1 (1+0+0=1)')
  assertEqual(pannaToAnk('000'), 10, 'pannaToAnk("000") = 10 (0→10)')

  assertEqual(normalizeDigitSet('321'), '123', 'normalizeDigitSet("321") = "123"')
  assertEqual(normalizeDigitSet('112'), '112', 'normalizeDigitSet("112") = "112"')
  assertEqual(normalizeDigitSet('111'), '111', 'normalizeDigitSet("111") = "111"')
}

// ────────────────────────────────────────────────────────────────────────────
// 8. Universe size verification
// ────────────────────────────────────────────────────────────────────────────
section('Universe sizes')

{
  assertEqual(SP_SET.size, 120, 'SP universe has 120 pannas')
  assertEqual(DP_SET.size, 90, 'DP universe has 90 pannas')
  assertEqual(TP_SET.size, 10, 'TP universe has 10 pannas')
  assertEqual(SP_SET.size + DP_SET.size + TP_SET.size, 220, 'Total = 220 pannas')
}

// ────────────────────────────────────────────────────────────────────────────
// Summary
// ────────────────────────────────────────────────────────────────────────────
console.log(`\n${'═'.repeat(60)}`)
console.log(`RESULTS: ${passed} passed, ${failed} failed`)
console.log(`${'═'.repeat(60)}`)

if (failed > 0) {
  process.exit(1)
}
