#!/bin/bash
# Build a portable zip of the ERP + Customer App project for VS Code.
# Excludes node_modules, .next, .git, sandbox-only dirs; patches .env to a portable relative path.
set -euo pipefail

PROJ=/home/z/my-project
STAGE=/home/z/my-project/zipstage
APPDIR="$STAGE/erp-customer-app"
OUT="$PROJ/download/Satta_Matka_God_VSCode_Hostinger_2026-10-06-v1.zip"

rm -rf "$STAGE"
mkdir -p "$APPDIR"
cd "$PROJ"

# --- directories to ship ---
for d in src prisma db public scripts examples; do
  cp -r "$d" "$APPDIR/"
done

# --- root files to ship ---
for f in package.json bun.lock tsconfig.json next.config.ts tailwind.config.ts \
         postcss.config.mjs eslint.config.mjs components.json next-env.d.ts \
         Caddyfile .gitignore README.md ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md worklog.md; do
  cp "$f" "$APPDIR/"
done

# --- portable .env (sandbox used an absolute path; relative works via src/lib/db.ts resolver) ---
cat > "$APPDIR/.env" <<'EOF'
# SQLite database — relative to the project root (resolved by src/lib/db.ts at runtime)
DATABASE_URL=file:./db/custom.db
EOF

# --- .env.example (referenced by README but missing in the sandbox) ---
cat > "$APPDIR/.env.example" <<'EOF'
# SQLite database (relative to project root; resolved by src/lib/db.ts)
DATABASE_URL=file:./db/custom.db

# Required in production — set strong random secrets
# SESSION_SECRET=change-me-to-a-long-random-string
# CRON_SECRET=change-me-too
# ADMIN_GATE_SECRET=rotates-the-super-admin-gate-token (/g/<token>)
EOF

# --- VS Code quick-start ---
cat > "$APPDIR/SETUP_IN_VSCODE.md" <<'EOF'
# Quick Start — Open in VS Code

A ready-to-run snapshot of **Satta Matka God** (ERP + Customer Android App +
WhatsApp Management panel)
(Next.js 16 · React 19 · Prisma 6 · SQLite · Tailwind 4 · shadcn/ui).

## Requirements

- Node.js 20+ (or Bun 1.1+)
- VS Code with recommended extensions: ESLint, Tailwind CSS IntelliSense, Prisma

## Run it

```bash
# 1. install dependencies
npm install            # or: bun install

# 2. generate the Prisma client
npx prisma generate    # or: bun run db:generate

# 3. start the dev server
npm run dev            # or: bun run dev
```

Open http://localhost:3000

| Route | What it is |
|---|---|
| `/` | Public landing — app download + the one encrypted admin entry (footer "·") |
| `/merp` | Admin ERP (markets, inventory, entries, results, settlement, games, charts) |
| `/app` | Customer App (bets, wallet, results, 4 languages) |
| `/g/<token>` | Encrypted super-admin entry → redirects to `/merp`; wrong token = 404 |
| `/download` | Redirects to `/` (kept so previously shared links/QRs keep working) |

### Super-admin encrypted link (operator brief: ONE encrypted entry)

The landing page shows no admin button. The super admin uses:

    http://your-domain/g/<token>

`<token>` = HMAC-SHA256(ADMIN_GATE_SECRET, "super-admin-login") base64url —
computed by the app itself (the discreet "·" in the landing footer carries it).
Default works out of the box; rotate by setting `ADMIN_GATE_SECRET` in `.env`
(see `.env.example`) — the token changes with the secret.

## Demo logins (from the shipped pre-seeded database)

| System | Account | Password |
|---|---|---|
| ERP Super Admin | `superadmin@mb.com` | `SAdmin@123_321` |
| ERP Manager | `admin@mb.com` | `Admin@123_321` |
| ERP Agent | `agent@mb.com` | `Agent@123_321` |
| Customer App | `9812345601` (Rahul) | `Rahul@123` |

### Agent play-commission demo (pre-seeded in the shipped database)

Agent **agentsanjay** (Sanjay Surana — your existing account) has 3 customers,
each with an approved deposit and real plays. **No global rate is set — the
built-in default 2% applies** (operator rule 2026-10: default 2%; set your own
percentage in Commission Settings and it takes over). Deposits never earn;
every PLAY files exactly one idempotent commission row:

| Customer (Customer App login) | Deposit | Played | Commission @2% |
|---|---|---|---|
| Rakesh Sharma `9876500001` / `Demo@123` | 4000 | 10000 (2000 → win 10000 → play 8000) | 200 |
| Dinesh Joshi `9876500002` / `Demo@123` | 5000 | 1500 | 30 |
| Mahesh Verma `9876500003` / `Demo@123` | 6000 | 2500 | 50 |
| **Total** | 15000 | **14000** | **₹280 pending** |

View it in ERP ▸ App Wallet ▸ **Agent Commission** (Super Admin: all agents,
Commission Settings, customer-wise rollup; agent login: "My Commission" own
ledger only). Re-run the demo anytime: `node scripts/seed-agentsanjay-demo.mjs`
(idempotent, server must be running on :3000).

## Database notes

- SQLite file ships at `db/custom.db` — no seeding required for first run.
- `.env` uses `DATABASE_URL=file:./db/custom.db`; `src/lib/db.ts` resolves it
  against the project root at runtime (works regardless of where you start the server).
- Schema changes use `prisma db push` (no migrations folder). If you run
  `npx prisma db push`, note the Prisma CLI resolves relative `file:` paths against
  `prisma/` — use an absolute path in `.env` for CLI operations if needed.
- Optional reseed from scratch: `npm run db:push` then `npm run db:seed` and
  `node scripts/seed-app.js`.

## Regression suites (optional, Bun — start the dev server first)

```bash
bun scripts/test-entry-parser.ts            # 72 parser + dictionary checks
bun scripts/test-games-engine.ts            # 113 games-engine + expander checks (incl. operator 20/30/40 chart tables)
bun scripts/probe-whatsapp-samples.ts       # 6 operator WhatsApp blocks → totals
bun scripts/test-signup-approval-toggle.ts  # 17 signup-approval toggle checks
bun scripts/test-agent-commission.ts        # 56 play-commission checks (deposits never earn, default 2%)
bun scripts/test-agent-access-control.ts    # 58 RBAC matrix + data-isolation checks
bun scripts/test-whatsapp-pipeline.ts       # 116 intake + approval pipeline checks
bun scripts/test-whatsapp-panel.ts          # 37 WhatsApp Management panel checks
bun scripts/test-chitthi-render.ts          # 4 chitthi JPG render checks
```

## Hostinger / domain deployment + Android APK

See `download/Customer_App_Android_APK_and_Hosting_Guide.docx` (also in the
project delivery folder): domain + HTTPS hosting steps, the exact three-point
configuration change when moving from a preview URL to your domain, the full
Capacitor APK build (icon, splash, signing, release), and publishing the APK
to `public/downloads/satta-matka-god.apk` for the landing download button.

**Signup approval toggle** — ERP ▸ Customer List header (Super Admin only):
ON = new app signups wait for approval (default); OFF = instant access.

## WhatsApp Management panel (replaces the old WhatsApp Inbox)

A dedicated sidebar section with six pages — the whole WhatsApp channel in
one place:

| Page | What it does |
|---|---|
| WhatsApp Dashboard | Channel KPIs, 7-day activity, approval funnel, top customers, bot evolution, reply latency, computed optimization suggestions, sandbox simulator |
| Messages | Per-customer / per-group conversation management with full audit detail and failed-reply retry |
| Templates | Message templates in Meta's categories (utility / marketing / authentication); the 4 BOT REPLY slots (vyapar_ack, tx_success, rejection_notice, invalid_notice) override the built-in bot replies when activated; send any active template to a customer with {{variable}} fields |
| Approvals | Pending vyapar queue → approve (creates the ERP transaction, confirmation sent after commit) or reject with reason; approved transactions + rejected messages with full audit |
| Bot Learning | Unknown patterns → define rule → test on history → activate (parser version bump); evolution stats |
| Customer/Group Mapping | Provider Group ID → exactly ONE customer (super admin only) |

Template defaults ship INACTIVE — the canonical built-in replies stay in
effect until you activate a template.

> **Note:** the former Hisab section (New Hisab / Hisab Records / Customer
> Hisab) was removed by operator decision — settlement happens at the
> customer/agent level. The Settlement table and its historical rows remain
> in the database untouched.
>
> The public website is now the single download landing (`/`) per operator
> brief — the old marketing pages (`/landing`, `/marketing`), the Landing
> Config feature and the public ERP demo-signup were removed. The product is
> branded **Satta Matka God** throughout.

## Production build

```bash
npm run build
npm run start
```

Full documentation: [`ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md`](./ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md)
and [`README.md`](./README.md).
EOF

# --- zip it ---
mkdir -p "$PROJ/download"
rm -f "$OUT"
cd "$STAGE"
zip -rq "$OUT" erp-customer-app

# --- verify ---
echo "=== integrity ==="
unzip -tqq "$OUT" && echo "OK: zip integrity verified"
echo "=== stats ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== top-level layout ==="
unzip -l "$OUT" | awk '{print $4}' | grep -v '^$' | cut -d/ -f1-2 | sort -u | head -25

# cleanup staging
rm -rf "$STAGE"
echo "DONE: $OUT"
