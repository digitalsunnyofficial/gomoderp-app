/**
 * test-admin-notify.ts — master-admin App Notifications management.
 *
 * Covers the /api/app-admin/notifications surface + its customer-visible
 * effect through /api/customer-app/notifications:
 *
 *  1. Unauth guards            (GET/POST/DELETE without session → 401)
 *  2. Super GET                (counts, agents list, broadcast history)
 *  3. Broadcast 'all'          (customerId:null row — every customer sees it)
 *  4. Customer sees broadcast  (demo customer notifications contains it)
 *  5. Targeted 'customer'      (single personal row)
 *  6. Targeted 'agent'         (per-customer rows for one agent's customers)
 *  7. Validation               (empty text → 400, bad audience → 400,
 *                               agent without agentUsername → 400)
 *  8. Retract DELETE           (broadcast removed from the app list)
 *  9. Audit + self-cleanup     (no leftover rows — demo state pristine)
 *
 * Run: bun scripts/test-admin-notify.ts   (live server on :3000)
 */
import { PrismaClient } from '@prisma/client'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const MARKER = 'zznotify-test-broadcast'
const MARKER2 = 'zznotify-test-personal'
const MARKER3 = 'zznotify-test-agent'

async function main() {
  console.log('\n══ App Notifications — master-admin composer + push ══\n')

  // ── 1. Unauth guards ──
  const g1 = await fetch(`${BASE}/api/app-admin/notifications`)
  check('1  GET without session → 401', g1.status === 401, `got ${g1.status}`)
  const p1 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: 'x' }),
  })
  check('1b POST without session → 401', p1.status === 401, `got ${p1.status}`)
  const d1 = await fetch(`${BASE}/api/app-admin/notifications?id=zzz`, { method: 'DELETE' })
  check('1c DELETE without session → 401', d1.status === 401, `got ${d1.status}`)

  // ── 2. Super session + GET shape ──
  const login = await fetch(`${BASE}/api/auth`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'superadmin@mb.com', password: 'SAdmin@123_321' }),
  })
  const cookie = (login.headers.get('set-cookie') || '').split(';')[0]
  check('2  ERP super login ok', login.status === 200 && !!cookie, `status ${login.status}`)

  const get1 = await fetch(`${BASE}/api/app-admin/notifications`, { headers: { Cookie: cookie } })
  const get1j = await get1.json() as {
    broadcasts: Array<{ id: string; icon: string; text: string; createdAt: string }>
    counts: { total: number; approved: number; pending: number; pushRegistered: number; pushEnabled: boolean }
    agents: Array<{ username: string; name: string | null; customers: number }>
  }
  check('2b GET returns broadcasts + counts + agents',
    get1.status === 200 && Array.isArray(get1j.broadcasts) && !!get1j.counts && Array.isArray(get1j.agents),
    `status ${get1.status}`)

  // demo agent known from seed (agentsanjay) should appear if it has customers
  const demoAgent = get1j.agents.find(a => a.username === 'agentsanjay')
  check('2c agent list includes agentsanjay with >0 customers',
    !!demoAgent && demoAgent.customers > 0, JSON.stringify(get1j.agents))

  // ── 3. Broadcast to ALL ──
  const post1 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ text: MARKER, icon: 'party', audience: 'all' }),
  })
  const post1j = await post1.json() as { ok: boolean; notified: string; push: { skipped: boolean; delivered: number } }
  check('3  POST audience=all → ok, broadcast row', post1.status === 200 && post1j.ok && typeof post1j.notified === 'string',
    JSON.stringify(post1j))

  const row = await db.appNotification.findFirst({ where: { customerId: null, text: MARKER } })
  check('3b customerId:null broadcast row written with icon', !!row && row.icon === 'party', JSON.stringify(row))

  // ── 4. Demo customer sees the broadcast in the app ──
  const custLogin = await fetch(`${BASE}/api/customer-app/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mobile: '9876500001', password: 'Demo@123' }),
  })
  const custLoginj = await custLogin.json() as { token?: string }
  check('4  demo customer login', custLogin.status === 200 && !!custLoginj.token, `status ${custLogin.status}`)
  const H = { Authorization: `Bearer ${custLoginj.token}` }
  const notifs = await fetch(`${BASE}/api/customer-app/notifications`, { headers: H })
  const notifsj = await notifs.json() as { notifications: Array<{ text: string; icon: string }> }
  check('4b broadcast visible in customer notifications',
    notifsj.notifications.some(n => n.text === MARKER && n.icon === 'party'),
    `count=${notifsj.notifications?.length}`)

  // ── 5. Targeted single customer ──
  const demoCust = await db.appCustomer.findUnique({ where: { mobile: '9876500001' } })
  const post2 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ text: MARKER2, icon: 'bell', audience: 'customer', customerId: demoCust?.id }),
  })
  const post2j = await post2.json() as { ok: boolean; notified: number; push: { skipped: boolean } }
  check('5  POST audience=customer → notified 1', post2.status === 200 && post2j.ok && post2j.notified === 1,
    JSON.stringify(post2j))
  const row2 = await db.appNotification.findFirst({ where: { customerId: demoCust?.id, text: MARKER2 } })
  check('5b personal row written', !!row2)

  // ── 6. Targeted agent audience ──
  const post3 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ text: MARKER3, audience: 'agent', agentUsername: 'agentsanjay' }),
  })
  const post3j = await post3.json() as { ok: boolean; notified: number }
  const agentCustCount = await db.appCustomer.count({ where: { agentUsername: 'agentsanjay' } })
  check('6  POST audience=agent → notified == agent customer count',
    post3.status === 200 && post3j.ok && post3j.notified === agentCustCount,
    `got ${post3j.notified}, expected ${agentCustCount}`)

  // ── 7. Validation ──
  const v1 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ text: '   ', audience: 'all' }),
  })
  check('7  empty text → 400', v1.status === 400, `got ${v1.status}`)
  const v2 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ text: 'x', audience: 'everyone' }),
  })
  check('7b bad audience → 400', v2.status === 400, `got ${v2.status}`)
  const v3 = await fetch(`${BASE}/api/app-admin/notifications`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ text: 'x', audience: 'agent' }),
  })
  check('7c agent audience without agentUsername → 400', v3.status === 400, `got ${v3.status}`)

  // ── 8. Retract broadcast ──
  const del = await fetch(`${BASE}/api/app-admin/notifications?id=${row?.id}`, {
    method: 'DELETE', headers: { Cookie: cookie },
  })
  check('8  DELETE broadcast → ok', del.status === 200, `got ${del.status}`)
  const goneRow = await db.appNotification.findUnique({ where: { id: row?.id } })
  check('8b broadcast row removed', !goneRow)
  const notifs2 = await fetch(`${BASE}/api/customer-app/notifications`, { headers: H })
  const notifs2j = await notifs2.json() as { notifications: Array<{ text: string }> }
  check('8c customer no longer sees the broadcast', !notifs2j.notifications.some(n => n.text === MARKER))

  // ── 9. Self-cleanup (no demo pollution) ──
  const del2 = await db.appNotification.deleteMany({ where: { text: { in: [MARKER2, MARKER3] } } })
  check('9  cleanup: personal + agent rows removed', del2.count === agentCustCount + 1, `deleted ${del2.count}`)
  const left = await db.appNotification.count({ where: { text: { startsWith: 'zznotify' } } })
  check('9b zero zznotify rows left', left === 0, `left ${left}`)

  console.log(`\n${pass} PASS / ${fail} FAIL`)
  if (fail > 0) process.exitCode = 1
  await db.$disconnect()
}

main().catch(async e => {
  console.error('FATAL:', e)
  // best-effort cleanup so a crash never leaves fixtures behind
  await db.appNotification.deleteMany({ where: { text: { startsWith: 'zznotify' } } }).catch(() => {})
  await db.$disconnect()
  process.exitCode = 1
})
