// WhatsApp input-channel pipeline acceptance test (bun) — v3, intake + approval.
// Runs the REAL pipeline against the REAL database in sandbox mode
// (no Meta credentials → replies stored as "sandbox"). Every temp row is
// cleaned up at the end.
//
// v2 coverage (legacy auto mode — AppConfig whatsapp_approval = off):
//   • only registered customers engage (unregistered → rejected)
//   • clean vyapar → Transaction (sequential ID) + atomic lines + raw text
//   • documented confirmation format + customer → agent attribution
//   • Del / Result / Bal commands, idempotent redelivery
// v3 coverage (approval mode ON — the spec default):
//   • valid vyapar → Pending Approval ONLY (no ERP record) + ack reply
//   • approve → transaction created → reply sent AFTER commit (doc format)
//   • reject → no transaction, original message + audit intact
//   • group chats: Group ID → mapped customer, sender stored separately,
//     unregistered group rejected, Del refused from groups
//   • forwarded messages: original sender resolved, team member recorded
//   • invalid input → precise reason, never a transaction
//   • learning candidates: capture → define → test on history → activate
//     (ParserTerm + parser_version bump — never automatic)
//   • failed outbound reply retried separately (transaction never duplicated)
import { db } from '../src/lib/db'
import {
  processInbound,
  approveWhatsAppApproval,
  rejectWhatsAppApproval,
  retryOutbound,
  getParserVersion,
} from '../src/lib/whatsapp/pipeline'

let pass = 0, fail = 0
function check(name: string, cond: boolean, extra = '') {
  if (cond) { pass++; console.log(`PASS  ${name} ${extra}`) }
  else { fail++; console.error(`FAIL  ${name} ${extra}`) }
}

const TEST_MOBILE = '9123456780' // dedicated test number (10 digits)
const TEST_PHONE_CC = '919123456780' // same number with 91 country code
const VENDOR_MOBILE = '9123456781' // dedicated vendor test number
const AGENT_USERNAME = 'wa-test-agent'
const GROUP_ID = '120363999888777'   // numeric provider Group ID (group chat target)
const UNMAPPED_GROUP = '999777666555'
const TEAM_MOBILE = '91999900001'

// ── Setup: temp registered customer (filed under a temp agent) + temp agent + vendor ──
const bcrypt = await import('bcryptjs')
const agent = await db.user.create({
  data: {
    username: AGENT_USERNAME,
    name: 'Vaid Test Agent',
    password: await bcrypt.hash('agentpass123', 8),
    role: 'user',
    status: 'active',
  },
})
const customer = await db.appCustomer.create({
  data: {
    name: 'WA Test Customer',
    mobile: TEST_MOBILE,
    password: await bcrypt.hash('testpass123', 8),
    wallet: 0,
    approvalStatus: 'approved',
    referral: AGENT_USERNAME,
    agentUsername: AGENT_USERNAME,
    agentName: 'Vaid Test Agent',
  },
})
const vendor = await db.vendor.create({
  data: {
    code: 'WATEST1',
    businessName: 'WA Test Vendor',
    mobileNo: VENDOR_MOBILE,
    createdBy: AGENT_USERNAME, // agent-added ERP customer
  },
})

let txCount = () => db.whatsAppTransaction.count({
  where: { OR: [{ customerId: customer.id }, { vendorId: vendor.id }] },
})

async function setApprovalMode(mode: 'on' | 'off') {
  await db.appConfig.upsert({
    where: { key: 'whatsapp_approval' },
    create: { key: 'whatsapp_approval', value: mode === 'on' ? 'on' : 'off' },
    update: { value: mode === 'on' ? 'on' : 'off' },
  })
}

// Legacy auto mode first (sections 1-15), then the v3 approval suite (16+).
await setApprovalMode('off')

try {
  // ── 1. Unregistered number ──
  const r1 = await processInbound({ phone: '9000000001', text: 'Milan\n128=75' })
  check('1 unregistered → rejected', r1.status === 'rejected', r1.status)
  check('1 unregistered reply text', r1.reply.includes('not registered'), r1.reply.split('\n')[0])
  const in1 = await db.whatsAppMessage.findUnique({ where: { id: r1.inboundId! } })
  check('1 inbound stored rejected', in1?.status === 'rejected' && in1.error === 'unregistered number')
  const out1 = await db.whatsAppMessage.findUnique({ where: { id: r1.outboundId! } })
  check('1 reply stored sandbox', out1?.direction === 'out' && out1.status === 'sandbox')
  check('1 no transaction for unregistered', await txCount() === 0)

  // ── 2. Registered customer, simple vyapar → TRANSACTION in documented format ──
  const r2 = await processInbound({
    phone: TEST_PHONE_CC,
    profileName: 'WA Tester',
    text: `Milan day\n128=75\n139=75\n35=100\ntotal 250`,
    waMessageId: 'wamid.TEST2',
  })
  check('2 processed', r2.status === 'processed', r2.status)
  check('2 market resolved Milan Day', r2.marketName === 'Milan Day', r2.marketName)
  check('2 doc format: Transaction Successful', r2.reply.includes('1 ==> Transaction Successful'), r2.reply.split('\n')[0])
  check('2 doc format: Transaction ID line', /Transaction ID := \d+/.test(r2.reply), '')
  check('2 doc format: Total 250', r2.reply.includes('Milan Day = Total 250'), r2.reply.split('\n')[3])
  check('2 doc format: Grand Total', r2.reply.includes('Grand Total 250'), '')
  check('2 expanded entries listed', r2.reply.includes('128=75 139=75') && r2.reply.includes('35=100'), '')
  check('2 attribution: customer + agent', r2.reply.includes('Customer := WA Test Customer (Agent: Vaid Test Agent)'), '')
  check('2 txNumber returned', typeof r2.txNumber === 'number' && r2.txNumber > 0, String(r2.txNumber))
  const txA = await db.whatsAppTransaction.findUnique({ where: { txNumber: r2.txNumber! } })
  check('2 transaction stored', !!txA && txA.total === 250 && txA.customerId === customer.id, '')
  check('2 agent snapshot on transaction', txA?.agentUsername === AGENT_USERNAME && txA.agentName === 'Vaid Test Agent', '')
  check('2 raw message stored', !!txA && txA.rawMessage.includes('total 250') && txA.rawMessage.includes('128=75'), '')
  check('2 market snapshot', !!txA?.marketCode && txA.marketName === 'Milan Day', `${txA?.marketCode}`)
  const linesA = await db.whatsAppTransactionLine.findMany({ where: { txId: txA!.id } })
  check('2 atomic lines = 3', linesA.length === 3, String(linesA.length))
  check('2 line kinds single/double/triple', linesA.some(l => l.kind === 'triple') && linesA.some(l => l.kind === 'double'), linesA.map(l => l.kind).join(','))
  check('2 lines money conserved', linesA.reduce((s, l) => s + l.amount, 0) === 250, String(linesA.reduce((s, l) => s + l.amount, 0)))

  // ── 3. Operator's real Block 5 through the channel (money invariant, bucket listing) ──
  const r3 = await processInbound({
    phone: TEST_PHONE_CC,
    text: `Milan open motor\n23457890,100\n12345678,100`,
    waMessageId: 'wamid.TEST3',
  })
  check('3 processed', r3.status === 'processed')
  check('3 motor money 11200 (bucket listing >30 entries)', r3.reply.includes('Motor Pana: 92 nos = ₹11200'), r3.reply.split('\n').find(l => l.includes('Motor')) || '')
  check('3 doc format: Total 11200', r3.reply.includes('Milan Day (Open) = Total 11200'), '')
  check('3 session detected open', r3.reply.includes('(Open)'), '')

  // ── 4. Idempotency — Meta redelivery creates NO duplicate transaction ──
  const before4 = await txCount()
  const r4 = await processInbound({
    phone: TEST_PHONE_CC,
    text: `Milan\n128=75`,
    waMessageId: 'wamid.TEST3',
  })
  check('4 duplicate detected', r4.status === 'duplicate', r4.status)
  const dupCount = await db.whatsAppMessage.count({ where: { waMessageId: 'wamid.TEST3' } })
  check('4 exactly one inbound row for wamid', dupCount === 1, String(dupCount))
  check('4 no duplicate transaction', await txCount() === before4, `${before4} → ${await txCount()}`)

  // ── 5. No market in message → no transaction ──
  const r5 = await processInbound({ phone: TEST_PHONE_CC, text: '128=75\n139=75', waMessageId: 'wamid.TEST5' })
  check('5 rejected no-market', r5.status === 'rejected' && r5.reason === 'no market found in message')
  check('5 reply lists markets', r5.reply.includes('Available markets') && r5.reply.includes('Milan'), '')

  // ── 6. Market but unreadable vyapar → no transaction ──
  const r6 = await processInbound({ phone: TEST_PHONE_CC, text: 'Kalyan\nhello good morning', waMessageId: 'wamid.TEST6' })
  check('6 rejected unreadable', r6.status === 'rejected' && r6.reply.includes('could not read any vyapar'))

  // ── 7. Rate-assumption + Grand Total accumulation ──
  const r7 = await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\n128\n139', waMessageId: 'wamid.TEST7' })
  check('7 processed with assumed rate note', r7.status === 'processed' && r7.reply.includes('rate assumed ₹100'), '')
  check('7 Grand Total accumulates (250+11200+200)', r7.reply.includes('Grand Total 11650'), r7.reply.split('\n').find(l => l.includes('Grand')) || '')

  // ── 8. Inbox rows shape ──
  const inbox = await db.whatsAppMessage.findMany({
    where: { phone: { in: ['9000000001', TEST_PHONE_CC] } },
    orderBy: { createdAt: 'asc' },
  })
  check('8 in+out rows persisted', inbox.filter(m => m.direction === 'in').length >= 5 && inbox.filter(m => m.direction === 'out').length >= 5,
    `in=${inbox.filter(m => m.direction === 'in').length} out=${inbox.filter(m => m.direction === 'out').length}`)

  // ── 9. Del — void own transaction (audit-safe) ──
  const r9 = await processInbound({ phone: TEST_PHONE_CC, text: `Del ${r2.txNumber}`, waMessageId: 'wamid.TEST9' })
  check('9 del accepted', r9.status === 'processed' && r9.reply.includes(`Deleted Successful — Transaction ID ${r2.txNumber} Deleted`), r9.reply)
  const txAAfter = await db.whatsAppTransaction.findUnique({ where: { txNumber: r2.txNumber! } })
  check('9 transaction voided not deleted', txAAfter?.status === 'deleted' && txAAfter.deletedBy === TEST_PHONE_CC, txAAfter?.status)
  check('9 lines preserved after void', await db.whatsAppTransactionLine.count({ where: { txId: txAAfter!.id } }) === 3)

  // ── 10. Del — unknown ID and already-deleted ID → no mutation ──
  const r10a = await processInbound({ phone: TEST_PHONE_CC, text: 'Del 999999', waMessageId: 'wamid.TEST10a' })
  check('10 unknown ID rejected', r10a.status === 'rejected' && r10a.reply.includes('Transaction 999999 not found'), r10a.reply.split('\n')[0])
  const r10b = await processInbound({ phone: TEST_PHONE_CC, text: `Del ${r2.txNumber}`, waMessageId: 'wamid.TEST10b' })
  check('10 already-deleted ID rejected', r10b.status === 'rejected' && r10b.reply.includes('not found'), '')

  // ── 11. Bal — report excludes deleted, groups by market ──
  const r11 = await processInbound({ phone: TEST_PHONE_CC, text: 'Bal', waMessageId: 'wamid.TEST11' })
  check('11 bal processed', r11.status === 'processed' && r11.reply.includes('Balance Report'), r11.reply.split('\n')[0])
  check('11 bal excludes deleted (11400 = 11200+200)', r11.reply.includes('Total Sale 11400'), r11.reply.split('\n').find(l => l.includes('Total Sale')) || '')
  check('11 bal lists Milan Day', r11.reply.includes('Milan Day'), '')

  // ── 12. Result — pending first, then the declared card ──
  const milanCode = inbox.find(m => m.marketName === 'Milan Day')?.marketCode || 'milan'
  const r12a = await processInbound({ phone: TEST_PHONE_CC, text: 'Result Milan', waMessageId: 'wamid.TEST12a' })
  check('12 result without declaration → wait', r12a.status === 'processed' && r12a.reply.includes('not declared yet'), r12a.reply.split('\n')[0])
  await db.appResult.create({
    data: {
      marketCode: milanCode, marketName: 'Milan Day', resultDate: new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10),
      openPanna: '128', openDigit: '3', closePanna: '479', closeDigit: '0', jodi: '30',
      declaredBy: 'wa-test',
    },
  })
  const r12b = await processInbound({ phone: TEST_PHONE_CC, text: 'Result Milan', waMessageId: 'wamid.TEST12b' })
  check('12 result card open', r12b.reply.includes('Open: 128-3'), r12b.reply.split('\n')[1] || '')
  check('12 result card close', r12b.reply.includes('Close: 479-0'), '')
  await db.appResult.deleteMany({ where: { marketCode: milanCode, declaredBy: 'wa-test' } })

  // ── 13. Invalid command → syntax guidance, no transaction ──
  const before13 = await txCount()
  const r13 = await processInbound({ phone: TEST_PHONE_CC, text: 'Del', waMessageId: 'wamid.TEST13' })
  check('13 invalid command guidance', r13.status === 'rejected' && r13.reply.includes('Supported commands'), '')
  check('13 no transaction from commands', await txCount() === before13)

  // ── 14. Vendor path — agent-added ERP customer with attribution ──
  const r14 = await processInbound({
    phone: VENDOR_MOBILE,
    text: 'Kalyan\n12=50',
    waMessageId: 'wamid.TEST14',
  })
  check('14 vendor processed', r14.status === 'processed', r14.status)
  check('14 vendor attribution in reply', r14.reply.includes('Customer := WA Test Vendor (Agent: Vaid Test Agent)'), '')
  const txV = await db.whatsAppTransaction.findFirst({ where: { vendorId: vendor.id } })
  check('14 vendor transaction stored', !!txV && txV.total === 50 && txV.agentUsername === AGENT_USERNAME, '')
  const r14b = await processInbound({ phone: VENDOR_MOBILE, text: `Del ${txV?.txNumber}`, waMessageId: 'wamid.TEST14b' })
  check('14 vendor can void own transaction', r14b.status === 'processed' && r14b.reply.includes('Deleted Successful'), '')

  // ── 15. Cross-customer protection — vendor cannot del the app customer's tx ──
  const r15 = await processInbound({ phone: VENDOR_MOBILE, text: `Del ${r3.txNumber}`, waMessageId: 'wamid.TEST15' })
  check('15 foreign del rejected', r15.status === 'rejected' && r15.reply.includes('not found'), '')
  const txBAfter = await db.whatsAppTransaction.findUnique({ where: { txNumber: r3.txNumber! } })
  check('15 foreign tx untouched', txBAfter?.status === 'active', txBAfter?.status)

  // ════════════════════════════════════════════════════════════
  // v3 — INTAKE & APPROVAL SUITE (AppConfig whatsapp_approval = on)
  // ════════════════════════════════════════════════════════════
  await setApprovalMode('on')
  await db.whatsAppGroupMapping.create({
    data: { groupId: GROUP_ID, groupLabel: 'WA Test Group (label only)', vendorId: vendor.id, createdBy: 'wa-test' },
  })

  const approvalCount = () => db.whatsAppApproval.count()

  // ── 16. Valid vyapar → PENDING APPROVAL only, NO ERP record ──
  const before16 = await txCount()
  const r16 = await processInbound({
    phone: TEST_PHONE_CC,
    profileName: 'WA Tester',
    text: `Milan day\n128=75\n139=75\n35=100\ntotal 250`,
    waMessageId: 'wamid.T16',
  })
  check('16 status pending_approval', r16.status === 'pending_approval', r16.status)
  check('16 NO transaction created', await txCount() === before16, `${before16} → ${await txCount()}`)
  check('16 ack reply is NOT a success claim', !r16.reply.includes('Transaction Successful') && r16.reply.includes('pending approval'), r16.reply.split('\n')[0])
  check('16 ack carries parsed total', r16.reply.includes('Total: ₹250'), '')
  const in16 = await db.whatsAppMessage.findUnique({ where: { id: r16.inboundId! } })
  check('16 inbound row status pending_approval', in16?.status === 'pending_approval', in16?.status)
  check('16 inbound stores parserVersion', (in16?.parserVersion ?? 0) >= 1, String(in16?.parserVersion))
  const appr16 = await db.whatsAppApproval.findUnique({ where: { messageId: r16.inboundId! } })
  check('16 approval row pending', appr16?.status === 'pending', appr16?.status)
  check('16 approval has agent attribution', appr16?.agentUsername === AGENT_USERNAME, `${appr16?.agentUsername}`)
  check('16 immutable parsed snapshot stored', (appr16?.parsedSnapshot || '').includes('"singles"'), '')
  check('16 raw message on approval', !!appr16 && appr16.rawMessage.includes('total 250'), '')
  check('16 validation ok (no warnings)', appr16?.validationStatus === 'ok', `${appr16?.validationStatus}`)

  // ── 17. Approve → ERP transaction + documented reply AFTER commit ──
  const versionBefore17 = await getParserVersion()
  const out17 = await approveWhatsAppApproval(appr16!.id, 'superadmin')
  check('17 approve ok', out17.ok && typeof out17.txNumber === 'number', String(out17.txNumber))
  check('17 transaction created', await txCount() === before16 + 1, `${before16} → ${await txCount()}`)
  const tx17 = await db.whatsAppTransaction.findUnique({ where: { txNumber: out17.txNumber! } })
  check('17 tx total 250 + attribution', !!tx17 && tx17.total === 250 && tx17.customerId === customer.id && tx17.agentUsername === AGENT_USERNAME, '')
  const appr17 = await db.whatsAppApproval.findUnique({ where: { id: appr16!.id } })
  check('17 approval approved with by/at', appr17?.status === 'approved' && appr17?.approvedBy === 'superadmin' && !!appr17?.approvedAt, '')
  check('17 approval links tx', appr17?.txId === tx17?.id && appr17?.txNumber === out17.txNumber, '')
  const reply17 = await db.whatsAppMessage.findFirst({ where: { replyToId: r16.inboundId!, direction: 'out' }, orderBy: { createdAt: 'desc' } })
  check('17 reply sent AFTER commit in doc format', !!reply17 && reply17.body.includes('1 ==> Transaction Successful') && reply17.body.includes(`Transaction ID := ${out17.txNumber}`) && reply17.body.includes('Grand Total'), reply17?.body.split('\n')[0])
  check('17 reply carries agent attribution', !!reply17 && reply17.body.includes('(Agent: Vaid Test Agent)'), '')
  const in17 = await db.whatsAppMessage.findUnique({ where: { id: r16.inboundId! } })
  check('17 inbound now processed', in17?.status === 'processed', in17?.status)
  check('17 parser version unchanged (no rule change)', await getParserVersion() === versionBefore17, '')
  const lines17 = await db.whatsAppTransactionLine.findMany({ where: { txId: tx17!.id } })
  check('17 atomic lines created on approval (3)', lines17.length === 3, String(lines17.length))

  // double-approve refused (idempotent decisions)
  const out17b = await approveWhatsAppApproval(appr16!.id, 'superadmin')
  check('17 double-approve refused', !out17b.ok && (out17b.error || '').includes('already'), out17b.error)
  check('17 no duplicate transaction', await txCount() === before16 + 1, '')

  // ── 18. Reject → no transaction, original message + audit intact ──
  const r18 = await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\n45=abc test', waMessageId: 'wamid.T18' })
  // "45=abc test" — 45=abc has non-numeric amount; parser may skip → total may be 0 → rejected at validation.
  // Force a parseable-but-rejectable vyapar instead: valid numbers, then admin rejects.
  const r18b = await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\n77=60\n88=40', waMessageId: 'wamid.T18b' })
  check('18 valid vyapar pends', r18b.status === 'pending_approval', r18b.status)
  const appr18 = await db.whatsAppApproval.findUnique({ where: { messageId: r18b.inboundId! } })
  const before18 = await txCount()
  const out18 = await rejectWhatsAppApproval(appr18!.id, 'superadmin', 'Entry 77 looks wrong — resend the correct jodi.')
  check('18 reject ok', out18.ok, out18.error)
  check('18 NO transaction from rejection', await txCount() === before18, `${before18} → ${await txCount()}`)
  const appr18After = await db.whatsAppApproval.findUnique({ where: { id: appr18!.id } })
  check('18 approval rejected with reason', appr18After?.status === 'rejected' && (appr18After.rejectionReason || '').includes('77'), '')
  const in18 = await db.whatsAppMessage.findUnique({ where: { id: r18b.inboundId! } })
  check('18 original message intact', !!in18 && in18.body.includes('77=60') && in18.status === 'rejected', in18?.status)
  const out18r = await db.whatsAppMessage.findFirst({ where: { replyToId: r18b.inboundId!, direction: 'out' }, orderBy: { createdAt: 'desc' } })
  check('18 rejection notice sent to chat', !!out18r && out18r.body.includes('was not accepted') && out18r.body.includes('77'), out18r?.body.split('\n')[0])

  // ── 19. Duplicate provider message ID in approval mode ──
  const before19 = await approvalCount()
  await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\n22=30', waMessageId: 'wamid.T19' })
  const r19dup = await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\n22=30', waMessageId: 'wamid.T19' })
  check('19 duplicate detected', r19dup.status === 'duplicate', r19dup.status)
  check('19 exactly one approval row', await approvalCount() === before19 + 1, `${before19} → ${await approvalCount()}`)

  // ── 20. Group chat: Group ID → mapped customer, sender stored separately ──
  const r20 = await processInbound({
    phone: GROUP_ID, // group chat target
    groupId: GROUP_ID,
    senderPhone: '91888880001',
    senderName: 'Group Member Ravi',
    text: 'Milan\n100=50',
    waMessageId: 'wamid.T20',
  })
  check('20 group message pends', r20.status === 'pending_approval', r20.status)
  const appr20 = await db.whatsAppApproval.findUnique({ where: { messageId: r20.inboundId! } })
  check('20 customer = mapped vendor', appr20?.vendorId === vendor.id && appr20.customerName === 'WA Test Vendor', appr20?.customerName)
  check('20 sender stored SEPARATELY', appr20?.senderPhone === '91888880001' && appr20.senderName === 'Group Member Ravi', `${appr20?.senderPhone}`)
  check('20 group id on approval', appr20?.groupId === GROUP_ID, '')
  const out20 = await approveWhatsAppApproval(appr20!.id, 'superadmin')
  const tx20 = await db.whatsAppTransaction.findUnique({ where: { txNumber: out20.txNumber! } })
  check('20 approved tx attributed to group customer', !!tx20 && tx20.vendorId === vendor.id && tx20.total === 50, '')
  const out20r = await db.whatsAppMessage.findFirst({ where: { replyToId: r20.inboundId!, direction: 'out' }, orderBy: { createdAt: 'desc' } })
  check('20 confirmation reply to the GROUP', !!out20r && out20r.phone === GROUP_ID && out20r.body.includes(`Transaction ID := ${out20.txNumber}`), out20r?.phone)

  // ── 21. Unregistered group → precise rejection, no approval/tx ──
  const before21 = await approvalCount()
  const r21 = await processInbound({ phone: UNMAPPED_GROUP, groupId: UNMAPPED_GROUP, senderPhone: '91888880002', text: 'Milan\n111=25', waMessageId: 'wamid.T21' })
  check('21 unmapped group rejected', r21.status === 'rejected' && r21.reply.includes('group is not registered'), r21.reply.split('\n')[0])
  check('21 precise error names the group', (r21.reason || '').includes(UNMAPPED_GROUP), r21.reason)
  check('21 no approval row for unmapped group', await approvalCount() === before21, '')

  // ── 22. Del from a group → refused (ownership ambiguity) ──
  const r22 = await processInbound({ phone: GROUP_ID, groupId: GROUP_ID, senderPhone: '91888880001', text: `Del ${out20.txNumber}`, waMessageId: 'wamid.T22' })
  check('22 del refused from group', r22.status === 'rejected' && r22.reply.includes('group members cannot delete'), r22.reply.split('\n')[0])
  const tx20After = await db.whatsAppTransaction.findUnique({ where: { id: tx20!.id } })
  check('22 group tx untouched', tx20After?.status === 'active', tx20After?.status)

  // ── 23. Forwarded by the pickup team → original sender resolved ──
  const r23 = await processInbound({
    phone: TEAM_MOBILE, // the team member who forwarded
    forwardedFrom: TEST_MOBILE, // original sender metadata preserved
    senderPhone: TEAM_MOBILE,
    text: 'Kalyan\n11=25',
    waMessageId: 'wamid.T23',
  })
  check('23 forwarded message pends', r23.status === 'pending_approval', r23.status)
  const appr23 = await db.whatsAppApproval.findUnique({ where: { messageId: r23.inboundId! } })
  check('23 customer = ORIGINAL sender', appr23?.customerId === customer.id && appr23.customerName === 'WA Test Customer', appr23?.customerName)
  check('23 team member recorded as sender', appr23?.senderPhone === TEAM_MOBILE, `${appr23?.senderPhone}`)
  const in23 = await db.whatsAppMessage.findUnique({ where: { id: r23.inboundId! } })
  check('23 forwardedFrom stored on raw row', in23?.forwardedFrom === TEST_MOBILE && in23?.senderPhone === TEAM_MOBILE, `${in23?.forwardedFrom}`)

  // ── 24. Invalid input → precise reason, NEVER a transaction/approval ──
  const before24 = await approvalCount()
  const r24 = await processInbound({ phone: TEST_PHONE_CC, text: 'Kalyan\nhello good morning friends', waMessageId: 'wamid.T24' })
  check('24 unreadable rejected', r24.status === 'rejected', r24.status)
  check('24 precise reason stored', (r24.reason || '').includes('no readable vyapar'), r24.reason)
  check('24 no approval for invalid input', await approvalCount() === before24, `${before24} → ${await approvalCount()}`)

  // ── 25. Learning library: capture → define → test → activate ──
  const versionBefore25 = await getParserVersion()
  const r25 = await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\nwamalang\n128=75', waMessageId: 'wamid.T25' })
  check('25 unknown label still parses valid vyapar', r25.status === 'pending_approval', r25.status)
  const cand25 = await db.parserLearningLog.findFirst({ where: { rawInput: { contains: 'wamalang' } }, orderBy: { createdAt: 'desc' } })
  check('25 learning candidate captured', !!cand25 && cand25.source === 'whatsapp', `${cand25?.rawInput} / ${cand25?.status}`)
  check('25 candidate NOT auto-applied', cand25?.status === 'pending' && !cand25.activatedTermId, `${cand25?.status}`)
  const d25 = await db.parserLearningLog.update({ where: { id: cand25!.id }, data: { ruleDefinition: JSON.stringify({ term: 'wamalang', category: 'common' }), status: 'reviewed' } })
  check('25 rule defined (term + category)', !!JSON.parse(d25.ruleDefinition!).term, '')
  const matched25 = await db.whatsAppMessage.count({ where: { direction: 'in', body: { contains: 'wamalang' } } })
  check('25 historical messages available for testing', matched25 >= 1, String(matched25))
  // activate path (mirrors the API route): ParserTerm created + version bump + candidate applied
  const term25 = await db.parserTerm.create({ data: { term: 'wamalang', category: 'common', note: 'learned from WhatsApp: "wamalang"', createdBy: 'wa-test' } })
  await db.parserLearningLog.update({ where: { id: cand25!.id }, data: { status: 'applied', activatedTermId: term25.id } })
  check('25 activated → ParserTerm created', !!term25, '')
  const applied25 = await db.parserLearningLog.findUnique({ where: { id: cand25!.id } })
  check('25 candidate applied + audit linked', applied25?.status === 'applied' && applied25.activatedTermId === term25.id, applied25?.status)

  // ── 26. Failed outbound reply retried separately — transaction never duplicated ──
  const r26 = await processInbound({ phone: TEST_PHONE_CC, text: 'Milan\n50=25', waMessageId: 'wamid.T26' })
  check('26 vyapar pends', r26.status === 'pending_approval', r26.status)
  const appr26 = await db.whatsAppApproval.findUnique({ where: { messageId: r26.inboundId! } })
  const out26 = await approveWhatsAppApproval(appr26!.id, 'superadmin')
  check('26 approve ok', out26.ok && out26.txNumber! > 0, String(out26.txNumber))
  const before26 = await txCount()
  const reply26 = await db.whatsAppMessage.findFirst({ where: { replyToId: r26.inboundId!, direction: 'out' }, orderBy: { createdAt: 'desc' } })
  await db.whatsAppMessage.update({ where: { id: reply26!.id }, data: { status: 'failed', error: 'Graph API 500 (simulated)' } })
  const retry26 = await retryOutbound(reply26!.id)
  check('26 retry ok (sandbox)', retry26.ok && retry26.status === 'sandbox', retry26.status)
  check('26 NO second transaction after retry', await txCount() === before26, `${before26} → ${await txCount()}`)
  const retry26b = await retryOutbound(reply26!.id)
  check('26 re-retry of delivered reply refused', !retry26b.ok && (retry26b.error || '').includes('already'), retry26b.error)

  // ── 27. Legacy auto mode still available (toggle back off) ──
  await setApprovalMode('off')
  const r27 = await processInbound({ phone: TEST_PHONE_CC, text: 'Kalyan\n13=75', waMessageId: 'wamid.T27' })
  check('27 legacy auto tx works', r27.status === 'processed' && r27.reply.includes('1 ==> Transaction Successful'), r27.status)
  check('27 auto tx created without approval', await txCount() > before16, '')
} finally {
  // ── Cleanup: remove everything this test created (FK-safe order) ──
  const testPhones = ['9000000001', TEST_PHONE_CC, VENDOR_MOBILE, TEAM_MOBILE, GROUP_ID, UNMAPPED_GROUP]
  const testMessages = await db.whatsAppMessage.findMany({ where: { phone: { in: testPhones } }, select: { id: true } })
  const testMessageIds = testMessages.map(m => m.id)
  await db.whatsAppApproval.deleteMany({ where: { messageId: { in: testMessageIds } } })
  await db.whatsAppTransactionLine.deleteMany({ where: { tx: { OR: [{ customerId: customer.id }, { vendorId: vendor.id }] } } })
  await db.whatsAppTransaction.deleteMany({ where: { OR: [{ customerId: customer.id }, { vendorId: vendor.id }] } })
  await db.whatsAppMessage.deleteMany({ where: { phone: { in: testPhones } } })
  await db.whatsAppGroupMapping.deleteMany({ where: { groupId: { in: [GROUP_ID, UNMAPPED_GROUP] } } })
  await db.parserTerm.deleteMany({ where: { term: 'wamalang' } })
  await db.parserLearningLog.deleteMany({ where: { OR: [{ rawInput: { contains: 'wamalang' } }, { firstMessageId: { in: testMessageIds } }] } })
  await db.appConfig.deleteMany({ where: { key: { in: ['whatsapp_approval', 'parser_version'] } } })
  await db.appResult.deleteMany({ where: { declaredBy: 'wa-test' } })
  await db.appCustomer.delete({ where: { id: customer.id } }).catch(() => undefined)
  await db.vendor.delete({ where: { id: vendor.id } }).catch(() => undefined)
  await db.user.delete({ where: { id: agent.id } }).catch(() => undefined)
  console.log('\ncleanup done (approvals, messages, transactions, mapping, learning, config, temp customer/vendor/agent removed)')
}

console.log(`\n${pass} PASS / ${fail} FAIL`)
process.exit(fail ? 1 : 0)
