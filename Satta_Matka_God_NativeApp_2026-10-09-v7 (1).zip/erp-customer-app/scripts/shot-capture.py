# shot-capture.py — photograph every screen of the customer app (web build =
# the UI source of truth, identical to the native app) for the landing-page
# customer guide. Phone viewport 390x844 @2x. Requires fixtures:
#   bun scripts/shot-fixtures.ts up
#   python3 scripts/shot-capture.py
#   bun scripts/shot-fixtures.ts down
import os, sys, time
from playwright.sync_api import sync_playwright

BASE = 'http://localhost:3000'
OUT = '/home/z/my-project/public/how-it-works'
os.makedirs(OUT, exist_ok=True)

A_MOBILE = '9912900001'
A_PASS = 'Shot@12345'

def shot(page, name):
    page.wait_for_timeout(700)  # settle animations/fonts
    page.screenshot(path=f'{OUT}/{name}.png')
    print('  shot', name)

def kill_portal(page):
    # remove the Next.js dev overlay portal — it intercepts pointer events
    page.evaluate("""() => { document.querySelectorAll('nextjs-portal').forEach(e => e.remove()) }""")

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(
        viewport={'width': 390, 'height': 844},
        device_scale_factor=2,
        user_agent='Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36',
        locale='en-IN',
    )
    page = ctx.new_page()
    page.goto(BASE + '/app', wait_until='networkidle')
    kill_portal(page)

    # ── 1. login (with pre-login language chips) ──
    page.wait_for_selector('input[inputmode="numeric"]', timeout=30000)
    shot(page, '01-login')

    # ── 2. register form ──
    kill_portal(page)
    page.get_by_text('New here?').click()
    page.wait_for_selector('input[placeholder="Your name"]', timeout=10000)
    shot(page, '02-register')
    kill_portal(page)
    page.get_by_text('BACK TO LOGIN').click()
    page.wait_for_selector('input[inputmode="numeric"]', timeout=10000)

    # ── 3. login as fixture customer A → (maybe) language ask → home ──
    kill_portal(page)
    page.fill('input[inputmode="numeric"]', A_MOBILE)
    kill_portal(page)
    page.fill('input[type="password"]', A_PASS)
    kill_portal(page)
    page.click('button.btn-g')
    page.wait_for_selector('.prow-i, .appbar', timeout=20000)  # lang ask OR home
    if page.locator('.prow-i').count():                        # first login: ask shows
        time.sleep(0.6)
        if not os.path.exists(f'{OUT}/03-lang-ask.png'):
            shot(page, '03-lang-ask')
        page.locator('.prow-i', has_text='English').first.click()
        page.wait_for_selector('.appbar', timeout=20000)
    page.wait_for_selector('.mcard2', timeout=20000)
    time.sleep(1.2)
    shot(page, '04-home')

    # ── 4. play screen (Milan Star = accepting temp market) ──
    page.locator('.mcard2', has_text='MILAN STAR').first.click()
    page.wait_for_selector('.gtab', timeout=15000)
    time.sleep(1.0)
    shot(page, '05-play-single')

    # jodi tab view
    page.locator('.gtab', has_text='Jodi').first.click()
    page.wait_for_timeout(500)
    shot(page, '06-play-jodi')
    page.locator('.gtab', has_text='Single Digit').first.click()
    page.wait_for_timeout(400)

    # ── 5. fill tiles → slip → confirm modal ──
    tiles = page.locator('.tile input')
    tiles.nth(0).fill('20')
    tiles.nth(1).fill('10')
    tiles.nth(5).fill('10')
    page.wait_for_timeout(400)
    kill_portal(page)
    page.locator('.slip button.btn-g').click()
    page.wait_for_selector('.overlay .modal', timeout=10000)
    shot(page, '07-slip-confirm')
    page.locator('.overlay .modal button', has_text='CANCEL').first.click()
    page.wait_for_timeout(400)
    # clear the slip for later shots
    slip_clear = page.locator('.slip button', has_text='Clear all')
    if slip_clear.count():
        slip_clear.first.click()
    # leave the play screen via its back chevron (2nd .ibtn in the subbar —
    # the 1st opens the chart modal)
    kill_portal(page)
    page.locator('.subbar .ibtn').nth(1).click()
    page.wait_for_selector('.bnav', timeout=10000)

    # ── 6. starline screen (hides bottom nav → leave via its back chevron) ──
    kill_portal(page)
    page.locator('.btab').nth(1).click()
    page.wait_for_timeout(900)
    shot(page, '08-starline')
    kill_portal(page)
    page.locator('.subbar .ibtn').nth(0).click()
    page.wait_for_selector('.bnav', timeout=10000)

    # ── 7. my bids ──
    kill_portal(page)
    page.locator('.btab').nth(2).click()
    page.wait_for_selector('.appbar', timeout=10000)
    time.sleep(1.0)
    shot(page, '09-mybids')

    # ── 8. results & charts (4 tabs) ──
    kill_portal(page)
    page.locator('.btab').nth(3).click()
    page.wait_for_selector('.tab', timeout=10000)
    time.sleep(1.0)
    shot(page, '10-results')
    kill_portal(page)
    page.locator('button.tab', has_text='Jodi Chart').click()
    time.sleep(0.8)
    shot(page, '11-jodi-chart')
    kill_portal(page)
    page.locator('button.tab', has_text='Panel Chart').click()
    time.sleep(0.8)
    shot(page, '12-panel-chart')
    page.locator('button.tab', has_text='Starline').last.click()
    time.sleep(0.8)
    shot(page, '13-starline-board')

    # ── 9. profile ──
    kill_portal(page)
    page.locator('.btab').nth(4).click()
    page.wait_for_selector('.appbar', timeout=10000)
    time.sleep(0.8)
    shot(page, '14-profile')

    # ── 10. wallet ──
    kill_portal(page)
    page.locator('.btab').nth(0).click()
    page.wait_for_selector('.wchip', timeout=10000)
    kill_portal(page)
    page.locator('.wchip').click()
    page.wait_for_selector('.wcard', timeout=10000)
    time.sleep(1.0)
    shot(page, '15-wallet')

    # withdraw modal
    page.locator('.wbtns button', has_text='Withdraw').first.click()
    page.wait_for_selector('.overlay', timeout=10000)
    shot(page, '16-withdraw-modal')
    kill_portal(page)
    page.locator('.overlay h3 button').click()
    page.wait_for_timeout(400)

    # deposit modal (business QR)
    page.locator('.wbtns button', has_text='Add Points').first.click()
    page.wait_for_selector('.overlay', timeout=10000)
    time.sleep(1.0)
    shot(page, '17-deposit-modal')
    kill_portal(page)
    page.locator('.overlay h3 button').click()
    page.wait_for_timeout(400)

    # ── 11. notifications ──
    kill_portal(page)
    page.locator('.btab').nth(0).click()
    page.wait_for_selector('.ibtn', timeout=10000)
    kill_portal(page)
    page.locator('.ibtn').click()
    page.wait_for_selector('.appbar', timeout=10000)
    time.sleep(0.8)
    shot(page, '18-notifications')

    # ── 12. logout → signup as a fresh mobile → await-approval wall ──
    kill_portal(page)
    page.locator('.btab').nth(4).click()
    page.wait_for_timeout(600)
    logout = page.get_by_text('Log out')
    if not logout.count():
        logout = page.get_by_text('Logout')
    logout.first.click()
    page.wait_for_selector('input[inputmode="numeric"]', timeout=10000)

    kill_portal(page)
    page.get_by_text('New here?').click()
    page.wait_for_selector('input[placeholder="Your name"]', timeout=10000)
    kill_portal(page)
    page.fill('input[placeholder="Your name"]', 'Prem Patel')
    kill_portal(page)
    page.fill('input[placeholder="10-digit mobile"]', '9912900002')
    kill_portal(page)
    page.locator('input[type="password"]').nth(0).fill('Shot@12345')
    kill_portal(page)
    page.locator('input[type="password"]').nth(1).fill('Shot@12345')
    kill_portal(page)
    page.locator('button.btn-g').click()
    page.wait_for_timeout(1500)
    shot(page, '19-await-approval')

    browser.close()
    print('done →', OUT)
