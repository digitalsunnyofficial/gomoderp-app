import { BUILT_IN_TERMS, GROUP_OPTION_ORDER } from '../src/lib/matka/term-registry'
const byCat: Record<string, string[]> = {}
for (const t of BUILT_IN_TERMS) (byCat[t.category] ||= []).push(t.term)
for (const [c, terms] of Object.entries(byCat)) console.log(c + ': ' + terms.length + ' → ' + terms.join(', '))
console.log('TOTAL built-in terms:', BUILT_IN_TERMS.length)
console.log('GROUP_OPTION_ORDER:', GROUP_OPTION_ORDER.length, 'options')
const noAlias = GROUP_OPTION_ORDER.filter(o => !(byCat[o]?.length))
console.log('Group options with NO built-in alias:', JSON.stringify(noAlias))
