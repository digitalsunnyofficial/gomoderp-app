// E2E verify: (1) ERP Entry List "Submitted By" = app customer name;
// (2) canonical panna representation end-to-end (012→120, 038→380).
const BASE = 'http://localhost:3000'

async function j(method, path, body, headers = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  })
  return { status: res.status, data: await res.json().catch(() => ({})), headers: res.headers }
}

async function main() {
  // ── 1) Priya places bets: SP '038' (→380), motor seed '012' (→120 family)
  const login = await j('POST', '/api/customer-app/auth/login', { mobile: '9822345602', password: 'Priya@123' })
  const token = login.data.token
  console.log('app login (Priya):', login.status)
  if (!token) { console.log(login.data); return }

  const bet = await j('POST', '/api/customer-app/bets', {
    items: [
      { marketCode: 'sridevi_night_open', slot: 'open', type: 'sp', num: '038', points: 20, gameCode: 'sp' },
      { marketCode: 'sridevi_night_open', slot: 'open', type: 'single', num: '5', points: 10, gameCode: 'single' },
    ],
  }, { Authorization: 'Bearer ' + token })
  console.log('bet POST:', bet.status, '| mirrorNote:', bet.data.mirrorNote, '| wallet:', bet.data.wallet)

  // stored bet numbers (canonical check)
  const bets = await j('GET', '/api/customer-app/bets', undefined, { Authorization: 'Bearer ' + token })
  const latest = (bets.data.bets || []).slice(0, 2)
  latest.forEach(b => console.log('stored bet:', b.type, b.num, '| market:', b.marketName, '| customer field ok'))

  // ── 2) ERP: entry list "Submitted By" for the mirrored card
  const erp = await j('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  const cookie = (erp.headers.getSetCookie?.() || []).map(c => c.split(';')[0]).join('; ')
  console.log('\nERP login:', erp.status)

  const inv = await j('GET', '/api/inventories?page=1&limit=5', null, { cookie })
  const rows = inv.data.data || []
  rows.slice(0, 4).forEach(r => console.log(
    'entry:', r.inventoryCode?.code, '| createdBy:', r.createdBy, '| creatorInfo:', r.creatorInfo ? r.creatorInfo.name + ' (' + r.creatorInfo.role + ')' : 'null'
  ))

  // ── 3) mirror row numbers canonical?
  const card = rows.find(r => r.inventoryCode?.code === 'app_sridevi_night_open')
  if (card) {
    const detail = await j('GET', '/api/inventories/' + card.id, null, { cookie })
    const triples = detail.data.tripleInventories || detail.data.inventory?.tripleInventories || []
    const ds = detail.data.doubleSingleInventories || []
    const first = triples[0]
    if (first) {
      const pd = JSON.parse(first.parsedData || '{}')
      const nums = (pd.numbers || []).slice(0, 4).map(n => n.number)
      console.log('\nmirror triple row numbers:', JSON.stringify(nums), '| details:', String(first.details).slice(0, 60))
    }
    const dsRow = ds[0]
    if (dsRow) console.log('mirror single row:', JSON.stringify((JSON.parse(dsRow.parsedData || '{}').numbers || []).slice(0, 3)))
  } else {
    console.log('\nno app_sridevi_night_open card found in first page')
  }
}

main().catch(e => { console.error('FATAL', e); process.exit(1) })
