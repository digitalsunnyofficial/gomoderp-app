#!/bin/bash
# One-shot E2E: start server → browser-verify the WhatsApp panel → screenshots → stop server.
set -uo pipefail
cd /home/z/my-project
mkdir -p download
pkill -f "next dev -p 3000" 2>/dev/null; pkill -f agent-browser 2>/dev/null; sleep 1
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP"; break; fi
done
[ "$UP" != "1" ] && { echo "FATAL: no server"; tail -20 /tmp/devserver.log; exit 1; }
curl -s -o /dev/null -w "merp warm: %{http_code}\n" http://localhost:3000/merp --max-time 180

agent-browser open http://localhost:3000/merp 2>&1 | tail -1
agent-browser wait --load networkidle 2>&1 | tail -1
# login
agent-browser snapshot -i -c 2>&1 | grep -E "textbox|button" | head -6
agent-browser find label "Email or Username" fill "superadmin@mb.com" 2>/dev/null || agent-browser fill @e3 "superadmin@mb.com" 2>/dev/null || true
agent-browser snapshot -i -c > /tmp/wa-snap.txt 2>&1
user_ref=$(grep -oE '@e[0-9]+' /tmp/wa-snap.txt | head -1)
echo "snapshot saved"

# Try robust login via labels/positions
agent-browser find textbox fill "superadmin@mb.com" --nth 0 2>/dev/null || true
agent-browser snapshot -i -c 2>&1 | head -12
