// guide-content-b.js — chapters 5–8 of the Deployment & Operations Guide.
const { h1, h2, h3, p, pMono, bullet, tblTitle, tbl, figure, caption } = require("./guide-helpers");

function chaptersB() {
  const out = [];

  // ══ 5. PART C — NOTIFICATIONS FROM MASTER ADMIN ══
  out.push(h1("5. Part C — Managing App Notifications from the Master Admin"));
  out.push(h1("5.1 The App Notifications Panel"));
  out.push(p(["Notifications for the native app are composed and controlled entirely from the ERP: log in at /merp as the super admin and open App Wallet ▸ App Notifications. The panel shows a live audience snapshot — total customers, approved, pending approval and push-registered devices — followed by a compose card and the broadcast history. Access is master-admin only by design: the sidebar entry, the page route and the API all enforce the super role, so agents and managers cannot message your customers."]));
  out.push(p(["Sending is a single action. Choose an audience, pick a style, write the message (up to 500 characters) and press Send. Every recipient instantly gets the message in the app's Notifications screen, and every customer whose phone has a registered push token also receives a system push notification — the banner that appears even when the app is closed. The result message reports exactly what happened, for example \"4 customer(s), push delivered to 3 device(s)\"."]));
  out.push(tblTitle("Table 5: Audience choices and their delivery semantics"));
  out.push(tbl(
    ["Audience", "Who receives it", "In-app delivery"],
    [
      ["All customers", "Everyone, present and future signups", "One broadcast entry visible in every customer's Notifications list"],
      ["Approved only", "All approved accounts", "Personal copies per customer"],
      ["Pending approval", "Signups awaiting your approval", "Personal copies — useful to nudge them while they wait"],
      ["One agent's customers", "Everyone filed under a chosen agent", "Personal copies per customer in that agent's tree"],
      ["Single customer", "One account found by name or mobile", "One personal message"],
    ],
    [24, 38, 38]
  ));
  out.push(p(["The style picker sets the icon customers see next to the message: megaphone for announcements, party popper for promotions, trophy for results, sparkles for special notes, warning triangle for important notices and the plain bell for general messages. These names are shared by the web app and the native app icon maps, so a notification renders identically everywhere. Broadcast history lists every message with its timestamp and a retract control; retracting removes the in-app entry from all customers, though pushes already delivered to lock screens cannot be recalled."]));
  out.push(h1("5.2 How the Push Chain Works"));
  out.push(p(["The delivery path is: ERP panel → /api/app-admin/notifications → in-app rows in the database → Expo Push API (exp.host) → Firebase Cloud Messaging → the customer's phone. The app registers each device once via POST /api/customer-app/push/register, and the stored token is what the backend sends to. The server needs no Firebase credentials at all — the app's google-services.json plus the EAS project id carry that side, exactly as documented in SETUP_NATIVE_APP.md §3. Until that one-time setup is done, the panel still works: messages appear in-app, pushes are skipped, and the panel shows a push-disabled banner. Setting PUSH_ENABLED=false in the backend .env forces the same behaviour at any time; it is the safe kill switch."]));
  out.push(h1("5.3 Everything Else the Master Admin Manages"));
  out.push(p(["Notifications are the newest lever, and they sit beside the full set of app-management controls the ERP already provides. The table below is the operator's map from \"what the customer experiences in the app\" to \"where the master admin controls it\"."]));
  out.push(tblTitle("Table 6: Native-app experience → ERP control"));
  out.push(tbl(
    ["What the customer sees in the app", "Where the master admin controls it (ERP)"],
    [
      ["Markets with open/close times, countdowns", "Market Management ▸ Markets (timings, weekly schedule, status)"],
      ["Which games and rates appear in a market", "Market Management ▸ Game Management + Game Allocation (per-market rate and min-point overrides)"],
      ["Declared results, charts, starline board", "Market Management ▸ Market Results / Chart Data / Starlines; per-bid settle in Entry ▸ App Bids"],
      ["Wallet balance, deposit approval, withdrawals", "App Wallet ▸ Payment Management (deposits, withdrawal payouts, business QR settings)"],
      ["Signup approval, blocking, bet/withdraw flags", "User Management ▸ Customer List / App Customers"],
      ["Agent filings and play commission", "App Wallet ▸ Agent Commission (global and per-agent rates, ledgers)"],
      ["Home notice marquee, banners, deposit account details", "App content configuration (notice text, slider banners, UPI details, default agent) via the app-config API"],
      ["Push and in-app notifications", "App Wallet ▸ App Notifications (this part)"],
    ],
    [46, 54]
  ));

  // ══ 6. PART D — LANDING PAGE GUIDE ══
  out.push(h1("6. Part D — Landing Page Customer Guide and Screenshots"));
  out.push(h1("6.1 What the Landing Page Now Teaches"));
  out.push(p(["The landing page at / is no longer only a download button. It is a complete self-service guide in four layers. The hero section carries the download call-to-action with an availability probe: the button turns to a ready-state only when the APK file is actually published, so a customer can never hit a dead link. Below it, four highlight cards summarise what the app does — live markets, the UPI wallet, the built-in games and the four languages. The section \"How the App Works — 5 Easy Steps\" then walks the customer from install to payout in plain language: download and install, register, pick a language, add points through UPI, play and withdraw."]));
  out.push(p(["The centrepiece is the Complete Screenshot Guide: nineteen real captures of the app — the actual native build, not mock-ups — grouped into five sections with explanatory text. Getting Started shows login, registration, the approval-pending wall and the language chooser; Home & Playing shows the home screen, the play screen, number picking and the confirm slip; Results & Charts shows results, the jodi chart with repeating-number highlighting, the panel chart and the starline board; Wallet shows the balance card, the add-points and withdraw modals and notifications; My Bids & Profile closes the loop. An Installation Help section answers the three questions that actually come up — the Play Protect warning, reinstalling without losing the account, and allowing notifications."]));
  out.push(figure("public/how-it-works/04-home.png", 780, 1688, 165));
  out.push(caption("Figure 1: Home screen capture shown on the landing page — real native app, web-identical UI"));
  out.push(h1("6.2 The Screenshot Set"));
  out.push(p(["The nineteen captures live in public/how-it-works/ with stable numbered filenames (01-login … 19-await-approval), so the page references never change; replacing a PNG with a new capture of the same name updates the guide after a redeploy. The same set is delivered to you as Native_App_Screenshots_2026-10-08.zip for sharing on WhatsApp or any channel — it covers every screen of the native app: login, register, language ask, home, play (single and jodi), slip confirm, starline, my bids, results, jodi chart, panel chart, starline board, wallet, withdraw, deposit, notifications, profile and await-approval."]));

  // ══ 7. VERIFICATION ══
  out.push(h1("7. Post-Deployment Verification Checklist"));
  out.push(p(["After the server is live, run this checklist top to bottom — it takes about ten minutes and exercises every layer described above. The route checks come straight from the workspace's automated battery (scripts/flow-live-test.ts plus ten regression suites plus the notification suite — 563 passing checks in total), so if the manual checklist passes, the same code paths have already passed their automated equivalents."]));
  out.push(tblTitle("Table 7: Go-live verification checklist"));
  out.push(tbl(
    ["#", "Check", "Expected"],
    [
      ["1", "Open https://godmoderp.online/", "Landing page loads with screenshot gallery; download button shows ready-state once the APK is published"],
      ["2", "Open /merp and log in", "ERP dashboard with the App Wallet section visible"],
      ["3", "Open /customerapp on a phone", "Download page serves the APK; install and open the app"],
      ["4", "Register a test customer in the app", "Approval-pending wall appears"],
      ["5", "Approve the signup in ERP ▸ Customer List", "App proceeds to language choice and home"],
      ["6", "Add points: pay the business QR, submit amount + UTR", "Request appears in Payment Management"],
      ["7", "Approve the deposit in the ERP", "Wallet updates in the app within seconds; notification appears"],
      ["8", "Place a bid in any open market; declare the result in App Bids", "Bid settles; win credited if selected; result notification pushed"],
      ["9", "Request a withdrawal; mark it paid in the ERP", "Hold → paid lifecycle correct; notification pushed"],
      ["10", "Send a broadcast from App Wallet ▸ App Notifications", "In-app entry for every customer; push banner on registered devices"],
    ],
    [6, 44, 50]
  ));
  out.push(p(["One caution on data: the shipped demo database contains eleven demo customers and a pending demo commission of ₹280 at 2% for the agentsanjay account. It exists so you can verify flows before go-live. Replace it with a clean production database (or your migrated data) as described in §4.8, and never demo on the live domain after customers have real balances."]));

  // ══ 8. APPENDIX ══
  out.push(h1("8. Appendix — Key Files and Commands Reference"));
  out.push(h1("8.1 Files You Will Touch Most"));
  out.push(tblTitle("Table 8: File map for deployment and operations"));
  out.push(tbl(
    ["File / folder", "What it is"],
    [
      ["satta-matka-god-native/app.json", "App identity, version, versionCode, apiBase, EAS project id — edit before every release build"],
      ["satta-matka-god-native/SETUP_NATIVE_APP.md", "The APK manual: prerequisites, Firebase push setup, debug/release builds, publishing"],
      ["satta-matka-god-native/UPDATE_FROM_V1.md", "Short replace-list for upgrading older installs"],
      ["src/lib/config.ts", "Reads apiBase and the EAS id from app.json at runtime"],
      ["src/components/public/DownloadCta.tsx", "Download button: APK path probe + APP_VERSION shown to customers"],
      ["src/app/customerapp/page.tsx", "The /customerapp download page (install steps, Play Protect note)"],
      ["public/downloads/", "Where the signed APK must be placed (satta-matka-god.apk)"],
      ["public/how-it-works/", "The 19 landing-page screenshots (numbered, stable filenames)"],
      ["src/app/api/app-admin/notifications/route.ts", "Notification API: broadcast, targeted send, retract; super-admin guarded"],
      ["src/components/pages/AppNotificationsPage.tsx", "The ERP composer UI behind App Wallet ▸ App Notifications"],
      ["scripts/one-shot-task35.sh", "Full verification battery: start server, 563 checks, teardown"],
    ],
    [40, 60]
  ));
  out.push(h1("8.2 Command Cheat-Sheet"));
  out.push(tblTitle("Table 9: Everyday commands"));
  out.push(tbl(
    ["Task", "Command"],
    [
      ["Run the system locally", "npm run dev   → http://localhost:3000"],
      ["Build for production", "npm run build"],
      ["Serve production build", "npm start   (standalone server on :3000, under PM2 in production)"],
      ["Apply schema to a fresh DB", "npx prisma db push"],
      ["Run the native app in dev", "cd satta-matka-god-native && npx expo start"],
      ["Regenerate android/ after config change", "npm run prebuild"],
      ["Build the release APK", "cd android && ./gradlew assembleRelease"],
      ["Full verification battery", "bash scripts/one-shot-task35.sh"],
      ["Backup the database", "cp db/prod.db backups/prod-$(date +%F).db"],
    ],
    [42, 58]
  ));
  out.push(p(["Treat this document as the living runbook for the deployment: when a procedure changes, update the matching section here in the same round so the guide and the system never drift apart. The workspace worklog (worklog.md) records every delivered change task-by-task and remains the detailed history behind this summary."]));

  return out;
}

module.exports = { chaptersB };
