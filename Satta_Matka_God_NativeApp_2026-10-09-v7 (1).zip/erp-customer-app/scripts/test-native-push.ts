/**
 * test-native-push.ts — Task 31: push registration endpoints + expo-push lib.
 *
 * Self-contained: creates a TEMP super user (not needed for the endpoints but
 * keeps the harness identical to the other suites) and a TEMP customer, then:
 *
 *  1. Unauth guards: GET/POST/DELETE /api/customer-app/push/register → 401
 *  2. GET  (authed)  → registered:false, enabled:true
 *  3. POST invalid token ("abc") → 400
 *  4. POST valid ExpoPushToken   → ok:true; DB pushToken set
 *  5. GET  → registered:true
 *  6. POST second-format token (ExpoPushToken[...]) → replaces value (trimmed)
 *  7. DELETE → registered:false; DB pushToken null
 *  8. Lib (PUSH_ENABLED=false): sendExpoPush → skipped:true, no network;
 *     notifyCustomer still writes the AppNotification row and never throws
 *  9. pushEnabled(): env kill switch respected
 * 10. Cleanup: temp customer + notifications + sessions + temp super user
 *
 * Run: bun scripts/test-native-push.ts   (server must be on :3000)
 */
import { PrismaClient } from '@prisma/client'

process.env.PUSH_ENABLED = 'false' // keep the lib offline for the unit checks

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const MOBILE = '9900000031'

async function main() {
  console.log('\n══ Task 31 — native app push ══\n')

  // ── Temp customer (direct DB create, approved) ──
  await db.appCustomer.deleteMany({ where: { mobile: MOBILE } })
  const cust = await db.appCustomer.create({
    data: {
      name: 'Push Test', mobile: MOBILE, password: 'x-not-used', wallet: 0,
      approvalStatus: 'approved', status: 'active',
    },
  })
  const session = await db.appSession.create({
    data: {
      customerId: cust.id,
      token: 'push-test-token-' + Date.now(),
      expiresAt: new Date(Date.now() + 3600_000),
    },
  })
  const H = { Authorization: 'Bearer ' + session.token, 'Content-Type': 'application/json' }

  // ── 1. Unauth guards ──
  const g1 = await fetch(`${BASE}/api/customer-app/push/register`)
  check('1a GET without token → 401', g1.status === 401, `got ${g1.status}`)
  const g2 = await fetch(`${BASE}/api/customer-app/push/register`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: 'x' }),
  })
  check('1b POST without token → 401', g2.status === 401, `got ${g2.status}`)
  const g3 = await fetch(`${BASE}/api/customer-app/push/register`, { method: 'DELETE' })
  check('1c DELETE without token → 401', g3.status === 401, `got ${g3.status}`)

  // ── 2-5. Register flow ──
  const r0 = await fetch(`${BASE}/api/customer-app/push/register`, { headers: H })
  const r0j = await r0.json() as { registered: boolean; enabled: boolean }
  check('2 initial GET → registered:false, enabled:true',
    r0.status === 200 && r0j.registered === false && r0j.enabled === true, JSON.stringify(r0j))

  const bad = await fetch(`${BASE}/api/customer-app/push/register`, {
    method: 'POST', headers: H, body: JSON.stringify({ token: 'abc' }),
  })
  check('3 invalid token → 400', bad.status === 400, `got ${bad.status}`)

  const T1 = 'ExponentPushToken[aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee]'
  const ok = await fetch(`${BASE}/api/customer-app/push/register`, {
    method: 'POST', headers: H, body: JSON.stringify({ token: '  ' + T1 + ' ' }),
  })
  const okj = await ok.json() as { ok: boolean }
  check('4 valid token → ok', ok.status === 200 && okj.ok === true, JSON.stringify(okj))
  const after = await db.appCustomer.findUnique({ where: { id: cust.id }, select: { pushToken: true } })
  check('4b DB stores trimmed token', after?.pushToken === T1, after?.pushToken || 'null')

  const r1 = await fetch(`${BASE}/api/customer-app/push/register`, { headers: H })
  check('5 GET → registered:true', ((await r1.json()) as { registered: boolean }).registered === true)

  // ── 6. Second format replaces ──
  const T2 = 'ExpoPushToken[zzzzzzzz-yyyy-xxxx-wwww-vvvvvvvvvvvv]'
  await fetch(`${BASE}/api/customer-app/push/register`, {
    method: 'POST', headers: H, body: JSON.stringify({ token: T2 }),
  })
  const after2 = await db.appCustomer.findUnique({ where: { id: cust.id }, select: { pushToken: true } })
  check('6 re-register replaces token', after2?.pushToken === T2, after2?.pushToken || 'null')

  // ── 7. Deregister ──
  const del = await fetch(`${BASE}/api/customer-app/push/register`, { method: 'DELETE', headers: H })
  const after3 = await db.appCustomer.findUnique({ where: { id: cust.id }, select: { pushToken: true } })
  check('7 DELETE → cleared',
    del.status === 200 && ((await del.json()) as { registered: boolean }).registered === false
      && after3?.pushToken === null,
    after3?.pushToken || 'null')

  // ── 8-9. Lib behaviour with PUSH_ENABLED=false (import AFTER env set) ──
  const { sendExpoPush, notifyCustomer, pushEnabled } = await import('../src/lib/push/expo-push')
  check('9 pushEnabled() false under kill switch', pushEnabled() === false)
  const sent = await sendExpoPush([{ to: T1, title: 't', body: 'b' }])
  check('8a sendExpoPush skipped (no network attempt)',
    sent.skipped === true && sent.delivered === 0, JSON.stringify(sent))
  const before = await db.appNotification.count({ where: { customerId: cust.id } })
  await notifyCustomer({ customerId: cust.id, icon: 'bell', text: 'push-test row', pushTitle: 't' })
  const afterN = await db.appNotification.count({ where: { customerId: cust.id } })
  check('8b notifyCustomer writes the in-app row (never throws)', afterN === before + 1,
    `before=${before} after=${afterN}`)

  console.log(`\n${pass} PASS / ${fail} FAIL`)
  if (fail > 0) process.exitCode = 1
}

main()
  .catch((e) => { console.error('suite crashed:', e); process.exitCode = 1 })
  .finally(async () => {
    // ── 10. Cleanup ──
    const rows = await db.appCustomer.findMany({ where: { mobile: MOBILE }, select: { id: true } })
    for (const c of rows) {
      await db.appNotification.deleteMany({ where: { customerId: c.id } })
      await db.appSession.deleteMany({ where: { customerId: c.id } })
      await db.appTransaction.deleteMany({ where: { customerId: c.id } })
      await db.appCustomer.delete({ where: { id: c.id } }).catch(() => {})
    }
    await db.user.deleteMany({ where: { username: 'zz-push-test' } })
    await db.$disconnect()
  })
