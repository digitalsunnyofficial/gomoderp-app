/**
 * Market Management v2 — single source for ERP + Game.
 * Removes ALL existing markets (and their codes) and rebuilds the exact
 * operator list via the formula: Market Name + Phase + Session.
 *
 *   Sridevi Day Open / Close          Sridevi Night Open / Close
 *   Time Bazaar Day Open / Close      Milan Day Open / Close
 *   Milan Night Open / Close          Kalyan Open / Close   (classic — no phase)
 *   Main Bazaar Day Open / Close      Main Bazaar Night Open / Close
 *   Rajdhani Night Open / Close
 *
 * Game allocations are rebuilt for every new market code (all active games),
 * so "games linked to a market" keeps working without touching the catalog.
 * A starter set of ERP-managed starlines is created (editable/deletable).
 *
 * Run: node scripts/seed-markets-v2.js
 */
const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

// name, phase, session, openTime, closeTime — every record is one session market
const MARKETS = [
  { name: 'Sridevi', phase: 'day', session: 'open', openTime: '09:00', closeTime: '10:30' },
  { name: 'Sridevi', phase: 'day', session: 'close', openTime: '17:00', closeTime: '18:15' },
  { name: 'Sridevi', phase: 'night', session: 'open', openTime: '19:00', closeTime: '20:30' },
  { name: 'Sridevi', phase: 'night', session: 'close', openTime: '22:00', closeTime: '23:15' },
  { name: 'Time Bazaar', phase: 'day', session: 'open', openTime: '10:00', closeTime: '11:30' },
  { name: 'Time Bazaar', phase: 'day', session: 'close', openTime: '16:30', closeTime: '18:00' },
  { name: 'Milan', phase: 'day', session: 'open', openTime: '09:30', closeTime: '11:00' },
  { name: 'Milan', phase: 'day', session: 'close', openTime: '16:30', closeTime: '18:00' },
  { name: 'Milan', phase: 'night', session: 'open', openTime: '19:30', closeTime: '21:00' },
  { name: 'Milan', phase: 'night', session: 'close', openTime: '22:15', closeTime: '23:30' },
  { name: 'Kalyan', phase: 'none', session: 'open', openTime: '09:30', closeTime: '15:45' },
  { name: 'Kalyan', phase: 'none', session: 'close', openTime: '15:45', closeTime: '18:45' },
  { name: 'Main Bazaar', phase: 'day', session: 'open', openTime: '09:30', closeTime: '11:00' },
  { name: 'Main Bazaar', phase: 'day', session: 'close', openTime: '16:30', closeTime: '18:00' },
  { name: 'Main Bazaar', phase: 'night', session: 'open', openTime: '19:30', closeTime: '21:00' },
  { name: 'Main Bazaar', phase: 'night', session: 'close', openTime: '22:15', closeTime: '23:30' },
  { name: 'Rajdhani', phase: 'night', session: 'open', openTime: '19:30', closeTime: '21:15' },
  { name: 'Rajdhani', phase: 'night', session: 'close', openTime: '22:15', closeTime: '23:45' },
]

const STARLINES = [
  { hour: 10, minute: 0 },
  { hour: 12, minute: 30 },
  { hour: 15, minute: 0 },
  { hour: 17, minute: 30 },
  { hour: 20, minute: 0 },
]

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '')

async function main() {
  const games = await db.game.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } })
  console.log(`Active games in catalog: ${games.length}`)

  // 1. Wipe — remove every existing market + its allocations (bets/results are
  //    historical records and intentionally kept).
  const oldMarkets = await db.appMarket.findMany()
  for (const m of oldMarkets) {
    await db.gameAllocation.deleteMany({ where: { marketCode: m.code } })
  }
  const delMarkets = await db.appMarket.deleteMany()
  console.log(`Removed ${delMarkets.count} existing markets (+ their allocations)`)

  // 2. Create the operator's list via Name + Phase + Session
  let created = 0
  for (const [i, mk] of MARKETS.entries()) {
    const code = slug([mk.name, mk.phase === 'none' ? '' : mk.phase, mk.session].filter(Boolean).join('_'))
    await db.appMarket.upsert({
      where: { code },
      create: {
        code,
        name: mk.name,
        phase: mk.phase,
        session: mk.session,
        category: mk.phase === 'night' ? 'night' : 'regular',
        openTime: mk.openTime,
        closeTime: mk.closeTime,
        betClosingMinutes: 5,
        isOn: true,
        weeklySchedule: '{}',
        sortOrder: i + 1,
      },
      update: { name: mk.name, phase: mk.phase, session: mk.session, openTime: mk.openTime, closeTime: mk.closeTime, sortOrder: i + 1 },
    })
    created++
  }
  console.log(`Created ${created} session markets (Name + Phase + Session)`)

  // 3. Allocate every active game to every market (games linked to markets → app shows them)
  const markets = await db.appMarket.findMany({ orderBy: { sortOrder: 'asc' } })
  let allocs = 0
  for (const mk of markets) {
    for (const g of games) {
      await db.gameAllocation.upsert({
        where: { gameId_marketCode: { gameId: g.id, marketCode: mk.code } },
        create: { gameId: g.id, marketCode: mk.code, rate: null, minPoints: 10, isActive: true },
        update: { isActive: true },
      })
      allocs++
    }
  }
  console.log(`Allocated ${games.length} games × ${markets.length} markets = ${allocs} allocations`)

  // 4. Starter starlines (ERP-managed, editable/deletable in Market Management)
  for (const [i, sl] of STARLINES.entries()) {
    const code = 'st' + sl.hour
    await db.appStarline.upsert({
      where: { code },
      create: {
        code,
        name: `Starline ${String(sl.hour).padStart(2, '0')}:${String(sl.minute).padStart(2, '0')}`,
        hour: sl.hour, minute: sl.minute, betClosingMinutes: 5, isOn: true, sortOrder: i + 1,
      },
      update: { isOn: true },
    })
  }
  const slCount = await db.appStarline.count()
  console.log(`Starlines configured: ${slCount}`)

  console.log('\nMarket list:')
  for (const m of markets) {
    const phase = m.phase === 'night' ? 'Night' : m.phase === 'day' ? 'Day' : ''
    const sess = m.session === 'both' ? 'Open + Close' : m.session === 'open' ? 'Open' : 'Close'
    console.log(`  ${m.code.padEnd(26)} ${[m.name, phase, sess].filter(Boolean).join(' ').padEnd(30)} ${m.openTime}→${m.closeTime}`)
  }
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
