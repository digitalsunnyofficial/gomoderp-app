#!/bin/bash
set -u
cd /home/z/my-project
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
setsid bash scripts/start-dev.sh > dev.log 2>&1 < /dev/null &
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health 2>/dev/null)
  [ "$code" = "200" ] && { echo "server up"; break; }
  sleep 2
done
curl -s -o /dev/null http://localhost:3000/merp --max-time 180
agent-browser close >/dev/null 2>&1 || true
agent-browser open http://localhost:3000/merp >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
sleep 3
agent-browser eval "localStorage.clear(); sessionStorage.clear(); 'cleared'" >/dev/null 2>&1
agent-browser reload >/dev/null 2>&1
sleep 3
agent-browser find first "input[placeholder='Enter username']" fill "superadmin@mb.com" >/dev/null 2>&1
agent-browser find first "input[placeholder='Enter password']" fill "SAdmin@123_321" >/dev/null 2>&1
agent-browser find role button click --name "Login" >/dev/null 2>&1
sleep 5
agent-browser find text "Approvals" click >/dev/null 2>&1
sleep 7
echo "── approvals page text ──"
agent-browser eval "document.body.innerText.match(/Pending \(\d+\)|Approved Transactions \(\d+\)|Rejected \(\d+\)/g)?.join(' | ')" 2>&1
echo "── approvals API direct ──"
agent-browser eval "fetch('/api/whatsapp/approvals?status=all').then(r => r.json()).then(d => JSON.stringify({count: d.data?.length, statuses: d.data?.map(x => x.status)})).catch(e => 'ERR ' + e.message)" 2>&1
echo "── network log ──"
agent-browser network requests --filter approvals 2>&1 | tail -5
agent-browser screenshot download/t29-debug-approvals.png >/dev/null 2>&1
agent-browser close >/dev/null 2>&1
pkill -f "next dev -p 3000" 2>/dev/null
