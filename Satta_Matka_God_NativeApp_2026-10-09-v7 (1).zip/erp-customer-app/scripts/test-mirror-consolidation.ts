// Regression: consolidated Customer App mirror entries (Task 16.4)
// Simulates THREE placements from TWO customers on the same market session
// and asserts the ERP mirror produces exactly ONE row per (class × slot)
// with merged numbers, per-customer attribution, and Submitted By = 'app'.
//
// Run: npx tsx scripts/test-mirror-consolidation.ts
import { PrismaClient } from '@prisma/client'
import { mirrorBetsToErpInventory } from '../src/lib/matka/erp-mirror'

const db = new PrismaClient()

const MARKET = 'sridevi_day_open' // existing canonical market code
const DATE = '2026-09-20'         // past date — never touches live cards

let failures = 0
function check(name: string, cond: boolean, extra = '') {
  if (cond) console.log(`  PASS  ${name}`)
  else { failures++; console.log(`  FAIL  ${name} ${extra}`) }
}

function parse(raw: string) { return JSON.parse(raw) }

const range = (d: string) => ({ gte: new Date(d + 'T00:00:00.000Z'), lt: new Date(new Date(d + 'T00:00:00.000Z').getTime() + 86400000) })

async function main() {
  console.log('=== mirror consolidation regression ===')

  // ── clean slate for the test date (precisely bounded — never touches live cards) ──
  const invCode = await db.inventoryCode.findFirst({ where: { marketCode: MARKET } })
  if (invCode) {
    const olds = await db.inventory.findMany({ where: { inventoryCodeId: invCode.id, date: range(DATE) } })
    for (const o of olds) {
      await db.tripleInventory.deleteMany({ where: { inventoryId: o.id } })
      await db.doubleSingleInventory.deleteMany({ where: { inventoryId: o.id } })
      await db.inventory.delete({ where: { id: o.id } })
    }
  }

  const base = { marketCode: MARKET, marketName: 'Sridevi Day Open', betDate: DATE }

  // ── Customer A: pannas 380@100, 125@50 + single 5@10 ──
  const r1 = await mirrorBetsToErpInventory([
    { ...base, slot: 'open', type: 'sp', num: '380', points: 100, gameCode: 'single-pana' },
    { ...base, slot: 'open', type: 'dp', num: '125', points: 50, gameCode: 'double-pana' },
    { ...base, slot: 'open', type: 'single', num: '5', points: 10, gameCode: 'single-digit' },
  ], 'Test Cust A', '9000000001')
  check('A placement mirrored ok', r1.ok && r1.rows === 2, JSON.stringify(r1))

  // ── Customer B: panna 380@50 (same number!) + 347@20 + single 5@15 + jodi 45@10 ──
  const r2 = await mirrorBetsToErpInventory([
    { ...base, slot: 'open', type: 'tp', num: '380', points: 50, gameCode: 'motor' },
    { ...base, slot: 'open', type: 'sp', num: '347', points: 20, gameCode: 'single-pana' },
    { ...base, slot: 'open', type: 'single', num: '5', points: 15, gameCode: 'single-digit' },
    { ...base, slot: 'open', type: 'jodi', num: '45', points: 10, gameCode: 'jodi' },
  ], 'Test Cust B', '9000000002')
  check('B placement mirrored ok', r2.ok && r2.rows === 3, JSON.stringify(r2))

  // ── Customer A again (2nd placement, same session) ──
  const r3 = await mirrorBetsToErpInventory([
    { ...base, slot: 'open', type: 'sp', num: '590', points: 30, gameCode: 'single-pana' },
  ], 'Test Cust A', '9000000001')
  check('A 2nd placement mirrored ok', r3.ok, JSON.stringify(r3))

  // ── assertions ──
  const card = await db.inventory.findFirst({
    where: { inventoryCode: { marketCode: MARKET }, date: range(DATE) },
    include: { inventoryCode: true },
  })
  check('exactly ONE card for the session', !!card && card.inventoryCode.marketCode === MARKET && card.date.toISOString().slice(0, 10) === DATE, card ? card.date.toISOString() : 'no card')
  check('card Submitted By = app', card!.createdBy === 'app', card!.createdBy)

  const triples = await db.tripleInventory.findMany({ where: { inventoryId: card!.id } })
  check('exactly ONE triple row (no per-customer rows)', triples.length === 1, `got ${triples.length}`)
  const t = triples[0]
  const tpd = parse(t.parsedData)
  check('triple createdBy = app', t.createdBy === 'app', t.createdBy)
  check('triple numbers merged & ascending', JSON.stringify(tpd.numbers.map((n: { number: string }) => n.number)) === JSON.stringify(['125', '347', '380', '590']), JSON.stringify(tpd.numbers))
  const prices: Record<string, number> = {}
  for (const n of tpd.numbers) prices[n.number] = n.price
  check('380 totals across A+B (100+50)', prices['380'] === 150, `got ${prices['380']}`)
  check('triple totalAmount = 250', t.totalAmount === 250, `got ${t.totalAmount}`)
  check('byCustomer 380 has A=100 and B=50', tpd.byCustomer?.['380']?.['Test Cust A (9000000001)'] === 100 && tpd.byCustomer?.['380']?.['Test Cust B (9000000002)'] === 50, JSON.stringify(tpd.byCustomer?.['380']))
  check('customers list has both', (tpd.customers || []).length === 2, JSON.stringify(tpd.customers))
  check('details names the channel not a customer', t.details.startsWith('Customer App · Sridevi Day Open · open panna bets · 2 customers'), t.details)
  check('totalEntriesCount = 5 panna bids', tpd.totalEntriesCount === 5, `got ${tpd.totalEntriesCount}`)

  const ds = await db.doubleSingleInventory.findMany({ where: { inventoryId: card!.id } })
  const dsSingle = ds.find(d => d.type === 'single')
  const dsDouble = ds.find(d => d.type === 'double')
  check('single + jodi rows only (2 DS rows)', ds.length === 2, `got ${ds.length}`)
  const spd = parse(dsSingle!.parsedData)
  check('single 5 merged A+B (10+15)', spd.numbers?.[0]?.number === '5' && spd.numbers?.[0]?.price === 25, JSON.stringify(spd.numbers))
  check('single byCustomer has both', spd.byCustomer?.['5']?.['Test Cust A (9000000001)'] === 10 && spd.byCustomer?.['5']?.['Test Cust B (9000000002)'] === 15, JSON.stringify(spd.byCustomer?.['5']))
  check('single createdBy = app', dsSingle!.createdBy === 'app')
  const jpd = parse(dsDouble!.parsedData)
  check('jodi row separate slot/type', jpd.slot === 'open' && jpd.numbers?.[0]?.number === '45', JSON.stringify(jpd.numbers))

  // card total = triple 250 + single 25 + jodi 10
  const card2 = await db.inventory.findUnique({ where: { id: card!.id } })
  check('card total 285', card2!.totalAmount === 285, `got ${card2!.totalAmount}`)

  // ── cleanup: remove ONLY the precisely-bounded test card + rows ──
  await db.tripleInventory.deleteMany({ where: { inventoryId: card!.id } })
  await db.doubleSingleInventory.deleteMany({ where: { inventoryId: card!.id } })
  await db.inventory.deleteMany({ where: { id: card!.id, date: range(DATE) } })
  console.log('\ncleanup done (test card removed)')

  console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
