/**
 * E2E INTEGRATION VERIFICATION — the 5 boundaries, live against the dev server.
 * Covers: canonical market, allocation identity, bet→ERP→master boards,
 * per-session lockout, atomic declaration, correction/reversal, idempotency.
 */
const BASE = 'http://localhost:3000'

let cookie = ''
let userHeaders = {}
async function erp(path, opts = {}) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: { 'content-type': 'application/json', cookie, ...userHeaders, ...(opts.headers || {}) },
  })
  const sc = res.headers.get('set-cookie')
  if (sc && sc.includes('erp_session=')) cookie = sc.split(';')[0]
  const text = await res.text()
  try { return { status: res.status, data: JSON.parse(text) } } catch { return { status: res.status, data: text } }
}
async function app(path, token, opts = {}) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
  })
  const text = await res.text()
  try { return { status: res.status, data: JSON.parse(text) } } catch { return { status: res.status, data: text } }
}
const ok = (name, cond, detail = '') => {
  console.log(`${cond ? '✅' : '❌'} ${name}${detail ? ' — ' + detail : ''}`)
  if (!cond) process.exitCode = 1
}
const today = new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10)

async function main() {
  // ── 0. Logins ──
  const login = await erp('/api/auth', { method: 'POST', body: JSON.stringify({ username: 'superadmin@mb.com', password: 'SAdmin@123_321' }) })
  ok('ERP super login', login.status === 200, `status ${login.status}`)
  // Mirror the browser client: apiFetch attaches x-user-* headers from the
  // stored session — server-side isolation filters read these. The login
  // response IS the user object (top-level fields).
  const lu = login.data || {}
  userHeaders = {
    'x-user-id': String(lu.id || ''),
    'x-user-name': String(lu.username || ''),
    'x-user-role': String(lu.role || ''),
    'x-user-markets': String(lu.assignedMarkets || ''),
  }

  const appLogin = await app('/api/customer-app/auth/login', '', { method: 'POST', body: JSON.stringify({ mobile: '9852345605', password: 'Vikram@123' }) })
  const token = appLogin.data?.token || ''
  ok('Customer Vikram login', appLogin.status === 200 && !!token, `wallet ${appLogin.data?.customer?.wallet}`)

  // ── 1. Canonical markets: 18 session rows ──
  const mkts = await erp('/api/app-admin/markets')
  const sdo = mkts.data.markets.find(m => m.code === 'sridevi_day_open')
  ok('18 canonical market sessions', mkts.data.markets.length === 18, `found ${mkts.data.markets.length}`)
  ok('Sridevi Day Open identity', sdo && sdo.name === 'Sridevi' && sdo.phase === 'day' && sdo.session === 'open')

  // ── 2. Allocation API returns phase/session (UI dropdown fix enabler) ──
  const alloc = await erp('/api/app-admin/allocation')
  const allocMk = alloc.data.markets.find(m => m.code === 'sridevi_day_open')
  ok('Allocation GET carries phase+session', allocMk && allocMk.phase === 'day' && allocMk.session === 'open')
  const famActive = alloc.data.games.filter(g => ['family-4', 'family-6', 'family-8'].includes(g.code) && g.isActive)
  ok('Family Sets 4/6/8 retired from catalogue', famActive.length === 0, `active family sets: ${famActive.length}`)

  // ── 3. Widen window so the OPEN slot accepts right now (open bets run up to the open-time mark) ──
  const widen = await erp('/api/app-admin/markets', { method: 'PATCH', body: JSON.stringify({ id: sdo.id, openTime: '23:55', closeTime: '23:59', betClosingMinutes: 0 }) })
  ok('Widen Sridevi Day Open window (PATCH)', widen.status === 200)

  // ── 4. Vikram places SP 678 open, 10 pts (idempotent key e2e-abc-1) ──
  const home1 = await app('/api/customer-app/home', token)
  const mk1 = home1.data.markets.find(m => m.code === 'sridevi_day_open')
  ok('Home carries session displayName', mk1?.displayName === 'Sridevi Day Open', mk1?.displayName)
  const bet1 = await app('/api/customer-app/bets', token, {
    method: 'POST',
    body: JSON.stringify({ items: [{ marketCode: 'sridevi_day_open', slot: 'open', type: 'sp', num: '678', points: 10, clientRequestId: 'e2e-abc-1' }] }),
  })
  ok('Bet placed', bet1.status === 200 && bet1.data.placedCount === 1, `mirror:${bet1.data.mirrorNote} wallet:${bet1.data.wallet}`)
  ok('Bet snapshot has full session identity', bet1.data.bets?.[0]?.marketName === 'Sridevi Day Open', bet1.data.bets?.[0]?.marketName)

  // ── 5. Idempotent replay ──
  const bet1r = await app('/api/customer-app/bets', token, {
    method: 'POST',
    body: JSON.stringify({ items: [{ marketCode: 'sridevi_day_open', slot: 'open', type: 'sp', num: '678', points: 10, clientRequestId: 'e2e-abc-1' }] }),
  })
  ok('Replay ignored (idempotency)', bet1r.data.placedCount === 0 && bet1r.data.duplicates === 1 && bet1r.data.wallet === bet1.data.wallet,
    `placed ${bet1r.data.placedCount} dups ${bet1r.data.duplicates} wallet ${bet1r.data.wallet}`)

  // ── 6. ERP entry list has the canonical card ──
  const invs = await erp('/api/inventories?limit=50')
  const invList = Array.isArray(invs.data) ? invs.data : (invs.data.data || invs.data.inventories || [])
  const card = invList.find(i => i.inventoryCode?.code === 'app_sridevi_day_open')
  ok('ERP Entry List has canonical card', !!card, card ? `${card.inventoryCode.name} · total ${card.totalAmount} · type ${card.inventoryCode.type}` : 'MISSING')
  ok('Card name is session display name', card?.inventoryCode?.name === 'Sridevi Day Open', card?.inventoryCode?.name)
  ok('Card marketCode linked', card?.inventoryCode?.marketCode === 'sridevi_day_open')

  // ── 7. Master boards aggregate the app bet ──
  const charts = await erp(`/api/app-admin/market-charts?market=sridevi_day_open&date=${today}`)
  const tOpen = charts.data.boards?.triple?.open?.cells || []
  ok('Triple board has SP 678', tOpen.some(c => c.num === '678' && c.points === 10), JSON.stringify(tOpen))

  // ── 8. Declare Open 137 → SP 678 settles LOST ──
  const dec1 = await erp('/api/app-admin/results', { method: 'POST', body: JSON.stringify({ marketCode: 'sridevi_day_open', openPanna: '137' }) })
  ok('Open result declared', dec1.status === 200 && dec1.data.result?.openPanna === '137', `v${dec1.data.result?.version}`)
  ok('Bet 678 lost', dec1.data.settlement?.lost === 1, JSON.stringify(dec1.data.settlement))

  // ── 9. CLOSE session still accepts after open declared (lockout fix).
  // Re-widen so the CLOSE slot accepts now (close runs between open and close marks) ──
  const widen2 = await erp('/api/app-admin/markets', { method: 'PATCH', body: JSON.stringify({ id: sdo.id, openTime: '00:00', closeTime: '23:59', betClosingMinutes: 0 }) })
  ok('Re-widen window for close slot', widen2.status === 200)
  const bet2 = await app('/api/customer-app/bets', token, {
    method: 'POST',
    body: JSON.stringify({ items: [{ marketCode: 'sridevi_day_open', slot: 'close', type: 'sp', num: '246', points: 10, clientRequestId: 'e2e-abc-2' }] }),
  })
  ok('Close-session bet accepted after Open declared', bet2.status === 200 && bet2.data.placedCount === 1, bet2.data.error || `wallet ${bet2.data.wallet}`)
  const bet2openReplay = await app('/api/customer-app/bets', token, {
    method: 'POST',
    body: JSON.stringify({ items: [{ marketCode: 'sridevi_day_open', slot: 'open', type: 'sp', num: '902', points: 10, clientRequestId: 'e2e-abc-3' }] }),
  })
  ok('Open-session bet rejected after Open declared', bet2openReplay.status === 400, bet2openReplay.data.error || '')

  // ── 10. Declare Close 246 → SP 246 close WINS 1400 ──
  const dec2 = await erp('/api/app-admin/results', { method: 'POST', body: JSON.stringify({ marketCode: 'sridevi_day_open', closePanna: '246' }) })
  ok('Close result declared, SP 246 wins', dec2.status === 200 && dec2.data.settlement?.won === 1 && dec2.data.settlement?.totalWin === 1400,
    `won ${dec2.data.settlement?.won} totalWin ${dec2.data.settlement?.totalWin}`)

  // ── 11. CORRECT close 246 → 247 → reversal + version 2 ──
  const dec3 = await erp('/api/app-admin/results', { method: 'POST', body: JSON.stringify({ marketCode: 'sridevi_day_open', closePanna: '247' }) })
  ok('Correction accepted, version 2', dec3.status === 200 && dec3.data.result?.version === 2 && dec3.data.settlement?.corrected === true,
    `v${dec3.data.result?.version} corrected ${dec3.data.settlement?.corrected}`)
  ok('Reversal: 1400 clawed back', dec3.data.settlement?.reversedAmount === 1400 && dec3.data.settlement?.reversedCount === 1,
    `reversed ${dec3.data.settlement?.reversedAmount} × ${dec3.data.settlement?.reversedCount}`)

  // ── 12. Ledger + wallet + notification state ──
  const wallet = await app('/api/customer-app/wallet', token)
  const txs = wallet.data.transactions || []
  const reversal = txs.find(t => t.type === 'win_reversal' && t.amount === -1400)
  ok('win_reversal ledger entry exists', !!reversal, reversal ? reversal.remark.slice(0, 60) : 'MISSING')
  const me = await app('/api/customer-app/me', token)
  ok('Wallet back to pre-win level (9980)', me.data.customer?.wallet === 9980, `wallet ${me.data.customer?.wallet}`)
  const notifs = await app('/api/customer-app/notifications', token)
  const corr = (notifs.data.notifications || []).find(n => (n.text || '').includes('RESULT CORRECTED'))
  ok('Correction broadcast delivered', !!corr, corr ? corr.text.slice(0, 70) : 'MISSING')

  // ── 13. App sees result immediately with identity ──
  const home2 = await app('/api/customer-app/home', token)
  const mk2 = home2.data.markets.find(m => m.code === 'sridevi_day_open')
  ok('App home shows corrected result', mk2?.todayResult?.closePanna === '247', `${mk2?.todayResult?.openPanna}-${mk2?.todayResult?.closePanna} jodi ${mk2?.todayResult?.jodi}`)
  ok('Home resultsStamp present (correction detection)', !!home2.data.resultsStamp)

  // ── 14. My Bids identity ──
  const mybets = await app('/api/customer-app/bets?status=all', token)
  const b1 = (mybets.data.bets || []).find(b => b.num === '678')
  ok('My Bids enriched with session identity', b1?.marketName === 'Sridevi Day Open', b1?.marketName)

  // ── 15. Restore realistic window ──
  const restore = await erp('/api/app-admin/markets', { method: 'PATCH', body: JSON.stringify({ id: sdo.id, openTime: '09:00', closeTime: '10:30' }) })
  ok('Restore realistic Sridevi Day Open window', restore.status === 200)

  console.log(`\nBusiness date used: ${today}`)
}

main().catch(e => { console.error('E2E crashed:', e); process.exit(1) })
