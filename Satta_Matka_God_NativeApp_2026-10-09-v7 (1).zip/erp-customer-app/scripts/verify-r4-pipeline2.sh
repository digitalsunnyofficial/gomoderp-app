#!/bin/bash
# Task 42 phase 2: finish the r4 pipeline proof on the ALREADY-EXTRACTED stage
# (node_modules installed + built in phase 1). Re-sync the two changed files,
# run the exact lifecycle scripts, boot, and live-test.
set -e
cd /home/z/my-project
STAGE=/home/z/my-project/zipstage-r4-pipeline

echo "══ 0. refresh stage with final r4 files ══"
cd /home/z/my-project
unzip -qo download/Satta_Matka_God_Hostinger_Ready_2026-10-09-r4.zip \
  package.json scripts/sync-schema.js prisma/schema.prisma \
  "src/app/api/app-admin/apk/route.ts" \
  "src/app/apk/*" \
  src/components/pages/AppAdminPages3.tsx src/lib/store.ts src/lib/navigation.ts \
  src/lib/access-control.ts src/app/merp/page.tsx src/components/public/DownloadCta.tsx \
  -d "$STAGE"

cd "$STAGE"
echo "══ 1. npm run postinstall (generate + SELF-HEAL) ══"
npm run postinstall 2>&1 | rg "Generated Prisma|Datasource|in sync|Done|sync-schema" | head -6

echo "══ 2. stage db schema state ══"
python3 - <<'PYEOF'
import sqlite3
c = sqlite3.connect('db/custom.db')
tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
print('ApkArtifact table:', 'ApkArtifact' in tables)
cols = [r[1] for r in c.execute('PRAGMA table_info(AppCustomer)').fetchall()]
print('AppCustomer.pushToken column:', 'pushToken' in cols)
for t in ['AppCustomer','AppMarket','AppBet','AppTransaction','User']:
    print(t, c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0])
PYEOF

echo "══ 3. build ══"
npm run build 2>&1 | tail -3

echo "══ 4. boot on :3100 ══"
pkill -f "next start" 2>/dev/null || true
rm -f /tmp/r4-boot.log
setsid -f bash -c "cd $STAGE && PORT=3100 npm start > /tmp/r4-boot.log 2>&1"
for i in $(seq 1 30); do
  sleep 2
  CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 http://127.0.0.1:3100/api/health || echo 000)
  [ "$CODE" = "200" ] && break
done
curl -s -o /dev/null -w "health: %{http_code}\n" http://127.0.0.1:3100/api/health
echo "══ 5. routes ══"
for r in / /customerapp /merp /apk/sm-gomod.apk; do printf "%s -> %s\n" "$r" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1:3100$r)"; done
