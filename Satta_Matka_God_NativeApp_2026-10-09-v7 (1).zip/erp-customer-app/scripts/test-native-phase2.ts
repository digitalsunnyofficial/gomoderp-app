/**
 * test-native-phase2.ts — Task 32: native app Phase-2 backend surface.
 *
 * Covers everything the new Results/Charts, My Bids and Withdraw screens
 * consume, plus the hold→settle/refund lifecycle they depend on:
 *
 *  1. Unauth guards (results/starline/bets/withdrawals → 401)
 *  2. results?market      — default 35-day window untouched
 *  3. results?months=3|12 — additive month-window param (charts month nav)
 *  4. results?months=99   — invalid value falls back to the 35-day default
 *  5. results?starline=1  — board shape (hour/panna/digit)
 *  6. bets GET            — enriched bets + counts{all,pending,won,lost}
 *  7. withdrawals POST    — min ₹500, exceeds-wallet, canWithdraw=false → 403
 *  8. withdrawals POST ok — atomic hold: debit + withdraw_hold ledger + request
 *  9. withdrawals GET     — history visible to the app
 * 10. admin reject        — refund: wallet restored + withdraw_refund ledger
 * 11. admin paid          — status paid + withdraw_paid ledger (no wallet change)
 *
 * Self-contained temp fixtures (customer, market, results, bets) are removed in
 * cleanup. Run: bun scripts/test-native-phase2.ts   (server on :3000)
 */
import { PrismaClient } from '@prisma/client'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const MOBILE = '9900000032'
const MK = 'zzp2'
const istDate = (d = new Date()) => new Date(d.getTime() + 5.5 * 3600 * 1000).toISOString().slice(0, 10)
const daysAgo = (n: number) => istDate(new Date(Date.now() - n * 86400000))

async function main() {
  console.log('\n══ Task 32 — native app Phase 2 (results/charts, my bids, withdrawals) ══\n')

  // ── Fixtures ──
  await cleanup()
  const cust = await db.appCustomer.create({
    data: {
      name: 'Phase2 Test', mobile: MOBILE, password: 'x-not-used', wallet: 2000,
      approvalStatus: 'approved', status: 'active',
    },
  })
  const session = await db.appSession.create({
    data: { customerId: cust.id, token: 'phase2-token-' + Date.now(), expiresAt: new Date(Date.now() + 3600_000) },
  })
  const H = { Authorization: 'Bearer ' + session.token, 'Content-Type': 'application/json' }

  await db.appMarket.create({
    data: { code: MK, name: 'ZZ Phase2 Test', phase: 'none', session: 'both', openTime: '09:00', closeTime: '21:00', isOn: false },
  })
  await db.appResult.createMany({
    data: [
      { marketCode: MK, marketName: 'ZZ Phase2 Test', resultDate: daysAgo(0), openPanna: '123', openDigit: '6', closePanna: '380', closeDigit: '1', jodi: '61', declaredBy: 'test' },
      { marketCode: MK, marketName: 'ZZ Phase2 Test', resultDate: daysAgo(40), openPanna: '456', openDigit: '5', jodi: null, declaredBy: 'test' },
      { marketCode: MK, marketName: 'ZZ Phase2 Test', resultDate: daysAgo(100), openPanna: '789', openDigit: '4', closePanna: '150', closeDigit: '6', jodi: '46', declaredBy: 'test' },
    ],
  })
  await db.appBet.createMany({
    data: [
      { customerId: cust.id, marketCode: MK, marketName: 'ZZ Phase2 Test', betDate: daysAgo(0), slot: 'open', type: 'single', num: '5', points: 100, rate: 9, status: 'pending' },
      { customerId: cust.id, marketCode: MK, marketName: 'ZZ Phase2 Test', betDate: daysAgo(1), slot: 'jodi', type: 'jodi', num: '47', points: 100, rate: 90, status: 'won', win: 9000 },
    ],
  })

  // ── 1. Unauth guards ──
  for (const [i, path] of [
    '/api/customer-app/results?market=' + MK,
    '/api/customer-app/results?starline=1',
    '/api/customer-app/bets',
    '/api/customer-app/withdrawals',
  ].entries()) {
    const r = await fetch(`${BASE}${path}`)
    check(`1${'abcd'[i]} GET ${path.split('?')[0]} unauth → 401`, r.status === 401, `got ${r.status}`)
  }
  const pUn = await fetch(`${BASE}/api/customer-app/withdrawals`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ amount: 500 }),
  })
  check('1e POST withdrawals unauth → 401', pUn.status === 401, `got ${pUn.status}`)

  // ── 2. Default 35-day window ──
  const r35 = await fetch(`${BASE}/api/customer-app/results?market=${MK}`, { headers: H })
  const j35 = await r35.json() as { marketName: string; results: { resultDate: string; jodi: string | null }[] }
  check('2 default window → 1 result (35 days)',
    r35.status === 200 && j35.results.length === 1 && j35.results[0].resultDate === daysAgo(0), JSON.stringify(j35.results.map(r => r.resultDate)))
  check('2b marketName snapshot returned', j35.marketName === 'ZZ Phase2 Test', j35.marketName)

  // ── 3. months param ──
  const r3 = await fetch(`${BASE}/api/customer-app/results?market=${MK}&months=3`, { headers: H })
  const j3 = await r3.json() as { results: unknown[] }
  check('3 months=3 → 2 results (today + 40d)', j3.results.length === 2, `got ${j3.results.length}`)
  const r12 = await fetch(`${BASE}/api/customer-app/results?market=${MK}&months=12`, { headers: H })
  const j12 = await r12.json() as { results: unknown[] }
  check('3b months=12 → 3 results', j12.results.length === 3, `got ${j12.results.length}`)

  // ── 4. invalid months falls back ──
  const rBad = await fetch(`${BASE}/api/customer-app/results?market=${MK}&months=99`, { headers: H })
  const jBad = await rBad.json() as { results: unknown[] }
  check('4 months=99 → default 35-day window (1 result)', jBad.results.length === 1, `got ${jBad.results.length}`)

  // ── 5. Starline board shape ──
  const rStar = await fetch(`${BASE}/api/customer-app/results?starline=1`, { headers: H })
  const jStar = await rStar.json() as { board: { hour: number; panna: string | null; digit: string | null }[] }
  check('5 starline board is array of {hour,panna,digit}',
    rStar.status === 200 && Array.isArray(jStar.board) && jStar.board.every(b => typeof b.hour === 'number'),
    JSON.stringify(jStar).slice(0, 120))

  // ── 6. Bets GET + counts ──
  const rB = await fetch(`${BASE}/api/customer-app/bets?status=all`, { headers: H })
  const jB = await rB.json() as { bets: { id: string; status: string; num: string }[]; counts: Record<string, number> }
  check('6 bets GET → 2 bets for temp customer', rB.status === 200 && jB.bets.length === 2, `got ${jB.bets.length}`)
  check('6b counts keys all/pending/won/lost', ['all', 'pending', 'won', 'lost'].every(k => typeof jB.counts[k] === 'number'), JSON.stringify(jB.counts))
  const rBp = await fetch(`${BASE}/api/customer-app/bets?status=pending`, { headers: H })
  const jBp = await rBp.json() as { bets: unknown[] }
  check('6c status=pending filter → 1 bet', jBp.bets.length === 1, `got ${jBp.bets.length}`)

  // ── 7. Withdrawal guards ──
  const wMin = await fetch(`${BASE}/api/customer-app/withdrawals`, { method: 'POST', headers: H, body: JSON.stringify({ amount: 400 }) })
  check('7a below minimum ₹500 → 400', wMin.status === 400, `got ${wMin.status}`)
  const wMax = await fetch(`${BASE}/api/customer-app/withdrawals`, { method: 'POST', headers: H, body: JSON.stringify({ amount: 999999 }) })
  check('7b exceeds wallet → 400', wMax.status === 400, `got ${wMax.status}`)
  await db.appCustomer.update({ where: { id: cust.id }, data: { canWithdraw: false } })
  const wBlk = await fetch(`${BASE}/api/customer-app/withdrawals`, { method: 'POST', headers: H, body: JSON.stringify({ amount: 500 }) })
  check('7c canWithdraw=false → 403', wBlk.status === 403, `got ${wBlk.status}`)
  await db.appCustomer.update({ where: { id: cust.id }, data: { canWithdraw: true } })

  // ── 8. Successful request (hold) ──
  const wOk = await fetch(`${BASE}/api/customer-app/withdrawals`, { method: 'POST', headers: H, body: JSON.stringify({ amount: 700 }) })
  const wOkj = await wOk.json() as { ok: boolean; wallet: number; withdrawal: { id: string; status: string } }
  check('8 POST ₹700 → ok, wallet 1300', wOk.status === 200 && wOkj.ok && wOkj.wallet === 1300, JSON.stringify(wOkj))
  check('8b request row pending', wOkj.withdrawal?.status === 'pending', JSON.stringify(wOkj.withdrawal))
  const holdTxn = await db.appTransaction.findFirst({ where: { customerId: cust.id, type: 'withdraw_hold', amount: -700 } })
  check('8c withdraw_hold ledger row written', !!holdTxn)

  // ── 9. History GET ──
  const wList = await fetch(`${BASE}/api/customer-app/withdrawals`, { headers: H })
  const wListj = await wList.json() as { withdrawals: { id: string; amount: number; status: string }[] }
  check('9 GET history contains the request', wList.status === 200 && wListj.withdrawals.some(w => w.id === wOkj.withdrawal.id), JSON.stringify(wListj.withdrawals))

  // ── 10-11. Admin settle flows (ERP super session) ──
  const login = await fetch(`${BASE}/api/auth`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'superadmin@mb.com', password: 'SAdmin@123_321' }),
  })
  const setCookie = login.headers.get('set-cookie') || ''
  const cookie = setCookie.split(';')[0]
  check('10 ERP super login ok', login.status === 200 && !!cookie, `status ${login.status}`)

  const rej = await fetch(`${BASE}/api/app-admin/withdrawals`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ id: wOkj.withdrawal.id, action: 'reject' }),
  })
  check('10b admin reject → ok', rej.status === 200, `got ${rej.status}`)
  const afterRej = await db.appCustomer.findUnique({ where: { id: cust.id } })
  const refundTxn = await db.appTransaction.findFirst({ where: { customerId: cust.id, type: 'withdraw_refund', amount: 700 } })
  check('10c refund restores wallet to 2000 + refund ledger row',
    afterRej?.wallet === 2000 && !!refundTxn, `wallet=${afterRej?.wallet}`)

  const w2 = await fetch(`${BASE}/api/customer-app/withdrawals`, { method: 'POST', headers: H, body: JSON.stringify({ amount: 500 }) })
  const w2j = await w2.json() as { ok: boolean; wallet: number; withdrawal: { id: string } }
  check('11 second request ₹500 → wallet 1500', w2.status === 200 && w2j.wallet === 1500, JSON.stringify(w2j))
  const paid = await fetch(`${BASE}/api/app-admin/withdrawals`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ id: w2j.withdrawal.id, action: 'paid' }),
  })
  const afterPaid = await db.appCustomer.findUnique({ where: { id: cust.id } })
  const paidTxn = await db.appTransaction.findFirst({ where: { customerId: cust.id, type: 'withdraw_paid' } })
  check('11b admin paid → wallet unchanged (hold already debited) + paid ledger',
    paid.status === 200 && afterPaid?.wallet === 1500 && !!paidTxn, `wallet=${afterPaid?.wallet}`)

  // unauth admin guard (no cookie)
  const admUn = await fetch(`${BASE}/api/app-admin/withdrawals`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: w2j.withdrawal.id, action: 'paid' }),
  })
  check('11c admin action without session → 401', admUn.status === 401, `got ${admUn.status}`)

  console.log(`\n${pass} PASS / ${fail} FAIL`)
  if (fail > 0) process.exitCode = 1
}

async function cleanup() {
  const customers = await db.appCustomer.findMany({ where: { mobile: MOBILE } })
  for (const c of customers) {
    await db.appBet.deleteMany({ where: { customerId: c.id } })
    await db.appWithdrawRequest.deleteMany({ where: { customerId: c.id } })
    await db.appTransaction.deleteMany({ where: { customerId: c.id } })
    await db.appFundRequest.deleteMany({ where: { customerId: c.id } })
    await db.appNotification.deleteMany({ where: { customerId: c.id } })
    await db.appSession.deleteMany({ where: { customerId: c.id } })
    await db.appCustomer.delete({ where: { id: c.id } }).catch(() => {})
  }
  await db.appResult.deleteMany({ where: { marketCode: MK } })
  await db.appMarket.deleteMany({ where: { code: MK } })
}

main()
  .catch((e) => { console.error('suite crashed:', e); process.exitCode = 1 })
  .finally(async () => { await cleanup(); await db.$disconnect() })
