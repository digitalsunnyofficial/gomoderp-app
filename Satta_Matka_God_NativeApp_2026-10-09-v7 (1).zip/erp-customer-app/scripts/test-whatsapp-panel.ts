// test-whatsapp-panel.ts — WhatsApp Management panel regression suite.
//
// Covers (server must be running on :3000):
//   A. Templates API: pipeline defaults materialized (4 keyed, inactive),
//      category counts, create/edit/toggle guards, key-slot uniqueness.
//   B. Pipeline template resolution: active vyapar_ack template overrides the
//      built-in ack wording; deactivating restores the canonical text.
//   C. Send-to-customer: manual template send creates an outbound row, links
//      the customer, bumps usageCount, fills variables.
//   D. Panel stats: totals/funnel/topCustomers/suggestions computed.
//   E. Access: agents 403 on panel APIs; unauthenticated 401.
// FK-safe self-purge covers aborted runs; demo/production data untouched.
//
// Run: bun scripts/test-whatsapp-panel.ts
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const SUPER = 'zz-wa-panel-super'
const AGENT = 'zz-wa-panel-agent'
const MARK = 'wa-panel-test'

async function erpLogin(username: string, password: string): Promise<string> {
  const res = await fetch(`${BASE}/api/auth`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  })
  if (res.status !== 200) throw new Error(`erp login failed ${res.status}`)
  return (res.headers.get('set-cookie') || '').split(';')[0]
}

async function purgeUsers(usernames: string[]) {
  const uids = (await db.user.findMany({ where: { username: { in: usernames } } })).map(u => u.id)
  if (!uids.length) return
  await db.userSession.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.userActivity.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.userSubscription.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.user.deleteMany({ where: { id: { in: uids } } })
}

async function purge() {
  // FK-safe: children first. Scoped to this suite's fixtures only.
  await db.agentCommission.deleteMany({ where: { agentUsername: { in: [AGENT, MARK] } } })
  await db.whatsAppApproval.deleteMany({ where: { customerName: MARK } })
  await db.whatsAppTransactionLine.deleteMany({ where: { tx: { customerName: MARK } } })
  await db.whatsAppTransaction.deleteMany({ where: { customerName: MARK } })
  await db.whatsAppMessage.deleteMany({ where: { OR: [{ phone: { startsWith: '8877' } }, { body: { contains: MARK } }] } })
  await db.whatsAppTemplate.deleteMany({ where: { OR: [{ createdBy: { in: [SUPER, MARK] } }, { name: { contains: MARK } }] } })
  await db.appCustomer.deleteMany({ where: { name: MARK } })
  await db.vendor.deleteMany({ where: { createdBy: MARK } })
  await purgeUsers([SUPER, AGENT])
}

async function main() {
  await purge()

  // Fixtures
  await db.user.create({ data: { username: SUPER, name: 'WA Panel Super', password: await bcrypt.hash('wa-super-123', 10), role: 'super', status: 'active' } })
  await db.user.create({ data: { username: AGENT, name: 'WA Panel Agent', password: await bcrypt.hash('wa-agent-123', 10), role: 'user', status: 'active' } })
  const cust = await db.appCustomer.create({ data: { name: MARK, mobile: '8877000001', password: await bcrypt.hash('wa-cust-123', 10), status: 'active', approvalStatus: 'approved' } })
  const cookie = await erpLogin(SUPER, 'wa-super-123')
  check('super login', !!cookie)

  const agentCookie = await erpLogin(AGENT, 'wa-agent-123')
  check('agent login', !!agentCookie)

  // ── A. Templates API ──
  const g1 = await fetch(`${BASE}/api/whatsapp/templates`, { headers: { cookie } })
  const t1 = await g1.json() as { data: Array<{ id: string; key: string | null; name: string; category: string; isActive: boolean; usageCount: number; variableList: Array<{ name: string }> }>; counts: Record<string, number> }
  check('templates GET 200', g1.status === 200)
  const keys = (t1.data || []).map(t => t.key).filter(Boolean)
  for (const k of ['vyapar_ack', 'tx_success', 'rejection_notice', 'invalid_notice']) {
    check(`default slot present: ${k}`, keys.includes(k))
  }
  check('all four defaults shipped INACTIVE (built-in wording stays canonical)',
    (t1.data || []).filter(t => t.key && ['vyapar_ack', 'tx_success', 'rejection_notice', 'invalid_notice'].includes(t.key)).every(t => !t.isActive))
  check('category counts present', !!t1.counts && typeof t1.counts.utility === 'number')

  const ackTpl = (t1.data || []).find(t => t.key === 'vyapar_ack')!

  // create guard: agent 403, manager-less body 400, dup key 409
  const c1 = await fetch(`${BASE}/api/whatsapp/templates`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie: agentCookie },
    body: JSON.stringify({ name: 'x', bodyText: 'y' }),
  })
  check('agent template create 403', c1.status === 403, String(c1.status))
  const c2 = await fetch(`${BASE}/api/whatsapp/templates`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ name: `Dup ${MARK}`, bodyText: 'y', key: 'vyapar_ack' }),
  })
  check('duplicate pipeline key 409', c2.status === 409, String(c2.status))
  const c3 = await fetch(`${BASE}/api/whatsapp/templates`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ name: `Custom ${MARK}`, bodyText: `Hello {{name}} from ${MARK}`, category: 'marketing' }),
  })
  check('custom template create 200', c3.status === 200, String(c3.status))
  const custom = ((await c3.json()) as { data: { id: string; variables: string } }).data
  check('variables auto-derived from {{tokens}}', custom.variables.includes('"name"'))

  // edit + toggle
  const u1 = await fetch(`${BASE}/api/whatsapp/templates/${ackTpl.id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ bodyText: `PANEL ACK for ${MARK}: {{market_name}} / {{total}}`, isActive: true }),
  })
  check('edit + activate pipeline template 200', u1.status === 200)
  const agentEdit = await fetch(`${BASE}/api/whatsapp/templates/${ackTpl.id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json', cookie: agentCookie },
    body: JSON.stringify({ name: 'hacked' }),
  })
  check('agent template edit 403', agentEdit.status === 403)

  // ── B. Pipeline resolution (active template overrides ack) ──
  const s1 = await fetch(`${BASE}/api/whatsapp/simulate`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ phone: '8877000001', name: 'PanelTest', text: 'Milan open\n45=100\n50=150' }),
  })
  const sim1 = await s1.json() as { reply?: string; error?: string }
  check('simulated vyapar processed', !sim1.error, sim1.error || '')
  check('ACTIVE vyapar_ack template overrides built-in ack wording', (sim1.reply || '').includes(`PANEL ACK for ${MARK}`), (sim1.reply || '').slice(0, 80))
  const ackRow = await db.whatsAppMessage.findFirst({ where: { direction: 'out', phone: '8877000001', body: { contains: `PANEL ACK for ${MARK}` } }, orderBy: { createdAt: 'desc' } })
  check('template-driven outbound row stored', !!ackRow)

  // deactivate → built-in wording returns
  await fetch(`${BASE}/api/whatsapp/templates/${ackTpl.id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ isActive: false }),
  })
  const s2 = await fetch(`${BASE}/api/whatsapp/simulate`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ phone: '8877000001', name: 'PanelTest', text: 'Milan open\n45=100' }),
  })
  const sim2 = await s2.json() as { reply?: string }
  check('inactive template → canonical built-in ack restored', !!sim2.reply && !sim2.reply.includes(`PANEL ACK for ${MARK}`), (sim2.reply || '').slice(0, 80))

  // usageCount bumped by the ACTIVE-ack send in step B
  const ackAfter = await db.whatsAppTemplate.findUnique({ where: { id: ackTpl.id } })
  check('pipeline template usage tracked', (ackAfter?.usageCount || 0) >= 1, String(ackAfter?.usageCount))

  // ── C. Send-to-customer (custom marketing template) ──
  const cust2 = await db.appCustomer.findUnique({ where: { id: cust.id } })
  check('fixture customer exists', !!cust2)
  // custom starts inactive → send must be refused before activation
  const sendInactive = await fetch(`${BASE}/api/whatsapp/templates/${custom.id}/send`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ customerId: cust.id, params: { name: 'Ravi' } }),
  })
  check('send while INACTIVE refused 400', sendInactive.status === 400, String(sendInactive.status))
  await fetch(`${BASE}/api/whatsapp/templates/${custom.id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ isActive: true }),
  })
  const send1 = await fetch(`${BASE}/api/whatsapp/templates/${custom.id}/send`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ customerId: cust.id, params: { name: 'Ravi' } }),
  })
  const send1d = await send1.json() as { data?: { status: string; phone: string; body: string; customerName?: string }; error?: string }
  check('manual send 200 + sandbox/sent', send1.status === 200 && ['sandbox', 'sent'].includes(send1d.data?.status || ''), JSON.stringify(send1d).slice(0, 120))
  check('variables rendered into sent body', (send1d.data?.body || '').includes('Hello Ravi'), send1d.data?.body)
  const outRow = await db.whatsAppMessage.findFirst({ where: { direction: 'out', phone: '8877000001', body: { contains: 'Hello Ravi' } } })
  check('manual send creates linked outbound row', !!outRow && outRow.customerId === cust.id)
  const usageAfter = await db.whatsAppTemplate.findUnique({ where: { id: custom.id } })
  check('manual send bumps usageCount', (usageAfter?.usageCount || 0) >= 1, String(usageAfter?.usageCount))
  const sendAgent = await fetch(`${BASE}/api/whatsapp/templates/${custom.id}/send`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', cookie: agentCookie },
    body: JSON.stringify({ phone: '8877000002' }),
  })
  check('agent manual send 403', sendAgent.status === 403)

  // ── D. Panel stats ──
  const ps = await fetch(`${BASE}/api/whatsapp/panel-stats`, { headers: { cookie } })
  const stats = await ps.json() as {
    totals?: { inbound: number; outbound: number; pending: number; approved: number; rejected: number; failedOutbound: number }
    daily?: Array<{ date: string; inbound: number }>
    topCustomers?: Array<{ key: string; name: string; inbound: number }>
    suggestions?: Array<{ severity: string; text: string }>
    parserVersion?: number
  }
  check('panel-stats 200', ps.status === 200)
  check('stats: inbound counts our sim messages', (stats.totals?.inbound || 0) >= 2, String(stats.totals?.inbound))
  check('stats: 7-day series present', (stats.daily?.length || 0) === 7)
  check('stats: topCustomers include our customer', (stats.topCustomers || []).some(c => c.name === MARK || c.key === `phone:8877000001`))
  check('stats: suggestions computed', (stats.suggestions?.length || 0) > 0)
  check('stats: parser version present', (stats.parserVersion || 0) >= 1)

  // ── E. Access guards ──
  const agentStats = await fetch(`${BASE}/api/whatsapp/panel-stats`, { headers: { cookie: agentCookie } })
  check('agent panel-stats 403', agentStats.status === 403)
  const agentTpl = await fetch(`${BASE}/api/whatsapp/templates`, { headers: { cookie: agentCookie } })
  check('agent templates GET 403', agentTpl.status === 403)
  const noAuth = await fetch(`${BASE}/api/whatsapp/panel-stats`)
  check('unauthenticated panel-stats 401', noAuth.status === 401)
  const noAuthTpl = await fetch(`${BASE}/api/whatsapp/templates`)
  check('unauthenticated templates 401', noAuthTpl.status === 401)

  // ── Cleanup (FK-safe, also covers aborted runs) ──
  await db.whatsAppApproval.deleteMany({ where: { customerName: MARK } })
  await db.whatsAppTransactionLine.deleteMany({ where: { tx: { customerName: MARK } } })
  await db.whatsAppTransaction.deleteMany({ where: { customerName: MARK } })
  await db.whatsAppMessage.deleteMany({ where: { OR: [{ phone: { startsWith: '8877' } }, { body: { contains: MARK } }, { body: { contains: 'Hello Ravi' } }] } })
  await db.whatsAppTemplate.deleteMany({ where: { OR: [{ createdBy: { in: [SUPER, MARK] } }, { name: { contains: MARK } }] } })
  // restore the default vyapar_ack wording for production (delete the edited row; GET re-seeds)
  await db.whatsAppTemplate.deleteMany({ where: { key: 'vyapar_ack' } })
  await db.appCustomer.deleteMany({ where: { id: cust.id } })
  await purgeUsers([SUPER, AGENT])
  console.log('\ncleanup done (panel fixtures removed; pipeline defaults re-seed on next GET)')

  console.log(`\n${'═'.repeat(40)}`)
  console.log(`RESULT: ${pass} pass, ${fail} fail`)
  process.exit(fail ? 1 : 0)
}

main()
  .catch(e => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
