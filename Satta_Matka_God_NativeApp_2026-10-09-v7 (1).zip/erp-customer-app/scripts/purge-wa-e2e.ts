// One-off: purge E2E browser-test fixtures (temp agent/customer/group/messages)
import { db } from '../src/lib/db'

const testPhones = ['9123456790', '919123456790', '120363998877665544']
const msgs = await db.whatsAppMessage.findMany({ where: { phone: { in: testPhones } }, select: { id: true } })
const ids = msgs.map(m => m.id)
await db.whatsAppApproval.deleteMany({ where: { messageId: { in: ids } } })
const cust = await db.appCustomer.findUnique({ where: { mobile: '9123456790' } })
await db.whatsAppTransactionLine.deleteMany({ where: { tx: { customerId: cust?.id } } })
await db.whatsAppTransaction.deleteMany({ where: { customerId: cust?.id } })
await db.whatsAppMessage.deleteMany({ where: { phone: { in: testPhones } } })
await db.whatsAppGroupMapping.deleteMany({ where: { groupId: '120363998877665544' } })
await db.parserLearningLog.deleteMany({ where: { firstMessageId: { in: ids } } })
if (cust) await db.appCustomer.delete({ where: { id: cust.id } }).catch(() => undefined)
await db.user.deleteMany({ where: { username: 'wa-e2e-agent' } })
console.log('e2e purge done')
process.exit(0)
