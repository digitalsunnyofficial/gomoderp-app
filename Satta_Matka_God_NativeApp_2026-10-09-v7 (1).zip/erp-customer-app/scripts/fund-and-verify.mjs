// Fund test wallets via the PRODUCTION ERP flow (manual wallet adjustment),
// then re-verify the customer bet pipeline end-to-end with one small bet.
const BASE = 'http://localhost:3000'

async function j(method, path, body, cookie) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(cookie ? { cookie } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  })
  const text = await res.text()
  let data
  try { data = JSON.parse(text) } catch { data = text.slice(0, 200) }
  return { status: res.status, data, headers: res.headers }
}

async function main() {
  // 1) ERP super login
  const login = await j('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  const setCookie = login.headers.getSetCookie?.() || []
  const cookie = setCookie.map(c => c.split(';')[0]).join('; ')
  console.log('ERP login:', login.status, cookie ? 'session ok' : 'NO COOKIE')
  if (!cookie) { console.log(login.data); return }

  // 2) List customers (find ids)
  const list = await j('GET', '/api/app-admin/customers', null, cookie)
  console.log('customers GET:', list.status)
  const customers = list.data.customers || list.data || []
  const fundTargets = ['Rahul', 'Priya', 'Amit', 'Sneha', 'Hitesh Thakkar']
  for (const c of customers) {
    if (!fundTargets.includes(c.name)) continue
    if (Number(c.wallet) > 0) { console.log(`- ${c.name}: already ₹${c.wallet}, skip`); continue }
    const r = await j('POST', '/api/app-admin/customers',
      { id: c.id, amount: 5000, remark: 'Opening test balance for production-like live testing' }, cookie)
    console.log(`- ${c.name}: fund ₹5,000 ->`, r.status, r.data.wallet !== undefined ? `wallet ₹${r.data.wallet}` : r.data)
  }

  // 3) End-to-end re-verify: Rahul places a small bet through the app API
  const appLogin = await j('POST', '/api/customer-app/auth/login', { mobile: '9812345601', password: 'Rahul@123' })
  console.log('\napp login:', appLogin.status)
  const token = appLogin.data.token
  if (!token) { console.log(appLogin.data); return }
  const bet = await j('POST', '/api/customer-app/bets',
    { items: [{ marketCode: 'milan_night_open', slot: 'open', type: 'single', num: '5', points: 100, clientRequestId: 'diag-verify-' + Date.now() }] },
    undefined)
  // bets route uses Authorization header per app-auth
  const res2 = await fetch(BASE + '/api/customer-app/bets', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify({ items: [{ marketCode: 'milan_night_open', slot: 'open', type: 'single', num: '5', points: 100, clientRequestId: 'diag-verify-' + Date.now() }] }),
  })
  const betData = await res2.json()
  console.log('bet POST:', res2.status, JSON.stringify(betData).slice(0, 400))
}

main().catch(e => { console.error('FATAL', e); process.exit(1) })
