/**
 * test-agent-access-control.ts — RBAC verification for the agent access
 * setup (operator rules: agents must NOT have Smart Entry, Chitthi
 * Generator or Plan management; agents see ONLY their own customers).
 *
 * Self-contained: creates temp super + manager + 2 agents + app customers
 * + vendors, runs the matrix over live HTTP (server on :3000) plus the
 * page-access matrix unit checks, then cleans everything up.
 *
 * Sections:
 *  A. PAGE-ACCESS MATRIX (lib unit checks, no server)
 *  B. NAV DERIVATION (sidebar = matrix)
 *  C. CUSTOMER DATA ISOLATION (/api/app-admin/customers, /api/vendors)
 *  D. ADMIN-ONLY APIs REJECT AGENTS (chitthi, plans, signup-config, detail)
 *  E. ADMIN/MANAGER ACCESS PRESERVED (regressions)
 *
 * Run: bun scripts/test-agent-access-control.ts
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const SUPER = 'zz-rbac-super'
const MANAGER = 'zz-rbac-manager'
const AGENT = 'zz-rbac-agent'
const OTHER = 'zz-rbac-other'

async function erpLogin(username: string, password: string): Promise<string> {
  const res = await fetch(`${BASE}/api/auth`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  })
  if (res.status !== 200) throw new Error(`erp login failed ${res.status} for ${username}`)
  return (res.headers.get('set-cookie') || '').split(';')[0]
}

async function get(cookie: string, path: string) {
  const res = await fetch(`${BASE}${path}`, { headers: { cookie } })
  let body: any = null
  try { body = await res.json() } catch { /* binary/empty */ }
  return { status: res.status, body }
}
async function send(cookie: string, method: string, path: string, data?: unknown) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) },
    body: data === undefined ? undefined : JSON.stringify(data),
  })
  let body: any = null
  try { body = await res.json() } catch { /* empty */ }
  return { status: res.status, body }
}

const NAMES = ['ZZ RBAC Own', 'ZZ RBAC Agentless', 'ZZ RBAC OtherAgent']

async function purge() {
  // FK-safe cleanup of everything this test (or an aborted run) created
  const custs = await db.appCustomer.findMany({ where: { name: { in: NAMES } } })
  for (const c of custs) {
    await db.appBet.deleteMany({ where: { customerId: c.id } })
    await db.appTransaction.deleteMany({ where: { customerId: c.id } })
    await db.appFundRequest.deleteMany({ where: { customerId: c.id } })
    await db.appWithdrawRequest.deleteMany({ where: { customerId: c.id } })
    await db.appNotification.deleteMany({ where: { customerId: c.id } })
    await db.appSession.deleteMany({ where: { customerId: c.id } })
    await db.agentCommission.deleteMany({ where: { customerId: c.id } })
    await db.appCustomer.delete({ where: { id: c.id } }).catch(() => {})
  }
  await db.vendor.deleteMany({ where: { code: { in: ['ZZRBAC1', 'ZZRBAC2'] } } })
  await purgeUsers([SUPER, MANAGER, AGENT, OTHER])
}

async function purgeUsers(usernames: string[]) {
  const uids = (await db.user.findMany({ where: { username: { in: usernames } } })).map(u => u.id)
  if (!uids.length) return
  await db.userSession.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.userActivity.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.userSubscription.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.user.deleteMany({ where: { id: { in: uids } } })
}

async function main() {
  console.log('\n════════════════════════════════════════════════════')
  console.log(' AGENT ACCESS CONTROL — RBAC MATRIX TEST')
  console.log('════════════════════════════════════════════════════')

  // ── A. PAGE-ACCESS MATRIX (unit) ──────────────────────────────
  console.log('\n── A. Page-access matrix (access-control.ts) ──')
  const { canAccessPage, accessiblePages, PAGE_ACCESS } = await import('../src/lib/access-control')
  const type = PAGE_ACCESS as Record<string, string>

  check('A1 agent denied Smart Entry', canAccessPage('user', 'unified-entry') === false)
  check('A2 agent denied Chitthi Generator', canAccessPage('user', 'chitthi') === false)
  check('A3 agent denied Plan management', canAccessPage('user', 'sub-plans') === false)
  check('A4 agent denied WhatsApp panel', !canAccessPage('user', 'wa-dashboard') && !canAccessPage('user', 'wa-messages') && !canAccessPage('user', 'wa-templates') && !canAccessPage('user', 'wa-approvals') && !canAccessPage('user', 'wa-learning') && !canAccessPage('user', 'wa-mappings'))
  check('A5 agent denied App Bids', canAccessPage('user', 'app-bids') === false)
  check('A6 removed Hisab pages fail-closed for EVERY role (module removed)', !canAccessPage('user', 'sett-new' as never) && !canAccessPage('manager', 'sett-list' as never) && !canAccessPage('super', 'vendor-sett' as never))
  check('A7 agent denied market mgmt', !canAccessPage('user', 'configure') && !canAccessPage('user', 'starlines') && !canAccessPage('user', 'market-results') && !canAccessPage('user', 'game-management'))
  check('A8 agent denied system mgmt', !canAccessPage('user', 'sys-mgmt-users') && !canAccessPage('user', 'sys-mgmt-activity') && !canAccessPage('user', 'sys-mgmt-parser-cfg'))
  check('A9 agent denied hierarchy directories', !canAccessPage('user', 'hierarchy-managers') && !canAccessPage('user', 'hierarchy-agents'))
  check('A10 agent denied payment mgmt', !canAccessPage('user', 'app-funds') && !canAccessPage('user', 'sub-payments'))
  check('A11 agent allowed Dashboard', canAccessPage('user', 'dashboard') === true)
  check('A12 agent allowed New Entry + Entry List', canAccessPage('user', 'inv-new') && canAccessPage('user', 'inv-list'))
  check('A13 agent allowed Customer List (scoped)', canAccessPage('user', 'vendor'))
  check('A14 agent allowed My Commission + My Subscription', canAccessPage('user', 'agent-commission') && canAccessPage('user', 'sub-users'))
  check('A15 manager keeps Smart Entry + Chitthi + Plan', canAccessPage('manager', 'unified-entry') && canAccessPage('manager', 'chitthi') && canAccessPage('manager', 'sub-plans'))
  check('A16 manager denied super-only pages', !canAccessPage('manager', 'hierarchy-managers') && !canAccessPage('manager', 'game-allocation') && !canAccessPage('manager', 'sys-mgmt-users') && !canAccessPage('manager', 'users'))
  check('A17 super allowed everything', Object.keys(type).every(p => canAccessPage('super', p as never)))
  check('A18 legacy master role treated as super', canAccessPage('master', 'unified-entry') && canAccessPage('master', 'sys-mgmt-users'))
  check('A19 unknown page denied (fail-closed)', canAccessPage('super', 'no-such-page' as never) === false)
  const agentPages = accessiblePages('user')
  check('A20 agent page set exactly as operator profile',
    agentPages.length === 9 &&
    ['dashboard', 'inv-new', 'inv-list', 'card-view', 'vendor', 'agent-commission', 'sub-users', 'paywall', 'login'].every(p => agentPages.includes(p as never)),
    `got: ${agentPages.join(',')}`)
  check('A21 login page reachable by all roles', canAccessPage('user', 'login') && canAccessPage('manager', 'login') && canAccessPage('super', 'login'))

  // ── B. NAV DERIVATION ─────────────────────────────────────────
  console.log('\n── B. Sidebar derivation (navigation.ts) ──')
  const nav = await import('../src/lib/navigation')
  const flat = (arr: Array<{ section: string; items: Array<{ id: string; label: string }> }>) =>
    arr.flatMap(s => s.items.map(i => ({ ...i, section: s.section })))
  const userNav = flat(nav.NAV_ITEMS_USER as never)
  const mgrNav = flat(nav.NAV_ITEMS_MANAGER as never)
  const supNav = flat(nav.NAV_ITEMS_MASTER as never)
  check('B1 agent nav has NO Smart Entry', !userNav.some(i => i.id === 'unified-entry'))
  check('B2 agent nav has NO Chitthi Generator', !userNav.some(i => i.id === 'chitthi'))
  check('B3 agent nav has NO Plan page', !userNav.some(i => i.id === 'sub-plans'))
  check('B4 agent nav keeps New Entry / Entry List / Customer List', ['inv-new', 'inv-list', 'vendor'].every(id => userNav.some(i => i.id === id)))
  check('B5 agent nav labels My Commission / My Subscription', userNav.some(i => i.id === 'agent-commission' && i.label === 'My Commission') && userNav.some(i => i.id === 'sub-users' && i.label === 'My Subscription'))
  check('B6 agent nav exactly 6 items', userNav.length === 6, `got ${userNav.length}: ${userNav.map(i => i.id).join(',')}`)
  check('B7 manager nav keeps Smart Entry + Chitthi + Plan', mgrNav.some(i => i.id === 'unified-entry') && mgrNav.some(i => i.id === 'chitthi') && mgrNav.some(i => i.id === 'sub-plans'))
  check('B8 manager nav has no super-only pages', !mgrNav.some(i => i.id === 'hierarchy-managers' || i.id === 'sys-mgmt-users' || i.id === 'game-allocation'))
  check('B9 super nav is the full catalog', supNav.length >= 30 && supNav.some(i => i.id === 'unified-entry') && supNav.some(i => i.id === 'chitthi') && supNav.some(i => i.id === 'sub-plans'))

  // ── Fixtures for HTTP sections ────────────────────────────────
  await purge()
  const pwd = await bcrypt.hash('rbac-test-123', 10)
  await db.user.create({ data: { username: SUPER, name: 'RBAC Super', password: pwd, role: 'super', status: 'active' } })
  await db.user.create({ data: { username: MANAGER, name: 'RBAC Manager', password: pwd, role: 'manager', status: 'active' } })
  await db.user.create({ data: { username: AGENT, name: 'Sanjay RBAC', password: pwd, role: 'user', status: 'active' } })
  await db.user.create({ data: { username: OTHER, name: 'Other RBAC', password: pwd, role: 'user', status: 'active' } })

  const mk = '88' + String(Date.now()).slice(-8)
  await db.appCustomer.create({ data: { name: NAMES[0], mobile: '91' + mk.slice(-8), password: 'x', agentUsername: AGENT, agentName: 'Sanjay RBAC' } })
  await db.appCustomer.create({ data: { name: NAMES[1], mobile: '92' + mk.slice(-8), password: 'x' } })
  await db.appCustomer.create({ data: { name: NAMES[2], mobile: '93' + mk.slice(-8), password: 'x', agentUsername: OTHER, agentName: 'Other RBAC' } })
  await db.vendor.create({ data: { code: 'ZZRBAC1', businessName: 'RBAC Own Vendor', mobileNo: '8000000001', createdBy: AGENT } })
  await db.vendor.create({ data: { code: 'ZZRBAC2', businessName: 'RBAC Other Vendor', mobileNo: '8000000002', createdBy: OTHER } })

  const superCk = await erpLogin(SUPER, 'rbac-test-123')
  const mgrCk = await erpLogin(MANAGER, 'rbac-test-123')
  const agentCk = await erpLogin(AGENT, 'rbac-test-123')
  check('fix: all three sessions issued', !!superCk && !!mgrCk && !!agentCk)

  // ── C. CUSTOMER DATA ISOLATION ────────────────────────────────
  console.log('\n── C. Customer data isolation ──')
  const agentList = await get(agentCk, '/api/app-admin/customers')
  const agentRows = (agentList.body?.customers || []) as Array<{ name: string }>
  check('C1 agent request succeeds (200)', agentList.status === 200)
  check('C2 agent sees ONLY own filed customer', agentRows.length === 1 && agentRows[0].name === NAMES[0], `got ${agentRows.map(r => r.name).join(',') || 'none'}`)
  check('C3 agent does NOT see agentless customer', !agentRows.some(r => r.name === NAMES[1]))
  check('C4 agent does NOT see other agent\'s customer', !agentRows.some(r => r.name === NAMES[2]))

  const mgrList = await get(mgrCk, '/api/app-admin/customers')
  const mgrRows = (mgrList.body?.customers || []) as Array<{ name: string }>
  check('C5 manager still sees the full directory', mgrList.status === 200 && [NAMES[0], NAMES[1], NAMES[2]].every(n => mgrRows.some(r => r.name === n)))

  const supList = await get(superCk, '/api/app-admin/customers')
  const supRows = (supList.body?.customers || []) as Array<{ id: string; name: string }>
  check('C6 super still sees the full directory', supList.status === 200 && [NAMES[0], NAMES[1], NAMES[2]].every(n => supRows.some(r => r.name === n)))

  const agentVendors = await get(agentCk, '/api/vendors')
  const av = Array.isArray(agentVendors.body) ? agentVendors.body as Array<{ code: string }> : []
  check('C7 agent ERP customers scoped to own (server-verified headers)', agentVendors.status === 200 && av.some(v => v.code === 'ZZRBAC1') && !av.some(v => v.code === 'ZZRBAC2'), `got ${av.map(v => v.code).join(',') || 'none'}`)

  const supVendors = await get(superCk, '/api/vendors')
  const sv = Array.isArray(supVendors.body) ? supVendors.body as Array<{ code: string }> : []
  check('C8 super sees both vendors', supVendors.status === 200 && sv.some(v => v.code === 'ZZRBAC1') && sv.some(v => v.code === 'ZZRBAC2'))

  const agentDash = await get(agentCk, '/api/dashboard')
  check('C9 agent dashboard still works (isolated data)', agentDash.status === 200)

  // ── D. ADMIN-ONLY APIs REJECT AGENTS ──────────────────────────
  console.log('\n── D. Admin-only APIs reject agents ──')
  const chitthiPost = await send(agentCk, 'POST', '/api/chitthi', { rawText: '5=100', market: 'Milan Day' })
  check('D1 agent chitthi generate → 403', chitthiPost.status === 403, `got ${chitthiPost.status}`)
  const chitthiGet = await get(agentCk, '/api/chitthi')
  check('D2 agent chitthi list → 403', chitthiGet.status === 403, `got ${chitthiGet.status}`)
  const chitthiImg = await get(agentCk, '/api/chitthi/00000000-0000-0000-0000-000000000000/image')
  check('D3 agent chitthi image → 403 (guard before lookup)', chitthiImg.status === 403, `got ${chitthiImg.status}`)
  const chitthiImgSuper = await get(superCk, '/api/chitthi/00000000-0000-0000-0000-000000000000/image')
  check('D4 super chitthi image passes guard (404 unknown id)', chitthiImgSuper.status === 404, `got ${chitthiImgSuper.status}`)

  const planPost = await send(agentCk, 'POST', '/api/subscription-plans', { name: 'zz', label: 'zz', durationDays: 30, price: 100 })
  check('D5 agent plan create → 403', planPost.status === 403, `got ${planPost.status}`)
  const planPut = await send(agentCk, 'PUT', '/api/subscription-plans/zz-none', { price: 1 })
  check('D6 agent plan update → 403', planPut.status === 403, `got ${planPut.status}`)
  const planDel = await send(agentCk, 'DELETE', '/api/subscription-plans/zz-none')
  check('D7 agent plan delete → 403', planDel.status === 403, `got ${planDel.status}`)
  const planPostMgr = await send(mgrCk, 'PUT', '/api/subscription-plans/zz-none', { price: 1 })
  check('D8 manager plan update passes role gate (404 unknown)', planPostMgr.status === 404, `got ${planPostMgr.status}`)

  const cfgAgent = await get(agentCk, '/api/app-admin/signup-config')
  check('D9 agent signup-config → 403', cfgAgent.status === 403, `got ${cfgAgent.status}`)
  const cfgSuper = await get(superCk, '/api/app-admin/signup-config')
  check('D10 super signup-config → 200', cfgSuper.status === 200)

  const ownCust = supRows.find(r => r.name === NAMES[0])
  const otherCust = supRows.find(r => r.name === NAMES[2])
  if (ownCust && otherCust) {
    const d1 = await get(agentCk, `/api/app-admin/customers/detail?id=${ownCust.id}`)
    check('D11 agent customer detail → 403 (even own)', d1.status === 403, `got ${d1.status}`)
    const d2 = await get(agentCk, `/api/app-admin/customers/${otherCust.id}`)
    check('D12 agent customer-360 → 403', d2.status === 403, `got ${d2.status}`)
    const d3 = await send(agentCk, 'PATCH', '/api/app-admin/customers', { id: otherCust.id, action: 'approve' })
    check('D13 agent approve action → 403', d3.status === 403, `got ${d3.status}`)
  } else {
    check('D11-D13 fixture lookup', false, 'customers not found in super list')
  }

  const anon = await get('', '/api/app-admin/customers')
  check('D14 unauthenticated directory request → 401', anon.status === 401, `got ${anon.status}`)

  // ── E. REGRESSIONS (what must keep working) ───────────────────
  console.log('\n── E. Regressions ──')
  const plansPublic = await get('', '/api/subscription-plans')
  check('E1 plan list stays public (customer app pricing)', plansPublic.status === 200 && Array.isArray(plansPublic.body))
  const agentSubs = await get(agentCk, '/api/user-subscriptions')
  check('E2 agent My Subscription API works', agentSubs.status === 200)
  const agentComm = await get(agentCk, '/api/app-admin/commissions')
  check('E3 agent My Commission API works (own ledger)', agentComm.status === 200)
  const supComm = await get(superCk, '/api/app-admin/commissions')
  check('E4 super commission view works', supComm.status === 200)

  // ── Cleanup ───────────────────────────────────────────────────
  await purge()
  console.log('\n────────────────────────────────────────────────────')
  console.log(` RESULT: ${pass} PASS  /  ${fail} FAIL`)
  console.log('────────────────────────────────────────────────────\n')
  await db.$disconnect()
  process.exit(fail ? 1 : 0)
}

main().catch(async (e) => {
  console.error('FATAL', e)
  await purge().catch(() => {})
  await db.$disconnect()
  process.exit(1)
})
