/**
 * flow-live-test.ts — live end-to-end flow verification against the RUNNING
 * dev server on :3000 (NO restart, NO pkill — the platform preview server
 * stays up). Walks the exact journey the native app performs, screen by
 * screen, on fresh temp fixtures, then cleans everything up.
 *
 *   A. Routes .......... /, /merp, /app, /download, /api/health
 *   B. Journey ......... signup → admin approve → login → home → fund request
 *                        → admin approve → wallet 5000 → place bid (₹100)
 *                        → replay-idempotency → my bids → results/starline
 *                        → withdraw hold → admin reject (refund) → withdraw
 *                        → admin paid → notifications → push status
 *   C. Demo integrity .. commission pending ₹280 @2%, demo customer login
 *
 * Run: bun scripts/flow-live-test.ts
 */
import { PrismaClient } from '@prisma/client'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const MOBILE = '9900000041'
const MK = 'zzflow'
const PW = 'Flow@12345'

async function j(method: string, path: string, body?: unknown, headers: Record<string, string> = {}) {
  const r = await fetch(`${BASE}${path}`, {
    method,
    headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  })
  let data: any = null
  try { data = await r.json() } catch { /* html/empty */ }
  return { status: r.status, data, headers: r.headers }
}

async function cleanup() {
  await db.appResult.deleteMany({ where: { marketCode: 'st99', declaredBy: 'flow-test' } })
  const cust = await db.appCustomer.findUnique({ where: { mobile: MOBILE } })
  if (cust) {
    await db.appBet.deleteMany({ where: { customerId: cust.id } })
    await db.appTransaction.deleteMany({ where: { customerId: cust.id } })
    await db.appWithdrawRequest.deleteMany({ where: { customerId: cust.id } })
    await db.appFundRequest.deleteMany({ where: { customerId: cust.id } })
    await db.appNotification.deleteMany({ where: { customerId: cust.id } })
    await db.appSession.deleteMany({ where: { customerId: cust.id } })
    await db.appCustomer.delete({ where: { id: cust.id } })
  }
  await db.appMarket.deleteMany({ where: { code: MK } })
}

async function main() {
  console.log('\n══ Live flow — workspace on :3000 (native-app journey) ══\n')
  await cleanup()

  // ── A. Routes ──
  console.log('── A. routes ──')
  for (const [path, want] of [['/', 200], ['/merp', 200], ['/app', 200], ['/download', 307], ['/api/health', 200]] as const) {
    const r = await fetch(`${BASE}${path}`, { redirect: 'manual' })
    check(`${path} → ${want}`, r.status === want, `got ${r.status}`)
  }

  // ── B. Customer journey ──
  console.log('── B. customer journey (native-app parity) ──')
  const su = await j('POST', '/api/customer-app/auth/signup', { name: 'Flow Test', mobile: MOBILE, password: PW })
  const autoApproved = su.status === 200 && !!su.data?.token
  const signupHandled = autoApproved || (su.status === 200 || su.status === 201)
  check('B1 signup accepted', signupHandled, `${su.status} ${JSON.stringify(su.data).slice(0, 120)}`)

  const adm = await j('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  const setCookie = adm.headers.get('set-cookie') || ''
  const cookie = setCookie.split(';')[0].replace(/\r/g, '')
  check('B2 ERP super login → session cookie', adm.status === 200 && cookie.length > 10, `status ${adm.status}`)

  const row0 = await db.appCustomer.findUnique({ where: { mobile: MOBILE } })
  if (!autoApproved && row0 && row0.approvalStatus === 'pending') {
    const ap = await j('PATCH', '/api/app-admin/customers', { id: row0.id, action: 'approve' }, { Cookie: cookie })
    check('B3 admin approve → 200', ap.status === 200, `${ap.status} ${JSON.stringify(ap.data).slice(0, 120)}`)
  } else {
    check('B3 customer approved (auto-approve or pre-approved)', !!row0 && row0.approvalStatus === 'approved', `status ${row0?.approvalStatus}`)
  }

  const li = await j('POST', '/api/customer-app/auth/login', { mobile: MOBILE, password: PW })
  const token = li.data?.token
  check('B4 login → Bearer token', li.status === 200 && !!token, `${li.status} ${JSON.stringify(li.data).slice(0, 100)}`)
  const H = { Authorization: 'Bearer ' + token }

  const me = await j('GET', '/api/customer-app/me', undefined, H)
  const custId = me.data?.customer?.id
  check('B5 me → customer, wallet 0', me.status === 200 && !!custId && me.data.customer.wallet === 0, JSON.stringify(me.data?.customer?.wallet))

  const home = await j('GET', '/api/customer-app/home', undefined, H)
  const mkts = home.data?.markets || []
  check('B6 home → markets list served', home.status === 200 && mkts.length > 0, `${mkts.length} markets`)

  const fr = await j('POST', '/api/customer-app/funds', { amount: 5000, method: 'UPI', utr: 'FLOW' + Date.now().toString().slice(-8) }, H)
  const fundId = fr.data?.fund?.id || fr.data?.id || fr.data?.requestId
  check('B7 fund request ₹5000 filed', fr.status === 200 && !!fundId, `${fr.status} ${JSON.stringify(fr.data).slice(0, 120)}`)

  const fap = await j('POST', '/api/app-admin/funds', { id: fundId, action: 'approve' }, { Cookie: cookie })
  check('B8 admin approves fund → 200', fap.status === 200, `${fap.status} ${JSON.stringify(fap.data).slice(0, 120)}`)

  const w1 = await j('GET', '/api/customer-app/wallet', undefined, H)
  check('B9 wallet balance ₹5000', w1.status === 200 && w1.data?.wallet === 5000, `got ${w1.data?.wallet}`)
  let bal = 5000

  // temp market whose OPEN session is accepting right now: for session 'both'
  // markets the open slot accepts while cur < openTime (IST), so place the
  // open time ~2h ahead of the current IST clock (capped at 23:59).
  const ist = new Date(Date.now() + 5.5 * 3600 * 1000)
  const curMins = ist.getUTCHours() * 60 + ist.getUTCMinutes()
  const oMins = Math.min(curMins + 120, 1439)
  const cMins = Math.min(oMins + 60, 1439)
  const hm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
  await db.appMarket.create({ data: {
    code: MK, name: 'ZZ Flow Test', phase: 'none', session: 'both',
    openTime: hm(oMins), closeTime: hm(cMins), betClosingMinutes: 0, isOn: true, isActive: true,
  } })

  // seed one declared starline result for TODAY so the board pipeline is
  // observable (the demo day hasn't declared any starline yet)
  await db.appResult.create({ data: {
    marketCode: 'st99', marketName: 'ZZ Star 99', resultDate: ist.toISOString().slice(0, 10),
    openPanna: '123', openDigit: '6', declaredBy: 'flow-test',
  } })
  const crid = 'flow-' + Date.now()
  const bet = await j('POST', '/api/customer-app/bets',
    { items: [{ marketCode: MK, slot: 'open', type: 'single', num: '5', points: 100, clientRequestId: crid }] }, H)
  bal -= 100
  check('B10 place bid ₹100 → ok, wallet debited',
    bet.status === 200 && bet.data?.wallet === bal && bet.data?.placedCount === 1,
    `${bet.status} ${JSON.stringify(bet.data).slice(0, 140)}`)

  const replay = await j('POST', '/api/customer-app/bets',
    { items: [{ marketCode: MK, slot: 'open', type: 'single', num: '5', points: 100, clientRequestId: crid }] }, H)
  check('B11 same clientRequestId replay → ignored, wallet unchanged',
    replay.status === 200 && replay.data?.placedCount === 0 && replay.data?.duplicates === 1 && replay.data?.wallet === bal,
    JSON.stringify(replay.data).slice(0, 140))

  const bets = await j('GET', '/api/customer-app/bets?status=all', undefined, H)
  check('B12 my-bids → 1 pending bet + counts',
    bets.status === 200 && bets.data?.bets?.length === 1 && bets.data?.counts?.pending === 1,
    JSON.stringify(bets.data?.counts))

  const rz = await j('GET', `/api/customer-app/results?market=${MK}`, undefined, H)
  check('B13 results (temp market) → 200', rz.status === 200 && Array.isArray(rz.data?.results), `${rz.status}`)
  const rk = await j('GET', '/api/customer-app/results?market=kalyan', undefined, H)
  check('B14 results (demo market kalyan) → 200', rk.status === 200, `${rk.status}`)
  const st = await j('GET', '/api/customer-app/results?starline=1', undefined, H)
  const stCell = (st.data?.board || []).find((b: any) => b.hour === 99)
  check('B15 starline board → declared st99 result surfaced',
    st.status === 200 && Array.isArray(st.data?.board) && !!stCell && stCell.panna === '123' && stCell.digit === '6',
    JSON.stringify(st.data?.board || []).slice(0, 120))

  const wd1 = await j('POST', '/api/customer-app/withdrawals', { amount: 500 }, H)
  bal -= 500
  check('B16 withdraw ₹500 → hold (wallet debited)',
    wd1.status === 200 && wd1.data?.wallet === bal && wd1.data?.withdrawal?.status === 'pending',
    `${wd1.status} ${JSON.stringify(wd1.data).slice(0, 120)}`)
  const holdTxn = await db.appTransaction.findFirst({ where: { customerId: custId, type: 'withdraw_hold', amount: -500 } })
  check('B17 withdraw_hold ledger row', !!holdTxn)

  const rej = await j('POST', '/api/app-admin/withdrawals', { id: wd1.data.withdrawal.id, action: 'reject' }, { Cookie: cookie })
  const afterRej = await db.appCustomer.findUnique({ where: { id: custId! } })
  const refundTxn = await db.appTransaction.findFirst({ where: { customerId: custId, type: 'withdraw_refund', amount: 500 } })
  bal += 500
  check('B18 admin reject → refund (wallet restored + ledger)',
    rej.status === 200 && afterRej?.wallet === bal && !!refundTxn, `wallet ${afterRej?.wallet}`)

  const wd2 = await j('POST', '/api/customer-app/withdrawals', { amount: 500 }, H)
  const paid = await j('POST', '/api/app-admin/withdrawals', { id: wd2.data?.withdrawal?.id, action: 'paid' }, { Cookie: cookie })
  bal -= 500
  const afterPaid = await db.appCustomer.findUnique({ where: { id: custId! } })
  const paidTxn = await db.appTransaction.findFirst({ where: { customerId: custId, type: 'withdraw_paid' } })
  check('B19 withdraw ₹500 → admin paid (hold stands, paid ledger)',
    wd2.status === 200 && paid.status === 200 && afterPaid?.wallet === bal && !!paidTxn, `wallet ${afterPaid?.wallet}`)

  const notif = await j('GET', '/api/customer-app/notifications', undefined, H)
  const texts = JSON.stringify(notif.data?.notifications || [])
  check('B20 notifications → approval + withdrawal notices',
    notif.status === 200 && texts.includes('approved') && texts.toLowerCase().includes('withdraw'),
    `${notif.data?.notifications?.length} rows`)

  const pr = await j('GET', '/api/customer-app/push/register', undefined, H)
  check('B21 push register status → 200', pr.status === 200, `${pr.status}`)

  // ── C. Demo integrity ──
  console.log('── C. demo integrity ──')
  const comm = await j('GET', '/api/app-admin/commissions', undefined, { Cookie: cookie })
  check('C1 demo commission pending still ₹280 @2%', comm.data?.summary?.pendingAmount === 280, `got ${comm.data?.summary?.pendingAmount}`)

  const demo = await j('POST', '/api/customer-app/auth/login', { mobile: '9876500001', password: 'Demo@123' })
  check('C2 demo customer (Rakesh 9876500001) login ok', demo.status === 200 && !!demo.data?.token, `${demo.status}`)

  // ── Cleanup ──
  await cleanup()
  const leftC = await db.appCustomer.findUnique({ where: { mobile: MOBILE } })
  const leftM = await db.appMarket.findUnique({ where: { code: MK } })
  check('Cleanup — temp customer + market removed', !leftC && !leftM)

  console.log(`\n${pass} PASS / ${fail} FAIL`)
  if (fail > 0) process.exitCode = 1
}

main().catch(e => { console.error(e); process.exitCode = 1 }).finally(() => db.$disconnect())
