#!/bin/bash
# Task 42: FULL operator-pipeline proof for r4 — exactly what Hostinger runs:
#   npm ci (postinstall: prisma generate && prisma db push) → build → start (prestart db push)
# Then live tests against :3100 — the two reported incidents + the APK feature.
set -e
cd /home/z/my-project
STAGE=/home/z/my-project/zipstage-r4-pipeline

echo "══ 1. extract r4 ══"
rm -rf "$STAGE" && mkdir -p "$STAGE"
unzip -qq download/Satta_Matka_God_Hostinger_Ready_2026-10-09-r4.zip -d "$STAGE"

echo "══ 2. npm ci (postinstall self-heal fires) ══"
cd "$STAGE"
npm ci --no-audit --no-fund 2>&1 | tail -4

echo "══ 3. schema state after postinstall ══"
python3 - <<'PYEOF'
import sqlite3
c = sqlite3.connect('db/custom.db')
tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
print('ApkArtifact table:', 'ApkArtifact' in tables)
print('AgentCommissionWithdrawal table:', 'AgentCommissionWithdrawal' in tables)
cols = [r[1] for r in c.execute('PRAGMA table_info(AppCustomer)').fetchall()]
print('AppCustomer.pushToken column:', 'pushToken' in cols)
for t in ['AppCustomer','AppMarket','AppBet','AppTransaction','User']:
    print(t, c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0])
PYEOF

echo "══ 4. build (webpack, pinned next 16.1.3) ══"
npm run build 2>&1 | tail -4

echo "══ 5. boot on :3100 (prestart self-heal fires) ══"
rm -f /tmp/r4-boot.log
setsid -f bash -c "cd $STAGE && PORT=3100 npm start > /tmp/r4-boot.log 2>&1"
for i in $(seq 1 30); do
  sleep 2
  if curl -s -o /dev/null --max-time 2 http://127.0.0.1:3100/api/health; then break; fi
done
curl -s -o /dev/null -w "health: %{http_code}\n" http://127.0.0.1:3100/api/health
rg -n "db push|in sync" /tmp/r4-boot.log | head -3 || echo "(prestart quiet — already in sync)"
