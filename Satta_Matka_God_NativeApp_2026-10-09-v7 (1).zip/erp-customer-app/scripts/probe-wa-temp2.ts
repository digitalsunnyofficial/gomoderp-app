import { db } from '../src/lib/db'
const bcrypt = await import('bcryptjs')
const c = await db.appCustomer.create({
  data: { name: 'Priya WhatsApp', mobile: '9876500012', password: await bcrypt.hash('x1234567', 8), approvalStatus: 'approved' },
})
console.log(c.id)
process.exit(0)
