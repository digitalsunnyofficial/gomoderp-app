/**
 * probe-whatsapp-samples.ts — run the operator's 6 REAL WhatsApp blocks
 * (2026-09-30, "San pag" → Milan) through the live Smart Entry parser and
 * compare against the operator's own declared totals.
 *
 * Operator totals (the acceptance criteria):
 *   Block 1  All dp9 50rs ................ Total 4500   (90 DP pannas × 50)
 *   Block 2  Sp 7=75 / 8 / 3=75 .......... Total 2700   (3 anks × 12 SP chart pannas × 75)
 *   Block 3  20 pannas 150rs ............. Total 3000   (20 × 150)
 *   Block 4  20 pannas 150rs ............. Total 3000   (20 × 150)
 *   Block 5  Milan open motor seeds ...... Total 11200  (C(8,3)=56 × 100 × 2 seeds)
 *   Block 6  Milan open dp motor seeds ... Total 4480   (8×7=56 × 40 × 2 seeds)
 *
 * Run: bun scripts/probe-whatsapp-samples.ts
 */
import { parseUnifiedEntry } from '../src/lib/matka/entry-parser'

const TS = '[4:02 pm, 30/09/2026] San pag:'

const BLOCKS: Array<{ name: string; text: string; expected: number }> = [
  {
    name: 'B1: All dp9 @50',
    expected: 4500,
    text: `${TS} Milan

All dp9
50rs

Total 4500`,
  },
  {
    name: 'B2: Sp 7=75, 8, 3=75',
    expected: 2700,
    text: `${TS} Milan

Sp
7=75
8
3=75

Total 2700`,
  },
  {
    name: 'B3: 20 pannas @150',
    expected: 3000,
    text: `${TS} Milan

128 236 245 290

129 390 589 679

256 346 670 689

130 239 347 356

140 230 690 780

150rs

Total 3000`,
  },
  {
    name: 'B4: 20 pannas @150',
    expected: 3000,
    text: `${TS} Milan

178 367 457 790

124 340 458 467

125 134 170 189

180 289 478 568

145 235 569 578

150rs

Total 3000`,
  },
  {
    name: 'B5: Milan open motor (2 seeds @100)',
    expected: 11200,
    text: `${TS} Milan open motor
23457890,100
12345678,100

Total 11200`,
  },
  {
    name: 'B6: Milan open dp motor (2 seeds @40)',
    expected: 4480,
    text: `${TS} Milan open dp motor
23457890,40
12345678,40

Total 4480`,
  },
]

function bucketTotal(r: ReturnType<typeof parseUnifiedEntry>): number {
  const g = r.groups.reduce((s, grp) => s + grp.entries.reduce((x, e) => x + e.amount, 0), 0)
  return (
    r.singles.reduce((s, e) => s + e.amount, 0) +
    r.doubles.reduce((s, e) => s + e.amount, 0) +
    r.triples.reduce((s, e) => s + e.amount, 0) +
    r.common.reduce((s, e) => s + e.amount, 0) +
    g
  )
}

let okCount = 0
for (const b of BLOCKS) {
  const r = parseUnifiedEntry(b.text, 0)
  const total = bucketTotal(r)
  const ok = total === b.expected
  if (ok) okCount++
  console.log(`\n── ${b.name} — expected ${b.expected} → got ${total} ${ok ? '✓' : '✗ MISMATCH'}`)
  console.log(
    `   singles=${r.singles.length}(@${r.singles.reduce((s, e) => s + e.amount, 0)}) doubles=${r.doubles.length}(@${r.doubles.reduce((s, e) => s + e.amount, 0)}) triples=${r.triples.length}(@${r.triples.reduce((s, e) => s + e.amount, 0)}) common=${r.common.length}`
  )
  for (const g of r.groups) {
    const sum = g.entries.reduce((s, e) => s + e.amount, 0)
    console.log(`   group ${g.option}: ${g.entries.length} pannas, sum ${sum}, seeds=[${g.seeds.join(' | ')}]`)
    if (g.invalid.length) console.log(`     invalid: ${g.invalid.map(i => `${i.raw} (${i.reason})`).join(' ; ')}`)
  }
  if (r.unknownLabels.length) console.log(`   UNKNOWN LABELS: ${r.unknownLabels.join(', ')}`)
  if (r.skipped.length) console.log(`   skipped (${r.skipped.length}): ${r.skipped.slice(0, 6).join(' ; ')}${r.skipped.length > 6 ? ' …' : ''}`)
  // phantom-single detector: any single that came from a metadata line (amount 0)
  const phantoms = r.singles.filter(e => e.amount === 0)
  if (phantoms.length) console.log(`   ⚠ PHANTOM SINGLES @0: ${phantoms.map(e => e.number).join(',')}`)
}

console.log(`\n═══ ${okCount}/${BLOCKS.length} blocks match the operator totals ═══`)
if (okCount !== BLOCKS.length) process.exit(1)
