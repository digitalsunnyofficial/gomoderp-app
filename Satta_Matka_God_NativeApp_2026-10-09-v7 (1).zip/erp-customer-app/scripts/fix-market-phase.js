// One-off: backfill AppMarket.phase from category (night → night) for markets
// created before the phase/session fields existed.
const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

async function main() {
  const markets = await db.appMarket.findMany()
  for (const m of markets) {
    const phase = m.category === 'night' ? 'night' : 'day'
    if (m.phase !== phase) {
      await db.appMarket.update({ where: { id: m.id }, data: { phase } })
      console.log('updated', m.code, '→ phase', phase)
    }
  }
  console.log('done')
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
