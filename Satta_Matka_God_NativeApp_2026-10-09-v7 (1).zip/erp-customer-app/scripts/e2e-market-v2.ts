/**
 * E2E verification — Task 10 (market mgmt v2 + starlines + results split +
 * jodi/panel chart data + triple section + ERP mirror).
 *
 * Covers:
 *  1. Market list = exactly the 18 Name+Phase+Session records
 *  2. Starlines CRUD (create → patch → declare → delete)
 *  3. Customer app login (Vikram) → place bets (single/jodi/sp + sangam)
 *  4. ERP mirror: bets appear as ERP inventory rows (Entry List source) and
 *     master boards aggregate app + ERP channels
 *  5. Chart-data backfill (jodi & panel) — silent upsert, no settlement
 *  6. Market result declare still settles (regression)
 *
 * Run: bun scripts/e2e-market-v2.ts
 */
const BASE = 'http://localhost:3000'

function istDate(d = new Date()): string {
  // match app-engine istDate: IST = UTC+5:30
  const ist = new Date(d.getTime() + 5.5 * 3600000)
  return ist.toISOString().slice(0, 10)
}

async function api(path: string, opts: RequestInit = {}, cookie?: string, extraHeaders: Record<string, string> = {}) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(cookie ? { Cookie: cookie } : {}),
      ...extraHeaders,
      ...(opts.headers || {}),
    },
  })
  const text = await res.text()
  let json: any
  try { json = JSON.parse(text) } catch { json = { raw: text.slice(0, 200) } }
  return { status: res.status, json, setCookie: res.headers.get('set-cookie') }
}

let pass = 0, fail = 0
function check(name: string, cond: boolean, extra = '') {
  if (cond) { pass++; console.log(`PASS  ${name}`) }
  else { fail++; console.log(`FAIL  ${name} ${extra}`) }
}

async function main() {
  const today = istDate()
  console.log(`E2E market-v2 — ${today}`)

  // ── ERP session ──
  const login = await api('/api/auth', { method: 'POST', body: JSON.stringify({ action: 'login', username: 'superadmin@mb.com', password: 'SAdmin@123_321' }) })
  check('ERP super login', login.status === 200)
  const cookie = (login.setCookie || '').split(';')[0]
  // ERP data routes trust the client-sent identity headers (same as api-helpers.ts)
  const erpHeaders = {
    'x-user-id': String(login.json.id),
    'x-user-name': String(login.json.username),
    'x-user-role': String(login.json.role),
    'x-user-markets': String(login.json.assignedMarkets || ''),
  }
  const erp = (path: string, opts: RequestInit = {}) => api(path, opts, cookie, erpHeaders)

  // ── 1. Market list: 18 formula records, no phase-less surprises ──
  const mk = await erp('/api/app-admin/markets', {})
  check('markets GET 200', mk.status === 200)
  const markets: any[] = mk.json.markets || []
  check('18 session markets', markets.length === 18, `got ${markets.length}`)
  const expectNames = ['Sridevi', 'Time Bazaar', 'Milan', 'Kalyan', 'Main Bazaar', 'Rajdhani']
  check('all operator names present', expectNames.every(n => markets.some(m => m.name === n)))
  const kalyan = markets.filter((m: any) => m.name === 'Kalyan')
  check('Kalyan classic (phase none)', kalyan.length === 2 && kalyan.every((m: any) => m.phase === 'none'))
  const sridevi = markets.filter((m: any) => m.name === 'Sridevi')
  check('Sridevi 4 records (day/night × open/close)', sridevi.length === 4)
  check('no legacy shridevi/time/milan codes', !markets.some((m: any) => ['shridevi', 'time', 'milan', 'kalyan', 'main_bazaar'].includes(m.code)))

  // ── 2. Starlines CRUD ──
  const slList0 = await erp('/api/app-admin/starlines', {})
  check('starlines GET 200', slList0.status === 200)
  const sl0: any[] = slList0.json.starlines || []
  // idempotent re-runs: remove leftovers from previous crashed runs
  for (const prev of sl0.filter((s: any) => s.code === 'st9')) {
    await erp('/api/app-admin/starlines?id=' + prev.id, { method: 'DELETE' })
  }
  const slClean = await erp('/api/app-admin/starlines', {})
  check('seeded 5 starlines', (slClean.json.starlines || []).length === 5, `got ${(slClean.json.starlines || []).length}`)

  // create a new starline (09:00)
  const slCreate = await api('/api/app-admin/starlines', { method: 'POST', body: JSON.stringify({ hour: 9, minute: 0, betClosingMinutes: 3 }) }, cookie)
  check('starline create (st9)', slCreate.status === 200 && slCreate.json.starline?.code === 'st9', JSON.stringify(slCreate.json).slice(0, 120))

  // duplicate rejected
  const slDup = await api('/api/app-admin/starlines', { method: 'POST', body: JSON.stringify({ hour: 9 }) }, cookie)
  check('duplicate starline rejected 409', slDup.status === 409)

  // patch: rename + minute
  const slPatch = await api('/api/app-admin/starlines', { method: 'PATCH', body: JSON.stringify({ id: slCreate.json.starline.id, name: 'Morning Starline', minute: 30 }) }, cookie)
  check('starline patch (name+minute)', slPatch.status === 200 && slPatch.json.starline?.name === 'Morning Starline' && slPatch.json.starline?.minute === 30)

  // OFF starline blocks betting
  const slOff = await api('/api/app-admin/starlines', { method: 'PATCH', body: JSON.stringify({ id: slCreate.json.starline.id, isOn: false }) }, cookie)
  check('starline switch OFF', slOff.status === 200 && slOff.json.starline?.isOn === false)

  // ── 3. Customer app: session for Vikram (operator changed his password —
  // mint a session token directly instead of resetting anything) ──
  const { PrismaClient } = await import('@prisma/client')
  const pdb = new (require('@prisma/client').PrismaClient)()
  const vikram = await pdb.appCustomer.findUnique({ where: { mobile: '9852345605' } })
  const { randomUUID } = await import('crypto')
  const appToken = 'e2e_' + randomUUID().replace(/-/g, '')
  await pdb.appSession.create({ data: { token: appToken, customerId: vikram.id, expiresAt: new Date(Date.now() + 3600000) } })
  const appAuth = { Authorization: `Bearer ${appToken}` }
  check('Vikram session minted', !!vikram && !!appToken)
  await pdb.$disconnect()

  const home = await api('/api/customer-app/home', {}, undefined, { ...appAuth })
  check('app home 200', home.status === 200)
  const homeMarkets: any[] = home.json.markets || []
  check('home shows 18 markets', homeMarkets.length === 18, `got ${homeMarkets.length}`)
  check('home market identity "Kalyan Open"', homeMarkets.some((m: any) => (m.displayName || '').includes('Kalyan Open')))
  const starCfg = home.json.starline?.starlines || []
  check('home starlines configured list (OFF hidden)', starCfg.length === 5, `got ${starCfg.length}`)

  // pick a live market for betting (kalyan_open window 09:30→15:45 IST wide)
  const liveMk = homeMarkets.find((m: any) => m.code === 'kalyan_open') || homeMarkets[0]
  // re-run hygiene: drop today's declared result for that market so betting reopens
  {
    const { PrismaClient: PC2 } = await import('@prisma/client')
    const p2 = new PC2()
    await p2.appResult.deleteMany({ where: { marketCode: liveMk.code, resultDate: today } })
    await p2.$disconnect()
  }
  console.log(`  betting market: ${liveMk.code} (${liveMk.displayName || liveMk.name})`)

  const wallet0 = home.json.customer?.wallet
  const betsPayload = {
    items: [
      { marketCode: liveMk.code, slot: 'open', type: 'single', num: '7', points: 50, gameCode: 'single' },
      { marketCode: liveMk.code, slot: 'open', type: 'jodi', num: '71', points: 20, gameCode: 'jodi' },
      { marketCode: liveMk.code, slot: 'open', type: 'sp', num: '137', points: 10, gameCode: 'sp' },
      { marketCode: liveMk.code, slot: 'open', type: 'hsb', num: '380-5', points: 10, gameCode: 'hsb' },
    ],
  }
  const place = await api('/api/customer-app/bets', { method: 'POST', body: JSON.stringify(betsPayload) }, undefined, { ...appAuth })
  check('Vikram bets placed', place.status === 200 && place.json.placedCount === 4, JSON.stringify(place.json).slice(0, 200))
  check('mirror note present', typeof place.json.mirrorNote === 'string' && place.json.mirrorNote.includes('ERP entry:'), String(place.json.mirrorNote))
  check('wallet debited 90', place.json.wallet === wallet0 - 90, `${wallet0} → ${place.json.wallet}`)

  // starline bet on the OFF starline must be rejected
  const starBet = await api('/api/customer-app/bets', { method: 'POST', body: JSON.stringify({ items: [{ marketCode: 'st9', slot: 'open', type: 'single', num: '5', points: 10 }] }) }, undefined, { ...appAuth })
  check('OFF starline bet rejected', starBet.status === 400, JSON.stringify(starBet.json).slice(0, 120))

  // unconfigured hour (st3) must be rejected while managed starlines exist
  const starUn = await api('/api/customer-app/bets', { method: 'POST', body: JSON.stringify({ items: [{ marketCode: 'st3', slot: 'open', type: 'single', num: '5', points: 10 }] }) }, undefined, { ...appAuth })
  check('unconfigured starline hour rejected', starUn.status === 400 && JSON.stringify(starUn.json).includes('not available'), JSON.stringify(starUn.json).slice(0, 140))

  // bet on a configured ON starline (st12 = 12:30, accepting before 12:25 IST)
  const starOk = await api('/api/customer-app/bets', { method: 'POST', body: JSON.stringify({ items: [{ marketCode: 'st12', slot: 'open', type: 'single', num: '5', points: 10 }] }) }, undefined, { ...appAuth })
  check('configured starline bet accepted (or window-closed)', starOk.status === 200 || (starOk.status === 400 && JSON.stringify(starOk.json).includes('closed')), JSON.stringify(starOk.json).slice(0, 140))

  // ── 4. ERP mirror verification ──
  const invCodes = await erp('/api/inventory-codes', {})
  const codes: any[] = invCodes.json || []
  const appCode = Array.isArray(codes) ? codes.find((c: any) => c.code === `app_${liveMk.code}`) : null
  check('ERP InventoryCode app_<market> exists', !!appCode)

  const invList = await erp(`/api/inventories?search=${encodeURIComponent('Kalyan')}`, {})
  const invs: any[] = Array.isArray(invList.json) ? invList.json : (invList.json.inventories || invList.json.data || [])
  const todayInv = invs.find((i: any) => (i.inventoryCode?.code === `app_${liveMk.code}`))
  check('ERP inventory card exists for market today', !!todayInv, `invs ${invs.length}`)

  if (todayInv) {
    const ti = await erp(`/api/triple-inventories?inventoryId=${todayInv.id}`, {})
    const tiRows: any[] = Array.isArray(ti.json) ? ti.json : (ti.json.tripleInventories || [])
    const pannaRow = tiRows.find((r: any) => r.type === 'mix' && r.details?.includes('Customer App'))
    check('Triple row (panna bets) in ERP list', !!pannaRow)
    const sangamRow = tiRows.find((r: any) => r.type === 'sangam')
    check('Triple row (sangam bets) type sangam', !!sangamRow)
    const ds = await erp(`/api/double-single-inventories?inventoryId=${todayInv.id}`, {})
    const dsRows: any[] = Array.isArray(ds.json) ? ds.json : (ds.json.doubleSingleInventories || [])
    const singleRow = dsRows.find((r: any) => r.type === 'single' && r.details?.includes('Customer App'))
    const jodiRow = dsRows.find((r: any) => r.type === 'double' && r.details?.includes('Customer App'))
    check('DoubleSingle row (single bets) in ERP list', !!singleRow)
    check('DoubleSingle row (jodi bets) in ERP list', !!jodiRow)
    if (pannaRow) {
      const pd = JSON.parse(pannaRow.parsedData)
      check('panna row aggregates 137×10', (pd.numbers || []).some((n: any) => n.number === '137' && n.price === 10))
    }
  }

  // ── Master boards include app + ERP channel ──
  const mc = await erp(`/api/app-admin/market-charts?market=${liveMk.code}&date=${today}`, {})
  check('market-charts 200', mc.status === 200)
  const boards = mc.json.boards
  const singleCells = boards?.single?.open?.cells || []
  const jodiCells = boards?.double?.jodi?.cells || []
  const tripleCells = boards?.triple?.open?.cells || []
  check('single board has 7×50 (app)', singleCells.some((c: any) => c.num === '7' && c.points >= 50))
  check('double board has 71×20 (app)', jodiCells.some((c: any) => c.num === '71' && c.points >= 20))
  check('triple board has 137 (digit-set key)', tripleCells.some((c: any) => c.points >= 10))

  // ERP-only channel test: inject a pure-ERP row and confirm boards merge it
  if (todayInv) {
    await erp('/api/double-single-inventories', {
      method: 'POST',
      body: JSON.stringify({
        inventoryId: todayInv.id, type: 'single',
        details: 'WhatsApp paste test', parsedData: JSON.stringify({ numbers: [{ number: '3', price: 77 }] }),
        rate: 0, totalAmount: 77, createdBy: 'superadmin@mb.com',
      }),
    })
    const mc2 = await erp(`/api/app-admin/market-charts?market=${liveMk.code}&date=${today}`, {})
    const sc2 = mc2.json.boards?.single?.open?.cells || []
    check('boards merge pure-ERP WhatsApp row (3×77)', sc2.some((c: any) => c.num === '3' && c.points >= 77))
  }

  // ── 5. Chart-data backfill (Jodi & Panel) ──
  const backfill = await api('/api/app-admin/chart-data', {
    method: 'POST',
    body: JSON.stringify({
      marketCode: liveMk.code,
      entries: [
        { resultDate: '2026-09-20', openPanna: '137', closePanna: '347' },
        { resultDate: '2026-09-21', openPanna: '128', closePanna: '246' },
        { resultDate: '2026-09-22', openPanna: '380', closePanna: '470' },
      ],
    }),
  }, cookie)
  check('chart backfill saved 3 days', backfill.status === 200 && backfill.json.updated === 3, JSON.stringify(backfill.json).slice(0, 160))

  const cd = await erp(`/api/app-admin/chart-data?market=${liveMk.code}`, {})
  const cdRows: any[] = cd.json.results || []
  const r20 = cdRows.find((r: any) => r.resultDate === '2026-09-20')
  check('backfill row derives jodi 14 (137→1, 347→4? no: 1+2+4...) check digits', !!r20)
  if (r20) {
    check('open digit of 137 = 1', r20.openDigit === '1', String(r20.openDigit))
    check('close digit of 347 = 4', r20.closeDigit === '4', String(r20.closeDigit))
    check('jodi = 14', r20.jodi === '14', String(r20.jodi))
  }
  // today/future dates rejected
  const bfToday = await api('/api/app-admin/chart-data', {
    method: 'POST',
    body: JSON.stringify({ marketCode: liveMk.code, entries: [{ resultDate: today, openPanna: '123', closePanna: '456' }] }),
  }, cookie)
  check('backfill rejects today', bfToday.status === 200 && bfToday.json.updated === 0 && (bfToday.json.skipped || []).length === 1)

  // app results feed includes backfill
  const appRes = await api(`/api/customer-app/results?market=${liveMk.code}`, {}, undefined, { ...appAuth })
  const appRows: any[] = appRes.json.results || []
  check('app results include backfilled 2026-09-20', appRows.some((r: any) => r.resultDate === '2026-09-20' && r.jodi === '14'))

  // ── 6. Regression: market result declare settles ──
  const declare = await api('/api/app-admin/results', {
    method: 'POST',
    body: JSON.stringify({ marketCode: liveMk.code, resultDate: today, openPanna: '137', closePanna: '380' }),
  }, cookie)
  check('declare result 200', declare.status === 200, JSON.stringify(declare.json).slice(0, 160))
  const s = declare.json.settlement
  check('settlement ran (4 bids considered)', s && s.considered >= 4, JSON.stringify(s))
  check('exactly the 137 SP won (10×140=1400)', s && s.won === 1 && s.totalWin === 1400, JSON.stringify(s))

  // betting locked after declare
  const locked = await api('/api/customer-app/bets', { method: 'POST', body: JSON.stringify({ items: [{ marketCode: liveMk.code, slot: 'open', type: 'single', num: '1', points: 10 }] }) }, undefined, { ...appAuth })
  check('betting locked after declare', locked.status === 400 && JSON.stringify(locked.json).includes('declared'))

  // ── cleanup: delete the test starline ──
  const slDel = await erp('/api/app-admin/starlines?id=' + slCreate.json.starline.id, { method: 'DELETE' })
  check('starline delete', slDel.status === 200)

  console.log(`\nRESULT: ${pass} passed, ${fail} failed`)
  process.exit(fail ? 1 : 0)
}

main().catch(e => { console.error(e); process.exit(1) })
