/**
 * rename-role.ts — One-shot codemod: Master Admin → Super Admin.
 *
 * Internal role value: 'master' → 'super'
 * Display strings:     "Master Admin" → "Super Admin"
 *
 * Run: bun scripts/rename-role.ts   (idempotent — safe to re-run)
 */
import { readFileSync, writeFileSync } from 'fs'
import { execSync } from 'child_process'

const ROOT = '/home/z/my-project'

// Files that contain role values or Master Admin display strings
const files = execSync(
  `rg -l "master" ${ROOT}/src ${ROOT}/prisma/seed.js ${ROOT}/prisma/schema.prisma 2>/dev/null || true`,
  { shell: '/bin/bash' }
)
  .toString()
  .split('\n')
  .map(f => f.trim())
  .filter(Boolean)

console.log(`Scanning ${files.length} files…`)

// Ordered replacement rules (applied per file, in order)
const rules: Array<[RegExp, string]> = [
  // ── Display strings first ──
  [/Master Admin/g, 'Super Admin'],
  [/Master admin/g, 'Super admin'],
  [/master admin/g, 'super admin'], // comments only
  [/\? 'Master' :/g, "? 'Super' :"],
  [/`Master`/g, '`Super`'],
  [/>Master<\/span>/g, '>Super</span>'],

  // ── Role VALUES ──
  [/(role\s*===\s*)'master'/g, "$1'super'"],
  [/(role\s*!==\s*)'master'/g, "$1'super'"],
  [/(role:\s*)'master'/g, "$1'super'"],
  [/(role\s*===\s*)"master"/g, '$1"super"'],
  [/(role\s*!==\s*)"master"/g, '$1"super"'],
  [/(role:\s*)"master"/g, '$1"super"'],
  [/(value=)"master"/g, '$1"super"'],
  // schema.prisma comment:  // "master", "manager", or "user"
  [/\/\/ "master", "manager"/g, '// "super", "manager"'],
  // seed.js: defaultRole / requestedRole contexts are manager|user — untouched
]

let totalChanges = 0
for (const file of files) {
  const before = readFileSync(file, 'utf8')
  let after = before
  for (const [re, to] of rules) {
    after = after.replace(re, to)
  }
  if (after !== before) {
    writeFileSync(file, after)
    const n = before.split('master').length - 1
    totalChanges++
    console.log(`  updated: ${file.replace(ROOT + '/', '')}`)
  }
}

console.log(`\nDone. ${totalChanges} files updated.`)

// Report any remaining role-value 'master' literals (expected: hierarchy-auth legacy map only)
console.log('\nRemaining role-value literals (review):')
try {
  const out = execSync(
    `rg -n "'master'|\"master\"" ${ROOT}/src ${ROOT}/prisma/seed.js --no-heading 2>/dev/null | rg -v "master_admin|MASTER_ADMIN|Super|super" || true`,
    { shell: '/bin/bash' }
  ).toString()
  console.log(out || '  (none)')
} catch {
  console.log('  (none)')
}
