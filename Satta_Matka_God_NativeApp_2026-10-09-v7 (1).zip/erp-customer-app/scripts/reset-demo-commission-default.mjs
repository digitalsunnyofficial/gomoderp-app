// reset-demo-commission-default.mjs — aligns the shipped demo ledger with the
// operator rule (2026-10): global commission rate NOT configured → built-in
// default 2% applies. Deletes the agent_commission_rate AppConfig row (so the
// UI shows "default 2% in effect") and re-prices the agentsanjay demo ledger
// rows from the previous 5% to 2% (amount = round(baseAmount * 0.02)).
//
// Direct Prisma — no server required. Idempotent.
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

const AGENT = 'agentsanjay'

async function main() {
  // 1) Unset the global rate → default 2% in effect
  const del = await db.appConfig.deleteMany({ where: { key: 'agent_commission_rate' } })
  console.log(`agent_commission_rate config rows deleted: ${del.count} → built-in default 2% applies`)

  // 2) Re-price the demo commission rows at 2%
  const rows = await db.agentCommission.findMany({ where: { agentUsername: AGENT } })
  let total = 0
  for (const r of rows) {
    if (r.status !== 'pending') { console.log(`· skip ${r.id} (${r.status})`); continue }
    const newAmount = Math.round(r.baseAmount * 0.02)
    await db.agentCommission.update({ where: { id: r.id }, data: { rate: 2, amount: newAmount } })
    total += newAmount
    console.log(`· ${r.detail || r.id}: ₹${r.baseAmount} @ 5% → ₹${newAmount} @ 2%`)
  }
  console.log(`demo ledger re-priced: ${rows.length} rows, pending total ₹${total} on the agentsanjay plays`)

  // 3) Verify
  const agg = await db.agentCommission.aggregate({
    where: { agentUsername: AGENT, status: 'pending' },
    _sum: { amount: true, baseAmount: true }, _count: { _all: true },
  })
  console.log(`verify: ${agg._count._all} pending rows, ₹${agg._sum.amount} commission on ₹${agg._sum.baseAmount} played`)
  if (agg._sum.amount !== 280) {
    console.log('WARNING: expected ₹280 (2% of ₹14000) — check rows above')
  }
}

main().catch(e => { console.error('FATAL', e); process.exit(1) }).finally(() => db.$disconnect())
