const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  PageBreak, Header, Footer, PageNumber, NumberFormat,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  PageOrientation, LevelFormat, TableOfContents,
} = require("docx");
const fs = require("fs");

// ─── Palette ─────────────────────────────────────────────────────
const P = {
  primary: "101820",
  body: "182030",
  secondary: "506070",
  accent: "2D6A4F",
  surface: "F5F7FA",
  white: "FFFFFF",
  light: "E8F5E9",
  tableHead: "1B4332",
  tableHeadText: "FFFFFF",
  wireBg: "F0F4F0",
  wireBorder: "94A3B8",
  mobileBg: "E3F2FD",
};

// ─── Helpers ─────────────────────────────────────────────────────
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 480, after: 200, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: P.primary, font: { ascii: "Calibri", eastAsia: "SimHei" } })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: P.primary, font: { ascii: "Calibri", eastAsia: "SimHei" } })],
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 24, color: P.primary, font: { ascii: "Calibri", eastAsia: "SimHei" } })],
  });
}
function p(text) {
  return new Paragraph({
    spacing: { after: 120, line: 312 },
    children: [new TextRun({ text, size: 22, color: P.body, font: { ascii: "Calibri", eastAsia: "SimSun" } })],
  });
}
function pBold(text) {
  return new Paragraph({
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 22, color: P.primary, font: { ascii: "Calibri", eastAsia: "SimHei" } })],
  });
}
function pMono(text) {
  return new Paragraph({
    spacing: { after: 80, line: 280 },
    indent: { left: 480 },
    children: [new TextRun({ text, size: 20, color: "334155", font: { ascii: "Consolas", eastAsia: "Consolas" } })],
  });
}
function empty() {
  return new Paragraph({ spacing: { after: 80 }, children: [] });
}

// Table helper
function makeTable(headers, rows, colWidths) {
  const cellMargins = { top: 50, bottom: 50, left: 100, right: 100 };
  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: headers.map((h, i) =>
      new TableCell({
        width: { size: colWidths[i], type: WidthType.PERCENTAGE },
        shading: { type: ShadingType.CLEAR, fill: P.tableHead },
        margins: cellMargins,
        children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 20, color: P.tableHeadText, font: { ascii: "Calibri", eastAsia: "SimHei" } })] })],
      })
    ),
  });
  const dataRows = rows.map((row, ri) =>
    new TableRow({
      cantSplit: true,
      children: row.map((cell, ci) =>
        new TableCell({
          width: { size: colWidths[ci], type: WidthType.PERCENTAGE },
          shading: ri % 2 === 0 ? { type: ShadingType.CLEAR, fill: P.surface } : undefined,
          margins: cellMargins,
          children: [new Paragraph({ children: [new TextRun({ text: String(cell), size: 20, color: P.body, font: { ascii: "Calibri", eastAsia: "SimSun" } })] })],
        })
      ),
    })
  );
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 1, color: "D0D0D0" },
      bottom: { style: BorderStyle.SINGLE, size: 1, color: "D0D0D0" },
      left: { style: BorderStyle.SINGLE, size: 1, color: "D0D0D0" },
      right: { style: BorderStyle.SINGLE, size: 1, color: "D0D0D0" },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: "E0E0E0" },
      insideVertical: { style: BorderStyle.SINGLE, size: 1, color: "E0E0E0" },
    },
    rows: [headerRow, ...dataRows],
  });
}

// Wireframe box helper - ASCII wireframe representation
function wireframe(lines) {
  const maxWidth = Math.max(...lines.map(l => l.length)) + 4;
  const top = "+" + "-".repeat(maxWidth) + "+";
  const rows = lines.map(l => "| " + l.padEnd(maxWidth - 2) + " |");
  return [top, ...rows, top].map(line =>
    new Paragraph({
      spacing: { after: 0, line: 240 },
      children: [new TextRun({ text: line, size: 18, color: "475569", font: { ascii: "Consolas", eastAsia: "Consolas" } })],
    })
  );
}

// ─── COVER SECTION ───────────────────────────────────────────────
function buildCover() {
  const totalHeight = 16838;
  const innerHeight = totalHeight - 1200; // safety margin
  const cellBorders = {
    top: { style: BorderStyle.NONE },
    bottom: { style: BorderStyle.NONE },
    left: { style: BorderStyle.NONE },
    right: { style: BorderStyle.NONE },
    insideHorizontal: { style: BorderStyle.NONE },
    insideVertical: { style: BorderStyle.NONE },
  };
  return [
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: cellBorders,
      rows: [
        new TableRow({
          height: { value: totalHeight, rule: "exact" },
          children: [
            new TableCell({
              width: { size: 100, type: WidthType.PERCENTAGE },
              verticalAlign: "top",
              borders: cellBorders,
              shading: { type: ShadingType.CLEAR, fill: "0D1B2A" },
              children: [
                new Paragraph({ spacing: { before: 3200 }, children: [] }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 200, after: 100, line: 1200, lineRule: "atLeast" },
                  children: [new TextRun({ text: "MATKA CARD ERP", size: 72, bold: true, color: "FFFFFF", font: { ascii: "Calibri", eastAsia: "SimHei" } })],
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 200, after: 100, line: 600, lineRule: "atLeast" },
                  children: [new TextRun({ text: "Master Documentation", size: 40, color: "81C784", font: { ascii: "Calibri", eastAsia: "SimHei" } })],
                }),
                new Paragraph({ spacing: { before: 400 }, children: [] }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { after: 60 },
                  children: [new TextRun({ text: "Complete System Flow  |  Wireframes  |  Input Samples", size: 22, color: "B0BEC5", font: { ascii: "Calibri", eastAsia: "SimSun" } })],
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { after: 60 },
                  children: [new TextRun({ text: "Module Working Briefs  |  Page Correlations  |  Internal Linking", size: 22, color: "B0BEC5", font: { ascii: "Calibri", eastAsia: "SimSun" } })],
                }),
                new Paragraph({ spacing: { before: 1600 }, children: [] }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [new TextRun({ text: "Master Admin  &  User Android App", size: 24, bold: true, color: "4CAF50", font: { ascii: "Calibri", eastAsia: "SimHei" } })],
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 100 },
                  children: [new TextRun({ text: "Version 1.0  |  August 2026", size: 20, color: "78909C", font: { ascii: "Calibri" } })],
                }),
              ],
            }),
          ],
        }),
      ],
    }),
  ];
}

// ─── DOCUMENT SECTIONS ───────────────────────────────────────────

function section1_Terminology() {
  return [
    h1("1. Terminology & Domain Concepts"),
    p("This section establishes the core domain vocabulary used throughout the Matka Card ERP system. Every term here maps directly to code variables, database fields, and UI labels. Understanding these terms is essential before examining any module flow or input pattern."),
    makeTable(
      ["Term", "Domain Meaning", "Code Mapping", "Database Model"],
      [
        ["Card", "A daily entry sheet for a market/game containing all panna bets for that session", "Inventory", "Inventory"],
        ["Hisab", "Settlement / accounting entry for paying out winnings to vendors", "Settlement", "Settlement"],
        ["Khatri", "Vendor / bookie who takes bets and pays winnings", "Vendor", "Vendor"],
        ["Panna", "A 3-digit number (000-999) in the matka system, bet on specific digit combinations", "ParsedEntry.number", "TripleInventory.parsedData"],
        ["Ank", "Column position (1-10) = digitSum % 10, the result digit", "calculateTriplePosition()", "Computed at runtime"],
        ["SP (Single Panna)", "3-digit panna where all digits are different (120 total, 12 per ank)", "isSP(), SP_SET", "chart-definitions.ts"],
        ["DP (Double Panna)", "3-digit panna where exactly 2 digits are same (90 total, 9 per ank)", "isDP(), DP_SET", "chart-definitions.ts"],
        ["TP (Triple Panna)", "3-digit panna where all 3 digits are same (10 total: 000-999, 1 per ank)", "isTP(), TP_SET", "chart-definitions.ts"],
        ["220 Chart", "SP(120) + DP(90) + TP(10) = 220 total pannas, the canonical chart", "PANNA_220_CHART", "Hardcoded 22x10 array"],
        ["Motor Pana", "All C(n,3) SP combinations from a digit set (e.g., 12489 yields 10 Motor pannas)", "expandMotor()", "group-expanders.ts"],
        ["Mix", "Free-form WhatsApp paste parsed by the v5 parser into panna+rate entries", "tripleMode='mix'", "TripleInventory.type='mix'"],
        ["Group", "Structured input: seeds expanded via group expander (SP/DP/TP/Motor etc.)", "tripleMode='group'", "TripleInventory.type='group'"],
        ["Common", "2-digit series number generates exactly 10 pannas for that series", "tripleMode='common'", "TripleInventory.type='common'"],
        ["Single", "1-digit bet (0-9) with rate, stored in DoubleSingleInventory", "dsMode='single'", "DoubleSingleInventory.type='single'"],
        ["Double", "2-digit bet (00-99) with rate, stored in DoubleSingleInventory", "dsMode='double'", "DoubleSingleInventory.type='double'"],
        ["Amount", "Raw amount entry without pannas (for both triple and DS)", "type='amount'", "Both models"],
      ],
      [15, 35, 25, 25]
    ),
    empty(),
    p("The 220 Panna Chart is the foundational data structure. It is organized as a 22-row by 10-column grid where each column represents an Ank (1-10). Rows 0-11 contain SP pannas (12 per column), row 12 contains TP pannas (1 per column: 111, 222, ..., 000), and rows 13-21 contain DP pannas (9 per column). This chart is rendered via HTML Canvas for download and sharing, and supports percentage adjustments (less/add) and per-column deductions applied by the master admin."),
  ];
}

function section2_Markets() {
  return [
    h1("2. Markets & Game Structure"),
    p("The system supports multiple markets, each representing a different Matka game session. Markets are color-coded throughout the UI for instant visual identification. The master admin can add custom markets beyond the five built-in ones, and these are persisted in localStorage for the admin session."),
    makeTable(
      ["Market", "Color Code", "Game Types", "Description"],
      [
        ["Milan", "Cyan (#06B6D4)", "Open, Close, Night-Open, Night-Close", "Milan Day and Milan Night sessions"],
        ["Shridevi", "Purple (#8B5CF6)", "Open, Close, Night-Open, Night-Close", "Shridevi Day and Night sessions"],
        ["Time", "Green (#10B981)", "Open, Close, Night-Open, Night-Close", "Time Bazar sessions"],
        ["Kalyan", "Amber (#F59E0B)", "Open, Close, Night-Open, Night-Close", "Kalyan Day and Night sessions"],
        ["Rajdhani", "Red (#EF4444)", "Open, Close, Night-Open, Night-Close", "Rajdhani Day and Night sessions"],
      ],
      [15, 20, 30, 35]
    ),
    empty(),
    p("Each market has InventoryCodes representing specific game sessions (e.g., 'Milan Open', 'Kalyan Close'). An Inventory (Card) is created for a specific date + InventoryCode combination. Regular users are assigned specific markets via the Market Permissions module, and all their data access is automatically filtered by their assigned markets. The master admin has unrestricted access to all markets."),
    h2("2.1 Inventory Code Types"),
    p("Each market supports four session types that correspond to different opening times within a day. These types determine when the card entries are active and when settlements are calculated."),
    makeTable(
      ["Type", "Code Suffix", "Active Hours", "Settlement Window"],
      [
        ["open", "_O", "Morning (9:00-11:00)", "Same day evening"],
        ["close", "_C", "Evening (17:00-19:00)", "Next day morning"],
        ["night-open", "_NO", "Night (21:00-23:00)", "Next day afternoon"],
        ["night-close", "_NC", "Late Night (01:00-03:00)", "Next day evening"],
      ],
      [20, 20, 30, 30]
    ),
  ];
}

function section3_Architecture() {
  return [
    h1("3. System Architecture"),
    p("The Matka Card ERP is built as a single-page application (SPA) using Next.js 16 with React 19. The entire UI is contained in a single monolithic page.tsx file (9,716 lines) that switches between pages using Zustand state management. The system features a dual UI architecture: a full-featured desktop interface with sidebar navigation, and a Material Design mobile interface optimized for Android devices."),
    h2("3.1 Technology Stack"),
    makeTable(
      ["Layer", "Technology", "Version", "Purpose"],
      [
        ["Framework", "Next.js", "16.1.1", "Server-side rendering, API routes, standalone output"],
        ["UI Library", "React", "19.x", "Component rendering with hooks and transitions"],
        ["State Management", "Zustand", "5.x", "Client-side global state (currentPage, auth, mobile)"],
        ["Database", "SQLite via Prisma", "6.11.1", "ORM with 15 models, migrations, and seed data"],
        ["UI Components", "shadcn/ui (Radix)", "Latest", "50+ accessible UI primitives"],
        ["Styling", "Tailwind CSS", "4.x", "Utility-first CSS with responsive breakpoints"],
        ["Icons", "lucide-react", "Latest", "Consistent icon library across all pages"],
        ["Animation", "framer-motion", "Latest", "Page transitions and micro-interactions"],
        ["Proxy", "Caddy", "Latest", "Reverse proxy on port 81 to Next.js on port 3000"],
      ],
      [15, 25, 15, 45]
    ),
    empty(),
    h2("3.2 Dual UI Architecture"),
    p("The system automatically detects the device type using window.innerWidth < 768 and switches between completely different UI implementations. The desktop UI features a sidebar with collapsible sections, a topbar with user info, and full-featured forms with inline validation. The mobile UI uses Material Design patterns including a top app bar, bottom navigation with 5 tabs, floating action buttons (FAB), and card-based layouts optimized for touch interaction. Both interfaces share the same API layer and state management, ensuring data consistency across devices."),
    makeTable(
      ["Aspect", "Desktop", "Mobile (Android)"],
      [
        ["Navigation", "Left sidebar with collapsible sections + topbar", "Bottom navigation (5 tabs) + top app bar"],
        ["Layout", "grid-cols-[240px_1fr] sidebar + content", "Full-width cards with FAB for actions"],
        ["Detection", "window.innerWidth >= 768", "window.innerWidth < 768"],
        ["Login", "LoginPage - standard form", "MobileLoginPage - Material Design form"],
        ["Card Entry", "Full CardInventoryPage with tabs", "Routes to same page, touch-optimized"],
        ["Performance", "Standard React rendering", "useDeferredValue for heavy lists, 150ms deferred fetches"],
        ["State", "useAppStore (shared Zustand)", "useAppStore (shared Zustand)"],
      ],
      [15, 40, 45]
    ),
    empty(),
    h2("3.3 Authentication & Authorization"),
    p("Authentication uses a header-based approach rather than session cookies. The frontend stores user credentials in localStorage under the key 'erp_user' after a successful POST to /api/auth. Every subsequent API call via the apiFetch() helper automatically injects four custom headers: x-user-id, x-user-name, x-user-role, and x-user-markets. API routes read these headers using readAuthContext() for fast access or getAuthUser() for database-verified access. Market access is enforced via canAccessMarket() and marketFilter() Prisma where-clause builders, which restrict regular users to their assigned markets while giving master admins unrestricted access."),
    p("On first login, non-master users automatically receive a 7-day trial subscription. Users can be locked by the master admin, which prevents login entirely and is tracked with lockedAt, lockedBy, and lockReason fields. All authentication events and mutations are logged to the UserActivity table for audit purposes."),
    h2("3.4 API Routes Summary"),
    p("The system provides 25+ API routes organized into functional groups. All routes follow RESTful patterns with market-based access control. The following table provides a comprehensive mapping of every API endpoint, its supported methods, and its purpose within the system."),
    makeTable(
      ["Endpoint", "Methods", "Purpose", "Access Control"],
      [
        ["/api/auth", "POST", "Login (check lock, auto-trial, set session)", "Public"],
        ["/api/auth/logout", "POST", "Logout and clear session", "Authenticated"],
        ["/api/inventories", "GET/POST", "List (paginated, market-filtered) / Create card", "Market filter"],
        ["/api/inventories/[id]", "GET/PUT/DELETE", "Single card CRUD with market access", "Owner + market"],
        ["/api/inventory-codes", "GET", "List all market game codes", "Market filter"],
        ["/api/triple-inventories", "GET/POST", "List/Save mix/group/common/amount entries", "Market filter"],
        ["/api/triple-inventories/[id]", "DELETE", "Delete entry + recalc parent total", "Market filter"],
        ["/api/double-single-inventories", "GET/POST", "List/Save single/double/amount entries", "Market filter"],
        ["/api/double-single-inventories/[id]", "DELETE", "Delete entry + recalc parent total", "Market filter"],
        ["/api/vendors", "GET/POST", "List/Create Khatri (vendor)", "Master only for create"],
        ["/api/vendors/[id]", "GET/PUT/DELETE", "Khatri CRUD", "Market filter"],
        ["/api/settlements", "GET/POST", "List/Create Hisab (settlement)", "Market filter"],
        ["/api/settlements/[id]", "GET/PUT/DELETE", "Hisab CRUD", "Market filter"],
        ["/api/users", "GET/POST", "List/Create user", "Master only"],
        ["/api/users/[id]", "GET/PUT/DELETE", "User CRUD", "Master only"],
        ["/api/users/[id]/markets", "PUT", "Update assigned markets", "Master only"],
        ["/api/users/[id]/lock", "PUT", "Lock/unlock user", "Master only"],
        ["/api/users/[id]/permissions", "PUT", "Update per-code permissions", "Master only"],
        ["/api/dashboard", "GET", "Aggregate statistics", "Role-based stats"],
        ["/api/user-activity", "GET", "Audit trail", "Master only"],
        ["/api/chart-revisions", "GET/POST", "Chart revision log", "Master only"],
        ["/api/parser-exceptions", "GET/POST", "Parser exception records", "Master only"],
        ["/api/parser-exceptions/[id]", "PATCH", "Resolve/ignore exception", "Master only"],
        ["/api/parser-config", "GET", "Parser configuration", "Master only"],
        ["/api/subscription-plans", "GET/POST", "Subscription plan CRUD", "Master only"],
        ["/api/user-subscriptions/check", "GET", "Check current user access", "Authenticated"],
        ["/api/payments", "GET/POST", "Payment records", "Master only"],
        ["/api/landing-config", "GET/POST", "Landing page CMS", "Master only"],
      ],
      [25, 12, 38, 25]
    ),
  ];
}

function section4_DatabaseSchema() {
  return [
    h1("4. Database Schema"),
    p("The system uses SQLite via Prisma ORM with 15 models. The schema supports the complete Matka Card ERP workflow from card creation through settlement. Key relationships include Inventory as the parent entity containing TripleInventory and DoubleSingleInventory entries, Vendor (Khatri) linked to both entries and settlements, and a comprehensive audit trail through UserActivity, ChartRevision, and ParserException models."),
    makeTable(
      ["Model", "Purpose", "Key Fields", "Relationships"],
      [
        ["User", "Authentication & RBAC", "username, password, role, assignedMarkets, isLocked", "1:N UserPermission, UserSubscription"],
        ["UserPermission", "Per-code access control", "inventoryCode, canView/canEdit/canDelete", "N:1 User"],
        ["InventoryCode", "Market game session codes", "code (unique), name, market, type", "Referenced by Inventory, Settlement"],
        ["Inventory", "Card (daily entry sheet)", "date, time, inventoryCodeId, status, totalAmount", "1:N Triple, DoubleSingle; N:1 InventoryCode"],
        ["TripleInventory", "Mix/Group/Common/Amount", "vendorId, type, details, parsedData, rate, totalAmount", "N:1 Inventory, Vendor"],
        ["DoubleSingleInventory", "Single/Double/Amount", "vendorId, type, details, parsedData, rate, totalAmount", "N:1 Inventory, Vendor"],
        ["Vendor", "Khatri (bookie)", "code, businessName, mobileNo, advance, openingBalance", "1:N Triple, DoubleSingle, Settlement"],
        ["Settlement", "Hisab (payment record)", "date, vendorId, amount, commissionRate, winning, status", "N:1 Vendor, InventoryCode"],
        ["UserActivity", "Audit trail", "userId, action, entity, entityId, market, metadata", "N:1 User"],
        ["ChartRevision", "Chart edit history", "chartId, editedBy, action, previousData/newData", "Standalone audit"],
        ["ParserException", "Skipped/dropped records", "originalText, market, reason, kind, status", "Standalone audit"],
        ["SubscriptionPlan", "SaaS plan definition", "name, label, durationDays, price, features", "1:N UserSubscription"],
        ["UserSubscription", "User plan assignment", "userId, planId, startDate/endDate, status", "N:1 User, SubscriptionPlan"],
        ["Payment", "Payment tracking", "subscriptionId, amount, method, status, receiptNo", "N:1 UserSubscription"],
        ["LandingConfig", "Landing page CMS", "section, content (JSON), isActive", "Standalone config"],
      ],
      [15, 20, 35, 30]
    ),
  ];
}

function section5_MasterAdminFlow() {
  return [
    h1("5. Master Admin - Complete Flow"),
    p("The master admin has full unrestricted access to all system modules. This section documents every page the master admin can access, the workflow within each page, the wireframe layout, and how pages connect to each other. The master admin sidebar contains 7 navigation sections with a total of 20+ pages."),
    h2("5.1 Navigation Map"),
    p("The master admin sidebar organizes pages into 7 collapsible sections. Each section groups related functionality. Clicking any navigation item sets the Zustand currentPage state, which triggers a React re-render to display the corresponding page component. The sidebar persists across all pages and highlights the active item."),
    makeTable(
      ["Section", "Pages", "Nav Key", "Component"],
      [
        ["Main", "Dashboard", "dashboard", "DashboardPage"],
        ["Card", "New Card, Card Lists", "inv-new, inv-list", "NewInventoryPage, InventoryListPage"],
        ["Hisab", "New Hisab, Hisab Records, Khatri Hisab", "sett-new, sett-list, vendor-sett", "NewSettlementPage, SettlementListPage, VendorSettlementPage"],
        ["Admin Only", "Khatri, Settings", "vendor, configure", "VendorPage, ConfigurePage"],
        ["System Mgmt", "Users, Market Permissions, User Activity, Locked Users, Parser Exceptions, Parser Config, Chart Revisions", "sys-mgmt-*", "UsersPage, MarketPermissionsPage, ..."],
        ["Subscription", "Plans, User Subscriptions, Payments", "sub-plans, sub-users, sub-payments", "SubscriptionPlansPage, ..."],
        ["Website", "Landing Page", "landing-config", "LandingConfigPage"],
      ],
      [12, 30, 25, 33]
    ),
    empty(),

    h2("5.2 Dashboard"),
    h3("5.2.1 Wireframe"),
    ...wireframe([
      "+--Dashboard------------------------------------------+",
      "| [Total Cards] [Hisab Done] [Winning Paid] [Khatris] |",
      "|                                                      |",
      "| Quick Actions:                                       |",
      "| [New Card] [New Hisab] [View Cards] [View Hisab]    |",
      "|                                                      |",
      "| Recent Card Entries:                                 |",
      "| Date  | Market  | Code    | Amount | Status         |",
      "| ...   | ...     | ...     | ...    | ...            |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("The DashboardPage component displays four aggregate stat cards fetched from GET /api/dashboard. These include Total Cards (count of Inventory records), Hisab Done (count of completed Settlements), Total Winning Paid (sum of Settlement amounts with status='paid'), and Active Khatris (count of active Vendor records). Below the stats are four quick-action tiles that provide one-click navigation to the most common tasks. A recent card entries table shows the latest 10 Inventory records with date, market, code, total amount, and status columns."),
    h3("5.2.2 Data Flow"),
    p("On mount, the component calls apiFetch('/api/dashboard') which returns aggregated statistics. The recent entries table calls apiFetch('/api/inventories?page=1&limit=10'). All data respects market access control, though the master admin sees all markets. Navigation from quick actions sets the Zustand currentPage to the target page key."),

    h2("5.3 New Card (New Inventory)"),
    h3("5.3.1 Wireframe"),
    ...wireframe([
      "+--New Card-------------------------------------------+",
      "| Card Date:  [____________]  (date picker)            |",
      "| Card Code:  [____v______]  (dropdown)                |",
      "|             Options: Milan Open, Milan Close, ...    |",
      "| Remark:     [____________]  (optional text)          |",
      "|                                                      |",
      "| [Create Card]                                        |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("The NewInventoryPage provides a form with three fields: date (defaults to today, with a date picker), inventoryCodeId (dropdown populated from GET /api/inventory-codes showing market+type pairs), and remark (optional free text). On submit, POST /api/inventories creates the Inventory record with the selected date, time (auto-captured), inventoryCodeId, remark, and createdBy fields. After successful creation, the system sets viewingInventoryId and navigates to the card-view page where data entry begins."),
    h3("5.3.2 Input Sample"),
    pBold("Form Fields:"),
    pMono("Date: 09/08/2026 (auto-filled, editable via picker)"),
    pMono("Card Code: Milan Open (selected from dropdown)"),
    pMono("Remark: Morning session (optional)"),
    pMono("POST /api/inventories { date, time: '10:30', inventoryCodeId, remark, createdBy: 'master' }"),

    h2("5.4 Card Inventory Page (Card View) - THE CORE PAGE"),
    p("This is the heart of the ERP system where all data entry occurs. The CardInventoryPage is the largest component in the codebase (~1,700 lines) and handles both Triple (Mix/Group/Common/Amount) and Double-Single (Single/Double/Amount) data entry with full parsing, chart rendering, and CRUD operations."),
    h3("5.4.1 Wireframe - Main Layout"),
    ...wireframe([
      "+--Card: Milan Open - 09/08/2026---------------------+",
      "| Status: [Open]  Total: 12,500  Txns: 8              |",
      "|                                                      |",
      "| [Triple Tab] [DS Tab]                                |",
      "|------------------------------------------------------|",
      "| TRIPLE: [Mix] [Group] [Common] [Amount]              |",
      "| or DS:    [Single] [Double] [Amount]                 |",
      "|                                                      |",
      "| (Mode-specific input area - see below)               |",
      "|                                                      |",
      "| [Submit] [Reset]                                     |",
      "|------------------------------------------------------|",
      "| Existing Entries:                                    |",
      "| Type | Vendor | Details | Amount | Actions           |",
      "| mix  | Khatri1| 5 items | 2,500  | [Del] [Chart]    |",
      "| group| Khatri2| SP:3    | 1,800  | [Del] [Chart]    |",
      "| single| Khatri1| 3 items| 600    | [Del]            |",
      "+------------------------------------------------------+",
    ]),
    empty(),

    h3("5.4.2 Triple Section - Mix Mode"),
    ...wireframe([
      "+--Mix Mode------------------------------------------+",
      "| Vendor:     [___Select Khatri___]  (dropdown)        |",
      "| Rate:       [______]  (default rate)                 |",
      "| Paste Content:                                      |",
      "| +------------------------------------------------+ |",
      "| | 370=30" + "\u20B9" + "                                        | |",
      "| | 270=20" + "\u20B9" + "                                        | |",
      "| | 124*500" + "\u20B9" + "                                       | |",
      "| | 130*100" + "\u20B9" + "                                       | |",
      "| +------------------------------------------------+ |",
      "| (Parsed preview with green valid / red invalid)      |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    pBold("Input Samples - Mix Mode:"),
    p("The Mix mode accepts free-form WhatsApp-formatted content pasted into the textarea. The v5 parser processes this content through a 5-stage pipeline that handles 19 grammar patterns. The parser supports multiple separator types (dot, slash, comma, hyphen, colon, star, plus, underscore, equals), carry-forward multi-line entries, and automatic duplicate aggregation."),
    pMono("Type 1:  489.50" + "\u20B9" + "                  (single panna + amount)"),
    pMono("Type 2:  366/690/456...50" + "\u20B9" + "        (N pannas + amount)"),
    pMono("Type 3:  347,356,590,267.....200" + "\u20B9" + " (comma group + dots)"),
    pMono("Type 4:  123.135.158...150rs     (dot group)"),
    pMono("Type 5:  145-127-230-129..25" + "\u20B9" + "  (hyphen group)"),
    pMono("Type 6:  128:560:129:679...700" + "\u20B9" + " (colon group)"),
    pMono("Type 7:  119 110 112 113...350" + "\u20B9" + " (space group)"),
    pMono("Type 8:  matrix lines + +150" + "\u20B9" + "     (carry-forward)"),
    pMono("Type 9:  680=200" + "\u20B9" + "               (assignment)"),
    pMono("Type 10: 178*200" + "\u20B9" + "               (star separator)"),
    pMono("Type 12: 488,448,247,389..50" + "\u20B9" + "  (pending pannas)"),
    pMono("Type 14: 159,357___370" + "\u20B9" + "       (underscore)"),
    pMono("Type 17: 566 166 660 150" + "\u20B9" + "     (last=amount)"),
    pMono("Type 18: 389=260" + "\u20B9" + " + 389=30" + "\u20B9" + " -> 389=290" + "\u20B9" + " (aggregate)"),
    pMono("Type 19: 000=25" + "\u20B9" + "              (preserve 000)"),

    empty(),
    h3("5.4.3 Triple Section - Group Mode"),
    ...wireframe([
      "+--Group Mode----------------------------------------+",
      "| Vendor:  [___Select Khatri___]  (dropdown)           |",
      "| Group:   [___Select___]  (dropdown)                   |",
      "|          Options: SP, DP, TP, SPDP, SPTP, DPTP,     |",
      "|           SPDPTP, Motor Pana, 50/60/70/90 ABR,      |",
      "|           Family Chart                               |",
      "| Rate:    [______]  (default for seeds w/o rate)      |",
      "| Amount:  [______]  (override total)                   |",
      "| Paste Content:                                      |",
      "| +------------------------------------------------+ |",
      "| | Spdpmo                                          | |",
      "| | 12489=50" + "\u20B9" + "                                     | |",
      "| | 14679=30" + "\u20B9" + "                                     | |",
      "| +------------------------------------------------+ |",
      "| Preview: [12 valid] [0 skipped] [0 rejected]         |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    pBold("Group Type Options & Expansion Logic:"),
    makeTable(
      ["Group Type", "Seed Format", "Expansion", "Pannas per Ank"],
      [
        ["SP", "Ank digit (e.g., 5)", "Generates 12 SP pannas for that ank", "12"],
        ["DP", "Ank digit (e.g., 5)", "Generates 9 DP pannas for that ank", "9"],
        ["TP", "Ank digit (e.g., 5)", "Generates 1 TP panna for that ank", "1"],
        ["SPDP", "Ank digit", "SP + DP = 21 pannas", "21"],
        ["SPTP", "Ank digit", "SP + TP = 13 pannas", "13"],
        ["DPTP", "Ank digit", "DP + TP = 10 pannas", "10"],
        ["SPDPTP", "Ank digit", "SP + DP + TP = 22 pannas", "22"],
        ["Motor Pana", "Digit set (e.g., 12489)", "C(n,3) SP combinations from digits", "Varies"],
        ["50 Chart", "Ank digit", "First 5 SP pannas per ank from CHART_50", "5"],
        ["60 Chart", "Ank digit", "First 6 SP pannas per ank from CHART_60", "6"],
        ["70 Chart", "Ank digit", "First 7 SP pannas per ank from CHART_70", "7"],
        ["90 ABR Chart", "Ank digit", "First 9 SP pannas per ank from ABR9_PANNAS", "9"],
        ["Family Chart", "Any panna", "All pannas sharing the same digit set", "Varies"],
      ],
      [15, 22, 45, 18]
    ),
    empty(),
    pBold("Input Samples - Group Mode:"),
    p("The Group mode uses a textarea for multiline input. Each line can contain a seed (digits) with an optional rate. The parser strips type prefixes (Spdpmo, Spmo, Motor Pana, etc.) from the first line and processes each subsequent line as a seed entry. The group expander then generates the full set of pannas based on the selected group type."),
    pMono("Sample 1 - Motor with combined prefix (SP+DP+Motor):"),
    pMono("  Spdpmo"),
    pMono("  12489=50" + "\u20B9"),
    pMono("  14679=30" + "\u20B9"),
    pMono("  Total 1500"),
    pMono("  => Strips 'Spdpmo', expands 12489 and 14679 via Motor expander"),
    pMono(""),
    pMono("Sample 2 - SP+Motor combined prefix:"),
    pMono("  Spmo"),
    pMono("  12467890=50" + "\u20B9"),
    pMono("  T---1750"),
    pMono("  => Strips 'Spmo', expands 12467890 via Motor expander"),
    pMono(""),
    pMono("Sample 3 - SP Group:"),
    pMono("  5=50" + "\u20B9"),
    pMono("  3=30" + "\u20B9"),
    pMono("  => Expands ank 5 as 12 SP pannas, ank 3 as 12 SP pannas"),
    pMono(""),
    pMono("Sample 4 - Motor Pana with explicit prefix:"),
    pMono("  Motor Pana"),
    pMono("  12489=50" + "\u20B9"),
    pMono("  => Strips 'Motor Pana', expands 12489 via C(5,3)=10 SP combos"),

    empty(),
    h3("5.4.4 Triple Section - Common Mode"),
    ...wireframe([
      "+--Common Mode---------------------------------------+",
      "| Vendor:  [___Select Khatri___]  (dropdown)           |",
      "| Series:  [________________]  (2-digit series nums)   |",
      "|          placeholder: Enter 00,10,11,12,13,14,15    |",
      "| Rate:    [______]                                     |",
      "| Amount:  [______]                                     |",
      "| [Submit]                                              |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("Common mode generates pannas from 2-digit series numbers. Each series (00-99) produces exactly 10 pannas that share that series as a prefix. For example, series '12' generates pannas 120, 123, 124, 125, 126, 127, 128, 129, 121, 122. Multiple series can be entered comma-separated, and each generates its own set of 10 pannas."),
    pBold("Input Sample - Common Mode:"),
    pMono("Series: 00,10,11,12,13"),
    pMono("Rate: 50"),
    pMono("=> Generates 50 pannas (5 series x 10 each)"),

    empty(),
    h3("5.4.5 Triple Section - Amount Mode"),
    ...wireframe([
      "+--Amount Mode---------------------------------------+",
      "| Vendor:  [___Select Khatri___]  (dropdown)           |",
      "| Amount:  [______]                                     |",
      "| [Submit]                                              |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("Amount mode is the simplest triple entry. It records a raw monetary amount without any panna associations. This is used for recording fixed entries, adjustments, or vendor advances that are not tied to specific panna bets."),

    empty(),
    h3("5.4.6 DS Tab - Single Mode"),
    ...wireframe([
      "+--Single Mode---------------------------------------+",
      "| Vendor:  [___Select Khatri___]  (dropdown)           |",
      "| Rate:    [______]  (Single then 0)                   |",
      "| Amount:  [______]  (auto-calculated)                 |",
      "| Paste Content:                                      |",
      "| +------------------------------------------------+ |",
      "| | 5=50" + "\u20B9" + "                                          | |",
      "| | 3=30" + "\u20B9" + "                                          | |",
      "| | 7=20" + "\u20B9" + "                                          | |",
      "| | Or just digits: 13469                           | |",
      "| +------------------------------------------------+ |",
      "| [Submit] [Reset]                                     |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    pBold("Input Samples - Single Mode:"),
    pMono("WhatsApp format: 5=50" + "\u20B9" + ", 3=30" + "\u20B9" + ", 7=20" + "\u20B9"),
    pMono("Raw digits: 13469 (each digit becomes a single entry with default rate)"),
    pMono("Combined prefix: Sp 5=50" + "\u20B9" + " (prefix stripped, evaluated as single)"),
    p("The parser validates that each entry is exactly 1 digit (0-9). Entries with more digits are dropped and recorded as parser exceptions."),

    empty(),
    h3("5.4.7 DS Tab - Double Mode"),
    ...wireframe([
      "+--Double Mode---------------------------------------+",
      "| Vendor:  [___Select Khatri___]  (dropdown)           |",
      "| Series:  [______]  (optional vendor name)            |",
      "| Select (Double):                                    |",
      "| +------------------------------------------------+ |",
      "| | Milan                                            | |",
      "| | 23.42.72.82.92.02.                              | |",
      "| | 22.43.73.83.93.03.                              | |",
      "| | 24.44.74.84.94.04.                              | |",
      "| | .....=500rs                                     | |",
      "| +------------------------------------------------+ |",
      "| Rate:    [______]  (auto-filled from content)        |",
      "| Amount:  [______]  (auto-calculated)                 |",
      "| [Submit] [Reset]                                     |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    pBold("Input Samples - Double Mode:"),
    pMono("Milan dot format (primary parser):"),
    pMono("  Milan"),
    pMono("  23.42.72.82.92.02."),
    pMono("  22.43.73.83.93.03."),
    pMono("  24.44.74.84.94.04."),
    pMono("  .....=500rs"),
    pMono("WhatsApp format (fallback): 23=50" + "\u20B9" + ", 42=30" + "\u20B9"),
    pMono("Space/comma format (2nd fallback): 23 42 72 82"),
    p("The double parser has a three-tier strategy: first it tries the Milan dot format (specific to certain Khatris), then falls back to WhatsApp format parsing, then to raw space/comma splitting. Each entry must be exactly 2 digits (00-99)."),

    empty(),
    h3("5.4.8 220 Chart & Sharing"),
    p("Every card entry has an associated 220 Panna Chart that displays the current bet amounts for each of the 220 pannas organized in the 22x10 grid. The chart is rendered on an HTML Canvas element using Liberation Serif and DejaVu fonts for consistent rendering. It supports several operations: download as PNG image, share via Web Share API (with clipboard and download fallbacks), and share specifically to WhatsApp with formatted text output."),
    p("The master admin can apply percentage adjustments to the chart: a 'less' percentage reduces all rates, and an 'add' percentage increases them. These are stored as chartLessPct and chartAddPct state variables and applied during canvas rendering as chartAppliedPct. Additionally, the master admin can set per-column deductions (chartColDeduction) which deduct a fixed amount from each column's total. These adjustments are tracked in the ChartRevision audit table."),
  ];
}

function section6_UserAppFlow() {
  return [
    h1("6. User Android App - Complete Flow"),
    p("The mobile interface uses Material Design patterns optimized for Android devices. It features a bottom navigation bar with 5 tabs, a top app bar with context-specific titles, floating action buttons (FAB) for primary actions, and card-based layouts throughout. The mobile experience is specifically designed for touch interaction with larger tap targets, simplified forms, and optimized data loading using useDeferredValue and deferred fetch patterns."),
    h2("6.1 Mobile Navigation"),
    p("The mobile bottom navigation provides 5 tabs that cover the essential user workflow. Unlike the desktop sidebar which shows all admin pages, the mobile interface focuses on the core Card and Hisab operations that users perform daily. System management functions are accessible through the Profile tab's menu."),
    makeTable(
      ["Tab", "Icon", "MobileTab Key", "Primary Action", "FAB Action"],
      [
        ["Home", "home", "home", "Dashboard overview", "None"],
        ["Inventory", "inventory_2", "inventory", "Card list", "New Card"],
        ["Settlement", "account_balance_wallet", "settlement", "Hisab records", "New Hisab"],
        ["Vendors", "people", "vendors", "Khatri list", "None"],
        ["Profile", "person", "profile", "User profile + system menu", "None"],
      ],
      [12, 18, 15, 25, 30]
    ),
    empty(),
    h2("6.2 Mobile Pages Wireframes"),

    h3("6.2.1 Mobile Login"),
    ...wireframe([
      "+--Login (Material Design)---------------------------+",
      "|                                                      |",
      "|     [Matka Card ERP Logo]                            |",
      "|                                                      |",
      "|  Username: [________________]                        |",
      "|  Password: [________________]                        |",
      "|                                                      |",
      "|  [         Login         ]                           |",
      "|                                                      |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("The MobileLoginPage uses Material Design styled input fields with outline variants and a prominent login button. On successful POST /api/auth, the user object is stored in localStorage and the page navigates to the home tab. Invalid credentials show a snackbar error message. Locked users receive a specific error message indicating their account is locked."),

    h3("6.2.2 Mobile Dashboard"),
    ...wireframe([
      "+--Dashboard-----------------------------------------+",
      "| [Total Cards]  [Hisab Done]                          |",
      "| [Win Paid]     [Khatris]                             |",
      "|                                                      |",
      "| Recent:                                              |",
      "| +--Card--Milan--Open--12500--+                       |",
      "| | 09/08/2026    [View]       |                       |",
      "| +----------------------------+                       |",
      "+------------------------------------------------------+",
      "| [Home] [Inventory] [Settlement] [Vendors] [Profile]  |",
    ]),
    empty(),
    p("The MobileDashboardPage renders 4 stat cards in a 2x2 grid using Material Design card components. Recent card entries appear as scrollable cards below. The bottom navigation persists at the bottom with the Home tab highlighted."),

    h3("6.2.3 Mobile New Card"),
    ...wireframe([
      "+--New Card------------------------------------------+",
      "| Card Date:  [____________]  (calendar icon)          |",
      "| Card Code:  [____v______]  (qr_code icon)           |",
      "| Remark:     [____________]  (edit_note icon)         |",
      "|                                                      |",
      "| [  + Create Card  ]  (full-width button)            |",
      "+------------------------------------------------------+",
      "|                      [+] FAB                         |",
    ]),
    empty(),
    pBold("Input Sample:"),
    pMono("Date: 09/08/2026 (today, with calendar picker)"),
    pMono("Card Code: Milan Open (dropdown from /api/inventory-codes)"),
    pMono("Remark: Optional text"),

    h3("6.2.4 Mobile Card List"),
    ...wireframe([
      "+--Card Lists----------------------------------------+",
      "| [Search...]                                         |",
      "|                                                      |",
      "| +--Milan Open--09/08/2026----12500--+                |",
      "| | Status: Open    [Open Card >]     |                |",
      "| +-----------------------------------+                |",
      "| +--Kalyan Close--08/08/2026--8900---+                |",
      "| | Status: Settled [Open Card >]     |                |",
      "| +-----------------------------------+                |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("The MobileCardListPage shows cards as Material Design list items with market color chips, date, total amount, and status badges. Tapping a card opens the full CardInventoryPage (same as desktop but touch-optimized) where the user can enter panna data."),

    h3("6.2.5 Mobile New Hisab"),
    ...wireframe([
      "+--New Hisab-----------------------------------------+",
      "| Date:      [____________]                            |",
      "| Vendor:    [____v______]  (Khatri dropdown)          |",
      "| Card Code: [____v______]  (market session)           |",
      "| Amount:    [____________]                             |",
      "| Commission:[____________]                             |",
      "| Winning:   [____________]                             |",
      "|                                                      |",
      "| [  + Create Hisab  ]                                 |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    pBold("Input Sample:"),
    pMono("Date: 09/08/2026, Vendor: Khatri Ramesh, Code: Milan Open"),
    pMono("Amount: 25000, Commission Rate: 5%, Winning: 18000"),

    h3("6.2.6 Mobile Profile & System Menu"),
    ...wireframe([
      "+--Profile-------------------------------------------+",
      "| User: operator1                                     |",
      "| Role: User                                          |",
      "| Markets: Milan, Kalyan                              |",
      "|                                                      |",
      "| System Management:                                   |",
      "| > Users                                              |",
      "| > Market Permissions                                 |",
      "| > User Activity                                      |",
      "| > Locked Users                                       |",
      "| > Parser Exceptions                                  |",
      "|                                                      |",
      "| [Logout]                                             |",
      "+------------------------------------------------------+",
    ]),
    empty(),
    p("The MobileProfilePage displays the current user's information and assigned markets. For users with the 'master' role, a System Management section expands to show admin pages. These open as overlay pages within the mobile interface, maintaining the Material Design aesthetic. The logout button calls POST /api/auth/logout and clears the localStorage session."),

    h2("6.3 Mobile vs Desktop Feature Parity"),
    makeTable(
      ["Feature", "Desktop", "Mobile", "Notes"],
      [
        ["Dashboard", "Full stats + table", "2x2 stat cards + recent list", "Mobile simplifies layout"],
        ["New Card", "Full form", "Full form (Material Design)", "Same fields, different styling"],
        ["Card Entry (Mix/Group/Single/Double)", "Full CardInventoryPage", "Same page, touch-optimized", "Shared component"],
        ["220 Chart", "Canvas + download/share", "Canvas + download/share", "Same rendering engine"],
        ["New Hisab", "Full form", "Full form (Material Design)", "Same fields"],
        ["Khatri CRUD", "Full CRUD table", "Card-based list + forms", "Simplified mobile view"],
        ["System Management", "Sidebar navigation", "Profile > System menu", "Same pages, overlay style"],
        ["Subscription/Paywall", "Full plans grid", "Mobile paywall page", "MobilePaywallPage"],
      ],
      [20, 25, 25, 30]
    ),
  ];
}

function section7_ParserSystem() {
  return [
    h1("7. Parser System - Complete Technical Reference"),
    p("The WhatsApp Parser v5 is a critical subsystem that transforms raw WhatsApp-formatted text into structured panna+rate entries. It handles 19 grammar patterns across 5 processing stages, with safety caps to prevent runaway processing. This section provides the complete technical reference for understanding how input is evaluated for each game type."),
    h2("7.1 Parser Architecture"),
    p("The parser operates in two modes: a fast path for simple NNN=RATE patterns (covering 90%+ of real-world input) and a slow path with the full 5-stage pipeline for complex multi-line input. Both paths respect the same validation rules and mode-specific constraints."),
    makeTable(
      ["Stage", "Purpose", "Key Operations"],
      [
        ["1", "Strip WhatsApp metadata", "Remove timestamps, phone numbers, message headers (WA_HEADER_RE)"],
        ["2", "Remove noise words", "Strip: Mob, MB, DMO, DMB, Mo.ko, Mb.kb, Mop, SR, Ko, Total, separators"],
        ["3", "Normalize separators", "Convert . , .. = + - * : / _ to single split point (SPLIT_RE)"],
        ["4", "Extract pannas + rate", "Parse each line: find rate suffix (RATE_SUFFIX_RE), split on separators, collect digit tokens"],
        ["5", "Aggregate duplicates", "Type 18: merge entries with same panna, sum rates (never overwrite)"],
      ],
      [8, 25, 67]
    ),
    empty(),
    h2("7.2 Type Prefix Handling"),
    p("Combined game type prefixes are stripped from input before parsing. The TYPE_PREFIX_RE regex matches these prefixes in longest-first order to prevent partial matches (e.g., Spdpmo before Spmo before Sp)."),
    pBold("Regex Pattern:"),
    pMono("/^(?:Spdpmo|Spmo|Spdp|Sptp|Dptp|Spdptp|Motor\\s*(?:Pana)?|Sp|Dp|Tp)\\s+/i"),
    empty(),
    makeTable(
      ["Prefix", "Game Types", "Example Input", "After Stripping"],
      [
        ["Spdpmo", "SP + DP + Motor", "Spdpmo 12489=50" + "\u20B9", "12489=50" + "\u20B9"],
        ["Spmo", "SP + Motor", "Spmo 5=30" + "\u20B9", "5=30" + "\u20B9"],
        ["Spdp", "SP + DP", "Spdp 12489=50" + "\u20B9", "12489=50" + "\u20B9"],
        ["Sptp", "SP + TP", "Sptp 5=30" + "\u20B9", "5=30" + "\u20B9"],
        ["Dptp", "DP + TP", "Dptp 5=30" + "\u20B9", "5=30" + "\u20B9"],
        ["Spdptp", "SP + DP + TP", "Spdptp 5=30" + "\u20B9", "5=30" + "\u20B9"],
        ["Motor Pana", "Motor (explicit)", "Motor Pana 12489=50" + "\u20B9", "12489=50" + "\u20B9"],
        ["Motor", "Motor (implicit)", "Motor 12489=50" + "\u20B9", "12489=50" + "\u20B9"],
        ["Sp", "SP", "Sp 5=50" + "\u20B9", "5=50" + "\u20B9"],
        ["Dp", "DP", "Dp 5=50" + "\u20B9", "5=50" + "\u20B9"],
        ["Tp", "TP", "Tp 5=50" + "\u20B9", "5=50" + "\u20B9"],
      ],
      [12, 18, 30, 30]
    ),
    empty(),
    h2("7.3 Evaluation by Game Type"),
    p("The parser evaluates input differently based on the mode/context in which it is called. This is the critical distinction: Mix mode accepts any 1-4 digit panna, Group mode accepts 1-10 digit seeds, Single mode accepts only 1-digit entries, and Double mode accepts only 2-digit entries. The isValidPanna() function enforces these constraints."),
    makeTable(
      ["Mode", "Valid Digit Length", "Parser Call", "Post-Processing"],
      [
        ["mix", "1-4 digits", "parseWhatsAppContentFull(content, 'mix', rate)", "normalizePanna() for 3-digit, build grid"],
        ["group", "1-10 digits (seeds)", "parseWhatsAppContentFull(content, 'group', rate)", "Expand seeds via group expander, merge duplicates"],
        ["common", "2 digits (series)", "generateCommonPannas(series)", "Each series -> 10 pannas"],
        ["single", "1 digit only (0-9)", "parseWhatsAppContent(content, 'single', rate)", "Filter ^\\d$, fallback raw digit parsing"],
        ["double", "2 digits only (00-99)", "parseWhatsAppContent(content, 'double', rate)", "Try Milan dot format first, then WA, then raw"],
        ["amount", "No digits", "Direct amount entry", "No parsing required"],
      ],
      [10, 20, 35, 35]
    ),
    empty(),
    h2("7.4 Safety Caps"),
    makeTable(
      ["Parameter", "Value", "Purpose"],
      [
        ["PARSER_TIME_BUDGET_MS", "3000 (3 seconds)", "Prevents runaway parsing on pathological input"],
        ["MAX_PARSER_ENTRIES", "2000", "Maximum parsed entries per input"],
        ["MAX_PARSER_LINES", "3000", "Maximum lines processed per input"],
        ["MAX_LINE_LENGTH", "500", "Lines exceeding this are skipped"],
        ["PARSER_BUDGET_CHECK_INTERVAL", "50 lines", "Check time budget every 50 lines"],
        ["MAX_SKIPPED_NUMBERS", "100", "Maximum skipped entries reported"],
        ["MAX_DROPPED_TOKENS", "100", "Maximum dropped tokens reported"],
      ],
      [30, 25, 45]
    ),
    empty(),
    h2("7.5 Complete Input Sample Catalog"),
    p("This section provides the complete catalog of all input formats accepted by the system, organized by section and mode. These samples represent real-world WhatsApp messages that Khatris send to the system."),
    h3("7.5.1 Mix Mode Input (Triple - Mix)"),
    pMono("Simple panna+rate:"),
    pMono("  370=30" + "\u20B9"),
    pMono("  270=20" + "\u20B9"),
    pMono("  124*500" + "\u20B9"),
    pMono("  130*100" + "\u20B9"),
    pMono(""),
    pMono("Multi-panna per line:"),
    pMono("  347,356,590,267.....200" + "\u20B9"),
    pMono("  123.135.158...150rs"),
    pMono("  145-127-230-129..25" + "\u20B9"),
    pMono("  128:560:129:679...700" + "\u20B9"),
    pMono(""),
    pMono("WhatsApp metadata (auto-stripped):"),
    pMono("  [8/9/26, 10:30:45 AM] Ramesh: 489.50" + "\u20B9"),
    pMono("  => Parser strips [timestamp] name:, leaves 489.50" + "\u20B9"),

    h3("7.5.2 Group Mode Input (Triple - Group)"),
    pMono("Motor with SP+DP+Motor combined prefix:"),
    pMono("  Spdpmo"),
    pMono("  12489=50" + "\u20B9"),
    pMono("  14679=30" + "\u20B9"),
    pMono("  Total 1500"),
    pMono(""),
    pMono("SP+Motor combined prefix:"),
    pMono("  Spmo"),
    pMono("  12467890=50" + "\u20B9"),
    pMono("  T---1750"),
    pMono(""),
    pMono("Motor Pana explicit:"),
    pMono("  Motor Pana"),
    pMono("  12489=50" + "\u20B9"),
    pMono("  14679=30" + "\u20B9"),
    pMono(""),
    pMono("SP Group (ank digits with rates):"),
    pMono("  5=50" + "\u20B9"),
    pMono("  3=30" + "\u20B9"),
    pMono("  128=20" + "\u20B9"),
    pMono(""),
    pMono("DP Group:"),
    pMono("  5=50" + "\u20B9"),
    pMono("  7=30" + "\u20B9"),
    pMono(""),
    pMono("Family Chart:"),
    pMono("  128=50" + "\u20B9"),
    pMono("  => Expands to all pannas with digits {1,2,8}: 128,138,182,etc."),

    h3("7.5.3 Single Mode Input (DS - Single)"),
    pMono("WhatsApp formatted:"),
    pMono("  5=50" + "\u20B9"),
    pMono("  3=30" + "\u20B9"),
    pMono("  7=20" + "\u20B9"),
    pMono(""),
    pMono("Raw digits (each gets default rate):"),
    pMono("  13469"),
    pMono(""),
    pMono("With SP prefix:"),
    pMono("  Sp"),
    pMono("  5=50" + "\u20B9"),
    pMono("  3=30" + "\u20B9"),

    h3("7.5.4 Double Mode Input (DS - Double)"),
    pMono("Milan dot format (primary):"),
    pMono("  Milan"),
    pMono("  23.42.72.82.92.02."),
    pMono("  22.43.73.83.93.03."),
    pMono("  24.44.74.84.94.04."),
    pMono("  .....=500rs"),
    pMono(""),
    pMono("WhatsApp formatted (fallback):"),
    pMono("  23=50" + "\u20B9"),
    pMono("  42=30" + "\u20B9"),
    pMono("  72=20" + "\u20B9"),
    pMono(""),
    pMono("Space separated (2nd fallback):"),
    pMono("  23 42 72 82 92 02"),
  ];
}

function section8_PageCorrelation() {
  return [
    h1("8. Page Correlation & Internal Linking"),
    p("This section maps every internal navigation path and page-to-page link in the system. Understanding these correlations is essential for tracing user workflows and debugging flow issues. The Zustand store manages all navigation through the currentPage state variable, and no Next.js file-based routing is used (except for the public landing page)."),
    h2("8.1 Navigation State Flow"),
    p("All navigation is managed through the Zustand store's setCurrentPage() function. When a user clicks a sidebar item, bottom tab, or action button, the currentPage state is updated, which triggers a React re-render displaying the target component. Some pages require additional state (like viewingInventoryId for the card view), which is set simultaneously."),
    makeTable(
      ["From Page", "Trigger", "Target Page", "State Set"],
      [
        ["Login", "Successful auth", "Dashboard", "isLoggedIn=true, currentUser=user"],
        ["Dashboard", "Click 'New Card'", "New Card (inv-new)", "currentPage='inv-new'"],
        ["Dashboard", "Click 'New Hisab'", "New Hisab (sett-new)", "currentPage='sett-new'"],
        ["Dashboard", "Click 'View Cards'", "Card Lists (inv-list)", "currentPage='inv-list'"],
        ["Dashboard", "Click 'View Hisab'", "Hisab Records (sett-list)", "currentPage='sett-list'"],
        ["New Card", "Submit form", "Card View (card-view)", "viewingInventoryId=id"],
        ["Card Lists", "Click card row", "Card View (card-view)", "viewingInventoryId=id"],
        ["Card View", "Click chart btn", "Chart Modal (overlay)", "showChart=true"],
        ["New Hisab", "Submit form", "Hisab Records (sett-list)", "currentPage='sett-list'"],
        ["Khatri Hisab", "Click vendor", "Settlement detail", "vendorId=id"],
        ["Sidebar/Bottom", "Click nav item", "Target page", "currentPage=target"],
        ["Profile (Mobile)", "System menu item", "Admin page", "currentPage=target"],
      ],
      [15, 20, 25, 40]
    ),
    empty(),
    h2("8.2 Data Dependencies Between Pages"),
    p("Several pages have data dependencies where the content of one page affects another. These dependencies are managed through shared API calls and Zustand state. When data is mutated on one page, dependent pages must refresh their data."),
    makeTable(
      ["Source Page", "Mutation", "Dependent Pages", "Refresh Strategy"],
      [
        ["Card View", "Create triple/ds entry", "Dashboard (stats), Card View (totals)", "Deferred 150ms fetch after submit"],
        ["Card View", "Delete triple/ds entry", "Card View (totals)", "Immediate fetch + recalc"],
        ["New Hisab", "Create settlement", "Dashboard (stats), Hisab Records", "Navigate to list after submit"],
        ["Khatri", "Create/update vendor", "Card View (vendor dropdown), New Hisab", "Vendor list re-fetched on mount"],
        ["Settings", "Add inventory code", "New Card (code dropdown)", "Code list re-fetched on mount"],
        ["Users", "Create/lock user", "Locked Users, User Activity", "Navigate or manual refresh"],
        ["Market Permissions", "Update markets", "All pages (market filter)", "User must re-login for effect"],
      ],
      [15, 22, 30, 33]
    ),
    empty(),
    h2("8.3 Complete Page Inventory"),
    makeTable(
      ["Page Key", "Component", "Role Access", "Data Sources (API)", "Side Effects"],
      [
        ["dashboard", "DashboardPage", "All", "GET /dashboard, GET /inventories", "None (read-only)"],
        ["inv-new", "NewInventoryPage", "All", "GET /inventory-codes", "POST /inventories"],
        ["inv-list", "InventoryListPage", "All", "GET /inventories (paginated)", "None (read-only)"],
        ["card-view", "CardInventoryPage", "All", "GET /triple, /ds, /vendors, /inventory-codes", "POST /triple, /ds; DELETE /triple/[id], /ds/[id]"],
        ["sett-new", "NewSettlementPage", "All", "GET /vendors, /inventory-codes", "POST /settlements"],
        ["sett-list", "SettlementListPage", "All", "GET /settlements (paginated)", "None (read-only)"],
        ["vendor-sett", "VendorSettlementPage", "All", "GET /settlements, /vendors", "None (read-only)"],
        ["vendor", "VendorPage", "Master", "GET /vendors", "POST/PUT/DELETE /vendors"],
        ["configure", "ConfigurePage", "Master", "GET /inventory-codes", "POST/PUT/DELETE /inventory-codes"],
        ["users", "UsersPage", "Master", "GET /users", "POST/PUT/DELETE /users"],
        ["sys-mgmt-markets", "MarketPermissionsPage", "Master", "GET /users", "PUT /users/[id]/markets"],
        ["sys-mgmt-activity", "UserActivityPage", "Master", "GET /user-activity", "None (read-only)"],
        ["sys-mgmt-locked", "LockedUsersPage", "Master", "GET /users (locked)", "PUT /users/[id]/lock"],
        ["sys-mgmt-parser-ex", "ParserExceptionsPage", "Master", "GET /parser-exceptions", "PATCH /parser-exceptions/[id]"],
        ["sys-mgmt-parser-cfg", "ParserConfigPage", "Master", "GET /parser-config", "None (read-only)"],
        ["sys-mgmt-chart-revs", "ChartRevisionsPage", "Master", "GET /chart-revisions", "None (read-only)"],
        ["sub-plans", "SubscriptionPlansPage", "Master", "GET /subscription-plans", "POST/PUT/DELETE /subscription-plans"],
        ["sub-users", "UserSubscriptionsPage", "Master", "GET /user-subscriptions", "PUT /user-subscriptions/[id]"],
        ["sub-payments", "PaymentsPage", "Master", "GET /payments", "POST/PUT /payments"],
        ["landing-config", "LandingConfigPage", "Master", "GET /landing-config", "POST /landing-config"],
        ["paywall", "PaywallPage", "User (non-subscribed)", "GET /subscription-plans", "POST /user-subscriptions"],
      ],
      [15, 20, 12, 30, 23]
    ),
  ];
}

function section9_ModuleWorkingBriefs() {
  return [
    h1("9. Module Working Briefs"),
    p("This section describes how each module works when a user is actively using it. Each brief covers the user interaction flow, the data processing pipeline, the API calls made, and the state changes that occur. These briefs are organized by functional area rather than by page, as some modules span multiple pages."),
    h2("9.1 Card Management Module"),
    h3("9.1.1 Card Creation Flow"),
    p("Step 1: User navigates to New Card page. The system fetches all InventoryCodes from GET /api/inventory-codes and populates the Card Code dropdown. Step 2: User selects a date (defaults to today), chooses a Card Code from the dropdown (e.g., 'Milan Open'), and optionally enters a remark. Step 3: User clicks 'Create Card'. The system POSTs to /api/inventories with {date, time (auto), inventoryCodeId, remark, createdBy}. Step 4: The API checks for duplicate cards (same date + inventoryCodeId) and returns the new inventory ID. Step 5: The system sets viewingInventoryId to the new ID and navigates to card-view, where data entry begins."),
    h3("9.1.2 Data Entry Flow (Mix Mode)"),
    p("Step 1: User selects the Triple tab and Mix sub-mode. Step 2: User selects a Vendor (Khatri) from the dropdown. Step 3: User sets a default Rate (used when entries lack explicit rates). Step 4: User pastes WhatsApp-formatted content into the textarea. Step 5: The parser processes the content in real-time, showing a preview of valid entries (green) and invalid entries (red). Step 6: User clicks Submit. Step 7: The handleSubmitTriple function calls parseWhatsAppContentFull() which returns {entries, skippedNumbers, droppedTokens}. Step 8: Entries are built into a 10-column grid using buildGridFromParsed(). Step 9: The system POSTs to /api/triple-inventories with {inventoryId, vendorId, type:'mix', details, parsedData:{entries,grid,totals,skipped,dropped}}. Step 10: Parser exceptions are recorded via POST /api/parser-exceptions. Step 11: The parent Inventory totalAmount is recalculated. Step 12: Form resets, lists are deferred-refreshed after 150ms."),
    h3("9.1.3 Data Entry Flow (Group Mode)"),
    p("Step 1: User selects the Triple tab and Group sub-mode. Step 2: User selects a Vendor and a Group Type from the dropdown. Step 3: User pastes seed content (with optional type prefix like Spdpmo). Step 4: The parser strips the type prefix and extracts seed+rate pairs. Step 5: Each seed is expanded by the group expander (e.g., Motor expands digit set into C(n,3) SP combinations). Step 6: Expanded entries are merged (duplicate pannas have their rates summed). Step 7: The system POSTs to /api/triple-inventories with type:'group' and parsedData including groupType, generatedPannas, and expanded grid. Step 8: The remaining flow matches Mix mode (steps 10-12)."),
    h3("9.1.4 Data Entry Flow (Single/Double)"),
    p("Step 1: User switches to the DS tab. Step 2: For Single mode, user pastes 1-digit entries or raw digit strings. For Double mode, user pastes Milan dot format, WhatsApp format, or raw 2-digit entries. Step 3: The parser validates digit lengths (1 for single, 2 for double) and drops invalid entries. Step 4: The system POSTs to /api/double-single-inventories with the appropriate type ('single' or 'double'). Step 5: Amount is auto-calculated from entries x rate. Step 6: The remaining flow matches Mix mode."),
    h3("9.1.5 Chart Operations"),
    p("The 220 Chart is available for any card that has triple entries. Clicking the chart icon opens a modal with the Canvas-rendered chart. The master admin can apply percentage adjustments (less/add) and per-column deductions. The chart can be downloaded as PNG, shared via the Web Share API, or shared specifically to WhatsApp. All chart save/share/regenerate actions are logged to the ChartRevision audit table."),

    h2("9.2 Hisab (Settlement) Module"),
    h3("9.2.1 Settlement Creation Flow"),
    p("Step 1: User navigates to New Hisab page. Step 2: User enters date, selects Vendor (Khatri), selects Card Code (market session), and enters amount, commission rate, and winning amount. Step 3: The commission amount is auto-calculated as amount x commissionRate / 100. Step 4: User clicks Submit. Step 5: The system POSTs to /api/settlements with {date, vendorId, inventoryCodeId, amount, commissionRate, comAmount, winning, status:'pending'}. Step 6: After success, the system navigates to Hisab Records."),
    h3("9.2.2 Khatri Hisab View"),
    p("The VendorSettlementPage aggregates all settlements per vendor, showing total amounts, commissions, winnings, and net balances. This provides a per-Khatri accounting view that is essential for payment reconciliation."),

    h2("9.3 Khatri (Vendor) Management Module"),
    p("This module is accessible only to the master admin. It provides full CRUD for vendor records. Each vendor (Khatri) has a unique code, business name, mobile number, and over 20 additional business fields including advance payment tracking and opening balance. Vendors are referenced by both TripleInventory and DoubleSingleInventory entries (via vendorId) and by Settlement records. Creating or updating a vendor triggers a refresh of all vendor dropdowns across the system."),

    h2("9.4 System Management Module"),
    h3("9.4.1 User Management"),
    p("The master admin can create, update, and delete users. Each user has a username, password, and role ('master' or 'user'). User accounts can be locked/unlocked, which prevents login and is tracked with audit fields (lockedAt, lockedBy, lockReason). All user mutations are logged to UserActivity."),
    h3("9.4.2 Market Permissions"),
    p("Each user can be assigned specific markets via the assignedMarkets CSV field. This controls which market data the user can access across all pages. The marketFilter() Prisma helper automatically injects {market: {in: [...]}} into all queries for non-master users. Changes require re-login to take effect."),
    h3("9.4.3 Parser Exception Management"),
    p("Parser exceptions represent entries that were skipped or dropped during parsing. The master admin can view all exceptions, filter by status (open/resolved/ignored), and resolve or ignore individual exceptions. Resolving an exception does not retroactively add the entry; it simply marks it as acknowledged."),
    h3("9.4.4 Audit Trail (User Activity)"),
    p("Every significant action is logged to the UserActivity table with userId, action type, entity, entityId, market, and metadata (JSON). Actions include login, logout, create, update, delete, lock, unlock, chart_save, chart_regenerate, parser_resolve, and access denials. This provides a complete audit trail for compliance and debugging."),

    h2("9.5 Subscription & Billing Module"),
    p("The subscription module provides SaaS-style access control. Non-master users must have an active subscription to access the system. On first login, a 7-day trial is automatically applied. The master admin can create subscription plans (name, duration, price, features JSON), assign subscriptions to users (activate, extend, cancel), and manage payment records (amount, method, status, receipt number). The paywall page shows available plans and handles the subscription purchase flow."),
  ];
}

function section10_AuditSystem() {
  return [
    h1("10. Audit & Compliance System"),
    p("The Matka Card ERP implements a comprehensive audit trail that tracks every significant user action. This is critical for a financial system where accuracy and accountability are paramount. The audit system operates silently in the background and never throws errors that could disrupt user workflows."),
    h2("10.1 Audit Event Types"),
    makeTable(
      ["Action", "Trigger", "Entity", "Metadata Captured"],
      [
        ["login", "Successful authentication", "User", "IP, timestamp, markets"],
        ["logout", "User logout", "User", "Timestamp"],
        ["login_blocked_locked", "Locked user attempts login", "User", "lockReason, lockedBy"],
        ["create", "POST to any CRUD endpoint", "Inventory/Settlement/Vendor", "Full request body"],
        ["update", "PUT to any CRUD endpoint", "Any entity", "Before/after diff"],
        ["delete", "DELETE to any CRUD endpoint", "Any entity", "Deleted record details"],
        ["lock", "User account locked", "User", "lockReason"],
        ["unlock", "User account unlocked", "User", "Unlock timestamp"],
        ["chart_save", "Chart saved/downloaded", "Inventory", "Chart adjustments, panna count"],
        ["chart_regenerate", "Chart regenerated", "Inventory", "Revision diff"],
        ["parse", "Parser processes input", "TripleInventory/DS", "Entry count, skipped, dropped"],
        ["parser_resolve", "Exception resolved", "ParserException", "Resolution note"],
        ["create_denied", "Create attempt without permission", "Any entity", "Permission check result"],
      ],
      [18, 25, 20, 37]
    ),
    empty(),
    h2("10.2 Chart Revision Tracking"),
    p("Every time a chart is saved, shared, or regenerated, a ChartRevision record is created. This captures the chartId, the user who made the change (editedBy), the action type ('save', 'regenerate', 'edit', 'manual_override'), and both the previous and new data as JSON. This allows the master admin to review the complete history of chart modifications and revert changes if necessary."),
    h2("10.3 Parser Exception Tracking"),
    p("When the parser encounters entries it cannot process (skipped or dropped), these are recorded as ParserException records with the original text, the market context, the reason for the exception, and the kind ('skipped' for entries with rate=0, 'dropped' for invalid tokens). The master admin can review these exceptions, investigate the cause, and mark them as resolved or ignored. This ensures no data is silently lost during parsing."),
  ];
}

// ─── ASSEMBLE DOCUMENT ───────────────────────────────────────────
const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: { ascii: "Calibri", eastAsia: "Microsoft YaHei" },
          size: 22,
          color: P.body,
        },
        paragraph: {
          spacing: { line: 312 },
        },
      },
      heading1: {
        run: { font: { ascii: "Calibri", eastAsia: "SimHei" }, size: 32, bold: true, color: P.primary },
        paragraph: { spacing: { before: 480, after: 200, line: 312 } },
      },
      heading2: {
        run: { font: { ascii: "Calibri", eastAsia: "SimHei" }, size: 28, bold: true, color: P.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 } },
      },
      heading3: {
        run: { font: { ascii: "Calibri", eastAsia: "SimHei" }, size: 24, bold: true, color: P.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 } },
      },
    },
  },
  numbering: {
    config: [
      {
        reference: "list-1",
        levels: [{
          level: 0,
          format: LevelFormat.DECIMAL,
          text: "%1.",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
    ],
  },
  sections: [
    // Cover section
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 0, bottom: 0, left: 0, right: 0 },
        },
      },
      children: buildCover(),
    },
    // TOC + Body section
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [new TextRun({ text: "Matka Card ERP \u2014 Master Documentation", size: 16, color: P.secondary, italics: true, font: { ascii: "Calibri" } })],
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: P.secondary })],
            }),
          ],
        }),
      },
      children: [
        // Table of Contents
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { after: 200 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, color: P.primary, font: { ascii: "Calibri", eastAsia: "SimHei" } })],
        }),
        new TableOfContents("Table of Contents", {
          hyperlink: true,
          headingStyleRange: "1-3",
        }),
        new Paragraph({
          spacing: { before: 100 },
          children: [new TextRun({ text: "Right-click the Table of Contents and select \u201cUpdate Field\u201d to refresh page numbers.", size: 18, color: P.secondary, italics: true })],
        }),
        new Paragraph({ children: [new PageBreak()] }),

        // All sections
        ...section1_Terminology(),
        ...section2_Markets(),
        ...section3_Architecture(),
        ...section4_DatabaseSchema(),
        ...section5_MasterAdminFlow(),
        ...section6_UserAppFlow(),
        ...section7_ParserSystem(),
        ...section8_PageCorrelation(),
        ...section9_ModuleWorkingBriefs(),
        ...section10_AuditSystem(),
      ],
    },
  ],
});

// ─── EXPORT ──────────────────────────────────────────────────────
const OUTPUT = "/home/z/my-project/download/Matka_Card_ERP_Master_Documentation.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUTPUT, buf);
  console.log("SUCCESS:", OUTPUT);
}).catch(err => {
  console.error("ERROR:", err);
  process.exit(1);
});
