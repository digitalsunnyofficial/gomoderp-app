// Task 42: reproduce issue 1 (app customers list) + issue 2 (customer signup/login) on :3000
const BASE = 'http://127.0.0.1:3000'
let suCookie = ''

async function call(method: string, path: string, body?: any, cookie?: string) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  })
  const setCookie = res.headers.get('set-cookie')
  const text = await res.text()
  let json: any = null
  try { json = JSON.parse(text) } catch {}
  return { status: res.status, json, text: text.slice(0, 500), setCookie }
}

async function main() {
  // 1. super admin login
  const adm = await call('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  console.log('ERP login:', adm.status, JSON.stringify(adm.json).slice(0, 120))
  suCookie = (adm.setCookie || '').split(';')[0]

  // 2. app customers list (issue 1)
  const cust = await call('GET', '/api/app-admin/customers?tab=app', undefined, suCookie)
  console.log('App customers list:', cust.status, cust.json ? JSON.stringify(cust.json).slice(0, 300) : cust.text)

  // also the exact URL the page calls — check what CustomerListPages fetches
  const cust2 = await call('GET', '/api/app-admin/customers', undefined, suCookie)
  console.log('App customers list (no qs):', cust2.status, cust2.json ? JSON.stringify(cust2.json).slice(0, 300) : cust2.text)

  // 3. customer signup (issue 2)
  const su = await call('POST', '/api/customer-app/auth/signup', { name: 'Live Test 42', mobile: '9772204242', password: 'Test@123' })
  console.log('Customer signup:', su.status, JSON.stringify(su.json).slice(0, 200) || su.text)

  // 4. customer login
  const li = await call('POST', '/api/customer-app/auth/login', { mobile: '9876500001', password: 'Demo@123' })
  console.log('Customer login (demo):', li.status, JSON.stringify(li.json).slice(0, 200) || li.text)
}
main().catch(e => { console.error('FATAL', e); process.exit(1) })
