#!/usr/bin/env python3
# gen-native-assets.py — brand assets for the Expo native app (Task 31)
# Dark #0B0E13 background + gold #D4AF37 "SMG" mark, matching the landing page.
from PIL import Image, ImageDraw, ImageFont

GOLD = (212, 175, 55)
GOLD_DIM = (154, 126, 40)
DARK = (11, 14, 19)
WHITE = (255, 255, 255)
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

OUT = "/home/z/my-project/satta-matka-god-native/assets/"


def logo(size: int, bg=DARK, fg=GOLD, ring=True) -> Image.Image:
    """Gold 'SMG' monogram inside a ring on the dark background."""
    img = Image.new("RGB", (size, size), bg)
    d = ImageDraw.Draw(img)
    m = size * 0.08
    if ring:
        d.ellipse([m, m, size - m, size - m], outline=fg, width=max(2, size // 34))
    f = ImageFont.truetype(FONT, int(size * 0.34))
    bb = d.textbbox((0, 0), "SMG", font=f)
    w, h = bb[2] - bb[0], bb[3] - bb[1]
    d.text(((size - w) / 2 - bb[0], (size - h) / 2 - bb[1] - size * 0.02), "SMG",
           font=f, fill=fg)
    # small star above the monogram
    star_f = ImageFont.truetype(FONT, int(size * 0.10))
    bb2 = d.textbbox((0, 0), "★", font=star_f)
    w2, h2 = bb2[2] - bb2[0], bb2[3] - bb2[1]
    d.text(((size - w2) / 2 - bb2[0], size * 0.17 - bb2[1]), "★", font=star_f, fill=fg)
    return img


def wordmark(height: int) -> Image.Image:
    """Splash: monogram + product name on transparent-friendly dark bg."""
    W, H = height * 2, height
    img = Image.new("RGB", (W, H), DARK)
    d = ImageDraw.Draw(img)
    mark = logo(int(H * 0.52))
    img.paste(mark, (int(W * 0.12), int(H * 0.24)))
    x = int(W * 0.12) + mark.width + int(H * 0.08)
    f1 = ImageFont.truetype(FONT, int(H * 0.13))
    d.text((x, int(H * 0.33)), "Satta Matka", font=f1, fill=GOLD)
    f2 = ImageFont.truetype(FONT, int(H * 0.16))
    d.text((x, int(H * 0.50)), "God", font=f2, fill=WHITE)
    return img


# 1. App icon 1024
logo(1024).save(OUT + "icon.png")
# 2. Adaptive-icon foreground (art inside the 66% safe zone on DARK,
#    not transparent — transparency in adaptive foreground renders black-ish
#    inconsistently across OEM launchers)
logo(1024).save(OUT + "adaptive-icon.png")
# 3. Splash image
wordmark(700).save(OUT + "splash-icon.png")
# 4. Notification small icon 96 (solid gold mark, no ring, no bg)
notif = logo(96, bg=DARK, fg=GOLD, ring=False)
notif.save(OUT + "notification-icon.png")
# 5. Favicon-ish 192 for reference/docs
logo(192).save(OUT + "icon-192.png")
print("assets written:", OUT)
