#!/bin/bash
# Task 35 one-shot verification — master-admin App Notifications (+ landing
# guide/customerapp regression). Start server → NEW notify suite → live-flow
# journey → ALL regressions → routes (incl. /customerapp + screenshots) →
# demo state → teardown. Single invocation (sandbox reaps detached servers
# between tool calls; pkill first kills any stale dev server from a prior run).
set -u
cd /home/z/my-project

PORT=3000
PASS=0; FAIL=0
c() { if [ "$1" = "0" ]; then PASS=$((PASS+1)); echo "PASS  $2"; else FAIL=$((FAIL+1)); echo "FAIL  $2"; fi }

pkill -f "next dev" 2>/dev/null; sleep 1

echo "════ starting dev server (one-shot) ════"
rm -f /tmp/one-shot-dev.log
nohup npx next dev -p $PORT > /tmp/one-shot-dev.log 2>&1 &
SRV=$!

UP=1
for i in $(seq 1 90); do
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 "http://localhost:$PORT/api/health" 2>/dev/null || echo 000)
  if [ "$code" = "200" ]; then UP=0; break; fi
  sleep 1
done
c $UP "server healthy on :$PORT"

if [ $UP -ne 0 ]; then
  echo "server did not come up — aborting"; kill $SRV 2>/dev/null; exit 1
fi

echo "════ warmup (cold Turbopack cache — compile every route before testing) ════"
warm() { # warm <path> <expected>
  for i in $(seq 1 12); do
    code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 30 "http://localhost:$PORT$1" 2>/dev/null || echo 000)
    [ "$code" = "$2" ] && return 0
    sleep 2
  done
  return 1
}
warm "/" 200;                          c $? "warm /"
warm "/merp" 200;                      c $? "warm /merp"
warm "/app" 200;                       c $? "warm /app"
warm "/customerapp" 200;               c $? "warm /customerapp"
warm "/api/customer-app/results?market=kalyan" 401; c $? "warm customer-app API surface"
warm "/api/app-admin/notifications" 401;            c $? "warm app-admin notifications route"
warm "/how-it-works/04-home.png" 200;  c $? "warm static screenshots"

echo "════ NEW: admin notifications suite ════"
bun scripts/test-admin-notify.ts > /tmp/t-notify.log 2>&1; c $? "admin-notify suite"
grep -E "PASS /" /tmp/t-notify.log | tail -1

echo "════ live flow journey (29 checks) ════"
bun scripts/flow-live-test.ts > /tmp/t-flow.log 2>&1; c $? "flow-live-test suite"
grep -E "PASS /|PASS," /tmp/t-flow.log | tail -1

echo "════ regression suites ════"
bun scripts/test-native-phase2.ts       > /tmp/t-phase2.log 2>&1; c $? "native-phase2 suite"
bun scripts/test-native-push.ts         > /tmp/t-push.log 2>&1;    c $? "native-push suite"
bun scripts/test-entry-parser.ts        > /tmp/t-parser.log 2>&1;  c $? "entry-parser suite"
bun scripts/test-games-engine.ts        > /tmp/t-games.log 2>&1;   c $? "games-engine suite"
bun scripts/test-agent-commission.ts    > /tmp/t-comm.log 2>&1;    c $? "agent-commission suite"
bun scripts/test-agent-access-control.ts> /tmp/t-rbac.log 2>&1;    c $? "agent-access-control suite"
bun scripts/test-whatsapp-pipeline.ts   > /tmp/t-wap.log 2>&1;     c $? "whatsapp-pipeline suite"
bun scripts/test-whatsapp-panel.ts      > /tmp/t-wapn.log 2>&1;    c $? "whatsapp-panel suite"
bun scripts/test-signup-approval-toggle.ts > /tmp/t-signup.log 2>&1; c $? "signup-approval-toggle suite"
bun scripts/test-chitthi-render.ts      > /tmp/t-chitthi.log 2>&1; c $? "chitthi render suite"

echo "════ suite tallies ════"
for f in /tmp/t-notify.log /tmp/t-flow.log /tmp/t-phase2.log /tmp/t-push.log /tmp/t-parser.log /tmp/t-games.log /tmp/t-comm.log /tmp/t-rbac.log /tmp/t-wap.log /tmp/t-wapn.log /tmp/t-signup.log /tmp/t-chitthi.log; do
  echo "-- $(basename $f)"; grep -E "RESULT|PASS /|pass," "$f" | tail -1
done

echo "════ routes (web + mobile API surface) ════"
for r in / /merp /app /customerapp /api/health; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT$r")
  [ "$code" = "200" ]; c $? "route $r → 200 (got $code)"
done
code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/how-it-works/04-home.png")
[ "$code" = "200" ]; c $? "landing screenshot /how-it-works/04-home.png → 200 (got $code)"
for r in "/api/customer-app/results?market=kalyan" "/api/customer-app/bets" "/api/customer-app/withdrawals" "/api/app-admin/notifications"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT$r")
  [ "$code" = "401" ]; c $? "unauth $r → 401 (got $code)"
done

echo "════ demo state untouched ════"
COOKIE=$(curl -s -i -X POST "http://localhost:$PORT/api/auth" -H 'Content-Type: application/json' \
  -d '{"username":"superadmin@mb.com","password":"SAdmin@123_321"}' | grep -i "^set-cookie:" | sed 's/^[Ss]et-[Cc]ookie: //' | cut -d';' -f1 | tr -d '\r' | tr '\n' ';' )
pend=$(curl -s "http://localhost:$PORT/api/app-admin/commissions" -H "cookie: $COOKIE" | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const j=JSON.parse(s);console.log(j.summary.pendingAmount)})")
[ "$pend" = "280" ]; c $? "demo pending commission still ₹280 (got ₹$pend)"
bcount=$(curl -s "http://localhost:$PORT/api/app-admin/notifications" -H "cookie: $COOKIE" | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const j=JSON.parse(s);console.log(j.broadcasts.length)})")
echo "  (broadcast history rows: $bcount — zznotify fixtures must be gone)"
custcount=$(curl -s "http://localhost:$PORT/api/app-admin/customers" -H "cookie: $COOKIE" | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const j=JSON.parse(s);console.log(j.customers.length)})")
echo "  (demo app customers: $custcount — flow fixture must be gone)"

echo "════ teardown ════"
kill $SRV 2>/dev/null; pkill -f "next dev" 2>/dev/null; sleep 1
echo "PASS=$PASS FAIL=$FAIL"
[ $FAIL -eq 0 ]
