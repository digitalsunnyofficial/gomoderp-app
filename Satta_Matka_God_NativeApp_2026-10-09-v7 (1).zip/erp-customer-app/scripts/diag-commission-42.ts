// Task 42: inspect demo commission drift (280.2 vs 280)
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
async function main() {
  const agent = await db.user.findFirst({ where: { username: 'agentsanjay' } })
  console.log('agent:', agent?.username, '| commissionPct:', agent?.commissionPct)
  const rows = await db.agentCommission.findMany({
    where: { agentUsername: 'agentsanjay' },
    orderBy: { createdAt: 'desc' }, take: 12,
  })
  for (const r of rows) {
    console.log(`${r.createdAt.toISOString()}  status=${r.status}  amount=${r.amount}  customer=${r.customerMobile || r.customerId}  meta=${(r as any).metadata || ''}`)
  }
  const pending = rows.filter(r => r.status === 'pending').reduce((s, r) => s + r.amount, 0)
  console.log('pending total:', pending)
  const recentCustomers = await db.appCustomer.findMany({ orderBy: { createdAt: 'desc' }, take: 5, select: { mobile: true, name: true, agentUsername: true, createdAt: true } })
  console.log('newest customers:', JSON.stringify(recentCustomers, null, 1))
  const recentBets = await db.appBet.findMany({ orderBy: { createdAt: 'desc' }, take: 5, select: { customerName: true, marketName: true, points: true, createdAt: true } })
  console.log('newest bets:', JSON.stringify(recentBets, null, 1))
}
main().finally(() => db.$disconnect())
