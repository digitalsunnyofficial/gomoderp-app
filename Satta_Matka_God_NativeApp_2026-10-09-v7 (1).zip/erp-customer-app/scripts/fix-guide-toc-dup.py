#!/usr/bin/env python3
# fix-guide-toc-dup.py — remove the duplicated first TOC entry left by the
# placeholder injector, and give the hyperlink entry a cached page number.
# Structure: para#1 = TOC field begin+instr+separate + hyperlink entry (empty
# PAGEREF result); para#2.. = 28 plain entries, first of which duplicates para#1.
import re, zipfile, shutil, os

DOCX = "/home/z/my-project/download/Satta_Matka_God_Deployment_and_Operations_Guide.docx"
TMP = DOCX + ".tmp"

with zipfile.ZipFile(DOCX, "r") as z:
    names = z.namelist()
    files = {n: z.read(n) for n in names}

doc = files["word/document.xml"].decode("utf-8")

# 1. cached page number "1" inside the first PAGEREF field (empty result today)
pat = re.compile(
    r'(<w:instrText[^>]*>PAGEREF _Toc\d+ \\h</w:instrText>\s*'
    r'<w:fldChar w:fldCharType="separate"/>)\s*'
    r'(<w:fldChar w:fldCharType="end"/>)'
)
doc, n1 = pat.subn(r'\1<w:r><w:t>1</w:t></w:r>\2', doc)
print(f"cached page numbers inserted: {n1}")

# 2. drop the duplicated plain "1. Executive Summary" paragraph (pStyle 9)
dup = re.compile(
    r'<w:p><w:pPr><w:pStyle w:val="9"/>.*?</w:pPr>'
    r'<w:r><w:t>1\. Executive Summary</w:t></w:r>'
    r'<w:r><w:tab/></w:r><w:r><w:t>1</w:t></w:r></w:p>'
)
doc, n2 = dup.subn("", doc, count=1)
print(f"duplicate plain entry removed: {n2}")
assert n1 == 1 and n2 == 1, "unexpected TOC structure — aborting without write"

files["word/document.xml"] = doc.encode("utf-8")
with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        z.writestr(n, files[n])
shutil.move(TMP, DOCX)
print("OK", os.path.getsize(DOCX), "bytes")
