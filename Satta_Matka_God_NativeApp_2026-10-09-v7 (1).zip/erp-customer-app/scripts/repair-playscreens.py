#!/usr/bin/env python3
# Repair PlayScreens.tsx: dedupe inserted imports/constants, fix paren corruption.
# ALL brackets built via chr() — zero literal brackets in this file.
import pathlib, re

LB, RB = chr(91), chr(93)
p = pathlib.Path('src/components/customerapp/PlayScreens.tsx')
src = p.read_text()
lines = src.split('\n')

# 1) dedupe the canonicalPanna import (keep first occurrence)
imp = 'import { canonicalPanna } from ' + chr(39) + '@/lib/matka/chart-definitions' + chr(39)
seen = False
out = []
for ln in lines:
    if ln.strip() == imp.strip():
        if seen:
            continue
        seen = True
    out.append(ln)
lines = out

# 2) collapse the duplicated constants blocks: find each block (comment+4 lines)
#    and keep only the first, rebuilt correctly.
BLOCK_MARK = '// Operator-canonical panna spelling for every grid/picker (ascending'
first_idx = None
drop = set()
for i, ln in enumerate(lines):
    if ln.startswith(BLOCK_MARK):
        if first_idx is None:
            first_idx = i
        else:
            # mark the 7 lines of this duplicate block (comment, 2 const pairs, blank)
            for j in range(i, min(i + 7, len(lines))):
                drop.add(j)
lines = [ln for i, ln in enumerate(lines) if i not in drop]

# 3) rebuild the remaining block's map lines with correct brackets/parens
lines = [
    ('  Object.entries(SPB).map((' + LB + 'k, v' + RB + ') => ' + LB + 'k, v.map(canonicalPanna)' + RB + '))')
    if ln.strip().startswith('Object.entries(SPB).map(') else ln
    for ln in lines
]
lines = [
    ('  Object.entries(DPB).map((' + LB + 'k, v' + RB + ') => ' + LB + 'k, v.map(canonicalPanna)' + RB + '))')
    if ln.strip().startswith('Object.entries(DPB).map(') else ln
    for ln in lines
]

src = '\n'.join(lines)

# 4) sanity: exactly one import + one SPB_C definition
assert src.count(imp) == 1, 'import dupes remain'
assert src.count('const SPB_C') == 1, 'SPB_C dupes remain'
assert src.count('const DPB_C') == 1, 'DPB_C dupes remain'
assert '.map(canonicalPanna)' + RB + '))' in src, 'bracket repair failed'

p.write_text(src)
print('REPAIRED: 1 import, 1 SPB_C, 1 DPB_C, brackets correct')
