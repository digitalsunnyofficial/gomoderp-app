import { db } from '../src/lib/db'
await db.whatsAppMessage.deleteMany({ where: { phone: '919812345678' } })
await db.appCustomer.deleteMany({ where: { mobile: '9812345678' } })
console.log('cleaned: messages + temp customer')
process.exit(0)
