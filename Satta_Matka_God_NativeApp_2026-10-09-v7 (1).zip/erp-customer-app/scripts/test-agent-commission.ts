/**
 * test-agent-commission.ts — end-to-end test of the Agent ↔ Customer
 * onboarding mapping + PLAY commission system (operator rule 2026-10:
 * agents earn on what their customers PLAY — deposits never earn
 * commission).
 *
 * Self-contained: creates its own temp super user + agent + customers,
 * runs the full matrix and cleans up everything afterwards.
 *
 * Matrix:
 *  A. MAPPING
 *   1. customer signup WITH agent code (agent username)  → agentUsername/agentName filed
 *   2. signup response + profile carry the agent name
 *   3. signup with UNKNOWN agent code → never blocks, falls back (default agent or none)
 *   4. signup WITHOUT code → default-agent rule (or none)
 *  B. PLAY COMMISSION (one ledger row per placed bet — never on deposits)
 *   5. deposit approved → NO commission row (deposit commission retired)
 *   6. agent override 10% → bet 2000 → row baseAmount=2000 amount=200 source=bet
 *   7. duplicate clientRequestId replay → no second row (idempotent)
 *   8. wallet top-up (simulated win) → bet 8000 → SECOND row amount=800
 *      (the operator's example shape: deposit → play → win → play again)
 *   9. explicit override 0% → bet → NO row
 *  10. override cleared → global 5% applies
 *  C. LEDGER + GUARDS
 *  11. mark_paid → paid + paidBy + paidAt; re-mark → 400; cancel path
 *  12. agent scoping: own rows only + customerRollup totals
 *  13. master summary/rollup: cancelled excluded, exact amounts
 *  14. no-agent customer bet → no row ever
 *  15. non-super PUT rejected; users/[id] PUT commissionRate works
 *
 * Run: bun scripts/test-agent-commission.ts   (server must be on :3000)
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const SUPER = 'zz-com-test'
const AGENT = 'zz-com-agent'
const AGENT_PHONE = '900' + String(Date.now()).slice(-7)

async function erpLogin(username: string, password: string): Promise<string> {
  const res = await fetch(`${BASE}/api/auth`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  })
  if (res.status !== 200) throw new Error(`erp login failed ${res.status}`)
  return (res.headers.get('set-cookie') || '').split(';')[0]
}

async function appLogin(mobile: string, password: string): Promise<string> {
  const res = await fetch(`${BASE}/api/customer-app/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mobile, password }),
  })
  const d = await res.json() as { token?: string }
  if (!d.token) throw new Error(`app login failed ${res.status}`)
  return d.token
}

async function placeBet(token: string, item: Record<string, unknown>) {
  const res = await fetch(`${BASE}/api/customer-app/bets`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify({ items: [item] }),
  })
  return { status: res.status, body: await res.json() as Record<string, unknown> }
}

const TEST_CUSTOMER_NAMES = ['Suresh Mapped', 'Unknown Code', 'Lonely Noagent', 'No Code']

/** Remove a user + every row that references it (FK-safe, idempotent). */
async function purgeUsers(usernames: string[]) {
  const uids = (await db.user.findMany({ where: { username: { in: usernames } } })).map(u => u.id)
  if (!uids.length) return
  await db.userSession.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.userActivity.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.userSubscription.deleteMany({ where: { userId: { in: uids } } }).catch(() => {})
  await db.user.deleteMany({ where: { id: { in: uids } } })
}

/** Remove test customers (by name) + their commissions/bets/funds/txns. FK-safe. */
async function purgeTestCustomers() {
  const custs = await db.appCustomer.findMany({ where: { name: { in: TEST_CUSTOMER_NAMES } } })
  for (const c of custs) {
    await db.agentCommission.deleteMany({ where: { customerId: c.id } })
    await db.appTransaction.deleteMany({ where: { customerId: c.id } })
    await db.appFundRequest.deleteMany({ where: { customerId: c.id } })
    await db.appNotification.deleteMany({ where: { customerId: c.id } })
    await db.appSession.deleteMany({ where: { customerId: c.id } })
    await db.appBet.deleteMany({ where: { customerId: c.id } })
    await db.appCustomer.delete({ where: { id: c.id } }).catch(() => {})
  }
}

/** Current IST minute-of-day (bets routes validate against IST windows). */
function istMinutes(): number {
  const d = new Date()
  return (d.getUTCHours() * 60 + d.getUTCMinutes() + 330) % 1440
}

let tempStarline: string | null = null
/** Find a bettable single-digit target right now; create a temp starline window if nothing is open. */
async function ensureBettable(): Promise<{ marketCode: string; slot: string; type: string; num: string }> {
  const ist = istMinutes()
  const sls = await db.appStarline.findMany({ where: { isOn: true, isActive: true } })
  for (const sl of sls) {
    if (ist < sl.hour * 60 + (sl.minute || 0) - (sl.betClosingMinutes || 0)) {
      return { marketCode: sl.code, slot: 'open', type: 'single', num: '5' }
    }
  }
  const markets = await db.appMarket.findMany({ where: { isActive: true } })
  for (const m of markets) {
    const [oh, om] = String(m.openTime).split(':').map(Number)
    const [ch, cm] = String(m.closeTime).split(':').map(Number)
    const openM = oh * 60 + om
    const closeM = ch * 60 + cm - (m.betClosingMinutes || 10)
    if (ist >= openM && ist < closeM) {
      return { marketCode: m.code, slot: m.session === 'close' ? 'close' : 'open', type: 'single', num: '5' }
    }
  }
  // Nothing open (night gap) — open a temp starline for the next IST hour.
  const nextHour = (Math.floor(ist / 60) + 1) % 24
  const code = 'st' + nextHour
  const existing = await db.appStarline.findUnique({ where: { code } })
  if (!existing) {
    await db.appStarline.create({
      data: { code, name: 'PlayComm Test ' + code, hour: nextHour, minute: 0, betClosingMinutes: 0, isOn: true, isActive: true, sortOrder: 999 },
    })
    tempStarline = code
  }
  return { marketCode: code, slot: 'open', type: 'single', num: '5' }
}

async function main() {
  // ── 0. Fixtures (also purges leftovers from any earlier aborted run) ──
  await purgeTestCustomers()
  await db.agentCommission.deleteMany({ where: { agentUsername: AGENT } })
  await db.appConfig.deleteMany({ where: { key: 'agent_commission_rate' } })
  await purgeUsers([SUPER, AGENT])
  await db.user.create({
    data: { username: SUPER, name: 'Commission Test Super', password: await bcrypt.hash('com-test-123', 10), role: 'super', status: 'active' },
  })
  await db.user.create({
    data: { username: AGENT, name: 'Ramesh Commission', password: await bcrypt.hash('com-agent-123', 10), role: 'user', status: 'active', phone: AGENT_PHONE },
  })
  const cookie = await erpLogin(SUPER, 'com-test-123')
  check('temp super login + cookie', !!cookie)

  // Baseline GLOBAL summary — the summary assertions below are DELTA-based so the
  // suite stays valid when legitimate non-test rows (e.g. the agentsanjay demo
  // ledger) already exist in the shared AgentCommission table.
  const base0 = await fetch(`${BASE}/api/app-admin/commissions`, { headers: { cookie } })
  const dd0 = await base0.json() as { summary: { pendingAmount: number; paidAmount: number } }
  const basePending = dd0.summary.pendingAmount
  const basePaid = dd0.summary.paidAmount
  check('baseline summary captured (pre-fixture)', typeof basePending === 'number' && typeof basePaid === 'number', JSON.stringify(dd0.summary))

  // Built-in default (operator rule 2026-10): with NO global rate configured,
  // the effective rate is 2% and the API flags it as the built-in default.
  await db.appConfig.deleteMany({ where: { key: 'agent_commission_rate' } })
  const g0 = await fetch(`${BASE}/api/app-admin/commissions`, { headers: { cookie } })
  const gd0 = await g0.json() as { globalRate: number; globalRateIsDefault: boolean }
  check('unset global rate → built-in default 2%', g0.status === 200 && gd0.globalRate === 2 && gd0.globalRateIsDefault === true, JSON.stringify(gd0))

  const stamp = String(Date.now()).slice(-8)
  const mobA = '91' + stamp.slice(-8)   // signup WITH agent code (plays)
  const mobB = '92' + stamp.slice(-8)   // signup with UNKNOWN code
  const mobC = '93' + stamp.slice(-8)   // direct DB customer, NO agent (plays)

  // Config + signup-toggle state to restore in cleanup
  const savedRate = await db.appConfig.findUnique({ where: { key: 'agent_commission_rate' } })
  const savedSignupToggle = await db.appConfig.findUnique({ where: { key: 'signup_approval_required' } })
  const bet = await ensureBettable()
  check('bettable window available (existing or temp starline)', !!bet.marketCode, JSON.stringify(bet))

  try {
    // Force config to a known state
    await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'set_global_rate', rate: 5 }),
    })
    await db.user.update({ where: { username: AGENT }, data: { commissionRate: null } })
    // Signups must auto-approve so the test customers can bet immediately
    await db.appConfig.upsert({
      where: { key: 'signup_approval_required' },
      update: { value: 'false' },
      create: { key: 'signup_approval_required', value: 'false' },
    })

    // ── A. MAPPING ──
    console.log('\nA. Agent ↔ Customer mapping')
    const s1 = await fetch(`${BASE}/api/customer-app/auth/signup`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Suresh Mapped', mobile: mobA, password: 'test123', referral: AGENT }),
    })
    const d1 = await s1.json() as { pendingApproval?: boolean; customer?: { agentName?: string | null } }
    check('signup with agent code → 200', s1.status === 200, JSON.stringify(d1))
    const custA = await db.appCustomer.findUnique({ where: { mobile: mobA } })
    check('customer filed under agent (agentUsername)', custA?.agentUsername === AGENT, JSON.stringify(custA?.agentUsername))
    check('agent name snapshot set', !!custA?.agentName, JSON.stringify(custA?.agentName))
    check('signup response carries agentName', (d1.customer?.agentName || '') !== '', JSON.stringify(d1.customer))

    const s2 = await fetch(`${BASE}/api/customer-app/auth/signup`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Unknown Code', mobile: mobB, password: 'test123', referral: 'no-such-agent-zz' }),
    })
    check('signup with unknown code → 200 (never blocks)', s2.status === 200, String(s2.status))
    const custB = await db.appCustomer.findUnique({ where: { mobile: mobB } })
    const defAgent = (await db.appConfig.findUnique({ where: { key: 'default_agent' } }))?.value?.trim() || null
    const expectedB = defAgent || null
    check('unknown code → default-agent fallback rule', custB?.agentUsername === expectedB, `got ${custB?.agentUsername}, expected ${expectedB}`)

    // Direct DB customer with NO agent (bypasses the default tree)
    const custC = await db.appCustomer.create({
      data: { name: 'Lonely Noagent', mobile: mobC, password: await bcrypt.hash('test123', 10), status: 'active', approvalStatus: 'approved', agentUsername: null, agentName: null, referral: null },
    })
    check('no-agent customer created', !!custC)

    // Signup without code — default-agent rule for the app path (informational)
    const s3 = await fetch(`${BASE}/api/customer-app/auth/signup`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'No Code', mobile: '94' + stamp.slice(-8), password: 'test123' }),
    })
    check('signup without code → 200', s3.status === 200, String(s3.status))
    const custD = await db.appCustomer.findUnique({ where: { mobile: '94' + stamp.slice(-8) } })
    check('no code → default-agent rule (or none)', custD?.agentUsername === expectedB, `got ${custD?.agentUsername}`)

    // ── B. PLAY COMMISSION MATRIX ──
    console.log('\nB. Play commission accrual matrix')

    async function mkFund(customerId: string, amount: number): Promise<string> {
      const f = await db.appFundRequest.create({
        data: { customerId, amount, method: 'UPI', utr: 'UTR' + Math.random().toString(36).slice(2, 10), status: 'pending' },
      })
      return f.id
    }
    async function approve(fundId: string): Promise<{ status: number; body: Record<string, unknown> }> {
      const res = await fetch(`${BASE}/api/app-admin/funds`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
        body: JSON.stringify({ id: fundId, action: 'approve' }),
      })
      return { status: res.status, body: await res.json() as Record<string, unknown> }
    }
    const rowsFor = (customerId: string) => db.agentCommission.findMany({ where: { customerId }, orderBy: { createdAt: 'asc' } })

    const tokenA = await appLogin(mobA, 'test123')
    const tokenC = await appLogin(mobC, 'test123')
    check('app logins issued', !!tokenA && !!tokenC)

    // 5. DEPOSIT → NO commission (rule change 2026-10)
    const f1 = await mkFund(custA!.id, 5000)
    const a1 = await approve(f1)
    check('deposit 5000 approved', a1.status === 200, JSON.stringify(a1.body))
    check('deposit approved → NO commission row (deposits never earn)', (await rowsFor(custA!.id)).length === 0)

    // 6. agent override 10% → bet 2000 → ONE row, exact amounts
    await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'set_agent_rate', agentUsername: AGENT, rate: 10 }),
    })
    const bet1 = await placeBet(tokenA, { ...bet, points: 2000, clientRequestId: 'pcom-1-' + stamp })
    check('bet 2000 placed', bet1.status === 200, JSON.stringify(bet1.body).slice(0, 200))
    check('placement reports commissionFiled=1', (bet1.body as { commissionFiled?: number }).commissionFiled === 1, JSON.stringify(bet1.body.commissionFiled))
    let rowsA = await rowsFor(custA!.id)
    check('exactly ONE commission row for the bet', rowsA.length === 1, String(rowsA.length))
    const r1 = rowsA[0]
    check('override 10% wins over global 5%', r1?.rate === 10 && r1?.amount === 200, `rate ${r1?.rate}, amount ${r1?.amount}`)
    check('row is play-sourced: source=bet, baseAmount=2000', r1?.source === 'bet' && r1?.baseAmount === 2000, `source ${r1?.source}, base ${r1?.baseAmount}`)
    check('row carries betId + play detail snapshots', !!r1?.betId && !!r1?.marketName && (r1?.detail || '').length > 0, JSON.stringify({ betId: r1?.betId, marketName: r1?.marketName, detail: r1?.detail }))
    check('snapshots: agent + customer on row', r1?.agentUsername === AGENT && r1?.customerName === 'Suresh Mapped' && r1?.customerMobile === mobA)

    // 7. duplicate clientRequestId replay → no second row
    const replay = await placeBet(tokenA, { ...bet, points: 2000, clientRequestId: 'pcom-1-' + stamp })
    check('replay ignored (placedCount 0)', replay.status === 200 && (replay.body as { placedCount?: number }).placedCount === 0, JSON.stringify(replay.body).slice(0, 120))
    check('still exactly ONE commission row after replay', (await rowsFor(custA!.id)).length === 1)

    // 8. WIN refill → play again → SECOND row (operator's example shape)
    const topup = await fetch(`${BASE}/api/app-admin/customers`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ id: custA!.id, amount: 10000, remark: 'Play commission test — simulated win payout' }),
    })
    check('wallet top-up 10000 (simulated win)', topup.status === 200, JSON.stringify(await topup.json()).slice(0, 120))
    const bet2 = await placeBet(tokenA, { ...bet, points: 8000, clientRequestId: 'pcom-2-' + stamp })
    check('second bet 8000 placed (after win refill)', bet2.status === 200, JSON.stringify(bet2.body).slice(0, 200))
    rowsA = await rowsFor(custA!.id)
    check('SECOND commission row filed', rowsA.length === 2, String(rowsA.length))
    const r2 = rowsA[1]
    check('second row: baseAmount=8000 amount=800 rate=10', r2?.baseAmount === 8000 && r2?.amount === 800 && r2?.rate === 10, `base ${r2?.baseAmount}, amount ${r2?.amount}, rate ${r2?.rate}`)
    check('cumulative commission = 1000 on 10000 played', rowsA.reduce((a, x) => a + x.amount, 0) === 1000 && rowsA.reduce((a, x) => a + x.baseAmount, 0) === 10000)

    // 9. explicit override 0% → commission OFF for this agent
    await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'set_agent_rate', agentUsername: AGENT, rate: 0 }),
    })
    const bet3 = await placeBet(tokenA, { ...bet, points: 100, clientRequestId: 'pcom-3-' + stamp })
    check('bet 100 placed under 0% override', bet3.status === 200, JSON.stringify(bet3.body).slice(0, 120))
    check('override 0% → NO commission row', (await rowsFor(custA!.id)).length === 2)

    // 10. override cleared → global 5% applies
    await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'set_agent_rate', agentUsername: AGENT, rate: null }),
    })
    const bet4 = await placeBet(tokenA, { ...bet, points: 800, clientRequestId: 'pcom-4-' + stamp })
    check('bet 800 placed under global rate', bet4.status === 200, JSON.stringify(bet4.body).slice(0, 120))
    rowsA = await rowsFor(custA!.id)
    check('third row filed at global 5%', rowsA.length === 3 && rowsA[2]?.rate === 5 && rowsA[2]?.amount === 40, JSON.stringify(rowsA[2]))

    // 14. no-agent customer plays → no row ever
    const fC = await mkFund(custC.id, 1000)
    const aC = await approve(fC)
    check('no-agent customer deposit 1000 approved', aC.status === 200, JSON.stringify(aC.body))
    const betC = await placeBet(tokenC, { ...bet, points: 500, clientRequestId: 'pcom-c-' + stamp })
    check('no-agent customer bet placed', betC.status === 200, JSON.stringify(betC.body).slice(0, 120))
    check('no-agent customer → NO commission rows', (await db.agentCommission.count({ where: { customerId: custC.id } })) === 0)

    // ── C. LEDGER + GUARDS ──
    console.log('\nC. Ledger workflow + guards')

    // 12. agent scoping: login as agent, GET sees only own rows + rollups
    const agentCookie = await erpLogin(AGENT, 'com-agent-123')
    const g1 = await fetch(`${BASE}/api/app-admin/commissions`, { headers: { cookie: agentCookie } })
    const dd1 = await g1.json() as {
      commissions: Array<{ agentUsername: string; baseAmount: number; amount: number }>
      scope: string; agents: unknown[]
      customerRollup: Array<{ customerId: string; played: number; commission: number; count: number }>
    }
    check('agent GET 200, scope=self', g1.status === 200 && dd1.scope === 'self')
    check('agent sees ONLY own rows', dd1.commissions.length > 0 && dd1.commissions.every(r => r.agentUsername === AGENT), JSON.stringify(dd1.commissions.map(r => r.agentUsername)))
    check('agent never receives the agents directory', Array.isArray(dd1.agents) && dd1.agents.length === 0)
    check('agent customerRollup: 1 customer, played=10800 commission=1040 bids=3 (pre-mark/cancel)',
      dd1.customerRollup.length === 1 &&
      dd1.customerRollup[0].played === 10800 &&
      dd1.customerRollup[0].commission === 1040 &&
      dd1.customerRollup[0].count === 3,
      JSON.stringify(dd1.customerRollup))

    // 15. non-super PUT rejected
    const p1 = await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie: agentCookie },
      body: JSON.stringify({ action: 'mark_paid', id: r1!.id }),
    })
    check('agent PUT rejected 403', p1.status === 403, String(p1.status))

    // 11. mark_paid (super) + re-mark rejected + cancel path
    const p2 = await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'mark_paid', id: r1!.id }),
    })
    check('super mark_paid 200', p2.status === 200, String(p2.status))
    const row1 = await db.agentCommission.findUnique({ where: { id: r1!.id } })
    check('row paid with paidBy snapshot', row1?.status === 'paid' && row1?.paidBy === SUPER && !!row1?.paidAt)
    const p3 = await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'mark_paid', id: r1!.id }),
    })
    check('re-mark-paid already-paid → 400', p3.status === 400, String(p3.status))
    const p4 = await fetch(`${BASE}/api/app-admin/commissions`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ action: 'cancel', id: r2!.id }),
    })
    check('super cancel 200', p4.status === 200, String(p4.status))
    const row2 = await db.agentCommission.findUnique({ where: { id: r2!.id } })
    check('row cancelled (audit row preserved)', row2?.status === 'cancelled')

    // users/[id] PUT commissionRate (super)
    const agentId = (await db.user.findUnique({ where: { username: AGENT } }))!.id
    const u1 = await fetch(`${BASE}/api/users/${agentId}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ commissionRate: 7.5, updatedBy: SUPER }),
    })
    check('users PUT commissionRate 7.5 → 200', u1.status === 200, String(u1.status))
    check('DB commissionRate persisted', ((await db.user.findUnique({ where: { id: agentId } }))!.commissionRate) === 7.5)
    const u2 = await fetch(`${BASE}/api/users/${agentId}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie: agentCookie },
      body: JSON.stringify({ commissionRate: 99 }),
    })
    check('agent self-serve rate change rejected 403', u2.status === 403, String(u2.status))

    // 13. master summary + rollups (exact money math)
    // r1 ₹200 → paid; r2 ₹800 → cancelled (excluded from pending/paid/rollups); r3 ₹40 → pending
    const g2 = await fetch(`${BASE}/api/app-admin/commissions`, { headers: { cookie } })
    const dd2 = await g2.json() as {
      commissions: Array<{ status: string; amount: number }>
      summary: { pendingAmount: number; paidAmount: number }
      globalRate: number
      agentRollup: Array<{ agentUsername: string; totalCommission: number; totalPlayed: number; count: number }>
      customerRollup: Array<{ customerId: string; played: number; commission: number }>
    }
    check('super summary: paid delta = +200 (baseline + fixture)', dd2.summary.paidAmount === basePaid + 200, `base ${basePaid} → ${JSON.stringify(dd2.summary)}`)
    check('super summary: pending delta = +40 (cancelled excluded)', dd2.summary.pendingAmount === basePending + 40, `base ${basePending} → ${JSON.stringify(dd2.summary)}`)
    check('cancelled row still present in ledger (audit preserved)', dd2.commissions.some(r => r.status === 'cancelled' && r.amount === 800))
    check('globalRate readable = 5', dd2.globalRate === 5)
    check('agentRollup: totalCommission=240 totalPlayed=2800 (cancelled excluded)',
      dd2.agentRollup.some(r => r.agentUsername === AGENT && r.totalCommission === 240 && r.totalPlayed === 2800 && r.count === 2),
      JSON.stringify(dd2.agentRollup))
    check('super customerRollup carries the played + commission per customer',
      dd2.customerRollup.some(r => r.customerId === custA!.id && r.played === 2800 && r.commission === 240),
      JSON.stringify(dd2.customerRollup))

    // restore original global rate (delete → back to built-in default 2%)
    if (savedRate) {
      await fetch(`${BASE}/api/app-admin/commissions`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
        body: JSON.stringify({ action: 'set_global_rate', rate: Number(savedRate.value) }),
      })
    } else {
      await db.appConfig.deleteMany({ where: { key: 'agent_commission_rate' } })
    }
  } finally {
    // ── Cleanup (FK-safe, also covers earlier aborted runs) ──
    await purgeTestCustomers()
    await db.agentCommission.deleteMany({ where: { agentUsername: AGENT } })
    await db.appConfig.deleteMany({ where: { key: 'agent_commission_rate' } })
    if (savedSignupToggle) {
      await db.appConfig.update({ where: { key: 'signup_approval_required' }, data: { value: savedSignupToggle.value } }).catch(() => {})
    }
    if (tempStarline) {
      await db.appStarline.deleteMany({ where: { code: tempStarline, name: { startsWith: 'PlayComm Test' } } }).catch(() => {})
    }
    await purgeUsers([SUPER, AGENT])
    console.log('\ncleanup done — fixtures removed')
  }

  console.log(`\n════════════════════════════════`)
  console.log(`RESULT: ${pass} pass, ${fail} fail`)
  if (fail > 0) process.exit(1)
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
