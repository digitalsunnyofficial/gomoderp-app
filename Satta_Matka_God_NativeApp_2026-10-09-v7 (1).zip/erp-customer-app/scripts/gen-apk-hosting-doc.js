// ────────────────────────────────────────────────────────────────────────────
// gen-apk-hosting-doc.js — Customer App Android APK & Hosting Guide (.docx)
// Recipe R1 (Pure Paragraph Left) + DM-1 Deep Cyan palette, English guide,
// Profile A fonts (Times New Roman), 3-section structure (cover / front / body)
// Structure reuses the validated gen-smart-entry-doc.js generator (Task 20).
// ────────────────────────────────────────────────────────────────────────────
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, AlignmentType, HeadingLevel,
  WidthType, BorderStyle, ShadingType, SectionType, TableOfContents,
  PageBreak, LevelFormat, TableLayoutType,
} = require("docx");
const fs = require("fs");

// ── Palette: DM-1 Deep Cyan (tech guide) ──
const P = {
  bg: "162235", accent: "37DCF2",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "1B6B7A", headerText: "FFFFFF", accentLine: "1B6B7A", innerLine: "C8DDE2", surface: "EDF3F5" },
  headingColor: "0B3C4A",
  body: "000000", secondary: "505A64",
};
const FONTS = { ascii: "Times New Roman", eastAsia: "SimSun" };
const MONO = { ascii: "Courier New", eastAsia: "SimSun" };

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ── Text helpers ──
function safeText(v, ph) {
  if (v === undefined || v === null || v === "" || String(v) === "NaN" || String(v) === "undefined") return ph || "[n/a]";
  return String(v);
}
function run(text, opts = {}) {
  return new TextRun({ text: safeText(text), size: 24, color: P.body, font: FONTS, ...opts });
}
function monoRun(text, opts = {}) {
  return new TextRun({ text: safeText(text), size: 20, color: P.body, font: MONO, ...opts });
}
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1, alignment: AlignmentType.CENTER,
    spacing: { before: 360, after: 180, line: 380, lineRule: "atLeast" },
    children: [new TextRun({ text, bold: true, size: 32, color: P.headingColor, font: FONTS })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 130, line: 360, lineRule: "atLeast" },
    children: [new TextRun({ text, bold: true, size: 30, color: P.headingColor, font: FONTS })],
  });
}
function body(textOrRuns, opts = {}) {
  const children = Array.isArray(textOrRuns) ? textOrRuns : [run(textOrRuns)];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children, ...opts,
  });
}
function bullet(textOrRuns) {
  const children = Array.isArray(textOrRuns) ? textOrRuns : [run(textOrRuns)];
  return new Paragraph({ bullet: { level: 0 }, spacing: { line: 312, after: 60 }, children });
}
function numbered(ref, textOrRuns) {
  const children = Array.isArray(textOrRuns) ? textOrRuns : [run(textOrRuns)];
  return new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { line: 312, after: 60 }, children });
}
function caption(text) {
  return new Paragraph({
    keepNext: true, spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: P.headingColor, font: FONTS })],
  });
}
function cellPara(content) {
  if (typeof content === "object" && content.t !== undefined) {
    if (content.mono) return new Paragraph({ spacing: { line: 312 }, children: [monoRun(content.t, { bold: !!content.bold, color: content.color || P.body })] });
    return new Paragraph({ spacing: { line: 312 }, children: [run(content.t, { bold: !!content.bold, size: 21, color: content.color || P.body })] });
  }
  return new Paragraph({ spacing: { line: 312 }, children: [run(String(content), { size: 21 })] });
}
function tbl(headers, rows, widths, opts = {}) {
  const headerRow = new TableRow({
    tableHeader: true, cantSplit: true,
    children: headers.map((text, i) => new TableCell({
      children: [new Paragraph({ spacing: { line: 312 }, children: [new TextRun({ text, bold: true, size: 21, color: P.table.headerText, font: FONTS })] })],
      shading: { type: ShadingType.CLEAR, fill: P.table.headerBg },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  });
  const dataRows = rows.map((cells, r) => new TableRow({
    cantSplit: true,
    children: cells.map((cell, i) => new TableCell({
      children: [cellPara(cell)],
      shading: { type: ShadingType.CLEAR, fill: r % 2 === 0 ? "FFFFFF" : P.table.surface },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: P.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: P.table.innerLine },
      insideVertical: NB,
    },
    rows: [headerRow, ...dataRows],
  });
}
// Command block: shaded single-cell table so commands survive copy/paste
function cmdBlock(lines) {
  const paras = lines.map(t => new Paragraph({
    spacing: { line: 312, after: 40 },
    children: [monoRun(t, { color: "0B3C4A" })],
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: P.table.innerLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.innerLine },
      left: { style: BorderStyle.SINGLE, size: 8, color: P.table.accentLine },
      right: NB, insideHorizontal: NB, insideVertical: NB,
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        children: paras,
        shading: { type: ShadingType.CLEAR, fill: "F4F8F9" },
        margins: { top: 100, bottom: 100, left: 160, right: 120 },
        width: { size: 100, type: WidthType.PERCENTAGE },
      })],
    })],
  });
}

// ── Cover (R1) — English-aware title layout ──
function estimateTextWidth(text, pt) {
  let width = 0;
  for (const ch of text) {
    const code = ch.codePointAt(0);
    const isCJK = (code >= 0x4E00 && code <= 0x9FFF) || (code >= 0x3400 && code <= 0x4DBF) ||
      (code >= 0x3000 && code <= 0x303F) || (code >= 0xFF00 && code <= 0xFFEF);
    width += isCJK ? pt * 20 : pt * 11;
  }
  return width;
}
function splitTitleLinesEN(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = []; let cur = "";
  for (const w of words) {
    const candidate = cur ? cur + " " + w : w;
    if (estimateTextWidth(candidate, pt) <= maxWidthTwips || !cur) cur = candidate;
    else { lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 4) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLinesEN(title, maxWidthTwips, titlePt);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLinesEN(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(params) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
    metaLineCount = 0, fixedHeight = 800, pageHeight = 16838 } = params;
  const SAFETY = 1200;
  const usableHeight = pageHeight - SAFETY;
  const titleHeight = titleLineCount * (titlePt * 23 + 200);
  const subtitleHeight = hasSubtitle ? (12 * 23 + 600) : 0;
  const englishLabelHeight = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaHeight = metaLineCount * (10 * 23 + 100);
  const implicitParaHeight = 3 * 300;
  const contentHeight = titleHeight + subtitleHeight + englishLabelHeight + metaHeight + fixedHeight + implicitParaHeight;
  const remainingSpace = usableHeight - contentHeight;
  const safeRemaining = Math.max(remainingSpace, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(safeRemaining * 0.45);
  const rawBottom = Math.floor(safeRemaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(safeRemaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}
function buildCoverR1(config) {
  const PC = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: PC.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: PC.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "), size: 18, color: PC.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true, color: PC.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 800, line: 320, lineRule: "atLeast" },
      children: [new TextRun({ text: config.subtitle, size: 24, color: PC.subtitleColor, font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: PC.metaColor, font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: PC.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: PC.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        " }),
      new TextRun({ text: config.footerRight || "", size: 16, color: PC.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: PC.bg }, borders: noBorders,
        children,
      })],
    })],
  })];
}

// ── Shared header/footer ──
function pageHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.innerLine, space: 4 } },
      children: [new TextRun({ text: "Customer App \u2014 Android APK & Hosting Guide", size: 18, color: "808080", font: FONTS })],
    })],
  });
}
function pageNumFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: FONTS })],
    })],
  });
}

// ════════════════════════════════════════════════════════════════════════════
// FRONT MATTER — Executive Summary + Table of Contents
// ════════════════════════════════════════════════════════════════════════════
const frontMatter = [
  h1("Executive Summary"),
  body("The Matka Card ERP platform now ships as two products from one codebase: the ERP administration panel (used by the operator and staff) and the customer app (used by players to register, add points through UPI, place bids and see results). This guide explains the complete delivery chain for the customer Android application: how the APK is built, how the app talks to the server, what changes when the ERP is hosted on a real domain, and how the finished APK is published to customers through the built-in download landing page."),
  body("The central fact that makes the whole chain simple is that the customer app is a web application served by the same server as the ERP. Every screen of the customer app already exists at the /app route of the deployed site, and every API call it makes uses a relative path such as /api/customer-app/.... The Android APK is therefore a thin, native shell around that web app: it opens the operator\u2019s domain inside a secure system WebView, adds an app icon and splash screen, and behaves like any normal installed application. All business logic, all data and all fixes live on the server \u2014 updating the ERP website instantly updates every installed app, with no Play Store and no app updates required for content or logic changes."),
  body([
    run("The guide is organised as follows. Chapters 1\u20132 explain the architecture and what runs where. Chapter 3 is the complete, command-by-command APK build procedure using Capacitor, including icon, splash screen, signing and the release build. Chapters 4\u20135 cover hosting the ERP on the operator\u2019s own domain with HTTPS and list exactly what changes \u2014 and what deliberately does not \u2014 when moving from the current preview URL to the production domain. Chapter 6 covers publishing through the built-in download page, and Chapters 7\u20138 provide the operating procedures and the final go-live checklist."),
  ]),
  body([
    run("Audience: ", { bold: true }),
    run("the operator and any technician performing the hosting and APK steps. Every command is copy-paste ready; every value that depends on the operator (domain name, app id, keystore password) is marked as a placeholder in the form \u3010your-domain.com\u3011."),
    new PageBreak(),
  ]),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 480, after: 360 },
    children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FONTS, color: P.headingColor })],
  }),
  new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }),
  new Paragraph({
    spacing: { before: 200 },
    children: [new TextRun({ text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \u201CUpdate Field.\u201D", italics: true, size: 18, color: "888888", font: FONTS })],
  }),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 1 — System at a Glance
// ════════════════════════════════════════════════════════════════════════════
const ch1 = [
  h1("1. System at a Glance"),
  body("One server, one codebase, three delivery surfaces. The Next.js project that constitutes the ERP also serves the marketing landing page (the root address), the customer web app (the /app route), and every API the two products need (the /api routes). The ERP panel itself lives at /merp and is where operators run the business: markets, results, Smart Entry, customer approvals, payment management and the signup-approval toggle. The customer app is the player-facing surface: registration and login, wallet with UPI deposits and withdrawals, live markets with rates, bid placement for single, jodi, panna and chart games, result notifications and winning settlements."),
  body("Because the customer app is web technology, it can be delivered in two ways at the same time. Any customer with a browser can simply open the site address; nothing needs to be installed. And for the \u201Creal app on the home screen\u201D experience \u2014 an icon, a splash screen, full-screen without browser bars \u2014 the same address is wrapped into a native Android APK. The wrapper is produced with Capacitor, the standard open-source tool for turning web apps into installable Android applications. The wrapper contains no business logic at all: it is a few megabytes of native shell whose only job is to open the operator\u2019s domain full-screen and keep the session secure."),
  body("This architecture has three practical consequences that the rest of the guide builds on. First, there is exactly one deployment target: the server. Fixing a bug, changing a rate, or adding a game is done once in the ERP codebase and is live for every customer immediately, regardless of which APK version they installed. Second, the APK itself almost never needs rebuilding \u2014 only when the icon, the name, the app identifier or the server address changes. Third, security-relevant behaviour (passwords, sessions, wallet balances, bet validation) never leaves the server; the device only ever renders screens and displays data that the server has already authorised."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 2 — How the Android App Works
// ════════════════════════════════════════════════════════════════════════════
const ch2 = [
  h1("2. How the Android App Works"),
  h2("2.1 What Runs Where"),
  body("The division of labour between the installed app and the server is deliberately one-sided. The table below lists every concern and where it lives. The only thing stored on the device of any significance is the session token (a random 64-character key in the WebView\u2019s local storage), plus normal UI cache. A lost phone is therefore a session problem, not a data problem: the operator blocks the customer from the ERP and every further request with that token is refused."),
  caption("Table 2-1: Responsibilities of the device and the server"),
  tbl(
    ["Concern", "On the device (APK)", "On the server (ERP domain)"],
    [
      ["Screens and layout", "Renders whatever the server sends (WebView)", "Serves the customer web app at /app"],
      ["Login and registration", "Displays the forms", "Validates, hashes passwords, creates the account; applies the signup-approval toggle"],
      ["Session", "Holds the token in local storage", "Creates, validates, expires (90-day sliding window) and can revoke sessions"],
      ["Wallet and points", "Shows balances", "Owns the ledger; every deposit, win and withdrawal is a server transaction"],
      ["Bids and games", "Sends bid slips", "Validates rates, closing times and balances; settles results"],
      ["Business rules and fixes", "\u2014 none \u2014", "All of them; updated by redeploying the site"],
    ],
    [22, 36, 42]
  ),
  h2("2.2 One Code Path for Web and APK"),
  body("There is no separate mobile codebase to maintain. The customer app screens are regular web pages that already adapt to phone-sized screens, and every network call they make uses a relative address (\u201C/api/customer-app/...\u201D). When the same pages are shown inside the APK\u2019s WebView and loaded from the operator\u2019s domain, the relative calls resolve to that same domain \u2014 which means the APK works unchanged on the developer\u2019s test site, on a preview URL, and on the final production domain. The only per-domain setting inside the APK is the server address it opens at start-up, configured in one small file (Chapter 3, step 3)."),
  h2("2.3 What the Customer Experience Looks Like"),
  body("A customer receives the download link or QR code, opens the download page in any Android browser, taps the download button and installs (Chapter 6 covers the publication flow; the download page itself detects whether the APK file is present and guides the customer accordingly). On first open the app shows the login and registration screen. Depending on the Master Admin\u2019s signup-approval setting in the ERP, the new account either starts playing immediately (toggle off \u2014 instant access) or waits briefly for the operator\u2019s approval in the ERP Customer List (toggle on \u2014 the default). After logging in, the customer picks a language once, sees the live markets with their wallet balance, places bids, and receives results and winnings automatically. Nothing in this flow changes between the web delivery and the APK delivery \u2014 it is literally the same application."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 3 — Building the APK Step by Step
// ════════════════════════════════════════════════════════════════════════════
const ch3 = [
  h1("3. Building the APK \u2014 Step by Step"),
  body("This chapter produces a signed, installable APK named Matka Bazaar using Capacitor. The steps are written for a Windows or macOS machine with internet access and take roughly 30\u201345 minutes the first time. Perform them once; afterwards only step 7 (rebuilding) is ever needed."),
  h2("3.1 Prerequisites"),
  bullet("Node.js LTS (18 or newer) installed \u2014 verify with node -v."),
  bullet("Android Studio installed (this supplies the Android SDK, build tools and an emulator for testing). Open it once and accept the default SDK installation."),
  bullet("Java 17 runtime (bundled with recent Android Studio versions)."),
  bullet("The server address the app should open \u2014 during testing the current preview URL, later \u3010https://your-domain.com\u3011 (Chapter 5)."),
  h2("3.2 Create the Wrapper Project"),
  body("Create a folder outside the ERP project \u2014 this wrapper is a small, separate build project. Inside it, initialise Capacitor with the app\u2019s public name and identifier:"),
  cmdBlock([
    "mkdir matka-app-wrapper && cd matka-app-wrapper",
    "npm init -y",
    "npm install @capacitor/core @capacitor/cli @capacitor/android",
    "npx cap init \"Matka Bazaar\" \"com.classinfotech.matkabazaar\" --web-dir=www",
    "mkdir www",
  ]),
  body("The identifier \u3010com.classinfotech.matkabazaar\u3011 is permanent \u2014 it becomes the app\u2019s identity on the device and cannot be changed after customers have installed it, so choose it once, carefully."),
  h2("3.3 Point the App at Your Server"),
  body("Edit capacitor.config.json so the wrapper opens the ERP\u2019s customer app directly and allows that domain to navigate:"),
  cmdBlock([
    "{",
    "  \"appId\": \"com.classinfotech.matkabazaar\",",
    "  \"appName\": \"Matka Bazaar\",",
    "  \"webDir\": \"www\",",
    "  \"server\": {",
    "    \"url\": \"https://your-domain.com/app\",",
    "    \"cleartext\": false,",
    "    \"allowNavigation\": [\"your-domain.com\"]",
    "  }",
    "}",
  ]),
  body("Replace \u3010your-domain.com\u3011 with the address the ERP is (or will be) hosted on. For the first build it can equally be the current preview address \u2014 Chapter 5 explains the one-line change needed when the real domain goes live. cleartext: false enforces HTTPS, which keeps logins safe and is required by modern Android."),
  h2("3.4 Add the Icon and Splash Screen"),
  body("Prepare two images: a 1024\u00D71024 icon.png (the square logo) and a 2732\u00D72732 splash.png (background colour with centred logo works best). Place them in a new folder named resources, then generate every density Android needs automatically:"),
  cmdBlock([
    "npm install @capacitor/assets --save-dev",
    "npx capacitor-assets generate --android",
  ]),
  h2("3.5 Create the Native Android Project"),
  cmdBlock([
    "npx cap add android",
    "npx cap sync android",
  ]),
  body("This writes the android/ folder \u2014 a complete, standard Android Studio project owned by you. From this point the app can already be built as a test version."),
  h2("3.6 Build a Test APK and Verify It"),
  cmdBlock([
    "cd android",
    ".\\gradlew assembleDebug        (Windows)",
    "./gradlew assembleDebug        (macOS / Linux)",
  ]),
  body("The finished file appears at android/app/build/outputs/apk/debug/app-debug.apk. Copy it to a real Android phone (Android 8 or newer), tap it, allow \u201Cinstall from this source\u201D when asked, and open the app. It should show the customer app from the configured server address: register a test customer, place a test bid on a test market, and confirm the wallet updates. This debug APK is for testing only \u2014 it is signed with a debug key and should never be distributed to customers."),
  h2("3.7 Build the Signed Release APK (the one customers get)"),
  body("Android requires every distributed APK to be signed with a private keystore that only the operator owns. Generate it once and keep it safe \u2014 losing it means customers must uninstall and reinstall when a new release appears:"),
  cmdBlock([
    "keytool -genkey -v -keystore matka-bazaar.keystore -alias matkabazaar",
    "  -keyalg RSA -keysize 2048 -validity 10000",
  ]),
  body("Store the keystore file, its password and the alias password in two safe places. Then open android/app/build.gradle and add the signing configuration, replacing the placeholders:"),
  cmdBlock([
    "android { signingConfigs { release {",
    "    storeFile file(\"../../matka-bazaar.keystore\")",
    "    storePassword \"\u3010keystore-password\u3011\"",
    "    keyAlias \"matkabazaar\"",
    "    keyPassword \"\u3010key-password\u3011\"",
    "} } buildTypes { release { signingConfig signingConfigs.release",
    "    minifyEnabled false } } }",
  ]),
  body("Finally build the release APK:"),
  cmdBlock([
    ".\\gradlew assembleRelease      (Windows)",
    "./gradlew assembleRelease      (macOS / Linux)",
  ]),
  body("The distributable file is at android/app/build/outputs/apk/release/app-release.apk \u2014 roughly 3\u20135 MB, since it contains only the shell. This is the file published to customers in Chapter 6."),
  h2("3.8 When Does the APK Need Rebuilding?"),
  body("Almost never. Rebuild only when the server address changes (moving to the production domain), when the icon, name or version changes, or when a new Android capability is added. Rate changes, game changes, design changes, result logic, fixes \u2014 all of those are deployed on the server and reach every installed app on the customer\u2019s next app open, with no rebuild and no reinstall."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 4 — Hosting the ERP on Your Domain
// ════════════════════════════════════════════════════════════════════════════
const ch4 = [
  h1("4. Hosting the ERP on Your Domain"),
  h2("4.1 What the Platform Needs"),
  body("The ERP is a Node.js application with a local database file. It therefore needs hosting that can run a persistent Node process \u2014 a VPS or a Node-enabled hosting plan \u2014 and it cannot run correctly on hosting that only serves static files. A Hostinger VPS (or any Ubuntu server) with 2\u20134 GB of RAM is a comfortable fit. The domain name (for example \u3010your-domain.com\u3011) is pointed at that server, and an HTTPS certificate is installed on it. HTTPS is not optional: the customer app wrapper is configured to refuse non-secure connections, and password or wallet traffic must never travel unencrypted."),
  h2("4.2 The Deployment Steps"),
  numbered("host-steps", "Point the domain: create an A record from \u3010your-domain.com\u3011 to the server\u2019s IP address and wait for DNS to propagate (usually minutes to a few hours)."),
  numbered("host-steps", "Install Node.js LTS, a process manager (pm2) and a web server with SSL (Caddy or Nginx + certbot) on the server."),
  numbered("host-steps", "Copy the project to the server (the deployment zip built for VS Code and Hostinger contains the full source, the schema and the deployment scripts)."),
  numbered("host-steps", "Run npm install, then npx prisma generate, then npx prisma db push to create the database schema at the DATABASE_URL path configured in .env."),
  numbered("host-steps", "Run the build (npm run build) and start the app under the process manager (pm2 start npm --name erp -- start)."),
  numbered("host-steps", "Reverse-proxy the domain to the app\u2019s port with SSL enabled (Caddy does this automatically with a Let\u2019s Encrypt certificate from one line of configuration)."),
  numbered("host-steps", "Open the site, verify the landing page, log into the ERP, change the seeded demo passwords, and set the real UPI QR and rates in the ERP."),
  body("The project zip ships with the deployment bootstrap that was used for the original Hostinger packaging; on a Hostinger Node plan the same steps run through their Node.js application panel instead of the command line, with the panel supplying the Node version and the start command."),
  h2("4.3 The Database and Backups"),
  body("The platform uses SQLite: the entire database is one file (custom.db at the path configured in .env). This keeps hosting simple \u2014 no database server to install \u2014 but it makes the file precious. Configure a daily backup that copies that one file somewhere off the server (Hostinger backups, or a nightly cron that copies it to object storage). Restoring is the same operation in reverse: stop the app, put the file back, start the app. No other component holds state."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 5 — What Changes When Moving to the Domain
// ════════════════════════════════════════════════════════════════════════════
const ch5 = [
  h1("5. What Changes When the ERP Moves to the Domain"),
  body("The short answer: almost nothing in the code, three things in configuration. Because every API call in both the ERP and the customer app is relative, and the whole system is served from one origin, the same build that runs today on the preview address runs on the production domain unchanged. The table below separates reality from the common fear that \u201Cmoving to a domain means code changes\u201D."),
  caption("Table 5-1: Change list \u2014 preview address vs production domain"),
  tbl(
    ["Item", "Changes?", "What to do"],
    [
      ["Application source code", { t: "NO", bold: true }, "Nothing. Relative API paths work on any domain."],
      ["Database location", "Yes \u2014 configuration", "Set DATABASE_URL in .env to a persistent path on the server; run prisma db push once."],
      ["HTTPS certificate", "Yes \u2014 server", "Install via Caddy/certbot; mandatory for the app and logins."],
      ["APK server address", "Yes \u2014 one line", "Set server.url in capacitor.config.json to \u3010https://your-domain.com/app\u3011 and rebuild (Chapter 3, step 3)."],
      ["allowDevOrigins (next.config.ts)", "No", "Dev-only setting; production serves same-origin and ignores it."],
      ["Download page APK check", "No", "The /download page reads /downloads/matka-bazaar-app.apk relative to the domain \u2014 automatic."],
      ["Marketing links and QR", "No", "All relative; share \u3010https://your-domain.com/download\u3011 with customers."],
      ["Session cookies (ERP)", "No", "Same-origin cookies work as-is; keep HTTPS so they are sent securely."],
    ],
    [26, 18, 56]
  ),
  h2("5.1 The Three-Point Configuration Checklist"),
  numbered("domain-steps", "Server: point the domain, enable SSL, set DATABASE_URL to the server\u2019s database path, build and start (Chapter 4)."),
  numbered("domain-steps", "Wrapper: update capacitor.config.json server.url and allowNavigation to the domain, run npx cap sync android, rebuild the signed release APK (Chapter 3)."),
  numbered("domain-steps", "Publishing: copy the new APK to public/downloads/matka-bazaar-app.apk on the server, bump APP_VERSION in the download page, redeploy (Chapter 6)."),
  body("That is the whole migration. No database migration is needed when moving hosts other than copying the existing database file to the new server if the data should be preserved; a fresh start simply runs prisma db push and seeds anew."),
  h2("5.2 Testing Before Telling Customers"),
  body("After the domain is live and the rebuilt APK is installed on a test phone, run one full customer journey on the production address: register (confirm the approval toggle behaves as chosen), log in, add points through the UPI QR with a small real payment, place a bid in an open market, declare the result from the ERP and verify the win notification and settlement, request a withdrawal and pay it out from the ERP. Only when this loop is clean on the production domain should the download link be distributed to customers."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 6 — Publishing the APK to Customers
// ════════════════════════════════════════════════════════════════════════════
const ch6 = [
  h1("6. Publishing the APK \u2014 The Download Landing Page"),
  body("The platform includes a dedicated public page for distributing the Android app at the address /download. It is linked from the marketing landing page (navbar, hero, showcase section and footer), and it is designed to be shared directly with customers: on WhatsApp, by SMS, or as a printed QR code at the shop. The page shows the app name, version, highlights, a five-step installation guide written for non-technical customers, and the download button."),
  body("The page is self-aware about the APK file. It checks for /downloads/matka-bazaar-app.apk on the server as soon as it opens: if the file is present, the green download button serves it directly; if it is absent, the button is replaced by a friendly \u201Capp package not published yet\u201D notice with a recheck button \u2014 so the page can be shared before the first build is uploaded without showing broken links. Publishing a build is therefore exactly two actions on the server:"),
  numbered("pub-steps", "Copy the signed app-release.apk to the project\u2019s public/downloads/ folder under the exact name matka-bazaar-app.apk and redeploy (or, on the server, drop it into the matching public folder and restart)."),
  numbered("pub-steps", "Open src/app/download/page.tsx and set APP_VERSION to the released version so customers see \u201Cv1.0.1\u201D etc. on the page."),
  h2("6.1 Sharing the Link"),
  body("Customers need one URL: \u3010https://your-domain.com/download\u3011. For print media, generate a QR code with any standard QR generator pointed at that URL \u2014 the code is stable for the life of the domain, because the page itself handles every future APK change. When a customer already has the app installed and a new build is published, they simply download the new APK from the same page and install it over the old one; accounts, wallets and settings are untouched because all of that lives on the server."),
  h2("6.2 Version Discipline"),
  body("Keep the version on the download page in sync with the build. Increment the Android versionCode in android/app/build.gradle for each new release build (Android treats a higher versionCode as an upgrade and installs it without uninstalling), bump APP_VERSION on the page, and note the change in one line to the operator. If a distribution becomes doubtful (an APK shared outside the operator\u2019s control), the server address inside it can be pointed elsewhere in a rebuild \u2014 customers cannot be harmed by stale APKs because every sensitive action is authorised server-side."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 7 — Operations and Troubleshooting
// ════════════════════════════════════════════════════════════════════════════
const ch7 = [
  h1("7. Operations and Troubleshooting"),
  h2("7.1 Regular Routines"),
  bullet("Daily: the SQLite database file is backed up automatically by the server\u2019s backup job; verify the backup timestamp once a week."),
  bullet("Weekly: check that the ERP dashboard loads, results declared reach a test device, and the download page serves the current APK version."),
  bullet("On every release: rebuild only if Chapter 3, step 8 applies; otherwise deploy the site and let the wrapper pick up changes."),
  h2("7.2 Customer-Side Symptoms"),
  caption("Table 7-1: Symptoms, causes and fixes"),
  tbl(
    ["Symptom in the app", "Most likely cause", "Fix"],
    [
      ["\u201CCannot reach the server\u201D on open", "Server down, domain expired, or DNS not propagated", "Check the site in a phone browser; if the site is down, restart the app process on the server; if DNS, wait or fix the A record."],
      ["White screen after login", "HTTPS certificate invalid or expired", "Renew the certificate (certbot renew / Caddy automatic); the wrapper refuses insecure connections by design."],
      ["\u201CAwaiting approval\u201D at registration", "Signup-approval toggle is ON (default)", "Approve from ERP Customer List, or turn the toggle off if instant access is wanted."],
      ["\u201CAlready registered\u201D at signup", "Mobile number exists from an earlier attempt", "Log in instead; if the password is forgotten, the operator resets it from the Customer List."],
      ["App shows old rates or games", "WebView cached an old screen", "Close the app fully and reopen; the server version is always authoritative on next load."],
      ["Customer changed phone", "New device, old session token", "Simply log in again on the new device; block the old session from the ERP if needed."],
    ],
    [30, 30, 40]
  ),
  h2("7.2.1 The Signup-Approval Toggle in Daily Use"),
  body("The toggle lives in the ERP Customer List header, next to the search box, and is operated by the Super (Master) Admin. ON means every new app registration lands in the pending list on that same page for a manual approve or reject \u2014 the recommended setting while the business is small and every customer is known personally. OFF means a customer who registers gets a working session immediately, with the account created as approved and marked \u201Cauto \u2014 approval toggle off\u201D in the record for audit. The setting affects new registrations only: customers already waiting stay pending and can be approved at any time, and blocking or rejecting remains available per customer regardless of the toggle."),
  h2("7.3 Escalation Path"),
  body("If a problem cannot be resolved from Table 7-1, collect four pieces of information before escalating: the exact time of the failure, the customer\u2019s mobile number, the market and action attempted, and a screenshot of the app screen. With the timestamp and mobile number, the ERP\u2019s audit trail and activity log identify the exact server response, which turns most reports into a one-minute diagnosis."),
];

// ════════════════════════════════════════════════════════════════════════════
// CHAPTER 8 — Go-Live Checklist
// ════════════════════════════════════════════════════════════════════════════
const ch8 = [
  h1("8. Go-Live Checklist"),
  body("Work through this list in order. Every line is a yes/no; the move to customers happens only when every line is yes."),
  caption("Table 8-1: The complete go-live checklist"),
  tbl(
    ["#", "Check", "Where"],
    [
      ["1", "Domain resolves to the server and opens the landing page over HTTPS", "\u3010https://your-domain.com\u3011"],
      ["2", "ERP login works; seeded demo passwords changed", "/merp"],
      ["3", "Markets, rates and UPI QR configured with real values", "ERP \u2014 Markets, Payments"],
      ["4", "Signup-approval toggle set to the intended mode", "ERP \u2014 Customer List header"],
      ["5", "Full test journey on the production domain is clean (register, deposit, bid, declare, withdraw)", "ERP + customer app"],
      ["6", "APK built with the production domain in capacitor.config.json; signed release build", "Chapter 3, steps 3 and 7"],
      ["7", "app-release.apk published as public/downloads/matka-bazaar-app.apk", "Server"],
      ["8", "APP_VERSION on the download page matches the build", "src/app/download/page.tsx"],
      ["9", "Download page opens the green download button and the APK installs on a clean phone", "\u3010https://your-domain.com/download\u3011"],
      ["10", "Daily database backup confirmed running", "Server"],
    ],
    [8, 62, 30]
  ),
  body("When the list is complete, distribute \u3010https://your-domain.com/download\u3011 to customers. From that moment the operating rhythm is simple: run the business in the ERP, deploy changes to the site when needed, and rebuild the APK only when its shell \u2014 not its content \u2014 changes."),
];

// ════════════════════════════════════════════════════════════════════════════
// APPENDICES
// ════════════════════════════════════════════════════════════════════════════
const appendices = [
  h1("Appendix A: Command Reference"),
  caption("Table A-1: Every command used in this guide, in order"),
  tbl(
    ["Purpose", "Command(s)"],
    [
      ["Initialise the wrapper", { t: "npm init -y \u00B7 npm install @capacitor/core @capacitor/cli @capacitor/android \u00B7 npx cap init \"Matka Bazaar\" \"com.classinfotech.matkabazaar\" --web-dir=www", mono: true }],
      ["App icon and splash", { t: "npm install @capacitor/assets --save-dev \u00B7 npx capacitor-assets generate --android", mono: true }],
      ["Native project", { t: "npx cap add android \u00B7 npx cap sync android", mono: true }],
      ["Test build", { t: "cd android && ./gradlew assembleDebug", mono: true }],
      ["Signing keystore (once)", { t: "keytool -genkey -v -keystore matka-bazaar.keystore -alias matkabazaar -keyalg RSA -keysize 2048 -validity 10000", mono: true }],
      ["Release build", { t: "./gradlew assembleRelease", mono: true }],
      ["Server deployment", { t: "npm install \u00B7 npx prisma generate \u00B7 npx prisma db push \u00B7 npm run build \u00B7 pm2 start npm --name erp -- start", mono: true }],
      ["After any wrapper config change", { t: "npx cap sync android  (then rebuild)", mono: true }],
    ],
    [30, 70]
  ),
  h1("Appendix B: File and Configuration Reference"),
  caption("Table B-1: Where every artefact lives"),
  tbl(
    ["Artefact", "Location", "Notes"],
    [
      ["Wrapper configuration", { t: "matka-app-wrapper/capacitor.config.json", mono: true }, "server.url and allowNavigation \u2014 the only per-domain APK setting"],
      ["Signing keystore", { t: "matka-bazaar.keystore", mono: true }, "Operator-owned; keep two safe copies; required for every release build"],
      ["Release APK output", { t: "android/app/build/outputs/apk/release/app-release.apk", mono: true }, "The file customers install"],
      ["Published APK", { t: "public/downloads/matka-bazaar-app.apk", mono: true }, "Exact name; the download page checks for it"],
      ["Download landing page", { t: "src/app/download/page.tsx", mono: true }, "Public route /download; APP_VERSION constant at the top"],
      ["Marketing landing page", { t: "src/app/page.tsx", mono: true }, "Links to /download from navbar, hero, showcase and footer"],
      ["Signup-approval toggle", { t: "ERP \u2192 Customer List", mono: true }, "Super Admin switch; stored as AppConfig key signup_approval_required"],
      ["Database", { t: "custom.db (path from .env DATABASE_URL)", mono: true }, "Single SQLite file; the only thing to back up"],
      ["Dev-only origins setting", { t: "next.config.ts \u2192 allowedDevOrigins", mono: true }, "Ignored in production; do not mistake for a deployment requirement"],
    ],
    [26, 40, 34]
  ),
  body("Final note: every value shown as \u3010placeholder\u3011 in this guide \u2014 the domain, the app identifier, the keystore passwords, the version \u2014 is operator-specific and must be filled in during the relevant step. The platform code itself needs no edits anywhere in this process, and the voice input module of the ERP remains untouched by all of the above."),
];

// ════════════════════════════════════════════════════════════════════════════
// ASSEMBLY — 3 sections (cover / front matter Roman / body Arabic)
// ════════════════════════════════════════════════════════════════════════════
const numberingConfig = ["host-steps", "domain-steps", "pub-steps"].map(ref => ({
  reference: ref,
  levels: [{
    level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 } } },
  }],
}));

const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: FONTS, size: 24, color: P.body },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FONTS, size: 32, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 360, after: 180, line: 380 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FONTS, size: 30, bold: true, color: P.headingColor },
        paragraph: { spacing: { before: 260, after: 130, line: 360 }, outlineLevel: 1 },
      },
    },
  },
  numbering: { config: numberingConfig },
  sections: [
    { // Section 1: Cover — margin 0, no footer/header
      properties: {
        page: { size: { width: 11906, height: 16838 }, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1({
        title: "Customer App \u2014 Android APK & Hosting Guide",
        subtitle: "Building, signing and publishing the customer Android app, hosting the ERP on your own domain, and exactly what changes in the move",
        englishLabel: "DEPLOYMENT GUIDE",
        metaLines: [
          "Product: Matka Bazaar customer app + Matka Card ERP",
          "Covers: APK build (Capacitor), domain hosting, HTTPS, go-live checklist",
          "Includes: download landing page (/download) publication flow",
          "Prepared for: operator and deployment technician",
          "Date: 2 October 2026",
        ],
        footerLeft: "Master-Sanpag ERP \u00B7 Class Infotech",
        footerRight: "Android APK & Hosting",
        palette: { bg: P.bg, accent: P.accent, ...P.cover },
      }),
    },
    { // Section 2: Front matter — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN },
        },
      },
      headers: { default: pageHeader() },
      footers: { default: pageNumFooter() },
      children: frontMatter,
    },
    { // Section 3: Body — Arabic from 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: { default: pageHeader() },
      footers: { default: pageNumFooter() },
      children: [...ch1, ...ch2, ...ch3, ...ch4, ...ch5, ...ch6, ...ch7, ...ch8, ...appendices],
    },
  ],
});

const OUT = "/home/z/my-project/download/Customer_App_Android_APK_and_Hosting_Guide.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("WROTE", OUT, buf.length, "bytes");
});
