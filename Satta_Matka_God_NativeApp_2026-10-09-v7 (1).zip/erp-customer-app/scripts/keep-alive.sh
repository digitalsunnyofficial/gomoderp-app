#!/bin/bash
# Self-restarting server — keeps running even if bash session ends
cd /home/z/my-project
while true; do
  echo "$(date): Starting server..." >> /home/z/my-project/server-loop.log
  node .next/standalone/server.js -p 3000 >> /home/z/my-project/server-loop.log 2>&1
  echo "$(date): Server exited, restarting in 2s..." >> /home/z/my-project/server-loop.log
  sleep 2
done
