#!/usr/bin/env python3
"""Post-processor: replaces #LBM# placeholders with the real bracket-m
sequence that the tool transport strips from Write/Edit payloads.
Usage: python3 scripts/fixup.py file1 [file2 ...]
"""
import sys

BM = chr(91) + 'm'  # '[' + 'm'

def main():
    for path in sys.argv[1:]:
        try:
            with open(path, encoding='utf-8') as f:
                s = f.read()
        except FileNotFoundError:
            print('MISSING', path)
            continue
        if '#LBM#' in s:
            s = s.replace('#LBM#', BM)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(s)
            print('FIXED', path)
        else:
            print('clean', path)

if __name__ == '__main__':
    main()
