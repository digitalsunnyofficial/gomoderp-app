import { db } from '../src/lib/db'
const bcrypt = await import('bcryptjs')
// temp registered customer
const c = await db.appCustomer.create({
  data: { name: 'Ramesh Field', mobile: '9812345678', password: await bcrypt.hash('x1234567', 8), approvalStatus: 'approved' },
})
console.log('created customer', c.id)
process.exit(0)
