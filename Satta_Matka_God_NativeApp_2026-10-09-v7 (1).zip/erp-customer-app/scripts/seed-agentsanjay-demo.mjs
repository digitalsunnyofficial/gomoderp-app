// seed-agentsanjay-demo.mjs — demo data for the agent play-commission rule.
//
// Creates 3 customers under agent "agentsanjay" through the PRODUCTION
// flows only (app signup with agent code → fund request → super approval
// → bets through the app bet API), so every ledger row is exactly what
// the live system would write.
//
// Money script (operator's example, reproduced on customer 1):
//   deposit 4000 → play 2000 (commission) → +10000 "win" refill
//   → play 8000 (commission again)
// NOTE: the win is filed as a manual admin top-up (admin_credit) instead
// of declaring a real market result — declaring a result would settle
// every pending bet on that market, including live customers' bets.
//
// Run: node scripts/seed-agentsanjay-demo.mjs   (server on :3000)
const BASE = 'http://localhost:3000'
const AGENT_REFERRAL = 'agentsanjay'
// NOTE (operator rule 2026-10): the global commission rate is NOT set here —
// the built-in default 2% applies until the admin sets their own percentage
// in ERP ▸ App Wallet ▸ Agent Commission ▸ Commission Settings.

import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

async function j(method, path, body, headers = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  })
  const text = await res.text()
  let data
  try { data = JSON.parse(text) } catch { data = text.slice(0, 300) }
  return { status: res.status, data, headers: res.headers }
}

async function main() {
  // 1) ERP super login
  const login = await j('POST', '/api/auth', { username: 'superadmin@mb.com', password: 'SAdmin@123_321' })
  const setCookie = login.headers.getSetCookie?.() || []
  const cookie = setCookie.map(c => c.split(';')[0]).join('; ')
  if (!cookie) { console.log('ERP login failed:', login.status, login.data); process.exit(1) }
  console.log('ERP super login: ok')

  // 2) Global play-commission rate — deliberately LEFT UNSET so the demo
  //    shows the built-in default 2% (set your own via Commission Settings;
  //    the API call is: PUT /api/app-admin/commissions {action:'set_global_rate', rate:N}).
  console.log('global play-commission rate: left UNSET → built-in default 2% applies')

  // 3) The three customers
  const plan = [
    { name: 'Rakesh Sharma', mobile: '9876500001', password: 'Demo@123', deposits: [4000], plays: [2000, 8000], winRefill: 10000 },
    { name: 'Dinesh Joshi',  mobile: '9876500002', password: 'Demo@123', deposits: [5000], plays: [1000, 500], winRefill: 0 },
    { name: 'Mahesh Verma',  mobile: '9876500003', password: 'Demo@123', deposits: [6000], plays: [1500, 1000], winRefill: 0 },
  ]

  // Bettable target right now (managed starline first, then main markets) —
  // read straight from the DB (same windows the bet API validates against)
  async function pickBettable() {
    const now = new Date()
    const ist = (now.getUTCHours() * 60 + now.getUTCMinutes() + 330) % 1440
    const sls = await db.appStarline.findMany({ where: { isOn: true, isActive: true } })
    for (const sl of sls) {
      if (ist < sl.hour * 60 + (sl.minute || 0) - (sl.betClosingMinutes || 0)) {
        return { marketCode: sl.code, slot: 'open', type: 'single', num: '5' }
      }
    }
    const markets = await db.appMarket.findMany({ where: { isActive: true } })
    for (const m of markets) {
      const [oh, om] = String(m.openTime).split(':').map(Number)
      const [ch, cm] = String(m.closeTime).split(':').map(Number)
      const openM = oh * 60 + om
      const closeM = ch * 60 + cm - (m.betClosingMinutes || 10)
      if (ist >= openM && ist < closeM) {
        return { marketCode: m.code, slot: m.session === 'close' ? 'close' : 'open', type: 'single', num: '5' }
      }
    }
    return null
  }
  const betItem = await pickBettable()
  if (!betItem) { console.log('No bettable window right now — deposits done, plays skipped. Re-run later to add plays.'); }
  console.log('bet target:', betItem ? `${betItem.marketCode} (${betItem.slot})` : 'none')

  let n = 0
  for (const c of plan) {
    n++
    // 3a) signup (idempotent: skip if mobile already registered)
    let token
    const su = await j('POST', '/api/customer-app/auth/signup',
      { name: c.name, mobile: c.mobile, password: c.password, referral: AGENT_REFERRAL })
    if (su.status === 200 && su.data.token) {
      token = su.data.token
      console.log(`✓ ${c.name} signed up (referral ${AGENT_REFERRAL}) — filed under agent`)
    } else if (su.status === 409) {
      const li = await j('POST', '/api/customer-app/auth/login', { mobile: c.mobile, password: c.password })
      token = li.data.token
      console.log(`• ${c.name} already registered — logged in`)
    } else {
      console.log(`✗ signup failed for ${c.name}:`, su.status, JSON.stringify(su.data)); continue
    }
    const auth = { Authorization: 'Bearer ' + token }

    // 3b) deposits → fund request (customer) → approval (super) — production flow
    let wallet = 0
    for (const amount of c.deposits) {
      const fr = await j('POST', '/api/customer-app/funds',
        { amount, method: 'UPI', utr: 'DEMO' + c.mobile.slice(-4) + String(amount) + String(Date.now()).slice(-5) }, auth)
      const fundId = fr.data && (fr.data.fund?.id || fr.data.id || fr.data.requestId)
      if (fr.status !== 200 || !fundId) { console.log(`  ✗ fund request failed:`, fr.status, JSON.stringify(fr.data)); continue }
      const ap = await j('POST', '/api/app-admin/funds', { id: fundId, action: 'approve' }, { cookie })
      if (ap.status === 200) { wallet += amount; console.log(`  ✓ deposit ₹${amount} approved (production flow)`) }
      else console.log(`  ✗ fund approval failed:`, ap.status, JSON.stringify(ap.data))
    }

    // 3c) win refill for customer 1 — manual admin top-up (labeled), NOT a declared result
    if (c.winRefill > 0) {
      const me = await j('GET', '/api/customer-app/me', undefined, auth)
      const custId = me.data && me.data.customer && me.data.customer.id
      if (custId) {
        const tp = await j('POST', '/api/app-admin/customers',
          { id: custId, amount: c.winRefill, remark: 'Demo: win payout credited manually (no result declared)' }, { cookie })
        if (tp.status === 200) { wallet += c.winRefill; console.log(`  ✓ win refill ₹${c.winRefill} credited (admin top-up)`) }
        else console.log(`  ✗ top-up failed:`, tp.status, JSON.stringify(tp.data))
      }
    }

    // 3d) plays — every play files the agent's commission automatically
    for (const points of c.plays) {
      if (!betItem) break
      const item = { ...betItem, points, clientRequestId: 'demo-' + c.mobile + '-' + points + '-' + (++n) }
      const r = await j('POST', '/api/customer-app/bets', { items: [item] }, auth)
      if (r.status === 200) {
        wallet -= points
        console.log(`  ✓ played ₹${points} → commission filed: ${r.data.commissionFiled ?? '?'} row(s), wallet ₹${r.data.wallet}`)
      } else {
        console.log(`  ✗ play ₹${points} failed:`, r.status, JSON.stringify(r.data).slice(0, 160))
      }
    }
    console.log(`  ─ ${c.name} wallet now ≈ ₹${wallet}`)
  }

  // 4) Verify: commissions report as super (what master admin sees)
  const rep = await j('GET', '/api/app-admin/commissions', undefined, { cookie })
  if (rep.status !== 200) { console.log('report GET failed', rep.status, rep.data); return }
  const d = rep.data
  const roll = (d.agentRollup || []).find(r => r.agentUsername === AGENT_REFERRAL)
  console.log('\n──────── MASTER ADMIN VIEW ────────')
  console.log('global rate:', d.globalRate + '%')
  if (roll) {
    console.log(`@${AGENT_REFERRAL}: commission ₹${roll.totalCommission} on ₹${roll.totalPlayed} played (${roll.count} rows)`)
  } else {
    console.log(`@${AGENT_REFERRAL}: no commission rows yet`)
  }
  const mine = (d.customerRollup || []).filter(r => r.agentUsername === AGENT_REFERRAL)
  for (const r of mine) {
    console.log(`  • ${r.customerName} (${r.customerMobile}) — wallet ₹${r.wallet}, played ₹${r.played}, commission ₹${r.commission} (${r.count} plays)`)
  }
  const ledger = (d.commissions || []).filter(r => r.agentUsername === AGENT_REFERRAL)
  console.log('ledger rows:')
  for (const r of ledger) {
    console.log(`  · ${new Date(r.createdAt).toLocaleString('en-IN')} | ${r.customerName} | ${r.detail} | played ₹${r.baseAmount} @ ${r.rate}% → ₹${r.amount} [${r.status}]`)
  }
  console.log('\nNOTE: customer app logins → ' + plan.map(p => p.mobile + ' / ' + p.password).join(', '))
}

main().catch(e => { console.error('FATAL', e); process.exit(1) }).finally(() => db.$disconnect())
