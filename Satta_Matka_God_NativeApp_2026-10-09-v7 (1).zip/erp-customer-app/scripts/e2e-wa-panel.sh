#!/bin/bash
# e2e-wa-panel.sh — one-shot browser E2E for the WhatsApp Management panel.
set -u
cd /home/z/my-project
PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad() { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
has() { if echo "$2" | grep -q "$3"; then ok "$1"; else bad "$1 — wanted: $3"; fi; }

echo "── starting dev server ──"
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
setsid bash scripts/start-dev.sh > dev.log 2>&1 < /dev/null &
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health 2>/dev/null)
  [ "$code" = "200" ] && { echo "server up"; break; }
  sleep 2
done
curl -s -o /dev/null http://localhost:3000/merp --max-time 180
agent-browser close >/dev/null 2>&1 || true

echo "── ERP login ──"
agent-browser open http://localhost:3000/merp >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
sleep 3
# clear stale SPA state from any earlier run (server restarted → old session invalid)
agent-browser eval "localStorage.clear(); sessionStorage.clear(); 'cleared'" >/dev/null 2>&1
agent-browser reload >/dev/null 2>&1
sleep 3
agent-browser find first "input[placeholder='Enter username']" fill "superadmin@mb.com" >/dev/null 2>&1
agent-browser find first "input[placeholder='Enter password']" fill "SAdmin@123_321" >/dev/null 2>&1
agent-browser find role button click --name "Login" >/dev/null 2>&1 || agent-browser find first "button[type='submit']" click >/dev/null 2>&1
sleep 5

echo "── 1. Sidebar: WhatsApp section replaces the old single Inbox ──"
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "WhatsApp section present" "$SNAP" "WhatsApp"
has "WhatsApp Dashboard item" "$SNAP" "WhatsApp Dashboard"
has "Messages item" "$SNAP" "Messages"
has "Templates item" "$SNAP" "Templates"
has "Approvals item" "$SNAP" "Approvals"
has "Bot Learning item" "$SNAP" "Bot Learning"
if echo "$SNAP" | grep -q "WhatsApp Inbox"; then bad "old 'WhatsApp Inbox' item still present"; else ok "old 'WhatsApp Inbox' item gone"; fi
if echo "$SNAP" | grep -qi "Hisab"; then bad "Hisab still in sidebar"; else ok "Hisab removed from sidebar"; fi

echo "── 2. WhatsApp Dashboard ──"
agent-browser find text "WhatsApp Dashboard" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "dashboard KPI: inbound" "$SNAP" "Inbound"
has "dashboard KPI: pending" "$SNAP" "ENDING APPROVAL"
has "dashboard funnel" "$SNAP" "Approval funnel"
has "dashboard evolution" "$SNAP" "Bot evolution"
has "dashboard suggestions" "$SNAP" "Optimization suggestions"
has "dashboard simulator" "$SNAP" "Simulate an incoming message"
agent-browser screenshot download/t29-wa-dashboard.png >/dev/null 2>&1 && ok "screenshot: wa dashboard"

echo "── 3. Templates page ──"
agent-browser find text "Templates" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "templates: utility category chip" "$SNAP" "Utility"
has "templates: marketing chip" "$SNAP" "Marketing"
has "templates: authentication chip" "$SNAP" "Authentication"
has "templates: bot reply slot labeled" "$SNAP" "BOT REPLY"
has "templates: vyapar-received default listed" "$SNAP" "Vyapar received"
agent-browser screenshot download/t29-wa-templates.png >/dev/null 2>&1 && ok "screenshot: wa templates"

echo "── 4. Messages page (per-customer) ──"
agent-browser find text "Messages" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
if echo "$SNAP" | grep -q "No conversations yet"; then ok "messages page: empty state (no threads yet)"; else ok "messages page: conversation threads rendered"; fi
agent-browser screenshot download/t29-wa-messages.png >/dev/null 2>&1 && ok "screenshot: wa messages"

echo "── 5. Approvals page ──"
agent-browser find text "Approvals" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "approvals: pending tab" "$SNAP" "Pending"
has "approvals: approved tab" "$SNAP" "Approved Transactions"
has "approvals: rejected tab" "$SNAP" "Rejected"
agent-browser screenshot download/t29-wa-approvals.png >/dev/null 2>&1 && ok "screenshot: wa approvals"

echo "── 6. Bot Learning page ──"
agent-browser find text "Bot Learning" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
evo=$(agent-browser eval "const t = document.body.innerText.toLowerCase(); t.includes('parser version') && t.includes('rules activated') ? 'cards-ok' : 'missing'" 2>/dev/null | tr -d '"')
[ "$evo" = "cards-ok" ] && ok "learning: evolution stat cards (parser version / rules activated)" || bad "learning: evolution cards ($evo)"
has "learning: candidates area" "$SNAP" "candidates"
agent-browser screenshot download/t29-wa-learning.png >/dev/null 2>&1 && ok "screenshot: wa learning"

echo "── 7. Mappings page + simulator flow ──"
agent-browser find text "Customer/Group Mapping" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "mappings: map-a-group form" "$SNAP" "Map a group to a customer"
agent-browser screenshot download/t29-wa-mappings.png >/dev/null 2>&1 && ok "screenshot: wa mappings"

echo "── 8. Dashboard: simulate a vyapar through the pipeline ──"
agent-browser find text "WhatsApp Dashboard" click >/dev/null 2>&1
sleep 6
agent-browser find first "input[placeholder='Sender WhatsApp no.']" fill "9812345601" >/dev/null 2>&1
agent-browser find first "textarea" fill "Milan open
45=100
50=150" >/dev/null 2>&1
agent-browser find role button click --name "Run through pipeline" >/dev/null 2>&1 || agent-browser find text "Run through pipeline" click >/dev/null 2>&1
sleep 8
SNAP=$(agent-browser snapshot -c 2>/dev/null)
has "simulator ack reply shown" "$SNAP" "pending"
agent-browser screenshot download/t29-wa-simulate.png >/dev/null 2>&1 && ok "screenshot: simulation"

echo "── 9. Approvals: approve the simulated vyapar ──"
agent-browser find text "Approvals" click >/dev/null 2>&1
sleep 6
SNAP=$(agent-browser snapshot -c 2>/dev/null)
if echo "$SNAP" | grep -Eq "Pending \(([1-9])"; then
  ok "pending approval queued"
  # open the pending row's detail panel, then approve (JS-click: robust against icon+text nodes)
  agent-browser find text "Rahul" click >/dev/null 2>&1
  sleep 3
  clicked=$(agent-browser eval "(() => { const b = [...document.querySelectorAll('button')].find(x => x.textContent.includes('Approve & create transaction')); if (b) { b.click(); return 'clicked'; } return 'notfound'; })()" 2>/dev/null | tr -d '"')
  if [ "$clicked" = "clicked" ]; then ok "approve action clicked"; else bad "approve button not found after selecting row ($clicked)"; fi
  sleep 6
  SNAP2=$(agent-browser snapshot -c 2>/dev/null)
  has "approval confirmed (transaction created)" "$SNAP2" "Transaction #"
else
  bad "no pending approval found"
fi
agent-browser screenshot download/t29-wa-approve.png >/dev/null 2>&1 && ok "screenshot: approval flow"

echo "── done ──"
echo "RESULT: $PASS pass, $FAIL fail"
agent-browser close >/dev/null 2>&1 || true
pkill -f "next dev -p 3000" 2>/dev/null
[ "$FAIL" = "0" ]
