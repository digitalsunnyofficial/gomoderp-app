#!/bin/bash
# Verify canonical routes: /merp (ERP) = 200, /app (customer app) = 200, / (landing) = 200
set -uo pipefail
cd /home/z/my-project
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP after ~$((i*2))s"; break; fi
done
[ "$UP" != "1" ] && { echo "FATAL: no server"; tail -20 /tmp/devserver.log; exit 1; }

for path in /merp /app / /download; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:3000$path" --max-time 180)
  echo "ROUTE $path → $code"
done
pkill -f "next dev -p 3000" 2>/dev/null
echo "════ ROUTES DONE ════"
