#!/bin/bash
# build-native-zip.sh — Task 31 deliverable:
#   backend (with push layer) + satta-matka-god-native (Expo app) + guides.
set -euo pipefail

PROJ=/home/z/my-project
STAGE="$PROJ/zipstage-native"
APPDIR="$STAGE/erp-customer-app"
NATDIR="$STAGE/satta-matka-god-native"
OUT="$PROJ/download/Satta_Matka_God_NativeApp_2026-10-09-v7.zip"

rm -rf "$STAGE"; mkdir -p "$APPDIR" "$NATDIR"
cd "$PROJ"

# ── backend staging (same ship list as build-vscode-zip.sh) ──
for d in src prisma db public scripts examples; do cp -r "$d" "$APPDIR/"; done
for f in package.json bun.lock tsconfig.json next.config.ts tailwind.config.ts \
         postcss.config.mjs eslint.config.mjs components.json next-env.d.ts \
         Caddyfile .gitignore README.md ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md worklog.md; do
  cp "$f" "$APPDIR/"
done

cat > "$APPDIR/.env" <<'EOF'
# SQLite database — relative to the project root (resolved by src/lib/db.ts at runtime)
DATABASE_URL=file:./db/custom.db
EOF
cat > "$APPDIR/.env.example" <<'EOF'
# SQLite database (relative to project root; resolved by src/lib/db.ts)
DATABASE_URL=file:./db/custom.db

# Required in production — set strong random secrets
# SESSION_SECRET=change-me-to-a-long-random-string
# CRON_SECRET=change-me-too
# ADMIN_GATE_SECRET=rotates-the-super-admin-gate-token (/g/<token>)
# PUSH_ENABLED=false   ← kill switch for native-app push notifications
EOF

cat > "$APPDIR/SETUP_IN_VSCODE.md" <<'EOF'
# Satta Matka God — backend quick start
Full guide: ERP_CUSTOMER_APP_SYSTEM_DOCUMENTATION.md · Native app: ../SETUP_NATIVE_APP.md
```bash
npm install
npx prisma generate
npm run dev            # http://localhost:3000  (landing /  /merp ERP  /app web-customer)
```
Demo state ships in db/custom.db (agentsanjay + 3 customers, ₹280 pending commission @2%).
Includes the Task-31 push layer + Task-32 Phase-2 API surface (results months
param) for the native customer app.
EOF

# ── native app staging (source only) ──
# NOTE: files MUST be copied from $PROJ/satta-matka-god-native/ — copying a
# bare name would resolve against the project root and ship BACKEND files
# (v3 packaging bug: native package.json was the Next.js one, and App.tsx /
# app.json / index.ts / tsconfig.json / babel.config.js were dropped).
for f in package.json app.json babel.config.js tsconfig.json index.ts .gitignore \
         App.tsx SETUP_NATIVE_APP.md UPDATE_FROM_V1.md README.md; do
  [ -f "$PROJ/satta-matka-god-native/$f" ] && cp "$PROJ/satta-matka-god-native/$f" "$NATDIR/" || true
done
cp -r "$PROJ/satta-matka-god-native/src" "$NATDIR/"
cp -r "$PROJ/satta-matka-god-native/assets" "$NATDIR/"

# ── top-level guides (dup of the in-app copies for visibility) ──
cp "$PROJ/satta-matka-god-native/SETUP_NATIVE_APP.md" "$STAGE/"
cp "$PROJ/satta-matka-god-native/UPDATE_FROM_V1.md" "$STAGE/"

cat > "$STAGE/README-FIRST.txt" <<'EOF'
Satta Matka God — full stack + NATIVE customer app (v7, 2026-10-09)

  erp-customer-app/     Next.js backend + ERP + web customer app (push + Phase-2 APIs)
  satta-matka-god-native/  TRUE NATIVE Android app (Expo/React Native — no WebView)

  v7 = CRITICAL APK CONNECTIVITY FIX (2026-10-09) — replace src/lib/config.ts
       + app.json and REBUILD THE APK:
    • the app shipped with extra.apiBase = http://10.0.2.2:3000 — the ANDROID
      EMULATOR loopback. On a real phone EVERY request died before reaching
      the server → "sign in failed", no signup, no login. app.json now points
      at https://godmoderp.online (edit extra.apiBase if the domain changes)
    • config.ts: dev builds can override with
      EXPO_PUBLIC_DEV_API_BASE=http://<lan-ip>:3000 npx expo start
      release builds always use extra.apiBase
    • NOTE: the first release APK built from older sources can NEVER reach
      the production server — this rebuild is mandatory for all customers.
  v6 = ON-DEVICE BUG-FIX BUILD (2026-10-09) — fixes all 6 issues found in
       real-device testing. REPLACE THE WHOLE NATIVE FOLDER + REBUILD APK:
    • back button no longer exits the app — hardware back navigates
      (inner screens → home, signup → login); exit only from home
    • starline screen now shows the ADMIN-CREATED hourly starlines from
      the ERP (name, HH:MM, live countdown) — static "BABA STARLINE"
      placeholder removed (shows only when admin has created none)
    • triple-pana (TP) bettable again — server window fix: TP accepted
      through the WHOLE market window and settles on the close panna
    • numeric-only inputs everywhere — points/amount boxes accept digits
      only (words/letters can no longer be typed); UTR is alnum-upper
    • bottom gap fixed — toast sits above the gesture bar on every
      device (bottom: 88 + safe-area inset), starline scroll padding
      corrected (150 → 48)
    • notices & banners are now MANAGED from the ERP: ERP ▸ App Wallet ▸
      App Content (new master-admin page) edits the same AppConfig keys
      the web app + native app read — change once, both apps update

  v5 = OPERATOR RULES BUILD (2026-10-09):
    • bet-window wording now says "bets stop at the open/close time"
      (open/close times = bet cutoffs; Jodi only during the Open session)
    • automatic app notifications: result declared, winner, deposit
      approved/rejected, withdrawal paid/rejected, betting-open /
      close-session-live / closes-in-10-min reminders (60s cron, deduped)
    • ERP ▸ Starlines ▸ "Generate Hourly Slots" — one config creates the
      full day of hourly starlines (Main Star Line 09:05 AM ... 08:05 PM)
    • UPI auto-capture: app "Pay with UPI App" intent + POST /api/upi/
      auto-verify feed → wallet credited automatically (ERP ▸ Payment
      Management ▸ UPI Auto-Credit: ON + webhook secret)
    • agent commission withdrawal flow: ERP ▸ Agent Commission — agent
      files request, master pays (FIFO settles commission rows exactly)
    • panel chart rebuilt dpboss-style: weekly rows, open/close panna
      digits vertical, jodi horizontal (web + native)
    • native UI: status-bar-safe headers, gesture-bar-safe bottom nav +
      scroll padding, keyboard no longer covers inputs (resize mode +
      KeyboardAvoidingView in all sheets)

  v4 = v3 UI-PARITY BUILD + packaging fix + /customerapp download page:
    • FIXED: v3 zip shipped the BACKEND package.json inside the native
      folder and dropped App.tsx / app.json / index.ts / tsconfig.json /
      babel.config.js — the native project now zips correctly
    • NEW /customerapp route — https://your-domain/customerapp is the
      public APK download link (page + direct file)
    • landing page now carries the full customer guide with screenshots
    • NEW master-admin App Notifications panel: ERP ▸ App Wallet ▸
      App Notifications — broadcast / approved / pending / per-agent /
      single-customer messages with in-app + Expo push delivery,
      history and retract (API: /api/app-admin/notifications)

  v3 UI parity (unchanged in v4): every native screen is a faithful conversion of the
  web customer app (/app) — purple/pink gradient, white cards, gold actions,
  bottom navigation, language selector, banners, market cards, play screen
  with the full game engine, wallet, results/charts, my bids, notifications.
  The web customer app is the ONLY UI source of truth.

  What changed in v6 (exact files):
    • satta-matka-god-native/App.tsx — BackHandler hardware-back routing
    • satta-matka-god-native/src/lib/starline.ts — NEW starline helpers
    • satta-matka-god-native/src/screens/StarlineScreen.tsx — managed
      starlines from /api/customer-app/results?starline=1, countdowns
    • satta-matka-god-native/src/screens/HomeScreen.tsx — starline card
      uses managed data; marquee static-when-short
    • satta-matka-god-native/src/screens/MarketScreen.tsx — TP live
      window + lock text + sangam digit filters; padding 28 → 40
    • satta-matka-god-native/src/screens/PlayShared.tsx — digit-only
      point inputs
    • satta-matka-god-native/src/screens/Modals.tsx — digit-only amount
      inputs + UTR alnum-uppercase
    • satta-matka-god-native/src/ui.tsx — Toast bottom 96 → 88 + inset
    • erp-customer-app/src/app/api/customer-app/bets/route.ts — TP
      bettable through the whole window (settles close panna)
    • erp-customer-app/src/components/pages/AppContentPage.tsx — ERP
      editor for notice/banners (mounted as App Wallet ▸ App Content)
    • erp-customer-app/src/lib/navigation.ts / access-control.ts /
      store.ts + src/app/merp/page.tsx — App Content page wiring

  What changed in v3:
    • theme.ts/ui.tsx rebuilt from the web APP_CSS design tokens
    • all 13 screens re-skinned + web-exact modals (deposit QR, withdraw,
      confirm slip, password, market-closed, result-declared prompts)
    • bottom nav (home/starline/bids/results/profile) like the web shell
    • language ask screen + pre-login language chips (EN/HI/GU/MR)
    • full play engine ported: game allocation tabs, tiles grids, ank
      chips, sangam pickers, seed/ank-family panels, WhatsApp paste,
      live chart preview, bet slip with clientRequestId idempotency
    • engines copied verbatim from src/lib/matka (single source of truth)
    • Inter + Sora fonts, purple/pink launcher + splash assets

  SETUP_NATIVE_APP.md   how to run + build the APK (start here)
  UPDATE_FROM_V1.md     replace-list for existing installs

Backend:  cd erp-customer-app && npm install && npx prisma generate && npm run dev
Native:   cd satta-matka-god-native && npm install && npx expo install --fix
APK:      SETUP_NATIVE_APP.md §4  → publish per §5 (public/downloads/satta-matka-god.apk)
EOF

# ── zip ──
rm -f "$OUT"
cd "$STAGE"
zip -rq "$OUT" erp-customer-app satta-matka-god-native SETUP_NATIVE_APP.md UPDATE_FROM_V1.md README-FIRST.txt

# ── verify ──
unzip -tqq "$OUT" && echo "OK: zip integrity verified"
echo "files: $(unzip -l "$OUT" | tail -1)"
unzip -l "$OUT" | awk '{print $4}' | grep -v '^$' | cut -d/ -f1-2 | sort -u | head -25
ls -la "$OUT"
