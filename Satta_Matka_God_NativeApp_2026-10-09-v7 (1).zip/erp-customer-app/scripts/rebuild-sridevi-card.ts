// Recovery: rebuild the sridevi_day_open card (2026-09-26) that was
// accidentally removed by the regression test's cleanup, and drop the
// stray test card (2026-09-20). Rebuild uses AppBet rows (the source of
// truth) through the FIXED consolidated mirror — so the card comes back
// in the new one-row-per-class shape with per-customer attribution.
//
// Run: npx tsx scripts/rebuild-sridevi-card.ts
import { PrismaClient } from '@prisma/client'
import { mirrorBetsToErpInventory } from '../src/lib/matka/erp-mirror'

const db = new PrismaClient()
const MARKET = 'sridevi_day_open'
const LIVE_DATE = '2026-09-26'
const STRAY_DATE = '2026-09-20'

const range = (d: string) => ({ gte: new Date(d + 'T00:00:00.000Z'), lt: new Date(new Date(d + 'T00:00:00.000Z').getTime() + 86400000) })

async function main() {
  // 1) drop the stray test card entirely
  const code = await db.inventoryCode.findFirst({ where: { marketCode: MARKET } })
  if (code) {
    const strays = await db.inventory.findMany({ where: { inventoryCodeId: code.id, date: range(STRAY_DATE) } })
    for (const s of strays) {
      await db.tripleInventory.deleteMany({ where: { inventoryId: s.id } })
      await db.doubleSingleInventory.deleteMany({ where: { inventoryId: s.id } })
      await db.inventory.delete({ where: { id: s.id } })
    }
    console.log(`stray test cards removed: ${strays.length}`)
  }

  // 2) rebuild the live card from AppBets, grouped per customer
  const bets = await db.appBet.findMany({ where: { marketCode: MARKET, betDate: LIVE_DATE }, orderBy: { createdAt: 'asc' } })
  console.log(`appBets to re-mirror: ${bets.length}`)
  if (!bets.length) { console.log('nothing to rebuild'); return }

  const customers = await db.appCustomer.findMany()
  const cmap = new Map(customers.map(c => [c.id, c]))
  const byCust = new Map<string, typeof bets>()
  for (const b of bets) {
    const arr = byCust.get(b.customerId) || []
    arr.push(b)
    byCust.set(b.customerId, arr)
  }

  for (const [cid, list] of byCust) {
    const c = cmap.get(cid)
    const res = await mirrorBetsToErpInventory(
      list.map(b => ({ marketCode: b.marketCode, marketName: b.marketName || MARKET, betDate: b.betDate, slot: b.slot, type: b.type, num: b.num, points: b.points, gameCode: b.gameCode })),
      c?.name || 'Customer',
      c?.mobile || '',
    )
    console.log(`${c?.name}: bets=${list.length} mirror=${JSON.stringify(res)}`)
  }

  // 3) verify
  const card = await db.inventory.findFirst({
    where: { inventoryCode: { marketCode: MARKET }, date: range(LIVE_DATE) },
    include: { inventoryCode: true, tripleInventories: true, doubleSingleInventories: true },
  })
  if (!card) { console.log('ERROR: card not rebuilt'); process.exit(1) }
  const staked = bets.reduce((a, b) => a + b.points, 0)
  console.log(`\nrebuilt card: createdBy=${card.createdBy} total=${card.totalAmount} (appBets staked=${staked})`)
  for (const t of card.tripleInventories) {
    const pd = JSON.parse(t.parsedData)
    console.log(`  T[${t.type}/${pd.slot}] nums=${(pd.numbers || []).length} amt=${t.totalAmount} by=${t.createdBy} customers=${JSON.stringify(pd.customers)} byCustKeys=${Object.keys(pd.byCustomer || {}).length}`)
  }
  for (const d of card.doubleSingleInventories) {
    const pd = JSON.parse(d.parsedData)
    console.log(`  D[${d.type}/${pd.slot}] nums=${JSON.stringify(pd.numbers)} by=${d.createdBy} byCust=${JSON.stringify(pd.byCustomer)}`)
  }
  const ok = card.createdBy === 'app' && card.totalAmount === staked
  console.log(ok ? '\nREBUILD OK' : '\nREBUILD MISMATCH')
  process.exit(ok ? 0 : 1)
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
