#!/bin/bash
# One-shot: start server → run WhatsApp panel suite + whatsapp-pipeline regression + access-control → stop.
set -uo pipefail
cd /home/z/my-project
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP after ~$((i*2))s"; break; fi
done
[ "$UP" != "1" ] && { echo "FATAL: no server"; tail -20 /tmp/devserver.log; exit 1; }

# warm the ERP shell (Turbopack cold compile)
m=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/merp --max-time 180)
echo "MERP warm: $m"

echo "════ whatsapp-panel (new suite) ════"
timeout 300 bun scripts/test-whatsapp-panel.ts 2>&1 | grep -E "✗|RESULT|cleanup" | tail -8

echo "════ whatsapp-pipeline (regression 116) ════"
timeout 300 bun scripts/test-whatsapp-pipeline.ts 2>&1 | grep -E "FAIL|PASS /" | tail -3

echo "════ agent-access-control (regression 58) ════"
timeout 300 bun scripts/test-agent-access-control.ts 2>&1 | grep -E "RESULT|✗" | tail -6

pkill -f "next dev -p 3000" 2>/dev/null
echo "════ DONE ════"
