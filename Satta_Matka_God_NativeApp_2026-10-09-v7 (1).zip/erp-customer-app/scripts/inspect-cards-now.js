const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()
async function main() {
  const codes = await db.inventoryCode.findMany({ where: { marketCode: { not: null } }, include: { inventories: { orderBy: { date: 'desc' } } } })
  for (const c of codes) {
    for (const inv of c.inventories) {
      const [t, d] = await Promise.all([
        db.tripleInventory.findMany({ where: { inventoryId: inv.id } }),
        db.doubleSingleInventory.findMany({ where: { inventoryId: inv.id } }),
      ])
      console.log(`${c.code} | card ${inv.date.toISOString().slice(0,10)} | createdBy=${inv.createdBy} | total=${inv.totalAmount} | tripleRows=${t.length} dsRows=${d.length}`)
      for (const x of t) { const pd = JSON.parse(x.parsedData||'{}'); console.log(`   T[${x.type}/${pd.slot}] cnt=${(pd.numbers||[]).length} amt=${x.totalAmount} by=${x.createdBy} details=${String(x.details).slice(0,60)}`) }
      for (const x of d) { const pd = JSON.parse(x.parsedData||'{}'); console.log(`   D[${x.type}/${pd.slot}] cnt=${(pd.numbers||[]).length} amt=${x.totalAmount} by=${x.createdBy} details=${String(x.details).slice(0,60)}`) }
    }
  }
  // Vikram's bets for sridevi_day_open (what the deleted card held)
  const bets = await db.appBet.findMany({ where: { marketCode: 'sridevi_day_open' }, orderBy: { createdAt: 'asc' } })
  const byCust = {}
  for (const b of bets) { const k = `${b.betDate}|${b.customerId}`; byCust[k] = (byCust[k]||0)+1 }
  console.log('\nappBets sridevi_day_open by date|customer:', JSON.stringify(byCust))
  const custs = await db.appCustomer.findMany({ select: { id: true, name: true, mobile: true } })
  const cmap = Object.fromEntries(custs.map(c => [c.id, c]))
  for (const b of bets.slice(0, 3)) console.log(`  sample: ${b.betDate} ${cmap[b.customerId]?.name} ${b.type} ${b.num} @${b.points} slot=${b.slot}`)
  const cnts = await db.appBet.groupBy({ by: ['marketCode','betDate'], _count: { _all: true } })
  console.log('\nall appBets:', JSON.stringify(cnts.filter(c => c._count._all > 0)))
}
main().finally(() => db.$disconnect())
