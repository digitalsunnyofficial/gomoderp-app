#!/usr/bin/env python3
"""
postprocess-footers.py — WPS compatibility post-processing per docx skill toc.md:
  1. Remove empty <w:pgNumType/> from document.xml (cover section)
  2. Patch footer PAGE instrText with explicit format switches:
     - front-matter (Roman) section footer -> PAGE \\* ROMAN \\* MERGEFORMAT
     - body (Arabic) section footer        -> PAGE \\* arabic \\* MERGEFORMAT
"""
import re
import shutil
import sys
import zipfile
from pathlib import Path

docx_path = Path(sys.argv[1])
tmp = docx_path.parent / ("." + docx_path.stem + "-tmp")
if tmp.exists():
    shutil.rmtree(tmp)
tmp.mkdir()

with zipfile.ZipFile(docx_path) as z:
    z.extractall(tmp)

doc_xml = (tmp / "word" / "document.xml").read_text(encoding="utf-8")

# 1. Remove empty pgNumType (self-closing, no attributes)
doc_xml, n_removed = re.subn(r"<w:pgNumType/>", "", doc_xml)

# 2. Find sectPr blocks in order and their footer references + pgNumType fmt
sect_blocks = re.findall(r"<w:sectPr[^>]*>.*?</w:sectPr>|<w:sectPr[^>]*/>", doc_xml, re.DOTALL)
footer_fmt = {}  # footer filename -> 'roman' | 'arabic'
rels_xml = (tmp / "word" / "_rels" / "document.xml.rels").read_text(encoding="utf-8")
rid_to_target = dict(re.findall(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels_xml))

for block in sect_blocks:
    fmt = None
    m = re.search(r'<w:pgNumType[^>]*w:fmt="([^"]+)"', block)
    if m:
        fmt = "roman" if "roman" in m.group(1).lower() else "arabic"
    for rid in re.findall(r'<w:footerReference[^>]*r:id="([^"]+)"', block):
        target = rid_to_target.get(rid, "")
        fname = target.split("/")[-1]
        if fmt:
            footer_fmt[fname] = fmt

(tmp / "word" / "document.xml").write_text(doc_xml, encoding="utf-8")

# 3. Patch each footer's PAGE instrText
patched = []
for fname, fmt in footer_fmt.items():
    fpath = tmp / "word" / fname
    if not fpath.exists():
        continue
    fxml = fpath.read_text(encoding="utf-8")
    switch = "ROMAN" if fmt == "roman" else "arabic"
    new_fxml, n = re.subn(
        r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
        rf"\1 PAGE \\* {switch} \\* MERGEFORMAT \2",
        fxml,
    )
    if n:
        fpath.write_text(new_fxml, encoding="utf-8")
        patched.append(f"{fname} -> {switch} ({n} field)")

# 4. Rezip
out = docx_path.parent / docx_path.name
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in tmp.rglob("*"):
        if f.is_file():
            z.write(f, f.relative_to(tmp).as_posix())
shutil.rmtree(tmp)

print(f"pgNumType removed: {n_removed}")
print(f"footers patched: {patched}")
