#!/bin/bash
# One-shot: commission + signup-toggle regressions + demo state integrity after the panel round.
set -uo pipefail
cd /home/z/my-project
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP"; break; fi
done
[ "$UP" != "1" ] && { echo "FATAL: no server"; tail -20 /tmp/devserver.log; exit 1; }

m=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/merp --max-time 180)
echo "MERP warm: $m"

echo "════ agent-commission ════"
timeout 300 bun scripts/test-agent-commission.ts 2>&1 | grep -E "RESULT|✗" | tail -4
echo "════ signup-approval-toggle ════"
timeout 300 bun scripts/test-signup-approval-toggle.ts 2>&1 | grep -E "RESULT|✗" | tail -3

echo "════ DEMO STATE integrity ════"
bun -e '
import { PrismaClient } from "@prisma/client";
const p = new PrismaClient();
const custs = await p.appCustomer.count({ where: { agentUsername: "agentsanjay" } });
const comm = await p.agentCommission.findMany({ select: { amount: true, status: true, agentUsername: true } });
const demo = comm.filter(r => r.agentUsername === "agentsanjay");
console.log("agentsanjay customers:", custs, "| commission rows:", demo.length, "| total ₹:", demo.reduce((s,r)=>s+r.amount,0));
const wa = await p.whatsAppMessage.count();
const tpl = await p.whatsAppTemplate.count();
const testLeft = await p.user.count({ where: { username: { startsWith: "zz-wa-panel" } } });
console.log("whatsapp messages:", wa, "| templates:", tpl, "| panel-test leftovers:", testLeft);
await p.$disconnect();
'

pkill -f "next dev -p 3000" 2>/dev/null
echo "════ DONE ════"
