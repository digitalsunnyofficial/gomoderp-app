/**
 * Test for the unified entry parser — run with: bun scripts/test-entry-parser.ts
 */
import { parseUnifiedEntry } from '../src/lib/matka/entry-parser'
import { lookupTerm } from '../src/lib/matka/term-registry'
import { SP_SET } from '../src/lib/matka/chart-definitions'

let pass = 0
let fail = 0

function check(name: string, cond: boolean, detail?: string) {
  if (cond) {
    pass++
    console.log(`  ✓ ${name}`)
  } else {
    fail++
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`)
  }
}

// ─────────────────────────────────────────────
console.log('\n== Term registry ==')
check('SP lookup', lookupTerm('SP') === 'SP')
check('Single Panna lookup', lookupTerm('Single Panna') === 'SP')
check('Ank Panna lookup', lookupTerm('Ank Panna') === 'SP')
check('DP lookup', lookupTerm('DP') === 'DP')
check('jodi lookup', lookupTerm('jodi') === 'DP')
check('joti lookup', lookupTerm('Joti') === 'DP')
check('double ank lookup', lookupTerm('Double Ank') === 'DP')
check('motar lookup', lookupTerm('Motar') === 'Motor Pana')
check('cycle patti lookup', lookupTerm('Cycle Patti') === 'Motor Pana')
check('motor panna lookup', lookupTerm('MOTOR PANNA') === 'Motor Pana')
check('50 chart lookup', lookupTerm('50 Chart') === '50 Chart')
check('50 - numeric', lookupTerm('50') === '50 Chart')
check('90 abr lookup', lookupTerm('90 ABR') === '90 ABR Chart')
check('family set 8 lookup', lookupTerm('Family Set 8') === 'Family Set 8')
check('common lookup', lookupTerm('common') === 'common')
check('mix lookup', lookupTerm('MIX') === 'mix')
check('unknown → null', lookupTerm('halffix') === null)
check('noise → null', lookupTerm('rs') === null)
check('custom term wins', lookupTerm('hf', [{ term: 'hf', category: '50 Chart' }]) === '50 Chart')

// ─────────────────────────────────────────────
console.log('\n== The operator example (exact) ==')
const ex1 = `SP - 1,2,5,6,7 = 100 rs
DP - 12,23,47,35,18 = 50 rs
Motor -
134678 = 200rs
347890 = 100 rs`
const r1 = parseUnifiedEntry(ex1, 0)
check('singles: 5 entries', r1.singles.length === 5, JSON.stringify(r1.singles))
check('singles all @100', r1.singles.every(e => e.amount === 100))
check('singles numbers 1,2,5,6,7', r1.singles.map(e => e.number).sort().join(',') === '1,2,5,6,7')
check('doubles: 5 entries', r1.doubles.length === 5, JSON.stringify(r1.doubles))
check('doubles all @50', r1.doubles.every(e => e.amount === 50))
check('groups: 1 group (Motor Pana)', r1.groups.length === 1 && r1.groups[0].option === 'Motor Pana', JSON.stringify(r1.groups.map(g => g.option)))
const motor = r1.groups[0]
check('motor seeds: 2', motor.seeds.length === 2, JSON.stringify(motor.seeds))
// Admin-parity C(n,3): ONE canonical panna per combination (operator's own
// arithmetic: "23457890,100 / 12345678,100 → Total 11200" = C(8,3)×100×2).
// Seeds 134678 {1,3,4,6,7,8} → C(6,3)=20 @200; 347890 {3,4,7,8,9,0} → 20 @100;
// shared sets C(4,3)=4 merge @300 → 36 unique. Money preserved: 16×200 +
// 16×100 + 4×300 = 6000 = 20×200 + 20×100.
check('motor entries = 36 unique (4 merged @300)', motor.entries.length === 36, `got ${motor.entries.length}`)
check('motor @200 pannas = 16', motor.entries.filter(e => e.amount === 200).length === 16)
check('motor @100 pannas = 16', motor.entries.filter(e => e.amount === 100).length === 16)
check('motor merged @300 pannas = 4', motor.entries.filter(e => e.amount === 300).length === 4)
check('motor money preserved (6000)', motor.entries.reduce((s, e) => s + e.amount, 0) === 6000)
check('motor spellings canonical (no 6-perm dupes)', motor.entries.filter(e => e.amount === 200).every(e => SP_SET.has(e.number)), 'non-canonical spelling present')
check('no unknown labels', r1.unknownLabels.length === 0, JSON.stringify(r1.unknownLabels))
check('no skipped', r1.skipped.length === 0, JSON.stringify(r1.skipped))
check('no mix triples', r1.triples.length === 0)
check('recognized 3 labels', r1.recognizedLabels.length === 3)

// ─────────────────────────────────────────────
console.log('\n== Synonym variants route identically ==')
const ex2 = `Single Panna - 1,2,5 = 100
Jodi - 12,23 = 50
Motar Panna
134678 = 200`
const r2 = parseUnifiedEntry(ex2, 0)
check('singles 3 @100', r2.singles.length === 3 && r2.singles.every(e => e.amount === 100))
check('doubles 2 @50', r2.doubles.length === 2 && r2.doubles.every(e => e.amount === 50))
check('motor group 20 pannas @200 (C(6,3) admin parity)', r2.groups.length === 1 && r2.groups[0].option === 'Motor Pana' && r2.groups[0].entries.length === 20 && r2.groups[0].entries.every(e => e.amount === 200))

// ─────────────────────────────────────────────
console.log('\n== Unlabeled → mix; Common; group 3-digit ==')
const ex3 = `128,234,341=50
common - 111,117=25
SP - 128=100
badseed - 111=10`
const r3 = parseUnifiedEntry(ex3, 0)
check('mix triples 3', r3.triples.length === 3, JSON.stringify(r3.triples))
check('common 2 @25', r3.common.length === 2 && r3.common.every(e => e.amount === 25))
check('SP group has 128 @100', r3.groups.length === 1 && r3.groups[0].option === 'SP' && r3.groups[0].entries[0].number === '128' && r3.groups[0].entries[0].amount === 100)
check('111 held back under unknown label (not mis-filed)', r3.skipped.some(s => s.includes('111') && s.includes('held back')), JSON.stringify(r3.skipped))
check('unknown label "badseed" recorded', r3.unknownLabels.includes('badseed'), JSON.stringify(r3.unknownLabels))

// ─────────────────────────────────────────────
console.log('\n== Family set + chart + dedup ==')
const ex4 = `Family Set 8 - 123,128 = 100
50 Chart - 137 = 75
50 - 137 = 75`
const r4 = parseUnifiedEntry(ex4, 0)
const f8 = r4.groups.find(g => g.option === 'Family Set 8')
const c50 = r4.groups.find(g => g.option === '50 Chart')
check('family 8: 8 pannas @100 (dup seed deduped)', f8 && f8.entries.length === 8 && f8.entries.every(e => e.amount === 100), f8 ? JSON.stringify(f8.entries) : 'no group')
check('family dedup skipped note', r4.skipped.some(s => s.includes('duplicate of family')), JSON.stringify(r4.skipped))
check('50 chart via "50 Chart" and "50"', c50 && c50.entries.length === 1 && c50.entries[0].amount === 150, c50 ? JSON.stringify(c50.entries) : 'no group')

// ─────────────────────────────────────────────
console.log('\n== Default rate + unlabeled mixed lengths ==')
const ex5 = `5,20,342`
const r5 = parseUnifiedEntry(ex5, 25)
check('default rate applies', r5.singles.length === 1 && r5.doubles.length === 1 && r5.triples.length === 1 && r5.singles[0].amount === 25 && r5.triples[0].amount === 25)

// ─────────────────────────────────────────────
console.log('\n== Numeric label guards ==')
const ex6 = `50,60,70 = 100
60 - 290 = 25`
const r6 = parseUnifiedEntry(ex6, 0)
check('"50,60,70=100" stays doubles', r6.doubles.length === 3 && r6.doubles.every(e => e.amount === 100), JSON.stringify(r6.doubles))
const c60 = r6.groups.find(g => g.option === '60 Chart')
check('"60 - 290=25" routes to 60 Chart (290 is in chart)', c60 && c60.entries.length === 1 && c60.entries[0].number === '290' && c60.entries[0].amount === 25, JSON.stringify({ groups: r6.groups.map(g => g.option), skipped: r6.skipped }))

// ─────────────────────────────────────────────
console.log('\n== Section persistence across lines ==')
// BARE "SP -" header opens a CHART context: anks become ank seeds and expand
// to the SP chart column (12 pannas per ank — operator sample "Sp / 7=75 /
// 8 / 3=75 / Total 2700").
const ex7 = `SP -
1 = 10
2 = 20
DP - 12 = 30`
const r7 = parseUnifiedEntry(ex7, 0)
const spChart = r7.groups.find(g => g.option === 'SP')
check('bare SP header: anks expand to chart (24 pannas, sum 360)', !!spChart && spChart.entries.length === 24 && spChart.entries.reduce((s, e) => s + e.amount, 0) === 360, JSON.stringify({ groups: r7.groups.map(g => g.option), singles: r7.singles }))
check('no singles under bare chart header', r7.singles.length === 0)
check('double 12@30 (inline DP keeps double store)', r7.doubles.length === 1 && r7.doubles[0].amount === 30)
check('recognized 2 labels', r7.recognizedLabels.length === 2)

// INLINE "SP - 1 = 10" keeps the Task-2 operator-verified semantics: an
// inline label is a category TAG — the ank bet stays in the single store.
const ex7b = `SP - 1 = 10
2 = 20`
const r7b = parseUnifiedEntry(ex7b, 0)
check('inline SP label: ank stays in single store', r7b.singles.length === 2 && r7b.singles[0].amount === 10 && r7b.singles[1].amount === 20, JSON.stringify(r7b.singles))
check('inline SP label: no groups', r7b.groups.length === 0)

// ─────────────────────────────────────────────
console.log('\n== WhatsApp operator samples (2026-09-30, golden blocks) ==')
const TS = '[4:02 pm, 30/09/2026] San pag:'

// Block 1 — "All dp9" = the whole 90-DP universe (9 pannas × 10 anks) @50
const b1 = parseUnifiedEntry(`${TS} Milan\n\nAll dp9\n50rs\n\nTotal 4500`, 0)
const g90 = b1.groups.find(g => g.option === '90 DP Chart')
check('B1: 90 DP pannas @50 = 4500', !!g90 && g90.entries.length === 90 && g90.entries.reduce((s, e) => s + e.amount, 0) === 4500, JSON.stringify({ groups: b1.groups.map(g => g.option) }))
check('B1: no unknown labels (all dp9 recognized)', b1.unknownLabels.length === 0, JSON.stringify(b1.unknownLabels))
check('B1: header lines did not inject phantom bets', b1.singles.length === 0 && b1.doubles.length === 0 && b1.skipped.length === 0, JSON.stringify(b1.skipped))

// Block 2 — "Sp" header + anks: 12 SP chart pannas × 75 × 3 anks = 2700;
// the un-amounted "8" inherits the sibling rate 75
const b2 = parseUnifiedEntry(`${TS} Milan\n\nSp\n7=75\n8\n3=75\n\nTotal 2700`, 0)
const gsp = b2.groups.find(g => g.option === 'SP')
check('B2: SP chart 3 anks × 12 = 36 pannas, sum 2700', !!gsp && gsp.entries.length === 36 && gsp.entries.reduce((s, e) => s + e.amount, 0) === 2700, JSON.stringify({ groups: b2.groups.map(g => g.option) }))
check('B2: ank 8 inherited 75 (12 pannas @75)', !!gsp && gsp.entries.filter(e => e.amount === 75).length === 36)
check('B2: "Total 2700" skipped silently', b2.skipped.length === 0 && b2.unknownLabels.length === 0)

// Blocks 3+4 — bare panna lists, block rate at the END ("150rs")
const b3 = parseUnifiedEntry(`${TS} Milan\n\n128 236 245 290\n\n129 390 589 679\n\n256 346 670 689\n\n130 239 347 356\n\n140 230 690 780\n\n150rs\n\nTotal 3000`, 0)
check('B3: 20 mix triples @150 = 3000 (trailing block rate)', b3.triples.length === 20 && b3.triples.every(e => e.amount === 150) && b3.unknownLabels.length === 0 && b3.skipped.length === 0, JSON.stringify({ n: b3.triples.length, skipped: b3.skipped }))
const b4 = parseUnifiedEntry(`${TS} Milan\n\n178 367 457 790\n\n124 340 458 467\n\n125 134 170 189\n\n180 289 478 568\n\n145 235 569 578\n\n150rs\n\nTotal 3000`, 0)
check('B4: 20 mix triples @150 = 3000', b4.triples.length === 20 && b4.triples.every(e => e.amount === 150) && b4.skipped.length === 0)

// Block 5 — seed,rate comma style + C(8,3)=56 × 100 × 2 seeds = 11200
const b5 = parseUnifiedEntry(`${TS} Milan open motor\n23457890,100\n12345678,100\n\nTotal 11200`, 0)
const gm = b5.groups.find(g => g.option === 'Motor Pana')
check('B5: motor seeds both accepted', !!gm && gm.seeds.length === 2 && gm.invalid.length === 0, JSON.stringify(gm?.invalid))
check('B5: motor sum 11200 (C(8,3)=56 @100 × 2)', !!gm && gm.entries.reduce((s, e) => s + e.amount, 0) === 11200)
check('B5: no phantom rows from header/total', b5.singles.length === 0 && b5.doubles.length === 0 && b5.triples.length === 0 && b5.unknownLabels.length === 0)

// Block 6 — dp motor seed expansion n×(n-1) = 56 @40 × 2 = 4480
const b6 = parseUnifiedEntry(`${TS} Milan open dp motor\n23457890,40\n12345678,40\n\nTotal 4480`, 0)
const gdm = b6.groups.find(g => g.option === 'DP Motor')
check('B6: dp motor seeds expand (sum 4480)', !!gdm && gdm.seeds.length === 2 && gdm.entries.reduce((s, e) => s + e.amount, 0) === 4480, JSON.stringify({ groups: b6.groups.map(g => g.option), invalid: gdm?.invalid }))
check('B6: dp motor 56+56 stake rows before merge (money = 2240×2)', !!gdm && gdm.entries.length >= 56)

// ALL blocks in ONE paste (the real operator workflow)
const fullPaste = [`${TS} Milan\n\nAll dp9\n50rs\n\nTotal 4500`, `${TS} Milan\n\nSp\n7=75\n8\n3=75\n\nTotal 2700`, `${TS} Milan\n\n128 236 245 290\n\n129 390 589 679\n\n256 346 670 689\n\n130 239 347 356\n\n140 230 690 780\n\n150rs\n\nTotal 3000`, `${TS} Milan\n\n178 367 457 790\n\n124 340 458 467\n\n125 134 170 189\n\n180 289 478 568\n\n145 235 569 578\n\n150rs\n\nTotal 3000`, `${TS} Milan open motor\n23457890,100\n12345678,100\n\nTotal 11200`, `${TS} Milan open dp motor\n23457890,40\n12345678,40\n\nTotal 4480`].join('\n\n')
const rall = parseUnifiedEntry(fullPaste, 0)
const rallTotal = rall.singles.concat(rall.doubles, rall.triples, rall.common).reduce((s, e) => s + e.amount, 0) + rall.groups.reduce((s, g) => s + g.entries.reduce((x, e) => x + e.amount, 0), 0)
check('ALL 6 blocks in one paste = 28880 total', rallTotal === 4500 + 2700 + 3000 + 3000 + 11200 + 4480, `got ${rallTotal}`)
check('ALL 6: zero unknown labels, zero skipped', rall.unknownLabels.length === 0 && rall.skipped.length === 0, JSON.stringify({ unk: rall.unknownLabels, skipped: rall.skipped.slice(0, 5) }))
check('ALL 6: no phantom singles/doubles from headers', rall.singles.length === 0 && rall.doubles.length === 0)

console.log(`\n═══ RESULT: ${pass} passed, ${fail} failed ═══`)
if (fail > 0) process.exit(1)
