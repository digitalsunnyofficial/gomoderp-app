#!/bin/bash
# Keep-alive wrapper for the Next.js standalone server
cd /home/z/my-project
export DATABASE_URL="file:/home/z/my-project/db/custom.db"
export NODE_ENV=production
export PORT=3000
export HOSTNAME=0.0.0.0

MAX_RETRIES=10
RETRY_COUNT=0

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
  echo "[keep-alive] Starting server (attempt $((RETRY_COUNT+1)))..."
  node .next/standalone/server.js
  EXIT_CODE=$?
  echo "[keep-alive] Server exited with code $EXIT_CODE"
  if [ $EXIT_CODE -eq 0 ]; then
    echo "[keep-alive] Clean exit, stopping."
    break
  fi
  RETRY_COUNT=$((RETRY_COUNT+1))
  echo "[keep-alive] Waiting 3s before restart..."
  sleep 3
done

echo "[keep-alive] Max retries reached, stopping."
