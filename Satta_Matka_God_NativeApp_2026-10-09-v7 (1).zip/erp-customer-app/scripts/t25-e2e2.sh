#!/bin/bash
# t25-e2e2.sh — follow-up visual pass (top-of-page capture + empty-state text)
set -u
cd /home/z/my-project
PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad() { FAIL=$((FAIL+1)); echo "  ✗ $1"; }

setsid bash scripts/start-dev.sh > dev.log 2>&1 < /dev/null &
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health 2>/dev/null)
  [ "$code" = "200" ] && { echo "server up"; break; }
  sleep 2
done
agent-browser close >/dev/null 2>&1 || true

agent-browser open http://localhost:3000/merp >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
sleep 4
agent-browser find first "input[placeholder='Enter username']" fill "superadmin@mb.com" >/dev/null 2>&1
agent-browser find first "input[placeholder='Enter password']" fill "SAdmin@123_321" >/dev/null 2>&1
agent-browser find first "button[type='submit']" click >/dev/null 2>&1
sleep 5
agent-browser find text "Agent Commission" click >/dev/null 2>&1
sleep 3
agent-browser scrollintoview "h1" >/dev/null 2>&1
agent-browser scroll up 3000 >/dev/null 2>&1
sleep 1
agent-browser screenshot download/t25-erp-agent-commission-top.png >/dev/null 2>&1 && ok "top screenshot saved"
# full-text check of the empty state + settings labels
TXT=$(agent-browser get text "body" 2>/dev/null)
echo "$TXT" | grep -q "No commission rows" && ok "ledger empty-state renders" || bad "empty-state missing"
echo "$TXT" | grep -q "Per-agent overrides" && ok "per-agent overrides section renders" || bad "overrides section missing"
echo "$TXT" | grep -q "GLOBAL DEFAULT RATE" && ok "global rate input label renders" || bad "global rate label missing"
echo "$TXT" | grep -qi "agent override" && ok "rate precedence hint renders" || bad "hint missing"
# agent-side nav presence check: log out, log in as an agent? (covered by API scoping tests) — skip
agent-browser close >/dev/null 2>&1
echo "RESULT: $PASS pass, $FAIL fail"
pkill -9 -f "next dev" 2>/dev/null; pkill -9 -f next-server 2>/dev/null
exit $([ $FAIL -eq 0 ] && echo 0 || echo 1)
