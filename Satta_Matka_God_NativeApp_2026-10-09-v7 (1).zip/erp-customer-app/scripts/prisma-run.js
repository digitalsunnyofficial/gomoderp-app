#!/usr/bin/env node
// scripts/prisma-run.js — Prisma CLI wrapper for this project.
//
// WHY THIS EXISTS (important):
//   With SQLite, Prisma resolves a RELATIVE `file:` url relative to the
//   schema location (prisma/), while other tools may interpret it relative
//   to the CWD. To remove all ambiguity, this wrapper always passes an
//   ABSOLUTE DATABASE_URL to the prisma CLI, pointing at <project>/db/custom.db.
//
// USAGE (from package.json scripts):
//   node scripts/prisma-run.js db push
//   node scripts/prisma-run.js generate
//   node scripts/prisma-run.js migrate dev
//
// Do NOT run `npx prisma db push` directly — use the npm scripts instead.

const { spawnSync } = require('child_process')
const path = require('path')

const rootDir = path.resolve(__dirname, '..')
const args = process.argv.slice(2) // e.g. ["db", "push"]

if (args.length === 0) {
  console.error('Usage: node scripts/prisma-run.js <prisma command> [args...]')
  console.error('Examples: node scripts/prisma-run.js db push')
  process.exit(1)
}

const dbFile = path.join(rootDir, 'db', 'custom.db')
const env = {
  ...process.env,
  DATABASE_URL: 'file:' + dbFile,
}

// Make sure the db directory exists so SQLite can create the file
const fs = require('fs')
fs.mkdirSync(path.join(rootDir, 'db'), { recursive: true })

const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx'
const result = spawnSync(npx, ['prisma', ...args], {
  stdio: 'inherit',
  env,
  cwd: rootDir,
})

process.exit(result.status === null ? 1 : result.status)
