// E2E fixture: temp agent + app customer + group-mapped vendor for browser testing
import { db } from '../src/lib/db'
import bcrypt from 'bcryptjs'

const agent = await db.user.upsert({
  where: { username: 'wa-e2e-agent' },
  update: {},
  create: {
    username: 'wa-e2e-agent',
    name: 'E2E Agent',
    password: await bcrypt.hash('agentpass123', 8),
    role: 'user',
    status: 'active',
  },
})
const existing = await db.appCustomer.findUnique({ where: { mobile: '9123456790' } })
const customer = existing ?? await db.appCustomer.create({
  data: {
    name: 'E2E WhatsApp Customer',
    mobile: '9123456790',
    password: await bcrypt.hash('custpass123', 8),
    wallet: 0,
    approvalStatus: 'approved',
    referral: 'wa-e2e-agent',
    agentUsername: 'wa-e2e-agent',
    agentName: 'E2E Agent',
  },
})
console.log(JSON.stringify({ agentId: agent.id, customerId: customer.id, mobile: customer.mobile }))
process.exit(0)
