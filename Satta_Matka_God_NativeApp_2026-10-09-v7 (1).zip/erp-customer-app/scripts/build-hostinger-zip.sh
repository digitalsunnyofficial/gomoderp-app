#!/bin/bash
# build-hostinger-zip.sh — Hostinger-ready production package (r2).
# Built on top of the operator's own VS Code upload (ERP+CUSTOMER.zip):
# their real SQLite db is kept byte-identical; latest code files synced in;
# production deploy assets added; r2 = fixes for the first pipeline build
# failure (Turbopack PostCSS worker panic on auto-installed Next 16.3.8).
set -euo pipefail

PROJ=/home/z/my-project
SRC="$PROJ/zipstage-upload"            # extracted operator upload
STAGE="$PROJ/zipstage-hostinger"
OUT="$PROJ/download/Satta_Matka_God_Hostinger_Ready_2026-10-09-r2.zip"

[ -f "$PROJ/upload/ERP+CUSTOMER.zip" ] || { echo "operator upload missing"; exit 1; }
rm -rf "$SRC" "$STAGE"; mkdir -p "$SRC" "$STAGE"
unzip -q "$PROJ/upload/ERP+CUSTOMER.zip" -d "$SRC"

cp -a "$SRC/." "$STAGE/"
cd "$PROJ"

DB_MD5_BEFORE=$(md5sum "$STAGE/db/custom.db" | cut -d' ' -f1)

# ── 1. sync the one latest src file missing from the upload ──
mkdir -p "$STAGE/src/app/api/app-admin/payment-settings"
cp "$PROJ/src/app/api/app-admin/payment-settings/route.ts" \
   "$STAGE/src/app/api/app-admin/payment-settings/route.ts"

# ── 1b. production next.config.ts (adds serverExternalPackages for canvas) ──
# Their upload's config predates the chitthi canvas fix: Turbopack cannot
# bundle @napi-rs/canvas native bindings — without this the build FAILS
# ("asset is not placeable in ESM chunks"). Preview-domain dev origins dropped.
cat > "$STAGE/next.config.ts" <<'EOF'
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // @napi-rs/canvas ships platform-specific native binaries as optional deps —
  // they must be loaded by the Node resolver at runtime, not bundled by Turbopack.
  // (Without this, `next build` fails: "asset is not placeable in ESM chunks".)
  serverExternalPackages: ["@napi-rs/canvas"],
  allowedDevOrigins: ["127.0.0.1", "localhost"],
};

export default nextConfig;
EOF

# ── 1c. production package.json (r2 fixes from the first Hostinger build) ──
# The operator's first Hostinger pipeline build panicked in Turbopack's PostCSS
# worker (16.3.8 got installed from ^16.1.1; "creating new process / node
# process exited before we could connect"). Fixes:
#   • pin next to the EXACT version verified building (16.1.3)
#   • build with webpack — no Turbopack worker spawn, sandbox-proof
#   • start without a hardcoded port — respects the platform $PORT
#   • postinstall: prisma generate — managed builders never run it manually
python3 - "$STAGE/package.json" <<'PYEOF'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d["dependencies"]["next"] = "16.1.3"
d["scripts"]["build"] = "next build --webpack"
d["scripts"]["start"] = "next start"
d["scripts"]["postinstall"] = "prisma generate"
json.dump(d, open(p, "w"), indent=2)
print("package.json patched: next pinned 16.1.3, webpack build, PORT-aware start, postinstall prisma")
PYEOF

# regenerate a CONSISTENT package-lock.json for the patched package.json
# (their old lock resolved next 16.3.8; without this, npm ci would fail)
(cd "$STAGE" && npm install --package-lock-only --ignore-scripts --no-audit --no-fund >/dev/null 2>&1) \
  && echo "package-lock.json regenerated" \
  || echo "WARN: lock regen failed — deploy.sh falls back to npm install"
python3 -c "import json; d=json.load(open('$STAGE/package-lock.json')); print('locked next:', d['packages']['node_modules/next']['version'])" 2>/dev/null || true

# ── 2. top up public/ (landing-guide screenshots + chitthi assets + README) ──
cp -r "$PROJ/public/how-it-works" "$STAGE/public/how-it-works"
[ -d "$PROJ/public/chitthi" ] && cp -r "$PROJ/public/chitthi" "$STAGE/public/chitthi"
cp "$PROJ/public/downloads/README.txt" "$STAGE/public/downloads/README.txt"

# ── 3. top up scripts/ (latest dev/test scripts; keeps their identical set) ──
cp -r "$PROJ/scripts/." "$STAGE/scripts/"

# ── 4. production env with freshly generated secrets ──
SESSION_SECRET=$(openssl rand -hex 32)
CRON_SECRET=$(openssl rand -hex 24)
ADMIN_GATE_SECRET=$(openssl rand -hex 24)
cat > "$STAGE/.env.production" <<EOF
# ─────────────────────────────────────────────────────────────
# Satta Matka God — PRODUCTION environment (Hostinger VPS)
# Next.js loads this file automatically when NODE_ENV=production
# (PM2 sets it — see ecosystem.config.js).
# ─────────────────────────────────────────────────────────────

# SQLite database — relative to the project folder (resolved to an
# absolute path by src/lib/db.ts at runtime). KEEP AS IS.
DATABASE_URL=file:./db/custom.db

# Domain (inlined at build time — if you ever change the domain,
# change it here AND re-run: bash deploy.sh)
NEXT_PUBLIC_APP_URL=https://godmoderp.online
NEXT_PUBLIC_BASE_URL=https://godmoderp.online

# Session signing secret (auto-generated at package time)
SESSION_SECRET=${SESSION_SECRET}

# Protects /api/cron/markets (server-to-server)
CRON_SECRET=${CRON_SECRET}

# Super-admin gate token rotator (/g/<token>)
ADMIN_GATE_SECRET=${ADMIN_GATE_SECRET}

# Native-app push kill switch (uncomment to disable push globally)
# PUSH_ENABLED=false

# ── WhatsApp (only if you use the WhatsApp features) ──
# WHATSAPP_TOKEN=
# WHATSAPP_PHONE_NUMBER_ID=
# WHATSAPP_APP_SECRET=
# WHATSAPP_VERIFY_TOKEN=
EOF

# ── 5. PM2 process definition ──
mkdir -p "$STAGE/logs"
cat > "$STAGE/ecosystem.config.js" <<'EOF'
// PM2 process definition — Satta Matka God (production)
// Start:  pm2 start ecosystem.config.js     Stop: pm2 stop satta-matka-god
// Logs:   pm2 logs satta-matka-god          Status: pm2 status
module.exports = {
  apps: [{
    name: 'satta-matka-god',
    script: 'node_modules/next/dist/bin/next',
    args: 'start -p 3000',
    cwd: __dirname,
    instances: 1,            // MUST stay 1 — the market scheduler runs inside the app
    exec_mode: 'fork',
    autorestart: true,
    max_memory_restart: '800M',
    env: { NODE_ENV: 'production', PORT: 3000 },
    error_file: 'logs/pm2-error.log',
    out_file: 'logs/pm2-out.log',
    time: true,
  }],
};
EOF

# ── 6. Caddy reverse proxy (auto-HTTPS) ──
cat > "$STAGE/Caddyfile.hostinger" <<'EOF'
# Satta Matka God — Caddy config (auto-HTTPS via Let's Encrypt)
# Install:  cp Caddyfile.hostinger /etc/caddy/Caddyfile && systemctl reload caddy
# Requires DNS A records:  godmoderp.online -> YOUR_VPS_IP  and  www -> YOUR_VPS_IP

godmoderp.online {
	encode zstd gzip
	reverse_proxy 127.0.0.1:3000
}

www.godmoderp.online {
	redir https://godmoderp.online{uri} permanent
}
EOF

# ── 7. one-shot deploy script (runs ON the Hostinger VPS) ──
cat > "$STAGE/deploy.sh" <<'EOF'
#!/usr/bin/env bash
# Satta Matka God — Hostinger VPS deploy / update (run INSIDE the project folder)
# Usage:  bash deploy.sh
set -euo pipefail
say() { printf '\n\033[1;35m==> %s\033[0m\n' "$*"; }

say "1/6 Install dependencies"
if [ -f package-lock.json ]; then npm ci --include=dev || npm install --include=dev; else npm install; fi

say "2/6 Generate Prisma client"
npx prisma generate

say "3/6 Backup database"
mkdir -p db/backups
if [ -f db/custom.db ]; then
  B="db/backups/custom-$(date +%Y%m%d-%H%M%S).db"
  cp db/custom.db "$B"
  echo "    backup saved: $B"
fi

say "4/6 Sync database schema (ADDITIVE ONLY — your data is kept)"
npx prisma db push

say "5/6 Build production bundle (this takes a few minutes)"
npm run build

say "6/6 Start / restart with PM2"
if pm2 describe satta-matka-god >/dev/null 2>&1; then
  pm2 restart satta-matka-god --update-env
else
  pm2 start ecosystem.config.js
fi
pm2 save

say "DONE"
echo "    local check : curl http://127.0.0.1:3000/api/health   (expect 200)"
echo "    panel       : https://godmoderp.online/merp"
echo "    customer app: https://godmoderp.online/app"
echo "    apk page    : https://godmoderp.online/customerapp"
echo "    one-time    : pm2 startup   (make the app auto-start on reboot)"
EOF
chmod +x "$STAGE/deploy.sh"

# ── 8. operator deployment guide ──
cat > "$STAGE/DEPLOY_HOSTINGER.md" <<'EOF'
# Satta Matka God — Hostinger Deployment Guide

This package is **Hostinger-ready**: your code (latest build) + **your own
database, untouched** (`db/custom.db` — 11 customers, 10 markets, 182 bets,
12 starlines, all transactions). Nothing in the database was modified while
packaging. The missing table/columns the latest code expects are added
automatically by `deploy.sh` — additively, with a backup taken first.

---

## 0. What you need

| Item | Value |
|---|---|
| Hostinger plan | **VPS** (KVM 1 or better, Ubuntu 22.04 / 24.04) |
| Node.js | v20 or newer |
| Domain | `godmoderp.online` (A record → your VPS IP, plus `www`) |
| Panel login | `superadmin@mb.com` / `SAdmin@123_321` (**change after go-live**) |

Shared/premium web hosting will NOT run this app — it needs Node.js + PM2,
which the VPS plans provide.

## 1. One-time server preparation (SSH as root)

```bash
apt update && apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs
npm install -g pm2
apt install -y debian-keyring debian-archive-keyring apt-transport-https curl
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt update && apt install -y caddy
```

## 2. Upload this package

Upload the zip (SFTP/FileZilla or scp) — e.g. to `/opt/`:

```bash
scp Satta_Matka_God_Hostinger_Ready_2026-10-09-r2.zip root@YOUR_VPS_IP:/opt/
ssh root@YOUR_VPS_IP
cd /opt && unzip Satta_Matka_God_Hostinger_Ready_2026-10-09-r2.zip -d satta-matka-god
cd satta-matka-god
```

## 3. Deploy (one command)

```bash
bash deploy.sh
```

It does, in order: install deps → generate Prisma client → **backup your DB
into `db/backups/`** → additively sync the schema (creates the
`AgentCommissionWithdrawal` table + 3 payment-setting columns, keeps all
data) → production build → start under PM2.

## 4. Put Caddy in front (HTTPS + domain)

```bash
cp Caddyfile.hostinger /etc/caddy/Caddyfile
systemctl reload caddy
```

DNS (Hostinger hPanel → DNS): `A @ → VPS_IP`, `A www → VPS_IP`.
Caddy fetches the HTTPS certificate automatically.

## 5. Verify (go-live checklist)

```bash
curl http://127.0.0.1:3000/api/health        # 200
pm2 status                                    # satta-matka-god online
pm2 logs satta-matka-god --lines 20          # look for [cron] ticks
```

Then in a browser:
- `https://godmoderp.online/` — landing + guide
- `https://godmoderp.online/merp` — ERP admin panel (log in, check customers/markets/bets = your data)
- `https://godmoderp.online/app` — web customer app
- `https://godmoderp.online/customerapp` — APK download page

Finish with:
```bash
pm2 startup          # run the command it prints → app auto-starts on reboot
pm2 save
```

## 6. Android app

The native app must point at the production domain — in
`satta-matka-god-native/src/lib/config.ts` set the base URL to
`https://godmoderp.online`, then rebuild the APK
(`cd android && ./gradlew assembleRelease`, see the native package's
`SETUP_NATIVE_APP.md`) and drop the APK at
`public/downloads/satta-matka-god.apk` on the server — the
`/customerapp` page links to exactly that path.

## 7. Updating later (keeps the DB)

1. Upload the new package zip
2. Copy the new source files **over** the server folder **EXCEPT `db/`**
   (never touch `db/custom.db`) and except `.env.production` (keep your secrets)
3. `bash deploy.sh` again — it re-backs-up, re-syncs, rebuilds, restarts

## 8. House rules

- NEVER delete or hand-edit `db/custom.db` — that IS your business data
- Backups: `db/backups/` grows one file per deploy; also take a weekly copy
  off the server (download via SFTP)
- `.env.production` holds your secrets — never commit it or send it around
- Change the super-admin password after go-live (ERP ▸ admin settings)

## 9. What this package changed vs your VS Code copy

Everything else is byte-identical. Exactly these things were touched:
1. `src/app/api/app-admin/payment-settings/route.ts` — restored (was missing;
   the ERP Auto-Credit card needs it to save)
2. `next.config.ts` — added `serverExternalPackages: ["@napi-rs/canvas"]`;
   **without this the production build FAILS** (chitthi image renderer)
3. `package.json` (r2) — `next` pinned to **16.1.3** exactly (the first build
   auto-installed 16.3.8, whose Turbopack PostCSS worker panicked in
   Hostinger's sandbox), `build` uses **webpack** (`next build --webpack` —
   no spawned worker processes, builds everywhere), `start` honours the
   platform `PORT` env, and `postinstall` runs `prisma generate`
4. `package-lock.json` (r2) — regenerated to match the pinned versions
5. `public/` — added the 19 landing-guide screenshots + chitthi assets
6. NEW deployment files: `.env.production` (fresh secrets), `deploy.sh`,
   `ecosystem.config.js`, `Caddyfile.hostinger`, this guide

Your database was NOT modified — packaged byte-identical (md5-verified);
the schema catch-up happens on the server, additively, with a backup first.

## 10. Using a Hostinger platform builder (upload-archive pipeline)

If you deploy through a Hostinger build pipeline (upload zip → automatic
`npm install` → `npm run build` → start) instead of a raw VPS:

- r2 builds fine there: dependencies install from the regenerated lockfile,
  the build runs on webpack, and `npm start` listens on the platform's `$PORT`
- ⚠️ **database persistence**: the SQLite db lives INSIDE the app folder
  (`db/custom.db`). On archive-based pipelines each redeploy re-extracts the
  zip — your live data would reset to the packaged db. Before every redeploy:
  1. download the current `db/custom.db` from the running app (SFTP/file manager)
  2. drop it into the new zip (replacing `db/custom.db`)
  3. upload the new zip
  For a business that takes bets daily, the **VPS route (§1–§5) is strongly
  recommended** — the db then lives on your server permanently and survives
  every redeploy untouched.

## 11. Troubleshooting the Hostinger build

| Symptom | Fix |
|---|---|
| Turbopack panic `globals.css … node process exited before we could connect` | Already fixed in this package (`next build --webpack`). If you ever see it, your `build` script was reverted — put `--webpack` back. |
| Build killed near the end / `Killed` / `heap out of memory` | The builder ran out of RAM. Retry once; if it persists, build locally (`npm ci && npm run build`) and upload the whole folder **including `.next`** — the platform detects the prebuilt output and skips building. |
| App starts but page says wrong port / connection refused | Platform `PORT` is honoured by the start script; set the port in the hPanel Node-app settings to 3000 if asked. |
| `Cannot find module '@napi-rs/canvas'` at runtime | Run `npm install` again on the server — canvas ships platform-specific binaries and must match the server OS, not your PC. |
EOF

# ── 9. zip ──
DB_MD5_AFTER=$(md5sum "$STAGE/db/custom.db" | cut -d' ' -f1)
if [ "$DB_MD5_BEFORE" != "$DB_MD5_AFTER" ]; then echo "FATAL: db changed during staging!"; exit 1; fi
echo "db integrity: OK ($DB_MD5_AFTER)"

rm -f "$OUT"
cd "$STAGE"
zip -rq "$OUT" .
unzip -tqq "$OUT" && echo "OK: zip integrity verified"
echo "files: $(unzip -l "$OUT" | tail -1)"
ls -la "$OUT"
