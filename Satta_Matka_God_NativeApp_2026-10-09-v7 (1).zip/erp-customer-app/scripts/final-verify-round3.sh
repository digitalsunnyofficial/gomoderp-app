#!/bin/bash
# Final commission-suite re-run + corrected demo-state probe.
set -uo pipefail
cd /home/z/my-project
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
nohup bash scripts/start-dev.sh > /tmp/devserver.log 2>&1 &
UP=0
for i in $(seq 1 90); do
  sleep 2
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health --max-time 3 2>/dev/null)
  if [ "$code" = "200" ]; then UP=1; echo "SERVER UP after ~$((i*2))s"; break; fi
done
[ "$UP" != "1" ] && { echo "FATAL: no server"; tail -20 /tmp/devserver.log; exit 1; }

# warm merp
m=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/merp --max-time 180)
echo "MERP warm: $m"

echo "════ agent-commission (delta assertions) ════"
timeout 300 bun scripts/test-agent-commission.ts 2>&1 | grep -E "FAIL|✗|RESULT" | tail -5

echo "════ DEMO STATE (agentsanjay) — corrected probe ════"
bun -e '
import { PrismaClient } from "@prisma/client";
const p = new PrismaClient();
const custs = await p.appCustomer.findMany({ where: { agentUsername: "agentsanjay" }, select: { id: true, name: true, mobile: true, wallet: true, status: true } });
console.log("CUSTOMERS:", custs.length);
for (const c of custs) {
  const bets = await p.appBet.findMany({ where: { customerId: c.id }, select: { points: true } });
  const played = bets.reduce((s, b) => s + b.points, 0);
  console.log(`  ${c.name} (${c.mobile}) wallet=${c.wallet} played=${played} bets=${bets.length}`);
}
const comm = await p.agentCommission.findMany({ select: { agentUsername: true, customerName: true, baseAmount: true, amount: true, status: true, source: true } });
const agent = await p.user.findUnique({ where: { username: "agentsanjay" }, select: { commissionRate: true } });
console.log("COMMISSION_ROWS:", comm.length, "TOTAL_RS:", comm.reduce((s,r)=>s+r.amount,0), "STATES:", JSON.stringify(comm.reduce((m,r)=>{m[r.status]=(m[r.status]||0)+1;return m},{})), "AGENT_RATE_OVERRIDE:", agent?.commissionRate);
const funds = await p.appFundRequest.findMany({ select: { amount: true, status: true } });
console.log("FUND_REQUESTS:", funds.length, JSON.stringify(funds));
await p.$disconnect();
'

pkill -f "next dev -p 3000" 2>/dev/null
echo "════ DONE ════"
