#!/bin/bash
# Persistent ERP server starter — survives parent shell exit
cd /home/z/my-project

# Kill any prior instance
pkill -9 -f "node.*bootstrap\.js" 2>/dev/null
sleep 1

# Start in a new session, fully detached from this shell
setsid -f node bootstrap.js > /tmp/erp-server.log 2>&1
sleep 3

# Health check
HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/ || echo "000")
echo "Server PID: $(pgrep -f 'node.*bootstrap' | head -1)"
echo "Health: HTTP $HTTP"
