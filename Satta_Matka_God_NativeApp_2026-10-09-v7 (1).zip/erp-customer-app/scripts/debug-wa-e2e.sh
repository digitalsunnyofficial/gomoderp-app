#!/bin/bash
set -u
cd /home/z/my-project
pkill -f "next dev -p 3000" 2>/dev/null; sleep 1
setsid bash scripts/start-dev.sh > dev.log 2>&1 < /dev/null &
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health 2>/dev/null)
  [ "$code" = "200" ] && { echo "server up"; break; }
  sleep 2
done
curl -s -o /dev/null http://localhost:3000/merp --max-time 180
agent-browser close >/dev/null 2>&1 || true
agent-browser open http://localhost:3000/merp >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
sleep 3
# clear any stale session storage first
agent-browser eval "localStorage.clear(); sessionStorage.clear(); 'cleared'" 2>&1
agent-browser reload >/dev/null 2>&1
sleep 3
agent-browser find first "input[placeholder='Enter username']" fill "superadmin@mb.com" >/dev/null 2>&1
agent-browser find first "input[placeholder='Enter password']" fill "SAdmin@123_321" >/dev/null 2>&1
agent-browser find role button click --name "Login" >/dev/null 2>&1 || agent-browser find first "button[type='submit']" click >/dev/null 2>&1
sleep 5
echo "── navigate to Templates ──"
agent-browser find text "Templates" click >/dev/null 2>&1
sleep 6
echo "── console errors ──"
agent-browser errors 2>&1 | tail -15
echo "── page state ──"
agent-browser eval "document.body.innerText.slice(0, 300)" 2>&1 | head -8
agent-browser screenshot download/t29-debug-templates.png >/dev/null 2>&1
agent-browser close >/dev/null 2>&1
pkill -f "next dev -p 3000" 2>/dev/null
