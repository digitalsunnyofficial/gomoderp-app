const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

async function seed() {
  const patterns = [
    { name: 'comma_dash_value', label: 'Comma-Separated + --- + Amount', regex: '^((?:\\d{1,3},)+\\d{1,3})\\s*[\\-\\u2013\\u2014]{2,}\\s*(\\d+)\\s*$', flags: '', priority: 10, appliesTo: 'all', example: '61,81---2000', description: 'Comma-separated numbers followed by 2+ dashes and a shared value.', captureGroups: 'numbers,rate', numberSeparator: 'comma' },
    { name: 'space_dash_value', label: 'Space-Separated + --- + Amount', regex: '^((?:\\d{1,3}\\s+)+\\d{1,3})\\s*[\\-\\u2013\\u2014]{2,}\\s*(\\d+)\\s*$', flags: '', priority: 11, appliesTo: 'all', example: '61 81---2000', description: 'Space-separated numbers followed by 2+ dashes and a shared value.', captureGroups: 'numbers,rate', numberSeparator: 'space' },
    { name: 'comma_dot_amount_rs', label: 'Comma-Separated + Dot + Amount (optional rs)', regex: '^((?:\\d{1,3},)+\\d{1,3})\\s*\\.\\s*(\\d+)\\s*rs?\\s*$', flags: 'i', priority: 12, appliesTo: 'all', example: '00,02,60,67,66.1500rs', description: 'Comma-separated numbers followed by a dot, then amount with optional rs suffix.', captureGroups: 'numbers,rate', numberSeparator: 'comma' },
    { name: 'space_dot_amount_rs', label: 'Space-Separated + Dot + Amount (optional rs)', regex: '^((?:\\d{1,3}\\s+)+\\d{1,3})\\s*\\.\\s*(\\d+)\\s*rs?\\s*$', flags: 'i', priority: 13, appliesTo: 'all', example: '00 02 60 67 66.1500rs', description: 'Space-separated numbers followed by a dot, then amount with optional rs suffix.', captureGroups: 'numbers,rate', numberSeparator: 'space' },
    { name: 'single_dash_value', label: 'Number + --- + Amount', regex: '^(\\d{1,3})\\s*[\\-\\u2013\\u2014]{2,}\\s*(\\d+)\\s*$', flags: '', priority: 14, appliesTo: 'all', example: '07---2500', description: 'A single number followed by 2+ dashes and an amount.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'dot_group_equals_rs', label: 'Dot-Separated + = + Amount (optional rs)', regex: '^((?:\\d{1,3}\\.)+\\d{1,3})\\s*=\\s*(\\d+)\\s*rs?\\s*$', flags: 'i', priority: 15, appliesTo: 'all', example: '53.57.13.07=75rs', description: 'Dot-separated numbers followed by = and amount with optional rs.', captureGroups: 'numbers,rate', numberSeparator: 'dot' },
    { name: 'number_dot_amount_rs', label: 'Number + Dot + Amount (optional rs)', regex: '^(\\d{1,3})\\.\\s*(\\d+)\\s*rs?\\s*$', flags: 'i', priority: 16, appliesTo: 'all', example: '07.2500rs', description: 'A single number followed by a dot and amount with optional rs.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'paren_rate', label: '(NNN)RATE', regex: '^\\((\\d{2,3})\\)\\s*(\\d+)\\s*$', flags: '', priority: 20, appliesTo: 'all', example: '(61)25', description: 'Panna in parentheses with rate.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'bracket_dash', label: '[NN]-RATE', regex: '^\\[(\\d{2,3})\\]\\s*[\\-\\u2013]\\s*(\\d+)\\s*$', flags: '', priority: 21, appliesTo: 'all', example: '[02]-30', description: 'Double/triple in brackets with dash and rate.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'rs_rate', label: 'NN-rsRATE', regex: '^(\\d{2,3})\\s*[\\-\\u2013]\\s*rs\\s*(\\d+)\\s*$', flags: 'i', priority: 22, appliesTo: 'all', example: '42-rs20', description: 'Double/triple with dash, rs, and rate.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'pair_eq', label: 'NN*NN=RATE', regex: '^(\\d{2})\\s*[\\*\\u00d7xX]\\s*(\\d{2})\\s*=\\s*(\\d+)\\s*$', flags: '', priority: 23, appliesTo: 'double', example: '33*38=50', description: 'Two double numbers with star and equals rate.', captureGroups: 'number1,number2,rate', numberSeparator: 'none' },
    { name: 'star_eq', label: '*N=RATE', regex: '^[\\*\\u00d7xX]\\s*(\\d{1,3})\\s*=\\s*(\\d+)\\s*$', flags: '', priority: 24, appliesTo: 'all', example: '*1=20', description: 'Star prefix with equals and rate.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'equals_rate', label: 'NNN=RATE', regex: '^(\\d{2,3})\\s*=\\s*(\\d+)\\s*$', flags: '', priority: 40, appliesTo: 'all', example: '64=40', description: 'Number with equals and rate.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'dot_rate', label: 'NN.RATE (Milan)', regex: '^(\\d{2})\\.\\s*(\\d+)\\s*$', flags: '', priority: 50, appliesTo: 'double', example: '02.20', description: 'Double with single dot (Milan style).', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'triple_star', label: 'NNN*RATE', regex: '^(\\d{3})\\s*[*]\\s*(\\d+)\\s*$', flags: '', priority: 42, appliesTo: 'triple', example: '149*200', description: 'Triple with star separator.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'double_star', label: 'NN*RATE', regex: '^(\\d{2})\\s*[*]\\s*(\\d+)\\s*$', flags: '', priority: 44, appliesTo: 'double', example: '64*20', description: 'Double with star separator.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'triple_dash', label: 'NNN-RATE', regex: '^(\\d{3})\\s*[\\-\\u2013]\\s*(\\d+)\\s*$', flags: '', priority: 51, appliesTo: 'triple', example: '199-30', description: 'Triple with dash.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'double_dash', label: 'NN-RATE', regex: '^(\\d{2})\\s*[\\-\\u2013]\\s*(\\d+)\\s*$', flags: '', priority: 52, appliesTo: 'double', example: '91-20', description: 'Double with dash.', captureGroups: 'number,rate', numberSeparator: 'none' },
    { name: 'single_dash', label: 'N-RATE', regex: '^(\\d{1})\\s*[\\-\\u2013]\\s*(\\d+)\\s*$', flags: '', priority: 53, appliesTo: 'single', example: '1-250', description: 'Single with dash.', captureGroups: 'number,rate', numberSeparator: 'none' },
  ];

  let created = 0;
  let skipped = 0;
  for (const p of patterns) {
    try {
      const existing = await db.parserPattern.findUnique({ where: { name: p.name } });
      if (existing) { skipped++; continue; }
      await db.parserPattern.create({ data: { ...p, isBuiltIn: true, isActive: true, createdBy: 'system' } });
      created++;
    } catch (e) {
      console.error('Error seeding', p.name, e.message);
    }
  }
  console.log(`✅ Seeded: ${created}, Skipped: ${skipped}`);
  await db.$disconnect();
}

seed();
