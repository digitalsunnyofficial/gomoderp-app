const bcrypt = require('bcryptjs')
const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding sample data...')

  // ── Admin User (upsert) ──
  const adminHash = await bcrypt.hash('Admin@90_21#', 10)
  const admin = await prisma.user.upsert({
    where: { username: 'admin@master.com' },
    update: { password: adminHash, role: 'master', name: 'Master Admin', status: 'active' },
    create: {
      username: 'admin@master.com',
      password: adminHash,
      role: 'master',
      name: 'Master Admin',
      status: 'active',
    },
  })
  console.log('Admin user:', admin.username)

  // ── Manager ──
  const managerHash = await bcrypt.hash('Manager@123', 10)
  const manager = await prisma.user.upsert({
    where: { username: 'manager1' },
    update: { password: managerHash, role: 'manager', name: 'Rajesh Kumar', status: 'active' },
    create: {
      username: 'manager1',
      password: managerHash,
      role: 'manager',
      name: 'Rajesh Kumar',
      status: 'active',
    },
  })
  console.log('Manager user:', manager.username)

  // ── Agent ──
  const agentHash = await bcrypt.hash('Agent@123', 10)
  const agent = await prisma.user.upsert({
    where: { username: 'agent1' },
    update: { password: agentHash, role: 'user', name: 'Sample Agent', managerId: manager.id, status: 'active' },
    create: {
      username: 'agent1',
      password: agentHash,
      role: 'user',
      name: 'Sample Agent',
      managerId: manager.id,
      status: 'active',
    },
  })
  console.log('Agent user:', agent.username)

  // ── 10 Customers (Vendors) ──
  const customers = [
    { code: 'KH001', name: 'Amit Sharma' },
    { code: 'KH002', name: 'Priya Patel' },
    { code: 'KH003', name: 'Suresh Jain' },
    { code: 'KH004', name: 'Meena Desai' },
    { code: 'KH005', name: 'Ravi Verma' },
    { code: 'KH006', name: 'Anita Kulkarni' },
    { code: 'KH007', name: 'Dinesh Patil' },
    { code: 'KH008', name: 'Kavita Mehta' },
    { code: 'KH009', name: 'Ganesh Iyer' },
    { code: 'KH010', name: 'Lata Nair' },
  ]

  for (const c of customers) {
    const idx = parseInt(c.code.replace('KH00', ''), 10)
    const vendor = await prisma.vendor.upsert({
      where: { code: c.code },
      update: { businessName: c.name, mobileNo: '999999999' + idx },
      create: {
        code: c.code,
        businessName: c.name,
        mobileNo: '999999999' + idx,
        createdBy: 'admin1',
      },
    })
    console.log('Vendor:', vendor.code, '-', vendor.businessName)
  }

  console.log('\n✅ Sample data seeded successfully!')
  console.log('\nLogin credentials:')
  console.log('  Admin:   admin@master.com / Admin@90_21#')
  console.log('  Manager: manager1 / Manager@123')
  console.log('  Agent:   agent1 / Agent@123')
}

main()
  .catch((e) => {
    console.error('Error seeding data:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
