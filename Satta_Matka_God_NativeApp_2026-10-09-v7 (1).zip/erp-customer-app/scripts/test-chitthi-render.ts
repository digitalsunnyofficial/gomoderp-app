// Chitthi renderer acceptance test — renders two representative slips:
//   1. A classic mixed slip like the operator's sample photo (KB 14/5)
//   2. The operator's real WhatsApp Block 5 (Milan open motor, 112 pannas)
// Verifies JPEG output integrity; images saved for visual inspection.
import fs from 'fs'
import path from 'path'
import { parseUnifiedEntry } from '../src/lib/matka/entry-parser'
import { buildChitthiContent, renderChitthiJpeg, slipDateDisplay, chitthiStorageDir } from '../src/lib/chitthi/render'

let pass = 0, fail = 0
function check(name: string, cond: boolean, extra = '') {
  if (cond) { pass++; console.log(`PASS  ${name} ${extra}`) }
  else { fail++; console.error(`FAIL  ${name} ${extra}`) }
}

// ── Sample 1: classic mixed slip (mirrors the operator's photo sample) ──
const raw1 = `680=50
360=50
577=50
457=50
114=50
259=50
145=20
226=50
460=50
260=50
670=50
180=20
348=20
890=10
257=20
140=20
570=20`
const parse1 = parseUnifiedEntry(raw1, 100)
const total1 =
  [...parse1.singles, ...parse1.doubles, ...parse1.triples, ...parse1.common].reduce((s, e) => s + e.amount, 0) +
  parse1.groups.reduce((s, g) => s + g.entries.reduce((x, e) => x + e.amount, 0), 0)
console.log('sample1 buckets:', {
  singles: parse1.singles.length, doubles: parse1.doubles.length,
  triples: parse1.triples.length, common: parse1.common.length,
  groups: parse1.groups.map(g => `${g.option}:${g.entries.length}`),
  unknown: parse1.unknownLabels, skipped: parse1.skipped.length,
})
const content1 = buildChitthiContent(parse1, 'KB', slipDateDisplay('2026-05-14'), 'Ramesh Bhai')
const jpg1 = await renderChitthiJpeg(content1, 'test-sample-1')
const out1 = path.join(chitthiStorageDir(), 'test-sample-1.jpg')
fs.writeFileSync(out1, jpg1)
check('sample1 rendered jpeg', jpg1.length > 20_000, `${(jpg1.length / 1024).toFixed(0)}KB → ${out1}`)
check('sample1 total > 0', total1 > 0, `total=${total1}`)

// ── Sample 2: operator's real Block 5 (heavy 2-column fit test) ──
const raw2 = `Milan open motor
23457890,100
12345678,100`
const parse2 = parseUnifiedEntry(raw2, 100)
const motor = parse2.groups.find(g => g.entries.length > 0)
const motorSum = motor?.entries.reduce((s, e) => s + e.amount, 0) ?? 0
console.log('sample2 groups:', parse2.groups.map(g => `${g.option}:${g.entries.length}`).join(', '))
const content2 = buildChitthiContent(parse2, 'Milan', slipDateDisplay('2026-09-30'), 'Vikram')
const jpg2 = await renderChitthiJpeg(content2, 'test-sample-2')
const out2 = path.join(chitthiStorageDir(), 'test-sample-2.jpg')
fs.writeFileSync(out2, jpg2)
check('sample2 rendered jpeg', jpg2.length > 20_000, `${(jpg2.length / 1024).toFixed(0)}KB → ${out2}`)
// Operator arithmetic: C(8,3)=56 pannas × ₹100 × 2 seeds = ₹11,200 total; the
// two seeds share digits so entries MERGE by sum (92 unique, money preserved).
check('sample2 motor money invariant == 11200', motorSum === 11200, `entries=${motor?.entries.length} sum=${motorSum}`)

console.log(`\n${pass} PASS / ${fail} FAIL`)
process.exit(fail ? 1 : 0)
