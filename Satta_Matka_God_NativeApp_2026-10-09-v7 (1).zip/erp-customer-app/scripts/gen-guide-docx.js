// gen-guide-docx.js — assembles the Deployment & Operations Guide.
// 3-section architecture: Cover (R1, no footer) → Front matter (TOC, Roman) → Body (Arabic from 1).
const {
  Document, Packer, Paragraph, TextRun, Header, Footer, PageBreak,
  AlignmentType, PageNumber, NumberFormat, SectionType, TableOfContents,
} = require("docx");
const fs = require("fs");
const { P, FONT, buildCoverR1 } = require("./guide-helpers");
const { chaptersA } = require("./guide-content-a");
const { chaptersB } = require("./guide-content-b");

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

const pageNumFooter = () => new Footer({
  children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: FONT })],
  })],
});
const docHeader = () => new Header({
  children: [new Paragraph({
    alignment: AlignmentType.RIGHT,
    border: { bottom: { style: "single", size: 2, color: P.table.innerLine, space: 4 } },
    children: [new TextRun({ text: "Satta Matka God — Deployment & Operations Guide", size: 18, color: "808080", font: FONT })],
  })],
});

// ── Cover config (R1, DS-1) ──
const cover = buildCoverR1({
  title: "Deployment & Operations Guide",
  subtitle: "VS Code zip sync · Hostinger hosting · APK release · App notifications from the master admin",
  englishLabel: "SATTA MATKA GOD",
  metaLines: [
    "Domain: https://godmoderp.online/",
    "Scope: operator runbook — web, ERP, customer app and native APK",
    "Prepared for: Master Admin / Operator",
    "Date: 8 October 2026",
  ],
  footerLeft: "Satta Matka God · MERP + Native Customer App",
  footerRight: "Confidential — operator use",
  palette: P,
});

// ── Front matter: TOC ──
const frontMatter = [
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 480, after: 360 },
    children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, color: P.primary, font: FONT })],
  }),
  new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }),
  new Paragraph({
    spacing: { before: 200 },
    children: [new TextRun({
      text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
      italics: true, size: 18, color: "888888", font: FONT,
    })],
  }),
  // NOTE: no trailing PageBreak here — the body section below is
  // SectionType.NEXT_PAGE, which already starts on a fresh page
  // (PageBreak + NEXT_PAGE would produce a blank page).
];

const doc = new Document({
  creator: "Satta Matka God",
  title: "Deployment & Operations Guide",
  styles: {
    default: {
      document: {
        run: { font: { ascii: "Times New Roman", eastAsia: "Times New Roman" }, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 32, bold: true, color: P.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 28, bold: true, color: P.primary },
        paragraph: { spacing: { before: 260, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 24, bold: true, color: P.primary },
        paragraph: { spacing: { before: 220, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: Cover — margin 0, no footer, no page numbers
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: cover,
    },
    { // Section 2: Front matter — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin, pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageNumFooter() },
      children: frontMatter,
    },
    { // Section 3: Body — Arabic from 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: docHeader() },
      footers: { default: pageNumFooter() },
      children: [...chaptersA(), ...chaptersB()],
    },
  ],
});

const OUT = "/home/z/my-project/download/Satta_Matka_God_Deployment_and_Operations_Guide.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("WROTE", OUT, buf.length, "bytes");
});
