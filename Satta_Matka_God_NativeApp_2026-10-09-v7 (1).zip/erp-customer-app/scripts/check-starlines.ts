// Read-only check: what AppStarline rows exist + config keys + markets
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

async function main() {
  const sls = await db.appStarline.findMany({ orderBy: [{ hour: 'asc' }, { minute: 'asc' }] })
  console.log('=== AppStarline rows:', sls.length)
  for (const s of sls) {
    console.log(`code=${s.code} name=${s.name} hour=${s.hour} minute=${s.minute} close=${s.betClosingMinutes} isOn=${s.isOn} isActive=${s.isActive}`)
  }
  const cfg = await db.appConfig.findMany({ where: { key: { in: ['notice', 'banners'] } } })
  console.log('=== AppConfig:', cfg.map(c => `${c.key}=${JSON.stringify(c.value).slice(0, 120)}`).join(' | ') || '(none)')
  const markets = await db.appMarket.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } })
  console.log('=== Markets:', markets.map(m => `${m.code}(${m.name},on=${m.isOn})`).join(', '))
  const starResults = await db.appResult.findMany({ where: { marketCode: { startsWith: 'st' }, resultDate: new Date().toISOString().slice(0, 10).replace(/-/g, '-') } })
  console.log('=== star results today (loose):', starResults.length)
}
main().finally(() => process.exit(0))
