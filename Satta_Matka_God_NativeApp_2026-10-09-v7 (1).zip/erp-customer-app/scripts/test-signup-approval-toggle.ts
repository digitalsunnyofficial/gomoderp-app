/**
 * test-signup-approval-toggle.ts — end-to-end test of the Master Admin
 * signup-approval toggle (Task 22).
 *
 * Self-contained: creates a TEMPORARY super user (the operator's real master
 * admin credentials are unknown/not touched), runs the full toggle flow and
 * cleans up everything it created (temp user + test customers).
 *
 * Flow:
 *  0. Create temp super user zz-tgl-test → login → session cookie
 *  1. GET  /api/app-admin/signup-config        → default ON
 *  2. POST /api/customer-app/auth/signup       → pendingApproval: true, no token
 *  3. POST login for that customer             → 403 (awaiting approval)
 *  4. PUT  /api/app-admin/signup-config =false → toggle OFF
 *  5. POST signup (new mobile)                 → pendingApproval: false + token
 *  6. POST login for that customer             → 200 OK
 *  7. PUT toggle back ON; new signup is pending again
 *  8. Guard: PUT without session → 401/403
 *  9. Cleanup: delete temp super user + test customers
 *
 * Run: bun scripts/test-signup-approval-toggle.ts
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const BASE = 'http://localhost:3000'
const db = new PrismaClient()

let pass = 0, fail = 0
function check(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

async function cleanupCustomers(mobiles: string[]) {
  const rows = await db.appCustomer.findMany({ where: { mobile: { in: mobiles } }, select: { id: true } })
  for (const c of rows) {
    await db.appNotification.deleteMany({ where: { customerId: c.id } })
    await db.appSession.deleteMany({ where: { customerId: c.id } })
    await db.appCustomer.delete({ where: { id: c.id } }).catch(() => {})
  }
}

async function main() {
  // ── 0. Temp super user + login ──
  const tempUsername = 'zz-tgl-test'
  await db.user.deleteMany({ where: { username: tempUsername } })
  await db.user.create({
    data: {
      username: tempUsername,
      name: 'Toggle Test Super',
      password: await bcrypt.hash('tgl-test-123', 10),
      role: 'super',
      status: 'active',
    },
  })
  const loginRes = await fetch(`${BASE}/api/auth`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: tempUsername, password: 'tgl-test-123' }),
  })
  const setCookie = loginRes.headers.get('set-cookie') || ''
  check('temp super user login 200', loginRes.status === 200, String(loginRes.status))
  const cookie = setCookie.split(';')[0]
  check('session cookie received', !!cookie)

  const mobA = '9' + String(Date.now()).slice(-9)
  const mobB = '8' + String(Date.now()).slice(-9)
  const mobC = '7' + String(Date.now()).slice(-9)

  try {
    // ── 1. Default state: approval required ──
    const cfg1 = await fetch(`${BASE}/api/app-admin/signup-config`, { headers: { cookie } })
    const c1 = await cfg1.json() as { signupApprovalRequired: boolean }
    check('GET signup-config 200', cfg1.status === 200)
    check('toggle readable (boolean)', typeof c1.signupApprovalRequired === 'boolean', JSON.stringify(c1))
    // Force ON first so the test starts from a known state
    await fetch(`${BASE}/api/app-admin/signup-config`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ signupApprovalRequired: true }),
    })

    // ── 2. Signup while ON → pending, no token ──
    const s1 = await fetch(`${BASE}/api/customer-app/auth/signup`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Toggle Test A', mobile: mobA, password: 'test123' }),
    })
    const d1 = await s1.json() as { pendingApproval?: boolean; token?: string }
    check('signup ON → pendingApproval true', s1.status === 200 && d1.pendingApproval === true, JSON.stringify(d1))
    check('signup ON → no session token issued', !d1.token)

    // ── 3. Login blocked while pending ──
    const l1 = await fetch(`${BASE}/api/customer-app/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mobile: mobA, password: 'test123' }),
    })
    check('login pending → 403', l1.status === 403, String(l1.status))

    // ── 4. Toggle OFF (Super Admin) ──
    const put1 = await fetch(`${BASE}/api/app-admin/signup-config`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ signupApprovalRequired: false }),
    })
    check('PUT toggle OFF 200', put1.status === 200)

    // ── 5. Signup while OFF → instant approval + token ──
    const s2 = await fetch(`${BASE}/api/customer-app/auth/signup`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Toggle Test B', mobile: mobB, password: 'test123' }),
    })
    const d2 = await s2.json() as { pendingApproval?: boolean; token?: string; customer?: { approvalStatus?: string } }
    check('signup OFF → pendingApproval false', s2.status === 200 && d2.pendingApproval === false, JSON.stringify(d2))
    check('signup OFF → session token issued (auto-login)', !!d2.token)
    check('signup OFF → approvalStatus approved', d2.customer?.approvalStatus === 'approved')

    // ── 6. Login works instantly ──
    const l2 = await fetch(`${BASE}/api/customer-app/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mobile: mobB, password: 'test123' }),
    })
    check('login after OFF-signup → 200', l2.status === 200, String(l2.status))

    // ── 7. Toggle ON again — new signup is pending again ──
    const put2 = await fetch(`${BASE}/api/app-admin/signup-config`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ signupApprovalRequired: true }),
    })
    check('PUT toggle back ON 200', put2.status === 200)
    const s3 = await fetch(`${BASE}/api/customer-app/auth/signup`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Toggle Test C', mobile: mobC, password: 'test123' }),
    })
    const d3 = await s3.json() as { pendingApproval?: boolean }
    check('signup after re-ON → pending again', d3.pendingApproval === true, JSON.stringify(d3))

    // ── 8. Guard: non-super cannot PUT ──
    const put3 = await fetch(`${BASE}/api/app-admin/signup-config`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ signupApprovalRequired: false }),
    })
    check('PUT without session → 401/403', put3.status === 401 || put3.status === 403, String(put3.status))

    // ── 9. DB state check: B approved with auto marker, A/C pending ──
    const b = await db.appCustomer.findUnique({ where: { mobile: mobB } })
    const a = await db.appCustomer.findUnique({ where: { mobile: mobA } })
    check('DB: B approved by auto marker', b?.approvalStatus === 'approved' && (b.approvedBy || '').includes('auto'), JSON.stringify({ s: b?.approvalStatus, by: b?.approvedBy }))
    check('DB: A + C pending', a?.approvalStatus === 'pending' && b?.approvalStatus === 'approved')
  } finally {
    // ── Cleanup: temp super user + test customers ──
    await cleanupCustomers([mobA, mobB, mobC])
    await db.user.deleteMany({ where: { username: tempUsername } })
    console.log('\n  (cleanup: temp super user + 3 test customers removed)')
    await db.$disconnect()
  }

  console.log(`\n═══ RESULT: ${pass} passed, ${fail} failed ═══`)
  if (fail > 0) process.exit(1)
}

main().catch(e => { console.error(e); process.exit(1) })
