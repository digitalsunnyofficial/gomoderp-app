# -*- coding: utf-8 -*-
"""Fix G: rewrite ERP-merge block in market-charts route (canonical key + session bucketing)."""
import io

PATH = '/home/z/my-project/src/app/api/app-admin/market-charts/route.ts'
src = io.open(PATH, encoding='utf-8').read()

START = "  // \u2500\u2500 ERP channel rows for the same market+date (one source of vyapar) \u2500\u2500"
END = "  console.error('market-charts ERP merge error', erpErr)\n  }\n"

i = src.index(START)
j = src.index(END, i) + len(END)
old_block = src[i:j]
print('old block chars:', len(old_block))

NEW_BLOCK = '''  // \u2500\u2500 ERP channel rows for the same market+date (one source of vyapar) \u2500\u2500
  // Merge key = the canonical market link (InventoryCode.marketCode); the
  // legacy code/name fallbacks keep pre-link historical cards visible.
  // Session bucketing: each card's InventoryCode.type decides whether its
  // points land on the OPEN or CLOSE boards \u2014 ERP rows no longer default
  // to the open boards.
  interface ErpNum { num: string; points: number; slot: 'open' | 'close'; kind: 'single' | 'double' | 'panna' }
  const erpNums: ErpNum[] = []
  try {
    const mkRow = markets.find(m => m.code === market)
    const mkDisplay = mkRow ? marketDisplayName(mkRow) : mkName
    const invs = await db.inventory.findMany({
      where: {
        date: {
          gte: new Date(date + 'T00:00:00.000Z'),
          lt: new Date(new Date(date + 'T00:00:00.000Z').getTime() + 86400000),
        },
        status: { not: 'deleted' },
        inventoryCode: {
          OR: [
            { marketCode: market },            // canonical market link (single source)
            { code: 'app_' + market },         // legacy mirrored app cards
            { market: { equals: mkName } },    // legacy: WhatsApp cards tagged with the base market name
            { name: { equals: mkDisplay } },   // legacy: cards named with the full session display name
          ],
        },
      },
      select: { id: true, inventoryCode: { select: { type: true } } },
    })
    if (invs.length) {
      const invIds = invs.map(i => i.id)
      const bucketById = new Map(invs.map(i => [i.id, i.inventoryCode.type]))
      const bucketOf = (invId: string): 'open' | 'close' => {
        const t = bucketById.get(invId)
        return t === 'close' || t === 'night-close' ? 'close' : 'open'
      }
      const [triples, doubles] = await Promise.all([
        db.tripleInventory.findMany({ where: { inventoryId: { in: invIds } }, select: { inventoryId: true, parsedData: true, type: true } }),
        db.doubleSingleInventory.findMany({ where: { inventoryId: { in: invIds } }, select: { inventoryId: true, parsedData: true, type: true } }),
      ])
      const pushNums = (raw: string, kind: ErpNum['kind'], bucket: 'open' | 'close') => {
        try {
          const pd = JSON.parse(raw || '{}') as {
            numbers?: Array<{ number?: string; price?: number }>
            entries?: Array<{ number?: string; price?: number }>
          }
          const list = Array.isArray(pd.numbers) && pd.numbers.length ? pd.numbers : (Array.isArray(pd.entries) ? pd.entries : [])
          for (const n of list) {
            if (!n || typeof n.number !== 'string' || !n.price) continue
            // sangam composites (X-PPP / PPP-X / PPP-QQQ) stay in typeSummary only
            if (n.number.includes('-')) continue
            erpNums.push({ num: n.number, points: Number(n.price), slot: bucket, kind })
          }
        } catch { /* ignore malformed rows */ }
      }
      for (const t of triples) {
        if (t.type === 'sangam') continue
        pushNums(t.parsedData, 'panna', bucketOf(t.inventoryId))
      }
      for (const d of doubles) {
        pushNums(d.parsedData, d.type === 'double' ? 'double' : 'single', bucketOf(d.inventoryId))
      }
    }
  } catch (erpErr) {
    console.error('market-charts ERP merge error', erpErr)
  }
'''

src = src[:i] + NEW_BLOCK + src[j:]

OLD_LOOP = """  // ERP channel merge (WhatsApp paste + mirrored app bets)
  for (const e of erpNums) {
    if (e.kind === 'single') {
      const d = Number(e.num)
      if (!Number.isFinite(d) || d < 0 || d > 9) continue
      const pos = d === 0 ? 10 : d
      accAdd(sOpen, e.num, e.num, pos, e.points)
    } else if (e.kind === 'double') {
      if (!/^\\d{2}$/.test(e.num)) continue
      const sum = Number(e.num[0]) + Number(e.num[1])
      accAdd(jodiAcc, e.num, e.num, posOfSum(sum), e.points)
    } else if (e.kind === 'panna') {
      if (e.num.length !== 3) continue
      const key = pannaKey(e.num)
      if (key.length !== 3) continue
      const sum = Number(e.num[0]) + Number(e.num[1]) + Number(e.num[2])
      accAdd(tOpen, key, canonicalPanna(e.num), posOfSum(sum), e.points)
    }
  }"""

NEW_LOOP = """  // ERP channel merge (WhatsApp paste + mirrored app bets), session-bucketed
  for (const e of erpNums) {
    if (e.kind === 'single') {
      const d = Number(e.num)
      if (!Number.isFinite(d) || d < 0 || d > 9) continue
      const pos = d === 0 ? 10 : d
      if (e.slot === 'close') accAdd(sClose, e.num, e.num, pos, e.points)
      else accAdd(sOpen, e.num, e.num, pos, e.points)
    } else if (e.kind === 'double') {
      if (!/^\\d{2}$/.test(e.num)) continue
      const sum = Number(e.num[0]) + Number(e.num[1])
      accAdd(jodiAcc, e.num, e.num, posOfSum(sum), e.points)
    } else if (e.kind === 'panna') {
      if (e.num.length !== 3) continue
      const key = pannaKey(e.num)
      if (key.length !== 3) continue
      const sum = Number(e.num[0]) + Number(e.num[1]) + Number(e.num[2])
      if (e.slot === 'close') accAdd(tClose, key, canonicalPanna(e.num), posOfSum(sum), e.points)
      else accAdd(tOpen, key, canonicalPanna(e.num), posOfSum(sum), e.points)
    }
  }"""

if OLD_LOOP in src:
    src = src.replace(OLD_LOOP, NEW_LOOP)
    print('merge loop: replaced')
else:
    raise SystemExit('FATAL: ERP merge loop anchor not found')

# import line: add marketDisplayName
OLD_IMP = "import { istDate, isStarline, starlineName } from '@/lib/matka/app-engine'"
NEW_IMP = "import { istDate, isStarline, starlineName, marketDisplayName } from '@/lib/matka/app-engine'"
if OLD_IMP in src:
    src = src.replace(OLD_IMP, NEW_IMP)
    print('import: updated')
else:
    print('WARN: import anchor not found (may already include marketDisplayName)')

io.open(PATH, 'w', encoding='utf-8', newline='\n').write(src)
print('written OK, new length:', len(src))
