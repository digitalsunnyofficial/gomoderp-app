import { db } from '../src/lib/db'
const rows = await db.whatsAppMessage.findMany({ where: { phone: '919812345678' }, orderBy: { createdAt: 'asc' } })
console.log('rows:', rows.length)
for (const r of rows) {
  console.log('---', r.direction, '| status:', r.status, '| market:', r.marketName, '| wamid:', r.waMessageId)
  if (r.body) console.log(r.body.split('\n').slice(0, 10).join('\n'))
}
process.exit(0)
