// Task 42: PROOF — the deployed gold db, after the new prestart `prisma db push`,
// serves every failing flow with ZERO data loss. Simulates exactly what the
// Hostinger pipeline will do on boot.
import { execSync } from 'child_process'
import { PrismaClient } from '@prisma/client'

const GOLD = '/home/z/my-project/zipstage-hostinger-r3/db/custom.db'
const WORK = '/home/z/my-project/zipstage-goldwork/db/custom.db'
const URL = `file:${WORK}`

execSync(`rm -rf /home/z/my-project/zipstage-goldwork && mkdir -p $(dirname ${WORK}) && cp ${GOLD} ${WORK}`, { stdio: 'inherit' })

function count(label: string, n: number) { console.log(`   ${label}: ${n}`) }
const db = new PrismaClient({ datasources: { db: { url: URL } } })

async function main() {
  const before = {
    customers: await db.appCustomer.count(),
    markets: await db.appMarket.count(),
    bets: await db.appBet.count(),
    txns: await db.appTransaction.count(),
    users: await db.user.count(),
  }
  console.log('BEFORE push (gold db):'); Object.entries(before).forEach(([k, v]) => count(k, v))

  // ── the exact command the new prestart/postinstall runs ──
  execSync(`DATABASE_URL="${URL}" npx prisma db push --skip-generate`, { cwd: '/home/z/my-project', stdio: 'inherit' })

  const after = {
    customers: await db.appCustomer.count(),
    markets: await db.appMarket.count(),
    bets: await db.appBet.count(),
    txns: await db.appTransaction.count(),
    users: await db.user.count(),
  }
  console.log('AFTER push:'); Object.entries(after).forEach(([k, v]) => count(k, v))
  const same = JSON.stringify(before) === JSON.stringify(after)
  console.log(same ? '✅ ZERO DATA LOSS — every row intact' : '❌ DATA CHANGED!')

  // ── all previously-failing flows, directly against the pushed gold db ──
  const customers = await db.appCustomer.findMany({ orderBy: { createdAt: 'desc' }, take: 300 })
  console.log(`✅ customers list query OK — ${customers.length} rows`)
  const ids = customers.map(c => c.id)
  await db.appBet.groupBy({ by: ['customerId'], where: { customerId: { in: ids } }, _count: { _all: true }, _sum: { points: true, win: true } })
  console.log('✅ bets groupBy OK')
  const demo = await db.appCustomer.findUnique({ where: { mobile: '9876500001' } })
  console.log(`✅ login findUnique OK — ${demo?.name}`)
  await db.appCustomer.update({ where: { mobile: '9876500001' }, data: { lastLoginAt: demo?.lastLoginAt || new Date() } })
  console.log('✅ login lastLoginAt update OK')
  const t = await db.appCustomer.create({ data: { name: 'POST-PUSH PROBE', mobile: '0000000001', password: 'x', wallet: 0 } })
  await db.appCustomer.delete({ where: { id: t.id } })
  console.log('✅ signup create/delete probe OK')
  await db.agentCommissionWithdrawal.findMany({ take: 1 })
  console.log('✅ AgentCommissionWithdrawal table now present')
  await db.apkArtifact.findMany({ take: 1 })
  console.log('✅ ApkArtifact table now present')

  await db.$disconnect()
  if (!same) process.exit(1)
}
main().catch(e => { console.error('❌ PUSH/VERIFY FAILED:', String(e.message).slice(0, 300)); process.exit(1) })
