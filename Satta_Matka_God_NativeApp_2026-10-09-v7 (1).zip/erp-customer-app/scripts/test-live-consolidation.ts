// Live E2E for consolidated mirror entries (Task 16.4):
// Priya places a single + a panna bet on Milan Night Open — Rahul's card
// already holds the consolidated rows. Assert: NO new row appears, the
// existing rows MERGE (points sum, byCustomer gains Priya, customers=2).
//
// Run: npx tsx scripts/test-live-consolidation.ts
const BASE = 'http://localhost:3000'

async function j(method: string, path: string, body?: unknown, token?: string) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  return { status: res.status, data }
}

function parse(raw: string) { return JSON.parse(raw) }

let failures = 0
function check(name: string, cond: boolean, extra = '') {
  if (cond) console.log(`  PASS  ${name}`)
  else { failures++; console.log(`  FAIL  ${name} ${extra}`) }
}

async function main() {
  console.log('=== live consolidation E2E ===')
  // login Priya
  const login = await j('POST', '/api/customer-app/auth/login', { mobile: '9822345602', password: 'Priya@123' })
  const token = login.data?.token as string
  check('Priya app login', !!token, JSON.stringify(login.data).slice(0, 120))

  const home = await j('GET', '/api/customer-app/home', undefined, token)
  const mk = (home.data.markets || []).find((m: { code: string }) => m.code === 'milan_night_open')
  check('milan_night_open visible', !!mk)

  // place bets: single 8@10 + sp 380@10 (Priya) — same card as Rahul's rows
  // (fixed clientRequestIds keep this test idempotent — replays are deduped)
  const bet = await j('POST', '/api/customer-app/bets', {
    items: [
      { marketCode: 'milan_night_open', slot: 'open', type: 'single', num: '8', points: 10, gameCode: 'single-digit', marketName: mk?.displayName || 'Milan Night Open', clientRequestId: 'e2e-16.4-priya-single-8' },
      { marketCode: 'milan_night_open', slot: 'open', type: 'sp', num: '380', points: 10, gameCode: 'single-pana', marketName: mk?.displayName || 'Milan Night Open', clientRequestId: 'e2e-16.4-priya-sp-380' },
    ],
  }, token)
  console.log('bet POST:', bet.status, JSON.stringify(bet.data).slice(0, 220))
  check('bet placed 200', bet.status === 200)

  await new Promise(r => setTimeout(r, 1500))

  // AFTER: read the DB directly (server-side check)
  const { PrismaClient } = await import('@prisma/client')
  const db = new PrismaClient()
  const invCode = await db.inventoryCode.findFirst({ where: { marketCode: 'milan_night_open' } })
  const today = new Date()
  const istToday = new Date(today.getTime() + 5.5 * 3600 * 1000).toISOString().slice(0, 10)
  const card = await db.inventory.findFirst({
    where: { inventoryCodeId: invCode!.id, date: { gte: new Date(istToday + 'T00:00:00.000Z'), lt: new Date(new Date(istToday + 'T00:00:00.000Z').getTime() + 86400000) } },
    include: { tripleInventories: true, doubleSingleInventories: true },
  })
  console.log(`\nCard Milan Night Open (${istToday}): createdBy=${card?.createdBy} total=${card?.totalAmount}`)
  check('card Submitted By = app', card?.createdBy === 'app', card?.createdBy)

  const triples = card!.tripleInventories
  const dsRows = card!.doubleSingleInventories
  check('STILL exactly 1 triple row (merged, not new)', triples.length === 1, `got ${triples.length}`)
  check('STILL exactly 1 DS single row (merged, not new)', dsRows.length === 1, `got ${dsRows.length}`)

  const tpd = parse(triples[0].parsedData)
  const dpd = parse(dsRows[0].parsedData)
  const t380 = tpd.numbers.find((n: { number: string }) => n.number === '380')
  check('Priya panna 380 merged into the row (10 x2 runs = 20)', t380?.price === 20, JSON.stringify(t380))
  check('panna byCustomer: Priya owns 380', tpd.byCustomer?.['380']?.['Priya (9822345602)'] === 20, JSON.stringify(tpd.byCustomer?.['380']))
  check('panna byCustomer: Rahul still owns his 111 (motor)', tpd.byCustomer?.['111']?.['Rahul (9812345601)'] === 10, JSON.stringify(tpd.byCustomer?.['111']))
  check('panna customers list = 2', (tpd.customers || []).length === 2, JSON.stringify(tpd.customers))
  check('panna details = 2 customers', triples[0].details.includes('2 customers'), triples[0].details)

  const d8 = dpd.numbers.find((n: { number: string }) => n.number === '8')
  check('single 8 merged (Priya 10 x2 runs = 20)', d8?.price === 20, JSON.stringify(d8))
  check('single byCustomer has Rahul 5 + Priya 8', dpd.byCustomer?.['5']?.['Rahul (9812345601)'] === 100 && dpd.byCustomer?.['8']?.['Priya (9822345602)'] === 20, JSON.stringify(dpd.byCustomer))

  const staked = 490 + 40 // card had 490 before; Priya added 10+10 across two runs (run 2+ deduped)
  check('card total = 530', card!.totalAmount === staked, `got ${card!.totalAmount}`)

  await db.$disconnect()
  console.log(failures === 0 ? '\nALL LIVE CHECKS PASSED' : `\n${failures} LIVE CHECK(S) FAILED`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch(e => { console.error(e); process.exit(1) })
