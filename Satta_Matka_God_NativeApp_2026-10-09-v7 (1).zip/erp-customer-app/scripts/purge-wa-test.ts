// One-off: purge leftover rows from the crashed v3 test run (cleanup never ran).
import { db } from '../src/lib/db'

const testPhones = ['9000000001', '9123456780', '919123456780', '9123456781', '91999900001', '120363999888777', '999777666555']
const msgs = await db.whatsAppMessage.findMany({ where: { phone: { in: testPhones } }, select: { id: true } })
const ids = msgs.map(m => m.id)
await db.whatsAppApproval.deleteMany({ where: { messageId: { in: ids } } })
const cust = await db.appCustomer.findUnique({ where: { mobile: '9123456780' } })
const vend = await db.vendor.findUnique({ where: { code: 'WATEST1' } })
await db.whatsAppTransactionLine.deleteMany({ where: { tx: { OR: [{ customerId: cust?.id }, { vendorId: vend?.id }] } } })
await db.whatsAppTransaction.deleteMany({ where: { OR: [{ customerId: cust?.id }, { vendorId: vend?.id }] } })
await db.whatsAppMessage.deleteMany({ where: { phone: { in: testPhones } } })
await db.whatsAppGroupMapping.deleteMany({ where: { groupId: { in: ['120363999888777', '999777666555'] } } })
await db.parserTerm.deleteMany({ where: { term: 'wamalang' } })
await db.parserLearningLog.deleteMany({ where: { OR: [{ rawInput: { contains: 'wamalang' } }, { firstMessageId: { in: ids } }] } })
await db.appConfig.deleteMany({ where: { key: { in: ['whatsapp_approval', 'parser_version'] } } })
await db.appResult.deleteMany({ where: { declaredBy: 'wa-test' } })
if (cust) await db.appCustomer.delete({ where: { id: cust.id } }).catch(() => undefined)
if (vend) await db.vendor.delete({ where: { id: vend.id } }).catch(() => undefined)
await db.user.deleteMany({ where: { username: 'wa-test-agent' } })
console.log('purge done')
process.exit(0)
