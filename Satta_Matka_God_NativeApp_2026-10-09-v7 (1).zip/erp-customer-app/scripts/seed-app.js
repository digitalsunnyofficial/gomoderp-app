// Seed for the Matka Bazaar customer app + production ERP accounts:
//   • ERP users: superadmin@mb.com / admin@mb.com / agent@mb.com (old demo accounts removed)
//   • 5 sample customers (Hindi/Gujarati/Marathi/English)
//   • markets with weekly schedules (Kalyan Sunday off, Shridevi Sunday special draw)
//   • game catalog (23 games) + per-market allocations (20 games per market)
//   • business QR payment settings, config, sample results, notifications
// Usage: node scripts/seed-app.js  (or bun scripts/seed-app.js)
const { PrismaClient } = require('@prisma/client')
const bcrypt = require('bcryptjs')
const prisma = new PrismaClient()

const iso = d => {
  const ist = new Date(d.getTime() + 5.5 * 3600 * 1000)
  return ist.toISOString().slice(0, 10)
}
const daysAgo = n => { const d = new Date(); d.setDate(d.getDate() - n); return iso(d) }
const TODAY = () => iso(new Date())

const SP = {
  '0': '019,028,037,046,127,136,145,235,389,479,569,578', '1': '029,038,047,056,128,137,146,236,245,489,579,678',
  '2': '039,048,057,129,138,147,156,237,246,345,589,679', '3': '012,049,058,067,139,148,157,238,247,256,346,689',
  '4': '013,059,068,149,158,167,239,248,257,347,356,789', '5': '014,023,069,078,159,168,249,258,267,348,357,456',
  '6': '015,024,079,123,169,178,259,268,349,358,367,457', '7': '016,025,034,089,124,179,269,278,359,368,458,467',
  '8': '017,026,035,125,134,189,279,369,378,459,468,567', '9': '018,027,036,045,126,135,234,289,379,469,478,568',
}
const SPB = Object.fromEntries(Object.entries(SP).map(([k, v]) => [k, v.split(',')]))
const DP = {
  '0': '118,226,334,442,550,668,776,884,992', '1': '001,119,227,335,443,551,669,885,993',
  '2': '002,110,228,336,552,660,778,886,994', '3': '003,229,337,445,553,661,779,887,995',
  '4': '004,112,220,338,446,554,662,770,996', '5': '005,113,221,339,447,663,771,889,997',
  '6': '006,114,330,448,556,664,772,880,998', '7': '007,115,223,331,449,557,665,773,881',
  '8': '008,116,224,332,440,558,774,882,990', '9': '009,117,225,441,559,667,775,883,991',
}
const DPB = Object.fromEntries(Object.entries(DP).map(([k, v]) => [k, v.split(',')]))
const deriveDigit = p => String(p.split('').reduce((a, c) => a + Number(c), 0) % 10)

function hash(s) { let h = 7; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h }
function genRes(mk, ds) {
  const h = hash(mk + ds)
  const op = SPB[h % 10][h % 12]
  const cp = DPB[(h >>> 5) % 10][(h >>> 3) % 9]
  const od = deriveDigit(op), cd = deriveDigit(cp)
  return { openPanna: op, openDigit: od, closePanna: cp, closeDigit: cd, jodi: od + cd }
}

// ── Markets with weekly schedules (0=Sunday … 6=Saturday) ──
function weekly(defaultOpen, defaultClose, overrides = {}) {
  const wk = {}
  for (let d = 0; d < 7; d++) {
    if (overrides[d] === false) { wk[String(d)] = { on: false, open: defaultOpen, close: defaultClose }; continue }
    const o = overrides[d]
    wk[String(d)] = { on: true, open: (o && o.open) || defaultOpen, close: (o && o.close) || defaultClose }
  }
  return JSON.stringify(wk)
}

const MARKETS = [
  { code: 'shridevi', name: 'Shridevi', category: 'regular', phase: 'day', session: 'both', openTime: '10:00', closeTime: '11:30', sortOrder: 1, weeklySchedule: weekly('10:00', '11:30', { 0: { open: '10:00', close: '17:30' } }) }, // Sunday special draw ends 17:30
  { code: 'time', name: 'Time Bazar', category: 'regular', phase: 'day', session: 'both', openTime: '13:00', closeTime: '14:00', sortOrder: 2, weeklySchedule: weekly('13:00', '14:00') },
  { code: 'milan', name: 'Milan Day', category: 'regular', phase: 'day', session: 'both', openTime: '13:30', closeTime: '15:00', sortOrder: 3, weeklySchedule: weekly('13:30', '15:00') },
  { code: 'rajdhani', name: 'Rajdhani Day', category: 'regular', phase: 'day', session: 'both', openTime: '15:15', closeTime: '16:45', sortOrder: 4, weeklySchedule: weekly('15:15', '16:45') },
  { code: 'shridevi_night', name: 'Shridevi Night', category: 'night', phase: 'night', session: 'both', openTime: '21:00', closeTime: '22:30', sortOrder: 5, weeklySchedule: weekly('21:00', '22:30') },
  { code: 'milan_night', name: 'Milan Night', category: 'night', phase: 'night', session: 'both', openTime: '21:30', closeTime: '23:00', sortOrder: 6, weeklySchedule: weekly('21:30', '23:00') },
  { code: 'kalyan', name: 'Kalyan', category: 'night', phase: 'night', session: 'both', openTime: '21:45', closeTime: '23:15', sortOrder: 7, weeklySchedule: weekly('21:45', '23:15', { 0: false }) }, // Sunday weekly-off
]

// ── Game catalog (23 games — mirrors src/lib/matka/games-engine.ts) ──
const GAMES = [
  ['single', 'Single Digit', 'digit', 'ank', 'both', 'Single', 9, 'none', 'zap', 1],
  ['jodi', 'Jodi', 'jodi', 'jodi', 'both', 'Jodi', 90, 'none', 'layers', 2],
  ['sp', 'Single Pana', 'panna', 'panna', 'both', 'SP', 140, 'none', 'layers', 3],
  ['dp', 'Double Pana', 'panna', 'panna', 'both', 'DP', 280, 'none', 'layers', 4],
  ['tp', 'Triple Pana', 'panna', 'panna', 'close', 'TP', 700, 'none', 'layers', 5],
  ['hs', 'Half Sangam A', 'sangam', 'pair', 'both', 'Half Sangam A', 1500, 'none', 'star', 6],
  ['hsb', 'Half Sangam B', 'sangam', 'pair', 'both', 'Half Sangam B', 1500, 'none', 'star', 24],
  ['fs', 'Full Sangam', 'sangam', 'pair', 'both', 'Full Sangam', 8000, 'none', 'star', 7],
  ['oddeven', 'Odd / Even', 'special', 'oddeven', 'open', 'Odd Even', 1.95, 'none', 'circle', 8],
  ['sp-motor', 'SP Motor', 'motor', 'digits', 'both', 'Motor Pana', 140, 'sp-motor', 'flask-conical', 9],
  ['dp-motor', 'DP Motor', 'motor', 'digits', 'both', 'Motor Pana', 280, 'dp-motor', 'flask-conical', 10],
  ['motor', 'Motor Pana', 'motor', 'digits', 'both', 'Motor Pana', 140, 'motor', 'flask-conical', 11],
  ['spdp', 'SP DP', 'panna', 'panna', 'both', 'SPDP', 140, 'spdp', 'layers', 12],
  ['sptp', 'SP TP', 'panna', 'panna', 'both', 'SPTP', 140, 'sptp', 'layers', 13],
  ['dptp', 'DP TP', 'panna', 'panna', 'both', 'DPTP', 280, 'dptp', 'layers', 14],
  ['spdptp', 'SP DP TP', 'panna', 'panna', 'both', 'SPDPTP', 140, 'spdptp', 'layers', 15],
  ['family-4', 'Family Set 4', 'family', 'panna', 'both', 'Family Set 4', 140, 'family4', 'layers', 16],
  ['family-6', 'Family Set 6', 'family', 'panna', 'both', 'Family Set 6', 140, 'family6', 'layers', 17],
  ['family-8', 'Family Set 8', 'family', 'panna', 'both', 'Family Set 8', 140, 'family8', 'layers', 18],
  ['chart-50', '50 Chart', 'chart', 'panna', 'both', '50 Chart', 140, 'chart50', 'download', 19],
  ['chart-60', '60 Chart', 'chart', 'panna', 'both', '60 Chart', 140, 'chart60', 'download', 20],
  ['chart-70', '70 Chart', 'chart', 'panna', 'both', '70 Chart', 140, 'chart70', 'download', 21],
  ['chart-90dp', '90 DP Chart', 'chart', 'panna', 'both', '90 DP Chart', 280, 'chart90dp', 'download', 22],
  ['chart-abr', '90 ABR Chart', 'chart', 'panna', 'both', '90 ABR Chart', 140, 'chart90abr', 'download', 23],
  ['chart-20', '20 Chart', 'chart', 'panna', 'both', '20 Chart', 140, 'chart20', 'download', 25],
  ['chart-30', '30 Chart', 'chart', 'panna', 'both', '30 Chart', 140, 'chart30', 'download', 26],
  ['chart-40', '40 Chart', 'chart', 'panna', 'both', '40 Chart', 140, 'chart40', 'download', 27],
  ['family', 'Family Chart', 'family', 'panna', 'both', 'Family Chart', 140, 'family', 'users', 28],
]

// 24 games allocated to every app market: the combined Family Chart replaces
// the three individual family sets (sets stay in the catalog, unallocated).
const ALLOCATED = ['single', 'jodi', 'sp', 'dp', 'tp', 'hs', 'hsb', 'fs', 'sp-motor', 'dp-motor', 'motor', 'spdp', 'sptp', 'dptp', 'spdptp', 'family', 'chart-20', 'chart-30', 'chart-40', 'chart-50', 'chart-60', 'chart-70', 'chart-90dp', 'chart-abr']

// Family Set 4/6/8 allocations are retired on every market — the combined
// Family Chart covers them (operator merge request). Game rows remain in the
// catalog so nothing is lost; an operator can re-allocate a set manually.
const UNALLOCATED = ['family-4', 'family-6', 'family-8']

// ── Production ERP accounts ──
const ERP_USERS = [
  { username: 'superadmin@mb.com', password: 'SAdmin@123_321', role: 'super', name: 'Super Admin' },
  { username: 'admin@mb.com', password: 'Admin@123_321', role: 'manager', name: 'Admin' },
  { username: 'agent@mb.com', password: 'Agent@123_321', role: 'user', name: 'Agent' },
]

// ── Sample customers (5) ──
const CUSTOMERS = [
  { name: 'Rahul', mobile: '9812345601', password: 'Rahul@123', lang: 'hi', wallet: 2500 },
  { name: 'Priya', mobile: '9822345602', password: 'Priya@123', lang: 'en', wallet: 1800 },
  { name: 'Amit', mobile: '9832345603', password: 'Amit@123', lang: 'gu', wallet: 3200 },
  { name: 'Sneha', mobile: '9842345604', password: 'Sneha@123', lang: 'mr', wallet: 1500 },
  { name: 'Vikram', mobile: '9852345605', password: 'Vikram@123', lang: 'en', wallet: 4650 },
]

const BANNERS = [
  { t: 'SATTA KING 786', s: 'Play all markets · instant results', bg: 'linear-gradient(120deg,#7c3aed,#db2777)' },
  { t: '₹10 KHELO ₹9500', s: 'Full Sangam now live on Kalyan', bg: 'linear-gradient(120deg,#be185d,#f59e0b)' },
  { t: 'BABA STARLINE', s: '24 hour games · every hour on time', bg: 'linear-gradient(120deg,#0891b2,#6d28d9)' },
]

async function main() {
  console.log('Seeding production accounts + customer app data…')

  // ── ERP production users; old demo accounts removed ──
  for (const u of ERP_USERS) {
    const hashed = await bcrypt.hash(u.password, 10)
    await prisma.user.upsert({
      where: { username: u.username },
      create: { username: u.username, password: hashed, passwordPlain: u.password, role: u.role, name: u.name, status: 'active' },
      update: { password: hashed, passwordPlain: u.password, role: u.role, name: u.name, status: 'active' },
    })
  }
  console.log('  ✓ ERP users: ' + ERP_USERS.map(u => u.username).join(', '))
  const gone = await prisma.user.deleteMany({ where: { username: { in: ['admin1', 'admin2', 'agent1', 'user1'] } } })
  console.log('  ✓ removed ' + gone.count + ' old demo ERP accounts')

  // ── Markets (weekly schedules + master ON) ──
  for (const m of MARKETS) {
    await prisma.appMarket.upsert({
      where: { code: m.code },
      create: { ...m, isOn: true, betClosingMinutes: 5 },
      update: { name: m.name, category: m.category, phase: m.phase, session: m.session, openTime: m.openTime, closeTime: m.closeTime, sortOrder: m.sortOrder, weeklySchedule: m.weeklySchedule, isOn: true },
    })
  }
  console.log('  ✓ ' + MARKETS.length + ' app markets (weekly schedules: Kalyan Sunday off, Shridevi Sunday special)')

  // ── Game catalog + allocations ──
  for (const g of GAMES) {
    const [code, name, category, base, session, erpMapping, defaultRate, expansion, icon, sortOrder] = g
    await prisma.game.upsert({
      where: { code },
      create: { code, name, category, base, session, erpMapping, defaultRate, expansion, icon, sortOrder },
      update: { name, category, base, session, erpMapping, defaultRate, expansion, icon, sortOrder },
    })
  }
  const allGames = await prisma.game.findMany()
  const byCode = Object.fromEntries(allGames.map(g => [g.code, g]))
  let allocCount = 0
  for (const m of MARKETS) {
    for (const gc of ALLOCATED) {
      const game = byCode[gc]
      if (!game) continue
      await prisma.gameAllocation.upsert({
        where: { gameId_marketCode: { gameId: game.id, marketCode: m.code } },
        create: { gameId: game.id, marketCode: m.code, isActive: true, minPoints: 10 },
        update: { isActive: true },
      })
      allocCount++
    }
  }
  console.log('  ✓ ' + GAMES.length + ' games · ' + allocCount + ' allocations (' + ALLOCATED.length + ' per market)')

  // ── Retire family-set allocations (merged into the combined Family Chart) ──
  let retiredCount = 0
  for (const m of MARKETS) {
    for (const gc of UNALLOCATED) {
      const game = byCode[gc]
      if (!game) continue
      const res = await prisma.gameAllocation.updateMany({
        where: { gameId: game.id, marketCode: m.code, isActive: true },
        data: { isActive: false },
      })
      retiredCount += res.count
    }
  }
  console.log('  ✓ retired ' + retiredCount + ' family-set allocations (Family Chart now covers sets 4/6/8)')

  // ── Config ──
  await prisma.appConfig.upsert({
    where: { key: 'notice' },
    create: { key: 'notice', value: 'Milan Morning is now online — play now! · Download the Android app for instant results' },
    update: { value: 'Milan Morning is now online — play now! · Download the Android app for instant results' },
  })
  await prisma.appConfig.upsert({
    where: { key: 'banners' },
    create: { key: 'banners', value: JSON.stringify(BANNERS) },
    update: { value: JSON.stringify(BANNERS) },
  })
  console.log('  ✓ app config (notice, banners)')

  // ── Business UPI QR settings (managed from ERP → Payment Management → Business QR) ──
  await prisma.appPaymentSetting.upsert({
    where: { id: 'primary' },
    create: {
      id: 'primary',
      upiId: 'mainbazaar@upi',
      payeeName: 'MAIN BAZAAR',
      note: 'Pay on any UPI app and submit the UTR — points credited after admin check',
      minDeposit: 100,
      updatedBy: 'system',
    },
    update: {},
  })
  console.log('  ✓ business payment settings (UPI + 1 point = ₹1)')

  // ── Sample customers (replace the old demo account) ──
  const oldDemo = await prisma.appCustomer.findUnique({ where: { mobile: '9999999999' } })
  if (oldDemo) {
    await prisma.appCustomer.delete({ where: { id: oldDemo.id } }).catch(async () => {
      await prisma.appCustomer.update({ where: { id: oldDemo.id }, data: { status: 'blocked' } })
    })
    console.log('  ✓ old demo customer 9999999999 removed')
  }
  for (const c of CUSTOMERS) {
    const hashed = await bcrypt.hash(c.password, 10)
    const cust = await prisma.appCustomer.upsert({
      where: { mobile: c.mobile },
      create: {
        name: c.name, mobile: c.mobile, password: hashed, wallet: c.wallet,
        approvalStatus: 'approved', language: c.lang,
      },
      update: { approvalStatus: 'approved', language: c.lang, status: 'active' },
    })
    const txCount = await prisma.appTransaction.count({ where: { customerId: cust.id, type: 'deposit' } })
    if (!txCount) {
      await prisma.appTransaction.create({
        data: { customerId: cust.id, type: 'deposit', amount: c.wallet, balanceAfter: c.wallet, remark: 'Fund approved (UTR' + hash(c.mobile) + ')' },
      })
    }
  }
  console.log('  ✓ ' + CUSTOMERS.length + ' sample customers (' + CUSTOMERS.map(c => c.name + ' ' + c.mobile + '/' + c.password + ' · ' + c.lang).join(', ') + ')')

  // ── Sample results: past 10 days for each market (deterministic) ──
  let resCount = 0
  for (const m of MARKETS) {
    for (let d = 10; d >= 1; d--) {
      const ds = daysAgo(d)
      const r = genRes(m.code, ds)
      await prisma.appResult.upsert({
        where: { marketCode_resultDate: { marketCode: m.code, resultDate: ds } },
        create: { marketCode: m.code, marketName: m.name, resultDate: ds, ...r, declaredBy: 'system-seed' },
        update: {},
      })
      resCount++
    }
    // Today: leave undeclared so admin can declare live
  }
  // Starline: past hours of today declared
  const curH = new Date().getHours()
  for (let h = 0; h < curH; h++) {
    const p = SPB[hash('st' + h + TODAY()) % 10][hash('st' + h) % 12]
    await prisma.appResult.upsert({
      where: { marketCode_resultDate: { marketCode: 'st' + h, resultDate: TODAY() } },
      create: {
        marketCode: 'st' + h, marketName: 'Starline ' + String(h).padStart(2, '0') + ':00',
        resultDate: TODAY(), openPanna: p, openDigit: deriveDigit(p), declaredBy: 'system-seed',
      },
      update: {},
    })
    resCount++
  }
  console.log('  ✓ ' + resCount + ' sample results (10 days history + starline hours)')

  // ── Welcome broadcast notification ──
  await prisma.appNotification.create({
    data: { customerId: null, icon: 'megaphone', text: 'Welcome to Matka Bazaar — place your vyapar directly from the app!' },
  })
  console.log('  ✓ welcome notification')
  console.log('Done.')
}

main()
  .catch(e => { console.error(e); process.exit(1) })
  .finally(() => prisma.$disconnect())
