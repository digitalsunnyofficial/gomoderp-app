// prisma/seed.js — CommonJS seed script for Hostinger deployment
// Runs as postbuild step to ensure default data exists

const { PrismaClient } = require('@prisma/client')
const path = require('path')
const fs = require('fs')

// Resolve DB path. Relative `file:` urls are resolved against the SCHEMA
// directory (this file's location: prisma/) — the same rule the Prisma CLI
// and the generated client use — so seeding always targets <project>/db/custom.db
// regardless of the CWD the script is started from.
function resolveDatabaseUrl() {
  let url = process.env.DATABASE_URL || 'file:../db/custom.db'
  const m = url.match(/^file:(.+)$/)
  if (m && !path.isAbsolute(m[1])) {
    // Relative path — resolve against prisma/ (schema dir)
    url = 'file:' + path.resolve(__dirname, m[1])
  }
  return url
}

// Ensure the db/ directory exists before Prisma tries to open the file.
// Prevents "Error code 14: Unable to open the database file" on fresh deploys.
function ensureDbDir() {
  const url = resolveDatabaseUrl()
  const m = url.match(/^file:(.+)$/)
  if (m) {
    const dbPath = m[1]
    const dbDir = path.dirname(dbPath)
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true })
      console.log(`📁 Created db directory: ${dbDir}`)
    }
  }
}

ensureDbDir()

const prisma = new PrismaClient({
  log: ['error'],
  datasources: {
    db: { url: resolveDatabaseUrl() }
  }
})

async function main() {
  console.log(`🌱 Seeding database at: ${resolveDatabaseUrl().replace('file:', '')}`)

  // Seed inventory codes (14 markets)
  const codes = [
    { code: 'MILAN-O', name: 'Milan Open', market: 'milan', type: 'open' },
    { code: 'MILAN-C', name: 'Milan Close', market: 'milan', type: 'close' },
    { code: 'SRIDEVI-O', name: 'Shridevi Open', market: 'shridevi', type: 'open' },
    { code: 'SRIDEVI-C', name: 'Shridevi Close', market: 'shridevi', type: 'close' },
    { code: 'TIME-O', name: 'Time Open', market: 'time', type: 'open' },
    { code: 'TIME-C', name: 'Time Close', market: 'time', type: 'close' },
    { code: 'KALYAN-O', name: 'Kalyan Open', market: 'kalyan', type: 'open' },
    { code: 'KALYAN-C', name: 'Kalyan Close', market: 'kalyan', type: 'close' },
    { code: 'RAJDHANI-O', name: 'Rajdhani Open', market: 'rajdhani', type: 'open' },
    { code: 'RAJDHANI-C', name: 'Rajdhani Close', market: 'rajdhani', type: 'close' },
    { code: 'MILAN-NO', name: 'Milan Night Open', market: 'milan', type: 'night-open' },
    { code: 'MILAN-NC', name: 'Milan Night Close', market: 'milan', type: 'night-close' },
    { code: 'SRIDEVI-NO', name: 'Shridevi Night Open', market: 'shridevi', type: 'night-open' },
    { code: 'SRIDEVI-NC', name: 'Shridevi Night Close', market: 'shridevi', type: 'night-close' },
  ]

  for (const c of codes) {
    await prisma.inventoryCode.upsert({
      where: { code: c.code },
      update: { name: c.name, market: c.market, type: c.type },
      create: c,
    })
  }
  console.log('✅ Inventory codes seeded')

  // Seed MASTER admin (admin1) — full system owner
  await prisma.user.upsert({
    where: { username: 'admin1' },
    update: {},
    create: {
      username: 'admin1',
      password: 'admin123',
      role: 'super',
      name: 'Super Admin',
      status: 'active',
    },
  })
  console.log('✅ Super Admin seeded (admin1 / admin123)')

  // Seed DEFAULT ADMIN (admin2) — manager role; standalone agents auto-assigned here
  // NOTE: We force-reset the password on every seed run so the documented
  // credentials (admin2 / admin123) always work, even if a previous deployment
  // changed them. Super admin (admin1) is NOT reset — respect user changes.
  const defaultAdmin = await prisma.user.upsert({
    where: { username: 'admin2' },
    update: { password: 'admin123', role: 'manager', name: 'Default Admin', status: 'active', assignedMarkets: 'milan,shridevi,time,kalyan,rajdhani' },
    create: {
      username: 'admin2',
      password: 'admin123',
      role: 'manager',
      name: 'Default Admin',
      status: 'active',
      assignedMarkets: 'milan,shridevi,time,kalyan,rajdhani',
    },
  })
  console.log('✅ Default Admin seeded (admin2 / admin123) — manager role')

  // Seed DEFAULT AGENT (agent1) — under default admin; for testing/demo
  // Also force-reset password so documented credentials always work.
  await prisma.user.upsert({
    where: { username: 'agent1' },
    update: { password: 'agent123', role: 'user', name: 'Default Agent', status: 'active', assignedMarkets: 'milan,shridevi,time,kalyan,rajdhani', managerId: defaultAdmin.id },
    create: {
      username: 'agent1',
      password: 'agent123',
      role: 'user',
      name: 'Default Agent',
      status: 'active',
      assignedMarkets: 'milan,shridevi,time,kalyan,rajdhani',
      managerId: defaultAdmin.id,
    },
  })
  console.log('✅ Default Agent seeded (agent1 / agent123) — under default admin')

  // Seed regular user (user1) — legacy test account, kept for backward compat
  await prisma.user.upsert({
    where: { username: 'user1' },
    update: {},
    create: {
      username: 'user1',
      password: 'user123',
      role: 'user',
      name: 'User 1',
      status: 'active',
    },
  })
  console.log('✅ Regular User seeded (user1 / user123)')

  // Seed subscription plans
  // Operator-verified pricing (2026-09-07):
  //   - Starter:    ₹15,000/month — 1 admin + 1 user
  //   - Growth:     ₹25,000/month — 1 admin + 2 users  (most popular)
  //   - Business:   ₹35,000/month — 1 admin + 4 users
  // Plus a 2-day free demo trial so prospects can evaluate before purchasing.
  const plans = [
    {
      name: 'trial',
      label: '2-Day Trial',
      durationDays: 2,
      price: 0,
      features: JSON.stringify([
        'Full access for 2 days',
        '1 admin + 1 user (demo)',
        'All markets & chart types',
        'No credit card required',
      ]),
    },
    {
      name: 'starter',
      label: 'Starter',
      durationDays: 30,
      price: 15000,
      features: JSON.stringify([
        '1 Admin account',
        '1 Agent account',
        'All 5 markets supported',
        'WhatsApp parser + chart generation',
        'Khatri & hisab management',
        'Priority support',
      ]),
    },
    {
      name: 'growth',
      label: 'Growth',
      durationDays: 30,
      price: 25000,
      features: JSON.stringify([
        '1 Admin account',
        '2 Agent accounts',
        'All 5 markets supported',
        'WhatsApp parser + chart generation',
        'Khatri & hisab management',
        'Priority support',
        'Audit trail & user activity logs',
      ]),
    },
    {
      name: 'business',
      label: 'Business',
      durationDays: 30,
      price: 35000,
      features: JSON.stringify([
        '1 Admin account',
        '4 Agent accounts',
        'All 5 markets supported',
        'WhatsApp parser + chart generation',
        'Khatri & hisab management',
        'Priority support',
        'Audit trail & user activity logs',
        'Parser exception management',
        'Chart revision history',
      ]),
    },
  ]
  for (const p of plans) {
    await prisma.subscriptionPlan.upsert({
      where: { name: p.name },
      update: { label: p.label, durationDays: p.durationDays, price: p.price, features: p.features, isActive: true },
      create: p,
    })
  }
  console.log('✅ Subscription plans seeded (trial=2 days, starter=15k, growth=25k, business=35k)')

  // ── Deactivate legacy plans that are no longer sold ──
  // Old plans (monthly ₹999, quarterly, semi_annual, annual) are kept in the
  // DB for historical billing records but marked inactive so they don't show
  // on the pricing page.
  const legacyPlanNames = ['monthly', 'quarterly', 'semi_annual', 'annual']
  for (const name of legacyPlanNames) {
    await prisma.subscriptionPlan.updateMany({
      where: { name, NOT: { name: { in: ['trial', 'starter', 'growth', 'business'] } } },
      data: { isActive: false },
    })
  }

  // Seed user1 permissions (can view all inventory codes)
  const allCodes = await prisma.inventoryCode.findMany()
  const user1 = await prisma.user.findUnique({ where: { username: 'user1' } })
  if (user1) {
    for (const ic of allCodes) {
      await prisma.userPermission.upsert({
        where: {
          userId_inventoryCode: {
            userId: user1.id,
            inventoryCode: ic.code,
          }
        },
        update: {},
        create: {
          userId: user1.id,
          inventoryCode: ic.code,
          canView: true,
          canEdit: false,
          canDelete: false,
        },
      })
    }
  }
  console.log('✅ User1 permissions seeded')

  console.log('🎉 Seeding complete!')
}

main()
  .catch(e => { console.error('❌ Seed error:', e); process.exit(1) })
  .finally(() => prisma.$disconnect())
