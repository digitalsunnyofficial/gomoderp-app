import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // @napi-rs/canvas ships platform-specific native binaries as optional deps —
  // they must be loaded by the Node resolver at runtime, not bundled by Turbopack.
  serverExternalPackages: ["@napi-rs/canvas"],
  allowedDevOrigins: [
    "127.0.0.1",
    "localhost",
    "*.space-z.ai",
    ".space-z.ai",
    "preview-chat-da6d991d-e9ec-4acd-831e-876d3414d7ba.space-z.ai",
  ],
};

export default nextConfig;
