# ERP + CUSTOMER APP — SYSTEM DOCUMENTATION

**Project:** Satta Matka God ERP / Hisab System + Satta Matka God Customer App
**Document version:** 1.0 · Generated from a full codebase audit (all routes, pages, models, engines inspected)
**Status vocabulary:** IMPLEMENTED · PARTIALLY IMPLEMENTED · NOT IMPLEMENTED · PLANNED · NEEDS VERIFICATION

---

## 1. EXECUTIVE OVERVIEW

The system is a two-sided matka (satta/betting) bookkeeping and operations platform:

- **Admin ERP (`/merp`)** — a role-based single-page application used by the operator's back office to manage markets, inventory codes, card entries ("vyapar"), customers (vendors), settlements (hisab), parser configuration, subscriptions and the customer-app back office (bids, results, payments, games, allocations).
- **Customer App (`/app`)** — a mobile-phone-styled web app used by customers to register (approval-gated), view live markets with countdown timers, place bets across 28 game types (single digit, jodi, panna families, motors, charts, Sangam A/B, combined Family Chart), deposit/withdraw money against a business UPI QR, and receive result announcements with personal win/loss status.

**Who uses the system**

| Actor | Entry point | What they do |
|---|---|---|
| Super Admin (`role=super`) | `/merp` | Full control: users, markets, results, payments, games, allocations, parser, subscriptions |
| Manager (`role=manager`) | `/merp` | Delegated operations: entries, bids, results declare, customers, agents |
| Agent / User (`role=user`) | `/merp` or device access link | Customer (vendor) bookkeeping and entries within assigned markets |
| Customer | `/app` (Bearer session) | Bets, wallet, deposits/withdrawals, results, notifications |
| Scheduler (internal) | `instrumentation.ts` | Auto open/close markets every 60 s per IST windows |

**How the ERP and the Customer App communicate:** they do **not** talk to each other directly. Both are clients of the same Next.js server and the same SQLite database. The ERP acts through `/api/app-admin/*` + classic ERP APIs (cookie session); the app acts through `/api/customer-app/*` (Bearer AppSession). Admin actions (approve deposit, declare result, toggle market) land in the DB and reach the app through the app's 15-second polling loop — no push channel is implemented.

---

## 2. SYSTEM ARCHITECTURE

```
        Admin / ERP (SPA at /merp, cookie session)
                 │  fetch + x-user-* headers
                 ▼
        Next.js 16 server (src/app/api/**)
        ├── src/proxy.ts ................ auth gate for ALL /api/* (signed erp_session cookie)
        ├── /api/customer-app/** ........ customer app APIs (Bearer AppSession, public prefix)
        ├── /api/app-admin/** ........... ERP-side app management (cookie session)
        ├── classic ERP APIs ............ users, vendors, inventories, settlements, payments…
        ▼                                ▼
        Business logic libraries (src/lib/**)
        ├── matka/entry-parser.ts ....... unified text parser (Smart Entry)
        ├── matka/games-engine.ts ....... 28-game catalog + expansion
        ├── matka/app-engine.ts ......... IST clock, windows, rates, settlement predicates
        ├── matka/games.ts .............. ERP game/rate tables
        ├── market-cron.ts .............. scheduled→open→closed lifecycle
        ├── app-auth.ts ................. Bearer sessions + atomic wallet moves
        ▼
        Prisma 6 → SQLite (db/custom.db, 35 models)
        ▲
        Customer App (SPA at /app, Bearer token) — 15 s polling keeps views in sync
```

**Key architectural facts**

- The ERP is one huge client SPA: `src/app/merp/page.tsx` (~6,600 lines) hosts the legacy WhatsApp parser v5, the `CardInventoryPage` and the app shell with a `PageName` → component switch. Hash-based routing (`#/dashboard` etc.) is synced through `src/lib/cache-cookies.ts`.
- The Customer App is a separate SPA (`src/components/customerapp/**`, mounted at `/app`) with its own injected CSS (`shell.tsx`), screen state machine, and Bearer-token API wrapper.
- **Single-device enforcement** for ERP users (except super): an in-memory `userId → sid` registry in `src/proxy.ts` rejects a second device. Registry resets on server restart (documented limitation).
- **Market cron**: `src/instrumentation.ts` registers a 60 s interval that calls `marketCronTick()` (`src/lib/market-cron.ts`), flipping `AppMarket.marketStatus` between `scheduled / open / closed` from weekly timings + bet-closing minutes and pruning expired app sessions. `/api/cron/markets` allows manual/external triggering (key-guarded).
- **Real-time behaviour** = polling only (ERP pages refetch on action; app polls `me`+`home` every 15 s; countdowns recompute client-side every 1 s).

---

## 3. TECHNOLOGY STACK

Read from `package.json` / lockfile — not guessed.

| Layer | Technology | Version |
|---|---|---|
| Framework | Next.js (App Router, Turbopack dev, `output: "standalone"`) | ^16.1.1 |
| Language | TypeScript (build errors ignored by config) | ^5 |
| UI runtime | React | ^19 |
| ORM / DB | Prisma + SQLite (`db/custom.db`) | ^6.11.1 |
| Styling | Tailwind CSS v4 (`@tailwindcss/postcss`) + `tw-animate-css` | ^4 |
| Components | shadcn/ui on Radix primitives (40+ `src/components/ui/*`) | latest |
| State | Zustand (`src/lib/store.ts`) | ^5.0.6 |
| Auth | Custom signed-cookie session (HMAC-SHA256) + Bearer AppSession; bcryptjs hashing | bcryptjs ^3.0.3 |
| Icons / charts | lucide-react, recharts | ^0.525 / ^2.15 |
| Package manager | bun (bun.lock present; npm scripts also work) | — |
| Testing | Custom bun script suites (no unit-test framework) | — |
| Deployment | `next build` → standalone server (`bun .next/standalone/server.js`), Caddyfile provided | — |

Notable config: `next.config.ts` sets `typescript.ignoreBuildErrors: true`, `reactStrictMode: false`, `allowedDevOrigins` for the preview domain. Root layout (`src/app/layout.tsx`) loads Sora / Noto Sans / JetBrains Mono fonts and registers the market scheduler via `src/instrumentation.ts`.

---

## 4. USER ROLES

**ERP (`User` model)** — role values: `super`, `manager`, `user` (legacy `master` is read-compatible via `src/lib/roles.ts`).

| Capability | super | manager | user |
|---|---|---|---|
| Full nav (NAV_ITEMS_MASTER) | ✔ | — | — |
| Create/declare results, payments, allocations, QR | ✔ | partial (declare + markets read) | — |
| System Users management | ✔ | — | — |
| Entries within assigned markets | ✔ | ✔ | ✔ |
| Customer (vendor) list | ✔ | ✔ | ✔ |
| Password view (plaintext) | ✔ | — | — |
| Approval of pending signups | ✔ | own agents only | — |

Signup paths: `/api/auth/signup` (public) creates `pending_approval` users assigned to manager `admin2`; agents can alternatively be activated by a passwordless device-bound access link (`/agent/access/<token>`). Status lifecycle: `pending_approval → active` (or `rejected`); soft-delete = lock (`isLocked`).

**Customer App (`AppCustomer` model)** — self-signup creates `approvalStatus=pending` with **no session**; ERP Super Admin approves/rejects (`/api/app-admin/customers`). Blocked or pending customers fail Bearer auth. Each customer has wallet, language (en/hi/gu/mr), flags (`canBet`, `canWithdraw`).

---

## 5. APPLICATION STRUCTURE

| Route | File | Role |
|---|---|---|
| `/` | `src/app/page.tsx` | Promotional landing (static, indigo). CTAs → `/merp`. |
| `/landing` | `src/app/landing/page.tsx` | Config-driven marketing page (`/api/landing-config` GET + plans). |
| `/marketing` | `src/app/marketing/page.tsx` | **Dead route** — referenced nowhere (NOT IMPLEMENTED wiring). |
| `/merp` | `src/app/merp/page.tsx` | The ERP SPA (see §6). |
| `/app` | `src/app/app/page.tsx` | Mounts `CustomerApp` (see §7). |
| `/agent/access/[token]` | `src/app/agent/access/[token]/page.tsx` | Agent link activation → stores user → redirects to `/merp`. |
| `/api/**` | `src/app/api/**` | ~50 route handlers (§19). |

**ERP shell mechanics** (`src/app/merp/page.tsx` → `HomePage`):

- Boot: reads `localStorage.erp_user` → `useAppStore.login()`; validates subscription via `/api/user-subscriptions/check` (non-super without active subscription → `paywall` page).
- `PageName` registry (35 values, `src/lib/store.ts`); sidebar nav per role from `src/lib/navigation.ts` (8–9 sections); URL hash kept in sync; mobile viewport switches to `MobilePages.tsx` components (`MobileDashboardPage`, `MobileNewCardPage`, etc.).
- `renderPage()` switch maps every `PageName` → page component (§6).
- Embedded in the same file: **WhatsApp Parser v5** (19 grammar patterns, lines ~200–1500, used by legacy entry flows) and **`CardInventoryPage`** (card view: chart grids, entry editing, chart canvas generator, export).

**Shared UI** (`src/components/shared-ui.tsx`): `SectionCard`, `FormField`, `FormInput`, `FormSelect`, `GoldButton`, `OutlineButton`, `BlueButton`, `Pagination`, `Modal` — reused by all ERP pages.

---

## 6. ADMIN PAGES

All pages follow the same data pattern: `apiFetch()` (`src/lib/api-helpers.ts`) with cookie + `x-user-*` headers → JSON render. Access = nav visibility per role (§4). Business logic lives server-side; pages hold no rules beyond presentation.

| Page (PageName) | File | Purpose / Main actions | APIs | Models |
|---|---|---|---|---|
| Dashboard `dashboard` | DashboardPage.tsx | KPIs (entries, settlements, customers), donut, recent entries; app KPIs via app-admin dashboard | `/api/dashboard`, `/api/app-admin/dashboard` | Inventory, Settlement, Vendor, AppBet… |
| Smart Entry `unified-entry` | UnifiedEntryPage.tsx | One textarea → unified parser (§11); live 5-panel preview (Single/Double/Mix/Common/Groups); unknown-label "Teach" UI; submit creates entries | `/api/inventories`, `/api/parser-terms`, `/api/parser-exceptions` | Inventory, DsInventory, TripleInventory, ParserTerm, ParserException |
| New Entry `inv-new` | NewInventoryPage.tsx | Manual single entry creation; then opens card view | `/api/inventory-codes`, `/api/inventories` | InventoryCode, Inventory |
| Entry List `inv-list` | InventoryListPage.tsx | Paginated/searchable entries; open card view | `/api/inventories` | Inventory |
| App Bids `app-bids` | AppAdminPages.tsx | All customer bids (filters); **Declare Result & Settle** modal (open/close panna, IST date); **Market Charts** panel with Copy-WhatsApp-Chart | `/api/app-admin/bets`, `/results`, `/market-charts`, `/charts` | AppBet, AppResult, AppMarket |
| Admin/Agent List `hierarchy-managers` / `hierarchy-agents` | HierarchyPages.tsx | Team hierarchy lists, lock/unlock, delete, agent access links | `/api/users`, `/api/agents`, `/api/agents/[id]/access-link` | User, AgentAccessLink |
| System Users `sys-mgmt-users` (also legacy `users`) | SystemMgmtPages.tsx | Create/edit users, permissions per inventory code, assigned markets, password view/edit (super), lock | `/api/users`, `/api/users/[id]/permissions`, `/markets`, `/lock` | User, UserPermission |
| Customer List `vendor` | CustomerListPages.tsx | **Unified directory**: App Customers tab (approve/reject, block, wallet adjust, password reset, 360° detail modal) + ERP Customers tab (embedded VendorPage) | `/api/app-admin/customers`, `/customers/detail`, `/api/vendors` | AppCustomer, Vendor + bet/fund/ledger models |
| Locked / Pending Users `sys-mgmt-locked` / `sys-mgmt-pending` | SystemMgmtPages.tsx | Unlock; approve/reject signups | `/api/users/[id]/lock`, `/api/users/pending`, `/api/users/[id]/approve` | User |
| Markets `configure` | SystemMgmtPages.tsx (`ConfigurePage`) + MarketsPages.tsx (`AppMarketsSection`) | ERP inventory codes CRUD **and** the app-market manager: Add Market (Name + Phase Day/Night + Session Open/Close/Both + timings + bet-closing minutes, live identity preview "Main Bazaar Day Open"), weekly 7-day schedule editor, master ON/OFF switch, live status chips | `/api/inventory-codes`, `/api/app-admin/markets` | InventoryCode, AppMarket |
| Market Results `market-results` | MarketsPages.tsx (`MarketResultsPage`) | Declare/update single market open+close panna; auto digit + jodi derivation (e.g. `124-71-470`); **DECLARED AT** timestamp column; partial declares | `/api/app-admin/results` | AppResult, AppBet |
| Game Management `game-management` | GamesPages.tsx | 28-game catalog (category, base type, session, rate, on/off) | `/api/app-admin/games` | Game |
| Game Allocation `game-allocation` | GamesPages.tsx | Per-market matrix: enable game, override rate + min points — drives the app play screen tabs | `/api/app-admin/allocation` | GameAllocation |
| Market Permissions `sys-mgmt-markets` | SystemMgmtPages.tsx | Grant users access to specific markets (`assignedMarkets`) | `/api/users/[id]/markets` | User |
| New Hisab `sett-new` / Hisab Records `sett-list` | SettlementPages.tsx | Manual settlement records per market (win/loss accounting) | `/api/settlements` | Settlement |
| Customer Hisab `vendor-sett` | VendorPage.tsx (`VendorSettlementPage`) | Per-customer hisab summary | `/api/vendors`, `/api/settlements` | Vendor, Settlement |
| Payment Management `app-funds` | AppAdminPages.tsx (`FundRequestsPage` + `QrSettingsSection`) | Deposits approve/reject (credits wallet + ledger + notification); withdrawals paid/reject(refund); **Business QR tab** (upload QR ≤1.5 MB, UPI id, payee, min deposit, note) | `/api/app-admin/funds`, `/withdrawals`, `/payment-settings` | AppFundRequest, AppWithdrawRequest, AppPaymentSetting, AppTransaction |
| User Activity `sys-mgmt-activity` | SystemMgmtPages.tsx | Audit trail + summary | `/api/activities` | UserActivity |
| Parser Exceptions / Configurations `sys-mgmt-parser-ex` / `sys-mgmt-parser-cfg` | SystemMgmtPages.tsx | Unparsed-token triage; parser pattern/separator CRUD | `/api/parser-exceptions`, `/api/parser-config` | ParserException, ParserPattern, ParserSeparator |
| Chart Revision `sys-mgmt-chart-revs` | SystemMgmtPages.tsx | History of chart saves/edits/shares | `/api/chart-revisions` | ChartRevision |
| Plan / User Subscriptions / Payment `sub-plans` / `sub-users` / `sub-payments` | SubscriptionPages.tsx | Subscription plans CRUD; assign subscriptions; payment records (activates subscription) | `/api/subscription-plans`, `/api/user-subscriptions`, `/api/payments` | SubscriptionPlan, UserSubscription, Payment |
| Paywall `paywall` | SubscriptionPages.tsx | Shown when subscription check fails (non-super) | `/api/user-subscriptions/check` | UserSubscription |
| Landing Config `landing-config` | LandingConfigPage.tsx | JSON-per-section editor for `/landing`. ⚠️ PARTIALLY IMPLEMENTED: no nav item — reachable only by URL hash | `/api/landing-config` | LandingConfig |

Dead page files (never imported, kept for reference): `AppAdminPages2.tsx` (duplicate MarketResultsPage, Universes, AppCharts), `AppAdminPages3.tsx` (Winning/Payout/Content/Withdraw variants), `AppAdminPages4.tsx` (Games/Timings variants — referenced the removed broken `/api/app-admin/games/allocate`), `AppAdminPages5.tsx` (Payment/Customer360 variants). See §26.

Uses the shared **Unified Parser** (§11), **Bet Validation** (§12) and **Declare+Settle** (§15/§16) services — documented once there.

---

## 7. CUSTOMER APP PAGES

Mounted at `/app` (`src/app/app/page.tsx` → `src/components/customerapp/CustomerApp.tsx`). Phone-frame UI, own CSS injected from `shell.tsx` (~230 lines), i18n via `src/lib/matka/i18n.ts` (EN/हिन्दी/ગુજરાતી/मराठी, `t(lang,key)` with English fallback).

**Auth & tokens:** Bearer token in `localStorage.mb_token` (`TOKEN_KEY`); `appApi()` wrapper injects the header; 401 → clears token → back to `login`. Sessions are `AppSession` rows with 90-day sliding expiry.

**Screen flow (actual implementation):**

```
splash (1.4 s) → token check (/me)
   ├─ no language yet → lang (LangAskView) ─┐
   ├─ no token → login → (signup → await)   │
   └─ token valid → home ◀──────────────────┘
home ⇄ play (per market) ⇄ starline
home ⇄ mybets · results · wallet · profile · notifs
```

Bottom nav: home · starline · mybets · results · profile (hidden on play/starline).

| Screen | Purpose | APIs |
|---|---|---|
| splash / lang | Brand splash; first-run language chooser (also reachable from profile) | `/me` PATCH language |
| login / signup / await | Mobile+password login; self-signup (→ `pending`, no session); AwaitApprovalView | `/auth/login`, `/auth/signup` |
| home | Notice bar, 5 s rotating banners, **market cards** (OPEN TIME/CLOSE TIME badges, result pill `019-04-347`, live status bar with 1-second countdown "closes in H:MM:SS", RESULT OUT / MARKET CLOSED / MARKET OFF states), starline next-hour card, personal day summary | `/home` |
| play | Per-market betting: Open/Close session tabs (session-specific markets fix one tab), green **TIME LEFT** countdown pill, **icon-card game tab grid** (unique lucide icon per game via `GAME_ICONS` + rate badge), number grid + **live chart preview** (slip membership highlighted), bet slip (in-flow card — overlap bug fixed), WhatsApp **PasteModal** (parse → review → merge-by-sum), **SeedGamePanel** (motor/family/chart seeds → CALCULATE → expansion rows) | `/bets`, `/home` |
| starline | Hourly games, bulk add across hours, 1 s hour countdown | `/bets`, `/home` |
| mybets | Bid history with game labels + status chips | `/bets` |
| results | Jodi chart / Panel chart / Starline board (35 days) | `/results` |
| wallet | Balance, last 100 ledger rows, pending deposit/withdraw | `/wallet` |
| profile | Language switcher, password change, logout | `/me` PATCH |
| notifs | Personal + broadcast notifications (latest 50) | `/notifications` |

**Modals:** `ConfirmModal` (slip submit), `DepositModal` (business QR image, payee, UPI copy, min deposit, UTR required), `WithdrawModal` (respects `canWithdraw`, min ₹500), `PasswordModal`, `PasteModal`, `SeedGamePanel`, `ClosedModal` (big centered red prompt — market closed/off; play screen unreachable), `ResultPrompt` (big centered result announcement: pill + digit derivation; **"YOU WON ₹x" / "BETTER LUCK NEXT TIME"** when the customer had bids on that market; results-only note otherwise; shown once per market+day via `localStorage.mb_seen_results`, keeps last 100 keys).

**Real-time sync:** `refreshCustomer()` + `refreshHome()` every **15 s** on all main screens → admin changes (approval, wallet credit, result declare, market toggle) appear without manual refresh. Countdowns recompute client-side every **1 s** (`secsLeftToClose` IST, minus `betClosingMinutes`, via `fmtCountdown`).

---

## 8. MARKET MANAGEMENT

**Two market systems coexist (by design):**

1. **ERP inventory codes** (`InventoryCode`) — the classic bookkeeping markets used by entries/settlements. Managed in Markets page (top section).
2. **App markets** (`AppMarket`) — the customer-app betting markets. This is the full-featured system:

| Field | Meaning |
|---|---|
| `code` | slug, auto-derived from identity combo (e.g. `main_bazaar_day_open`) |
| `name` | Market Name (e.g. "Main Bazaar") |
| `phase` | `day` \| `night` |
| `session` | `open` \| `close` \| `both` (classic market) |
| `openTime` / `closeTime` | "HH:MM" (AM/PM pickers in UI) |
| `betClosingMinutes` | stop accepting bets N minutes before close (e.g. Shridevi closes betting 5 min before 11:30 declaration) |
| `isOn` | master ON/OFF power switch |
| `weeklySchedule` | JSON per-day `{on, open, close}` (0=Sunday) — Kalyan Sunday off, Shridevi Sunday special 17:30 |
| `marketStatus` | cron-maintained: `scheduled` → `open` → `closed` (also `off`) |
| `category` | `main` \| `starline` (starline = hourly markets `st0..st23`) |

**Identity rule:** display name = `marketDisplayName(name, phase, session)` — anti-duplication ("Milan Day" stays "Milan Day"; a session-specific record renders "Main Bazaar Day Open"). Duplicate Name+Phase+Session combos are rejected (409) at creation/edit.

**Creation flow (ERP Markets → Add Market):** Name + Phase + Session + bet closing minutes + open/close times → live identity preview → POST `/api/app-admin/markets` (super) → validation of window sanity → market appears with status chip; cron takes over the lifecycle.

**Inventory allocation to markets:** app games are attached to markets through `GameAllocation` (per market × game: active flag, rate override, min points) — this drives the app play-screen tabs. ERP-side market access for staff is `User.assignedMarkets` CSV + `UserPermission` rows per inventory code.

**Status summary:** IMPLEMENTED (weekly timings, bet closing minutes, cron lifecycle, phase/session model, weekly-off days, master switch). NOT IMPLEMENTED: per-market announcement text templates; automatic result randomization.

---

## 9. INVENTORY

The ERP bookkeeping inventory (classic hierarchy):

```
InventoryCode (market/chart code, e.g. "kalyan-single")
   └── Inventory (one card entry: header totals, uploadedBy, market)
         ├── DsInventory      (Double-Single rows: digit pairs + amounts)
         └── TripleInventory  (Triple rows: panna + amount + type group)
```

- Types surfaced by the entry layer: **Single, Double, Triple → Mix, Common, Group** (22 group options incl. **SP, DP, TP, SPDP, SPTP, DPTP, SPDPTP, Motor, SP Motor, DP Motor, 20/30/40/50/60/70/90 DP/90 ABR charts, Family Sets 4/6/8 + combined Family Chart**) — see `src/lib/matka/group-types.ts` + `term-registry.ts`.
- Card View (`CardInventoryPage` in `merp/page.tsx`) renders digit-column chart grids per type, grand totals, edit-entry modal, and a canvas chart generator (share image).
- **Recompute rule:** DS/Triple row writes recompute parent `Inventory` totals server-side (`/api/double-single-inventories`, `/api/triple-inventories`).
- The **chart** concept: a market's inventory aggregated digit-wise — the same shape reused by app "Market Charts" (`/api/app-admin/market-charts`) and the app's live chart preview.

No second inventory architecture exists for the app — app bets are stored as `AppBet` rows (per game/number/points) and aggregated on demand. Status: IMPLEMENTED.

---

## 10. TRANSACTION / VYAPAR FLOW

The project's word for a transaction is **entry** (ERP bookkeeping) or **bid** (customer app bet). One centralized rule set applies to every input channel:

```
Input (Smart Entry text | manual form | app slip | pasted WhatsApp text)
   → Normalize (term-registry: synonyms → canonical; number tokens cleaned)
   → Identify Customer (ERP: session/user; App: Bearer AppCustomer)
   → Identify Market (inventory code | AppMarket code + slot)
   → Identify Session (ERP: single chart | App: open/close/starline-hour)
   → Parse (unified entry parser §11 / parseQuickData for app paste)
   → Validate (§12: windows, closing minutes, result lockout, min points, wallet)
   → Business Rules (§20)
   → Create Transaction (ERP: Inventory+DS+Triple rows · App: AppBet rows + AppTransaction ledger)
   → Update Inventory (server recompute of parent totals | chart aggregation on read)
   → Settlement (§16)
```

**Single-source guarantees in the code:**

- All text parsing goes through `src/lib/matka/entry-parser.ts` + `term-registry.ts` (Smart Entry) — the legacy inline parser v5 inside `merp/page.tsx` remains only for the old entry components; app paste uses `parseQuickData` in `app-engine.ts` which reuses the same classification helpers.
- All app bet creation goes through **one** handler: `POST /api/customer-app/bets` — atomic wallet debit inside `$transaction` (`wallet >= total` guard) + per-bet ledger rows. No parallel bet-creation path exists.
- All settlement of app bets goes through **one** engine: `betWins`/`starBetWins` + declare endpoint (§15/§16).

---

## 11. PARSER

**One parser library** — `src/lib/matka/entry-parser.ts` + `src/lib/matka/term-registry.ts` (canonical categories, 100+ synonym terms, exact-match lookup, custom-term override via `ParserTerm` table). Regression-proofed by `scripts/test-entry-parser.ts` (51 checks).

- **Supported formats:** bare header lines (`Motor -`), inline labels (`SP - 1,2,5 = 100`), longest-prefix known-label matching, numeric-label dash guards (`50 - 128=75` is a chart label; `50,60,70=100` stays numbers), comma chains, jodi/panna auto-classification (app paste).
- **Example (operator's real case):** SP `1,2,5=100` → 3 single rows; DP `12,13@50` → 2 double rows; `Motor 13467` → 60 panna rows (motor = all 3-digit arrangements of the seed, classified SP/DP/TP) → merged by sum.
- **Expansion registry (`EXPANDER_REGISTRY`):** motor C(n,3) arrangements, family sets (dedup, set-type mismatch explanation), cut charts, 16 group charts (`group-expanders.ts` + `group-batch-engine.ts`, batch up to 10 seeds).
- **Output:** normalized rows `{type, number, points}` merged by sum; previewed live in Smart Entry before submit.
- **Validation & errors:** unknown labels are **never mis-filed** — held back, reported, and recorded in `ParserException` (kind: `skipped`/`dropped`); one-click "Teach" saves a new `ParserTerm` and re-parses instantly.
- **Legacy parser v5** (inside `merp/page.tsx`, ~1300 lines, 19 patterns) serves the old card-entry flows; consolidation into the unified parser is a recommended future task (§27), not done silently.

---

## 12. VALIDATION

App bet validation chain (single source: `POST /api/customer-app/bets`) — applied per slip item, in order:

1. Slip not empty; amounts positive; game type in `VALID_MAIN` / `VALID_STAR`.
2. `canBet` flag + fresh customer fetch (blocked customers rejected even mid-session).
3. Min points: 10 default, or `GameAllocation.minPoints` for allocated games.
4. Starline: hour 0–23, `slot==='open'` only, `starHourAccepting(hour)`.
5. Main market: exists + active; weekly schedule window for today (`marketWindowToday`, includes master `isOn` OFF kill-switch; weekly-off day blocks with clear message).
6. **Result-declared lockout:** any `AppResult` for (market, today) blocks all betting for that market.
7. **Bet closing minutes:** `slotAccepting(openTime, closeTime, slot, now, betClosingMinutes)` on the IST clock (`istClock`) — e.g. Shridevi 11:30 close with `betClosingMinutes=5` stops accepting at 11:25.
8. Atomic wallet debit: `updateMany({ wallet: { gte: total } }, { decrement })` inside `$transaction` → zero-partial-write guarantees; failure surfaces as insufficient-balance error.

Deposit validation: min deposit from `AppPaymentSetting.minDeposit` (default ₹100), UTR required. Withdrawal: min ₹500, `canWithdraw` flag, amount held from wallet immediately (`AppWithdrawRequest` + ledger row), refunded on reject.

ERP-side validation: parser holdback (§11), market access checks (`assignedMarkets`, `UserPermission`), inventory-code integrity on entry creation.

---

## 13. WHATSAPP

WhatsApp is an **input/output channel**, never a second brain:

**Input (IMPLEMENTED — copy-paste):**
```
WhatsApp message → user pastes into Smart Entry (ERP) or PasteModal (app)
   → unified parser / parseQuickData (same classification helpers)
   → same validation (§12 for app; §11 holdback for ERP)
   → same transaction creation (§10)
   → review table (app) or 5-panel preview (ERP) → confirm
```

**Output (IMPLEMENTED — chart sharing):** `/api/app-admin/market-charts` aggregates a market's bets (slot → type → number, sorted by points) and renders a **WhatsApp-ready text** block with a one-click "Copy WhatsApp Chart" button in App Bids. **2026-09 addition:** the same API now returns `boards` — the three **master charts per market (Single 0-9 / Double-Jodi 00-99 / Triple panna grid**, each with Open + Close sub-boards, 10 ank columns, pannas aggregated by digit-set and displayed in the operator's canonical chart spelling) — plus `typeSummary`, the per-game-type entry calculation (bids, staked, won, pending, net = staked − won) for win/loss management. Every app order feeds these boards automatically: seed games (SP/DP Motor, Family Chart, 20-90 charts) expand to standard sp/dp/tp rows at placement, so the master charts update exactly like pasted WhatsApp data.

**NOT IMPLEMENTED:** WhatsApp webhook/Cloud API integration (no inbound webhook route, no outbound send). The webhook flow would be: `Webhook → customer identification (phone) → market/session selection → existing parser → existing validation → existing bet logic → reply`. Extension point §27. Duplicate-message dedup rule (BR-013) is specified but only enforceable once a webhook exists.

---

## 14. OCR

**NOT IMPLEMENTED.** No OCR library, route, or model exists in the codebase.

Related implemented feature: **voice dictation** for ERP text inputs (`src/components/SpeechToTextButton.tsx` + `src/lib/speech-dictation.ts`, Web Speech API) — feeds the same text pipelines. If OCR is added later it must terminate in the existing parser + validation (§10 diagram), never a separate engine.

---

## 15. RESULT

Single flow (source: `POST /api/app-admin/results`, super-only; UI: Market Results page + App Bids declare modal):

```
Declare (marketCode, resultDate?, openPanna?, closePanna?)
   → panna validation (isValidPanna, 3-digit)
   → upsert one AppResult row per market+date (partial declares: open now, close later)
   → declaredAt timestamp stored (full datetime, shown in ERP "DECLARED AT" and app prompts)
   → derive digits: openDigit = digitSum(openPanna) mod 10, closeDigit likewise
   → jodi = openDigit+closeDigit (e.g. 124 → 7, 470 → 1 → jodi 71; displayed "124-71-470")
   → settle every now-decidable pending bet (§16)
   → broadcast notification to ALL active+approved customers (winners additionally get a personal winning notification)
```

Starline markets declare exactly one panna (stored as `openPanna`). After declaration, the market/date is betting-locked (BR-006) and the app card flips to RESULT OUT with a trophy button; the ResultPrompt auto-pops within one 15 s poll.

---

## 16. SETTLEMENT

Two distinct, coexisting meanings — both implemented once:

1. **App bet settlement (automatic, engine-driven):** predicates `betWins`/`starBetWins` in `src/lib/matka/app-engine.ts` decide each bet against the declared result by game type (single/jodi/SP/DP/TP/HS-A/HS-B/FS/allocated games). SP/DP/TP panna comparisons are **digit-set based** (`pannaMatches`/`pannaKey` in `chart-definitions.ts`) so the app grid spelling ("038") and the operator chart spelling ("380") settle identically; `isValidPanna` is permutation-tolerant for the same reason. Undecided bets (e.g. close-slot or jodi before close declaration) stay pending. Winners are credited `points × rate` (allocation-driven rate) via `appWalletMove` + `AppTransaction` ledger + notification; losers marked lost. Verified example: Shridevi 023/019 → 1 winner ₹900; SP Motor 60-bid slip → 1 won ₹1,400 / 59 lost.
2. **ERP hisab (manual records):** `Settlement` rows per market created/edited by staff (`/api/settlements`) — the bookkeeping side, independent of app bets.

No duplicate winning-calculation exists; the app play screen and ERP both read the same engine for previews.

---

## 17. BALANCE

**Customer wallet (the only money balance):** `AppCustomer.wallet` — every movement is paired with an `AppTransaction` ledger row through `appWalletMove()` (`src/lib/app-auth.ts`), atomic inside transactions.

| Movement | Trigger | Ledger |
|---|---|---|
| Debit | bet placement (§12) | negative row per bet |
| Credit | deposit approved (Payment Management) | positive row + notification |
| Credit | bet won (§16) | positive row |
| Hold | withdrawal request | negative row (refund on reject) |
| Manual | admin wallet adjust (+/−) with note | row + notification |

Deposits start as `AppFundRequest` (customer submits amount + UTR against the business QR); approval is super-only in Payment Management. Withdrawals are `AppWithdrawRequest` with `paid`/`reject(refund)` outcomes. `1 point = ₹1` is the displayed conversion.

**ERP side has no wallet:** staff see totals (inventory) and manual hisab records (§16). The legacy `Payment` model belongs to ERP user **subscriptions**, not customer money.

---

## 18. DATABASE

SQLite via Prisma (`db/custom.db`). Schema: `prisma/schema.prisma` — **35 models**, no migration history (workflow is `prisma db push`; see README). Connection resolves relative `file:` URLs to absolute paths (`src/lib/db.ts`) so the standalone build finds the DB. Seeds: `prisma/seed.js` (ERP users/codes/plans) and `scripts/seed-app.js` (production app seed: markets with weekly schedules, 28 games, 24 allocations per market, 5 demo customers, payment settings, welcome notifications).

**ERP models:** `User` (roles, lock, `assignedMarkets` CSV, `passwordPlain` intentional super-view column), `UserPermission`, `UserSession`, `AgentAccessLink` (passwordless agent links; SHA-256 token hash, device binding, revoke/expiry), `InventoryCode`, `Inventory`, `DsInventory`, `TripleInventory`, `Vendor`, `Settlement`, `UserActivity`, `ChartRevision`, `ParserException`, `ParserPattern`, `ParserSeparator`, `ParserTerm`, `ParserLearningLog`, `SubscriptionPlan`, `UserSubscription`, `Payment`, `LandingConfig`.

**App models:** `AppCustomer` (wallet, language, approvalStatus, canBet/canWithdraw), `AppSession` (Bearer), `AppMarket` (§8), `Game`, `GameAllocation`, `AppBet` (market, slot, gameCode, number, points, rate, status), `AppResult` (open/close panna + digits + jodi + declaredAt), `AppTransaction` (ledger), `AppFundRequest`, `AppWithdrawRequest`, `AppNotification`, `AppConfig`, `AppPaymentSetting` (singleton: QR, UPI, payee, minDeposit).

Key relations: `User → UserPermission` (per inventory code), `User → User` (manager self-relation "TeamMembers"), `Inventory → DsInventory/TripleInventory`, `AppCustomer → AppSession/AppBet/AppTransaction/...`, `AppMarket → AppBet/AppResult/GameAllocation`, `Game → GameAllocation`. Deletion of a user sets audit FKs to null (SetNull) preserving history.

---

## 19. APIs

**One API reference table.** Auth legend: **PUB** public · **SES** ERP cookie session (proxy-gated) · **ROLE** SES + in-handler role header check (`x-user-*`/`x-session-*`) · **APP** customer Bearer AppSession · **CRON** key-guarded.

| Method | Route | Purpose | Auth | Main models/service |
|---|---|---|---|---|
| POST | /api/auth | ERP login (bcrypt/plaintext, lock+approval checks, single-device registry, 7-day trial) | PUB | User, UserSession |
| POST | /api/auth/signup | Public agent signup → pending_approval | PUB | User |
| POST | /api/auth/logout · GET /check-session · POST /register-session | Session lifecycle | PUB | UserSession |
| GET | /api/auth/validate | Session echo from proxy headers | SES | — |
| GET/POST | /api/users | List (isolation; passwordPlain super-only) / create user | SES / ROLE(super,manager) | User, UserPermission |
| GET/PUT/DELETE | /api/users/[id] | Detail / update (password+role super-only) / soft-lock delete | SES | User |
| POST/DELETE | /api/users/[id]/approve · /lock | Approve/reject; lock/unlock | ROLE | User |
| GET/PUT | /api/users/[id]/markets · /permissions | Market assignment; per-code permissions | SES | User, UserPermission |
| GET | /api/users/pending | Pending signups (manager sees own agents) | ROLE | User |
| GET | /api/agents · POST /api/agents/[id]/access-link | Hierarchy agents; device-bound access link | SES | User, AgentAccessLink |
| GET | /api/agent/access/[token] | Passwordless link activation | PUB (token-validated) | AgentAccessLink, User, UserSession |
| GET/POST | /api/vendors · GET/PUT/DELETE /api/vendors/[id] · PUT /[id]/agent | ERP customers (vendors) CRUD + reassign | SES | Vendor |
| GET/POST | /api/inventories · /[id] | Card entries + isolation by market/creator | SES | Inventory, InventoryCode |
| GET/POST | /api/double-single-inventories · /[id] | DS rows + parent recompute | SES | DsInventory |
| GET/POST | /api/triple-inventories · /[id] | Triple rows + parent recompute | SES | TripleInventory |
| GET/POST | /api/inventory-codes | Chart codes CRUD | SES | InventoryCode |
| GET/POST | /api/settlements · /[id] | Manual hisab records | SES | Settlement |
| GET | /api/dashboard · /api/managers/stats | ERP dashboard; team stats | SES/ROLE | Inventory, Settlement, Vendor |
| GET/POST | /api/parser-config · /api/parser-exceptions · /[id] · /api/parser-terms | Parser pattern/separator/exception/term management | SES | ParserPattern, ParserException, ParserTerm |
| GET/POST | /api/chart-revisions | Chart revision log | SES | ChartRevision |
| GET | /api/activities · /api/user-activity | Audit trail (activities is the gated reader) | SES/ROLE | UserActivity |
| GET/POST/PUT/DELETE | /api/subscription-plans · /api/user-subscriptions · /[id] · /check · /api/payments · /[id] | Subscription system + payments (activates subscription) | SES (plans GET public) | SubscriptionPlan, UserSubscription, Payment |
| GET/POST | /api/landing-config | Marketing config (GET public; POST requires real ERP session cookie) | PUB GET / SES POST | LandingConfig |
| GET | /api/health · /api/diagnose-db | Health check; DB diagnostics | PUB / SES | — |
| POST | /api/customer-app/auth/login · /signup · /logout | App auth (pending signup has no session; login blocks pending/rejected) | PUB | AppCustomer, AppSession |
| GET/PATCH | /api/customer-app/me | Profile; PATCH language / password | APP | AppCustomer |
| GET | /api/customer-app/home | Whole home screen (markets, windows, results, games, day summary) | APP | AppMarket, AppResult, Game, GameAllocation, AppBet |
| GET/POST | /api/customer-app/bets | My bids / place slip (full validation chain §12) | APP | AppBet, AppTransaction |
| GET | /api/customer-app/results | 35-day results / starline board | APP | AppResult |
| GET | /api/customer-app/wallet | Balance + ledger + pending money | APP | AppTransaction, AppFundRequest, AppWithdrawRequest |
| GET/POST | /api/customer-app/funds · /withdrawals | Deposit request (min+UTR); withdrawals (hold) | APP | AppFundRequest, AppWithdrawRequest |
| GET | /api/customer-app/payment-qr · /notifications | Business QR; notifications (latest 50) | APP | AppPaymentSetting, AppNotification |
| GET | /api/app-admin/dashboard · /bets · /charts | Combined desk; bids; aggregate charts | SES | AppBet, AppResult, … |
| GET/POST/PATCH | /api/app-admin/markets | Markets CRUD (phase/session/weekly/closing-minutes; duplicate-identity guard) | SES (write: super) | AppMarket |
| GET/POST | /api/app-admin/results | Declare + settle (§15) | SES (POST: super) | AppResult, AppBet, AppTransaction |
| GET | /api/app-admin/market-charts · /customers/detail · /customers/[id] | WhatsApp chart text; 360° customer aggregates | SES | AppBet, AppCustomer, … |
| GET/PATCH/POST | /api/app-admin/customers | Unified customer directory (approve/reject/block/reset/wallet) | SES (write: super) | AppCustomer, AppSession |
| GET/POST | /api/app-admin/funds · /withdrawals · /payments | Deposit approve/reject; withdrawal paid/reject | SES (POST: super) | AppFundRequest, AppWithdrawRequest, AppTransaction |
| GET/PATCH | /api/app-admin/games | 28-game catalog (auto-heals from code) | SES (PATCH: super) | Game |
| GET/POST | /api/app-admin/allocation | Per-market game allocation matrix | SES (POST: super) | GameAllocation |
| GET/POST | /api/app-admin/payment-settings · /config | Business QR singleton; app config | SES (write: super) | AppPaymentSetting, AppConfig |
| GET | /api/app-admin/cron · GET/POST /api/cron/markets | Cron status; manual tick | SES / CRON | AppMarket |

Removed during this audit: `/api/app-admin/games/allocate` — a guaranteed-broken duplicate of `/api/app-admin/allocation` (referenced a non-existent `MarketGame` model; its only consumer was dead page code). See §26.

Dead/unreachable (kept, documented): `/api/subscriptions` (always 401 — parses the signed cookie as JSON), `/api/_proxy/[...path]` (legacy Laravel passthrough, no longer rewritten).

---

## 20. BUSINESS RULES

One centralized list. Rules confirmed by code (route handlers / engines).

| ID | Rule | Enforced in |
|---|---|---|
| BR-001 | A market must be `active`/ON before accepting transactions; master `isOn` OFF kills all app betting | bets route, `marketWindowToday` |
| BR-002 | A closed market (outside weekly window or cron `closed`) must reject new bets with a clear message | bets route, cron |
| BR-003 | Betting stops `betClosingMinutes` before market close (IST clock) | `slotAccepting` |
| BR-004 | Once a result is declared for (market, date), all further betting for that market+date is blocked | bets route |
| BR-005 | Unknown customers are never auto-created or auto-mapped: ERP vendors are staff-created; app customers self-signup but require admin approval before any session | signup routes |
| BR-006 | Pending/rejected/blocked customers cannot authenticate (ERP lock/approval; app Bearer checks each call) | auth libs |
| BR-007 | Bet total is debited atomically — no bet exists without sufficient wallet (`wallet >= total` guard in the same transaction) | bets route |
| BR-008 | Every wallet movement writes exactly one ledger row (`AppTransaction`) | `appWalletMove` |
| BR-009 | Deposits require UTR and respect configured min deposit; withdrawals min ₹500 and are held from balance immediately, refunded on reject | funds/withdrawals routes |
| BR-010 | `1 point = ₹1` across display and settlement | engine + UI |
| BR-011 | Result declaration requires a valid 3-digit panna; jodi/digits are derived, never hand-entered | results route |
| BR-012 | Winners are credited `points × rate` where rate comes from `GameAllocation` when the game is allocated, else the game default | settle logic |
| BR-013 | Undecidable bets (close-slot / jodi / HS / FS / TP before close declaration) remain pending until the close panna exists | settle predicates |
| BR-014 | A declared result is upserted once per market+date (partial open→close declares merge into one row); `declaredAt` is always stored | results route |
| BR-015 | Unknown parser labels are never silently mis-filed — they are held back, reported, and recorded as ParserExceptions | entry-parser |
| BR-016 | Duplicate market identity (Name+Phase+Session) is rejected | markets route |
| BR-017 | Only Super Admin can change user passwords and roles; only super/manager can create system users | users routes |
| BR-018 | ERP data isolation: users see entries/settlements/vendors of their hierarchy and assigned markets only; super sees all | dashboard/vendors/inventories routes |
| BR-019 | Single-device login for non-super ERP users (latest session wins) | proxy registry |
| BR-020 | App market identity = Name + Phase (Day/Night) + Session (Open/Close/Both); display name never duplicates phase/session words | `marketDisplayName` |

---

## 21. ERROR HANDLING

One taxonomy; every API returns `{ error }` with an appropriate status; the frontends surface it via toast/error states.

| Class | Cases | Behaviour |
|---|---|---|
| Invalid input | missing fields, non-numeric digits, invalid panna, malformed amounts | 400 with specific message (e.g. `"Open panna \"12\" is not a valid 3-digit panna"`) |
| Invalid market | unknown marketCode, starline misuse | 400 |
| Market closed | outside window / weekly off / master OFF / closing minutes passed / result declared | 400/403 with distinct messages surfaced on the app (ClosedModal, red countdown, locked banner) |
| Unknown customer | bad token, blocked, pending | 401 (app clears token → login), ERP 403 |
| Duplicate transaction | duplicate username (409), duplicate market identity (409) | 409 |
| Insufficient funds | wallet < total | 400 insufficient-balance message; slip stays intact client-side |
| Auth failure | bad credentials, expired session, second device | 401; ERP frontend clears `erp_user` → login |
| Authorization failure | non-super hitting super-only mutation | 403 |
| Parser failure | unknown labels/numbers | never throws — holdback + ParserException + UI "Teach" (BR-015) |
| API/DB failure | handler exception | 500 `{error}` + server log; DB-not-ready during boot tolerated by cron (silent retry) |
| WhatsApp failure | N/A (no webhook) — paste parse errors surface as line-level error rows in review tables | non-blocking |
| OCR failure | N/A (not implemented) | — |

Known quirks documented in §26: `check-session` fails open on DB error; some parser/audit routes are session-gated but lack role checks (any ERP session may write parser patterns/audit rows).

---

## 22. END-TO-END EXAMPLES

1. **Customer App → Transaction → Inventory (chart):** Rahul logs in (`/api/customer-app/auth/login` → Bearer) → home shows Shridevi OPEN, countdown ticking → play screen → game tab "SP Motor" (icon card, rate ×90) → seed `13467`, 10 pts → CALCULATE → 60 rows preview → add to slip → ConfirmModal → `POST /bets` (validation §12, wallet −600, 60 `AppBet` rows) → ERP App Bids → Market Charts → "Copy WhatsApp Chart" shows one merged Shridevi chart (digit/jodi/panna sections, totals).
2. **WhatsApp → Parser → Transaction:** operator pastes `Motor -\n13467 = 10` into Smart Entry → term-registry recognizes "Motor" → expander produces 60 panna rows merged by sum → live preview shows groups + total ₹36,750 → submit → Inventory + TripleInventory(type=group Motor Pana) rows → Card View chart.
3. **Invalid transaction → rejection:** customer tries single `118` on a SP tab → client-side classification rejects ("118 is a DP") before any call; server re-validates independently (BR-007 chain) — belt and braces.
4. **Market closed → rejection:** Kalyan at 23:59 with `betClosingMinutes=10` → cron set `closed` at 23:50 → app card shows red MARKET CLOSED, click opens ClosedModal (play unreachable); a direct `POST /bets` still fails server-side (BR-002/003).
5. **Result → Settlement → Balance:** ERP declares Kalyan `019 / 347` → digits 0/4, jodi 04, `declaredAt` stored → 1 winning jodi bet (₹100 × 90) credited ₹900 + personal notification, losers marked, broadcast sent → all customers' home flips RESULT OUT within 15 s; Rahul's ResultPrompt shows "YOU WON ₹900" with declared time; his wallet + ledger reflect the credit; further Kalyan bets now blocked (BR-004).

---

## 23. CODE MAP

```
Market Management (app)
  src/components/pages/MarketsPages.tsx (AppMarketsSection, weekly editor)
  → /api/app-admin/markets
  → src/lib/market-cron.ts · src/lib/matka/app-engine.ts (windows, countdowns)
  → AppMarket (weeklySchedule, betClosingMinutes, phase, session)

Game System
  src/components/pages/GamesPages.tsx (catalog + allocation matrix)
  → /api/app-admin/games · /api/app-admin/allocation
  → src/lib/matka/games-engine.ts (28-game expansion; reuses group-expanders,
    chart-definitions, panna-family)
  → Game, GameAllocation → drives app play tabs (PlayScreens.tsx)

Entries / Parser (ERP)
  src/components/pages/UnifiedEntryPage.tsx (Smart Entry) · NewInventoryPage · InventoryListPage
  → /api/inventories · /api/double-single-inventories · /api/triple-inventories · /api/parser-terms
  → src/lib/matka/entry-parser.ts · term-registry.ts · group-batch-engine.ts
  → Inventory, DsInventory, TripleInventory, ParserTerm, ParserException

Customer App Bets
  src/components/customerapp/{CustomerApp,PlayScreens,shell}.tsx
  → /api/customer-app/bets (+ /home polling every 15 s)
  → src/lib/app-auth.ts (Bearer, appWalletMove) · src/lib/matka/app-engine.ts
  → AppBet, AppTransaction, AppCustomer

Results & Settlement
  src/components/pages/{MarketsPages (MarketResultsPage), AppAdminPages (AppBidsPage)}.tsx
  → /api/app-admin/results · /api/app-admin/market-charts
  → app-engine.ts (deriveDigit, betWins, starBetWins)
  → AppResult, AppBet, AppTransaction, AppNotification

Payments
  src/components/pages/AppAdminPages.tsx (FundRequestsPage + QrSettingsSection)
  → /api/app-admin/funds · /withdrawals · /payment-settings · /api/customer-app/payment-qr
  → AppFundRequest, AppWithdrawRequest, AppPaymentSetting, AppTransaction

Customers (unified)
  src/components/pages/CustomerListPages.tsx (UnifiedCustomerListPage)
  → /api/app-admin/customers (+ /detail) · /api/vendors
  → AppCustomer, Vendor, AppSession, UserActivity

Auth
  src/app/api/auth/** · src/proxy.ts (gate + single-device) · src/lib/{session,auth,roles,audit,hierarchy-auth}.ts
  src/app/api/customer-app/auth/** · src/lib/app-auth.ts
  → User, UserSession, AgentAccessLink · AppCustomer, AppSession
```

---

## 24. TESTING

**Automated regression suites (bun scripts):**

| Suite | Command | Checks |
|---|---|---|
| Unified parser | `bun scripts/test-entry-parser.ts` | 51 — labels, expansions, merge-by-sum, guards, operator's real example |
| Games engine | `bun scripts/test-games-engine.ts` | 68 — SP/DP/TP/HS-A/HS-B/FS/Odd-Even/Motors/Family Sets + combined Family Chart/canonical charts/20-40 charts incl. "20 chart ank1 exact table" + digit-set settlement |

**Manual/E2E (agent-browser + curl, recorded in worklog):** ERP login (production accounts), Smart Entry submit → DB rows, app signup → approval → login, bet placement (main + starline + seed games), declare + settle (open/close, jodi derivation, notifications), deposit approve → wallet + ledger, withdrawal hold/refund, market create with identity, weekly schedule round-trip, master toggle, cron state flips, WhatsApp chart text, app i18n flow, result prompt, closed market modal, countdown timers, mobile ERP pages.

**Verification performed for this documentation (see §26 change summary):** parser 51/51 ✓, games 23/23 ✓, **production build `next build` PASSED** (all routes compiled, standalone artifact produced), dev server boot + health endpoint ✓, ERP login + app-admin API behaviour ✓ (incl. runtime proof that proxy-set `x-session-*` headers reach route handlers: a super-only GET returned 200 with the session cookie alone), customer app login + home (9 markets with phase/session identity) ✓, privilege guards (user-create 403 for plain role / 201 for super) ✓, browser E2E on both apps with **zero console/page errors**.

**2026-09 chart-architecture update — re-verification (see worklog Task 9):** games engine 68/68 ✓ (canonical SP/DP charts 120/90, 20/30/40 chart exact-table assertions, combined Family Chart, HS-B, digit-set settlement), parser 51/51 ✓, `tsc --noEmit` clean on all touched files ✓, E2E API flow ✓ (new games served to app → chart-20/hsb/single/jodi bets placed → master boards aggregate → result declared '137' settles SP winners by digit-set → '380' operator spelling accepted by validator), browser E2E ✓ (game carousel horizontal scroll + snap, 20 Chart expansion = exact operator rows, Family Chart 123 → 8 pannas, Half Sangam B panel → slip → confirm → POST 200, ERP Master Charts boards + Game-Type Win/Loss table, Game Management lists all 28 games, zero console/page errors on both apps), family-set allocations retired by seed (21 rows) with the combined Family Chart allocated instead.

Two additional runtime bugs were surfaced by this testing and fixed (details §26): a broken `TPD` import in `src/lib/matka/games.ts` that 500'd every route importing it (cron, health cascade), and the missing `AgentAccessLink` table that crashed the agent access-link feature at runtime.

**No unit-test framework** (jest/vitest) is configured — the bun suites are the regression baseline. Adding a test runner is an extension point (§27).

---

## 25. CURRENT STATUS

| Module | Status | Notes |
|---|---|---|
| Customer App | 🟢 | Login/i18n/home/play/starline/wallet/results/notifs; polling sync; countdowns; result prompt; closed modal |
| Admin ERP | 🟢 | All 25+ pages render; role-based nav; mobile fallback; paywall gate |
| Market | 🟢 | Market Management v2 — single source for ERP + Game; formula markets (18 session records seeded 2026-09-26); no built-ins; delete supported; phase Day/Night/None; Starlines CRUD (AppStarline); weekly timings, bet-closing minutes, cron lifecycle, master switch |
| Jodi & Panel Chart | 🟢 | Backend backfill input (`/api/app-admin/chart-data`) — silent AppResult upserts for past dates; app Results/Jodi/Panel charts fill instantly; Jodi Chart month navigation |
| ERP Mirror | 🟢 | App bets auto-mirrored to ERP inventories (`erp-mirror.ts`) — Entry List + ERP single/double/triple charts include app vyapar; master boards aggregate BOTH channels |
| Inventory | 🟢 | Codes + entries + DS/Triple rows + recompute + card view charts |
| Parser | 🟢 | Unified parser + term registry + teach loop; 51-check suite; legacy v5 still in merp (documented) |
| Transaction | 🟢 | One bet path (atomic), one entry path per channel, shared validation |
| Result | 🟢 | Results UI split — Market Results vs Starline Results sections; declare/update, partial declares, digits+jodi derivation, declaredAt, lockout; starline declare board + history |
| Settlement | 🟢 | Engine-driven app settlement + manual ERP hisab |
| Balance/Ledger | 🟢 | Atomic wallet + full ledger + deposits/withdrawals holds |
| WhatsApp | 🟡 | Copy-paste input + chart-text output IMPLEMENTED; webhook automation NOT IMPLEMENTED |
| OCR | 🔴 | Not implemented (voice dictation exists as related feature) |
| Reports | 🟡 | Dashboards + market charts + customer 360 IMPLEMENTED; dedicated report exports NOT IMPLEMENTED (dead page variants only) |
| Notifications | 🟢 | In-app (personal + broadcast); no push/SMS |
| Subscriptions | 🟢 | Plans, assignment, paywall gate, payments |
| Audit | 🟢 | UserActivity on all mutations; reader UI; ⚠️ some writers lack role checks (§26) |
| Tests | 🟡 | Two bun regression suites (74 checks) + `scripts/e2e-market-v2.ts` (48 checks) green; no framework/E2E harness |

---

### 25.1 Change record — 2026-09-26 (Market Management v2 + operator list)

1. **Triple section restructure** — the "Group" umbrella dropdown is gone. The Triple section offers direct items: Mix, Common, SP, DP, TP, SPDP, SPTP, DPTP, SPDPTP, Motor Pana, SP Motor, DP Motor, 20/30/40/50/60/70 Chart, 90 DP Chart, 90 ABR Chart, Family Chart, **Half Sangam A, Half Sangam B, Full Sangam** (new ERP sangam inputs; composite nums "X-PPP"/"PPP-X"/"PPP-QQQ" stored as TripleInventory type `sangam`, skipped by position grids by design).
2. **Market Management = single source for ERP + Game.** All legacy markets removed; the exact operator list seeded via the formula Name+Phase+Session — Sridevi Day/Night × Open/Close, Time Bazaar Day Open/Close, Milan Day/Night × Open/Close, Kalyan Open/Close (phase None), Main Bazaar Day/Night × Open/Close, Rajdhani Night Open/Close (18 records). No built-in markets — Add Market builds any further market by the same formula; DELETE removes a market + its allocations.
3. **Starlines management** — new AppStarline model + `/api/app-admin/starlines` CRUD + ERP "Starlines" page. One or many starlines, each with result time (hour:minute), bet-closing minutes, ON/OFF. Betting on `st<hour>` honors the config; when any starline is configured, unconfigured hours are rejected. Declaring lives in the Starline Results section.
4. **Results UI split** — "Results" page now has two separate sections: Market Results (panna declare + auto-derivation + settle + history) and Starline Results (single-panna declare + today board + history).
5. **Jodi & Panel chart data input** — new "Jodi & Panel Chart Data" ERP page + `/api/app-admin/chart-data`: paste `date, open panna, close panna` lines per market; silent AppResult upserts (no settlement/notifications) for PAST dates only; digits+jodi derived (137→1, 347→4, jodi 14). The app's Results, Jodi Chart (now with month navigation) and Panel Chart fill instantly.
6. **App-bets → ERP mirror** — every placed bet is mirrored into the ERP inventory system (`erp-mirror.ts`, inside the placement flow, best-effort): panna bets → TripleInventory rows, single/jodi → DoubleSingleInventory rows (`double` type for jodis), sangam → TripleInventory type `sangam`; rows attributed to the primary super account with the real customer in the details text. App vyapar therefore appears in ERP Entry List AND the ERP charts; the master single/double/triple boards in Market Charts aggregate BOTH channels (app bets + ERP inventory rows for the same market+date, `app_<code>` inventory codes auto-created).
7. **App home** — 18 market cards with formula identities (SRIDEVI DAY OPEN … KALYAN OPEN/RAJDHANI NIGHT OPEN); starline screen renders configured starline names/times and minute-precision acceptance.

---

## 26. KNOWN ISSUES

**Fixed during this audit (minimal safe changes — see final change summary):**

1. `/agent/access/[token]` redirected to the promo page `/` instead of the ERP → fixed to `/merp`.
2. Agent link activation was blocked by the proxy session gate (feature could never work) → `/api/agent/access` added to public prefixes (route itself validates the token).
3. `GET/PUT /api/users/[id]` leaked `passwordPlain` to any session → now super-only (matches list route policy); `PUT` role changes now super-only; `POST /api/users` now super/manager-only (privilege-escalation guard); create response no longer echoes `passwordPlain`.
4. `POST /api/landing-config` was publicly writable with spoofable headers → now requires a real ERP session cookie server-side.
5. Removed `/api/app-admin/games/allocate` — guaranteed 500 (referenced non-existent `MarketGame` model), duplicate of `/api/app-admin/allocation`, zero live consumers.
6. `src/lib/matka/games.ts` imported a non-existent `TPD` export from `app-engine.ts` — a real compile-breaker that 500'd `/api/app-admin/cron` (and any route importing `cron.ts`/`games.ts`). Fixed to the existing `TP` digit-indexed triple chart (semantics verified: `TP[d]` is the triple whose derived digit is `d`).
7. The `AgentAccessLink` Prisma model was missing from the schema while two routes (`/api/agents/[id]/access-link`, `/api/agent/access/[token]`) reference it — the agent access-link feature crashed at runtime (`TypeError: Cannot read properties of undefined`). Model reconstructed from its exact usage (tokenHash unique, device binding, revoke/expiry, issued-by) and pushed to the DB; activation now returns clean 401s and link generation works.

**Open (documented, intentionally NOT changed to avoid risk):**

- **Header-trust identity (⚠️ architectural):** in-handler role checks read client-supplied `x-user-*` / `x-session-*` headers (set by `apiFetch` from localStorage). The signed cookie is the real gate at the proxy; forged headers could elevate an authenticated session. Hardening = verify session server-side per handler (pattern already used in `landing-config` POST) — recommended roadmap item, touching ~40 routes.
- ~~NEEDS VERIFICATION (runtime):~~ **VERIFIED at runtime:** proxy-set `x-session-*` headers DO reach route handlers in this Next.js version (super-only `/api/app-admin/cron` returned 200 with the session cookie alone, no client headers). The header-trust caveat below still applies to the `x-user-*` headers the ERP client sets itself.
- Dead code kept for reference: `AppAdminPages2–5.tsx` (~2,300 lines, never imported), orphaned `GroupBatchInput/Preview` imports in `merp/page.tsx`, dead `/marketing` route, unused `showChart`/`selectedInventoryForChart` store fields, unreachable-from-nav pages `landing-config` and legacy `app-customers`/`hierarchy-customers` (mobile-only).
- Duplicated legacy paths: inline parser v5 vs unified parser; `/api/app-admin/payments` vs `/api/app-admin/funds` (two deposit-approve entries); `AppCustomersPage` superseded by `UnifiedCustomerListPage`.
- `/api/subscriptions` (always 401) and `/api/_proxy/[...path]` (unreachable) are dead routes.
- Misc: cron key defaults to `mb-cron` (set `CRON_SECRET` in production); `/api/auth/register-session` is public (could overwrite a user's single-device registry entry); `check-session` fails open on DB error; `User.passwordPlain` plaintext column is an intentional super feature but is a risk surface; single-device registry is in-memory (resets on restart); root layout title says "Hisab System" while branding elsewhere says "Satta Matka God ERP"; circular import `NewInventoryPage ⇄ merp/page.tsx` (works via ESM hoisting).
- `typescript.ignoreBuildErrors: true` masks type errors — keep an eye on runtime contracts.

---

## 27. FUTURE EXTENSION POINTS

1. **Auth hardening** — replace header-trust role checks with server-side session verification (`getSessionFromRequest`) per handler; move single-device registry to DB; add rate limiting to login endpoints.
2. **WhatsApp webhook** — inbound channel per §13 diagram reusing parser + validation + bet service; outbound notifications via Cloud API; dedup by message id (BR-013 enforcement).
3. **OCR intake** — image → text → existing parser (§14); candidate: tesseract via a server route feeding Smart Entry preview.
4. **Payments gateway** — replace manual UTR approval with a UPI collect/PSP callback; keep `AppFundRequest` as the ledger source; auto-credit on callback.
5. **Consolidation sweep** — delete dead files (`AppAdminPages2–5`, `/marketing`), finish consolidating parser v5 into the unified parser, merge the duplicate deposit-approve paths, wire or drop `landing-config` nav, remove unused store fields.
6. **Tests & CI** — adopt vitest, port the bun suites, add API integration tests (bets validation chain, settlement engine) and Playwright E2E for login→bet→declare→wallet.
7. **Prisma migrations** — introduce `prisma migrate` alongside `db push` once the schema stabilizes for production change history.
8. **Push channel** — replace/augment 15 s polling with SSE/WebSocket for result prompts and market status flips (examples/websocket scaffolding exists).
9. **Reporting** — exportable winning/bet/payout reports (the dead page variants show the intended shapes).
10. **Config** — require strong `SESSION_SECRET` and `CRON_SECRET` in production; strip `passwordPlain` entirely if the password-view feature is ever retired.
