# Satta Matka God — Native Android Customer App (Expo / React Native)

Build a **true native Android app** (real Android widgets — no WebView) from the
same backend that powers the ERP and the web customer app. One backend, one
database, one source of truth.

```
┌────────────────────────────┐        ┌──────────────────────────────┐
│  Native app (this folder)  │  Bearer│  Next.js backend (erp/)      │
│  Login · Markets · Bids    │ ──────▶│  /api/customer-app/*         │
│  Wallet · Deposit · Push   │  token │  ERP /merp stays web-only    │
└────────────────────────────┘        └──────────────────────────────┘
```

The customer session is a DB-backed opaque token (`AppSession`) returned by
`/api/customer-app/auth/login` and sent as `Authorization: Bearer <token>` —
the same API the web app uses, so accounts, wallets, markets and bids are
identical across web and native.

## Screens (native — full customer app, v3 UI-PARITY)

**v3 = UI PARITY BUILD.** Every screen below is a faithful React Native
conversion of the web customer app (`/app`) — same purple/pink gradient,
white cards, gold action buttons, bottom navigation, language selector,
banners, marquee notice, market cards with live status bars, same modals.
The web customer app is the ONLY UI source of truth; nothing is re-designed.

| Screen | What the customer gets |
|---|---|
| Splash / Login / Register | Purple→pink brand gradient, frosted logo, white card forms, pre-login language chips (EN/HI/GU/MR), approval-pending wall |
| Language ask | Post-login language selection (same list as the web `LangAskView`) |
| Home | Gradient appbar (name · mobile, bell + gold dot), wallet chip + ADD POINTS, scrolling notice marquee, auto-rotating banner, Main Markets with **MarketCard v2** (open/close time badges, result pill, play round-button, live status bar + countdown), Starline card, latest results |
| Market (play) | Sub-bar with wallet chip, Open/Close session tabs, live countdown pill, **game tabs from the ERP allocation**, rate bar + WhatsApp paste, tiles grids (single/jodi/SP/DP/TP), ank chips, sangam pickers, seed + ank-family panels with live expansion preview, chart preview, bet slip + confirm |
| Starline | Hour strip (24 games, DECLARED/PLAYING/NEXT), rate bar, countdown, declared result, single-digit grid, slip |
| **Results & Charts** | Results / **Jodi chart** (month calendar, red = repeating jodi, month navigation) / **Panel chart** / **Starline** 24-hour board with LIVE highlight |
| **My Bids** | ALL / PENDING / WON / LOST filter chips with counts, bet cards, auto-refresh when the ERP settles results |
| Wallet | Gradient wallet card, **pending deposit & withdrawal requests**, full ledger with colored txn icons |
| Deposit (modal) | Business QR image, UPI copy button, method picker, UTR submission |
| Withdraw (modal) | Request payout (min ₹500, hold semantics), disabled-state notice |
| Result prompts | Big centered "MARKET CLOSED" and "RESULT DECLARED" cards with win/loss summary (web-exact) |
| Profile | Initials avatar, status chips, agent line, settings rows (My Bids, Notifications, Language, Change Password), logout |
| Notifications | In-app history + push (deposit/withdrawal/result/win) |

---

## 1. Prerequisites (build machine)

| Tool | Why | Get it |
|------|-----|--------|
| Node.js 20+ | JS tooling | nodejs.org |
| JDK 17 | Android build | `winget install Microsoft.OpenJDK.17` / adoptium.net |
| Android SDK | gradle, platform tools | Install **Android Studio** once (installs SDK); afterwards you never need to open it |

Set `JAVA_HOME` to the JDK 17 folder and make sure `java -version` says 17.

## 2. Install & first run

```bash
cd satta-matka-god-native
npm install
npx expo install --fix     # aligns every dependency to the installed Expo SDK
```

Point the app at your backend — edit **app.json → expo.extra.apiBase**:

| Where the backend runs | apiBase value |
|---|---|
| Android emulator + backend on your PC | `http://10.0.2.2:3000` (default) |
| Real phone + backend on your PC | `http://<your-PC-LAN-IP>:3000` |
| Production server | `https://your-domain.com` ← required for release |

Then run in dev (Expo Go or emulator):

```bash
npx expo start            # scan QR / press a  → development
```

Log in with any customer from the backend (demo: Rakesh Sharma 9876500001 /
password from the ERP demo seed) — you should see the markets, wallet and
bid placement running against the real backend.

## 3. Push notifications (one-time, ~15 min)

Push travels: **backend → Expo Push API → Firebase (FCM) → device**.
The backend needs NO Firebase keys; the app needs a Firebase config:

1. `npm i -g eas-cli && npx eas init` — prints a project ID.
   Put it in **app.json → expo.extra.eas.projectId**.
2. console.firebase.google.com → create project "Satta Matka God" →
   Project settings → add Android app with package **com.sattamatkagod.app** →
   download **google-services.json** → put it in **this project root**.
3. Enable **Firebase Cloud Messaging API (V1)** in the Firebase console
   (Cloud Messaging tab) and upload the service account when prompted.

Without these steps the app still works; push is silently skipped.

The server already fires pushes on: deposit approved/rejected, withdrawal
paid/rejected, result declared (broadcast), win credited, payout reversal.
Kill switch: set `PUSH_ENABLED=false` in the backend `.env`.

## 4. Build the APK

### 4a. Test build (debug — your phone only)

```bash
npm run prebuild                    # generates android/ from app.json
cd android && ./gradlew assembleDebug
# → android/app/build/outputs/apk/debug/app-debug.apk
```

### 4b. Release build (the one customers get)

Generate a keystore ONCE and keep it safe (lose it = customers must
uninstall/reinstall on every update):

```bash
keytool -genkey -v -keystore sattamatkagod.keystore -alias sattamatkagod \
  -keyalg RSA -keysize 2048 -validity 10000
```

Edit `android/app/build.gradle`:

```gradle
android {
  signingConfigs { release {
      storeFile file("../../sattamatkagod.keystore")
      storePassword "YOUR_STORE_PASSWORD"
      keyAlias "sattamatkagod"
      keyPassword "YOUR_KEY_PASSWORD"
  } }
  buildTypes { release { signingConfig signingConfigs.release
      minifyEnabled false } }
}
```

**Before every release build:**
- app.json: `apiBase` → your production domain (HTTPS)
- app.json: bump `version` (1.0.1, 1.0.2 …) and `android.versionCode` (+1)
- `npm run prebuild` regenerates android/ with the new config

```bash
cd android && ./gradlew assembleRelease
# → android/app/build/outputs/apk/release/app-release.apk   (~15-25 MB native)
```

## 5. Publish to the download landing page

1. Copy `app-release.apk` into the BACKEND project:
   `erp-customer-app/public/downloads/satta-matka-god.apk` (exact filename)
2. In the backend edit `src/components/public/DownloadCta.tsx` → `APP_VERSION`
   to match the app version, redeploy the backend.
3. The landing page's gold **Download App (APK)** button now serves it.

## 6. Troubleshooting

| Symptom | Fix |
|---|---|
| `EADDRINUSE` when testing backend | kill the old server: `pkill -f "next dev"` |
| App can't reach backend on phone | PC firewall blocks :3000 — allow Node; use LAN IP not localhost |
| `getExpoPushTokenAsync` errors | projectId missing in app.json, or google-services.json not added |
| Push arrives but not while app closed | release build only foreground-quits behavior — normal in debug |
| gradle "SDK location not found" | open `android/` once in Android Studio, or create `android/local.properties` with `sdk.dir=<path>` |
| White screen in release | apiBase still points to 10.0.2.2 — set the production domain and rebuild |
