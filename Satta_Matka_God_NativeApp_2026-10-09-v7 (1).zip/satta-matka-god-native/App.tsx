// ──────────────────────────────────────────────────────────
// SATTA MATKA GOD — NATIVE CUSTOMER APP (Expo / React Native)
// UI PARITY BUILD: this is a screen-by-screen RN conversion of
// the existing web customer app (src/components/customerapp/*)
// — same state machine, same bottom nav, same modals, same
// design system. The web app is the ONLY UI source of truth.
// ──────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { BackHandler, Pressable, Text, View } from 'react-native'
import { StatusBar } from 'expo-status-bar'
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context'
import { useFonts } from '@expo-google-fonts/inter'
import {
  Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold, Inter_800ExtraBold,
} from '@expo-google-fonts/inter'
import { Sora_600SemiBold, Sora_700Bold, Sora_800ExtraBold } from '@expo-google-fonts/sora'
import * as SecureStore from 'expo-secure-store'
import { AuthProvider, useAuth } from './src/auth'
import { api, setApiToken, type Customer, type HomeData, type Market, type SlipEntry } from './src/lib/api'
import { registerPush } from './src/lib/push'
import { I, Toast, fmt } from './src/ui'
import { C, F } from './src/theme'
import { t, isLang, type Lang } from './src/lib/matka/i18n'
import { istDate } from './src/lib/matka/app-engine'

import SplashScreen from './src/screens/SplashScreen'
import LoginScreen from './src/screens/LoginScreen'
import RegisterScreen from './src/screens/RegisterScreen'
import { AwaitApprovalScreen, LangAskScreen } from './src/screens/AuthFlowScreens'
import HomeScreen from './src/screens/HomeScreen'
import MarketScreen from './src/screens/MarketScreen'
import StarlineScreen from './src/screens/StarlineScreen'
import MyBidsScreen from './src/screens/MyBidsScreen'
import ResultsScreen from './src/screens/ResultsScreen'
import WalletScreen from './src/screens/WalletScreen'
import { ProfileScreen, NotificationsScreen } from './src/screens/ProfileScreen'
import { DepositModal, WithdrawModal, ConfirmModal, PasswordModal, ClosedModal, ResultPrompt } from './src/screens/Modals'

type Screen = 'splash' | 'login' | 'signup' | 'await' | 'lang' | 'home' | 'play' | 'starline' | 'mybets' | 'results' | 'wallet' | 'profile' | 'notifs'
type ModalType = 'deposit' | 'withdraw' | 'confirm' | 'password' | null
type Prompt = { kind: 'closed' | 'result'; mk: Market } | null

// pre-login UI language lives outside the customer profile (web parity)
let PRE_LANG: Lang = 'en'

function Inner() {
  const { booting, token, customer: authCustomer, logout: authLogout } = useAuth()
  const insets = useSafeAreaInsets() // status-bar / gesture-bar safe insets
  const [bootPhase, setBootPhase] = useState(true) // splash visible
  const [screen, setScreen] = useState<Screen>('splash')
  const [customer, setCustomer] = useState<Customer | null>(null)
  const [home, setHome] = useState<HomeData | null>(null)
  const [marketCode, setMarketCode] = useState<string | null>(null)
  const [starHour, setStarHour] = useState<number | null>(null)
  const [slip, setSlip] = useState<SlipEntry[]>([])
  const [modal, setModal] = useState<ModalType>(null)
  const [prompt, setPrompt] = useState<Prompt>(null)
  const [toast, setToast] = useState<{ msg: string; cls: 'ok' | 'err' | '' } | null>(null)
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [slider, setSlider] = useState(0)
  const [langReturn, setLangReturn] = useState<'' | 'profile'>('')
  const [uiLang, setUiLang] = useState<Lang>(PRE_LANG)
  const [mybetsKey, setMybetsKey] = useState(0) // remount mybets after a slip is placed
  const seenRef = useRef<Set<string>>(new Set())
  const sendingRef = useRef(false)
  const cridRef = useRef<Record<string, string>>({})
  const bootedRef = useRef(false)

  const lang: Lang = isLang(customer?.language) ? (customer!.language as Lang) : uiLang
  const tr = useCallback((key: string) => t(lang, key), [lang])

  const showToast = useCallback((msg: string, cls: 'ok' | 'err' | '' = '') => {
    setToast({ msg, cls })
    if (toastTimer.current) clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToast(null), 3200)
  }, [])

  const go = useCallback((s: string) => { setModal(null); setScreen(s as Screen) }, [])
  const backTo = useCallback((s: string) => { setModal(null); setScreen((s || 'home') as Screen) }, [])

  // ── Android hardware back: navigate INSIDE the app instead of exiting.
  // Back on an inner screen returns home; back on home/login lets the
  // system do its default (exit / nothing). Modals handle their own
  // back via onRequestClose. ──
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (screen === 'play' || screen === 'starline' || screen === 'wallet' ||
          screen === 'notifs' || screen === 'mybets' || screen === 'results' || screen === 'profile') {
        backTo('home'); return true
      }
      if (screen === 'signup') { go('login'); return true }
      if (screen === 'lang' && langReturn === 'profile') { go('profile'); return true }
      return false // home / auth / splash → system default
    })
    return () => sub.remove()
  }, [screen, langReturn, go, backTo])

  const refreshCustomer = useCallback(async () => {
    try {
      const d = await api<{ customer: Customer }>('/api/customer-app/me')
      setCustomer(d.customer)
      return d.customer
    } catch (e) {
      if ((e as Error).message === 'SESSION_EXPIRED') go('login')
      return null
    }
  }, [go])

  const refreshHome = useCallback(async () => {
    try {
      const d = await api<HomeData>('/api/customer-app/home')
      setHome(d)
      if (d.customer) setCustomer(d.customer)
    } catch (e) {
      if ((e as Error).message === 'SESSION_EXPIRED') go('login')
    }
  }, [go])

  // ── Boot: splash ~1.4s → (token? verify : login) — web parity ──
  useEffect(() => {
    if (booting) return
    if (bootedRef.current) return
    bootedRef.current = true
    const tm = setTimeout(async () => {
      if (token) {
        const c = await refreshCustomer()
        if (c) {
          if (!isLang(c.language)) { setScreen('lang'); setLangReturn('') }
          else { setScreen('home'); void refreshHome() }
          setBootPhase(false)
          return
        }
      }
      setScreen('login')
      setBootPhase(false)
    }, 1400)
    return () => clearTimeout(tm)
  }, [booting, token, refreshCustomer, refreshHome])

  // keep the api client's token in sync with the auth provider
  useEffect(() => { setApiToken(token) }, [token])
  useEffect(() => { if (authCustomer && !customer) setCustomer(authCustomer) }, [authCustomer, customer])

  // Home banner slider (5s)
  useEffect(() => {
    if (screen !== 'home' || !home?.banners?.length) return
    const t2 = setInterval(() => setSlider(s => (s + 1) % home.banners.length), 5000)
    return () => clearInterval(t2)
  }, [screen, home?.banners?.length])

  // ── Result announcement prompts (seen keys persist per device) ──
  useEffect(() => {
    void (async () => {
      try {
        const raw = await SecureStore.getItemAsync('mb_seen_results')
        if (raw) seenRef.current = new Set(JSON.parse(raw) as string[])
      } catch { /* fresh device */ }
    })()
  }, [])
  useEffect(() => {
    if (!home || !customer) return
    const today = istDate()
    for (const m of home.markets) {
      if (m.resultDeclared && m.todayResult) {
        const key = m.code + '|' + today + '|' + String((m.todayResult as { updatedAt?: string; declaredAt?: string }).updatedAt || (m.todayResult as { declaredAt?: string }).declaredAt || '')
        if (!seenRef.current.has(key)) {
          seenRef.current.add(key)
          void SecureStore.setItemAsync('mb_seen_results', JSON.stringify([...seenRef.current].slice(-100))).catch(() => {})
          setPrompt({ kind: 'result', mk: m })
          break
        }
      }
    }
  }, [home, customer?.id])

  // ── Real-time sync: light polling every 10 s (web parity) ──
  useEffect(() => {
    if (!customer) return
    if (['splash', 'login', 'signup', 'await', 'lang'].includes(screen)) return
    const t2 = setInterval(() => { void refreshCustomer(); void refreshHome() }, 10000)
    return () => clearInterval(t2)
  }, [screen, customer?.id, refreshCustomer, refreshHome])

  // ── Auth actions ──
  const doLogin = async (mobile: string, password: string) => {
    try {
      const d = await api<{ token: string; customer: Customer }>('/api/customer-app/auth/login', { method: 'POST', body: { mobile, password } })
      setApiToken(d.token)
      await SecureStore.setItemAsync('smg_token', d.token).catch(() => {})
      setCustomer(d.customer)
      void registerPush()
      showToast(t(uiLang, 'welcome_back'), 'ok')
      if (!isLang(d.customer.language)) { setLangReturn(''); go('lang') }
      else { go('home'); void refreshHome() }
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const doSignup = async (name: string, mobile: string, password: string, referral: string) => {
    try {
      const d = await api<{ pendingApproval?: boolean; token?: string; customer?: Customer }>(
        '/api/customer-app/auth/signup', { method: 'POST', body: { name, mobile, password, referral: referral.trim() || undefined } })
      if (d.pendingApproval) { go('await'); return }
      if (d.token && d.customer) {
        setApiToken(d.token)
        await SecureStore.setItemAsync('smg_token', d.token).catch(() => {})
        setCustomer(d.customer)
        void registerPush()
        showToast('Account created — welcome!', 'ok')
        go('home')
        void refreshHome()
      }
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const doLogout = async () => {
    await authLogout()
    setCustomer(null); setHome(null); setSlip([]); setPrompt(null)
    go('login')
  }

  // ── Language selection ──
  const pickLanguage = async (code: Lang) => {
    PRE_LANG = code
    setUiLang(code)
    setCustomer(c => (c ? { ...c, language: code } : c))
    let ok = false
    try {
      await api('/api/customer-app/me', { method: 'PATCH', body: { language: code } })
      ok = true
    } catch { /* silent like the web */ }
    showToast(t(code, 'language_saved'), 'ok')
    if (langReturn === 'profile') go('profile')
    else { go('home'); if (!ok || !home) void refreshHome() }
  }

  // ── Play navigation ──
  const openPlay = (code: string) => { setMarketCode(code); go('play') }
  const openStar = (h: number) => { setStarHour(h); go('starline') }
  const openLangFromProfile = () => { setLangReturn('profile'); go('lang') }

  // ── Slip helpers (web parity: merge-by-key, idempotent clientRequestId) ──
  const setEntry: Parameters<typeof MarketScreen>[0]['setEntry'] = (key, mk, slot, type, num, pts, rate, label, gameCode) => {
    setSlip(prev => {
      const e = prev.find(x => x.key === key)
      if (pts > 0) {
        if (e) return prev.map(x => (x.key === key ? { ...x, pts } : x))
        return [...prev, { key, mk, slot, type, num, pts, rate, label, gameCode: gameCode || null }]
      }
      return prev.filter(x => x.key !== key)
    })
  }
  const removeSlip = (i: number) => setSlip(prev => prev.filter((_, idx) => idx !== i))
  const clearSlip = () => setSlip([])
  const bulkAddToSlip = useCallback((items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => {
    setSlip(prev => {
      let next = [...prev]
      for (const it of items) {
        const key = it.marketCode + '|' + it.slot + '|' + it.type + '|' + it.num
        const idx = next.findIndex(x => x.key === key)
        if (idx >= 0) {
          next = next.map((x, i) => (i === idx ? { ...x, pts: x.pts + it.points } : x))
        } else {
          next.push({ key, mk: it.marketCode, slot: it.slot, type: it.type, num: it.num, pts: it.points, rate: it.rate, label: it.marketName + ' · ' + it.type.toUpperCase() + ' ' + it.num, gameCode: it.gameCode || null })
        }
      }
      return next
    })
  }, [])

  const submitSlip = () => {
    if (!slip.length) return showToast(tr('enter_first'), 'err')
    if (customer && !customer.canBet) return showToast('Betting disabled for your account — contact support', 'err')
    setModal('confirm')
  }

  const confirmBets = async () => {
    if (sendingRef.current) return
    if (!slip.length) return
    sendingRef.current = true
    const total = slip.reduce((a, s) => a + s.pts, 0)
    try {
      const d = await api<{ wallet: number; placedCount: number; duplicates?: number }>('/api/customer-app/bets', {
        method: 'POST',
        body: {
          items: slip.map(s => ({
            marketCode: s.mk, slot: s.slot, type: s.type, num: s.num, points: s.pts,
            gameCode: s.gameCode || undefined,
            clientRequestId: (cridRef.current[s.key] ||= Date.now() + '-' + Math.random().toString(36).slice(2)),
          })),
        },
      })
      setCustomer(c => (c ? { ...c, wallet: d.wallet } : c))
      const dups = d.duplicates || 0
      cridRef.current = {}
      setSlip([]); setModal(null); setScreen('mybets'); setMybetsKey(k => k + 1)
      showToast(d.placedCount + ' ' + tr('placed_toast') + ' ' + fmt(total) + ' ' + tr('debited') + (dups ? ` · ${dups} duplicate(s) ignored` : ''), 'ok')
    } catch (e) {
      setModal(null)
      showToast((e as Error).message, 'err')
      if ((e as Error).message === 'SESSION_EXPIRED') go('login')
    } finally {
      sendingRef.current = false
    }
  }

  // ── Funds / withdrawals / password ──
  const submitDeposit = async (amount: number, method: string, utr: string) => {
    try {
      await api('/api/customer-app/funds', { method: 'POST', body: { amount, method, utr } })
      setModal(null)
      showToast(tr('deposit_done'), 'ok')
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const submitWithdraw = async (amount: number) => {
    try {
      const d = await api<{ wallet: number }>('/api/customer-app/withdrawals', { method: 'POST', body: { amount } })
      setCustomer(c => (c ? { ...c, wallet: d.wallet } : c))
      setModal(null)
      showToast(tr('withdraw_done'), 'ok')
    } catch (e) { showToast((e as Error).message, 'err') }
  }
  const submitPassword = async (oldPassword: string, newPassword: string) => {
    try {
      await api('/api/customer-app/me', { method: 'PATCH', body: { oldPassword, newPassword } })
      setModal(null)
      showToast(tr('password_changed'), 'ok')
    } catch (e) { showToast((e as Error).message, 'err') }
  }

  const [fontsLoaded] = useFonts({
    Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold, Inter_800ExtraBold,
    Sora_600SemiBold, Sora_700Bold, Sora_800ExtraBold,
  })
  if (!fontsLoaded || bootPhase || booting) return <><StatusBar style="light" /><SplashScreen /></>

  // ── Bottom nav — .bnav/.btab (hidden on play/starline like the web) ──
  const shell = !['splash', 'login', 'signup', 'await', 'lang'].includes(screen)
  const navVisible = shell && screen !== 'play' && screen !== 'starline'
  const bottomNav = navVisible ? (
    <View style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      backgroundColor: 'rgba(255,255,255,.97)', borderTopWidth: 1, borderTopColor: C.line,
      flexDirection: 'row', paddingTop: 6, paddingBottom: 8 + insets.bottom,
    }}>
      {([['home', 'home', tr('nav_home')], ['starline', 'star', tr('nav_star')], ['mybets', 'receipt', tr('nav_bids')], ['results', 'trophy', tr('nav_results')], ['profile', 'user', tr('nav_profile')]] as const).map(([id, ic, lb]) => {
        const active = screen === id || (id === 'home' && screen === 'wallet') || (id === 'home' && screen === 'notifs')
        return (
          <Pressable key={id} style={{ flex: 1, alignItems: 'center', gap: 2, paddingVertical: 6 }} onPress={() => go(id)}>
            {active ? <View style={{ position: 'absolute', top: -7, width: 34, height: 3, borderRadius: 99, backgroundColor: C.p2 }} /> : null}
            <I n={ic} size={20} color={active ? C.p2 : C.slate} />
            <Text style={{ fontSize: 9.5, fontWeight: '700', fontFamily: F.bold, color: active ? C.p2 : C.slate }}>{lb}</Text>
          </Pressable>
        )
      })}
    </View>
  ) : null

  let body: React.ReactNode
  if (screen === 'splash') body = <SplashScreen />
  else if (screen === 'login') body = <LoginScreen onLogin={doLogin} onSignup={() => go('signup')} ui={uiLang} setUi={setUiLang} />
  else if (screen === 'signup') body = <RegisterScreen onSignup={doSignup} onBack={() => go('login')} />
  else if (screen === 'await') body = <AwaitApprovalScreen tr={tr} onBack={() => go('login')} />
  else if (screen === 'lang') body = <LangAskScreen current={lang} onPick={pickLanguage} />
  else if (screen === 'home') body = (
    <HomeScreen home={home} customer={customer} slider={slider} tr={tr} go={go} openPlay={openPlay} openStar={openStar}
      onAddPoints={() => setModal('deposit')} onPrompt={setPrompt} />
  )
  else if (screen === 'play' && marketCode && home) body = (
    <MarketScreen
      market={home.markets.find(m => m.code === marketCode)!}
      lang={lang} tr={tr} wallet={customer?.wallet || 0}
      slip={slip} setEntry={setEntry} removeSlip={removeSlip} clearSlip={clearSlip}
      onSubmit={submitSlip} onBack={() => backTo('home')}
      onBulkAdd={bulkAddToSlip} showToast={showToast}
    />
  )
  else if (screen === 'starline') body = (
    <StarlineScreen
      initialHour={starHour} tr={tr} wallet={customer?.wallet || 0}
      board={home?.starline?.board || []} starlines={home?.starline?.starlines || []}
      slip={slip} setEntry={setEntry} removeSlip={removeSlip} clearSlip={clearSlip}
      onSubmit={submitSlip} onBack={() => backTo('home')}
    />
  )
  else if (screen === 'mybets') body = <MyBidsScreen wallet={customer?.wallet || 0} showToast={showToast} onExpired={() => go('login')} refreshKey={mybetsKey} />
  else if (screen === 'results') body = <ResultsScreen markets={home?.markets || []} />
  else if (screen === 'wallet') body = (
    <WalletScreen tr={tr} customer={customer}
      onAddPoints={() => setModal('deposit')} onWithdraw={() => setModal('withdraw')}
      showToast={showToast} onExpired={() => go('login')} />
  )
  else if (screen === 'profile') body = (
    <ProfileScreen customer={customer} tr={tr} go={go} onLogout={doLogout}
      onChangePassword={() => setModal('password')} onSelectLanguage={openLangFromProfile} />
  )
  else if (screen === 'notifs') body = <NotificationsScreen onBack={() => backTo('home')} />
  else body = <SplashScreen />

  const onGradient = false
  void onGradient
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="light" />
      {body}
      {bottomNav}
      {modal === 'deposit' && <DepositModal tr={tr} onClose={() => setModal(null)} onSubmit={submitDeposit} showToast={showToast} />}
      {modal === 'withdraw' && <WithdrawModal tr={tr} wallet={customer?.wallet || 0} canWithdraw={customer?.canWithdraw ?? true} onClose={() => setModal(null)} onSubmit={submitWithdraw} />}
      {modal === 'confirm' && <ConfirmModal tr={tr} slip={slip} onClose={() => setModal(null)} onConfirm={confirmBets} />}
      {modal === 'password' && <PasswordModal tr={tr} onClose={() => setModal(null)} onSubmit={submitPassword} />}
      {prompt?.kind === 'closed' && <ClosedModal tr={tr} mk={prompt.mk} onClose={() => setPrompt(null)} />}
      {prompt?.kind === 'result' && <ResultPrompt tr={tr} mk={prompt.mk} onClose={() => setPrompt(null)} />}
      <Toast msg={toast?.msg || null} kind={toast?.cls || ''} />
    </View>
  )
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <Inner />
      </AuthProvider>
    </SafeAreaProvider>
  )
}
