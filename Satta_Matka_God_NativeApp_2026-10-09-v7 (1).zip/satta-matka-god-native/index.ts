import { registerRootComponent } from 'expo'
import App from './App'

// Root component of the Satta Matka God native app.
registerRootComponent(App)
