// ──────────────────────────────────────────────────────────
// UI KIT — faithful RN port of the web customer app's shared
// CSS classes (shell.tsx APP_CSS): .btn/.btn-g/.btn-w/.btn-p,
// .chip + variants, inputs, cards, sheets, center prompts,
// toast, icons. Genuine React Native components — no WebView.
// ──────────────────────────────────────────────────────────
import React, { useEffect, useRef, useState } from 'react'
import {
  ActivityIndicator, Animated, Easing, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView,
  StyleSheet, Text, TextInput, View, type StyleProp, type TextInputProps, type TextStyle, type ViewStyle,
} from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import {
  Signal, Wifi, BatteryFull, Gem, Bell, Wallet, Plus, Zap, ChevronLeft, ChevronRight,
  Check, X, Receipt, Trophy, User, Home, Star, ArrowDownCircle, ArrowUpCircle,
  PlusCircle, Moon, Lock, LogIn, KeyRound, Download, Headphones, FlaskConical,
  Info, LogOut, Megaphone, Layers, Circle, AlertTriangle, MinusCircle,
  Play, Clock, Target, Hash, Link2, LayoutGrid, Boxes, GitMerge, Puzzle,
  Dices, Cog, Shapes, Sparkles, Split, TrendingUp, PartyPopper, Timer,
} from 'lucide-react-native'
import { C, F, RADIUS } from './theme'

// ── Icon map — same names the web app uses (I n="gem" etc.) ──
const ICONS: Record<string, React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>> = {
  signal: Signal, wifi: Wifi, 'battery-full': BatteryFull, gem: Gem, bell: Bell,
  wallet: Wallet, plus: Plus, zap: Zap, 'chevron-left': ChevronLeft, 'chevron-right': ChevronRight,
  check: Check, x: X, receipt: Receipt, trophy: Trophy, user: User, home: Home, star: Star,
  'arrow-down-circle': ArrowDownCircle, 'arrow-up-circle': ArrowUpCircle, 'plus-circle': PlusCircle,
  'minus-circle': MinusCircle, moon: Moon, lock: Lock, 'log-in': LogIn, 'key-round': KeyRound,
  download: Download, headphones: Headphones, 'flask-conical': FlaskConical, info: Info,
  'log-out': LogOut, megaphone: Megaphone, layers: Layers, circle: Circle, 'alert-triangle': AlertTriangle,
  play: Play, clock: Clock, target: Target, hash: Hash, 'link-2': Link2, 'layout-grid': LayoutGrid,
  boxes: Boxes, 'git-merge': GitMerge, puzzle: Puzzle, dices: Dices, cog: Cog, shapes: Shapes,
  sparkles: Sparkles, split: Split, 'trending-up': TrendingUp, party: PartyPopper, timer: Timer,
}
export function I({ n, size = 16, color, strokeWidth = 2 }: { n: string; size?: number; color?: string; strokeWidth?: number }) {
  const Cm = ICONS[n] || Circle
  return <Cm size={size} color={color} strokeWidth={strokeWidth} />
}

// Icon per game code — same catalog as shell.tsx GAME_ICONS
export const GAME_ICONS: Record<string, string> = {
  single: 'target', jodi: 'link-2', sp: 'hash', dp: 'layout-grid', tp: 'boxes',
  hs: 'git-merge', hsb: 'git-merge', fs: 'puzzle', oddeven: 'split',
  'sp-motor': 'cog', 'dp-motor': 'cog', motor: 'cog', spdp: 'shapes', sptp: 'shapes',
  dptp: 'shapes', spdptp: 'shapes', 'family-4': 'shapes', 'family-6': 'shapes', 'family-8': 'shapes',
  family: 'shapes',
  'chart-20': 'dices', 'chart-30': 'dices', 'chart-40': 'dices', 'chart-50': 'dices',
  'chart-60': 'dices', 'chart-70': 'dices', 'chart-90dp': 'dices', 'chart-abr': 'dices',
  'dp-50': 'dices', 'dp-60': 'dices', 'dp-70': 'dices', 'dp-90': 'dices', 'dp-90ab': 'dices',
}

// ── Formatting helpers (verbatim semantics from shell.tsx) ──
export const fmt = (n: number | string | null | undefined): string =>
  '₹' + Number(n || 0).toLocaleString('en-IN')
export const dtStr = (v: string | Date): string =>
  new Date(v).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true })
export const dateLabel = (ds: string): string =>
  new Date(ds + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })
export const nowStr = (): string =>
  new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true })
export const todayStr = (): string => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
export const fmt12 = (hhmm: string): string => {
  const [h, m] = (hhmm || '').split(':').map(Number)
  if (!Number.isFinite(h)) return hhmm || ''
  const ap = h < 12 ? 'AM' : 'PM'
  const hh = h % 12 || 12
  return `${hh}:${String(m || 0).padStart(2, '0')} ${ap}`
}

// ── Chip — .chip + .c-* variants ──
const CHIP_COLORS: Record<string, { bg: string; tx: string }> = {
  'c-grn': { bg: C.greenSoft, tx: '#15803d' },
  'c-gray': { bg: C.slateSoft, tx: C.grayChipTx },
  'c-red': { bg: C.redSoft, tx: C.red },
  'c-gold': { bg: '#fef3c7', tx: '#b45309' },
  'c-pink': { bg: C.pink, tx: C.pinkT },
  'c-teal': { bg: C.tealSoft, tx: C.tealTx },
  'c-cyan': { bg: C.cyanSoft, tx: C.cyanTx },
  'c-orange': { bg: C.orangeSoft, tx: C.orangeTx },
  'c-yellow': { bg: C.yellowSoft, tx: C.yellowTx },
}
export function Chip({ variant = 'c-gray', children, style }: {
  variant?: keyof typeof CHIP_COLORS; children: React.ReactNode; style?: StyleProp<ViewStyle>
}) {
  const cc = CHIP_COLORS[variant] || CHIP_COLORS['c-gray']
  return (
    <View style={[{ backgroundColor: cc.bg, paddingHorizontal: 9, paddingVertical: 3, borderRadius: RADIUS.chip, flexDirection: 'row', alignItems: 'center', alignSelf: 'auto' }, style]}>
      <Text style={{ color: cc.tx, fontSize: 10.5, fontWeight: '700', fontFamily: F.bold }}>{children}</Text>
    </View>
  )
}

// ── Buttons — .btn / .btn-g / .btn-w / .btn-p ──
export function Btn({ variant = 'w', label, icon, iconSize = 15, iconColor, onPress, disabled, style, textStyle, children }: {
  variant?: 'g' | 'w' | 'p' | 'danger' | 'whiteGlass' | 'red'
  label?: string
  icon?: string
  iconSize?: number
  iconColor?: string
  onPress?: () => void
  disabled?: boolean
  style?: StyleProp<ViewStyle>
  textStyle?: StyleProp<TextStyle>
  children?: React.ReactNode
}) {
  const pad: ViewStyle = { paddingVertical: 10, paddingHorizontal: 16, borderRadius: RADIUS.btn, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7, opacity: disabled ? 0.45 : 1 }
  let inner: React.ReactNode
  if (variant === 'g') {
    inner = (
      <LinearGradient colors={[...GRAD_G]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[pad, style]}>
        <BtnContent icon={icon} iconSize={iconSize} iconColor={iconColor || '#78350f'} label={label} textStyle={[{ color: '#78350f' }, textStyle]} children={children} />
      </LinearGradient>
    )
  } else if (variant === 'p') {
    inner = (
      <LinearGradient colors={[C.p1, C.p2]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[pad, style]}>
        <BtnContent icon={icon} iconSize={iconSize} iconColor={iconColor || '#fff'} label={label} textStyle={[{ color: '#fff' }, textStyle]} children={children} />
      </LinearGradient>
    )
  } else {
    const bg = variant === 'w' ? C.white : variant === 'danger' ? C.redSoft : variant === 'red' ? C.redSoft : 'rgba(255,255,255,.22)'
    const tx = variant === 'w' ? C.ink : variant === 'danger' || variant === 'red' ? C.red : '#fff'
    inner = (
      <Pressable onPress={onPress} disabled={disabled} style={({ pressed }) => [{ ...pad, backgroundColor: bg, borderWidth: variant === 'w' ? 1 : 0, borderColor: C.line }, style, pressed && { transform: [{ scale: 0.97 }] }]}>
        <BtnContent icon={icon} iconSize={iconSize} iconColor={iconColor || tx} label={label} textStyle={[{ color: tx }, textStyle]} children={children} />
      </Pressable>
    )
  }
  return <Pressable onPress={variant === 'g' || variant === 'p' ? onPress : undefined} disabled={disabled} style={({ pressed }) => [pressed && (variant === 'g' || variant === 'p') && { transform: [{ scale: 0.97 }] }]}>{inner}</Pressable>
}
const GRAD_G: [string, string] = [C.gold, C.gold2]
function BtnContent({ icon, iconSize, iconColor, label, textStyle, children }: {
  icon?: string; iconSize?: number; iconColor?: string; label?: string
  textStyle?: StyleProp<TextStyle>; children?: React.ReactNode
}) {
  return (
    <>
      {icon ? <I n={icon} size={iconSize} color={iconColor} /> : null}
      {label != null ? <Text style={[{ fontSize: 13, fontWeight: '700', fontFamily: F.bold }, textStyle]}>{label}</Text> : null}
      {children}
    </>
  )
}

// ── Input — .mb-root input styling ──
export function Inp({ style, mono, ...rest }: TextInputProps & { mono?: boolean }) {
  return (
    <TextInput
      placeholderTextColor={C.slate}
      {...rest}
      style={[{
        borderWidth: 1, borderColor: C.line, borderRadius: RADIUS.inp, paddingHorizontal: 12,
        paddingVertical: 9, backgroundColor: '#fff', color: C.ink, fontSize: 13,
        fontFamily: mono ? 'monospace' : F.reg,
      }, style]}
    />
  )
}
export function Lbl({ children, style }: { children: React.ReactNode; style?: StyleProp<TextStyle> }) {
  return <Text style={[{ fontSize: 11, color: C.mut, fontWeight: '800', fontFamily: F.xbold, letterSpacing: 0.5, marginBottom: 4 }, style]}>{children}</Text>
}

// ── Card ──
export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: RADIUS.card }, style]}>{children}</View>
}

// ── Bottom-sheet modal — .overlay + .modal ──
export function SheetModal({ title, onClose, children, scroll = true }: {
  title: string; onClose: () => void; children: React.ReactNode; scroll?: boolean
}) {
  const insets = useSafeAreaInsets()
  return (
    <Modal transparent animationType="slide" visible onRequestClose={onClose}>
      {/* KeyboardAvoidingView keeps the sheet's inputs above the keyboard
          (RN <Modal> runs its own window on Android — adjustResize alone
          does not lift it). */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <Pressable style={{ flex: 1, backgroundColor: 'rgba(30,41,59,.55)', justifyContent: 'flex-end' }} onPress={onClose}>
          <Pressable onPress={e => e.stopPropagation()} style={{ backgroundColor: '#fff', borderTopLeftRadius: RADIUS.sheet, borderTopRightRadius: RADIUS.sheet, paddingHorizontal: 18, paddingTop: 20, paddingBottom: 28 + insets.bottom, maxHeight: '85%' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <Text style={{ fontSize: 15, fontWeight: '700', fontFamily: F.sora, color: C.ink, flex: 1 }}>{title}</Text>
              <Pressable onPress={onClose} hitSlop={10}><I n="x" size={18} color={C.slate} /></Pressable>
            </View>
            {scroll ? <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">{children}</ScrollView> : children}
          </Pressable>
        </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  )
}

// ── Big centered prompt — .pov + .pmodal (closed / result declared) ──
export function CenterPrompt({ headerGrad, icon, onClose, children }: {
  headerGrad: readonly [string, string]; icon: string; onClose: () => void; children: React.ReactNode
}) {
  const pop = useRef(new Animated.Value(0.86)).current
  useEffect(() => {
    Animated.spring(pop, { toValue: 1, useNativeDriver: true, friction: 6 }).start()
  }, [pop])
  return (
    <Modal transparent animationType="fade" visible onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: 'rgba(15,23,42,.62)', alignItems: 'center', justifyContent: 'center', padding: 22 }} onPress={onClose}>
        <Pressable onPress={e => e.stopPropagation()} style={{ backgroundColor: C.cream, borderRadius: RADIUS.prompt, width: '100%', maxWidth: 330, overflow: 'hidden', transform: [{ scale: pop }], shadowColor: '#0f172a', shadowOpacity: 0.4, shadowRadius: 24, elevation: 24 }}>
          <LinearGradient colors={[...headerGrad] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 0.6, y: 1 }} style={{ paddingVertical: 20, paddingHorizontal: 18, paddingBottom: 14, alignItems: 'center' }}>
            <View style={{ width: 64, height: 64, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}>
              <I n={icon} size={32} color="#fff" />
            </View>
          </LinearGradient>
          <Pressable style={{ paddingVertical: 16, paddingHorizontal: 18, paddingBottom: 18 }} onPress={e => e.stopPropagation()}>
            {children}
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  )
}

// ── Toast — #mbtoast (rides above the system nav / bottom bar) ──
export function Toast({ msg, kind }: { msg: string | null; kind: 'ok' | 'err' | '' }) {
  const insets = useSafeAreaInsets()
  const v = useRef(new Animated.Value(0)).current
  useEffect(() => {
    Animated.timing(v, { toValue: msg ? 1 : 0, duration: 250, easing: Easing.out(Easing.quad), useNativeDriver: true }).start()
  }, [msg, v])
  if (!msg) return null
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', bottom: 88 + insets.bottom, alignSelf: 'center', maxWidth: '92%',
      backgroundColor: kind === 'err' ? C.red : kind === 'ok' ? C.okToast : '#1e293b',
      paddingHorizontal: 20, paddingVertical: 10, borderRadius: RADIUS.chip,
      opacity: v,
    }}>
      <Text style={{ color: '#fff', fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, textAlign: 'center' }}>{msg}</Text>
    </Animated.View>
  )
}

// ── Spinner row ──
export function Loading({ label = 'Loading…' }: { label?: string }) {
  return (
    <View style={{ padding: 18, alignItems: 'center', flexDirection: 'row', gap: 9, justifyContent: 'center' }}>
      <ActivityIndicator color={C.p2} />
      <Text style={{ color: C.mut, fontSize: 12, fontFamily: F.reg }}>{label}</Text>
    </View>
  )
}

export const SS = StyleSheet.create({
  tiny: { fontSize: 11 },
  small: { fontSize: 12 },
  muted: { color: C.mut },
  mono: { fontFamily: 'monospace' },
  bold: { fontWeight: '800' },
})

// chips used by bet type rows (same mapping as web TYPE_CHIP)
export const TYPE_CHIP: Record<string, keyof typeof CHIP_COLORS> = {
  single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow',
  hs: 'c-pink', fs: 'c-pink', oddeven: 'c-cyan', tp: 'c-yellow',
}
export const STATUS_CHIP: Record<string, keyof typeof CHIP_COLORS> = { pending: 'c-orange', won: 'c-grn', lost: 'c-gray' }
