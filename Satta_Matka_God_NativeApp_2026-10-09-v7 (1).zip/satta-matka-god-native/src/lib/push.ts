// ─── Push notifications (expo-notifications → Expo Push API → FCM) ──────────
// The app requests permission, obtains an ExpoPushToken and registers it on
// the backend (POST /api/customer-app/push/register). The server pushes:
// deposit approvals, withdrawal updates, results declared, wins.
//
// REQUIREMENTS (see SETUP_NATIVE_APP.md):
//   1. `npx eas init` → put the printed projectId into app.json extra.eas.projectId
//   2. Firebase project → download google-services.json into the project root
//      (Expo Push on Android relays through FCM v1).
//   3. Release build must reach the server over HTTPS.
// Without (1)/(2) the app still works — push registration is skipped with a
// console warning, never a crash.
import * as Notifications from 'expo-notifications'
import { Platform } from 'react-native'
import { EAS_PROJECT_ID } from './config'
import { api } from './api'

// Show alerts while the app is foregrounded (Android heads-up).
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
})

export async function initAndroidChannel() {
  if (Platform.OS !== 'android') return
  await Notifications.setNotificationChannelAsync('default', {
    name: 'General',
    importance: Notifications.AndroidImportance.HIGH,
    lightColor: '#D4AF37',
    vibrationPattern: [0, 250, 250, 250],
    enableVibrate: true,
  })
}

export async function registerPush(): Promise<{ ok: boolean; reason?: string }> {
  try {
    if (!EAS_PROJECT_ID) return { ok: false, reason: 'projectId missing (run: npx eas init)' }

    const settings = await Notifications.getPermissionsAsync()
    let granted =
      settings.granted || settings.ios?.status === Notifications.IosAuthorizationStatus.PROVISIONAL
    if (!granted) {
      const req = await Notifications.requestPermissionsAsync()
      granted = req.granted
    }
    if (!granted) return { ok: false, reason: 'permission denied' }

    await initAndroidChannel()

    const t = await Notifications.getDevicePushTokenAsync() // ensure FCM token exists
    if (!t?.data && Platform.OS === 'android') return { ok: false, reason: 'no FCM token (google-services.json missing?)' }

    const token = await Notifications.getExpoPushTokenAsync({ projectId: EAS_PROJECT_ID })
    if (!token?.data) return { ok: false, reason: 'no ExpoPushToken' }

    await api('/api/customer-app/push/register', {
      method: 'POST',
      body: { token: token.data },
    })
    return { ok: true }
  } catch (err) {
    console.warn('registerPush failed (non-fatal):', err)
    return { ok: false, reason: err instanceof Error ? err.message : 'error' }
  }
}

export async function deregisterPush(): Promise<void> {
  try {
    await api('/api/customer-app/push/register', { method: 'DELETE' })
  } catch {
    /* best-effort on logout */
  }
}
