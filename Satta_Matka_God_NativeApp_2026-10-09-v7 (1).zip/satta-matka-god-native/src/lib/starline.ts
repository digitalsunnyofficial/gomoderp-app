// ──────────────────────────────────────────────────────────
// STARLINE HELPERS — managed (ERP-created) starline slots.
// The operator creates hourly starlines in the ERP (e.g. one
// "Main Bombay Starline" row per result time 09:05 → 08:05).
// These helpers derive the display name and the "next playable
// slot" so the app shows the operator's real games instead of
// a static 24-hour board.
// ──────────────────────────────────────────────────────────
import type { StarInfo } from './api'

/** "HH:MM" 24h label of a slot's result time. */
export function starHHMM(sl: { hour: number; minute?: number }): string {
  return String(sl.hour).padStart(2, '0') + ':' + String(sl.minute || 0).padStart(2, '0')
}

/**
 * Base brand name of a managed starline set — strips the trailing
 * result time the generator appends ("Main Bombay Starline 09:05 AM"
 * → "Main Bombay Starline"). Falls back to the first name, then the
 * generic label.
 */
export function starBaseName(names: string[]): string {
  const stripped = names.map(n => n.replace(/\s*\d{1,2}:\d{2}\s*(AM|PM)?\s*$/i, '').trim()).filter(Boolean)
  if (!stripped.length) return 'STARLINE'
  const first = stripped[0]
  if (stripped.every(n => n === first)) return first
  // names differ — use the longest common word prefix
  const words = first.split(/\s+/)
  let base = ''
  for (let i = 1; i <= words.length; i++) {
    const candidate = words.slice(0, i).join(' ')
    if (stripped.every(n => n.startsWith(candidate + ' ') || n === candidate)) base = candidate
    else break
  }
  return base || first
}

/**
 * The slot the customer should play next: the earliest accepting slot
 * measured from NOW (wraps past midnight); when nothing is accepting,
 * the next upcoming slot; with a single slot set, that slot.
 */
export function nextStarSlot(starlines: StarInfo[], now = new Date()): StarInfo | null {
  if (!starlines.length) return null
  const nowMins = now.getHours() * 60 + now.getMinutes()
  const offset = (sl: StarInfo) => (((sl.hour * 60 + (sl.minute || 0)) - nowMins) + 1440) % 1440
  const sorted = [...starlines].sort((a, b) => offset(a) - offset(b))
  return sorted.find(s => s.accepting) || sorted[0]
}

/** Slots ordered by result time of day (for the hour strip). */
export function sortedStarSlots(starlines: StarInfo[]): StarInfo[] {
  return [...starlines].sort((a, b) => (a.hour * 60 + (a.minute || 0)) - (b.hour * 60 + (b.minute || 0)))
}

/** Seconds left until a slot's result time (wraps past midnight). */
export function secsToStarResult(sl: { hour: number; minute?: number }, now = new Date()): number {
  const nowSecs = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds()
  const resSecs = sl.hour * 3600 + (sl.minute || 0) * 60
  return (((resSecs - nowSecs) % 86400) + 86400) % 86400
}
