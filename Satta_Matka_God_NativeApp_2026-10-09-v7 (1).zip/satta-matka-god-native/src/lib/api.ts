// ─── API client: thin wrapper over fetch for /api/customer-app/* ────────────
// The backend authenticates with an opaque Bearer token (AppSession table) —
// exactly what the web app does, so the native app reuses the same endpoints
// with zero backend changes.
import { API_BASE } from './config'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

let token: string | null = null
let onUnauthorized: (() => void) | null = null

export function setApiToken(t: string | null) {
  token = t
}
export function setApiUnauthorizedHandler(fn: () => void) {
  onUnauthorized = fn
}

export async function api<T = unknown>(
  path: string,
  options: { method?: string; body?: unknown } = {},
): Promise<T> {
  const res = await fetch(API_BASE + path, {
    method: options.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
      'X-Client': 'satta-matka-god-native/1.0',
    },
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  })
  let json: unknown = null
  try {
    json = await res.json()
  } catch {
    /* non-JSON response */
  }
  if (!res.ok) {
    const msg =
      (json as { error?: string } | null)?.error ||
      (res.status === 401 ? 'SESSION_EXPIRED' : `Request failed (${res.status})`)
    if (res.status === 401 && onUnauthorized) {
      onUnauthorized()
      throw new ApiError('Please log in to continue', 401)
    }
    throw new ApiError(msg, res.status)
  }
  return json as T
}

// ── Response shapes (subset actually consumed by the app) ──
export type Customer = {
  id: string
  name: string
  mobile: string
  wallet: number
  status: string
  approvalStatus: string
  language: string
  canBet: boolean
  canWithdraw: boolean
  agentName: string | null
}

export type MarketGame = {
  code: string
  name: string
  base: string
  session: string
  expansion: string
  icon?: string
  erpMapping: string
  rate: number
  minPoints: number
}

export type Market = {
  id: string
  code: string
  name: string
  category: string
  phase: string
  session: string
  displayName: string
  openTime: string
  closeTime: string
  betClosingMinutes?: number
  marketStatus: string
  isOn: boolean
  openAccepting: boolean
  closeAccepting: boolean
  resultDeclared: boolean
  todayResult: {
    openPanna?: string | null
    closePanna?: string | null
    openDigit?: string | null
    closeDigit?: string | null
    jodi?: string | null
  } | null
  mySummary?: { bids: number; staked: number; winAmount: number; won: number; lost: number }
  games: MarketGame[]
}

export type Banner = { t: string; s: string; bg?: string }
export type StarInfo = {
  code: string; name: string; hour: number; minute: number
  betClosingMinutes: number; accepting: boolean
  panna: string | null; digit: string | null
}
export type HomeData = {
  customer: Customer
  notice: string | null
  banners: Banner[]
  markets: Market[]
  latestResults: { marketCode: string; marketName: string; date: string; open: string; close: string; jodi: string }[]
  starline?: {
    nextHour: number
    nextAccepting: boolean
    board: { hour: number; panna: string | null; digit: string | null }[]
    starlines?: StarInfo[]
  }
}

export type Txn = {
  id: string
  type: string
  amount: number
  balanceAfter: number
  remark: string
  createdAt: string
}

export type WalletData = {
  wallet: number
  transactions: Txn[]
  pendingFunds: { id: string; amount: number; method: string; utr: string; status: string; createdAt: string }[]
  pendingWithdraws: { id: string; amount: number; status: string; createdAt: string }[]
}

// ── Results & Charts (Phase 2) ──
export type ResultRow = {
  id?: string
  marketCode: string
  resultDate: string
  openPanna: string | null
  closePanna: string | null
  openDigit: string | null
  closeDigit: string | null
  jodi: string | null
}
export type StarBoardItem = { hour: number; panna: string | null; digit: string | null }

// ── My Bids (Phase 2) ──
export type MyBet = {
  id: string
  marketCode: string
  marketName: string
  betDate: string
  slot: string
  type: string
  num: string
  gameCode: string | null
  points: number
  rate: number
  win: number
  status: string
  createdAt: string
}
export type BetsData = {
  bets: MyBet[]
  counts: { all: number; pending: number; won: number; lost: number }
}

// ── Withdrawals (Phase 2) ──
export type Withdrawal = {
  id: string
  amount: number
  status: string
  remark?: string | null
  createdAt: string
}

export type PlacedBet = {
  id: string
  marketCode: string
  marketName: string
  slot: string
  type: string
  num: string
  points: number
  rate: number
  status: string
}

export type BidItem = {
  marketCode: string
  slot: string
  type: string
  num: string
  points: number
  gameCode?: string
  clientRequestId: string
}

// ── Bet slip entry (client-side; mirrors the web app's SlipItem) ──
export type SlipEntry = {
  key: string; mk: string; slot: string; type: string
  num: string; pts: number; rate: number; label: string
  gameCode?: string | null
}
