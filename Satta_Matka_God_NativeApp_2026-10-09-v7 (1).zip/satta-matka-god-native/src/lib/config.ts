import Constants from 'expo-constants'

// ─── Server address ──────────────────────────────────────────────────────────
// Resolution order:
//   1. DEV ONLY — EXPO_PUBLIC_DEV_API_BASE env var, for pointing a dev client
//      at a local server:  EXPO_PUBLIC_DEV_API_BASE=http://192.168.1.5:3000 npx expo start
//   2. extra.apiBase in app.json — the PRODUCTION server. Release APKs always
//      use this. Keep it in sync with the operator's real domain.
//   3. Last-resort fallback: emulator loopback in dev, production in release.
export const API_BASE: string =
  (__DEV__ && (process.env.EXPO_PUBLIC_DEV_API_BASE as string | undefined)
    ? process.env.EXPO_PUBLIC_DEV_API_BASE
    : (Constants.expoConfig?.extra as { apiBase?: string } | undefined)?.apiBase) ||
  (__DEV__ ? 'http://10.0.2.2:3000' : 'https://godmoderp.online')

// EAS project id — required for push notifications. Fill extra.eas.projectId
// in app.json (value printed by `npx eas init`). Empty = push disabled.
export const EAS_PROJECT_ID: string =
  (Constants.expoConfig?.extra as { eas?: { projectId?: string } } | undefined)?.eas
    ?.projectId || ''

export const APP_VERSION = Constants.expoConfig?.version || '1.0.0'
