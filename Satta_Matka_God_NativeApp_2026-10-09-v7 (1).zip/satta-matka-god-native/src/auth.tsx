import React, { createContext, useContext, useEffect, useState } from 'react'
import * as SecureStore from 'expo-secure-store'
import { api, setApiToken, setApiUnauthorizedHandler, type Customer } from './lib/api'
import { registerPush, deregisterPush } from './lib/push'

const TOKEN_KEY = 'smg_token'

type AuthState = {
  booting: boolean
  token: string | null
  customer: Customer | null
  login: (mobile: string, password: string) => Promise<{ ok: boolean; error?: string }>
  register: (
    name: string, mobile: string, password: string, referral?: string,
  ) => Promise<{ ok: boolean; pendingApproval?: boolean; error?: string }>
  logout: () => Promise<void>
  refreshCustomer: () => Promise<void>
}

const Ctx = createContext<AuthState>(null as never)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [booting, setBooting] = useState(true)
  const [token, setToken] = useState<string | null>(null)
  const [customer, setCustomer] = useState<Customer | null>(null)

  async function persist(t: string | null) {
    setApiToken(t)
    setToken(t)
    if (t) await SecureStore.setItemAsync(TOKEN_KEY, t)
    else await SecureStore.deleteItemAsync(TOKEN_KEY)
  }

  // 401 anywhere → session expired → drop to login
  useEffect(() => {
    setApiUnauthorizedHandler(() => {
      void persist(null)
      setCustomer(null)
    })
  }, [])

  useEffect(() => {
    void (async () => {
      try {
        const t = await SecureStore.getItemAsync(TOKEN_KEY)
        if (t) {
          setApiToken(t)
          setToken(t)
          try {
            const me = await api<{ customer: Customer }>('/api/customer-app/me')
            setCustomer(me.customer)
            void registerPush() // refresh token registration on fresh launches
          } catch {
            await persist(null) // stale/revoked token
          }
        }
      } finally {
        setBooting(false)
      }
    })()
  }, [])

  const login: AuthState['login'] = async (mobile, password) => {
    try {
      const r = await api<{ token: string; customer: Customer }>(
        '/api/customer-app/auth/login',
        { method: 'POST', body: { mobile, password } },
      )
      await persist(r.token)
      setCustomer(r.customer)
      void registerPush()
      return { ok: true }
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Login failed' }
    }
  }

  const register: AuthState['register'] = async (name, mobile, password, referral) => {
    try {
      const r = await api<{
        ok: boolean
        pendingApproval?: boolean
        token?: string
        customer?: Customer
      }>('/api/customer-app/auth/signup', {
        method: 'POST',
        body: { name, mobile, password, referral: referral || undefined },
      })
      if (r.pendingApproval) return { ok: true, pendingApproval: true }
      if (r.token && r.customer) {
        await persist(r.token)
        setCustomer(r.customer)
        void registerPush()
      }
      return { ok: true }
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Signup failed' }
    }
  }

  const logout: AuthState['logout'] = async () => {
    void deregisterPush()
    try {
      await api('/api/customer-app/auth/logout', { method: 'POST' })
    } catch {
      /* session may already be gone */
    }
    await persist(null)
    setCustomer(null)
  }

  const refreshCustomer: AuthState['refreshCustomer'] = async () => {
    try {
      const me = await api<{ customer: Customer }>('/api/customer-app/me')
      setCustomer(me.customer)
    } catch {
      /* keep current */
    }
  }

  return (
    <Ctx.Provider value={{ booting, token, customer, login, register, logout, refreshCustomer }}>
      {children}
    </Ctx.Provider>
  )
}
