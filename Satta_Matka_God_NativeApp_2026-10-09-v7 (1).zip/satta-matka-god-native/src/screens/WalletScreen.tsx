// ── Wallet — WalletScreen: gradient wallet card, pending requests,
//    transaction list with colored icon tiles (exact web layout) ──
import React, { useEffect, useState } from 'react'
import { ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Btn, Chip, fmt, dtStr } from '../ui'
import { C, F, GRAD } from '../theme'
import { api, type Customer, type Txn } from '../lib/api'

type TxnView = Txn
type PendingFund = { id: string; amount: number; utr: string; createdAt: string }
type PendingWithdraw = { id: string; amount: number; createdAt: string }

// txn icon map — [icon, bg, color] exactly like the web TI record
const TI: Record<string, [string, string, string]> = {
  deposit: ['arrow-down-circle', 'rgba(34,197,94,.14)', '#15803d'],
  win: ['trophy', 'rgba(245,158,11,.14)', '#b45309'],
  bet: ['receipt', 'rgba(100,116,139,.12)', '#475569'],
  withdraw_hold: ['arrow-up-circle', 'rgba(239,68,68,.12)', '#b91c1c'],
  withdraw_refund: ['arrow-down-circle', 'rgba(34,197,94,.14)', '#15803d'],
  withdraw_paid: ['arrow-up-circle', 'rgba(239,68,68,.12)', '#b91c1c'],
  admin_credit: ['plus-circle', 'rgba(13,148,136,.12)', '#0f766e'],
  admin_debit: ['minus-circle', 'rgba(239,68,68,.12)', '#b91c1c'],
}

export default function WalletScreen({ tr, customer, onAddPoints, onWithdraw, showToast, onExpired }: {
  tr: (k: string) => string
  customer: Customer | null
  onAddPoints: () => void
  onWithdraw: () => void
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
  onExpired: () => void
}) {
  const insets = useSafeAreaInsets()
  const [txns, setTxns] = useState<TxnView[]>([])
  const [pendingFunds, setPendingFunds] = useState<PendingFund[]>([])
  const [pendingWithdraws, setPendingWithdraws] = useState<PendingWithdraw[]>([])

  const load = () => {
    api<{ transactions: TxnView[]; pendingFunds: PendingFund[]; pendingWithdraws: PendingWithdraw[] }>('/api/customer-app/wallet')
      .then(d => {
        setTxns(d.transactions || [])
        setPendingFunds(d.pendingFunds || [])
        setPendingWithdraws(d.pendingWithdraws || [])
      })
      .catch((e: Error) => {
        if (e.message === 'SESSION_EXPIRED') onExpired()
        else showToast(e.message, 'err')
      })
  }
  useEffect(load as unknown as () => void, [])

  if (!customer) {
    return (
      <View style={{ padding: 18 }}>
        <Text style={{ color: C.mut, fontSize: 12, fontFamily: F.reg }}>{tr('loading')}</Text>
      </View>
    )
  }
  return (
    <>
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingTop: insets.top + 8, paddingBottom: 12 }}>
        <Text style={{ fontSize: 15, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>{tr('wallet')}</Text>
        <Text style={{ fontSize: 10.5, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>Points · deposits · withdrawals</Text>
      </LinearGradient>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 100 + insets.bottom }}>
        {/* .wcard */}
        <LinearGradient colors={[...GRAD.wcard] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0.6 }} style={{ borderRadius: 20, padding: 20, marginBottom: 14, overflow: 'hidden' }}>
          <View style={{ position: 'absolute', right: -40, top: -40, width: 160, height: 160, borderRadius: 80, backgroundColor: 'rgba(255,255,255,.13)' }} />
          <Text style={{ opacity: 0.85, fontSize: 10.5, fontWeight: '700', letterSpacing: 1, color: '#fff', fontFamily: F.bold }}>WALLET POINTS</Text>
          <Text style={{ fontSize: 28, fontWeight: '800', fontFamily: F.sora800, color: '#fff', marginVertical: 4 }}>{fmt(customer.wallet)}</Text>
          <Text style={{ fontSize: 11, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>{customer.name} · {customer.mobile}</Text>
          <View style={{ flexDirection: 'row', gap: 9, marginTop: 14 }}>
            <Btn variant="g" icon="arrow-down-circle" label={tr('add_points')} onPress={onAddPoints} style={{ flex: 1 }} />
            <Btn variant="whiteGlass" icon="arrow-up-circle" label={tr('withdraw_title')} onPress={onWithdraw} style={{ flex: 1 }} />
          </View>
        </LinearGradient>

        {/* pending requests */}
        {pendingFunds.length || pendingWithdraws.length ? (
          <>
            <View style={{ marginVertical: 8, marginTop: 2 }}>
              <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>Pending Requests</Text>
            </View>
            {pendingFunds.map(f => (
              <View key={f.id} style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <View>
                  <Text style={{ fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>Deposit {fmt(f.amount)}</Text>
                  <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg, marginTop: 1 }}>{dtStr(f.createdAt)} · {f.utr}</Text>
                </View>
                <Chip variant="c-orange">pending</Chip>
              </View>
            ))}
            {pendingWithdraws.map(w => (
              <View key={w.id} style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <View>
                  <Text style={{ fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>Withdraw {fmt(w.amount)}</Text>
                  <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg, marginTop: 1 }}>{dtStr(w.createdAt)} · amount on hold</Text>
                </View>
                <Chip variant="c-orange">pending</Chip>
              </View>
            ))}
          </>
        ) : null}

        {/* transactions */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 8, marginTop: 14 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>Transactions</Text>
          <Chip variant="c-gray">{txns.length}</Chip>
        </View>
        {txns.map(t => {
          const ti = TI[t.type] || ['circle', '#f1f5f9', '#64748b']
          return (
            <View key={t.id} style={{ flexDirection: 'row', gap: 11, alignItems: 'center', paddingVertical: 11, paddingHorizontal: 3, borderBottomWidth: 1, borderBottomColor: C.line }}>
              <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: ti[1], alignItems: 'center', justifyContent: 'center' }}>
                <I n={ti[0]} size={16} color={ti[2]} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text numberOfLines={1} style={{ fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{t.remark}</Text>
                <Text style={{ fontSize: 10.5, color: C.mut, fontFamily: F.reg, marginTop: 1 }}>{dtStr(t.createdAt)} · bal {fmt(t.balanceAfter)}</Text>
              </View>
              <Text style={{ marginLeft: 'auto', fontWeight: '800', fontSize: 13, fontFamily: F.xbold, color: t.amount > 0 ? '#15803d' : '#b91c1c' }}>
                {t.amount > 0 ? '+' : ''}{fmt(t.amount)}
              </Text>
            </View>
          )
        })}
        {!txns.length ? <Text style={{ color: C.mut, fontSize: 12, padding: 12, fontFamily: F.reg }}>No transactions yet.</Text> : null}
      </ScrollView>
    </>
  )
}
