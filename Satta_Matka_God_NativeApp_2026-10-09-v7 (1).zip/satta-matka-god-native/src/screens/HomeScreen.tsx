// ── Home — HomeScreen + MarketCard v2 (mcard2) + banner slider + marquee.
//    Exact web parity: appbar / wallet chip + add points / notice marquee /
//    banner / Main Markets / Starline card / Latest results. ──
import React, { useEffect, useRef, useState } from 'react'
import { Animated, Easing, Pressable, ScrollView, Text, View, type ViewStyle } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Btn, fmt, fmt12 } from '../ui'
import { C, F, GRAD } from '../theme'
import type { HomeData, Customer, Market } from '../lib/api'
import { RATES, slotAccepting, secsLeftToClose, fmtCountdown } from '../lib/matka/app-engine'
import { starBaseName, nextStarSlot, starHHMM } from '../lib/starline'
import type { Lang } from '../lib/matka/i18n'

type Tr = (k: string) => string

export default function HomeScreen({ home, customer, slider, tr, go, openPlay, openStar, onAddPoints, onPrompt }: {
  home: HomeData | null
  customer: Customer | null
  slider: number
  tr: Tr
  go: (s: string) => void
  openPlay: (code: string) => void
  openStar: (h: number) => void
  onAddPoints: () => void
  onPrompt: (p: { kind: 'closed' | 'result'; mk: Market }) => void
}) {
  const insets = useSafeAreaInsets()
  if (!home || !customer) {
    return (
      <View style={{ padding: 18 }}>
        <Text style={{ color: C.mut, fontSize: 12, fontFamily: F.reg }}>{tr('loading')}</Text>
      </View>
    )
  }
  const cur = new Date().getHours(), nx = (cur + 1) % 24
  // ── Managed starlines (ERP-created) drive the home card when present ──
  const starSlots = home?.starline?.starlines || []
  const managedStar = starSlots.length > 0
  const nextSlot = managedStar ? nextStarSlot(starSlots) : null
  const starTitle = managedStar ? starBaseName(starSlots.map(s => s.name)) : tr('starline_title')
  const starNextLabel = managedStar && nextSlot ? starHHMM(nextSlot) : `${String(nx).padStart(2, '0')}:00`
  const BANNERS = home.banners?.length
    ? home.banners
    : [{ t: 'MATKA BAZAAR', s: tr('play_all'), bg: 'linear-gradient(120deg,#7c3aed,#db2777)' }]
  const b = BANNERS[slider % BANNERS.length]
  return (
    <>
      {/* .appbar */}
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingTop: insets.top + 8, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}>
          <I n="gem" size={18} color="#fff" />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={{ fontSize: 15, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>MATKA BAZAAR</Text>
          <Text style={{ fontSize: 10.5, opacity: 0.85, color: '#fff', fontFamily: F.reg }} numberOfLines={1}>{customer.name} · {customer.mobile}</Text>
        </View>
        <Pressable onPress={() => go('notifs')} style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}>
          <I n="bell" size={16} color="#fff" />
          <View style={{ position: 'absolute', top: 2, right: 3, width: 8, height: 8, borderRadius: 99, backgroundColor: C.gold }} />
        </Pressable>
      </LinearGradient>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 100 + insets.bottom }}>
        {/* wallet chip + add points */}
        <View style={{ flexDirection: 'row', marginBottom: 12, gap: 9 }}>
          <Pressable onPress={() => go('wallet')} style={{ flex: 1, backgroundColor: 'rgba(255,255,255,.92)', borderRadius: 999, paddingVertical: 6, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
            <I n="wallet" size={13} color="#78350f" />
            <Text style={{ color: '#78350f', fontSize: 11.5, fontWeight: '800', fontFamily: F.xbold }}>{fmt(customer.wallet)}</Text>
          </Pressable>
          <Btn variant="g" icon="plus" label={tr('add_points')} onPress={onAddPoints} style={{ flex: 1 }} />
        </View>

        {/* notice marquee */}
        <Marquee text={home.notice || ''} tag={tr('notice')} />

        {/* banner */}
        <View style={{ borderRadius: 16, padding: 18, minHeight: 92, justifyContent: 'center', marginBottom: 12, overflow: 'hidden', backgroundColor: '#7c3aed' }}>
          <LinearGradient colors={[...GRAD.bannerFallback] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0.8 }} style={{ ...StyleSheet_absFill }}>
            <View style={{ position: 'absolute', right: -30, top: -30, width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(255,255,255,.15)' }} />
            <Text style={{ fontFamily: F.sora, fontSize: 19, fontWeight: '700', color: '#fff' }}>{b.t}</Text>
            <Text style={{ fontSize: 12, opacity: 0.9, color: '#fff', fontFamily: F.reg, marginTop: 2 }}>{b.s}</Text>
            <View style={{ flexDirection: 'row', gap: 4, marginTop: 10 }}>
              {BANNERS.map((_, i) => (
                <View key={i} style={{ width: i === (slider % BANNERS.length) ? 14 : 5, height: 5, borderRadius: 99, backgroundColor: i === (slider % BANNERS.length) ? '#fff' : 'rgba(255,255,255,.4)' }} />
              ))}
            </View>
          </LinearGradient>
        </View>

        {/* main markets */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 8, paddingHorizontal: 2, marginTop: 14 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>{tr('main_markets')}</Text>
          <Pressable onPress={() => go('results')}><Text style={{ fontSize: 11, fontWeight: '700', color: C.p2, fontFamily: F.bold }}>{tr('results')} →</Text></Pressable>
        </View>
        {home.markets.map(m => <MarketCard key={m.code} m={m} tr={tr} onPlay={openPlay} onPrompt={onPrompt} />)}

        {/* starline section */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 8, paddingHorizontal: 2, marginTop: 14 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>Starline — Hourly Games</Text>
          <Pressable onPress={() => go('starline')}><Text style={{ fontSize: 11, fontWeight: '700', color: C.p2, fontFamily: F.bold }}>{tr('all_markets')} →</Text></Pressable>
        </View>
        <LinearGradient colors={[...GRAD.starCard] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0.8 }} style={{ borderRadius: 16, padding: 13, marginBottom: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
            <View style={{ flex: 1 }}>
              <Text numberOfLines={1} style={{ fontSize: 14.5, fontFamily: F.sora, fontWeight: '700', color: C.ink }}>{starTitle}</Text>
              <Text style={{ fontSize: 11, color: C.mut, marginTop: 2, fontFamily: F.reg }}>Next game closes at {starNextLabel}</Text>
            </View>
            <View style={{ backgroundColor: '#dcfce7', paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 }}>
              <Text style={{ color: '#15803d', fontSize: 10.5, fontWeight: '700', fontFamily: F.bold }}>● {(managedStar ? nextSlot?.accepting : true) ? tr('live') : tr('closed')}</Text>
            </View>
          </View>
          <View style={{ flexDirection: 'row', gap: 7, marginTop: 10 }}>
            <Btn variant="p" icon="zap" label={`${tr('play')} ${starNextLabel}`} onPress={() => openStar(managedStar && nextSlot ? nextSlot.hour : nx)} style={{ flex: 1 }} />
            <Btn variant="w" label={tr('hour_board')} onPress={() => go('starline')} style={{ flex: 1 }} />
          </View>
          <Text style={{ fontSize: 11, color: C.mut, marginTop: 9, fontFamily: F.reg }}>
            Single 1:{RATES.star.single} · SP 1:{RATES.star.sp} · DP 1:{RATES.star.dp} · TP 1:{RATES.star.tp} · Odd/Even 1:{RATES.star.oddeven}
          </Text>
        </LinearGradient>

        {/* latest results */}
        <View style={{ marginVertical: 8, paddingHorizontal: 2, marginTop: 14, marginBottom: 6 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>{tr('latest_results')}</Text>
        </View>
        {home.latestResults.map(r => {
          const m = home.markets.find(x => x.code === r.marketCode)
          const clickable = !!(m?.resultDeclared && m.todayResult)
          return (
            <Pressable key={r.marketCode} onPress={clickable ? () => onPrompt({ kind: 'result', mk: m! }) : undefined} style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{r.marketName}</Text>
                <Text style={{ fontFamily: 'monospace', fontSize: 12, color: C.mut, marginTop: 2 }}>{r.open} × {r.close}</Text>
              </View>
              {r.jodi
                ? <View style={{ borderRadius: 9, paddingVertical: 4, paddingHorizontal: 11, backgroundColor: '#7c3aed' }}><Text style={{ fontFamily: 'monospace', fontWeight: '800', fontSize: 16, color: '#fff' }}>{r.jodi}</Text></View>
                : <View style={{ backgroundColor: '#ffedd5', paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 }}><Text style={{ color: '#c2410c', fontSize: 10.5, fontWeight: '700', fontFamily: F.bold }}>{tr('awaiting')}</Text></View>}
            </Pressable>
          )
        })}
      </ScrollView>
    </>
  )
}

const StyleSheet_absFill: ViewStyle = { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, borderRadius: 16, padding: 18, justifyContent: 'center' }

// ── notice marquee — .marq + mbslide animation ──
// Short notices render STATIC (always visible). Long ones marquee,
// starting just inside the left edge so the box is never empty-looking.
function Marquee({ text, tag }: { text: string; tag: string }) {
  const x = useRef(new Animated.Value(0)).current
  const [w, setW] = useState(0)
  const estTextW = (text.length + 2) * 7.2
  const animate = w > 0 && estTextW > w
  useEffect(() => {
    if (!animate) return
    x.setValue(0)
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(x, { toValue: 1, duration: 12000, easing: Easing.linear, useNativeDriver: true }),
        Animated.timing(x, { toValue: 0, duration: 0, useNativeDriver: true }),
      ]),
    )
    loop.start()
    return () => loop.stop()
  }, [w, x, text, animate])
  return (
    <View style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 12, flexDirection: 'row', gap: 8, alignItems: 'center', overflow: 'hidden', marginBottom: 12 }}>
      <View style={{ backgroundColor: C.pinkT, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6 }}>
        <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800', fontFamily: F.xbold }}>{tag}</Text>
      </View>
      <View style={{ flex: 1, overflow: 'hidden' }} onLayout={e => setW(e.nativeEvent.layout.width)}>
        <Animated.Text numberOfLines={1} style={{
          color: C.pinkT, fontSize: 12, fontWeight: '600', fontFamily: F.semi,
          transform: [{ translateX: animate
            ? x.interpolate({ inputRange: [0, 1], outputRange: [4, -(estTextW + 12)] })
            : 0 }],
        }}>
          {text}
        </Animated.Text>
      </View>
    </View>
  )
}

// ── MarketCard v2 — .mcard2: time badges / icon+name+result pill / play
//    round button / live status bar with ticking countdown ──
export function MarketCard({ m, tr, onPlay, onPrompt }: {
  m: Market
  tr: Tr
  onPlay: (code: string) => void
  onPrompt: (p: { kind: 'closed' | 'result'; mk: Market }) => void
}) {
  const [, tick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => tick(x => x + 1), 1000)
    return () => clearInterval(t)
  }, [])
  const off = m.isOn === false
  const cm = m.betClosingMinutes || 0
  const now = new Date()
  const openAcc = !off && !m.resultDeclared && slotAccepting(m.openTime, m.closeTime, 'open', now, cm)
  const closeAcc = !off && !m.resultDeclared && slotAccepting(m.openTime, m.closeTime, 'close', now, cm)
  const accepting = openAcc || closeAcc
  const r = m.todayResult
  const resLabel = r ? `${r.openPanna || '***'}-${r.jodi || '**'}-${r.closePanna || '***'}` : '***_**_***'
  const status: 'off' | 'res' | 'run' | 'stop' = off ? 'off' : m.resultDeclared ? 'res' : accepting ? 'run' : 'stop'
  const cd = secsLeftToClose(m.openTime, m.closeTime, openAcc ? 'open' : 'close', new Date(), cm)
  const act = () => {
    if (m.resultDeclared) onPrompt({ kind: 'result', mk: m })
    else if (accepting) onPlay(m.code)
    else onPrompt({ kind: 'closed', mk: m })
  }
  const statGrad = status === 'run' ? GRAD.run : status === 'stop' ? GRAD.stop : status === 'res' ? GRAD.res : null
  const playGrad = status === 'res' ? GRAD.playRes : accepting ? GRAD.playGo : GRAD.playNo
  return (
    <Pressable onPress={act} style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 18, marginBottom: 12, overflow: 'hidden', opacity: off ? 0.72 : 1 }} android_ripple={{ color: '#f1f5f9' }}>
      {/* time badges */}
      <View style={{ flexDirection: 'row', gap: 7, paddingHorizontal: 10, paddingTop: 10 }}>
        <View style={{ flex: 1, backgroundColor: C.amberBg, borderRadius: 999, paddingVertical: 7, paddingHorizontal: 4, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
          <I n="clock" size={12} color={C.amberTx} />
          <Text style={{ fontSize: 10.5, fontWeight: '800', color: C.amberTx, fontFamily: F.xbold }}>{tr('open_time_l')}: {fmt12(m.openTime)}</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: C.darkBrown, borderRadius: 999, paddingVertical: 7, paddingHorizontal: 4, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
          <I n="clock" size={12} color={C.darkBrownTx} />
          <Text style={{ fontSize: 10.5, fontWeight: '800', color: C.darkBrownTx, fontFamily: F.xbold }}>{tr('close_time_l')}: {fmt12(m.closeTime)}</Text>
        </View>
      </View>
      {/* middle */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 12, paddingTop: 11, paddingBottom: 12 }}>
        <LinearGradient colors={[...GRAD.mico] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 44, height: 44, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }}>
          <I n="trending-up" size={21} color={C.goldTx} />
        </LinearGradient>
        <View style={{ flex: 1, alignItems: 'center', minWidth: 0 }}>
          <Text style={{ fontFamily: F.sora, fontSize: 15.5, color: C.ink, letterSpacing: 0.3 }} numberOfLines={1}>{(m.displayName || m.name).toUpperCase()}</Text>
          <View style={{
            marginTop: 5, borderWidth: 1.5, borderColor: m.resultDeclared ? C.purpleLine : C.line, backgroundColor: m.resultDeclared ? C.purpleSoft : '#fff',
            borderRadius: 999, paddingVertical: 4, paddingHorizontal: 14,
          }}>
            <Text style={{ fontFamily: 'monospace', fontWeight: '800', fontSize: 15, letterSpacing: 1, color: m.resultDeclared ? C.purpleTx : C.ink }}>{resLabel}</Text>
          </View>
        </View>
        <LinearGradient colors={[...playGrad] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 46, height: 46, borderRadius: 999, alignItems: 'center', justifyContent: 'center', shadowColor: '#1e293b', shadowOpacity: 0.18, shadowRadius: 8, elevation: 4 }}>
          <I n={status === 'res' ? 'trophy' : accepting ? 'play' : 'x'} size={20} color="#fff" />
        </LinearGradient>
      </View>
      {/* status bar */}
      {statGrad ? (
        <LinearGradient colors={[...statGrad] as [string, string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, paddingVertical: 9, paddingHorizontal: 8 }}>
          <I n={status === 'run' ? 'zap' : status === 'res' ? 'trophy' : off ? 'moon' : 'lock'} size={13} color="#fff" />
          <Text style={{ color: '#fff', fontSize: 11.5, fontWeight: '800', fontFamily: F.xbold, letterSpacing: 0.5 }}>
            {status === 'run'
              ? (openAcc ? tr('betting_open_running') : tr('betting_close_running'))
              : status === 'res'
                ? `${tr('result_out')} · ${tr('result_out_tap')}`
                : off ? tr('market_off_t') : tr('market_closed_t')}
          </Text>
          {status === 'run' ? (
            <View style={{ backgroundColor: 'rgba(255,255,255,.22)', borderRadius: 999, paddingHorizontal: 9, paddingVertical: 1 }}>
              <Text style={{ color: '#fff', fontFamily: 'monospace', fontSize: 11, letterSpacing: 0.5 }}>{tr('closes_in')} {fmtCountdown(cd)}</Text>
            </View>
          ) : null}
        </LinearGradient>
      ) : (
        <View style={{ backgroundColor: C.grayChipTx, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, paddingVertical: 9, paddingHorizontal: 8 }}>
          <I n="moon" size={13} color="#fff" />
          <Text style={{ color: '#fff', fontSize: 11.5, fontWeight: '800', fontFamily: F.xbold, letterSpacing: 0.5 }}>{tr('market_off_t')}</Text>
        </View>
      )}
    </Pressable>
  )
}
