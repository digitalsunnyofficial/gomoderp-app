// ── Results & Charts — ResultsScreen: tabs / market chips / date-grouped
//    result rows / JodiChart / PanelChart / StarBoard, 10s live polling ──
import React, { useEffect, useState } from 'react'
import { Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { Chip } from '../ui'
import { C, F, GRAD } from '../theme'
import { api, type Market, type StarBoardItem } from '../lib/api'
import { JodiChart, PanelChart, StarBoard, dateLabel, type ResultRowT } from './Charts'
import { Tabs } from './PlayShared'

function mkNameFromCode(code: string, markets?: Market[]): string {
  if (code.startsWith('st')) return 'Starline ' + code.slice(2).padStart(2, '0') + ':00'
  const m = markets?.find(x => x.code === code)
  return m?.displayName || m?.name || code
}

export default function ResultsScreen({ markets, initialMarket }: {
  markets: Market[]
  initialMarket?: string | null
}) {
  const insets = useSafeAreaInsets()
  const [tab, setTab] = useState('results')
  const [chartMk, setChartMk] = useState(initialMarket || markets[0]?.code || 'kalyan')
  const [results, setResults] = useState<ResultRowT[]>([])
  const [starBoard, setStarBoard] = useState<StarBoardItem[]>([])
  const curH = new Date().getHours()

  useEffect(() => {
    let live = true
    const load = () => {
      if (tab === 'board') {
        api<{ board: StarBoardItem[] }>('/api/customer-app/results?starline=1')
          .then(d => { if (live) setStarBoard(d.board || []) })
          .catch(() => {})
        return
      }
      api<{ results: ResultRowT[] }>('/api/customer-app/results?market=' + chartMk)
        .then(d => { if (live) setResults(d.results || []) })
        .catch(() => {})
    }
    load()
    const t2 = setInterval(load, 10000)
    return () => { live = false; clearInterval(t2) }
  }, [chartMk, tab])

  const allMarketChips = markets.map(m => ({ code: m.code, name: m.displayName || m.name }))

  return (
    <>
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingTop: insets.top + 8, paddingBottom: 12 }}>
        <Text style={{ fontSize: 15, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>Results & Charts</Text>
        <Text style={{ fontSize: 10.5, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>Official declared results</Text>
      </LinearGradient>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 100 + insets.bottom }}>
        <Tabs
          tabs={[['results', 'Results'], ['jodi', 'Jodi Chart'], ['panel', 'Panel Chart'], ['board', 'Starline']]}
          value={tab} onChange={setTab} style={{ marginTop: 0 }}
        />
        {tab !== 'board' ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6, paddingBottom: 4 }}
            style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 6, flexGrow: 0 }}>
            {allMarketChips.map(m => (
              <Pressable key={m.code} onPress={() => setChartMk(m.code)} style={{
                backgroundColor: chartMk === m.code ? C.pinkT : C.pink, borderWidth: 1, borderColor: '#fbcfe8',
                borderRadius: 10, paddingHorizontal: 13, paddingVertical: 7,
              }}>
                <Text style={{ color: chartMk === m.code ? '#fff' : C.pinkT, fontWeight: '800', fontSize: 11, fontFamily: F.xbold }}>{m.name}</Text>
              </Pressable>
            ))}
          </ScrollView>
        ) : null}
        {tab === 'results' ? results.map(r => (
          <View key={r.resultDate}>
            <Text style={{ fontSize: 10.5, fontWeight: '800', color: C.mut, textTransform: 'uppercase', marginVertical: 7, marginTop: 12, marginLeft: 2, fontFamily: F.xbold }}>
              {dateLabel(r.resultDate)}
            </Text>
            <View style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{mkNameFromCode(r.marketCode, markets)}</Text>
                <Text style={{ fontFamily: 'monospace', fontSize: 12, color: C.mut, marginTop: 2 }}>
                  {r.openPanna ? r.openPanna + '-' + r.openDigit : '—'} <Text style={{ color: '#cbd5e1' }}>×</Text> {r.closePanna ? r.closePanna + '-' + r.closeDigit : '—'}
                </Text>
              </View>
              {r.jodi
                ? <View style={{ borderRadius: 9, paddingVertical: 4, paddingHorizontal: 11, backgroundColor: '#7c3aed' }}><Text style={{ fontFamily: 'monospace', fontWeight: '800', fontSize: 16, color: '#fff' }}>{r.jodi}</Text></View>
                : <View style={{ backgroundColor: '#ffedd5', paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 }}><Text style={{ color: '#c2410c', fontSize: 10.5, fontWeight: '700', fontFamily: F.bold }}>awaiting</Text></View>}
            </View>
          </View>
        )) : null}
        {tab === 'results' && !results.length ? <Text style={{ color: C.mut, fontSize: 12, padding: 12, fontFamily: F.reg }}>No results declared yet for this market.</Text> : null}
        {tab === 'jodi' ? <JodiChart results={results} mkName={mkNameFromCode(chartMk, markets)} /> : null}
        {tab === 'panel' ? <PanelChart results={results} mkName={mkNameFromCode(chartMk, markets)} /> : null}
        {tab === 'board' ? <StarBoard board={starBoard} curH={curH} /> : null}
      </ScrollView>
    </>
  )
}
