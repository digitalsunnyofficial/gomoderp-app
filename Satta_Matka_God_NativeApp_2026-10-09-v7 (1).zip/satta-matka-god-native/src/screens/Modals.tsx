// ──────────────────────────────────────────────────────────
// MODALS — DepositModal (business QR + UPI copy), WithdrawModal,
// ConfirmModal, PasswordModal, ClosedModal, ResultPrompt.
// Faithful RN port of the web modals incl. the big centered
// cream prompts (.pov/.pmodal).
// ──────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react'
import { Image, Linking, Pressable, Text, View } from 'react-native'
import * as Clipboard from 'expo-clipboard'
import { I, Btn, Chip, Inp, Lbl, SheetModal, CenterPrompt, fmt } from '../ui'
import { C, F } from '../theme'
import { api, type SlipEntry } from '../lib/api'
import type { Market } from '../lib/api'
import { canonicalPanna } from '../lib/matka/chart-definitions'

type Tr = (k: string) => string

// ── Deposit — QR card + amount/method/UTR + submit ──
export function DepositModal({ tr, onClose, onSubmit, showToast }: {
  tr: Tr; onClose: () => void; onSubmit: (amt: number, method: string, utr: string) => void
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
}) {
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState('UPI')
  const [utr, setUtr] = useState('')
  const [qr, setQr] = useState<{ upiId: string; payeeName: string; qrImage: string; note: string; minDeposit: number } | null>(null)
  const [copied, setCopied] = useState(false)
  const [paying, setPaying] = useState(false)
  const [payRef, setPayRef] = useState('')
  useEffect(() => {
    api<{ upiId: string; payeeName: string; qrImage: string; note: string; minDeposit: number }>('/api/customer-app/payment-qr')
      .then(d => setQr(d))
      .catch(() => setQr(null))
  }, [])
  const min = qr?.minDeposit || 100
  const copyUpi = async () => {
    if (!qr?.upiId) return
    try {
      await Clipboard.setStringAsync(qr.upiId)
      setCopied(true); setTimeout(() => setCopied(false), 2000)
    } catch { /* clipboard unavailable */ }
  }
  const ok = !!amount && Number(amount) >= min && !!utr.trim()
  // ── UPI intent: create the pending request server-side, then open the
  // chosen UPI app with the amount + tracking ref pre-filled. The wallet is
  // credited automatically when the payment feed confirms (or admin approval
  // as fallback) — the customer just pays and waits for the notification. ──
  const payWithUpi = async () => {
    if (!amount || Number(amount) < min) return showToast('Enter a valid amount first', 'err')
    setPaying(true)
    try {
      const d = await api<{ upiUri: string; ref: string }>('/api/customer-app/funds/upi-intent', {
        method: 'POST', body: { amount: Number(amount), app: 'upi' },
      })
      setPayRef(d.ref)
      const opened = await Linking.openURL(d.upiUri).catch(() => false)
      if (!opened) showToast('No UPI app found — pay via the QR and submit the UTR', 'err')
      else showToast('Payment request created — complete it in your UPI app', 'ok')
    } catch (e) { showToast((e as Error).message, 'err') } finally { setPaying(false) }
  }
  return (
    <SheetModal title={tr('deposit_title')} onClose={onClose}>
      <Text style={{ fontSize: 11, color: C.mut, fontWeight: '800', marginBottom: 6, fontFamily: F.xbold }}>{tr('pay_upi')}</Text>
      <View style={{ alignItems: 'center', gap: 8, backgroundColor: '#f8fafc', borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 14 }}>
        {qr?.qrImage ? (
          <Image source={{ uri: qr.qrImage }} style={{ width: 190, height: 190, resizeMode: 'contain', backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: C.line }} />
        ) : (
          <View style={{ width: 190, height: 190, borderRadius: 12, borderWidth: 1, borderColor: C.line, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', padding: 12 }}>
            <Text style={{ fontSize: 11, color: C.mut, textAlign: 'center', fontFamily: F.reg }}>
              {qr ? tr('qr_not_uploaded') : tr('loading_payment')}
            </Text>
          </View>
        )}
        {qr?.payeeName ? <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{qr.payeeName}</Text> : null}
        {qr?.upiId ? (
          <Pressable onPress={copyUpi} style={{ backgroundColor: C.tealSoft, paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <I n="wallet" size={13} color={C.tealTx} />
            <Text style={{ color: C.tealTx, fontSize: 12, fontWeight: '700', fontFamily: F.bold }}>{copied ? 'UPI ID copied!' : qr.upiId}</Text>
          </Pressable>
        ) : null}
        {qr?.note ? <Text style={{ fontSize: 11, color: C.mut, textAlign: 'center', fontFamily: F.reg }}>{qr.note}</Text> : null}
      </View>
      <Text style={{ fontSize: 11, color: C.mut, marginTop: 10, fontFamily: F.reg }}>
        {tr('deposit_note')} <Text style={{ fontWeight: '700' }}>{fmt(Number(amount) || min)}</Text>{tr('then_submit')}
      </Text>
      <Lbl style={{ marginTop: 10 }}>{tr('amount')} — {tr('min')} {min}</Lbl>
      <Inp keyboardType="number-pad" maxLength={9} placeholder={tr('min') + ' ₹' + min} value={amount} onChangeText={v => setAmount(v.replace(/\D/g, ''))} />
      <Btn variant="p" icon="zap" label={paying ? 'Opening UPI app…' : 'Pay with UPI App'} disabled={!amount || Number(amount) < min || paying}
        onPress={payWithUpi} style={{ width: '100%', marginTop: 10, paddingVertical: 13 }} />
      <Text style={{ fontSize: 10.5, color: C.mut, marginTop: 5, textAlign: 'center', fontFamily: F.reg }}>
        Opens PhonePe / GPay / Paytm with the amount filled — points are added automatically once the payment lands.
      </Text>
      {payRef ? (
        <View style={{ marginTop: 8, backgroundColor: '#ecfdf5', borderWidth: 1, borderColor: '#a7f3d0', borderRadius: 10, padding: 10 }}>
          <Text style={{ fontSize: 11, color: '#047857', fontFamily: F.bold }}>Payment ref: {payRef}</Text>
          <Text style={{ fontSize: 10.5, color: '#047857', fontFamily: F.reg, marginTop: 2 }}>Waiting for confirmation — you will get a notification when the points arrive. Paid already? Enter the UTR below for instant manual approval.</Text>
        </View>
      ) : null}
      <Lbl style={{ marginTop: 10 }}>{tr('method')}</Lbl>
      <MethodPicker value={method} onChange={setMethod} />
      <Lbl style={{ marginTop: 10 }}>{tr('utr')}</Lbl>
      <Inp placeholder="e.g. UTR883421900" value={utr} onChangeText={v => setUtr(v.replace(/[^a-zA-Z0-9]/g, '').toUpperCase())} maxLength={22} mono autoCapitalize="characters" />
      <Btn variant="g" icon="arrow-down-circle" label={tr('submit_request')} disabled={!ok}
        onPress={() => onSubmit(Number(amount), method, utr)} style={{ width: '100%', marginTop: 14, paddingVertical: 13 }} />
      {amount && Number(amount) < min ? <Text style={{ fontSize: 11, color: C.red, marginTop: 6, fontFamily: F.reg }}>Minimum deposit is ₹{min}</Text> : null}
    </SheetModal>
  )
}

function MethodPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <View style={{ flexDirection: 'row', gap: 7 }}>
      {['UPI', 'Bank Transfer'].map(m => (
        <Pressable key={m} onPress={() => onChange(m)} style={{
          flex: 1, paddingVertical: 9, borderRadius: 10, borderWidth: 1,
          backgroundColor: value === m ? C.p1 : '#fff', borderColor: value === m ? 'transparent' : C.line,
        }}>
          <Text style={{ textAlign: 'center', fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: value === m ? '#fff' : C.ink }}>{m}</Text>
        </Pressable>
      ))}
    </View>
  )
}

// ── Withdraw ──
export function WithdrawModal({ tr, wallet, canWithdraw, onClose, onSubmit }: {
  tr: Tr; wallet: number; canWithdraw: boolean; onClose: () => void; onSubmit: (amt: number) => void
}) {
  const [amount, setAmount] = useState('')
  return (
    <SheetModal title={tr('withdraw_title')} onClose={onClose}>
      <Text style={{ fontSize: 12, color: C.ink, marginBottom: 2, fontFamily: F.reg }}>
        {tr('available')} <Text style={{ fontWeight: '700' }}>{fmt(wallet)}</Text>
      </Text>
      <Lbl style={{ marginTop: 10 }}>{tr('amount')}</Lbl>
      <Inp keyboardType="number-pad" maxLength={9} placeholder="minimum ₹500" value={amount} onChangeText={v => setAmount(v.replace(/\D/g, ''))} />
      <Text style={{ fontSize: 11, color: C.mut, marginVertical: 12, fontFamily: F.reg }}>{tr('withdraw_note')}</Text>
      <Btn variant="g" icon="arrow-up-circle" label={tr('submit_request')} disabled={!canWithdraw || !Number(amount)}
        onPress={() => onSubmit(Number(amount))} style={{ width: '100%', paddingVertical: 13 }} />
      {!canWithdraw ? <Text style={{ fontSize: 11, color: C.red, marginTop: 8, fontFamily: F.reg }}>{tr('withdraw_disabled')}</Text> : null}
    </SheetModal>
  )
}

// ── Confirm slip ──
export function ConfirmModal({ tr, slip, onClose, onConfirm }: {
  tr: Tr; slip: SlipEntry[]; onClose: () => void; onConfirm: () => void
}) {
  const pts = slip.reduce((a, s) => a + s.pts, 0)
  return (
    <SheetModal title={tr('confirm_title')} onClose={onClose}>
      <View style={{ maxHeight: 180 }}>
        {slip.map((s, i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: C.line, borderStyle: 'dashed' }}>
            <Chip variant={s.type === 'hs' || s.type === 'fs' ? 'c-pink' : 'c-gray'}>{s.type.toUpperCase()}</Chip>
            <Text style={{ fontFamily: 'monospace', fontWeight: '800', color: C.ink }}>{canonicalPanna(s.num)}</Text>
            <Text style={{ fontSize: 11, color: C.mut, flex: 1 }} numberOfLines={1}>{s.label.split('·')[0]}</Text>
            <Text style={{ fontWeight: '800', color: C.ink, fontSize: 12 }}>{s.pts}</Text>
          </View>
        ))}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: C.awaitWarnBg, borderRadius: 11, paddingVertical: 10, paddingHorizontal: 13, marginVertical: 10, marginBottom: 14 }}>
        <Text style={{ fontSize: 12, fontWeight: '800', color: '#78350f', fontFamily: F.xbold }}>{tr('total_bids')} {slip.length} {tr('bids')}</Text>
        <Text style={{ color: '#78350f', fontSize: 16, fontWeight: '800', fontFamily: F.xbold }}>{fmt(pts)}</Text>
      </View>
      <View style={{ flexDirection: 'row', gap: 9 }}>
        <Btn variant="w" label={tr('cancel')} onPress={onClose} style={{ flex: 1, paddingVertical: 12 }} />
        <Btn variant="g" icon="check" label={tr('confirm')} onPress={onConfirm} style={{ flex: 1, paddingVertical: 12 }} />
      </View>
    </SheetModal>
  )
}

// ── Change password ──
export function PasswordModal({ tr, onClose, onSubmit }: {
  tr: Tr; onClose: () => void; onSubmit: (o: string, n: string) => void
}) {
  const [oldP, setOldP] = useState('')
  const [newP, setNewP] = useState('')
  return (
    <SheetModal title={tr('change_password')} onClose={onClose}>
      <Lbl style={{ marginTop: 4 }}>{tr('current_password')}</Lbl>
      <Inp secureTextEntry value={oldP} onChangeText={setOldP} />
      <Lbl style={{ marginTop: 12 }}>{tr('new_password')}</Lbl>
      <Inp secureTextEntry value={newP} onChangeText={setNewP} placeholder="min 6 characters" />
      <Btn variant="g" icon="key-round" label={tr('update_password')} onPress={() => onSubmit(oldP, newP)} style={{ width: '100%', marginTop: 16, paddingVertical: 13 }} />
    </SheetModal>
  )
}

// ── Big centered prompt — MARKET IS CLOSED ──
export function ClosedModal({ tr, mk, onClose }: { tr: Tr; mk: Market; onClose: () => void }) {
  return (
    <CenterPrompt headerGrad={['#f43f5e', '#dc2626']} icon="lock" onClose={onClose}>
      <Text style={{ fontFamily: F.sora, fontSize: 18, color: C.ink, textAlign: 'center' }}>{(mk.displayName || mk.name).toUpperCase()}</Text>
      <Text style={{ fontSize: 13, fontWeight: '800', color: C.red, marginTop: 5, letterSpacing: 0.4, textAlign: 'center', fontFamily: F.xbold }}>
        {mk.isOn === false ? tr('market_off_t') : tr('market_closed_t')}
      </Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 14, marginBottom: 4, backgroundColor: '#fff', borderRadius: 14, paddingVertical: 10, paddingHorizontal: 8, borderWidth: 1, borderColor: C.line }}>
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={{ fontSize: 9, fontWeight: '800', color: C.slate, letterSpacing: 1, fontFamily: F.xbold }}>{tr('open_time_l').toUpperCase()}</Text>
          <Text style={{ fontSize: 13.5, color: C.ink, fontFamily: F.bold, marginTop: 2 }}>{mk.openTime}</Text>
        </View>
        <View style={{ width: 1, height: 30, backgroundColor: C.line }} />
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={{ fontSize: 9, fontWeight: '800', color: C.slate, letterSpacing: 1, fontFamily: F.xbold }}>{tr('close_time_l').toUpperCase()}</Text>
          <Text style={{ fontSize: 13.5, color: C.ink, fontFamily: F.bold, marginTop: 2 }}>{mk.closeTime}</Text>
        </View>
      </View>
      {mk.betClosingMinutes ? (
        <Text style={{ fontSize: 11, color: C.mut, marginTop: 10, textAlign: 'center', fontFamily: F.reg }}>
          Bets stop {mk.betClosingMinutes} min before each declaration time
        </Text>
      ) : null}
      <Pressable onPress={onClose} style={{ width: '100%', marginTop: 14, paddingVertical: 13, borderRadius: 14, backgroundColor: '#fde68a', alignItems: 'center' }}>
        <Text style={{ color: '#78350f', fontWeight: '800', fontSize: 13.5, letterSpacing: 0.4, fontFamily: F.xbold }}>{tr('ok_understood')}</Text>
      </Pressable>
    </CenterPrompt>
  )
}

// ── Big centered prompt — RESULT DECLARED (+ win/loss) ──
export function ResultPrompt({ tr, mk, onClose }: { tr: Tr; mk: Market; onClose: () => void }) {
  const r = mk.todayResult
  const s = mk.mySummary
  const won = !!s && s.winAmount > 0
  const declaredAt = r && (r as { declaredAt?: string }).declaredAt
  return (
    <CenterPrompt headerGrad={['#7c3aed', '#db2777']} icon="party" onClose={onClose}>
      <Text style={{ fontFamily: F.sora, fontSize: 18, color: C.ink, textAlign: 'center' }}>{(mk.displayName || mk.name).toUpperCase()}</Text>
      <Text style={{ fontSize: 13, fontWeight: '800', color: C.purpleTx, marginTop: 5, letterSpacing: 0.4, textAlign: 'center', fontFamily: F.xbold }}>{tr('result_declared_t')}</Text>
      <View style={{ alignSelf: 'center', marginTop: 10, borderRadius: 14, paddingVertical: 8, paddingHorizontal: 18, backgroundColor: '#7c3aed' }}>
        <Text style={{ fontFamily: 'monospace', fontWeight: '800', fontSize: 21, letterSpacing: 1.2, color: '#fff' }}>
          {r ? `${r.openPanna || '***'}-${r.jodi || '**'}-${r.closePanna || '***'}` : '—'}
        </Text>
      </View>
      {r?.openPanna && r?.closePanna ? (
        <Text style={{ fontSize: 11, color: C.mut, marginTop: 7, textAlign: 'center', fontFamily: F.reg }}>
          {r.openPanna} → {r.openDigit} · {r.closePanna} → {r.closeDigit}
        </Text>
      ) : null}
      {s && s.bids > 0 ? (
        <>
          <View style={{
            marginTop: 12, borderRadius: 14, paddingVertical: 11, paddingHorizontal: 10,
            backgroundColor: won ? C.greenSoft : C.redSoft, borderWidth: 1, borderColor: won ? '#bbf7d0' : '#fecaca',
          }}>
            <Text style={{ fontWeight: '800', fontSize: 14.5, textAlign: 'center', color: won ? '#15803d' : C.red, fontFamily: F.xbold }}>
              {won ? tr('you_won') + ' ' + fmt(s.winAmount) : tr('better_luck')}
            </Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 14, marginTop: 10, flexWrap: 'wrap' }}>
            <Text style={{ fontSize: 10.5, color: C.mut, fontFamily: F.reg }}>{tr('bids')}: <Text style={{ color: C.ink, fontWeight: '700' }}>{s.bids}</Text></Text>
            <Text style={{ fontSize: 10.5, color: C.mut, fontFamily: F.reg }}>{tr('staked_l')}: <Text style={{ color: C.ink, fontWeight: '700' }}>{fmt(s.staked)}</Text></Text>
            <Text style={{ fontSize: 10.5, color: C.mut, fontFamily: F.reg }}>{tr('won_bids')}: <Text style={{ color: C.ink, fontWeight: '700' }}>{s.won}</Text></Text>
            <Text style={{ fontSize: 10.5, color: C.mut, fontFamily: F.reg }}>{tr('lost_bids')}: <Text style={{ color: C.ink, fontWeight: '700' }}>{s.lost}</Text></Text>
          </View>
        </>
      ) : (
        <Text style={{ fontSize: 11, color: C.mut, marginTop: 12, textAlign: 'center', fontFamily: F.reg }}>{tr('no_bids_in')}</Text>
      )}
      {declaredAt ? (
        <Text style={{ fontSize: 11, color: C.mut, marginTop: 9, textAlign: 'center', fontFamily: F.reg }}>
          {tr('declared_at_l')}: {new Date(declaredAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true })}
        </Text>
      ) : null}
      <Pressable onPress={onClose} style={{ width: '100%', marginTop: 14, paddingVertical: 13, borderRadius: 14, backgroundColor: '#fde68a', alignItems: 'center' }}>
        <Text style={{ color: '#78350f', fontWeight: '800', fontSize: 13.5, letterSpacing: 0.4, fontFamily: F.xbold }}>{tr('got_it')}</Text>
      </Pressable>
    </CenterPrompt>
  )
}
