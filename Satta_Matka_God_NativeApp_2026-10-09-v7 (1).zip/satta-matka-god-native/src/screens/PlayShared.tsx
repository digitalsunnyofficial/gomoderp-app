// ──────────────────────────────────────────────────────────
// PLAY SHARED — Tile, Grid, Bet Slip, Chart Preview, Paste
// modal, Seed-game panel, Ank-family panel, Ank bulk strip,
// play charts modal. Faithful RN port of PlayScreens.tsx.
// ──────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useState } from 'react'
import { Pressable, ScrollView, Text, TextInput, View } from 'react-native'
import { I, Btn, Chip, Card, Inp, Lbl, SheetModal, TYPE_CHIP } from '../ui'
import { C, F } from '../theme'
import type { Market, MarketGame, SlipEntry } from '../lib/api'
import { api } from '../lib/api'
import {
  SPB, DPB, TP, RATE_LBL, rateFor,
} from '../lib/matka/app-engine'
import { parseQuickData } from '../lib/matka/app-engine'
import { expandGame, gameLabel } from '../lib/matka/games-engine'
import { canonicalPanna } from '../lib/matka/chart-definitions'
import { JodiChart, PanelChart, type ResultRowT } from './Charts'

// Operator-canonical panna spelling for every grid/picker (web: SPB_C/DPB_C)
export const SPB_C: Record<string, string[]> = Object.fromEntries(
  Object.entries(SPB).map(([k, v]) => [k, v.map(canonicalPanna)]))
export const DPB_C: Record<string, string[]> = Object.fromEntries(
  Object.entries(DPB).map(([k, v]) => [k, v.map(canonicalPanna)]))

export type Kind = 'single' | 'jodi' | 'panna' | 'tp' | 'hs' | 'hsb' | 'fs' | 'oddeven' | 'seed'
export function kindOf(g: MarketGame | null, code: string): Kind {
  if (!g) {
    if (code === 'single') return 'single'
    if (code === 'jodi') return 'jodi'
    if (code === 'sp' || code === 'dp') return 'panna'
    if (code === 'tp') return 'tp'
    if (code === 'hs') return 'hs'
    if (code === 'hsb') return 'hsb'
    if (code === 'fs') return 'fs'
    if (code === 'oddeven') return 'oddeven'
    return 'seed'
  }
  if (g.base === 'digits') return 'seed'
  if (g.expansion !== 'none' && g.expansion !== 'sp' && g.expansion !== 'dp' && g.expansion !== 'tp') return 'seed'
  if (g.code === 'single') return 'single'
  if (g.code === 'jodi') return 'jodi'
  if (g.code === 'sp' || g.code === 'dp') return 'panna'
  if (g.code === 'tp') return 'tp'
  if (g.code === 'hs') return 'hs'
  if (g.code === 'hsb') return 'hsb'
  if (g.code === 'fs') return 'fs'
  if (g.code === 'oddeven') return 'oddeven'
  return 'seed'
}
export function iconForGame(g: MarketGame): string {
  return GAME_ICONS_SAFE[g.code] || (kindOf(g, g.code) === 'seed' ? 'flask-conical' : 'sparkles')
}
const GAME_ICONS_SAFE: Record<string, string> = {
  single: 'target', jodi: 'link-2', sp: 'hash', dp: 'layout-grid', tp: 'boxes',
  hs: 'git-merge', hsb: 'git-merge', fs: 'puzzle', oddeven: 'split',
  'sp-motor': 'cog', 'dp-motor': 'cog', motor: 'cog', spdp: 'shapes', sptp: 'shapes',
  dptp: 'shapes', spdptp: 'shapes', 'family-4': 'shapes', 'family-6': 'shapes', 'family-8': 'shapes',
  family: 'shapes',
  'chart-20': 'dices', 'chart-30': 'dices', 'chart-40': 'dices', 'chart-50': 'dices',
  'chart-60': 'dices', 'chart-70': 'dices', 'chart-90dp': 'dices', 'chart-abr': 'dices',
  'dp-50': 'dices', 'dp-60': 'dices', 'dp-70': 'dices', 'dp-90': 'dices', 'dp-90ab': 'dices',
}

// ── Grid — .grid.g5/.g4 flexbox columns with measured width ──
export function Grid({ cols, children, style, scroll }: {
  cols: number; children: React.ReactNode; style?: object; scroll?: boolean
}) {
  const [w, setW] = useState(0)
  const gap = 8
  const cell = w ? Math.floor((w - gap * (cols - 1)) / cols) : 0
  const items = React.Children.toArray(children)
  const body = (
    <View style={[{ flexDirection: 'row', flexWrap: 'wrap', gap }, style]} onLayout={e => setW(e.nativeEvent.layout.width)}>
      {items.map((c, i) => <View key={i} style={{ width: cell }}>{c}</View>)}
    </View>
  )
  return body
}

// ── Tile — .tile: green number tile with points input; amber when filled ──
export function Tile({ mk, mkName, slot, type, num, big, rate, gameCode, slip, setEntry }: {
  mk: string; mkName: string; slot: string; type: string; num: string; big?: boolean
  rate: number; gameCode: string | null
  slip: SlipEntry[]
  setEntry: (key: string, mk: string, slot: string, type: string, num: string, pts: number, rate: number, label: string, gameCode: string | null) => void
}) {
  const key = mk + '|' + slot + '|' + type + '|' + num
  const e = slip.find(x => x.key === key)
  const [txt, setTxt] = useState(e ? String(e.pts) : '')
  useEffect(() => { if (!e && txt !== '') setTxt('') }, [e, txt])
  const has = !!e
  return (
    <View style={{
      backgroundColor: C.tile, borderWidth: 1, borderColor: '#bbf7d0', borderRadius: 11,
      alignItems: 'center', paddingTop: 7, paddingBottom: 8, paddingHorizontal: 2,
    }}>
      <Text style={{ fontWeight: '800', fontSize: big ? 15 : 13.5, color: C.tilet, fontFamily: 'monospace' }}>{num}</Text>
      <TextInput
        keyboardType="number-pad" placeholder="-" placeholderTextColor={C.slate} value={txt}
        onChangeText={v => {
          const vv = v.replace(/\D/g, '')
          setTxt(vv)
          setEntry(key, mk, slot, type, num, Number(vv) || 0, rate, mkName + ' · ' + (RATE_LBL[type] || type) + ' ' + num, gameCode)
        }}
        style={{
          marginTop: 5, width: '100%', borderWidth: 1, borderColor: has ? C.gold : '#bbf7d0',
          borderRadius: 7, paddingVertical: 4, paddingHorizontal: 2, fontSize: 11.5, textAlign: 'center',
          fontWeight: '700', color: has ? '#78350f' : C.ink, backgroundColor: has ? '#fef3c7' : '#fff', height: 28,
        }}
      />
    </View>
  )
}

// ── Bet Slip — .slip ──
export function Slip({ tr, slip, removeSlip, clearSlip, onSubmit, disabled }: {
  tr: (k: string) => string
  slip: SlipEntry[]
  removeSlip: (i: number) => void
  clearSlip: () => void
  onSubmit: () => void
  disabled?: boolean
}) {
  const pts = slip.reduce((a, s) => a + s.pts, 0)
  return (
    <View style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 16, paddingVertical: 12, paddingHorizontal: 13, marginTop: 14, marginBottom: 4, shadowColor: '#1e293b', shadowOpacity: 0.08, shadowRadius: 12, elevation: 3 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6, alignItems: 'center' }}>
        <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{tr('bet_slip')} ({slip.length})</Text>
        {slip.length ? (
          <Pressable onPress={clearSlip}><Text style={{ fontSize: 11, color: C.red, fontWeight: '800', fontFamily: F.xbold }}>{tr('clear_all')}</Text></Pressable>
        ) : null}
      </View>
      {slip.length ? (
        <ScrollView style={{ maxHeight: 130 }} nestedScrollEnabled>
          {slip.map((s, i) => (
            <View key={s.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: C.line, borderStyle: 'dashed' }}>
              <Chip variant={s.type === 'hs' || s.type === 'hsb' || s.type === 'fs' ? 'c-pink' : 'c-gray'}>{s.type.toUpperCase()}</Chip>
              <Text style={{ fontFamily: 'monospace', fontWeight: '800', color: C.ink }}>{canonicalPanna(s.num)}</Text>
              <Text style={{ fontSize: 11, color: C.mut, flex: 1 }} numberOfLines={1}>{s.label.split('·')[0]}</Text>
              <Text style={{ fontWeight: '800', color: C.ink, fontSize: 12 }}>{s.pts} pts</Text>
              <Pressable onPress={() => removeSlip(i)} hitSlop={6}><I n="x" size={13} color="#cbd5e1" /></Pressable>
            </View>
          ))}
        </ScrollView>
      ) : <Text style={{ fontSize: 11, color: C.mut, paddingVertical: 5, fontFamily: F.reg }}>{tr('enter_points')}</Text>}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 10, color: C.mut, fontWeight: '700', fontFamily: F.bold }}>{tr('bids')}: {slip.length}</Text>
          <Text style={{ fontSize: 14, fontWeight: '800', fontFamily: F.xbold, color: C.ink }}>
            {tr('points')}: <Text style={{ color: C.pinkT, fontStyle: 'normal' }}>{pts}</Text>
          </Text>
        </View>
        <Btn variant="g" icon="check" label={tr('submit')} disabled={disabled} onPress={onSubmit} style={{ paddingVertical: 13, paddingHorizontal: 26 }} textStyle={{ fontSize: 14 }} />
      </View>
    </View>
  )
}

// ── Live chart preview — .pickrow chips ──
export function ChartPreview({ mode, ank, session, marketName, slip }: {
  mode: string; ank: number; session: string; marketName: string; slip: SlipEntry[]
}) {
  const chip = (n: string) => {
    const inSlip = slip.some(s => s.num === n)
    return (
      <View key={n} style={{ backgroundColor: inSlip ? C.p1 : C.purpleChipBg, borderRadius: 9, paddingHorizontal: 11, paddingVertical: 6 }}>
        <Text style={{ color: inSlip ? '#fff' : C.purpleChipTx, fontWeight: '700', fontSize: 12, fontFamily: 'monospace' }}>{n}</Text>
      </View>
    )
  }
  let title = ''
  let body: React.ReactNode = null
  if (mode === 'single') {
    title = 'Single Digit Chart — 0 to 9'
    body = <Wrap>{Array.from({ length: 10 }, (_, i) => chip(String(i)))}</Wrap>
  } else if (mode === 'jodi') {
    title = 'Jodi Chart — 00 to 99'
    body = <Wrap>{Array.from({ length: 100 }, (_, j) => chip(String(j).padStart(2, '0')))}</Wrap>
  } else if (mode === 'sp' || mode === 'dp') {
    const U = mode === 'sp' ? SPB_C : DPB_C
    title = (mode === 'sp' ? 'Single Panna' : 'Double Pana') + ' Chart — ank ' + ank
    body = <Wrap>{U[ank].map(chip)}</Wrap>
  } else if (mode === 'tp') {
    title = 'Triple Pana Chart'
    body = <Wrap>{TP.map(p => chip(canonicalPanna(p)))}</Wrap>
  }
  return (
    <Card style={{ padding: 12, marginTop: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8, alignItems: 'center' }}>
        <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink, flex: 1 }}>{title}</Text>
        <Chip variant="c-teal">LIVE PREVIEW · {marketName} · {session.toUpperCase()}</Chip>
      </View>
      {body}
      <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Highlighted numbers are already in your slip — the chart updates as you pick.</Text>
    </Card>
  )
}
function Wrap({ children }: { children: React.ReactNode }) {
  return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{children}</View>
}

// ── Paste WhatsApp data modal ──
export function PasteModal({ market, session, tr, onClose, onAdd, showToast }: {
  market: Market; session: string; tr: (k: string) => string
  onClose: () => void
  onAdd: (items: Array<{ num: string; type: string; points: number }>) => number
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
}) {
  const [text, setText] = useState('')
  const parsed = useMemo(() => parseQuickData(text), [text])
  const total = parsed.items.reduce((a, i) => a + i.points, 0)
  const typeChip: Record<string, 'c-teal' | 'c-cyan' | 'c-orange' | 'c-yellow'> = { single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow', tp: 'c-yellow' }
  return (
    <SheetModal title={tr('paste_title')} onClose={onClose}>
      <Text style={{ fontSize: 11, color: C.mut, marginBottom: 8, fontFamily: F.reg }}>
        {market.name} · <Text style={{ fontWeight: '700' }}>{session === 'open' ? tr('open') : tr('close')}</Text> {tr('session_word')} — {tr('paste_hint')}
      </Text>
      <TextInput
        multiline numberOfLines={6}
        placeholder={'1,2,5 = 100\n70 = 50\n128 = 25'} placeholderTextColor={C.slate}
        value={text} onChangeText={setText}
        style={{ borderWidth: 1, borderColor: C.line, borderRadius: 10, padding: 12, backgroundColor: '#fff', color: C.ink, fontFamily: 'monospace', fontSize: 12.5, minHeight: 120, textAlignVertical: 'top' }}
      />
      {parsed.items.length ? (
        <Card style={{ padding: 10, marginTop: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6, alignItems: 'center' }}>
            <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{tr('auto_calc')} ({parsed.items.length})</Text>
            <Chip variant="c-gold">TOTAL {total} pts</Chip>
          </View>
          <ScrollView style={{ maxHeight: 150 }} nestedScrollEnabled>
            {parsed.items.map((it, i) => (
              <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: C.line, borderStyle: 'dashed' }}>
                <Chip variant={typeChip[it.type] || 'c-gray'}>{it.type.toUpperCase()}</Chip>
                <Text style={{ fontFamily: 'monospace', fontWeight: '800', color: C.ink }}>{it.num}</Text>
                <Text style={{ fontSize: 11, color: C.mut, flex: 1 }}>{RATE_LBL[it.type] || it.type}</Text>
                <Text style={{ fontWeight: '800', color: C.ink, fontSize: 12 }}>{it.points} pts</Text>
              </View>
            ))}
          </ScrollView>
        </Card>
      ) : null}
      {parsed.errors.length ? (
        <Text style={{ fontSize: 11, color: C.red, marginTop: 8, fontFamily: F.reg }}>
          {tr('skipped')} {parsed.errors.length}: <Text style={{ fontFamily: 'monospace' }}>{parsed.errors.slice(0, 3).join(' · ')}</Text>{parsed.errors.length > 3 ? ' …' : ''}
        </Text>
      ) : null}
      <Btn variant="g" icon="check" label={`${tr('review_add')} ${parsed.items.length ? `(${parsed.items.length} · ${total} PTS)` : ''}`} disabled={!parsed.items.length}
        onPress={() => { const n = onAdd(parsed.items); showToast(n + ' ' + tr('bids_added'), 'ok'); onClose() }}
        style={{ width: '100%', marginTop: 12, paddingVertical: 13 }} />
    </SheetModal>
  )
}

// ── Seed-game panel (Motor / charts) — seed + points → live expansion ──
export function SeedGamePanel({ game, mk, mkName, slot, tr, onAdd, showToast }: {
  game: MarketGame; mk: string; mkName: string; slot: string; tr: (k: string) => string
  onAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
}) {
  const [seed, setSeed] = useState('')
  const [pts, setPts] = useState('')
  const hint = game.base === 'digits' ? tr('seed_hint_digits') : game.expansion.startsWith('chart') || game.base === 'panna' ? tr('seed_hint_panna') : tr('seed_hint_ank')
  const points = Number(pts) || 0
  const res = useMemo(() => (seed.trim() ? expandGame(game.code, seed) : null), [game.code, seed])
  const rows = res?.rows || null
  const okRows = (rows || []).filter(r => r.ok)
  const total = okRows.length * points
  const minOk = points >= (game.minPoints || 10)
  const errMsg = !seed.trim() ? ''
    : res?.error ? res.error
    : rows && rows.length && !okRows.length ? (rows[0]?.reason || 'No valid numbers')
    : !minOk ? tr('min_points') + ' (' + (game.minPoints || 10) + ')'
    : ''
  const addAll = () => {
    if (!okRows.length || !minOk) return
    onAdd(okRows.map(r => ({
      marketCode: mk, slot, type: r.type, num: canonicalPanna(r.num), points,
      rate: game.rate || rateFor(mk, r.type), marketName: mkName, gameCode: game.code,
    })))
    showToast(okRows.length + ' ' + tr('bids_added'), 'ok')
    setSeed(''); setPts('')
  }
  const typeChip: Record<string, 'c-teal' | 'c-cyan' | 'c-orange' | 'c-yellow'> = { single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow', tp: 'c-yellow' }
  return (
    <Card style={{ padding: 12, marginTop: 2 }}>
      <Text style={{ fontSize: 12, color: C.mut, marginBottom: 8, fontFamily: F.reg }}>
        {game.name} — <Text style={{ fontFamily: 'monospace' }}>{game.erpMapping}</Text> · pays 1:{game.rate || rateFor(mk, 'sp')}
      </Text>
      <Lbl>{tr('enter_seed').toUpperCase()} ({hint})</Lbl>
      <Inp mono value={seed} onChangeText={setSeed} placeholder={hint} style={{ fontWeight: '800', letterSpacing: 1 }} />
      <Lbl style={{ marginTop: 9 }}>{tr('per_row').toUpperCase()} (MIN {game.minPoints || 10})</Lbl>
      <Inp keyboardType="number-pad" maxLength={6} value={pts} onChangeText={v => setPts(v.replace(/\D/g, ''))} placeholder={String(game.minPoints || 10)} />
      {errMsg ? <Text style={{ fontSize: 11, color: C.red, marginTop: 8, fontFamily: F.reg }}>{errMsg}</Text> : null}
      {rows && okRows.length ? (
        <View style={{ backgroundColor: C.lavender, borderWidth: 1, borderColor: C.lavenderLine, borderRadius: 16, padding: 10, marginTop: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6, alignItems: 'center' }}>
            <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{tr('expansion_preview')} ({okRows.length})</Text>
            <Chip variant="c-pink">{okRows.length} × {points} = {total} pts</Chip>
          </View>
          <ScrollView style={{ maxHeight: 160 }} nestedScrollEnabled>
            {rows.map((r, i) => (
              <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: C.line, opacity: r.ok ? 1 : 0.5 }}>
                <Chip variant={typeChip[r.type] || 'c-gray'}>{r.type.toUpperCase()}</Chip>
                <Text style={{ fontFamily: 'monospace', fontWeight: '800', color: C.ink }}>{canonicalPanna(r.num)}</Text>
                <Text style={{ fontSize: 11, color: C.mut, flex: 1 }}>{r.ok ? '' : (r.reason || '')}</Text>
                <Text style={{ fontWeight: '800', color: C.ink, fontSize: 12 }}>{r.ok ? points : '—'}</Text>
              </View>
            ))}
          </ScrollView>
          <Btn variant="g" icon="check" label={`${tr('add_to_slip')} (${okRows.length} ${tr('rows_will_place')} · ${total} PTS)`} disabled={!okRows.length || !minOk} onPress={addAll} style={{ width: '100%', marginTop: 8 }} />
        </View>
      ) : null}
    </Card>
  )
}

// ── Ank-family panel — pick ONE ank → every panna of that ank ──
export function AnkFamilyPanel({ game, mk, mkName, slot, tr, onAdd, showToast }: {
  game: MarketGame; mk: string; mkName: string; slot: string; tr: (k: string) => string
  onAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
}) {
  const [ank, setAnk] = useState(0)
  const [pts, setPts] = useState('')
  const res = useMemo(() => expandGame(game.code, String(ank)), [game.code, ank])
  const okRows = (res?.rows || []).filter(r => r.ok)
  const points = Number(pts) || 0
  const total = okRows.length * points
  const minOk = points >= (game.minPoints || 10)
  const byType = okRows.reduce<Record<string, number>>((a, r) => { a[r.type] = (a[r.type] || 0) + 1; return a }, {})
  const typeChip: Record<string, 'c-teal' | 'c-cyan' | 'c-orange' | 'c-yellow'> = { single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow', tp: 'c-yellow' }
  const addAll = () => {
    if (!okRows.length || !minOk) return
    onAdd(okRows.map(r => ({
      marketCode: mk, slot, type: r.type, num: canonicalPanna(r.num), points,
      rate: game.rate || rateFor(mk, r.type), marketName: mkName, gameCode: game.code,
    })))
    showToast(okRows.length + ' ' + tr('bids_added'), 'ok')
    setPts('')
  }
  return (
    <Card style={{ padding: 12, marginTop: 2 }}>
      <Text style={{ fontSize: 12, color: C.mut, marginBottom: 8, fontFamily: F.reg }}>
        {game.name} — <Text style={{ fontFamily: 'monospace' }}>{game.erpMapping}</Text> · pays 1:{game.rate || rateFor(mk, 'sp')} — pick an ank, every panna of that ank is played
      </Text>
      <Lbl>{tr('pick_ank').toUpperCase()}</Lbl>
      <AnkChips ank={ank} setAnk={setAnk} />
      {okRows.length ? (
        <View style={{ backgroundColor: C.lavender, borderWidth: 1, borderColor: C.lavenderLine, borderRadius: 16, padding: 10, marginTop: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6, flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
            <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{tr('expansion_preview')} ({okRows.length})</Text>
            <View style={{ flexDirection: 'row', gap: 4, flexWrap: 'wrap' }}>
              {Object.entries(byType).map(([tp, n]) => <Chip key={tp} variant={typeChip[tp] || 'c-gray'}>{n} {tp.toUpperCase()}</Chip>)}
            </View>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4 }}>
            {okRows.map((r, i) => (
              <View key={i} style={{ paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999, backgroundColor: C.slateSoft }}>
                <Text style={{ fontFamily: 'monospace', fontWeight: '800', color: C.grayChipTx, fontSize: 10.5 }}>{canonicalPanna(r.num)}</Text>
              </View>
            ))}
          </View>
        </View>
      ) : (
        <Text style={{ fontSize: 11, color: C.mut, marginTop: 10, fontFamily: F.reg }}>
          No entries for ank {ank} in this game{game.code === 'dp-motor' ? ' — the DP Motor chart covers anks 1-9' : ''}.
        </Text>
      )}
      <Lbl style={{ marginTop: 9 }}>{tr('per_row').toUpperCase()} (MIN {game.minPoints || 10})</Lbl>
      <Inp keyboardType="number-pad" maxLength={6} value={pts} onChangeText={v => setPts(v.replace(/\D/g, ''))} placeholder={String(game.minPoints || 10)} />
      <Btn variant="g" icon="check" label={`${tr('add_to_slip')} ${okRows.length ? `(${okRows.length} ${tr('rows_will_place')} · ${total} PTS)` : ''}`} disabled={!okRows.length || !minOk} onPress={addAll} style={{ width: '100%', marginTop: 11 }} />
    </Card>
  )
}

// ── .achips — ank selector chips ──
export function AnkChips({ ank, setAnk }: { ank: number; setAnk: (a: number) => void }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }} contentContainerStyle={{ gap: 6, paddingBottom: 4 }}>
      {Array.from({ length: 10 }, (_, a) => (
        <Pressable key={a} onPress={() => setAnk(a)} style={{
          backgroundColor: ank === a ? C.pinkT : C.pink, borderWidth: 1, borderColor: '#fbcfe8',
          borderRadius: 10, paddingHorizontal: 13, paddingVertical: 7,
        }}>
          <Text style={{ color: ank === a ? '#fff' : C.pinkT, fontWeight: '800', fontSize: 13, fontFamily: 'monospace' }}>{a}</Text>
        </Pressable>
      ))}
    </ScrollView>
  )
}

// ── Bet-the-whole-ank strip — .card blue ──
export function AnkBulkStrip({ mk, mkName, slot, type, nums, rate, minPoints, gameCode, tr, onBulkAdd, showToast }: {
  mk: string; mkName: string; slot: string; type: string; nums: string[]
  rate: number; minPoints: number; gameCode: string | null; tr: (k: string) => string
  onBulkAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
}) {
  const [pts, setPts] = useState('')
  const points = Number(pts) || 0
  const ok = nums.length > 0 && points >= minPoints
  return (
    <View style={{ backgroundColor: C.blueSoft, borderWidth: 1, borderColor: C.blueLine, borderRadius: 16, padding: 10, marginTop: 10 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
        <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink, flex: 1 }}>Bet the whole ank — all {nums.length} {type.toUpperCase()} pannas of ank</Text>
        <Chip variant="c-teal">{nums.length} × {points || '…'} = {nums.length * (points || 0)} pts</Chip>
      </View>
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, alignItems: 'center' }}>
        <Inp keyboardType="number-pad" maxLength={6} placeholder={`points per panna (min ${minPoints})`} value={pts} onChangeText={v => setPts(v.replace(/\D/g, ''))} style={{ flex: 1 }} />
        <Btn variant="g" icon="layers" label={`Add ${nums.length} to Slip`} disabled={!ok} onPress={() => {
          onBulkAdd(nums.map(n => ({ marketCode: mk, slot, type, num: n, points, rate, marketName: mkName, gameCode })))
          showToast(nums.length + ' ' + tr('bids_added'), 'ok')
          setPts('')
        }} style={{ paddingVertical: 11, paddingHorizontal: 16 }} />
      </View>
    </View>
  )
}

// ── In-play charts modal (graph button on the play screen) ──
export function PlayChartsModal({ marketCode, marketName, onClose }: {
  marketCode: string; marketName: string; onClose: () => void
}) {
  const [tab, setTab] = useState<'jodi' | 'panel'>('jodi')
  const [results, setResults] = useState<ResultRowT[]>([])
  useEffect(() => {
    let live = true
    const load = () => {
      api<{ results: ResultRowT[] }>('/api/customer-app/results?market=' + marketCode)
        .then(d => { if (live) setResults(d.results || []) })
        .catch(() => {})
    }
    load()
    const t2 = setInterval(load, 10000)
    return () => { live = false; clearInterval(t2) }
  }, [marketCode])
  return (
    <SheetModal title={`${marketName} — Results Chart`} onClose={onClose}>
      <Tabs tabs={[['jodi', 'Jodi Chart'], ['panel', 'Panel Chart']]} value={tab} onChange={v => setTab(v as 'jodi' | 'panel')} />
      {tab === 'jodi' ? <JodiChart results={results} mkName={marketName} /> : <PanelChart results={results} mkName={marketName} />}
    </SheetModal>
  )
}

// ── .tabs — lavender segmented tabs ──
export function Tabs({ tabs, value, onChange, style }: {
  tabs: Array<[string, string]>; value: string; onChange: (v: string) => void; style?: object
}) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={[{ backgroundColor: C.purpleChipBg, borderRadius: 12, padding: 4, marginTop: 12, marginBottom: 10, flexGrow: 0 }, style]}>
      {tabs.map(([k, l]) => (
        <Pressable key={k} onPress={() => onChange(k)} style={{
          paddingHorizontal: 14, paddingVertical: 8, borderRadius: 9, marginRight: 3,
          backgroundColor: value === k ? '#fff' : 'transparent',
          shadowColor: '#1e293b', shadowOpacity: value === k ? 0.1 : 0, shadowRadius: 6, elevation: value === k ? 2 : 0,
        }}>
          <Text style={{ fontSize: 11, fontWeight: '800', fontFamily: F.xbold, color: value === k ? C.p2 : C.p1 }}>{l}</Text>
        </Pressable>
      ))}
    </ScrollView>
  )
}

export { TYPE_CHIP }
