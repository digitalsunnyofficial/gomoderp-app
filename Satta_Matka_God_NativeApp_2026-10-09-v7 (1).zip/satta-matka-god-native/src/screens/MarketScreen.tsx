// ──────────────────────────────────────────────────────────
// MARKET PLAY — faithful RN port of PlayScreen (web):
// subbar / session tabs / live countdown / game tabs from the
// ERP allocation / rate bar + paste / tiles grids / ank chips /
// sangam pickers / odd-even / seed + ank-family panels / chart
// preview / bet slip. Genuine RN components only.
// ──────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react'
import { Pressable, ScrollView, Text, TextInput, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Btn, Chip, Card, Inp, Lbl, fmt } from '../ui'
import { C, F, GRAD } from '../theme'
import type { Market, MarketGame, SlipEntry } from '../lib/api'
import {
  RATE_LBL, rateFor, deriveDigit, slotAccepting, secsLeftToClose, fmtCountdown, TP,
} from '../lib/matka/app-engine'
import { todayStr } from '../ui'
import { canonicalPanna } from '../lib/matka/chart-definitions'
import { gameLabel } from '../lib/matka/games-engine'
import type { Lang } from '../lib/matka/i18n'
import {
  SPB_C, DPB_C, kindOf, iconForGame, Grid, Tile, Slip, ChartPreview,
  PasteModal, SeedGamePanel, AnkFamilyPanel, AnkBulkStrip, PlayChartsModal, Tabs, AnkChips,
} from './PlayShared'

type Tr = (k: string) => string
export type SlipInputFn = (
  key: string, mk: string, slot: string, type: string, num: string, pts: number, rate: number, label: string, gameCode: string | null
) => void

export default function MarketScreen({ market, lang, tr, wallet, slip, setEntry, removeSlip, clearSlip, onSubmit, onBack, onBulkAdd, showToast }: {
  market: Market
  lang: Lang
  tr: Tr
  wallet: number
  slip: SlipEntry[]
  setEntry: SlipInputFn
  removeSlip: (i: number) => void
  clearSlip: () => void
  onSubmit: () => void
  onBack: () => void
  onBulkAdd: (items: Array<{ marketCode: string; slot: string; type: string; num: string; points: number; rate: number; marketName: string; gameCode?: string | null }>) => void
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
}) {
  const insets = useSafeAreaInsets()
  const mkSession: 'open' | 'close' | 'both' = market.session === 'open' || market.session === 'close' ? market.session : 'both'
  const games: MarketGame[] = (market.games?.length ? market.games : [
    { code: 'single', name: 'Single Digit', base: 'ank', session: 'both', expansion: 'none', icon: 'zap', erpMapping: 'Single', rate: 9, minPoints: 10 },
    { code: 'jodi', name: 'Jodi', base: 'jodi', session: 'both', expansion: 'none', icon: 'layers', erpMapping: 'Jodi', rate: 90, minPoints: 10 },
    { code: 'sp', name: 'Single Pana', base: 'panna', session: 'both', expansion: 'none', icon: 'layers', erpMapping: 'SP', rate: 140, minPoints: 10 },
    { code: 'dp', name: 'Double Pana', base: 'panna', session: 'both', expansion: 'none', icon: 'layers', erpMapping: 'DP', rate: 280, minPoints: 10 },
    { code: 'tp', name: 'Triple Pana', base: 'panna', session: 'close', expansion: 'none', icon: 'layers', erpMapping: 'TP', rate: 700, minPoints: 10 },
  ]).filter(g => g.code !== 'jodi' || mkSession !== 'close')
  const [mode, setMode] = useState<string>(games[0]?.code || 'single')
  const [session, setSession] = useState<'open' | 'close'>(mkSession === 'close' ? 'close' : 'open')
  const [ank, setAnk] = useState(0)
  const [showPaste, setShowPaste] = useState(false)
  const [showCharts, setShowCharts] = useState(false)
  const [hsDigit, setHsDigit] = useState<number | null>(null)
  const [hsAnk, setHsAnk] = useState(0)
  const [hsPanna, setHsPanna] = useState<string | null>(null)
  const [hbAnk, setHbAnk] = useState(0)
  const [hbPanna, setHbPanna] = useState<string | null>(null)
  const [hbDigit, setHbDigit] = useState<number | null>(null)
  const [fsOAnk, setFsOAnk] = useState(0)
  const [fsOpen, setFsOpen] = useState<string | null>(null)
  const [fsCAnk, setFsCAnk] = useState(0)
  const [fsClose, setFsClose] = useState<string | null>(null)
  const [hsPts, setHsPts] = useState('')
  const [hbPts, setHbPts] = useState('')
  const [fsPts, setFsPts] = useState('')
  const [, forceTick] = useState(0)

  const game = games.find(g => g.code === mode) || games[0]
  const kind = kindOf(game, mode)
  useEffect(() => {
    const t2 = setInterval(() => forceTick(x => x + 1), 1000)
    return () => clearInterval(t2)
  }, [])

  const fixedClose = kind === 'tp' || game?.session === 'close'
  const fixedOpen = game?.session === 'open' && kind !== 'oddeven'
  const sessioned = ['single', 'panna'].includes(kind)
    ? !fixedClose && !fixedOpen
    : kind === 'seed'
      ? game?.session === 'both'
      : false
  const cm = market.betClosingMinutes || 0
  const off = market.isOn === false
  const slot: 'open' | 'close' = fixedClose ? 'close' : 'open'
  const jodiLive = mkSession !== 'close' && slotAccepting(market.openTime, market.closeTime, 'open', new Date(), cm)
  // Triple Pana settles on the close panna but is bettable through the WHOLE
  // betting window — open session AND close session (operator rule 2026-10).
  const tpLive = kind === 'tp'
    ? slotAccepting(market.openTime, market.closeTime, 'open', new Date(), cm) ||
      slotAccepting(market.openTime, market.closeTime, 'close', new Date(), cm)
    : false
  const effSlot: string = kind === 'jodi' ? 'jodi' : (kind === 'hs' || kind === 'hsb') ? 'hs' : kind === 'fs' ? 'fs' : sessioned ? session : slot
  const open = off || market.resultDeclared
    ? false
    : kind === 'tp'
      ? tpLive
      : ['single', 'panna', 'seed'].includes(kind)
        ? slotAccepting(market.openTime, market.closeTime, (fixedClose ? 'close' : session) as 'open' | 'close', new Date(), cm)
        : kind === 'jodi' ? jodiLive : true
  const left = kind === 'tp'
    ? secsLeftToClose(market.openTime, market.closeTime, 'close', new Date(), cm)
    : ['single', 'panna', 'seed'].includes(kind)
      ? secsLeftToClose(market.openTime, market.closeTime, (fixedClose ? 'close' : session) as 'open' | 'close', new Date(), cm)
      : 0

  const addSangam = (kind2: 'hs' | 'hsb' | 'fs') => {
    if (kind2 === 'hs') {
      if (hsDigit == null || !hsPanna) return
      const pts = Number(hsPts)
      if (!pts || pts < (game?.minPoints || 10)) return
      const num = hsDigit + '-' + hsPanna
      const key = market.code + '|hs|hs|' + num
      if (slip.some(x => x.key === key)) return
      setEntry(key, market.code, 'hs', 'hs', num, pts, game?.rate || rateFor(market.code, 'hs'), market.name + ' · ' + (RATE_LBL.hs || 'hs') + ' ' + num, game?.code || 'hs')
      setHsPts('')
    } else if (kind2 === 'hsb') {
      if (!hbPanna || hbDigit == null) return
      const pts = Number(hbPts)
      if (!pts || pts < (game?.minPoints || 10)) return
      const num = hbPanna + '-' + hbDigit
      const key = market.code + '|hs|hsb|' + num
      if (slip.some(x => x.key === key)) return
      setEntry(key, market.code, 'hs', 'hsb', num, pts, game?.rate || rateFor(market.code, 'hsb'), market.name + ' · ' + (RATE_LBL.hsb || 'hsb') + ' ' + num, game?.code || 'hsb')
      setHbPts('')
    } else {
      if (!fsOpen || !fsClose) return
      const pts = Number(fsPts)
      if (!pts || pts < (game?.minPoints || 10)) return
      const num = fsOpen + '-' + fsClose
      const key = market.code + '|fs|fs|' + num
      if (slip.some(x => x.key === key)) return
      setEntry(key, market.code, 'fs', 'fs', num, pts, game?.rate || rateFor(market.code, 'fs'), market.name + ' · ' + (RATE_LBL.fs || 'fs') + ' ' + num, game?.code || 'fs')
      setFsPts('')
    }
  }

  const grid = () => {
    const mk = market.code, mkName = market.name
    const rate = game?.rate || rateFor(mk, mode === 'sp' ? 'sp' : mode === 'dp' ? 'dp' : mode)
    const gc = game?.code || mode
    if (kind === 'single') {
      return <Grid cols={5}>{Array.from({ length: 10 }, (_, i) =>
        <Tile key={i} mk={mk} mkName={mkName} slot={session} type="single" num={String(i)} big rate={rate} gameCode={gc} slip={slip} setEntry={setEntry} />)}</Grid>
    }
    if (kind === 'jodi') {
      return (
        <>
          <ScrollView style={{ maxHeight: 260 }} nestedScrollEnabled>
            <Grid cols={5}>{Array.from({ length: 100 }, (_, j) => {
              const n = String(j).padStart(2, '0')
              return <Tile key={n} mk={mk} mkName={mkName} slot="jodi" type="jodi" num={n} rate={rate} gameCode={gc} slip={slip} setEntry={setEntry} />
            })}</Grid>
          </ScrollView>
          <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Jodi = Open digit + Close digit · settles on the full result · open session only</Text>
        </>
      )
    }
    if (kind === 'panna') {
      const U = mode === 'sp' ? SPB_C : DPB_C
      return (
        <>
          <AnkChips ank={ank} setAnk={setAnk} />
          <Grid cols={4}>{U[ank].map(p =>
            <Tile key={p} mk={mk} mkName={mkName} slot={session} type={mode} num={p} rate={rate} gameCode={gc} slip={slip} setEntry={setEntry} />)}</Grid>
          <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Ank {ank} · {U[ank].length} pannas · grouped by result digit (same as the master chart)</Text>
          <AnkBulkStrip mk={mk} mkName={mkName} slot={session} type={mode} nums={U[ank]} rate={rate} minPoints={game?.minPoints || 10} gameCode={gc} tr={tr} onBulkAdd={onBulkAdd} showToast={showToast} />
        </>
      )
    }
    if (kind === 'tp') {
      const tpForAnk = canonicalPanna(TP.find(x => deriveDigit(x) === String(ank)) || TP[0])
      return (
        <>
          <AnkChips ank={ank} setAnk={setAnk} />
          <Grid cols={5}>{TP.map(rawP => { const p = canonicalPanna(rawP); return (
            <Tile key={p} mk={mk} mkName={mkName} slot="close" type="tp" num={p} rate={rate} gameCode={gc} slip={slip} setEntry={setEntry} />); })}</Grid>
          <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Triple Pana · all three digits same · pays 1:{rate} · settles on the close panna · ank {ank} → {tpForAnk}</Text>
          <AnkBulkStrip mk={mk} mkName={mkName} slot="close" type="tp" nums={[tpForAnk]} rate={rate} minPoints={game?.minPoints || 10} gameCode={gc} tr={tr} onBulkAdd={onBulkAdd} showToast={showToast} />
        </>
      )
    }
    if (kind === 'seed') {
      if (!game) return null
      if (['spdp', 'sptp', 'dptp', 'spdptp', 'dp-motor'].includes(game.code)) {
        return <AnkFamilyPanel game={game} mk={mk} mkName={mkName} slot={game.session === 'close' ? 'close' : session} tr={tr} onAdd={onBulkAdd} showToast={showToast} />
      }
      return <SeedGamePanel game={game} mk={mk} mkName={mkName} slot={game.session === 'close' ? 'close' : session} tr={tr} onAdd={onBulkAdd} showToast={showToast} />
    }
    if (kind === 'hs') {
      return (
        <>
          <Text style={{ fontSize: 12, color: C.mut, marginBottom: 8, fontFamily: F.reg }}>Half Sangam — pick <Text style={{ fontWeight: '700' }}>Open digit</Text> + <Text style={{ fontWeight: '700' }}>Close panna</Text> · pays 1:{game?.rate || rateFor(mk, 'hs')}</Text>
          <Lbl>OPEN DIGIT</Lbl>
          <PickRow items={Array.from({ length: 10 }, (_, i) => String(i))} value={hsDigit == null ? null : String(hsDigit)} onPick={v => setHsDigit(Number(v))} />
          <Lbl style={{ marginTop: 6 }}>CLOSE PANNA (SP)</Lbl>
          <AnkChips ank={hsAnk} setAnk={setHsAnk} />
          <PickRow items={SPB_C[hsAnk]} value={hsPanna} onPick={setHsPanna} />
          <Lbl style={{ marginTop: 6 }}>POINTS (MIN {game?.minPoints || 10})</Lbl>
          <Inp keyboardType="number-pad" maxLength={6} placeholder="points" value={hsPts} onChangeText={v => setHsPts(v.replace(/\D/g, ''))} style={{ marginTop: 4 }} />
          <Btn variant="g" icon="plus" label="Add Half Sangam to Slip" onPress={() => addSangam('hs')} style={{ width: '100%', marginTop: 10 }} />
        </>
      )
    }
    if (kind === 'hsb') {
      return (
        <>
          <Text style={{ fontSize: 12, color: C.mut, marginBottom: 8, fontFamily: F.reg }}>Half Sangam B — pick <Text style={{ fontWeight: '700' }}>Open panna</Text> + <Text style={{ fontWeight: '700' }}>Close digit</Text> · pays 1:{game?.rate || rateFor(mk, 'hsb')}</Text>
          <Lbl>OPEN PANNA (SP)</Lbl>
          <AnkChips ank={hbAnk} setAnk={setHbAnk} />
          <PickRow items={SPB_C[hbAnk]} value={hbPanna} onPick={setHbPanna} />
          <Lbl style={{ marginTop: 6 }}>CLOSE DIGIT</Lbl>
          <PickRow items={Array.from({ length: 10 }, (_, i) => String(i))} value={hbDigit == null ? null : String(hbDigit)} onPick={v => setHbDigit(Number(v))} />
          <Lbl style={{ marginTop: 6 }}>POINTS (MIN {game?.minPoints || 10})</Lbl>
          <Inp keyboardType="number-pad" maxLength={6} placeholder="points" value={hbPts} onChangeText={v => setHbPts(v.replace(/\D/g, ''))} style={{ marginTop: 4 }} />
          <Btn variant="g" icon="plus" label="Add Half Sangam B to Slip" onPress={() => addSangam('hsb')} style={{ width: '100%', marginTop: 10 }} />
        </>
      )
    }
    if (kind === 'fs') {
      return (
        <>
          <Text style={{ fontSize: 12, color: C.mut, marginBottom: 8, fontFamily: F.reg }}>Full Sangam — pick <Text style={{ fontWeight: '700' }}>Open panna</Text> + <Text style={{ fontWeight: '700' }}>Close panna</Text> · pays 1:{game?.rate || rateFor(mk, 'fs')}</Text>
          <Lbl>OPEN PANNA (SP)</Lbl>
          <AnkChips ank={fsOAnk} setAnk={setFsOAnk} />
          <PickRow items={SPB_C[fsOAnk]} value={fsOpen} onPick={setFsOpen} />
          <Lbl style={{ marginTop: 8 }}>CLOSE PANNA (SP)</Lbl>
          <AnkChips ank={fsCAnk} setAnk={setFsCAnk} />
          <PickRow items={SPB_C[fsCAnk]} value={fsClose} onPick={setFsClose} />
          <Lbl style={{ marginTop: 6 }}>POINTS (MIN {game?.minPoints || 10})</Lbl>
          <Inp keyboardType="number-pad" maxLength={6} placeholder="points" value={fsPts} onChangeText={v => setFsPts(v.replace(/\D/g, ''))} style={{ marginTop: 4 }} />
          <Btn variant="g" icon="plus" label="Add Full Sangam to Slip" onPress={() => addSangam('fs')} style={{ width: '100%', marginTop: 10 }} />
        </>
      )
    }
    if (kind === 'oddeven') {
      const mk = market.code
      return (
        <View style={{ gap: 10 }}>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {['ODD', 'EVEN'].map(o => {
              const key = mk + '|open|oddeven|' + o.toLowerCase()
              const e = slip.find(x => x.key === key)
              return (
                <OddEvenTile key={o} label={o} filled={!!e} mk={mk} mkName={market.name} game={game} setEntry={setEntry} />
              )
            })}
          </View>
          <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Result digit odd/even · pays 1:{game?.rate || rateFor(mk, 'oddeven')}</Text>
        </View>
      )
    }
    return null
  }

  return (
    <>
      {/* .subbar */}
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flexDirection: 'row', alignItems: 'center', gap: 9, paddingTop: insets.top + 9, paddingBottom: 9, paddingHorizontal: 12 }}>
        <Pressable onPress={() => setShowCharts(true)} style={ibtn}><I n="trending-up" size={16} color="#fff" /></Pressable>
        <Pressable onPress={onBack} style={ibtn}><I n="chevron-left" size={16} color="#fff" /></Pressable>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text numberOfLines={1} style={{ fontSize: 14, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>{(market.displayName || market.name).toUpperCase()}</Text>
          <Text numberOfLines={1} style={{ fontSize: 10, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>
            {todayStr()} · {tr('open_time_l')} {market.openTime} · {tr('close_time_l')} {market.closeTime}{cm ? ` · ${tr('closes_early')} ${cm}${tr('early')}` : ''}
          </Text>
        </View>
        <View style={{ backgroundColor: 'rgba(255,255,255,.92)', borderRadius: 999, paddingVertical: 6, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 5 }}>
          <I n="wallet" size={13} color="#78350f" />
          <Text style={{ color: '#78350f', fontSize: 11.5, fontWeight: '800', fontFamily: F.xbold }}>{fmt(wallet)}</Text>
        </View>
      </LinearGradient>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 40 + insets.bottom }} keyboardShouldPersistTaps="handled">
        {/* session tabs */}
        {sessioned ? (
          mkSession === 'both' ? (
            <View style={{ flexDirection: 'row', gap: 7, marginTop: 11 }}>
              {(['open', 'close'] as const).map(s => (
                <Pressable key={s} onPress={() => setSession(s)} style={{
                  flex: 1, paddingVertical: 9, borderRadius: 11, borderWidth: 1,
                  backgroundColor: session === s ? C.p1 : '#fff',
                  borderColor: session === s ? 'transparent' : C.line,
                }}>
                  <Text style={{ textAlign: 'center', fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: session === s ? '#fff' : C.ink }}>
                    {tr(s)}{(s === 'open' ? market.openAccepting : market.closeAccepting) && session === s && open ? ' · ' + tr('live') : ''}
                  </Text>
                </Pressable>
              ))}
            </View>
          ) : (
            <View style={{ flexDirection: 'row', gap: 7, marginTop: 11 }}>
              <View style={{ flex: 1, paddingVertical: 9, borderRadius: 11, backgroundColor: C.p1 }}>
                <Text style={{ textAlign: 'center', fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: '#fff' }}>
                  {mkSession === 'open' ? tr('open') : tr('close')} · {tr('session_word').toUpperCase()}
                </Text>
              </View>
            </View>
          )
        ) : null}

        {/* countdown / lock pill */}
        {off || market.resultDeclared ? (
          <CdWrap run={false}><I n="lock" size={14} color={C.red} /><Text style={cdTx}>{off ? `${market.name} OFF` : tr('result_locked')}</Text></CdWrap>
        ) : !open ? (
          <CdWrap run={false}><I n="lock" size={14} color={C.red} /><Text style={cdTx}>{kind === 'jodi'
            ? 'Jodi is open only during the Open session — jodi combines the open + close digits'
            : kind === 'tp'
              ? `Betting is closed for ${market.name} — bets stop ${cm || 0} min before the close time`
              : <>{tr('betting_closed')} {(fixedClose || !sessioned) ? (effSlot === 'jodi' ? 'Jodi' : tr('close')) : tr('open')} {tr('session_word')} {market.name}</>}</Text></CdWrap>
        ) : ['single', 'panna', 'tp', 'seed'].includes(kind) ? (
          <CdWrap run><I n="timer" size={14} color="#065f46" /><Text style={[cdTx, { color: '#065f46' }]}>{tr('time_left')} </Text><Text style={cdt}>{fmtCountdown(left)}</Text></CdWrap>
        ) : null}

        {/* game tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 2, paddingBottom: 8, paddingRight: 2 }} style={{ marginTop: 12 }}>
          {games.map(g => {
            const jodiLocked = g.code === 'jodi' && !jodiLive
            const on = mode === g.code
            return (
              <Pressable key={g.code} disabled={jodiLocked} onPress={() => setMode(g.code)} style={{
                width: 88, borderWidth: 1.5, borderColor: on ? C.p2 : C.line, borderRadius: 14,
                paddingVertical: 9, paddingHorizontal: 4, paddingBottom: 8, alignItems: 'center', gap: 5,
                backgroundColor: on ? C.lavender : '#fff',
                opacity: jodiLocked ? 0.45 : 1,
              }}>
                <View style={{ width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.p1 : C.slateSoft }}>
                  <I n={jodiLocked ? 'lock' : iconForGame(g)} size={17} color={on ? '#fff' : C.grayChipTx} />
                </View>
                <Text numberOfLines={1} style={{ fontSize: 10, fontWeight: '800', fontFamily: F.xbold, color: on ? C.pinkT : '#475569', maxWidth: '100%' }}>{g.name}</Text>
                <Text style={{ fontSize: 8.5, fontWeight: '800', fontFamily: F.xbold, color: on ? C.p2 : C.slate }}>1:{g.rate || rateFor(market.code, g.code)}</Text>
              </Pressable>
            )
          })}
        </ScrollView>

        {/* rate bar */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', borderWidth: 1, borderColor: '#d8b4fe', borderStyle: 'dashed', borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12, marginBottom: 11 }}>
          <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg, flex: 1 }}>{tr('rate')} · {game?.name || gameLabel(mode)}</Text>
          <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}><Text style={{ color: C.pinkT, fontSize: 13, fontWeight: '700' }}>1 : {game?.rate || rateFor(market.code, mode)}</Text></Text>
          <Btn variant="w" icon="layers" label={tr('paste_data')} onPress={() => setShowPaste(true)} style={{ paddingVertical: 6, paddingHorizontal: 11, borderRadius: 9 }} textStyle={{ fontSize: 11 }} iconSize={13} />
        </View>

        {/* the grid */}
        <View style={!open ? { opacity: 0.5 } : undefined} pointerEvents={open ? 'auto' : 'none'}>
          {grid()}
        </View>
        {['single', 'jodi', 'panna', 'tp'].includes(kind) ? (
          <ChartPreview mode={mode === 'sp' ? 'sp' : mode === 'dp' ? 'dp' : kind} ank={ank} session={session} marketName={market.name} slip={slip} />
        ) : null}
        <Slip tr={tr} slip={slip} removeSlip={removeSlip} clearSlip={clearSlip} onSubmit={onSubmit} />
      </ScrollView>

      {showPaste ? (
        <PasteModal
          market={market} session={session} tr={tr} onClose={() => setShowPaste(false)} showToast={showToast}
          onAdd={(items) => {
            const usable = items.filter(it => it.type !== 'tp' || kind === 'tp' || sessioned)
            const mapped = usable.map(it => ({
              marketCode: market.code,
              slot: it.type === 'jodi' ? 'jodi' : it.type === 'tp' ? 'close' : session,
              type: it.type, num: it.num, points: it.points,
              rate: game?.rate || rateFor(market.code, it.type), marketName: market.name,
              gameCode: ['single', 'jodi', 'sp', 'dp', 'tp'].includes(it.type) ? it.type : null,
            }))
            onBulkAdd(mapped)
            return mapped.length
          }}
        />
      ) : null}
      {showCharts ? (
        <PlayChartsModal marketCode={market.code} marketName={market.displayName || market.name} onClose={() => setShowCharts(false)} />
      ) : null}
    </>
  )
}

const ibtn = { width: 34, height: 34, borderRadius: 11, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center' as const, justifyContent: 'center' as const }
const cdTx = { fontSize: 12, fontWeight: '800', fontFamily: F.xbold, letterSpacing: 0.5 } as const
const cdt = { fontFamily: 'monospace' as never, fontSize: 15, letterSpacing: 1, color: '#065f46', fontWeight: '700' } as const

function CdWrap({ run, children }: { run: boolean; children: React.ReactNode }) {
  return (
    <View style={{
      flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 13,
      paddingVertical: 9, paddingHorizontal: 12, marginBottom: 10, flexWrap: 'wrap',
      backgroundColor: run ? '#ecfdf5' : C.redSoft, borderWidth: 1, borderColor: run ? '#a7f3d0' : '#fecaca',
    }}>
      {children}
    </View>
  )
}

// .pickrow + .pick chips (sangam pickers)
export function PickRow({ items, value, onPick }: {
  items: string[]; value: string | null; onPick: (v: string) => void
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginVertical: 8 }}>
      {items.map(p => (
        <Pressable key={p} onPress={() => onPick(p)} style={{
          backgroundColor: value === p ? C.p1 : C.purpleChipBg, borderRadius: 9, paddingHorizontal: 11, paddingVertical: 6,
        }}>
          <Text style={{ color: value === p ? '#fff' : C.purpleChipTx, fontWeight: '700', fontSize: 12, fontFamily: 'monospace' }}>{p}</Text>
        </Pressable>
      ))}
    </View>
  )
}

function OddEvenTile({ label, filled, mk, mkName, game, setEntry }: {
  label: string; filled: boolean; mk: string; mkName: string
  game: MarketGame | undefined
  setEntry: SlipInputFn
}) {
  const [txt, setTxt] = useState('')
  const key = mk + '|open|oddeven|' + label.toLowerCase()
  const rate = game?.rate || rateFor(mk, 'oddeven')
  return (
    <View style={{
      flex: 1, backgroundColor: C.tile, borderWidth: 1, borderColor: '#bbf7d0', borderRadius: 11,
      alignItems: 'center', paddingTop: 12, paddingBottom: 13, paddingHorizontal: 2,
    }}>
      <Text style={{ fontWeight: '800', fontSize: 16, color: C.tilet, fontFamily: 'monospace' }}>{label}</Text>
      <TextInput
        keyboardType="number-pad" placeholder="-" placeholderTextColor={C.slate} value={txt}
        onChangeText={v => {
          const vv = v.replace(/\D/g, '')
          setTxt(vv)
          setEntry(key, mk, 'open', 'oddeven', label, Number(vv) || 0, rate, mkName + ' · ' + (RATE_LBL.oddeven || 'oddeven') + ' ' + label, game?.code || null)
        }}
        style={{
          marginTop: 7, width: '92%', borderWidth: 1, borderColor: filled ? C.gold : '#bbf7d0',
          borderRadius: 7, paddingVertical: 5, paddingHorizontal: 2, fontSize: 11.5, textAlign: 'center',
          fontWeight: '700', color: filled ? '#78350f' : C.ink, backgroundColor: filled ? '#fef3c7' : '#fff',
        }}
      />
    </View>
  )
}
