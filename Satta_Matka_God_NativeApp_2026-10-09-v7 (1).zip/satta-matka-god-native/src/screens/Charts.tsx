// ──────────────────────────────────────────────────────────
// CHARTS — JodiChart (month calendar), PanelChart, StarBoard.
// Faithful RN port of InfoScreens.tsx chart views: same layout,
// colors (lavender table, red repeating jodis), month navigation.
// ──────────────────────────────────────────────────────────
import React, { useState } from 'react'
import { Pressable, ScrollView, Text, View } from 'react-native'
import { Chip, Card } from '../ui'
import { C, F } from '../theme'

export type ResultRowT = {
  marketCode: string; resultDate: string
  openPanna: string | null; closePanna: string | null
  openDigit: string | null; closeDigit: string | null; jodi: string | null
}

export const dateLabel = (ds: string): string =>
  new Date(ds + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })

const HEAD = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

// ── Jodi Chart — .jtable month grid with ‹ › navigation ──
export function JodiChart({ results, mkName }: { results: ResultRowT[]; mkName: string }) {
  const [monthOff, setMonthOff] = useState(0)
  const base = new Date()
  const n = new Date(base.getFullYear(), base.getMonth() + monthOff, 1)
  const y = n.getFullYear(), mo = n.getMonth()
  const days = new Date(y, mo + 1, 0).getDate()
  const start = (new Date(y, mo, 1).getDay() + 6) % 7
  const jodiMap: Record<string, string | null> = {}
  results.forEach(r => { jodiMap[r.resultDate] = r.jodi })
  const rows: Array<Array<{ day: number | null; j: string | null }>> = []
  let day = 1
  while (day <= days) {
    const cells: Array<{ day: number | null; j: string | null }> = []
    for (let c = 0; c < 7; c++) {
      if ((rows.length === 0 && c < start) || day > days) {
        cells.push({ day: null, j: null })
      } else {
        const ds = `${y}-${String(mo + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
        cells.push({ day, j: jodiMap[ds] ?? null })
        day++
      }
    }
    rows.push(cells)
    if (rows.length >= 6) break
  }
  return (
    <Card style={{ marginTop: 12, padding: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 9, alignItems: 'center' }}>
        <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: C.ink, flex: 1 }}>{mkName} — Jodi Chart</Text>
        <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
          <Pressable onPress={() => setMonthOff(o => o - 1)} accessibilityLabel="previous month"
            style={{ borderWidth: 1, borderColor: C.line, borderRadius: 8, width: 24, height: 24, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontWeight: '800', color: C.mut, fontSize: 13 }}>‹</Text>
          </Pressable>
          <Chip variant="c-pink">{n.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</Chip>
          <Pressable onPress={() => setMonthOff(o => Math.min(o + 1, 0))} disabled={monthOff >= 0} accessibilityLabel="next month"
            style={{ borderWidth: 1, borderColor: C.line, borderRadius: 8, width: 24, height: 24, alignItems: 'center', justifyContent: 'center', opacity: monthOff >= 0 ? 0.4 : 1 }}>
            <Text style={{ fontWeight: '800', color: C.mut, fontSize: 13 }}>›</Text>
          </Pressable>
        </View>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View>
          <View style={{ flexDirection: 'row' }}>
            {HEAD.map(d => (
              <View key={d} style={{ backgroundColor: C.purpleChipBg, borderWidth: 1, borderColor: '#e9d5ff', paddingVertical: 6, paddingHorizontal: 3, minWidth: 38, alignItems: 'center' }}>
                <Text style={{ color: C.purpleChipTx, fontSize: 9, fontWeight: '700', fontFamily: F.bold }}>{d}</Text>
              </View>
            ))}
          </View>
          {rows.map((cells, ri) => (
            <View key={ri} style={{ flexDirection: 'row' }}>
              {cells.map((c, ci) => (
                <View key={ci} style={{ borderWidth: 1, borderColor: '#e9d5ff', alignItems: 'center', justifyContent: 'center', minWidth: 38, height: 30 }}>
                  {c.day == null ? <Text> </Text> : (
                    <Text style={{ fontFamily: 'monospace', fontWeight: '700', fontSize: 10.5, color: c.j && c.j[0] === c.j[1] ? '#dc2626' : c.j ? C.ink : '#cbd5e1' }}>
                      {c.j || '·'}
                    </Text>
                  )}
                </View>
              ))}
            </View>
          ))}
        </View>
      </ScrollView>
      <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Red cells = repeating-digit jodis · data fills as results are declared</Text>
    </Card>
  )
}

// ── Panel Chart — dpboss weekly grid (operator rule 2026-10) ──
// Rows = weekly periods ("26/07 to 02/08"), columns = the days of that
// week. Each cell: OPEN panna digits stacked VERTICALLY on the left, the
// JODI big + horizontal in the centre, CLOSE panna digits stacked
// VERTICALLY on the right — mirrors the web chart exactly.
export function PanelChart({ results, mkName }: { results: ResultRowT[]; mkName: string }) {
  const weeks = React.useMemo(() => {
    const groups = new Map<string, Map<string, ResultRowT>>()
    const mondayOf = (ds: string): string => {
      const d = new Date(ds + 'T12:00:00Z')
      const shift = (d.getUTCDay() + 6) % 7 // 0 = Monday
      d.setUTCDate(d.getUTCDate() - shift)
      return d.toISOString().slice(0, 10)
    }
    for (const r of results) {
      const wk = mondayOf(r.resultDate)
      if (!groups.has(wk)) groups.set(wk, new Map())
      groups.get(wk)!.set(r.resultDate, r)
    }
    return [...groups.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([start, dayMap]) => {
        const s = new Date(start + 'T12:00:00Z')
        const e = new Date(s); e.setUTCDate(e.getUTCDate() + 6)
        const dmy = (d: Date) => `${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')}`
        const days: Array<{ ds: string; r: ResultRowT | null }> = []
        for (let i = 0; i < 7; i++) {
          const d = new Date(s); d.setUTCDate(d.getUTCDate() + i)
          const ds = d.toISOString().slice(0, 10)
          days.push({ ds, r: dayMap.get(ds) || null })
        }
        return { label: `${dmy(s)} to ${dmy(e)}`, days }
      })
  }, [results])

  const DigitCol = ({ panna }: { panna: string | null }) => (
    <View style={{ alignItems: 'center' }}>
      {panna
        ? panna.split('').map((ch, i) => (
          <Text key={i} style={{ fontSize: 9.5, lineHeight: 11, fontWeight: '700', fontFamily: 'monospace', color: C.ink }}>{ch}</Text>
        ))
        : <Text style={{ fontSize: 9.5, lineHeight: 11, fontWeight: '800', color: '#dc2626' }}>**</Text>}
    </View>
  )

  return (
    <View style={{ marginTop: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 8 }}>
        <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>{mkName} — Panel Chart</Text>
        <Chip variant="c-pink">Weekly</Chip>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View>
          {weeks.map(wk => (
            <View key={wk.label} style={{ flexDirection: 'row', marginBottom: 4 }}>
              <View style={{ width: 92, justifyContent: 'center', borderWidth: 1, borderColor: '#e9d5ff', backgroundColor: C.purpleChipBg, paddingHorizontal: 5, paddingVertical: 8 }}>
                <Text style={{ fontSize: 9.5, fontWeight: '700', color: C.purpleChipTx, fontFamily: F.bold }}>{wk.label}</Text>
              </View>
              {wk.days.map(d => {
                const red = !!d.r?.jodi && d.r.jodi[0] === d.r.jodi[1]
                return (
                  <View key={d.ds} style={{ flex: 1, minWidth: 62, borderWidth: 1, borderColor: '#e9d5ff', alignItems: 'center', justifyContent: 'center', paddingVertical: 6, paddingHorizontal: 4 }}>
                    {d.r ? (
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                        <DigitCol panna={d.r.openPanna} />
                        <Text style={{ fontSize: 14, fontWeight: '800', fontFamily: 'monospace', color: red ? '#dc2626' : C.ink, minWidth: 22, textAlign: 'center' }}>{d.r.jodi || '**'}</Text>
                        <DigitCol panna={d.r.closePanna} />
                      </View>
                    ) : (
                      <Text style={{ color: '#dc2626', fontWeight: '800', fontSize: 12, fontFamily: 'monospace' }}>**</Text>
                    )}
                  </View>
                )
              })}
            </View>
          ))}
        </View>
      </ScrollView>
      {!results.length ? <Text style={{ color: C.mut, fontSize: 12, padding: 12, fontFamily: F.reg }}>No results yet.</Text> : null}
      <Text style={{ fontSize: 11, color: C.mut, marginTop: 8, fontFamily: F.reg }}>Open panna vertical · jodi horizontal · close panna vertical · red = repeating jodi / missing result</Text>
    </View>
  )
}

// ── Starline board — .grid.g4 24 hour cells with LIVE highlight ──
export function StarBoard({ board, curH }: {
  board: Array<{ hour: number; panna: string | null; digit: string | null }>; curH: number
}) {
  const [w, setW] = useState(0)
  const gap = 8
  const cols = 4
  const cell = w ? Math.floor((w - gap * (cols - 1)) / cols) : 0
  return (
    <View style={{ marginTop: 12 }} onLayout={e => setW(e.nativeEvent.layout.width)}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 8 }}>
        <Text style={{ fontSize: 14, fontWeight: '700', fontFamily: F.sora, color: C.ink }}>BABA STARLINE — Today's Board</Text>
        <Chip variant="c-grn">{curH}:00 running</Chip>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap }}>
        {Array.from({ length: 24 }, (_, h) => {
          const r = board.find(b => b.hour === h)
          return (
            <View key={h} style={{
              width: cell, borderWidth: 1,
              borderColor: h === curH ? C.gold : C.line,
              backgroundColor: '#fff', borderRadius: 10, alignItems: 'center', paddingVertical: 7, paddingHorizontal: 2,
              opacity: h > curH ? 0.55 : 1,
            }}>
              <Text style={{ fontSize: 8.5, color: C.mut, fontFamily: F.reg }}>{String(h).padStart(2, '0')}:00 {h === curH ? '· LIVE' : h < curH ? '· done' : '· upcoming'}</Text>
              <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: 'monospace', color: C.ink, marginTop: 1 }}>
                {r && r.panna ? r.panna + '-' + r.digit : h === curH ? '…' : '—'}
              </Text>
            </View>
          )
        })}
      </View>
      <Text style={{ fontSize: 11, color: C.mut, marginTop: 9, fontFamily: F.reg }}>Declared hourly · panna + derived digit</Text>
    </View>
  )
}
