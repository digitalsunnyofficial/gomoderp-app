// ──────────────────────────────────────────────────────────
// STARLINE PLAY — faithful RN port of StarlineScreen (web):
// subbar / hour strip / rate bar / countdown / declared result
// row / single-digit grid / bet slip.
// MANAGED MODE (ERP-created starlines): when the operator has
// created starlines in the ERP, ONLY those games are shown —
// with their real names, result minutes and live state. The
// static 24-hour board is just the legacy fallback.
// ──────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react'
import { Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, fmt } from '../ui'
import { C, F, GRAD } from '../theme'
import type { SlipEntry, StarInfo } from '../lib/api'
import {
  rateFor, starHourAccepting, starlineName, fmtCountdown,
} from '../lib/matka/app-engine'
import { starBaseName, sortedStarSlots, secsToStarResult, starHHMM } from '../lib/starline'
import { todayStr } from '../ui'
import { Grid, Tile, Slip } from './PlayShared'
import type { SlipInputFn } from './MarketScreen'

export default function StarlineScreen({ initialHour, tr, wallet, board, starlines = [], slip, setEntry, removeSlip, clearSlip, onSubmit, onBack }: {
  initialHour: number | null
  tr: (k: string) => string
  wallet: number
  board: Array<{ hour: number; panna: string | null; digit: string | null }>
  starlines?: StarInfo[]
  slip: SlipEntry[]
  setEntry: SlipInputFn
  removeSlip: (i: number) => void
  clearSlip: () => void
  onSubmit: () => void
  onBack: () => void
}) {
  const insets = useSafeAreaInsets()
  const [, tick] = useState(0)
  useEffect(() => {
    const t2 = setInterval(() => tick(x => x + 1), 1000)
    return () => clearInterval(t2)
  }, [])

  // ── Managed slots (ERP-created) vs legacy 24-hour board ──
  const managed = starlines.length > 0
  const slots = managed ? sortedStarSlots(starlines) : []
  // default hour: the operator's next playable game; legacy = current hour
  const [hour, setHour] = useState<number | null>(null)
  const defHour = managed
    ? (() => {
        const nowMins = new Date().getHours() * 60 + new Date().getMinutes()
        const upcoming = slots.find(s => s.hour * 60 + (s.minute || 0) > nowMins && s.accepting)
        return (upcoming || slots.find(s => s.accepting) || slots[0])?.hour ?? new Date().getHours()
      })()
    : new Date().getHours()
  useEffect(() => {
    if (hour == null) setHour(initialHour ?? defHour)
    else if (initialHour != null) setHour(initialHour)
  }, [initialHour, defHour]) // eslint-disable-line react-hooks/exhaustive-deps
  const h = hour ?? defHour

  const slCfg = starlines.find(s => s.code === 'st' + h)
  const slot = managed ? slots.find(s => s.hour === h) : undefined
  const open = managed ? (slot?.accepting ?? false) : slCfg ? slCfg.accepting : starHourAccepting(h)
  const mk = 'st' + h
  const mkName = managed ? (slot?.name || starHHMM({ hour: h })) : slCfg?.name || starlineName(h)
  const result = board.find(b => b.hour === h)
  const title = managed ? starBaseName(starlines.map(s => s.name)) : tr('starline_title')

  // countdown → to THIS game's result time (managed) or top of hour (legacy)
  const secsLeft = managed && slot ? secsToStarResult(slot) : 3600 - (new Date().getMinutes() * 60 + new Date().getSeconds())

  const grid = () => {
    const slotKey = 'open'
    return <Grid cols={5}>{Array.from({ length: 10 }, (_, i) =>
      <Tile key={i} mk={mk} mkName={mkName} slot={slotKey} type="single" num={String(i)} big rate={rateFor(mk, 'single')} gameCode={null} slip={slip} setEntry={setEntry} />)}</Grid>
  }

  const nowMins = new Date().getHours() * 60 + new Date().getMinutes()
  const nextAccHour = managed
    ? (slots.find(s => s.accepting && s.hour !== h) ||
       slots.find(s => s.accepting))?.hour ?? null
    : (new Date().getHours() + 1) % 24

  return (
    <>
      {/* .subbar */}
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flexDirection: 'row', alignItems: 'center', gap: 9, paddingTop: insets.top + 9, paddingBottom: 9, paddingHorizontal: 12 }}>
        <Pressable onPress={onBack} style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}>
          <I n="chevron-left" size={16} color="#fff" />
        </Pressable>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text numberOfLines={1} style={{ fontSize: 14, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>{title}</Text>
          <Text numberOfLines={1} style={{ fontSize: 10, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>
            {todayStr()} · {managed ? `${slots.length} hourly game${slots.length === 1 ? '' : 's'} · results on time` : 'Hourly games · declare on the hour'}
          </Text>
        </View>
        <View style={{ backgroundColor: 'rgba(255,255,255,.92)', borderRadius: 999, paddingVertical: 6, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 5 }}>
          <I n="wallet" size={13} color="#78350f" />
          <Text style={{ color: '#78350f', fontSize: 11.5, fontWeight: '800', fontFamily: F.xbold }}>{fmt(wallet)}</Text>
        </View>
      </LinearGradient>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 48 + insets.bottom }} keyboardShouldPersistTaps="handled">
        {/* hour strip — managed: ONLY the operator's games · legacy: 24 hours */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6, paddingBottom: 8, paddingRight: 2 }}>
          {(managed ? slots : Array.from({ length: 24 }, (_, x) => ({
            code: 'st' + x, name: starlineName(x), hour: x, minute: 0,
            betClosingMinutes: 0, accepting: starHourAccepting(x), panna: null, digit: null,
          } as StarInfo))).map(sl => {
            const x = sl.hour
            const declared = board.find(b => b.hour === x)
            const sel = x === h
            const passed = sl.hour * 60 + (sl.minute || 0) <= nowMins
            return (
              <Pressable key={x} onPress={() => setHour(x)} style={{
                backgroundColor: sel ? C.p1 : '#fff', borderWidth: 1, borderColor: sel ? 'transparent' : C.line,
                borderRadius: 11, paddingHorizontal: 12, paddingVertical: 8, alignItems: 'center',
                opacity: sel ? 1 : declared ? 1 : !sl.accepting || passed ? 0.45 : 1,
              }}>
                <Text style={{ fontSize: 8.5, fontWeight: '700', fontFamily: F.bold, color: sel ? 'rgba(255,255,255,.8)' : C.mut }}>
                  {declared ? 'DECLARED' : sel ? 'PLAYING' : sl.accepting ? (x === nextAccHour ? 'NEXT' : 'OPEN') : 'GAME'}
                </Text>
                <Text style={{ fontSize: 13, fontFamily: 'monospace', fontWeight: '700', color: sel ? '#fff' : C.ink }}>
                  {starHHMM(sl)}
                </Text>
              </Pressable>
            )
          })}
        </ScrollView>

        {/* rate bar */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', borderWidth: 1, borderColor: '#d8b4fe', borderStyle: 'dashed', borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12, marginBottom: 11 }}>
          <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg, flex: 1 }} numberOfLines={1}>
            {mkName} · <Text style={{ color: open ? C.grn : C.mut, fontWeight: '800' }}>{open ? tr('accepting').toUpperCase() : tr('closed').toUpperCase()}</Text>
          </Text>
          <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}>
            Single <Text style={{ color: C.pinkT, fontSize: 13, fontWeight: '700' }}>1 : {rateFor(mk, 'single')}</Text>
          </Text>
        </View>

        {/* countdown */}
        {open ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 13, paddingVertical: 9, paddingHorizontal: 12, marginBottom: 10, backgroundColor: '#ecfdf5', borderWidth: 1, borderColor: '#a7f3d0' }}>
            <I n="timer" size={14} color="#065f46" />
            <Text style={{ fontSize: 12, fontWeight: '800', fontFamily: F.xbold, color: '#065f46' }}>{tr('time_left')} </Text>
            <Text style={{ fontFamily: 'monospace', fontSize: 15, letterSpacing: 1, color: '#065f46', fontWeight: '700' }}>{fmtCountdown(Math.max(0, secsLeft))}</Text>
          </View>
        ) : (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 13, paddingVertical: 9, paddingHorizontal: 12, marginBottom: 10, backgroundColor: C.redSoft, borderWidth: 1, borderColor: '#fecaca' }}>
            <I n="lock" size={14} color={C.red} />
            <Text style={{ fontSize: 12, fontWeight: '800', fontFamily: F.xbold, color: C.red }}>This game is closed — pick a later game above</Text>
          </View>
        )}

        {/* declared result row */}
        {result && result.panna ? (
          <View style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 11 }}>
            <Text style={{ fontSize: 13, fontWeight: '700', fontFamily: F.bold, color: C.ink }} numberOfLines={1}>Result — {mkName}</Text>
            <View style={{ borderRadius: 9, paddingVertical: 4, paddingHorizontal: 11, backgroundColor: '#7c3aed' }}>
              <Text style={{ fontFamily: 'monospace', fontWeight: '800', fontSize: 16, color: '#fff' }}>{result.panna}-{result.digit}</Text>
            </View>
          </View>
        ) : null}

        <View style={!open ? { opacity: 0.5 } : undefined} pointerEvents={open ? 'auto' : 'none'}>
          {grid()}
        </View>
        <Slip tr={tr} slip={slip} removeSlip={removeSlip} clearSlip={clearSlip} onSubmit={onSubmit} />
      </ScrollView>
    </>
  )
}
