// ── Signup — SignupView: name / mobile / password / confirm / agent code,
//    white card on the brand gradient (exact web layout) ──
import React, { useState } from 'react'
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Inp, Lbl, Btn } from '../ui'
import { C, F } from '../theme'

export default function RegisterScreen({ onSignup, onBack }: {
  onSignup: (name: string, mobile: string, password: string, referral: string) => void
  onBack: () => void
}) {
  const insets = useSafeAreaInsets()
  const [name, setName] = useState('')
  const [mobile, setMobile] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [agentCode, setAgentCode] = useState('')
  const [err, setErr] = useState('')
  const submit = () => {
    if (!name.trim()) return setErr('Enter your full name')
    if (!/^\d{10}$/.test(mobile)) return setErr('Enter a valid 10-digit mobile number')
    if (password.length < 6) return setErr('Password must be at least 6 characters')
    if (password !== confirm) return setErr('Passwords do not match')
    setErr('')
    onSignup(name.trim(), mobile, password, agentCode.trim())
  }
  return (
    <LinearGradient colors={['#6d28d9', '#db2777', '#9d174d']} start={{ x: 0, y: 0 }} end={{ x: 0.65, y: 1 }} style={{ flex: 1 }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'android' ? undefined : 'padding'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingTop: insets.top + 28, paddingBottom: insets.bottom + 28, paddingHorizontal: 28 }} keyboardShouldPersistTaps="handled">
          <View style={{ alignItems: 'center', marginBottom: 22 }}>
            <View style={{ width: 64, height: 64, borderRadius: 22, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
              <I n="gem" size={30} color="#fff" />
            </View>
            <Text style={{ fontFamily: F.sora, fontSize: 21, fontWeight: '700', color: '#fff' }}>CREATE ACCOUNT</Text>
            <Text style={{ fontSize: 11.5, opacity: 0.8, marginTop: 4, color: '#fff', fontFamily: F.reg }}>Signup and place your vyapar from the app</Text>
          </View>

          <View style={{ backgroundColor: '#fff', borderRadius: 20, padding: 22 }}>
            <Lbl>FULL NAME</Lbl>
            <Inp value={name} onChangeText={setName} placeholder="Your name" />
            <Lbl style={{ marginTop: 12 }}>MOBILE NUMBER</Lbl>
            <Inp keyboardType="number-pad" maxLength={10} value={mobile} onChangeText={v => setMobile(v.replace(/\D/g, ''))} placeholder="10-digit mobile" />
            <Lbl style={{ marginTop: 12 }}>PASSWORD</Lbl>
            <Inp secureTextEntry value={password} onChangeText={setPassword} placeholder="min 6 characters" />
            <Lbl style={{ marginTop: 12 }}>CONFIRM PASSWORD</Lbl>
            <Inp secureTextEntry value={confirm} onChangeText={setConfirm} />
            <Lbl style={{ marginTop: 12 }}>
              AGENT CODE <Text style={{ fontWeight: '600', opacity: 0.75 }}>(OPTIONAL)</Text>
            </Lbl>
            <Inp value={agentCode} onChangeText={setAgentCode} placeholder="Your agent's code / mobile" />
            <Text style={{ fontSize: 11, color: C.mut, marginTop: 5, lineHeight: 16.5, fontFamily: F.reg }}>
              Enter the code your agent gave you so your account is filed under them. You can also join without one.
            </Text>
            {err ? <Text style={{ color: C.red, fontSize: 11.5, marginTop: 8, fontFamily: F.bold }}>{err}</Text> : null}
            <Btn variant="g" icon="check" label="CREATE ACCOUNT" onPress={submit} style={{ width: '100%', marginTop: 18, paddingVertical: 13 }} />
            <Pressable style={{ alignItems: 'center', marginTop: 14 }} onPress={onBack}>
              <Text style={{ fontSize: 11, color: C.p2, fontWeight: '700', fontFamily: F.bold }}>← Back to login</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  )
}
