// ── My Bids — MyBetsScreen: filter chips, bet cards, 10s live polling ──
import React, { useEffect, useState } from 'react'
import { Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Chip, fmt, dtStr, Loading } from '../ui'
import { C, F, GRAD } from '../theme'
import { api, type MyBet, type BetsData } from '../lib/api'
import { canonicalPanna } from '../lib/matka/chart-definitions'
import { gameLabel } from '../lib/matka/games-engine'

const STATUS_CHIP: Record<string, 'c-orange' | 'c-grn' | 'c-gray'> = { pending: 'c-orange', won: 'c-grn', lost: 'c-gray' }
const TYPE_CHIP: Record<string, 'c-teal' | 'c-cyan' | 'c-orange' | 'c-yellow' | 'c-pink'> = {
  single: 'c-teal', jodi: 'c-cyan', sp: 'c-orange', dp: 'c-yellow',
  hs: 'c-pink', fs: 'c-pink', oddeven: 'c-cyan', tp: 'c-yellow',
}

export default function MyBidsScreen({ wallet, showToast, onExpired, refreshKey }: {
  wallet: number
  showToast: (m: string, cls?: 'ok' | 'err' | '') => void
  onExpired: () => void
  refreshKey?: number
}) {
  const insets = useSafeAreaInsets()
  const [filter, setFilter] = useState('all')
  const [bets, setBets] = useState<MyBet[]>([])
  const [counts, setCounts] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let live = true
    const load = (withSpinner: boolean) => {
      if (withSpinner) setLoading(true)
      api<BetsData>('/api/customer-app/bets?status=' + filter)
        .then(d => {
          if (!live) return
          setBets(d.bets || [])
          setCounts((d.counts as Record<string, number>) || {})
        })
        .catch((e: Error) => {
          if (e.message === 'SESSION_EXPIRED') onExpired()
          else showToast(e.message, 'err')
        })
        .finally(() => { if (live) setLoading(false) })
    }
    load(true)
    const t2 = setInterval(() => load(false), 10000)
    return () => { live = false; clearInterval(t2) }
  }, [filter, showToast, onExpired, refreshKey])

  return (
    <>
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingTop: insets.top + 8, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>My Bids</Text>
          <Text style={{ fontSize: 10.5, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>{counts.all || 0} total bids</Text>
        </View>
        <View style={{ backgroundColor: 'rgba(255,255,255,.92)', borderRadius: 999, paddingVertical: 6, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 5 }}>
          <I n="wallet" size={13} color="#78350f" />
          <Text style={{ color: '#78350f', fontSize: 11.5, fontWeight: '800', fontFamily: F.xbold }}>{fmt(wallet)}</Text>
        </View>
      </LinearGradient>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 100 + insets.bottom }}>
        <View style={{ flexDirection: 'row', gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
          {['all', 'pending', 'won', 'lost'].map(f => (
            <Pressable key={f} onPress={() => setFilter(f)} style={{
              backgroundColor: filter === f ? C.pink : C.slateSoft, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 999,
            }}>
              <Text style={{ fontSize: 10.5, fontWeight: '700', fontFamily: F.bold, color: filter === f ? C.pinkT : C.grayChipTx }}>
                {f.toUpperCase()} {f === 'all' ? `(${counts.all || 0})` : ''}
              </Text>
            </Pressable>
          ))}
        </View>
        {loading ? <Loading /> : null}
        {!loading && !bets.length ? <Text style={{ color: C.mut, fontSize: 12, paddingVertical: 14, fontFamily: F.reg }}>No bids here yet — go play!</Text> : null}
        {bets.map(b => (
          <View key={b.id} style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 14, paddingVertical: 12, paddingHorizontal: 14, marginBottom: 9 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 7 }}>
              <Text style={{ fontSize: 13, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{b.marketName}</Text>
              <Chip variant={STATUS_CHIP[b.status] || 'c-gray'}>{b.status}</Chip>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Chip variant={TYPE_CHIP[b.type] || 'c-gray'}>{b.type.toUpperCase()}</Chip>
                <View style={{ backgroundColor: C.purpleChipBg, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 2 }}>
                  <Text style={{ fontFamily: 'monospace', fontWeight: '800', fontSize: 14, color: C.purpleChipTx }}>{canonicalPanna(b.num)}</Text>
                </View>
                <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}>{b.slot}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={{ fontSize: 12, color: C.ink }}>
                  <Text style={{ fontWeight: '700' }}>{fmt(b.points)}</Text>
                  <Text style={{ fontSize: 11, color: C.mut }}> @1:{b.rate}</Text>
                </Text>
                <Text style={{ fontSize: 11, color: b.status === 'won' ? '#15803d' : C.mut, fontFamily: F.reg }}>
                  {b.status === 'won' ? 'won ' + fmt(b.win) : 'win pot. ' + fmt(b.points * b.rate)}
                </Text>
              </View>
            </View>
            {b.gameCode && !['single', 'jodi', 'sp', 'dp', 'tp', 'hs', 'fs', 'oddeven'].includes(b.gameCode) ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 5 }}>
                <I n="layers" size={10} color={C.mut} />
                <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}>{gameLabel(b.gameCode)}</Text>
              </View>
            ) : null}
            <Text style={{ fontSize: 11, color: C.mut, marginTop: 7, fontFamily: F.reg }}>{b.betDate} · {dtStr(b.createdAt)}</Text>
          </View>
        ))}
      </ScrollView>
    </>
  )
}
