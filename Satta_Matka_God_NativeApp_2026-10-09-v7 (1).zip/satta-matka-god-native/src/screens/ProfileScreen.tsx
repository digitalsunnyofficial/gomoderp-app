// ── Profile + Notifications — ProfileScreen / NotifsScreen (web parity):
//    avatar card with status chips, settings rows, logout; notification rows ──
import React, { useEffect, useState } from 'react'
import { Alert, Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Btn, Chip, Card, fmt, dtStr } from '../ui'
import { C, F, GRAD } from '../theme'
import { api } from '../lib/api'
import type { Customer } from '../lib/api'
import { LANGUAGES } from '../lib/matka/i18n'

export function ProfileScreen({ customer, tr, go, onLogout, onChangePassword, onSelectLanguage }: {
  customer: Customer | null
  tr: (k: string) => string
  go: (s: string) => void
  onLogout: () => void
  onChangePassword: () => void
  onSelectLanguage: () => void
}) {
  const insets = useSafeAreaInsets()
  if (!customer) {
    return (
      <View style={{ padding: 18 }}>
        <Text style={{ color: C.mut, fontSize: 12, fontFamily: F.reg }}>{tr('loading')}</Text>
      </View>
    )
  }
  const langNative = LANGUAGES.find(l => l.code === (customer.language || 'en'))?.native || 'English'
  const initials = customer.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
  return (
    <>
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingTop: insets.top + 8, paddingBottom: 12 }}>
        <Text style={{ fontSize: 15, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>{tr('nav_profile')}</Text>
        <Text style={{ fontSize: 10.5, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>Account & settings</Text>
      </LinearGradient>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 100 + insets.bottom }}>
        {/* avatar card */}
        <Card style={{ padding: 20, alignItems: 'center', marginBottom: 12 }}>
          <LinearGradient colors={[...GRAD.pav] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 64, height: 64, borderRadius: 20, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontSize: 22, fontWeight: '800', fontFamily: F.sora800 }}>{initials}</Text>
          </LinearGradient>
          <Text style={{ fontSize: 15, fontWeight: '700', fontFamily: F.bold, color: C.ink, marginTop: 10 }}>{customer.name}</Text>
          <Text style={{ fontSize: 11, color: C.mut, fontFamily: 'monospace', marginTop: 2 }}>{customer.mobile}</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
            <Chip variant={customer.status === 'active' ? 'c-grn' : 'c-red'}>{customer.status}</Chip>
            <Chip variant={customer.canBet ? 'c-teal' : 'c-red'}>Betting {customer.canBet ? 'On' : 'Off'}</Chip>
            <Chip variant={customer.canWithdraw ? 'c-teal' : 'c-red'}>Withdraw {customer.canWithdraw ? 'On' : 'Off'}</Chip>
          </View>
          {customer.agentName ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 9 }}>
              <I n="user" size={12} color={C.mut} />
              <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}>
                Agent: <Text style={{ color: C.ink, fontWeight: '700' }}>{customer.agentName}</Text>
              </Text>
            </View>
          ) : null}
          <View style={{ flexDirection: 'row', marginTop: 14, gap: 9, width: '100%' }}>
            <Btn variant="g" icon="wallet" label={fmt(customer.wallet)} onPress={() => go('wallet')} style={{ flex: 1 }} />
          </View>
        </Card>

        {/* settings rows */}
        <Card style={{ overflow: 'hidden' }}>
          <RowItem icon="receipt" label={tr('nav_bids')} onPress={() => go('mybids')} />
          <RowItem icon="bell" label="Notifications" onPress={() => go('notifs')} />
          <RowItem icon="circle" label={tr('language')} value={langNative} onPress={onSelectLanguage} />
          <RowItem icon="key-round" label={tr('change_password')} onPress={onChangePassword} last />
        </Card>

        {/* version card */}
        <Card style={{ marginTop: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, paddingHorizontal: 14 }}>
            <I n="info" size={17} color={C.p2} />
            <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}>Satta Matka God · v1.2 · customer app</Text>
          </View>
        </Card>

        <Btn variant="red" icon="log-out" label={tr('logout')} onPress={onLogout} style={{ width: '100%', marginTop: 12, paddingVertical: 13 }} />
      </ScrollView>
    </>
  )
}

function RowItem({ icon, label, value, onPress, last }: {
  icon: string; label: string; value?: string; onPress: () => void; last?: boolean
}) {
  return (
    <Pressable onPress={onPress} android_ripple={{ color: '#f1f5f9' }} style={{
      flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, paddingHorizontal: 14,
      borderBottomWidth: last ? 0 : 1, borderBottomColor: C.line,
    }}>
      <I n={icon} size={17} color={C.p2} />
      <Text style={{ fontSize: 13.5, fontWeight: '600', fontFamily: F.semi, color: C.ink, flex: 1 }}>{label}</Text>
      {value ? <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg }}>{value}</Text> : null}
      <I n="chevron-right" size={15} color="#cbd5e5" />
    </Pressable>
  )
}

// ── Notifications ──
export function NotificationsScreen({ onBack }: { onBack: () => void }) {
  const insets = useSafeAreaInsets()
  const [notifs, setNotifs] = useState<Array<{ id: string; icon: string; text: string; createdAt: string }>>([])
  useEffect(() => {
    api<{ notifications: Array<{ id: string; icon: string; text: string; createdAt: string }> }>('/api/customer-app/notifications')
      .then(d => setNotifs(d.notifications || []))
      .catch(() => {})
  }, [])
  return (
    <>
      <LinearGradient colors={[...GRAD.brand] as [string, string]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingTop: insets.top + 8, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Pressable onPress={onBack} style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}>
          <I n="chevron-left" size={16} color="#fff" />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontFamily: F.sora, fontWeight: '700', color: '#fff' }}>Notifications</Text>
          <Text style={{ fontSize: 10.5, opacity: 0.85, color: '#fff', fontFamily: F.reg }}>{notifs.length} messages</Text>
        </View>
      </LinearGradient>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 100 + insets.bottom }}>
        {notifs.map(n => (
          <View key={n.id} style={{ backgroundColor: '#fff', borderWidth: 1, borderColor: C.line, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: C.purpleChipBg, alignItems: 'center', justifyContent: 'center' }}>
              <I n={n.icon || 'bell'} size={16} color={C.p1} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 12.5, fontWeight: '700', fontFamily: F.bold, color: C.ink }}>{n.text}</Text>
              <Text style={{ fontSize: 11, color: C.mut, fontFamily: F.reg, marginTop: 2 }}>{dtStr(n.createdAt)}</Text>
            </View>
          </View>
        ))}
        {!notifs.length ? <Text style={{ color: C.mut, fontSize: 12, padding: 12, fontFamily: F.reg }}>No notifications yet.</Text> : null}
      </ScrollView>
    </>
  )
}

// keep Alert import used (web parity: profile rows use alert())
void Alert
