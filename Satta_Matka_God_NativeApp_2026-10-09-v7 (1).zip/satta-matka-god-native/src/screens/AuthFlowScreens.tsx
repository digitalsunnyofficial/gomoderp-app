// ── Awaiting approval + Language ask — AwaitApprovalView / LangAskView ──
import React from 'react'
import { Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Btn, Lbl } from '../ui'
import { C, F } from '../theme'
import { t, LANGUAGES, type Lang } from '../lib/matka/i18n'

export function AwaitApprovalScreen({ tr, onBack }: { tr: (k: string) => string; onBack: () => void }) {
  const insets = useSafeAreaInsets()
  return (
    <LinearGradient colors={['#6d28d9', '#db2777', '#9d174d']} start={{ x: 0, y: 0 }} end={{ x: 0.65, y: 1 }} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingTop: insets.top + 28, paddingBottom: insets.bottom + 28, paddingHorizontal: 28 }}>
        <View style={{ alignItems: 'center', marginBottom: 20 }}>
          <View style={{ width: 74, height: 74, borderRadius: 24, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
            <I n="info" size={34} color="#fff" />
          </View>
          <Text style={{ fontFamily: F.sora, fontSize: 21, fontWeight: '700', color: '#fff' }}>{tr('await_title')}</Text>
        </View>
        <View style={{ backgroundColor: '#fff', borderRadius: 20, padding: 22 }}>
          <Text style={{ fontSize: 12, lineHeight: 19, color: C.ink, fontFamily: F.reg }}>{tr('await_text')}</Text>
          <View style={{ flexDirection: 'row', backgroundColor: C.awaitWarnBg, borderRadius: 11, paddingHorizontal: 13, paddingVertical: 10, marginTop: 14, gap: 8, alignItems: 'center' }}>
            <I n="alert-triangle" size={15} color={C.awaitWarnTx} />
            <Text style={{ fontSize: 11, color: C.awaitWarnTx, fontWeight: '700', fontFamily: F.bold, flex: 1 }}>{tr('await_warn')}</Text>
          </View>
          <Btn variant="g" icon="log-in" label={tr('back_to_login')} onPress={onBack} style={{ width: '100%', marginTop: 16, paddingVertical: 13 }} />
        </View>
      </ScrollView>
    </LinearGradient>
  )
}

export function LangAskScreen({ current, onPick }: { current: Lang; onPick: (l: Lang) => void }) {
  const insets = useSafeAreaInsets()
  return (
    <LinearGradient colors={['#6d28d9', '#db2777', '#9d174d']} start={{ x: 0, y: 0 }} end={{ x: 0.65, y: 1 }} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingTop: insets.top + 28, paddingBottom: insets.bottom + 28, paddingHorizontal: 28 }}>
        <View style={{ alignItems: 'center', marginBottom: 22 }}>
          <View style={{ width: 74, height: 74, borderRadius: 24, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
            <I n="circle" size={34} color="#fff" />
          </View>
          <Text style={{ fontFamily: F.sora, fontSize: 21, fontWeight: '700', color: '#fff' }}>{t(current, 'choose_language')}</Text>
          <Text style={{ fontSize: 11.5, opacity: 0.8, marginTop: 4, color: '#fff', fontFamily: F.reg }}>{t(current, 'choose_language_sub')}</Text>
        </View>
        <View style={{ backgroundColor: '#fff', borderRadius: 20, padding: 18, gap: 9 }}>
          {LANGUAGES.map(l => (
            <Pressable key={l.code} onPress={() => onPick(l.code)} style={{
              flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, paddingHorizontal: 14,
              borderWidth: 1, borderColor: C.line, borderRadius: 13,
              backgroundColor: current === l.code ? C.lavender : '#fff',
            }}>
              <I n="circle" size={17} color={C.p2} />
              <Text style={{ fontSize: 13.5, fontWeight: '600', fontFamily: F.semi, color: C.ink }}>{l.native}</Text>
              <Text style={{ fontSize: 11, color: C.mut, marginLeft: 8, fontFamily: F.reg }}>{l.label}</Text>
              <View style={{ marginLeft: 'auto' }}><I n="chevron-right" size={15} color="#cbd5e5" /></View>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  )
}
