// ── Login — LoginView: gradient bg, frosted logo, white card, pre-login
//    language chips, mobile + password, gold CTA, "New here?" link ──
import React, { useState } from 'react'
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { I, Inp, Lbl, Btn } from '../ui'
import { C, F } from '../theme'
import { t, LANGUAGES, type Lang } from '../lib/matka/i18n'

export default function LoginScreen({ onLogin, onSignup, ui, setUi }: {
  onLogin: (mobile: string, password: string) => void
  onSignup: () => void
  ui: Lang
  setUi: (l: Lang) => void
}) {
  const insets = useSafeAreaInsets()
  const [mobile, setMobile] = useState('')
  const [password, setPassword] = useState('')
  const tr = (k: string) => t(ui, k)
  return (
    <LinearGradient colors={['#6d28d9', '#db2777', '#9d174d']} start={{ x: 0, y: 0 }} end={{ x: 0.65, y: 1 }} style={{ flex: 1 }}>
      <StatusBarLight />
      <KeyboardAvoidingView behavior={Platform.OS === 'android' ? undefined : 'padding'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingTop: insets.top + 28, paddingBottom: insets.bottom + 28, paddingHorizontal: 28 }} keyboardShouldPersistTaps="handled">
          <View style={{ alignItems: 'center', marginBottom: 20 }}>
            <View style={{ width: 74, height: 74, borderRadius: 24, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
              <I n="gem" size={34} color="#fff" />
            </View>
            <Text style={{ fontFamily: F.sora, fontSize: 23, fontWeight: '700', color: '#fff' }}>{tr('login_title')}</Text>
            <Text style={{ fontSize: 11.5, opacity: 0.8, marginTop: 4, color: '#fff', fontFamily: F.reg }}>{tr('login_sub')}</Text>
          </View>

          <View style={{ backgroundColor: '#fff', borderRadius: 20, padding: 22 }}>
            <View style={{ flexDirection: 'row', gap: 7, justifyContent: 'center', marginBottom: 16 }}>
              {LANGUAGES.map(l => (
                <Pressable key={l.code} onPress={() => setUi(l.code)} style={{
                  paddingVertical: 6, paddingHorizontal: 12, borderRadius: 999,
                  backgroundColor: ui === l.code ? C.pink : C.slateSoft,
                }}>
                  <Text style={{ fontSize: 12, fontWeight: '700', fontFamily: F.bold, color: ui === l.code ? C.pinkT : C.grayChipTx }}>{l.native}</Text>
                </Pressable>
              ))}
            </View>

            <Lbl>{tr('mobile')}</Lbl>
            <Inp keyboardType="number-pad" maxLength={10} value={mobile} onChangeText={v => setMobile(v.replace(/\D/g, ''))} />
            <Lbl style={{ marginTop: 13 }}>{tr('password')}</Lbl>
            <Inp secureTextEntry value={password} onChangeText={setPassword} />

            <Btn variant="g" icon="log-in" label={tr('login_btn')} onPress={() => onLogin(mobile, password)} style={{ width: '100%', marginTop: 18, paddingVertical: 13 }} />
            <Pressable style={{ alignItems: 'center', marginTop: 14 }} onPress={onSignup}>
              <Text style={{ fontSize: 11, color: C.p2, fontWeight: '700', fontFamily: F.bold }}>{tr('new_here')}</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  )
}

export function StatusBarLight() {
  // real status bar is driven from App.tsx (expo-status-bar, light content)
  return null
}
