// ── Splash — .splash (purple/pink gradient, frosted gem, pulse) ──
import React, { useEffect, useRef } from 'react'
import { Animated, Easing, Text, View } from 'react-native'
import { LinearGradient } from 'expo-linear-gradient'
import { I } from '../ui'
import { F } from '../theme'

export default function SplashScreen() {
  const pulse = useRef(new Animated.Value(1)).current
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.07, duration: 800, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 800, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ]),
    )
    loop.start()
    return () => loop.stop()
  }, [pulse])
  return (
    <LinearGradient colors={['#6d28d9', '#db2777', '#9d174d']} start={{ x: 0, y: 0 }} end={{ x: 0.6, y: 1 }} style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14 }}>
      <Animated.View style={{ width: 84, height: 84, borderRadius: 26, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center', transform: [{ scale: pulse }] }}>
        <I n="gem" size={40} color="#fff" />
      </Animated.View>
      <View style={{ alignItems: 'center' }}>
        <Text style={{ fontFamily: F.sora, fontSize: 26, fontWeight: '700', color: '#fff' }}>MATKA BAZAAR</Text>
        <Text style={{ opacity: 0.8, fontSize: 12, marginTop: 4, color: '#fff', fontFamily: F.reg }}>Play · Results · Wallet</Text>
      </View>
      <Text style={{ fontSize: 11, opacity: 0.7, color: '#fff', fontFamily: F.reg }}>Loading…</Text>
    </LinearGradient>
  )
}
