// ──────────────────────────────────────────────────────────
// THEME — EXACT port of the web customer app design system
// (src/components/customerapp/shell.tsx → APP_CSS :root vars).
// The web customer app is the ONLY UI source of truth; this
// file mirrors its palette, gradients and type ramp 1:1.
// ──────────────────────────────────────────────────────────
export const C = {
  p1: '#6d28d9',      // --p1
  p2: '#db2777',      // --p2
  gold: '#f59e0b',    // --gold
  gold2: '#fbbf24',   // --gold2
  grn: '#16a34a',     // --grn
  tile: '#dcfce7',    // --tile
  tilet: '#166534',   // --tilet
  pink: '#fce7f3',    // --pink
  pinkT: '#be185d',   // --pinkT
  ink: '#1e293b',     // --ink
  bg: '#f4f6fb',      // --bg
  line: '#e2e8f0',    // --line
  mut: '#64748b',     // --mut
  white: '#ffffff',
  amberBg: '#fef3c7', amberTx: '#92400e', amberTx2: '#b45309',
  darkBrown: '#451a03', darkBrownTx: '#fde68a',
  amberSoft: '#fffbeb',
  blueSoft: '#eff6ff', blueLine: '#bfdbfe',
  red: '#b91c1c', redSoft: '#fee2e2', redLine: '#fecaca',
  greenTx: '#15803d', greenSoft: '#dcfce7', greenLine: '#bbf7d0',
  slate: '#94a3b8', slateSoft: '#f1f5f9',
  cream: '#fdf6ec',
  awaitWarnBg: '#fef3c7', awaitWarnTx: '#78350f',
  purpleSoft: '#faf5ff', purpleTx: '#7e22ce', purpleLine: '#e9d5ff',
  purpleChipBg: '#ede9fe', purpleChipTx: '#5b21b6', purpleChipBg2: '#f3e8ff', purpleChipTx2: '#6b21a8',
  lavender: '#FDF2F8', lavenderLine: '#fbcfe8',
  tealTx: '#0f766e', tealSoft: '#ccfbf1',
  cyanTx: '#0e7490', cyanSoft: '#cffafe',
  orangeTx: '#c2410c', orangeSoft: '#ffedd5',
  yellowTx: '#854d0e', yellowSoft: '#fef08a',
  goldSoft: '#fef3c7', goldTx: '#b45309',
  grnChipTx: '#15803d',
  grayChipTx: '#64748b',
  okToast: '#0f766e',
}

// Gradients — every linear-gradient in APP_CSS, named after its class
export const GRAD = {
  brand: ['#6d28d9', '#db2777'] as const,                 // appbar/sb 92deg
  brandDeep: ['#6d28d9', '#db2777', '#9d174d'] as const,  // auth screens 165deg
  splash: ['#6d28d9', '#db2777', '#9d174d'] as const,     // 160deg
  gold: ['#f59e0b', '#fbbf24'] as const,                  // btn-g 135deg
  purpleBtn: ['#6d28d9', '#db2777'] as const,             // btn-p
  bannerFallback: ['#7c3aed', '#db2777'] as const,        // home fallback banner
  starCard: ['#ede9fe', '#fce7f3'] as const,              // starline home card
  wcard: ['#6d28d9', '#db2777'] as const,                 // wallet card 125deg
  run: ['#15803d', '#16a34a', '#15803d'] as const,        // mstat.run
  stop: ['#b91c1c', '#dc2626', '#b91c1c'] as const,       // mstat.stop
  res: ['#6d28d9', '#9333ea', '#6d28d9'] as const,        // mstat.res
  playGo: ['#16a34a', '#22c55e'] as const,                // mplay.go
  playNo: ['#dc2626', '#ef4444'] as const,                // mplay.no
  playRes: ['#7c3aed', '#a855f7'] as const,               // mplay.res
  mico: ['#fef3c7', '#fde68a'] as const,                  // market card icon box
  promptClosed: ['#f43f5e', '#dc2626'] as const,          // pmodal .ph.closed
  promptResult: ['#7c3aed', '#db2777'] as const,          // pmodal .ph.result
  cdRun: ['#ecfdf5', '#d1fae5'] as const,                 // cdwrap.run
  jodiB: ['#6d28d9', '#db2777'] as const,                 // jodi badge
  pav: ['#6d28d9', '#db2777'] as const,                   // profile avatar
}

// Font family names (loaded in App.tsx via @expo-google-fonts)
export const F = {
  reg: 'Inter_400Regular',
  med: 'Inter_500Medium',
  semi: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
  xbold: 'Inter_800ExtraBold',
  sora600: 'Sora_600SemiBold',
  sora: 'Sora_700Bold',
  sora800: 'Sora_800ExtraBold',
}

export const RADIUS = { inp: 10, btn: 12, chip: 999, card: 16, tile: 11, resrow: 13, mcard: 18, sheet: 22, prompt: 24 }
