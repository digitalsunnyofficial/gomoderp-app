Satta Matka God — full stack + NATIVE customer app (v7, 2026-10-09)

  erp-customer-app/     Next.js backend + ERP + web customer app (push + Phase-2 APIs)
  satta-matka-god-native/  TRUE NATIVE Android app (Expo/React Native — no WebView)

  v7 = CRITICAL APK CONNECTIVITY FIX (2026-10-09) — replace src/lib/config.ts
       + app.json and REBUILD THE APK:
    • the app shipped with extra.apiBase = http://10.0.2.2:3000 — the ANDROID
      EMULATOR loopback. On a real phone EVERY request died before reaching
      the server → "sign in failed", no signup, no login. app.json now points
      at https://godmoderp.online (edit extra.apiBase if the domain changes)
    • config.ts: dev builds can override with
      EXPO_PUBLIC_DEV_API_BASE=http://<lan-ip>:3000 npx expo start
      release builds always use extra.apiBase
    • NOTE: the first release APK built from older sources can NEVER reach
      the production server — this rebuild is mandatory for all customers.
  v6 = ON-DEVICE BUG-FIX BUILD (2026-10-09) — fixes all 6 issues found in
       real-device testing. REPLACE THE WHOLE NATIVE FOLDER + REBUILD APK:
    • back button no longer exits the app — hardware back navigates
      (inner screens → home, signup → login); exit only from home
    • starline screen now shows the ADMIN-CREATED hourly starlines from
      the ERP (name, HH:MM, live countdown) — static "BABA STARLINE"
      placeholder removed (shows only when admin has created none)
    • triple-pana (TP) bettable again — server window fix: TP accepted
      through the WHOLE market window and settles on the close panna
    • numeric-only inputs everywhere — points/amount boxes accept digits
      only (words/letters can no longer be typed); UTR is alnum-upper
    • bottom gap fixed — toast sits above the gesture bar on every
      device (bottom: 88 + safe-area inset), starline scroll padding
      corrected (150 → 48)
    • notices & banners are now MANAGED from the ERP: ERP ▸ App Wallet ▸
      App Content (new master-admin page) edits the same AppConfig keys
      the web app + native app read — change once, both apps update

  v5 = OPERATOR RULES BUILD (2026-10-09):
    • bet-window wording now says "bets stop at the open/close time"
      (open/close times = bet cutoffs; Jodi only during the Open session)
    • automatic app notifications: result declared, winner, deposit
      approved/rejected, withdrawal paid/rejected, betting-open /
      close-session-live / closes-in-10-min reminders (60s cron, deduped)
    • ERP ▸ Starlines ▸ "Generate Hourly Slots" — one config creates the
      full day of hourly starlines (Main Star Line 09:05 AM ... 08:05 PM)
    • UPI auto-capture: app "Pay with UPI App" intent + POST /api/upi/
      auto-verify feed → wallet credited automatically (ERP ▸ Payment
      Management ▸ UPI Auto-Credit: ON + webhook secret)
    • agent commission withdrawal flow: ERP ▸ Agent Commission — agent
      files request, master pays (FIFO settles commission rows exactly)
    • panel chart rebuilt dpboss-style: weekly rows, open/close panna
      digits vertical, jodi horizontal (web + native)
    • native UI: status-bar-safe headers, gesture-bar-safe bottom nav +
      scroll padding, keyboard no longer covers inputs (resize mode +
      KeyboardAvoidingView in all sheets)

  v4 = v3 UI-PARITY BUILD + packaging fix + /customerapp download page:
    • FIXED: v3 zip shipped the BACKEND package.json inside the native
      folder and dropped App.tsx / app.json / index.ts / tsconfig.json /
      babel.config.js — the native project now zips correctly
    • NEW /customerapp route — https://your-domain/customerapp is the
      public APK download link (page + direct file)
    • landing page now carries the full customer guide with screenshots
    • NEW master-admin App Notifications panel: ERP ▸ App Wallet ▸
      App Notifications — broadcast / approved / pending / per-agent /
      single-customer messages with in-app + Expo push delivery,
      history and retract (API: /api/app-admin/notifications)

  v3 UI parity (unchanged in v4): every native screen is a faithful conversion of the
  web customer app (/app) — purple/pink gradient, white cards, gold actions,
  bottom navigation, language selector, banners, market cards, play screen
  with the full game engine, wallet, results/charts, my bids, notifications.
  The web customer app is the ONLY UI source of truth.

  What changed in v6 (exact files):
    • satta-matka-god-native/App.tsx — BackHandler hardware-back routing
    • satta-matka-god-native/src/lib/starline.ts — NEW starline helpers
    • satta-matka-god-native/src/screens/StarlineScreen.tsx — managed
      starlines from /api/customer-app/results?starline=1, countdowns
    • satta-matka-god-native/src/screens/HomeScreen.tsx — starline card
      uses managed data; marquee static-when-short
    • satta-matka-god-native/src/screens/MarketScreen.tsx — TP live
      window + lock text + sangam digit filters; padding 28 → 40
    • satta-matka-god-native/src/screens/PlayShared.tsx — digit-only
      point inputs
    • satta-matka-god-native/src/screens/Modals.tsx — digit-only amount
      inputs + UTR alnum-uppercase
    • satta-matka-god-native/src/ui.tsx — Toast bottom 96 → 88 + inset
    • erp-customer-app/src/app/api/customer-app/bets/route.ts — TP
      bettable through the whole window (settles close panna)
    • erp-customer-app/src/components/pages/AppContentPage.tsx — ERP
      editor for notice/banners (mounted as App Wallet ▸ App Content)
    • erp-customer-app/src/lib/navigation.ts / access-control.ts /
      store.ts + src/app/merp/page.tsx — App Content page wiring

  What changed in v3:
    • theme.ts/ui.tsx rebuilt from the web APP_CSS design tokens
    • all 13 screens re-skinned + web-exact modals (deposit QR, withdraw,
      confirm slip, password, market-closed, result-declared prompts)
    • bottom nav (home/starline/bids/results/profile) like the web shell
    • language ask screen + pre-login language chips (EN/HI/GU/MR)
    • full play engine ported: game allocation tabs, tiles grids, ank
      chips, sangam pickers, seed/ank-family panels, WhatsApp paste,
      live chart preview, bet slip with clientRequestId idempotency
    • engines copied verbatim from src/lib/matka (single source of truth)
    • Inter + Sora fonts, purple/pink launcher + splash assets

  SETUP_NATIVE_APP.md   how to run + build the APK (start here)
  UPDATE_FROM_V1.md     replace-list for existing installs

Backend:  cd erp-customer-app && npm install && npx prisma generate && npm run dev
Native:   cd satta-matka-god-native && npm install && npx expo install --fix
APK:      SETUP_NATIVE_APP.md §4  → publish per §5 (public/downloads/satta-matka-god.apk)
