# Updating an EXISTING install (v1 VS Code zip or Task-31/32 native zip)

If your VS Code folder already runs the v1 backend, you do NOT need to replace
everything — the backend changes from Task 31 (push) and Task 32 (Phase-2
screens) are small and additive. The v3 native app is a UI-PARITY rebuild:
replace the WHOLE `satta-matka-god-native/` folder (section B).

## A. Backend (erp-customer-app) — replace only these

New files (copy from the zip):

- `src/lib/push/expo-push.ts`
- `src/app/api/customer-app/push/register/route.ts`

Replace these existing files (copy over):

- `prisma/schema.prisma` (adds `AppCustomer.pushToken`)
- `src/app/api/app-admin/funds/route.ts` (deposit push)
- `src/app/api/app-admin/withdrawals/route.ts` (withdrawal push)
- `src/app/api/app-admin/results/route.ts` (result broadcast + win push)
- `src/app/api/customer-app/results/route.ts` (Task 32 — additive `months`
  param that powers the native Jodi-chart month navigation)

Do NOT replace: `db/custom.db` (your live data stays), `.env`, `node_modules`.

Then:

```bash
npx prisma generate
npm run db:push        # adds the pushToken column — data preserved
npm run dev
```

Verify: `curl -i http://localhost:3000/api/customer-app/push/register` → 401.

## B. Native app — REPLACE THE WHOLE FOLDER (v3 UI-parity)

v3 rebuilds every screen to match the web customer app exactly (purple/pink
gradient, white cards, gold actions, bottom nav, language selector, full play
engine). Delete your existing `satta-matka-god-native/` folder and copy the
one from this zip, then:

```bash
cd satta-matka-god-native
rm -rf node_modules package-lock.json   # fresh deps: new packages were added
npm install
npx expo install --fix                  # aligns native module versions
```

New v3 dependencies (installed by the steps above): expo-linear-gradient,
react-native-svg, lucide-react-native, expo-clipboard, expo-font,
@expo-google-fonts/inter, @expo-google-fonts/sora.

Then follow `satta-matka-god-native/SETUP_NATIVE_APP.md` to run/build the APK.
Note: `app.json` now ships `versionCode 2` — bump it for every release build.

## C. Optional kill switch

Add to backend `.env`: `PUSH_ENABLED=false` to disable sending pushes
(tokens are still stored).
